import { DataViewPassThrough, DataViewLazyLoadEvent, DataViewPageEvent, DataViewSortEvent, DataViewLayoutChangeEvent, DataViewListTemplateContext, DataViewGridTemplateContext, DataViewPaginatorLeftTemplateContext, DataViewPaginatorRightTemplateContext, DataViewPaginatorDropdownItemTemplateContext, DataViewPaginatorState } from '@wawjs/ngx-prime/types/dataview';
export * from '@wawjs/ngx-prime/types/dataview';
import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { BlockableUI, Header, Footer, FilterService } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import { Subscription } from 'rxjs';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class DataViewStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-dataview-list': boolean;
            'p-dataview-grid': boolean;
        })[];
        header: string;
        loading: string;
        loadingOverlay: string;
        loadingIcon: string;
        pcPaginator: ({ position }: {
            position: any;
        }) => string;
        content: string;
        emptyMessage: string;
        footer: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DataViewStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<DataViewStyle>;
}
/**
 *
 * DataView displays data in grid or list layout with pagination and sorting features.
 *
 * [Live Demo](https://www.ngx-prime.org/dataview/)
 *
 * @module dataviewstyle
 *
 */
declare enum DataViewClasses {
    /**
     * Class name of the root element
     */
    root = "p-dataview",
    /**
     * Class name of the header element
     */
    header = "p-dataview-header",
    /**
     * Class name of the loading element
     */
    loading = "p-dataview-loading",
    /**
     * Class name of the loading overlay element
     */
    loadingOverlay = "p-dataview-loading-overlay",
    /**
     * Class name of the loading icon element
     */
    loadingIcon = "p-dataview-loading-icon",
    /**
     * Class name of the paginator element
     */
    pcPaginator = "p-dataview-paginator-[position]",
    /**
     * Class name of the content element
     */
    content = "p-dataview-content",
    /**
     * Class name of the empty message element
     */
    emptyMessage = "p-dataview-empty-message",
    /**
     * Class name of the footer element
     */
    footer = "p-dataview-footer"
}

/**
 * DataView displays data in grid or list layout with pagination and sorting features.
 * @group Components
 */
declare class DataView extends BaseComponent<DataViewPassThrough> implements BlockableUI {
    componentName: string;
    bindDirectiveInstance: Bind;
    $pcDataView: DataView | undefined;
    onAfterViewChecked(): void;
    /**
     * When specified as true, enables the pagination.
     * @group Props
     */
    paginator: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Number of rows to display per page.
     * @group Props
     */
    rows: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Number of total records, defaults to length of value when not defined.
     * @group Props
     */
    totalRecords: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Number of page links to display in paginator.
     * @group Props
     */
    pageLinks: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Array of integer/object values to display inside rows per page dropdown of paginator
     * @group Props
     */
    rowsPerPageOptions: _angular_core.InputSignal<any[] | number[] | undefined>;
    /**
     * Position of the paginator.
     * @group Props
     */
    paginatorPosition: _angular_core.InputSignal<"top" | "bottom" | "both">;
    /**
     * Custom style class for paginator
     * @group Props
     */
    paginatorStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to show it even there is only one page.
     * @group Props
     */
    alwaysShowPaginator: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Target element to attach the paginator dropdown overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @group Props
     */
    paginatorDropdownAppendTo: _angular_core.InputSignal<any>;
    /**
     * Paginator dropdown height of the viewport in pixels, a scrollbar is defined if height of list exceeds this value.
     * @group Props
     */
    paginatorDropdownScrollHeight: _angular_core.InputSignal<string>;
    /**
     * Template of the current page report element. Available placeholders are {currentPage},{totalPages},{rows},{first},{last} and {totalRecords}
     * @group Props
     */
    currentPageReportTemplate: _angular_core.InputSignal<string>;
    /**
     * Whether to display current page report.
     * @group Props
     */
    showCurrentPageReport: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Whether to display a dropdown to navigate to any page.
     * @group Props
     */
    showJumpToPageDropdown: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When enabled, icons are displayed on paginator to go first and last page.
     * @group Props
     */
    showFirstLastIcon: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to show page links.
     * @group Props
     */
    showPageLinks: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Defines if data is loaded and interacted with in lazy manner.
     * @group Props
     */
    lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to call lazy loading on initialization.
     * @group Props
     */
    lazyLoadOnInit: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Text to display when there is no data. Defaults to global value in i18n translation configuration.
     * @group Props
     */
    emptyMessage: _angular_core.InputSignal<string>;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the grid.
     * @group Props
     */
    gridStyleClass: _angular_core.InputSignal<string>;
    /**
     * Function to optimize the dom operations by delegating to ngForTrackBy, default algorithm checks for object identity.
     * @group Props
     */
    trackBy: _angular_core.InputSignal<(...args: any[]) => any>;
    /**
     * Comma separated list of fields in the object graph to search against.
     * @group Props
     */
    filterBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Locale to use in filtering. The default locale is the host environment's current locale.
     * @group Props
     */
    filterLocale: _angular_core.InputSignal<string | undefined>;
    /**
     * Displays a loader to indicate data load is in progress.
     * @group Props
     */
    loading: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * The icon to show while indicating data load is in progress.
     * @group Props
     */
    loadingIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Index of the first row to be displayed.
     * @group Props
     */
    first: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Property name of data to use in sorting by default.
     * @group Props
     */
    sortField: _angular_core.InputSignal<string | undefined>;
    /**
     * Order to sort the data by default.
     * @group Props
     */
    sortOrder: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * An array of objects to display.
     * @group Props
     */
    value: _angular_core.InputSignal<any[] | undefined>;
    /**
     * Defines the layout mode.
     * @group Props
     */
    layout: _angular_core.InputSignal<"list" | "grid">;
    /**
     * Callback to invoke when paging, sorting or filtering happens in lazy mode.
     * @param {DataViewLazyLoadEvent} event - Custom lazy load event.
     * @group Emits
     */
    onLazyLoad: _angular_core.OutputEmitterRef<DataViewLazyLoadEvent>;
    /**
     * Callback to invoke when pagination occurs.
     * @param {DataViewPageEvent} event - Custom page event.
     * @group Emits
     */
    onPage: _angular_core.OutputEmitterRef<DataViewPageEvent>;
    /**
     * Callback to invoke when sorting occurs.
     * @param {DataViewSortEvent} event - Custom sort event.
     * @group Emits
     */
    onSort: _angular_core.OutputEmitterRef<DataViewSortEvent>;
    /**
     * Callback to invoke when changing layout.
     * @param {DataViewLayoutChangeEvent} event - Custom layout change event.
     * @group Emits
     */
    onChangeLayout: _angular_core.OutputEmitterRef<DataViewLayoutChangeEvent>;
    /**
     * Template for the list layout.
     * @param {DataViewListTemplateContext} context - list template context.
     * @group Templates
     */
    readonly listTemplate: _angular_core.Signal<Nullable<TemplateRef<DataViewListTemplateContext<any>>>>;
    /**
     * Template for grid layout.
     * @param {DataViewGridTemplateContext} context - grid template context.
     * @group Templates
     */
    readonly gridTemplate: _angular_core.Signal<TemplateRef<DataViewGridTemplateContext<any>> | undefined>;
    /**
     * Template for the header section.
     * @group Templates
     */
    headerTemplate: TemplateRef<void>;
    /**
     * Template for the empty message section.
     * @group Templates
     */
    readonly emptymessageTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Template for the footer section.
     * @group Templates
     */
    footerTemplate: TemplateRef<void>;
    /**
     * Template for the left side of paginator.
     * @param {DataViewPaginatorLeftTemplateContext} context - paginator left template context.
     * @group Templates
     */
    readonly paginatorleft: _angular_core.Signal<TemplateRef<DataViewPaginatorLeftTemplateContext> | undefined>;
    /**
     * Template for the right side of paginator.
     * @param {DataViewPaginatorRightTemplateContext} context - paginator right template context.
     * @group Templates
     */
    readonly paginatorright: _angular_core.Signal<TemplateRef<DataViewPaginatorRightTemplateContext> | undefined>;
    /**
     * Template for items in paginator dropdown.
     * @param {DataViewPaginatorDropdownItemTemplateContext} context - paginator dropdown item template context.
     * @group Templates
     */
    readonly paginatordropdownitem: _angular_core.Signal<TemplateRef<DataViewPaginatorDropdownItemTemplateContext> | undefined>;
    /**
     * Template for loading icon.
     * @group Templates
     */
    readonly loadingicon: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Template for list icon.
     * @group Templates
     */
    readonly listicon: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Template for grid icon.
     * @group Templates
     */
    readonly gridicon: _angular_core.Signal<TemplateRef<void> | undefined>;
    readonly header: _angular_core.Signal<Header | undefined>;
    readonly footer: _angular_core.Signal<Footer | undefined>;
    filteredValue: Nullable<any[]>;
    filterValue: Nullable<string>;
    initialized: Nullable<boolean>;
    _layout: 'list' | 'grid';
    translationSubscription: Nullable<Subscription>;
    _componentStyle: DataViewStyle;
    _first: number;
    _rows: number | undefined;
    _totalRecords: number | undefined;
    private isFirstLayoutChange;
    get emptyMessageLabel(): string;
    filterService: FilterService;
    constructor();
    onInit(): void;
    onAfterViewInit(): void;
    updateTotalRecords(): void;
    paginate(event: DataViewPaginatorState): void;
    sort(): void;
    isEmpty(): boolean;
    createLazyLoadMetadata(): DataViewLazyLoadEvent;
    getBlockableElement(): HTMLElement;
    filter(filter: string, filterMatchMode?: string): void;
    hasFilter(): boolean | "" | null | undefined;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DataView, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DataView, "p-dataView, p-dataview, p-data-view", never, { "paginator": { "alias": "paginator"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "totalRecords": { "alias": "totalRecords"; "required": false; "isSignal": true; }; "pageLinks": { "alias": "pageLinks"; "required": false; "isSignal": true; }; "rowsPerPageOptions": { "alias": "rowsPerPageOptions"; "required": false; "isSignal": true; }; "paginatorPosition": { "alias": "paginatorPosition"; "required": false; "isSignal": true; }; "paginatorStyleClass": { "alias": "paginatorStyleClass"; "required": false; "isSignal": true; }; "alwaysShowPaginator": { "alias": "alwaysShowPaginator"; "required": false; "isSignal": true; }; "paginatorDropdownAppendTo": { "alias": "paginatorDropdownAppendTo"; "required": false; "isSignal": true; }; "paginatorDropdownScrollHeight": { "alias": "paginatorDropdownScrollHeight"; "required": false; "isSignal": true; }; "currentPageReportTemplate": { "alias": "currentPageReportTemplate"; "required": false; "isSignal": true; }; "showCurrentPageReport": { "alias": "showCurrentPageReport"; "required": false; "isSignal": true; }; "showJumpToPageDropdown": { "alias": "showJumpToPageDropdown"; "required": false; "isSignal": true; }; "showFirstLastIcon": { "alias": "showFirstLastIcon"; "required": false; "isSignal": true; }; "showPageLinks": { "alias": "showPageLinks"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "lazyLoadOnInit": { "alias": "lazyLoadOnInit"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "gridStyleClass": { "alias": "gridStyleClass"; "required": false; "isSignal": true; }; "trackBy": { "alias": "trackBy"; "required": false; "isSignal": true; }; "filterBy": { "alias": "filterBy"; "required": false; "isSignal": true; }; "filterLocale": { "alias": "filterLocale"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "loadingIcon": { "alias": "loadingIcon"; "required": false; "isSignal": true; }; "first": { "alias": "first"; "required": false; "isSignal": true; }; "sortField": { "alias": "sortField"; "required": false; "isSignal": true; }; "sortOrder": { "alias": "sortOrder"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; }, { "onLazyLoad": "onLazyLoad"; "onPage": "onPage"; "onSort": "onSort"; "onChangeLayout": "onChangeLayout"; }, ["listTemplate", "gridTemplate", "emptymessageTemplate", "paginatorleft", "paginatorright", "paginatordropdownitem", "loadingicon", "listicon", "gridicon", "header", "footer", "headerTemplate", "footerTemplate"], ["p-header", "p-footer"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class DataViewModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DataViewModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<DataViewModule, never, [typeof DataView, typeof i2.SharedModule], [typeof DataView, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<DataViewModule>;
}

export { DataView, DataViewClasses, DataViewModule, DataViewStyle };
