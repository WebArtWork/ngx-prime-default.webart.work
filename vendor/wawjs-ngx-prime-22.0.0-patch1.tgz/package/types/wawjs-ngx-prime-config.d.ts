import * as rxjs from 'rxjs';
import * as _wawjs_ngx_prime_api from '@wawjs/ngx-prime/api';
import { OverlayOptions, Translation, PassThroughOptions } from '@wawjs/ngx-prime/api';
import * as _wawjs_ngx_prime_config from '@wawjs/ngx-prime/config';
import * as _angular_core from '@angular/core';
import { ElementRef, TemplateRef, OnDestroy, InjectionToken, EnvironmentProviders } from '@angular/core';
import { AccordionPassThrough } from '@wawjs/ngx-prime/types/accordion';
import { AutoCompletePassThrough } from '@wawjs/ngx-prime/types/autocomplete';
import { AvatarPassThrough } from '@wawjs/ngx-prime/types/avatar';
import { AvatarGroupPassThrough } from '@wawjs/ngx-prime/types/avatargroup';
import { BadgePassThrough } from '@wawjs/ngx-prime/types/badge';
import { BlockUIPassThrough } from '@wawjs/ngx-prime/types/blockui';
import { BreadcrumbPassThrough } from '@wawjs/ngx-prime/types/breadcrumb';
import { ButtonPassThrough } from '@wawjs/ngx-prime/types/button';
import { CardPassThrough } from '@wawjs/ngx-prime/types/card';
import { CarouselPassThrough } from '@wawjs/ngx-prime/types/carousel';
import { CascadeSelectPassThrough } from '@wawjs/ngx-prime/types/cascadeselect';
import { CheckboxPassThrough } from '@wawjs/ngx-prime/types/checkbox';
import { ChipPassThrough } from '@wawjs/ngx-prime/types/chip';
import { ColorPickerPassThrough } from '@wawjs/ngx-prime/types/colorpicker';
import { ConfirmDialogPassThrough } from '@wawjs/ngx-prime/types/confirmdialog';
import { ConfirmPopupPassThrough } from '@wawjs/ngx-prime/types/confirmpopup';
import { DialogPassThrough } from '@wawjs/ngx-prime/types/dialog';
import { DividerPassThrough } from '@wawjs/ngx-prime/types/divider';
import { DockPassThrough } from '@wawjs/ngx-prime/types/dock';
import { DrawerPassThrough } from '@wawjs/ngx-prime/types/drawer';
import { EditorPassThrough } from '@wawjs/ngx-prime/types/editor';
import { FieldsetPassThrough } from '@wawjs/ngx-prime/types/fieldset';
import { FileUploadPassThrough } from '@wawjs/ngx-prime/types/fileupload';
import { FloatLabelPassThrough } from '@wawjs/ngx-prime/types/floatlabel';
import { FluidPassThrough } from '@wawjs/ngx-prime/types/fluid';
import { GalleriaPassThrough } from '@wawjs/ngx-prime/types/galleria';
import { IconFieldPassThrough } from '@wawjs/ngx-prime/types/iconfield';
import { IftaLabelPassThrough } from '@wawjs/ngx-prime/types/iftalabel';
import { ImagePassThrough } from '@wawjs/ngx-prime/types/image';
import { ImageComparePassThrough } from '@wawjs/ngx-prime/types/imagecompare';
import { InplacePassThrough } from '@wawjs/ngx-prime/types/inplace';
import { InputGroupPassThrough } from '@wawjs/ngx-prime/types/inputgroup';
import { InputGroupAddonPassThrough } from '@wawjs/ngx-prime/types/inputgroupaddon';
import { InputIconPassThrough } from '@wawjs/ngx-prime/types/inputicon';
import { InputMaskPassThrough } from '@wawjs/ngx-prime/types/inputmask';
import { InputNumberPassThrough } from '@wawjs/ngx-prime/types/inputnumber';
import { InputOtpPassThrough } from '@wawjs/ngx-prime/types/inputotp';
import { InputTextPassThrough } from '@wawjs/ngx-prime/types/inputtext';
import { KnobPassThrough } from '@wawjs/ngx-prime/types/knob';
import { MegaMenuPassThrough } from '@wawjs/ngx-prime/types/megamenu';
import { MenuPassThrough } from '@wawjs/ngx-prime/types/menu';
import { MenubarPassThrough } from '@wawjs/ngx-prime/types/menubar';
import { MessagePassThrough } from '@wawjs/ngx-prime/types/message';
import { MeterGroupPassThrough } from '@wawjs/ngx-prime/types/metergroup';
import { OrderListPassThrough } from '@wawjs/ngx-prime/types/orderlist';
import { OrganizationChartPassThrough } from '@wawjs/ngx-prime/types/organizationchart';
import { OverlayBadgePassThrough } from '@wawjs/ngx-prime/types/overlaybadge';
import { PanelPassThrough } from '@wawjs/ngx-prime/types/panel';
import { PanelMenuPassThrough } from '@wawjs/ngx-prime/types/panelmenu';
import { PopoverPassThrough } from '@wawjs/ngx-prime/types/popover';
import { ProgressBarPassThrough } from '@wawjs/ngx-prime/types/progressbar';
import { ProgressSpinnerPassThrough } from '@wawjs/ngx-prime/types/progressspinner';
import { RadioButtonPassThrough } from '@wawjs/ngx-prime/types/radiobutton';
import { RatingPassThrough } from '@wawjs/ngx-prime/types/rating';
import { VirtualScrollerPassThrough } from '@wawjs/ngx-prime/types/scroller';
import { ScrollPanelPassThrough } from '@wawjs/ngx-prime/types/scrollpanel';
import { ScrollTopPassThrough } from '@wawjs/ngx-prime/types/scrolltop';
import { SelectPassThrough } from '@wawjs/ngx-prime/types/select';
import { SelectButtonPassThrough } from '@wawjs/ngx-prime/types/selectbutton';
import { SkeletonPassThrough } from '@wawjs/ngx-prime/types/skeleton';
import { SliderPassThrough } from '@wawjs/ngx-prime/types/slider';
import { SpeedDialPassThrough } from '@wawjs/ngx-prime/types/speeddial';
import { SplitButtonPassThrough } from '@wawjs/ngx-prime/types/splitbutton';
import { SplitterPassThrough } from '@wawjs/ngx-prime/types/splitter';
import { StepperPassThrough } from '@wawjs/ngx-prime/types/stepper';
import { ColumnFilterPassThrough, TablePassThrough } from '@wawjs/ngx-prime/types/table';
import { TabsPassThrough, TabPassThrough, TabListPassThrough, TabPanelPassThrough, TabPanelsPassThrough } from '@wawjs/ngx-prime/types/tabs';
import { TagPassThrough } from '@wawjs/ngx-prime/types/tag';
import { TerminalPassThrough } from '@wawjs/ngx-prime/types/terminal';
import { TieredMenuPassThrough } from '@wawjs/ngx-prime/types/tieredmenu';
import { TimelinePassThrough } from '@wawjs/ngx-prime/types/timeline';
import { ToastPassThrough } from '@wawjs/ngx-prime/types/toast';
import { ToggleButtonPassThrough } from '@wawjs/ngx-prime/types/togglebutton';
import { ToggleSwitchPassThrough } from '@wawjs/ngx-prime/types/toggleswitch';
import { ToolbarPassThrough } from '@wawjs/ngx-prime/types/toolbar';
import { TreePassThrough } from '@wawjs/ngx-prime/types/tree';
import { TreeSelectPassThrough } from '@wawjs/ngx-prime/types/treeselect';
import { TreeTablePassThrough } from '@wawjs/ngx-prime/types/treetable';
import { BaseStyle } from '@wawjs/ngx-prime/base';

/** ZIndex configuration */
type ZIndex = {
    modal: number;
    overlay: number;
    menu: number;
    tooltip: number;
};
/** Theme configuration */
type ThemeType = {
    preset?: any;
    options?: any;
} | 'none' | boolean | undefined;
type ThemeConfigType = {
    theme?: ThemeType;
    csp?: {
        nonce: string | undefined;
    };
};
interface GlobalPassThrough {
    accordion?: AccordionPassThrough;
    autoComplete?: AutoCompletePassThrough;
    avatar?: AvatarPassThrough;
    avatarGroup?: AvatarGroupPassThrough;
    blockUI?: BlockUIPassThrough;
    breadcrumb?: BreadcrumbPassThrough;
    card?: CardPassThrough;
    carousel?: CarouselPassThrough;
    cascadeSelect?: CascadeSelectPassThrough;
    checkbox?: CheckboxPassThrough;
    chip?: ChipPassThrough;
    colorPicker?: ColorPickerPassThrough;
    columnFilter?: ColumnFilterPassThrough;
    confirmDialog?: ConfirmDialogPassThrough;
    confirmPopup?: ConfirmPopupPassThrough;
    dialog?: DialogPassThrough;
    divider?: DividerPassThrough;
    dock?: DockPassThrough;
    megaMenu?: MegaMenuPassThrough;
    drawer?: DrawerPassThrough;
    editor?: EditorPassThrough;
    fileUpload?: FileUploadPassThrough;
    floatLabel?: FloatLabelPassThrough;
    menu?: MenuPassThrough;
    menubar?: MenubarPassThrough;
    fluid?: FluidPassThrough;
    galleria?: GalleriaPassThrough;
    iconField?: IconFieldPassThrough;
    iftaLabel?: IftaLabelPassThrough;
    inputIcon?: InputIconPassThrough;
    image?: ImagePassThrough;
    imageCompare?: ImageComparePassThrough;
    inplace?: InplacePassThrough;
    inputText?: InputTextPassThrough;
    inputGroup?: InputGroupPassThrough;
    inputGroupAddon?: InputGroupAddonPassThrough;
    inputMask?: InputMaskPassThrough;
    inputNumber?: InputNumberPassThrough;
    inputOtp?: InputOtpPassThrough;
    knob?: KnobPassThrough;
    popover?: PopoverPassThrough;
    message?: MessagePassThrough;
    meterGroup?: MeterGroupPassThrough;
    orderList?: OrderListPassThrough;
    organizationChart?: OrganizationChartPassThrough;
    overlayBadge?: OverlayBadgePassThrough;
    progressBar?: ProgressBarPassThrough;
    progressSpinner?: ProgressSpinnerPassThrough;
    radioButton?: RadioButtonPassThrough;
    rating?: RatingPassThrough;
    virtualScroller?: VirtualScrollerPassThrough;
    scrollPanel?: ScrollPanelPassThrough;
    scrollTop?: ScrollTopPassThrough;
    select?: SelectPassThrough;
    selectButton?: SelectButtonPassThrough;
    skeleton?: SkeletonPassThrough;
    slider?: SliderPassThrough;
    speedDial?: SpeedDialPassThrough;
    splitButton?: SplitButtonPassThrough;
    splitter?: SplitterPassThrough;
    stepper?: StepperPassThrough;
    tabs?: TabsPassThrough;
    tab?: TabPassThrough;
    tabList?: TabListPassThrough;
    tabPanel?: TabPanelPassThrough;
    tabPanels?: TabPanelsPassThrough;
    table?: TablePassThrough;
    tieredMenu?: TieredMenuPassThrough;
    timeline?: TimelinePassThrough;
    tag?: TagPassThrough;
    terminal?: TerminalPassThrough;
    toast?: ToastPassThrough;
    toggleButton?: ToggleButtonPassThrough;
    toggleSwitch?: ToggleSwitchPassThrough;
    toolbar?: ToolbarPassThrough;
    tree?: TreePassThrough;
    treeSelect?: TreeSelectPassThrough;
    treeTable?: TreeTablePassThrough;
    panel?: PanelPassThrough;
    panelMenu?: PanelMenuPassThrough;
    button?: ButtonPassThrough;
    badge?: BadgePassThrough;
    fieldset?: FieldsetPassThrough;
    global?: {
        css?: string;
    };
    [key: string]: any;
}
type NgxPrimeConfigType = {
    ripple?: boolean;
    overlayAppendTo?: HTMLElement | ElementRef | TemplateRef<any> | string | null | undefined | any;
    /**
     * @deprecated Since v20. Use `inputVariant` instead.
     */
    inputStyle?: 'outlined' | 'filled';
    inputVariant?: 'outlined' | 'filled';
    overlayOptions?: OverlayOptions;
    translation?: Translation;
    /**
     * @experimental
     * This property is not yet implemented. It will be available in a future release.
     */
    unstyled?: boolean;
    zIndex?: ZIndex | null | undefined;
    pt?: GlobalPassThrough | null | undefined;
    ptOptions?: PassThroughOptions | null | undefined;
    filterMatchModeOptions?: any;
} & ThemeConfigType;

declare class ThemeProvider implements OnDestroy {
    theme: _angular_core.WritableSignal<any>;
    csp: _angular_core.WritableSignal<{
        nonce: string | undefined;
    }>;
    isThemeChanged: boolean;
    document: Document;
    baseStyle: BaseStyle;
    constructor();
    ngOnDestroy(): void;
    onThemeChange(value: any): void;
    loadCommonTheme(): void;
    setThemeConfig(config: ThemeConfigType): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ThemeProvider, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ThemeProvider>;
}

declare class NgxPrime extends ThemeProvider {
    ripple: _angular_core.WritableSignal<boolean>;
    platformId: any;
    /**
     * @deprecated Since v20. Use `inputVariant` instead.
     */
    inputStyle: _angular_core.WritableSignal<"outlined" | "filled" | null>;
    inputVariant: _angular_core.WritableSignal<"outlined" | "filled" | null>;
    overlayAppendTo: _angular_core.WritableSignal<any>;
    overlayOptions: OverlayOptions;
    csp: _angular_core.WritableSignal<{
        nonce: string | undefined;
    }>;
    unstyled: _angular_core.WritableSignal<boolean | undefined>;
    pt: _angular_core.WritableSignal<_wawjs_ngx_prime_config.GlobalPassThrough | null | undefined>;
    ptOptions: _angular_core.WritableSignal<_wawjs_ngx_prime_api.PassThroughOptions | null | undefined>;
    filterMatchModeOptions: {
        text: string[];
        numeric: string[];
        date: string[];
    };
    translation: Translation;
    zIndex: ZIndex;
    private translationSource;
    translationObserver: rxjs.Observable<any>;
    getTranslation(key: string): any;
    setTranslation(value: Translation): void;
    setConfig(config: NgxPrimeConfigType): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NgxPrime, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<NgxPrime>;
}

declare const PRIME_NG_CONFIG: InjectionToken<NgxPrimeConfigType>;
declare function provideNgxPrime(...features: NgxPrimeConfigType[]): EnvironmentProviders;

export { NgxPrime, PRIME_NG_CONFIG, ThemeProvider, provideNgxPrime };
export type { GlobalPassThrough, NgxPrimeConfigType, ThemeConfigType, ThemeType, ZIndex };
