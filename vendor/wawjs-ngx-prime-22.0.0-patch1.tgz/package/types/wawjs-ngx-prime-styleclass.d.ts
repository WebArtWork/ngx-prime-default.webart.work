import * as _angular_core from '@angular/core';
import { OnDestroy, ElementRef, Renderer2 } from '@angular/core';
import { VoidListener } from '@wawjs/ngx-prime/ts-helpers';

/**
 * StyleClass manages css classes declaratively to during enter/leave animations or just to toggle classes on an element.
 * @group Components
 */
declare class StyleClass implements OnDestroy {
    el: ElementRef<any>;
    renderer: Renderer2;
    private zone;
    /**
     * Selector to define the target element. Available selectors are '@next', '@prev', '@parent' and '@grandparent'.
     * @group Props
     */
    selector: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class to add when item begins to get displayed.
     * @group Props
     */
    enterFromClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class to add during enter animation.
     * @group Props
     */
    enterActiveClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class to add when item begins to get displayed.
     * @group Props
     */
    enterToClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class to add when item begins to get hidden.
     * @group Props
     */
    leaveFromClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class to add during leave animation.
     * @group Props
     */
    leaveActiveClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class to add when leave animation is completed.
     * @group Props
     */
    leaveToClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to trigger leave animation when outside of the element is clicked.
     * @group Props
     */
    hideOnOutsideClick: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Adds or removes a class when no enter-leave animation is required.
     * @group Props
     */
    toggleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to trigger leave animation when escape key pressed.
     * @group Props
     */
    hideOnEscape: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Whether to trigger leave animation when the target element resized.
     * @group Props
     */
    hideOnResize: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Target element to listen resize. Valid values are "window", "document" or target element selector.
     * @group Props
     */
    resizeSelector: _angular_core.InputSignal<string | undefined>;
    eventListener: VoidListener;
    documentClickListener: VoidListener;
    documentKeydownListener: VoidListener;
    windowResizeListener: VoidListener;
    resizeObserver: ResizeObserver | undefined;
    target: HTMLElement | null | undefined;
    enterListener: VoidListener;
    leaveListener: VoidListener;
    animating: boolean | undefined;
    _enterClass: string | undefined;
    _leaveClass: string | undefined;
    _resizeTarget: any;
    clickListener(): void;
    toggle(): void;
    enter(): void;
    leave(): void;
    bindDocumentClickListener(): void;
    bindDocumentKeydownListener(): void;
    isVisible(): boolean;
    isOutsideClick(event: MouseEvent): boolean;
    unbindDocumentClickListener(): void;
    unbindDocumentKeydownListener(): void;
    bindResizeListener(): void;
    unbindResizeListener(): void;
    bindWindowResizeListener(): void;
    unbindWindowResizeListener(): void;
    bindElementResizeListener(): void;
    unbindElementResizeListener(): void;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<StyleClass, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<StyleClass, "[pStyleClass]", never, { "selector": { "alias": "pStyleClass"; "required": false; "isSignal": true; }; "enterFromClass": { "alias": "enterFromClass"; "required": false; "isSignal": true; }; "enterActiveClass": { "alias": "enterActiveClass"; "required": false; "isSignal": true; }; "enterToClass": { "alias": "enterToClass"; "required": false; "isSignal": true; }; "leaveFromClass": { "alias": "leaveFromClass"; "required": false; "isSignal": true; }; "leaveActiveClass": { "alias": "leaveActiveClass"; "required": false; "isSignal": true; }; "leaveToClass": { "alias": "leaveToClass"; "required": false; "isSignal": true; }; "hideOnOutsideClick": { "alias": "hideOnOutsideClick"; "required": false; "isSignal": true; }; "toggleClass": { "alias": "toggleClass"; "required": false; "isSignal": true; }; "hideOnEscape": { "alias": "hideOnEscape"; "required": false; "isSignal": true; }; "hideOnResize": { "alias": "hideOnResize"; "required": false; "isSignal": true; }; "resizeSelector": { "alias": "resizeSelector"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class StyleClassModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<StyleClassModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<StyleClassModule, never, [typeof StyleClass], [typeof StyleClass]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<StyleClassModule>;
}

export { StyleClass, StyleClassModule };
