import { PanelPassThrough, PanelBeforeToggleEvent, PanelHeaderIconsTemplateContext } from '@wawjs/ngx-prime/types/panel';
export * from '@wawjs/ngx-prime/types/panel';
import * as _angular_core from '@angular/core';
import { TemplateRef, ElementRef } from '@angular/core';
import { MotionOptions, MotionEvent } from '@wawjs/css-prime-motion';
import * as i2 from '@wawjs/ngx-prime/api';
import { BlockableUI, Footer, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class PanelStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-panel-toggleable': any;
            'p-panel-expanded': any;
            'p-panel-collapsed': any;
        })[];
        header: string;
        title: string;
        headerActions: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-panel-icons-start': boolean;
            'p-panel-icons-end': boolean;
            'p-panel-icons-center': boolean;
        })[];
        pcToggleButton: string;
        contentContainer: string;
        contentWrapper: string;
        content: string;
        footer: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PanelStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<PanelStyle>;
}
/**
 *
 * Panel is a container with the optional content toggle feature.
 *
 * [Live Demo](https://www.ngx-prime.org/panel/)
 *
 * @module panelstyle
 *
 */
declare enum PanelClasses {
    /**
     * Class name of the root element
     */
    root = "p-panel",
    /**
     * Class name of the header element
     */
    header = "p-panel-header",
    /**
     * Class name of the title element
     */
    title = "p-panel-title",
    /**
     * Class name of the header actions element
     */
    headerActions = "p-panel-header-actions",
    /**
     * Class name of the toggle button element
     */
    pcToggleButton = "p-panel-toggle-button",
    /**
     * Class name of the content container element
     */
    contentContainer = "p-panel-content-container",
    /**
     * Class name of the content wrapper element
     */
    contentWrapper = "p-panel-content-wrapper",
    /**
     * Class name of the content element
     */
    content = "p-panel-content",
    /**
     * Class name of the footer element
     */
    footer = "p-panel-footer"
}

/**
 * Panel is a container with the optional content toggle feature.
 * @group Components
 */
declare class Panel extends BaseComponent<PanelPassThrough> implements BlockableUI {
    componentName: string;
    $pcPanel: Panel | undefined;
    _componentStyle: PanelStyle;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Id of the component.
     */
    id: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines if content of panel can be expanded and collapsed.
     * @group Props
     */
    toggleable: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Header text of the panel.
     * @group Props
     */
    _header: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines the initial state of panel content, supports one or two-way binding as well.
     * @group Props
     */
    collapsed: _angular_core.ModelSignal<boolean | undefined>;
    /**
     * Style class of the component.
     * @group Props
     * @deprecated since v20.0.0, use `class` instead.
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Position of the icons.
     * @group Props
     */
    iconPos: _angular_core.InputSignal<"start" | "end" | "center">;
    /**
     * Specifies if header of panel cannot be displayed.
     * @group Props
     */
    showHeader: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Specifies the toggler element to toggle the panel content.
     * @group Props
     */
    toggler: _angular_core.InputSignal<"header" | "icon">;
    /**
     * Transition options of the animation.
     * @group Props
     * @deprecated since v21.0.0, use `motionOptions` instead.
     */
    transitionOptions: _angular_core.InputSignal<string>;
    /**
     * Used to pass all properties of the ButtonProps to the Button component.
     * @group Props
     */
    toggleButtonProps: _angular_core.InputSignal<any>;
    /**
     * The motion options.
     * @group Props
     */
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    computedMotionOptions: _angular_core.Signal<MotionOptions>;
    /**
     * Callback to invoke before panel toggle.
     * @param {PanelBeforeToggleEvent} event - Custom panel toggle event
     * @group Emits
     */
    onBeforeToggle: _angular_core.OutputEmitterRef<PanelBeforeToggleEvent>;
    /**
     * Callback to invoke after panel toggle.
     * @param {PanelAfterToggleEvent} event - Custom panel toggle event
     * @group Emits
     */
    onAfterToggle: _angular_core.OutputEmitterRef<PanelBeforeToggleEvent>;
    readonly footerFacet: _angular_core.Signal<Footer | undefined>;
    /**
     * Defines template option for header.
     * @group Templates
     */
    readonly headerTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Defines template option for icons.
     * @example
     * ```html
     * <ng-template #icons> </ng-template>
     * ```
     * @group Templates
     */
    readonly iconsTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Defines template option for content.
     * @example
     * ```html
     * <ng-template #content> </ng-template>
     * ```
     * @group Templates
     */
    readonly contentTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Defines template option for footer.
     * @example
     * ```html
     * <ng-template #footer> </ng-template>
     * ```
     * @group Templates
     */
    footerTemplate: TemplateRef<void> | undefined;
    /**
     * Defines template option for headerIcon.
     * @param {PanelHeaderIconsTemplateContext} context - context of the template.
     * @example
     * ```html
     * <ng-template #headericons let-collapsed> </ng-template>
     * ```
     * @see {@link PanelHeaderIconsTemplateContext}
     * @group Templates
     */
    readonly headerIconsTemplate: _angular_core.Signal<TemplateRef<PanelHeaderIconsTemplateContext> | undefined>;
    _headerTemplate: TemplateRef<void> | undefined;
    _iconsTemplate: TemplateRef<void> | undefined;
    _contentTemplate: TemplateRef<void> | undefined;
    _footerTemplate: TemplateRef<void> | undefined;
    _headerIconsTemplate: TemplateRef<PanelHeaderIconsTemplateContext> | undefined;
    contentWrapperViewChild: ElementRef;
    get buttonAriaLabel(): string | undefined;
    onHeaderClick(event: MouseEvent): void;
    onIconClick(event: MouseEvent): void;
    toggle(event: MouseEvent): void;
    expand(): void;
    collapse(): void;
    getBlockableElement(): HTMLElement;
    updateTabIndex(): void;
    onKeyDown(event: KeyboardEvent): void;
    onToggleDone(event: MotionEvent): void;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    onAfterContentInit(): void;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Panel, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Panel, "p-panel", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "toggleable": { "alias": "toggleable"; "required": false; "isSignal": true; }; "_header": { "alias": "header"; "required": false; "isSignal": true; }; "collapsed": { "alias": "collapsed"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "iconPos": { "alias": "iconPos"; "required": false; "isSignal": true; }; "showHeader": { "alias": "showHeader"; "required": false; "isSignal": true; }; "toggler": { "alias": "toggler"; "required": false; "isSignal": true; }; "transitionOptions": { "alias": "transitionOptions"; "required": false; "isSignal": true; }; "toggleButtonProps": { "alias": "toggleButtonProps"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; }, { "collapsed": "collapsedChange"; "onBeforeToggle": "onBeforeToggle"; "onAfterToggle": "onAfterToggle"; }, ["footerFacet", "headerTemplate", "iconsTemplate", "contentTemplate", "headerIconsTemplate", "templates", "footerTemplate"], ["p-header", "*", "p-footer"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class PanelModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PanelModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<PanelModule, never, [typeof Panel, typeof i2.SharedModule, typeof i1.BindModule], [typeof Panel, typeof i2.SharedModule, typeof i1.BindModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<PanelModule>;
}

export { Panel, PanelClasses, PanelModule, PanelStyle };
