import * as _angular_core from '@angular/core';
import { ElementRef, TemplateRef } from '@angular/core';
import { MotionOptions } from '@wawjs/css-prime-motion';
import * as i2 from '@wawjs/ngx-prime/api';
import { OverlayOptions, ScrollerOptions, TreeNode, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Fluid } from '@wawjs/ngx-prime/fluid';
import { Overlay } from '@wawjs/ngx-prime/overlay';
import { TreeFilterEvent, TreeNodeSelectEvent, Tree, TreeNodeUnSelectEvent } from '@wawjs/ngx-prime/tree';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import { TreeSelectPassThrough, TreeSelectNodeExpandEvent, TreeSelectNodeCollapseEvent, TreeSelectValueTemplateContext, TreeSelectHeaderTemplateContext, TreeSelectItemTogglerIconTemplateContext, TreeSelectItemCheckboxIconTemplateContext } from '@wawjs/ngx-prime/types/treeselect';
export * from '@wawjs/ngx-prime/types/treeselect';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class TreeSelectStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-treeselect-display-chip': boolean;
            'p-disabled': any;
            'p-invalid': any;
            'p-focus': any;
            'p-variant-filled': boolean;
            'p-inputwrapper-filled': boolean;
            'p-inputwrapper-focus': any;
            'p-treeselect-open': any;
            'p-treeselect-clearable': any;
            'p-treeselect-fluid': any;
            'p-treeselect-sm p-inputfield-sm': boolean;
            'p-treeselect-lg p-inputfield-lg': boolean;
        })[];
        labelContainer: string;
        label: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-placeholder': boolean;
            'p-treeselect-label-empty': any;
        })[];
        clearIcon: string;
        chip: string;
        pcChip: string;
        dropdown: string;
        dropdownIcon: string;
        panel: string;
        treeContainer: string;
        emptyMessage: string;
    };
    inlineStyles: {
        root: ({ instance }: {
            instance: any;
        }) => any;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TreeSelectStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TreeSelectStyle>;
}
/**
 *
 * TreeSelect is a form component to choose from hierarchical data.
 *
 * [Live Demo](https://www.ngx-prime.org/treeselect/)
 *
 * @module treeselectstyle
 *
 */
declare enum TreeSelectClasses {
    /**
     * Class name of the root element
     */
    root = "p-treeselect",
    /**
     * Class name of the label container element
     */
    labelContainer = "p-treeselect-label-container",
    /**
     * Class name of the label element
     */
    label = "p-treeselect-label",
    /**
     * Class name of the chip item element
     */
    chipItem = "p-treeselect-chip-item",
    /**
     * Class name of the clear icon element
     */
    clearIcon = "p-treeselect-clear-icon",
    /**
     * Class name of the chip element
     */
    pcChip = "p-treeselect-chip",
    /**
     * Class name of the dropdown element
     */
    dropdown = "p-treeselect-dropdown",
    /**
     * Class name of the dropdown icon element
     */
    dropdownIcon = "p-treeselect-dropdown-icon",
    /**
     * Class name of the panel element
     */
    panel = "p-treeselect-overlay",
    /**
     * Class name of the tree container element
     */
    treeContainer = "p-treeselect-tree-container",
    /**
     * Class name of the empty message element
     */
    emptyMessage = "p-treeselect-empty-message"
}

declare const TREESELECT_VALUE_ACCESSOR: any;
/**
 * TreeSelect is a form component to choose from hierarchical data.
 * @group Components
 */
declare class TreeSelect extends BaseEditableHolder<TreeSelectPassThrough> {
    componentName: string;
    $pcTreeSelect: TreeSelect | undefined;
    bindDirectiveInstance: Bind;
    _componentStyle: TreeSelectStyle;
    onAfterViewChecked(): void;
    /**
     * Identifier of the underlying input element.
     * @group Props
     */
    inputId: _angular_core.InputSignal<string | undefined>;
    /**
     * Height of the viewport, a scrollbar is defined if height of list exceeds this value.
     * @group Props
     */
    scrollHeight: _angular_core.InputSignal<string>;
    /**
     * Defines how multiple items can be selected, when true metaKey needs to be pressed to select or unselect an item and when set to false selection of each item can be toggled individually. On touch enabled devices, metaKeySelection is turned off automatically.
     * @group Props
     */
    metaKeySelection: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Defines how the selected items are displayed.
     * @group Props
     */
    display: _angular_core.InputSignal<"chip" | "comma">;
    /**
     * Defines the selection mode.
     * @group Props
     */
    selectionMode: _angular_core.InputSignal<"single" | "multiple" | "checkbox">;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the input for accessibility.
     * @group Props
     */
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Label to display when there are no selections.
     * @group Props
     */
    placeholder: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the overlay panel.
     * @group Props
     */
    panelClass: _angular_core.InputSignal<string | Set<string> | {
        [klass: string]: any;
    } | string[] | undefined>;
    /**
     * Inline style of the panel element.
     * @group Props
     */
    panelStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the panel element.
     * @group Props
     */
    panelStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the container element.
     * @deprecated since v20.0.0, use `style` instead.
     * @group Props
     */
    containerStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the container element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    containerStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the label element.
     * @group Props
     */
    labelStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the label element.
     * @group Props
     */
    labelStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Specifies the options for the overlay.
     * @group Props
     */
    overlayOptions: _angular_core.InputSignal<OverlayOptions | undefined>;
    /**
     * Text to display when there are no options available. Defaults to value from ngx-prime locale configuration.
     * @group Props
     */
    emptyMessage: _angular_core.InputSignal<string>;
    /**
     * When specified, displays an input field to filter the items.
     * @group Props
     */
    filter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When filtering is enabled, filterBy decides which field or fields (comma separated) to search against.
     * @group Props
     */
    filterBy: _angular_core.InputSignal<string>;
    /**
     * Mode for filtering valid values are "lenient" and "strict". Default is lenient.
     * @group Props
     */
    filterMode: _angular_core.InputSignal<string>;
    /**
     * Placeholder text to show when filter input is empty.
     * @group Props
     */
    filterPlaceholder: _angular_core.InputSignal<string | undefined>;
    /**
     * Locale to use in filtering. The default locale is the host environment's current locale.
     * @group Props
     */
    filterLocale: _angular_core.InputSignal<string | undefined>;
    /**
     * Determines whether the filter input should be automatically focused when the component is rendered.
     * @group Props
     */
    filterInputAutoFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether checkbox selections propagate to descendant nodes.
     * @group Props
     */
    propagateSelectionDown: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether checkbox selections propagate to ancestor nodes.
     * @group Props
     */
    propagateSelectionUp: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When enabled, a clear icon is displayed to clear the value.
     * @group Props
     */
    showClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Clears the filter value when hiding the dropdown.
     * @group Props
     */
    resetFilterOnHide: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether the data should be loaded on demand during scroll.
     * @group Props
     */
    virtualScroll: _angular_core.InputSignal<boolean | undefined>;
    /**
     * Height of an item in the list for VirtualScrolling.
     * @group Props
     */
    virtualScrollItemSize: _angular_core.InputSignal<number | undefined>;
    /**
     * Whether to use the scroller feature. The properties of scroller component can be used like an object in it.
     * @group Props
     */
    virtualScrollOptions: _angular_core.InputSignal<ScrollerOptions | undefined>;
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * An array of treenodes.
     * @defaultValue undefined
     * @group Props
     */
    options: _angular_core.InputSignal<TreeNode<any>[] | undefined>;
    /**
     * Displays a loader to indicate data load is in progress.
     * @group Props
     */
    loading: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Loading mode display.
     * @group Props
     */
    loadingMode: _angular_core.InputSignal<"mask" | "icon">;
    /**
     * Specifies the size of the component.
     * @defaultValue undefined
     * @group Props
     */
    size: _angular_core.InputSignal<"small" | "large" | undefined>;
    /**
     * Specifies the input variant of the component.
     * @defaultValue undefined
     * @group Props
     */
    variant: _angular_core.InputSignal<"filled" | "outlined" | undefined>;
    /**
     * Spans 100% width of the container when enabled.
     * @defaultValue undefined
     * @group Props
     */
    fluid: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'self'
     * @group Props
     */
    appendTo: _angular_core.InputSignal<any>;
    /**
     * The motion options.
     * @group Props
     */
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    /**
     * Callback to invoke when a node is expanded.
     * @param {TreeSelectNodeExpandEvent} event - Custom node expand event.
     * @group Emits
     */
    onNodeExpand: _angular_core.OutputEmitterRef<TreeSelectNodeExpandEvent>;
    /**
     * Callback to invoke when a node is collapsed.
     * @param {TreeSelectNodeCollapseEvent} event - Custom node collapse event.
     * @group Emits
     */
    onNodeCollapse: _angular_core.OutputEmitterRef<TreeSelectNodeCollapseEvent>;
    /**
     * Callback to invoke when the overlay is shown.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onShow: _angular_core.OutputEmitterRef<any>;
    /**
     * Callback to invoke when the overlay is hidden.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onHide: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke when input field is cleared.
     * @group Emits
     */
    onClear: _angular_core.OutputEmitterRef<any>;
    /**
     * Callback to invoke when data is filtered.
     * @group Emits
     */
    onFilter: _angular_core.OutputEmitterRef<TreeFilterEvent>;
    /**
     * Callback to invoke when treeselect gets focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onFocus: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke when treeselect loses focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onBlur: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke when a node is unselected.
     * @param {TreeNodeUnSelectEvent} event - node unselect event.
     * @group Emits
     */
    onNodeUnselect: _angular_core.OutputEmitterRef<TreeNodeSelectEvent>;
    /**
     * Callback to invoke when a node is selected.
     * @param {TreeNodeSelectEvent} event - node select event.
     * @group Emits
     */
    onNodeSelect: _angular_core.OutputEmitterRef<TreeNodeSelectEvent>;
    $appendTo: _angular_core.Signal<any>;
    readonly focusInput: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly filterViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly treeViewChild: _angular_core.Signal<Nullable<Tree>>;
    readonly panelEl: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly overlayViewChild: _angular_core.Signal<Nullable<Overlay>>;
    readonly firstHiddenFocusableElementOnOverlay: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly lastHiddenFocusableElementOnOverlay: _angular_core.Signal<Nullable<ElementRef<any>>>;
    $variant: _angular_core.Signal<"filled" | "outlined" | null>;
    pcFluid: Fluid | null;
    get hasFluid(): boolean;
    filteredNodes: TreeNode[] | undefined | null;
    filterValue: Nullable<string>;
    serializedValue: Nullable<any[]>;
    /**
     * Custom value template.
     * @param {TreeSelectValueTemplateContext} context - value context.
     * @see {@link TreeSelectValueTemplateContext}
     * @group Templates
     */
    valueTemplate: Nullable<TemplateRef<TreeSelectValueTemplateContext>>;
    /**
     * Custom header template.
     * @param {TreeSelectHeaderTemplateContext} context - header context.
     * @see {@link TreeSelectHeaderTemplateContext}
     * @group Templates
     */
    readonly headerTemplate: _angular_core.Signal<Nullable<TemplateRef<TreeSelectHeaderTemplateContext>>>;
    /**
     * Custom empty message template.
     * @group Templates
     */
    emptyTemplate: Nullable<TemplateRef<void>>;
    /**
     * Custom footer template.
     * @param {TreeSelectHeaderTemplateContext} context - footer context.
     * @see {@link TreeSelectHeaderTemplateContext}
     * @group Templates
     */
    readonly footerTemplate: _angular_core.Signal<Nullable<TemplateRef<TreeSelectHeaderTemplateContext>>>;
    /**
     * Custom clear icon template.
     * @group Templates
     */
    clearIconTemplate: Nullable<TemplateRef<void>>;
    /**
     * Custom trigger icon template.
     * @group Templates
     */
    triggerIconTemplate: Nullable<TemplateRef<void>>;
    /**
     * Custom dropdown icon template.
     * @group Templates
     */
    dropdownIconTemplate: Nullable<TemplateRef<void>>;
    /**
     * Custom filter icon template.
     * @group Templates
     */
    filterIconTemplate: Nullable<TemplateRef<void>>;
    /**
     * Custom close icon template.
     * @group Templates
     */
    readonly closeIconTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom item toggler icon template.
     * @param {TreeSelectItemTogglerIconTemplateContext} context - toggler icon context.
     * @see {@link TreeSelectItemTogglerIconTemplateContext}
     * @group Templates
     */
    itemTogglerIconTemplate: Nullable<TemplateRef<TreeSelectItemTogglerIconTemplateContext>>;
    /**
     * Custom item checkbox icon template.
     * @param {TreeSelectItemCheckboxIconTemplateContext} context - checkbox icon context.
     * @see {@link TreeSelectItemCheckboxIconTemplateContext}
     * @group Templates
     */
    itemCheckboxIconTemplate: Nullable<TemplateRef<TreeSelectItemCheckboxIconTemplateContext>>;
    /**
     * Custom item loading icon template.
     * @group Templates
     */
    itemLoadingIconTemplate: Nullable<TemplateRef<void>>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _valueTemplate: TemplateRef<TreeSelectValueTemplateContext> | undefined;
    _headerTemplate: TemplateRef<TreeSelectHeaderTemplateContext> | undefined;
    _emptyTemplate: TemplateRef<void> | undefined;
    _footerTemplate: TemplateRef<TreeSelectHeaderTemplateContext> | undefined;
    _clearIconTemplate: TemplateRef<void> | undefined;
    _triggerIconTemplate: TemplateRef<void> | undefined;
    _filterIconTemplate: TemplateRef<void> | undefined;
    _closeIconTemplate: TemplateRef<void> | undefined;
    _itemTogglerIconTemplate: TemplateRef<TreeSelectItemTogglerIconTemplateContext> | undefined;
    _itemCheckboxIconTemplate: TemplateRef<TreeSelectItemCheckboxIconTemplateContext> | undefined;
    _itemLoadingIconTemplate: TemplateRef<void> | undefined;
    _dropdownIconTemplate: TemplateRef<void> | undefined;
    focused: Nullable<boolean>;
    overlayVisible: Nullable<boolean>;
    value: any | undefined;
    expandedNodes: any[];
    templateMap: any;
    listId: string;
    constructor();
    onHostClick(event: MouseEvent): void;
    onInit(): void;
    onAfterContentInit(): void;
    onOverlayBeforeEnter(): void;
    onOverlayBeforeHide(): void;
    onSelectionChange(event: any): void;
    onClick(event: any): void;
    onKeyDown(event: KeyboardEvent): void;
    onFilterInput(event: Event): void;
    onArrowDown(event: KeyboardEvent): void;
    onFirstHiddenFocus(event: any): void;
    onLastHiddenFocus(event: any): void;
    show(): void;
    hide(event?: any): void;
    clear(event: Event): void;
    checkValue(): boolean;
    onTabKey(event: any, pressedInInputText?: boolean): void;
    hasFocusableElements(): boolean;
    resetFilter(): void;
    updateTreeState(): void;
    updateTreeBranchState(node: TreeNode | null, path: any, selectedNodes: TreeNode[]): void;
    expandPath(expandedNodes: TreeNode[]): void;
    nodeExpand(event: {
        originalEvent: Event;
        node: TreeNode;
    }): void;
    nodeCollapse(event: {
        originalEvent: Event;
        node: TreeNode;
    }): void;
    resetExpandedNodes(): void;
    resetPartialSelected(nodes?: TreeNode<any>[] | undefined): void;
    findSelectedNodes(node: TreeNode, keys: any[], selectedNodes: TreeNode[]): void;
    isSelected(node: TreeNode): boolean;
    findIndexInSelection(node: TreeNode): number;
    onSelect(event: TreeNodeSelectEvent): void;
    onUnselect(event: TreeNodeUnSelectEvent): void;
    onInputFocus(event: Event): void;
    onInputBlur(event: Event): void;
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value: any): void;
    get emptyValue(): boolean;
    get emptyOptions(): boolean;
    get label(): any;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TreeSelect, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TreeSelect, "p-treeSelect, p-treeselect, p-tree-select", never, { "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; "isSignal": true; }; "metaKeySelection": { "alias": "metaKeySelection"; "required": false; "isSignal": true; }; "display": { "alias": "display"; "required": false; "isSignal": true; }; "selectionMode": { "alias": "selectionMode"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "panelClass": { "alias": "panelClass"; "required": false; "isSignal": true; }; "panelStyle": { "alias": "panelStyle"; "required": false; "isSignal": true; }; "panelStyleClass": { "alias": "panelStyleClass"; "required": false; "isSignal": true; }; "containerStyle": { "alias": "containerStyle"; "required": false; "isSignal": true; }; "containerStyleClass": { "alias": "containerStyleClass"; "required": false; "isSignal": true; }; "labelStyle": { "alias": "labelStyle"; "required": false; "isSignal": true; }; "labelStyleClass": { "alias": "labelStyleClass"; "required": false; "isSignal": true; }; "overlayOptions": { "alias": "overlayOptions"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "filterBy": { "alias": "filterBy"; "required": false; "isSignal": true; }; "filterMode": { "alias": "filterMode"; "required": false; "isSignal": true; }; "filterPlaceholder": { "alias": "filterPlaceholder"; "required": false; "isSignal": true; }; "filterLocale": { "alias": "filterLocale"; "required": false; "isSignal": true; }; "filterInputAutoFocus": { "alias": "filterInputAutoFocus"; "required": false; "isSignal": true; }; "propagateSelectionDown": { "alias": "propagateSelectionDown"; "required": false; "isSignal": true; }; "propagateSelectionUp": { "alias": "propagateSelectionUp"; "required": false; "isSignal": true; }; "showClear": { "alias": "showClear"; "required": false; "isSignal": true; }; "resetFilterOnHide": { "alias": "resetFilterOnHide"; "required": false; "isSignal": true; }; "virtualScroll": { "alias": "virtualScroll"; "required": false; "isSignal": true; }; "virtualScrollItemSize": { "alias": "virtualScrollItemSize"; "required": false; "isSignal": true; }; "virtualScrollOptions": { "alias": "virtualScrollOptions"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "loadingMode": { "alias": "loadingMode"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; }, { "onNodeExpand": "onNodeExpand"; "onNodeCollapse": "onNodeCollapse"; "onShow": "onShow"; "onHide": "onHide"; "onClear": "onClear"; "onFilter": "onFilter"; "onFocus": "onFocus"; "onBlur": "onBlur"; "onNodeUnselect": "onNodeUnselect"; "onNodeSelect": "onNodeSelect"; }, ["headerTemplate", "footerTemplate", "closeIconTemplate", "templates", "valueTemplate", "emptyTemplate", "clearIconTemplate", "triggerIconTemplate", "dropdownIconTemplate", "filterIconTemplate", "itemTogglerIconTemplate", "itemCheckboxIconTemplate", "itemLoadingIconTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class TreeSelectModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TreeSelectModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<TreeSelectModule, never, [typeof TreeSelect, typeof i2.SharedModule], [typeof TreeSelect, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<TreeSelectModule>;
}

export { TREESELECT_VALUE_ACCESSOR, TreeSelect, TreeSelectClasses, TreeSelectModule, TreeSelectStyle };
