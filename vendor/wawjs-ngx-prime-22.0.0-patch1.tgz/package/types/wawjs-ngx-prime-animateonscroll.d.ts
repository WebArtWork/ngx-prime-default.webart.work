import * as _angular_core from '@angular/core';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';

interface AnimateOnScrollOptions {
    root?: HTMLElement | null;
    rootMargin?: string;
    threshold?: number;
}
/**
 * AnimateOnScroll is used to apply animations to elements when entering or leaving the viewport during scrolling.
 * @group Components
 */
declare class AnimateOnScroll extends BaseComponent {
    /**
     * Selector to define the CSS class for enter animation.
     * @group Props
     */
    enterClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Selector to define the CSS class for leave animation.
     * @group Props
     */
    leaveClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Specifies the root option of the IntersectionObserver API.
     * @group Props
     */
    root: _angular_core.InputSignal<HTMLElement | null | undefined>;
    /**
     * Specifies the rootMargin option of the IntersectionObserver API.
     * @group Props
     */
    rootMargin: _angular_core.InputSignal<string | undefined>;
    /**
     * Specifies the threshold option of the IntersectionObserver API
     * @group Props
     */
    threshold: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Whether the scroll event listener should be removed after initial run.
     * @group Props
     */
    once: _angular_core.InputSignalWithTransform<boolean, unknown>;
    observer: IntersectionObserver | undefined;
    resetObserver: any;
    isObserverActive: boolean;
    animationState: any;
    animationEndListener: VoidFunction | null | undefined;
    onInit(): void;
    onAfterViewInit(): void;
    get options(): AnimateOnScrollOptions;
    bindIntersectionObserver(): void;
    enter(): void;
    leave(): void;
    bindAnimationEvents(): void;
    unbindAnimationEvents(): void;
    unbindIntersectionObserver(): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AnimateOnScroll, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AnimateOnScroll, "[pAnimateOnScroll]", never, { "enterClass": { "alias": "enterClass"; "required": false; "isSignal": true; }; "leaveClass": { "alias": "leaveClass"; "required": false; "isSignal": true; }; "root": { "alias": "root"; "required": false; "isSignal": true; }; "rootMargin": { "alias": "rootMargin"; "required": false; "isSignal": true; }; "threshold": { "alias": "threshold"; "required": false; "isSignal": true; }; "once": { "alias": "once"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class AnimateOnScrollModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AnimateOnScrollModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<AnimateOnScrollModule, never, [typeof AnimateOnScroll], [typeof AnimateOnScroll]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<AnimateOnScrollModule>;
}

export { AnimateOnScroll, AnimateOnScrollModule };
