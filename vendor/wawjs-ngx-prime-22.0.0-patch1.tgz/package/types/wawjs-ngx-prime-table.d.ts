import { TablePassThrough, TableSelectAllChangeEvent, TableRowSelectEvent, TableRowUnSelectEvent, TablePageEvent, TableFilterEvent, TableLazyLoadEvent, TableRowExpandEvent, TableRowCollapseEvent, TableContextMenuSelectEvent, TableColResizeEvent, TableColumnReorderEvent, TableRowReorderEvent, TableEditInitEvent, TableEditCancelEvent, TableHeaderCheckboxToggleEvent, ExportCSVOptions, TableFilterButtonPropsOptions, ColumnFilterPassThrough } from '@wawjs/ngx-prime/types/table';
export * from '@wawjs/ngx-prime/types/table';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as _angular_core from '@angular/core';
import { AfterViewChecked, ElementRef, TemplateRef, NgZone, SimpleChanges, ChangeDetectorRef } from '@angular/core';
import * as rxjs from 'rxjs';
import { Subscription } from 'rxjs';
import { MotionOptions, MotionEvent } from '@wawjs/css-prime-motion';
import * as i27 from '@wawjs/ngx-prime/api';
import { BlockableUI, FilterMetadata, ScrollerOptions, SortMeta, TableState, PrimeTemplate, OverlayService, FilterService, LazyLoadMeta, SelectItem } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import * as i12 from '@wawjs/ngx-prime/checkbox';
import { CheckboxChangeEvent } from '@wawjs/ngx-prime/checkbox';
import { ConnectedOverlayScrollHandler } from '@wawjs/ngx-prime/dom';
import * as i25 from '@wawjs/ngx-prime/radiobutton';
import { RadioButton, RadioButtonClickEvent } from '@wawjs/ngx-prime/radiobutton';
import * as i13 from '@wawjs/ngx-prime/scroller';
import { Scroller } from '@wawjs/ngx-prime/scroller';
import { Nullable, VoidListener } from '@wawjs/ngx-prime/ts-helpers';
import * as i2 from '@angular/common';
import * as i3 from '@wawjs/ngx-prime/paginator';
import * as i4 from '@wawjs/ngx-prime/inputtext';
import * as i5 from '@wawjs/ngx-prime/select';
import * as i6 from '@angular/forms';
import * as i7 from '@wawjs/ngx-prime/button';
import * as i8 from '@wawjs/ngx-prime/selectbutton';
import * as i9 from '@wawjs/ngx-prime/datepicker';
import * as i10 from '@wawjs/ngx-prime/inputnumber';
import * as i11 from '@wawjs/ngx-prime/badge';
import * as i14 from '@wawjs/ngx-prime/icons/arrowdown';
import * as i15 from '@wawjs/ngx-prime/icons/arrowup';
import * as i16 from '@wawjs/ngx-prime/icons/spinner';
import * as i17 from '@wawjs/ngx-prime/icons/sortalt';
import * as i18 from '@wawjs/ngx-prime/icons/sortamountupalt';
import * as i19 from '@wawjs/ngx-prime/icons/sortamountdown';
import * as i20 from '@wawjs/ngx-prime/icons/filter';
import * as i21 from '@wawjs/ngx-prime/icons/filterfill';
import * as i22 from '@wawjs/ngx-prime/icons/filterslash';
import * as i23 from '@wawjs/ngx-prime/icons/plus';
import * as i24 from '@wawjs/ngx-prime/icons/trash';
import * as i26 from '@wawjs/ngx-prime/motion';

declare class TableStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-datatable-hoverable': any;
            'p-datatable-resizable': any;
            'p-datatable-resizable-fit': any;
            'p-datatable-scrollable': any;
            'p-datatable-flex-scrollable': any;
            'p-datatable-striped': any;
            'p-datatable-gridlines': any;
            'p-datatable-sm': boolean;
            'p-datatable-lg': boolean;
        })[];
        mask: string;
        loadingIcon: string;
        header: string;
        pcPaginator: ({ instance }: {
            instance: any;
        }) => string;
        tableContainer: string;
        table: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-datatable-scrollable-table': any;
            'p-datatable-resizable-table': any;
            'p-datatable-resizable-table-fit': any;
        })[];
        thead: string;
        columnResizer: string;
        columnHeaderContent: string;
        columnTitle: string;
        columnFooter: string;
        sortIcon: string;
        pcSortBadge: string;
        filter: ({ instance }: {
            instance: any;
        }) => {
            'p-datatable-filter': boolean;
            'p-datatable-inline-filter': boolean;
            'p-datatable-popover-filter': boolean;
        };
        filterElementContainer: string;
        pcColumnFilterButton: string;
        pcColumnFilterClearButton: string;
        filterOverlay: ({ instance }: {
            instance: any;
        }) => {
            'p-datatable-filter-overlay p-component': boolean;
            'p-datatable-filter-overlay-popover': boolean;
        };
        filterConstraintList: string;
        filterConstraint: ({ selected }: {
            selected: any;
        }) => {
            'p-datatable-filter-constraint': boolean;
            'p-datatable-filter-constraint-selected': any;
        };
        filterConstraintSeparator: string;
        filterOperator: string;
        pcFilterOperatorDropdown: string;
        filterRuleList: string;
        filterRule: string;
        pcFilterConstraintDropdown: string;
        pcFilterRemoveRuleButton: string;
        pcFilterAddRuleButton: string;
        filterButtonbar: string;
        pcFilterClearButton: string;
        pcFilterApplyButton: string;
        tbody: ({ instance }: {
            instance: any;
        }) => {
            'p-datatable-tbody': boolean;
            'p-datatable-frozen-tbody': any;
            'p-virtualscroller-content': any;
        };
        rowGroupHeader: string;
        rowToggleButton: string;
        rowToggleIcon: string;
        rowExpansion: string;
        rowGroupFooter: string;
        emptyMessage: string;
        bodyCell: ({ instance }: {
            instance: any;
        }) => {
            'p-datatable-frozen-column': any;
        };
        reorderableRowHandle: string;
        pcRowEditorInit: string;
        pcRowEditorSave: string;
        pcRowEditorCancel: string;
        tfoot: string;
        footerCell: ({ instance }: {
            instance: any;
        }) => {
            'p-datatable-frozen-column': any;
        };
        virtualScrollerSpacer: string;
        footer: string;
        columnResizeIndicator: string;
        rowReorderIndicatorUp: string;
        rowReorderIndicatorDown: string;
        sortableColumn: ({ instance }: {
            instance: any;
        }) => {
            'p-datatable-sortable-column': any;
            ' p-datatable-column-sorted': any;
        };
        sortableColumnIcon: string;
        sortableColumnBadge: string;
        selectableRow: ({ instance }: {
            instance: any;
        }) => {
            'p-datatable-selectable-row': any;
            'p-datatable-row-selected': any;
        };
        resizableColumn: string;
        reorderableColumn: string;
        rowEditorCancel: string;
        frozenColumn: ({ instance }: {
            instance: any;
        }) => {
            'p-datatable-frozen-column': any;
            'p-datatable-frozen-column-left': boolean;
        };
        contextMenuRowSelected: ({ instance }: {
            instance: any;
        }) => {
            'p-datatable-contextmenu-row-selected': any;
        };
    };
    inlineStyles: {
        tableContainer: ({ instance }: {
            instance: any;
        }) => {
            'max-height': any;
            overflow: string;
        };
        thead: {
            position: string;
        };
        tfoot: {
            position: string;
        };
        rowGroupHeader: ({ instance }: {
            instance: any;
        }) => {
            top: any;
        };
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TableStyle>;
}
/**
 *
 * DataTable displays data in tabular format.
 *
 * [Live Demo](https://www.ngx-prime.org/table/)
 *
 * @module tablestyle
 *
 */
declare enum TableClasses {
    /**
     * Class name of the root element
     */
    root = "p-datatable",
    /**
     * Class name of the mask element
     */
    mask = "p-datatable-mask",
    /**
     * Class name of the loading icon element
     */
    loadingIcon = "p-datatable-loading-icon",
    /**
     * Class name of the header element
     */
    header = "p-datatable-header",
    /**
     * Class name of the paginator element
     */
    pcPaginator = "p-datatable-paginator-[position]",
    /**
     * Class name of the table container element
     */
    tableContainer = "p-datatable-table-container",
    /**
     * Class name of the table element
     */
    table = "p-datatable-table",
    /**
     * Class name of the thead element
     */
    thead = "p-datatable-thead",
    /**
     * Class name of the column resizer element
     */
    columnResizer = "p-datatable-column-resizer",
    /**
     * Class name of the column header content element
     */
    columnHeaderContent = "p-datatable-column-header-content",
    /**
     * Class name of the column title element
     */
    columnTitle = "p-datatable-column-title",
    /**
     * Class name of the sort icon element
     */
    sortIcon = "p-datatable-sort-icon",
    /**
     * Class name of the sort badge element
     */
    pcSortBadge = "p-datatable-sort-badge",
    /**
     * Class name of the filter element
     */
    filter = "p-datatable-filter",
    /**
     * Class name of the filter element container element
     */
    filterElementContainer = "p-datatable-filter-element-container",
    /**
     * Class name of the column filter button element
     */
    pcColumnFilterButton = "p-datatable-column-filter-button",
    /**
     * Class name of the column filter clear button element
     */
    pcColumnFilterClearButton = "p-datatable-column-filter-clear-button",
    /**
     * Class name of the filter overlay element
     */
    filterOverlay = "p-datatable-filter-overlay",
    /**
     * Class name of the filter constraint list element
     */
    filterConstraintList = "p-datatable-filter-constraint-list",
    /**
     * Class name of the filter constraint element
     */
    filterConstraint = "p-datatable-filter-constraint",
    /**
     * Class name of the filter constraint separator element
     */
    filterConstraintSeparator = "p-datatable-filter-constraint-separator",
    /**
     * Class name of the filter operator element
     */
    filterOperator = "p-datatable-filter-operator",
    /**
     * Class name of the filter operator dropdown element
     */
    pcFilterOperatorDropdown = "p-datatable-filter-operator-dropdown",
    /**
     * Class name of the filter rule list element
     */
    filterRuleList = "p-datatable-filter-rule-list",
    /**
     * Class name of the filter rule element
     */
    filterRule = "p-datatable-filter-rule",
    /**
     * Class name of the filter constraint dropdown element
     */
    pcFilterConstraintDropdown = "p-datatable-filter-constraint-dropdown",
    /**
     * Class name of the filter remove rule button element
     */
    pcFilterRemoveRuleButton = "p-datatable-filter-remove-rule-button",
    /**
     * Class name of the filter add rule button element
     */
    pcFilterAddRuleButton = "p-datatable-filter-add-rule-button",
    /**
     * Class name of the filter buttonbar element
     */
    filterButtonbar = "p-datatable-filter-buttonbar",
    /**
     * Class name of the filter clear button element
     */
    pcFilterClearButton = "p-datatable-filter-clear-button",
    /**
     * Class name of the filter apply button element
     */
    pcFilterApplyButton = "p-datatable-filter-apply-button",
    /**
     * Class name of the tbody element
     */
    tbody = "p-datatable-tbody",
    /**
     * Class name of the row group header element
     */
    rowGroupHeader = "p-datatable-row-group-header",
    /**
     * Class name of the row toggle button element
     */
    rowToggleButton = "p-datatable-row-toggle-button",
    /**
     * Class name of the row toggle icon element
     */
    rowToggleIcon = "p-datatable-row-toggle-icon",
    /**
     * Class name of the row expansion element
     */
    rowExpansion = "p-datatable-row-expansion",
    /**
     * Class name of the row group footer element
     */
    rowGroupFooter = "p-datatable-row-group-footer",
    /**
     * Class name of the empty message element
     */
    emptyMessage = "p-datatable-empty-message",
    /**
     * Class name of the reorderable row handle element
     */
    reorderableRowHandle = "p-datatable-reorderable-row-handle",
    /**
     * Class name of the row editor init element
     */
    pcRowEditorInit = "p-datatable-row-editor-init",
    /**
     * Class name of the row editor save element
     */
    pcRowEditorSave = "p-datatable-row-editor-save",
    /**
     * Class name of the row editor cancel element
     */
    pcRowEditorCancel = "p-datatable-row-editor-cancel",
    /**
     * Class name of the tfoot element
     */
    tfoot = "p-datatable-tfoot",
    /**
     * Class name of the virtual scroller spacer element
     */
    virtualScrollerSpacer = "p-datatable-virtualscroller-spacer",
    /**
     * Class name of the footer element
     */
    footer = "p-datatable-footer",
    /**
     * Class name of the column resize indicator element
     */
    columnResizeIndicator = "p-datatable-column-resize-indicator",
    /**
     * Class name of the row reorder indicator up element
     */
    rowReorderIndicatorUp = "p-datatable-row-reorder-indicator-up",
    /**
     * Class name of the row reorder indicator down element
     */
    rowReorderIndicatorDown = "p-datatable-row-reorder-indicator-down",
    /**
     * Class name of the sortable column element
     */
    sortableColumn = "p-datatable-sortable-column",
    /**
     * Class name of the sortable column icon element
     */
    sortableColumnIcon = "p-sortable-column-icon",
    /**
     * Class name of the sortable column badge element
     */
    sortableColumnBadge = "p-sortable-column-badge",
    /**
     * Class name of the selectable row element
     */
    selectableRow = "p-datatable-selectable-row",
    /**
     * Class name of the resizable column element
     */
    resizableColumn = "p-datatable-resizable-column",
    /**
     * Class name of the frozen column element
     */
    frozenColumn = "p-datatable-frozen-column",
    /**
     * Class name of the contextmenu row selected element
     */
    contextMenuRowSelected = "p-datatable-contextmenu-row-selected"
}

declare class TableService {
    private sortSource;
    private selectionSource;
    private contextMenuSource;
    private valueSource;
    private columnsSource;
    sortSource$: rxjs.Observable<SortMeta | SortMeta[] | null>;
    selectionSource$: rxjs.Observable<unknown>;
    contextMenuSource$: rxjs.Observable<any>;
    valueSource$: rxjs.Observable<any>;
    columnsSource$: rxjs.Observable<unknown>;
    onSort(sortMeta: SortMeta | SortMeta[] | null): void;
    onSelectionChange(): void;
    onContextMenu(data: any): void;
    onValueChange(value: any): void;
    onColumnsChange(columns: any[]): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TableService>;
}
/**
 * Table displays data in tabular format.
 * @group Components
 */
declare class Table<RowData = any> extends BaseComponent<TablePassThrough> implements BlockableUI, AfterViewChecked {
    componentName: string;
    /**
     * An array of objects to represent dynamic columns that are frozen.
     * @group Props
     */
    readonly frozenColumns: _angular_core.InputSignal<any[] | undefined>;
    /**
     * An array of objects to display as frozen.
     * @group Props
     */
    readonly frozenValue: _angular_core.InputSignal<any[] | undefined>;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    readonly styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the table.
     * @group Props
     */
    readonly tableStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the table.
     * @group Props
     */
    readonly tableStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * When specified as true, enables the pagination.
     * @group Props
     */
    readonly paginator: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Number of page links to display in paginator.
     * @group Props
     */
    readonly pageLinks: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Array of integer/object values to display inside rows per page dropdown of paginator
     * @group Props
     */
    readonly rowsPerPageOptions: _angular_core.InputSignal<any[] | undefined>;
    /**
     * Whether to show it even there is only one page.
     * @group Props
     */
    readonly alwaysShowPaginator: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Position of the paginator, options are "top", "bottom" or "both".
     * @group Props
     */
    readonly paginatorPosition: _angular_core.InputSignal<"top" | "bottom" | "both">;
    /**
     * Custom style class for paginator
     * @group Props
     */
    readonly paginatorStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Target element to attach the paginator dropdown overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @group Props
     */
    readonly paginatorDropdownAppendTo: _angular_core.InputSignal<any>;
    /**
     * Paginator dropdown height of the viewport in pixels, a scrollbar is defined if height of list exceeds this value.
     * @group Props
     */
    readonly paginatorDropdownScrollHeight: _angular_core.InputSignal<string>;
    /**
     * Template of the current page report element. Available placeholders are {currentPage},{totalPages},{rows},{first},{last} and {totalRecords}
     * @group Props
     */
    readonly currentPageReportTemplate: _angular_core.InputSignal<string>;
    /**
     * Whether to display current page report.
     * @group Props
     */
    readonly showCurrentPageReport: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Whether to display a dropdown to navigate to any page.
     * @group Props
     */
    readonly showJumpToPageDropdown: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Whether to display a input to navigate to any page.
     * @group Props
     */
    readonly showJumpToPageInput: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When enabled, icons are displayed on paginator to go first and last page.
     * @group Props
     */
    readonly showFirstLastIcon: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to show page links.
     * @group Props
     */
    readonly showPageLinks: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Sort order to use when an unsorted column gets sorted by user interaction.
     * @group Props
     */
    readonly defaultSortOrder: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Defines whether sorting works on single column or on multiple columns.
     * @group Props
     */
    readonly sortMode: _angular_core.InputSignal<"single" | "multiple">;
    /**
     * When true, resets paginator to first page after sorting. Available only when sortMode is set to single.
     * @group Props
     */
    readonly resetPageOnSort: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Specifies the selection mode, valid values are "single" and "multiple".
     * @group Props
     */
    readonly selectionMode: _angular_core.InputSignal<"single" | "multiple" | null | undefined>;
    /**
     * When enabled with paginator and checkbox selection mode, the select all checkbox in the header will select all rows on the current page.
     * @group Props
     */
    readonly selectionPageOnly: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Selected row with a context menu.
     * @group Props
     */
    readonly contextMenuSelection: _angular_core.InputSignal<any>;
    /**
     * Callback to invoke on context menu selection change.
     * @param {*} object - row data.
     * @group Emits
     */
    readonly contextMenuSelectionChange: _angular_core.OutputEmitterRef<any>;
    /**
     *  Defines the behavior of context menu selection, in "separate" mode context menu updates contextMenuSelection property whereas in joint mode selection property is used instead so that when row selection is enabled, both row selection and context menu selection use the same property.
     * @group Props
     */
    readonly contextMenuSelectionMode: _angular_core.InputSignal<string>;
    /**
     * A property to uniquely identify a record in data.
     * @group Props
     */
    readonly dataKey: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines whether metaKey should be considered for the selection. On touch enabled devices, metaKeySelection is turned off automatically.
     * @group Props
     */
    readonly metaKeySelection: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Defines if the row is selectable.
     * @group Props
     */
    readonly rowSelectable: _angular_core.InputSignal<(row: {
        data: any;
        index: number;
    }) => boolean | undefined>;
    /**
     * Function to optimize the dom operations by delegating to ngForTrackBy, default algorithm checks for object identity.
     * @group Props
     */
    readonly rowTrackBy: _angular_core.InputSignal<(...args: any[]) => any>;
    /**
     * Defines if data is loaded and interacted with in lazy manner.
     * @group Props
     */
    readonly lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to call lazy loading on initialization.
     * @group Props
     */
    readonly lazyLoadOnInit: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Algorithm to define if a row is selected, valid values are "equals" that compares by reference and "deepEquals" that compares all fields.
     * @group Props
     */
    readonly compareSelectionBy: _angular_core.InputSignal<"equals" | "deepEquals">;
    /**
     * Character to use as the csv separator.
     * @group Props
     */
    readonly csvSeparator: _angular_core.InputSignal<string>;
    /**
     * Name of the exported file.
     * @group Props
     */
    readonly exportFilename: _angular_core.InputSignal<string>;
    /**
     * An array of FilterMetadata objects to provide external filters.
     * @group Props
     */
    readonly filters: _angular_core.InputSignal<{
        [s: string]: FilterMetadata | FilterMetadata[];
    }>;
    /**
     * An array of fields as string to use in global filtering.
     * @group Props
     */
    readonly globalFilterFields: _angular_core.InputSignal<string[] | undefined>;
    /**
     * Delay in milliseconds before filtering the data.
     * @group Props
     */
    readonly filterDelay: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Locale to use in filtering. The default locale is the host environment's current locale.
     * @group Props
     */
    readonly filterLocale: _angular_core.InputSignal<string | undefined>;
    /**
     * Map instance to keep the expanded rows where key of the map is the data key of the row.
     * @group Props
     */
    readonly expandedRowKeys: _angular_core.InputSignal<{
        [s: string]: boolean;
    }>;
    /**
     * Map instance to keep the rows being edited where key of the map is the data key of the row.
     * @group Props
     */
    readonly editingRowKeys: _angular_core.InputSignal<{
        [s: string]: boolean;
    }>;
    /**
     * Whether multiple rows can be expanded at any time. Valid values are "multiple" and "single".
     * @group Props
     */
    readonly rowExpandMode: _angular_core.InputSignal<"single" | "multiple">;
    /**
     * Enables scrollable tables.
     * @group Props
     */
    readonly scrollable: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Type of the row grouping, valid values are "subheader" and "rowspan".
     * @group Props
     */
    readonly rowGroupMode: _angular_core.InputSignal<"subheader" | "rowspan" | undefined>;
    /**
     * Height of the scroll viewport in fixed pixels or the "flex" keyword for a dynamic size.
     * @group Props
     */
    readonly scrollHeight: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether the data should be loaded on demand during scroll.
     * @group Props
     */
    readonly virtualScroll: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Height of a row to use in calculations of virtual scrolling.
     * @group Props
     */
    readonly virtualScrollItemSize: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Whether to use the scroller feature. The properties of scroller component can be used like an object in it.
     * @group Props
     */
    readonly virtualScrollOptions: _angular_core.InputSignal<ScrollerOptions | undefined>;
    /**
     * Threshold in milliseconds to delay lazy loading during scrolling.
     * @group Props
     */
    readonly virtualScrollDelay: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Width of the frozen columns container.
     * @group Props
     */
    readonly frozenWidth: _angular_core.InputSignal<string | undefined>;
    /**
     * Local ng-template varilable of a ContextMenu.
     * @group Props
     */
    readonly contextMenu: _angular_core.InputSignal<any>;
    /**
     * When enabled, columns can be resized using drag and drop.
     * @group Props
     */
    readonly resizableColumns: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Defines whether the overall table width should change on column resize, valid values are "fit" and "expand".
     * @group Props
     */
    readonly columnResizeMode: _angular_core.InputSignal<string>;
    /**
     * When enabled, columns can be reordered using drag and drop.
     * @group Props
     */
    readonly reorderableColumns: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Displays a loader to indicate data load is in progress.
     * @group Props
     */
    readonly loading: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * The icon to show while indicating data load is in progress.
     * @group Props
     */
    readonly loadingIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to show the loading mask when loading property is true.
     * @group Props
     */
    readonly showLoader: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Adds hover effect to rows without the need for selectionMode. Note that tr elements that can be hovered need to have "p-selectable-row" class for rowHover to work.
     * @group Props
     */
    readonly rowHover: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Whether to use the default sorting or a custom one using sortFunction.
     * @group Props
     */
    readonly customSort: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Whether to use the initial sort badge or not.
     * @group Props
     */
    readonly showInitialSortBadge: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Export function.
     * @group Props
     */
    readonly exportFunction: _angular_core.InputSignal<(...args: any[]) => any | undefined>;
    /**
     * Custom export header of the column to be exported as CSV.
     * @group Props
     */
    readonly exportHeader: _angular_core.InputSignal<string | undefined>;
    /**
     * Unique identifier of a stateful table to use in state storage.
     * @group Props
     */
    readonly stateKey: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines where a stateful table keeps its state, valid values are "session" for sessionStorage and "local" for localStorage.
     * @group Props
     */
    readonly stateStorage: _angular_core.InputSignal<"session" | "local">;
    /**
     * Defines the editing mode, valid values are "cell" and "row".
     * @group Props
     */
    readonly editMode: _angular_core.InputSignal<"row" | "cell">;
    /**
     * Field name to use in row grouping.
     * @group Props
     */
    readonly groupRowsBy: _angular_core.InputSignal<any>;
    /**
     * Defines the size of the table.
     * @group Props
     */
    readonly size: _angular_core.InputSignal<"small" | "large" | undefined>;
    /**
     * Whether to show grid lines between cells.
     * @group Props
     */
    readonly showGridlines: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Whether to display rows with alternating colors.
     * @group Props
     */
    readonly stripedRows: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Order to sort when default row grouping is enabled.
     * @group Props
     */
    readonly groupRowsByOrder: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Defines the responsive mode, valid options are "stack" and "scroll".
     * @deprecated since v20.0.0, always defaults to scroll, stack mode needs custom implementation
     * @group Props
     */
    readonly responsiveLayout: _angular_core.InputSignal<string>;
    /**
     * The breakpoint to define the maximum width boundary when using stack responsive layout.
     * @group Props
     */
    readonly breakpoint: _angular_core.InputSignal<string>;
    /**
     * Locale to be used in paginator formatting.
     * @group Props
     */
    readonly paginatorLocale: _angular_core.InputSignal<string | undefined>;
    /**
     * An array of objects to display.
     * @group Props
     */
    readonly value: _angular_core.InputSignal<RowData[] | undefined>;
    /**
     * An array of objects to represent dynamic columns.
     * @group Props
     */
    readonly columns: _angular_core.InputSignal<any[] | undefined>;
    /**
     * Index of the first row to be displayed.
     * @group Props
     */
    readonly first: _angular_core.InputSignal<number | null | undefined>;
    /**
     * Number of rows to display per page.
     * @group Props
     */
    readonly rows: _angular_core.InputSignal<number | undefined>;
    /**
     * Number of total records, defaults to length of value when not defined.
     * @group Props
     */
    readonly totalRecords: _angular_core.InputSignal<number>;
    /**
     * Name of the field to sort data by default.
     * @group Props
     */
    readonly sortField: _angular_core.InputSignal<string | null | undefined>;
    /**
     * Order to sort when default sorting is enabled.
     * @group Props
     */
    readonly sortOrder: _angular_core.InputSignal<number | undefined>;
    /**
     * An array of SortMeta objects to sort the data by default in multiple sort mode.
     * @group Props
     */
    readonly multiSortMeta: _angular_core.InputSignal<SortMeta[] | null | undefined>;
    /**
     * Selected row in single mode or an array of values in multiple mode.
     * @group Props
     */
    readonly selection: _angular_core.InputSignal<any>;
    /**
     * Whether all data is selected.
     * @group Props
     */
    readonly selectAll: _angular_core.InputSignal<boolean | null | undefined>;
    /**
     * Emits when the all of the items selected or unselected.
     * @param {TableSelectAllChangeEvent} event - custom  all selection change event.
     * @group Emits
     */
    readonly selectAllChange: _angular_core.OutputEmitterRef<TableSelectAllChangeEvent>;
    /**
     * Callback to invoke on selection changed.
     * @param {any | null} value - selected data.
     * @group Emits
     */
    readonly selectionChange: _angular_core.OutputEmitterRef<any>;
    /**
     * Callback to invoke when a row is selected.
     * @param {TableRowSelectEvent} event - custom select event.
     * @group Emits
     */
    readonly onRowSelect: _angular_core.OutputEmitterRef<TableRowSelectEvent<RowData>>;
    /**
     * Callback to invoke when a row is unselected.
     * @param {TableRowUnSelectEvent} event - custom unselect event.
     * @group Emits
     */
    readonly onRowUnselect: _angular_core.OutputEmitterRef<TableRowUnSelectEvent<RowData>>;
    /**
     * Callback to invoke when pagination occurs.
     * @param {TablePageEvent} event - custom pagination event.
     * @group Emits
     */
    readonly onPage: _angular_core.OutputEmitterRef<TablePageEvent>;
    /**
     * Callback to invoke when a column gets sorted.
     * @param {Object} object - sort meta.
     * @group Emits
     */
    readonly onSort: _angular_core.OutputEmitterRef<any>;
    /**
     * Callback to invoke when data is filtered.
     * @param {TableFilterEvent} event - custom filtering event.
     * @group Emits
     */
    readonly onFilter: _angular_core.OutputEmitterRef<TableFilterEvent>;
    /**
     * Callback to invoke when paging, sorting or filtering happens in lazy mode.
     * @param {TableLazyLoadEvent} event - custom lazy loading event.
     * @group Emits
     */
    readonly onLazyLoad: _angular_core.OutputEmitterRef<TableLazyLoadEvent>;
    /**
     * Callback to invoke when a row is expanded.
     * @param {TableRowExpandEvent} event - custom row expand event.
     * @group Emits
     */
    readonly onRowExpand: _angular_core.OutputEmitterRef<TableRowExpandEvent<RowData>>;
    /**
     * Callback to invoke when a row is collapsed.
     * @param {TableRowCollapseEvent} event - custom row collapse event.
     * @group Emits
     */
    readonly onRowCollapse: _angular_core.OutputEmitterRef<TableRowCollapseEvent>;
    /**
     * Callback to invoke when a row is selected with right click.
     * @param {TableContextMenuSelectEvent} event - custom context menu select event.
     * @group Emits
     */
    readonly onContextMenuSelect: _angular_core.OutputEmitterRef<TableContextMenuSelectEvent<RowData>>;
    /**
     * Callback to invoke when a column is resized.
     * @param {TableColResizeEvent} event - custom column resize event.
     * @group Emits
     */
    readonly onColResize: _angular_core.OutputEmitterRef<TableColResizeEvent>;
    /**
     * Callback to invoke when a column is reordered.
     * @param {TableColumnReorderEvent} event - custom column reorder event.
     * @group Emits
     */
    readonly onColReorder: _angular_core.OutputEmitterRef<TableColumnReorderEvent>;
    /**
     * Callback to invoke when a row is reordered.
     * @param {TableRowReorderEvent} event - custom row reorder event.
     * @group Emits
     */
    readonly onRowReorder: _angular_core.OutputEmitterRef<TableRowReorderEvent>;
    /**
     * Callback to invoke when a cell switches to edit mode.
     * @param {TableEditInitEvent} event - custom edit init event.
     * @group Emits
     */
    readonly onEditInit: _angular_core.OutputEmitterRef<TableEditInitEvent>;
    /**
     * Callback to invoke when cell edit is completed.
     * @param {TableEditCompleteEvent} event - custom edit complete event.
     * @group Emits
     */
    readonly onEditComplete: _angular_core.OutputEmitterRef<TableEditCancelEvent>;
    /**
     * Callback to invoke when cell edit is cancelled with escape key.
     * @param {TableEditCancelEvent} event - custom edit cancel event.
     * @group Emits
     */
    readonly onEditCancel: _angular_core.OutputEmitterRef<TableEditCancelEvent>;
    /**
     * Callback to invoke when state of header checkbox changes.
     * @param {TableHeaderCheckboxToggleEvent} event - custom header checkbox event.
     * @group Emits
     */
    readonly onHeaderCheckboxToggle: _angular_core.OutputEmitterRef<TableHeaderCheckboxToggleEvent>;
    /**
     * A function to implement custom sorting, refer to sorting section for details.
     * @param {any} any - sort meta.
     * @group Emits
     */
    readonly sortFunction: _angular_core.OutputEmitterRef<any>;
    /**
     * Callback to invoke on pagination.
     * @param {number} number - first element.
     * @group Emits
     */
    readonly firstChange: _angular_core.OutputEmitterRef<number>;
    /**
     * Callback to invoke on rows change.
     * @param {number} number - Row count.
     * @group Emits
     */
    readonly rowsChange: _angular_core.OutputEmitterRef<number>;
    /**
     * Callback to invoke table state is saved.
     * @param {TableState} object - table state.
     * @group Emits
     */
    readonly onStateSave: _angular_core.OutputEmitterRef<TableState>;
    /**
     * Callback to invoke table state is restored.
     * @param {TableState} object - table state.
     * @group Emits
     */
    readonly onStateRestore: _angular_core.OutputEmitterRef<TableState>;
    readonly resizeHelperViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly reorderIndicatorUpViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly reorderIndicatorDownViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly wrapperViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly tableViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly tableHeaderViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly tableFooterViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly scroller: _angular_core.Signal<Nullable<Scroller>>;
    readonly _templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _value: RowData[];
    _columns: any[] | undefined;
    _totalRecords: number;
    _first: number | null | undefined;
    _rows: number | undefined;
    filteredValue: any[] | undefined | null;
    readonly _headerTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    headerTemplate: Nullable<TemplateRef<any>>;
    readonly _headerGroupedTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    headerGroupedTemplate: Nullable<TemplateRef<any>>;
    readonly _bodyTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    bodyTemplate: Nullable<TemplateRef<any>>;
    readonly _loadingBodyTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    loadingBodyTemplate: Nullable<TemplateRef<any>>;
    _captionTemplate: TemplateRef<any>;
    captionTemplate: Nullable<TemplateRef<any>>;
    _footerTemplate: TemplateRef<any>;
    footerTemplate: Nullable<TemplateRef<any>>;
    _footerGroupedTemplate: TemplateRef<any>;
    footerGroupedTemplate: Nullable<TemplateRef<any>>;
    _summaryTemplate: TemplateRef<any>;
    summaryTemplate: Nullable<TemplateRef<any>>;
    readonly _colGroupTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    colGroupTemplate: Nullable<TemplateRef<any>>;
    _expandedRowTemplate: TemplateRef<any>;
    expandedRowTemplate: Nullable<TemplateRef<any>>;
    _groupHeaderTemplate: TemplateRef<any>;
    groupHeaderTemplate: Nullable<TemplateRef<any>>;
    _groupFooterTemplate: TemplateRef<any>;
    groupFooterTemplate: Nullable<TemplateRef<any>>;
    _frozenExpandedRowTemplate: TemplateRef<any>;
    frozenExpandedRowTemplate: Nullable<TemplateRef<any>>;
    readonly _frozenHeaderTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    frozenHeaderTemplate: Nullable<TemplateRef<any>>;
    _frozenBodyTemplate: TemplateRef<any>;
    frozenBodyTemplate: Nullable<TemplateRef<any>>;
    readonly _frozenFooterTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    frozenFooterTemplate: Nullable<TemplateRef<any>>;
    readonly _frozenColGroupTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    frozenColGroupTemplate: Nullable<TemplateRef<any>>;
    readonly _emptyMessageTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    emptyMessageTemplate: Nullable<TemplateRef<any>>;
    readonly _paginatorLeftTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    paginatorLeftTemplate: Nullable<TemplateRef<any>>;
    readonly _paginatorRightTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    paginatorRightTemplate: Nullable<TemplateRef<any>>;
    readonly _paginatorDropdownItemTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    paginatorDropdownItemTemplate: Nullable<TemplateRef<any>>;
    _loadingIconTemplate: TemplateRef<any>;
    loadingIconTemplate: Nullable<TemplateRef<any>>;
    readonly _reorderIndicatorUpIconTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    reorderIndicatorUpIconTemplate: Nullable<TemplateRef<any>>;
    readonly _reorderIndicatorDownIconTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    reorderIndicatorDownIconTemplate: Nullable<TemplateRef<any>>;
    _sortIconTemplate: TemplateRef<any>;
    sortIconTemplate: Nullable<TemplateRef<any>>;
    readonly _checkboxIconTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    checkboxIconTemplate: Nullable<TemplateRef<any>>;
    readonly _headerCheckboxIconTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    headerCheckboxIconTemplate: Nullable<TemplateRef<any>>;
    _paginatorDropdownIconTemplate: TemplateRef<any>;
    paginatorDropdownIconTemplate: Nullable<TemplateRef<any>>;
    _paginatorFirstPageLinkIconTemplate: TemplateRef<any>;
    paginatorFirstPageLinkIconTemplate: Nullable<TemplateRef<any>>;
    _paginatorLastPageLinkIconTemplate: TemplateRef<any>;
    paginatorLastPageLinkIconTemplate: Nullable<TemplateRef<any>>;
    _paginatorPreviousPageLinkIconTemplate: TemplateRef<any>;
    paginatorPreviousPageLinkIconTemplate: Nullable<TemplateRef<any>>;
    _paginatorNextPageLinkIconTemplate: TemplateRef<any>;
    paginatorNextPageLinkIconTemplate: Nullable<TemplateRef<any>>;
    selectionKeys: any;
    lastResizerHelperX: number | undefined;
    reorderIconWidth: number | undefined;
    reorderIconHeight: number | undefined;
    draggedColumn: any;
    draggedRowIndex: number | undefined | null;
    droppedRowIndex: number | undefined | null;
    rowDragging: boolean | undefined | null;
    dropPosition: number | undefined | null;
    editingCell: Element | undefined | null;
    editingCellData: any;
    editingCellField: any;
    editingCellRowIndex: number | undefined | null;
    selfClick: boolean | undefined | null;
    documentEditListener: any;
    _multiSortMeta: SortMeta[] | undefined | null;
    _sortField: string | undefined | null;
    _sortOrder: number;
    preventSelectionSetterPropagation: boolean | undefined;
    _selection: any;
    _selectAll: boolean | null;
    _contextMenuSelection: any;
    _filters: {
        [s: string]: FilterMetadata | FilterMetadata[];
    };
    _expandedRowKeys: {
        [s: string]: boolean;
    };
    anchorRowIndex: number | undefined | null;
    rangeRowIndex: number | undefined;
    filterTimeout: any;
    initialized: boolean | undefined | null;
    rowTouched: boolean | undefined;
    restoringSort: boolean | undefined;
    restoringFilter: boolean | undefined;
    stateRestored: boolean | undefined;
    columnOrderStateRestored: boolean | undefined;
    columnWidthsState: string | undefined;
    tableWidthState: string | undefined;
    overlaySubscription: Subscription | undefined;
    resizeColumnElement: HTMLElement;
    columnResizing: boolean;
    rowGroupHeaderStyleObject: any;
    id: string;
    styleElement: any;
    responsiveStyleElement: any;
    overlayService: OverlayService;
    filterService: FilterService;
    tableService: TableService;
    zone: NgZone;
    _componentStyle: TableStyle;
    bindDirectiveInstance: Bind;
    private _totalRecordsSynced;
    private _prevValue;
    private _prevColumns;
    private _prevSortField;
    private _prevSortOrder;
    private _prevMultiSortMeta;
    private _prevSelection;
    private _prevSelectAll;
    constructor();
    onAfterViewChecked(): void;
    onInit(): void;
    onAfterContentInit(): void;
    onAfterViewInit(): void;
    get processedData(): any[];
    private _initialColWidths;
    dataToRender(data: any): any;
    updateSelectionKeys(): void;
    onPageChange(event: TablePageEvent): void;
    sort(event: any): void;
    sortSingle(): void;
    sortMultiple(): void;
    multisortField(data1: any, data2: any, multiSortMeta: SortMeta[], index: number): any;
    compareValuesOnSort(value1: any, value2: any, order: any): number;
    getSortMeta(field: string): SortMeta | null;
    isSorted(field: string): boolean | "" | null | undefined;
    handleRowClick(event: any): void;
    handleRowTouchEnd(): void;
    handleRowRightClick(event: any): void;
    selectRange(event: MouseEvent | KeyboardEvent, rowIndex: number, isMetaKeySelection?: boolean | undefined): void;
    clearSelectionRange(event: MouseEvent | KeyboardEvent): void;
    isSelected(rowData: any): boolean;
    findIndexInSelection(rowData: any): number;
    isRowSelectable(data: any, index: number): boolean;
    toggleRowWithRadio(event: any, rowData: any): void;
    toggleRowWithCheckbox(event: {
        originalEvent: Event;
        rowIndex: number;
    }, rowData: any): void;
    toggleRowsWithCheckbox({ originalEvent }: CheckboxChangeEvent, check: boolean): void;
    equals(data1: any, data2: any): boolean;
    filter(value: any, field: string, matchMode: string): void;
    filterGlobal(value: any, matchMode: string): void;
    isFilterBlank(filter: any): boolean;
    _filter(): void;
    executeLocalFilter(field: string, rowData: any, filterMeta: FilterMetadata): boolean;
    hasFilter(): boolean;
    createLazyLoadMetadata(): any;
    clear(): void;
    clearFilterValues(): void;
    reset(): void;
    getExportHeader(column: any): any;
    /**
     * Data export method.
     * @param {ExportCSVOptions} object - Export options.
     * @group Method
     */
    exportCSV(options?: ExportCSVOptions): void;
    onLazyItemLoad(event: LazyLoadMeta): void;
    /**
     * Resets scroll to top.
     * @group Method
     */
    resetScrollTop(): void;
    /**
     * Scrolls to given index when using virtual scroll.
     * @param {number} index - index of the element.
     * @group Method
     */
    scrollToVirtualIndex(index: number): void;
    /**
     * Scrolls to given index.
     * @param {ScrollToOptions} options - scroll options.
     * @group Method
     */
    scrollTo(options: any): void;
    updateEditingCell(cell: any, data: any, field: string, index: number): void;
    isEditingCellValid(): boolean | null | undefined;
    bindDocumentEditListener(): void;
    unbindDocumentEditListener(): void;
    initRowEdit(rowData: any): void;
    saveRowEdit(rowData: any, rowElement: HTMLTableRowElement): void;
    cancelRowEdit(rowData: any): void;
    toggleRow(rowData: any, event?: Event): void;
    isRowExpanded(rowData: any): boolean;
    isRowEditing(rowData: any): boolean;
    isSingleSelectionMode(): boolean;
    isMultipleSelectionMode(): boolean;
    onColumnResizeBegin(event: any): void;
    onColumnResize(event: any): void;
    onColumnResizeEnd(): void;
    private _totalTableWidth;
    onColumnDragStart(event: any, columnElement: any): void;
    onColumnDragEnter(event: any, dropHeader: any): void;
    onColumnDragLeave(event: Event): void;
    onColumnDrop(event: Event, dropColumn: any): void;
    resizeTableCells(newColumnWidth: number, nextColumnWidth: number | null): void;
    updateStyleElement(width: number[], colIndex: number, newColumnWidth: number, nextColumnWidth: number | null): void;
    onRowDragStart(event: any, index: number): void;
    onRowDragOver(event: MouseEvent, index: number, rowElement: any): void;
    onRowDragLeave(event: Event, rowElement: any): void;
    onRowDragEnd(): void;
    onRowDrop(event: Event, rowElement: any): void;
    isEmpty(): boolean;
    getBlockableElement(): HTMLElement;
    getStorage(): Storage;
    isStateful(): boolean;
    saveState(): void;
    clearState(): void;
    restoreState(): void;
    saveColumnWidths(state: any): void;
    setResizeTableWidth(width: string): void;
    restoreColumnWidths(): void;
    saveColumnOrder(state: any): void;
    restoreColumnOrder(): void;
    findColumnByKey(key: any): any;
    createStyleElement(): void;
    getGroupRowsMeta(): {
        field: any;
        order: number;
    };
    createResponsiveStyle(): void;
    destroyResponsiveStyle(): void;
    destroyStyleElement(): void;
    ngAfterViewChecked(): void;
    onDestroy(): void;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Table<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Table<any>, "p-table", never, { "frozenColumns": { "alias": "frozenColumns"; "required": false; "isSignal": true; }; "frozenValue": { "alias": "frozenValue"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "tableStyle": { "alias": "tableStyle"; "required": false; "isSignal": true; }; "tableStyleClass": { "alias": "tableStyleClass"; "required": false; "isSignal": true; }; "paginator": { "alias": "paginator"; "required": false; "isSignal": true; }; "pageLinks": { "alias": "pageLinks"; "required": false; "isSignal": true; }; "rowsPerPageOptions": { "alias": "rowsPerPageOptions"; "required": false; "isSignal": true; }; "alwaysShowPaginator": { "alias": "alwaysShowPaginator"; "required": false; "isSignal": true; }; "paginatorPosition": { "alias": "paginatorPosition"; "required": false; "isSignal": true; }; "paginatorStyleClass": { "alias": "paginatorStyleClass"; "required": false; "isSignal": true; }; "paginatorDropdownAppendTo": { "alias": "paginatorDropdownAppendTo"; "required": false; "isSignal": true; }; "paginatorDropdownScrollHeight": { "alias": "paginatorDropdownScrollHeight"; "required": false; "isSignal": true; }; "currentPageReportTemplate": { "alias": "currentPageReportTemplate"; "required": false; "isSignal": true; }; "showCurrentPageReport": { "alias": "showCurrentPageReport"; "required": false; "isSignal": true; }; "showJumpToPageDropdown": { "alias": "showJumpToPageDropdown"; "required": false; "isSignal": true; }; "showJumpToPageInput": { "alias": "showJumpToPageInput"; "required": false; "isSignal": true; }; "showFirstLastIcon": { "alias": "showFirstLastIcon"; "required": false; "isSignal": true; }; "showPageLinks": { "alias": "showPageLinks"; "required": false; "isSignal": true; }; "defaultSortOrder": { "alias": "defaultSortOrder"; "required": false; "isSignal": true; }; "sortMode": { "alias": "sortMode"; "required": false; "isSignal": true; }; "resetPageOnSort": { "alias": "resetPageOnSort"; "required": false; "isSignal": true; }; "selectionMode": { "alias": "selectionMode"; "required": false; "isSignal": true; }; "selectionPageOnly": { "alias": "selectionPageOnly"; "required": false; "isSignal": true; }; "contextMenuSelection": { "alias": "contextMenuSelection"; "required": false; "isSignal": true; }; "contextMenuSelectionMode": { "alias": "contextMenuSelectionMode"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "metaKeySelection": { "alias": "metaKeySelection"; "required": false; "isSignal": true; }; "rowSelectable": { "alias": "rowSelectable"; "required": false; "isSignal": true; }; "rowTrackBy": { "alias": "rowTrackBy"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "lazyLoadOnInit": { "alias": "lazyLoadOnInit"; "required": false; "isSignal": true; }; "compareSelectionBy": { "alias": "compareSelectionBy"; "required": false; "isSignal": true; }; "csvSeparator": { "alias": "csvSeparator"; "required": false; "isSignal": true; }; "exportFilename": { "alias": "exportFilename"; "required": false; "isSignal": true; }; "filters": { "alias": "filters"; "required": false; "isSignal": true; }; "globalFilterFields": { "alias": "globalFilterFields"; "required": false; "isSignal": true; }; "filterDelay": { "alias": "filterDelay"; "required": false; "isSignal": true; }; "filterLocale": { "alias": "filterLocale"; "required": false; "isSignal": true; }; "expandedRowKeys": { "alias": "expandedRowKeys"; "required": false; "isSignal": true; }; "editingRowKeys": { "alias": "editingRowKeys"; "required": false; "isSignal": true; }; "rowExpandMode": { "alias": "rowExpandMode"; "required": false; "isSignal": true; }; "scrollable": { "alias": "scrollable"; "required": false; "isSignal": true; }; "rowGroupMode": { "alias": "rowGroupMode"; "required": false; "isSignal": true; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; "isSignal": true; }; "virtualScroll": { "alias": "virtualScroll"; "required": false; "isSignal": true; }; "virtualScrollItemSize": { "alias": "virtualScrollItemSize"; "required": false; "isSignal": true; }; "virtualScrollOptions": { "alias": "virtualScrollOptions"; "required": false; "isSignal": true; }; "virtualScrollDelay": { "alias": "virtualScrollDelay"; "required": false; "isSignal": true; }; "frozenWidth": { "alias": "frozenWidth"; "required": false; "isSignal": true; }; "contextMenu": { "alias": "contextMenu"; "required": false; "isSignal": true; }; "resizableColumns": { "alias": "resizableColumns"; "required": false; "isSignal": true; }; "columnResizeMode": { "alias": "columnResizeMode"; "required": false; "isSignal": true; }; "reorderableColumns": { "alias": "reorderableColumns"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "loadingIcon": { "alias": "loadingIcon"; "required": false; "isSignal": true; }; "showLoader": { "alias": "showLoader"; "required": false; "isSignal": true; }; "rowHover": { "alias": "rowHover"; "required": false; "isSignal": true; }; "customSort": { "alias": "customSort"; "required": false; "isSignal": true; }; "showInitialSortBadge": { "alias": "showInitialSortBadge"; "required": false; "isSignal": true; }; "exportFunction": { "alias": "exportFunction"; "required": false; "isSignal": true; }; "exportHeader": { "alias": "exportHeader"; "required": false; "isSignal": true; }; "stateKey": { "alias": "stateKey"; "required": false; "isSignal": true; }; "stateStorage": { "alias": "stateStorage"; "required": false; "isSignal": true; }; "editMode": { "alias": "editMode"; "required": false; "isSignal": true; }; "groupRowsBy": { "alias": "groupRowsBy"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "showGridlines": { "alias": "showGridlines"; "required": false; "isSignal": true; }; "stripedRows": { "alias": "stripedRows"; "required": false; "isSignal": true; }; "groupRowsByOrder": { "alias": "groupRowsByOrder"; "required": false; "isSignal": true; }; "responsiveLayout": { "alias": "responsiveLayout"; "required": false; "isSignal": true; }; "breakpoint": { "alias": "breakpoint"; "required": false; "isSignal": true; }; "paginatorLocale": { "alias": "paginatorLocale"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "columns": { "alias": "columns"; "required": false; "isSignal": true; }; "first": { "alias": "first"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "totalRecords": { "alias": "totalRecords"; "required": false; "isSignal": true; }; "sortField": { "alias": "sortField"; "required": false; "isSignal": true; }; "sortOrder": { "alias": "sortOrder"; "required": false; "isSignal": true; }; "multiSortMeta": { "alias": "multiSortMeta"; "required": false; "isSignal": true; }; "selection": { "alias": "selection"; "required": false; "isSignal": true; }; "selectAll": { "alias": "selectAll"; "required": false; "isSignal": true; }; }, { "contextMenuSelectionChange": "contextMenuSelectionChange"; "selectAllChange": "selectAllChange"; "selectionChange": "selectionChange"; "onRowSelect": "onRowSelect"; "onRowUnselect": "onRowUnselect"; "onPage": "onPage"; "onSort": "onSort"; "onFilter": "onFilter"; "onLazyLoad": "onLazyLoad"; "onRowExpand": "onRowExpand"; "onRowCollapse": "onRowCollapse"; "onContextMenuSelect": "onContextMenuSelect"; "onColResize": "onColResize"; "onColReorder": "onColReorder"; "onRowReorder": "onRowReorder"; "onEditInit": "onEditInit"; "onEditComplete": "onEditComplete"; "onEditCancel": "onEditCancel"; "onHeaderCheckboxToggle": "onHeaderCheckboxToggle"; "sortFunction": "sortFunction"; "firstChange": "firstChange"; "rowsChange": "rowsChange"; "onStateSave": "onStateSave"; "onStateRestore": "onStateRestore"; }, ["_templates", "_headerTemplate", "_headerGroupedTemplate", "_bodyTemplate", "_loadingBodyTemplate", "_colGroupTemplate", "_frozenHeaderTemplate", "_frozenFooterTemplate", "_frozenColGroupTemplate", "_emptyMessageTemplate", "_paginatorLeftTemplate", "_paginatorRightTemplate", "_paginatorDropdownItemTemplate", "_reorderIndicatorUpIconTemplate", "_reorderIndicatorDownIconTemplate", "_checkboxIconTemplate", "_headerCheckboxIconTemplate", "_captionTemplate", "_footerTemplate", "_footerGroupedTemplate", "_summaryTemplate", "_expandedRowTemplate", "_groupHeaderTemplate", "_groupFooterTemplate", "_frozenExpandedRowTemplate", "_frozenBodyTemplate", "_loadingIconTemplate", "_sortIconTemplate", "_paginatorDropdownIconTemplate", "_paginatorFirstPageLinkIconTemplate", "_paginatorLastPageLinkIconTemplate", "_paginatorPreviousPageLinkIconTemplate", "_paginatorNextPageLinkIconTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class TableBody extends BaseComponent {
    dataTable: Table<any>;
    tableService: TableService;
    hostName: string;
    readonly columns: _angular_core.InputSignal<any[] | undefined>;
    readonly template: _angular_core.InputSignal<Nullable<TemplateRef<any>>>;
    readonly value: _angular_core.InputSignal<any[] | undefined>;
    readonly frozen: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly frozenRows: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly scrollerOptions: _angular_core.InputSignal<any>;
    subscription: Subscription;
    _value: any[] | undefined;
    onAfterViewInit(): void;
    constructor();
    shouldRenderRowGroupHeader(value: any, rowData: any, i: number): boolean;
    shouldRenderRowGroupFooter(value: any, rowData: any, i: number): boolean;
    shouldRenderRowspan(value: any, rowData: any, i: number): boolean;
    calculateRowGroupSize(value: any, rowData: any, index: number): number | null;
    onDestroy(): void;
    updateFrozenRowStickyPosition(): void;
    updateFrozenRowGroupHeaderStickyPosition(): void;
    getScrollerOption(option: any, options?: any): any;
    getRowIndex(rowIndex: number): any;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableBody, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TableBody, "[pTableBody]", never, { "columns": { "alias": "pTableBody"; "required": false; "isSignal": true; }; "template": { "alias": "pTableBodyTemplate"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "frozen": { "alias": "frozen"; "required": false; "isSignal": true; }; "frozenRows": { "alias": "frozenRows"; "required": false; "isSignal": true; }; "scrollerOptions": { "alias": "scrollerOptions"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class RowGroupHeader extends BaseComponent {
    dataTable: Table<any>;
    _componentStyle: TableStyle;
    get getFrozenRowGroupHeaderStickyPosition(): any;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RowGroupHeader, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<RowGroupHeader, "[pRowGroupHeader]", never, {}, {}, never, never, true, never>;
}
declare class FrozenColumn extends BaseComponent {
    readonly frozen: _angular_core.InputSignal<boolean | undefined>;
    readonly alignFrozen: _angular_core.InputSignal<string>;
    resizeListener: VoidListener;
    private resizeObserver?;
    _componentStyle: TableStyle;
    constructor();
    onAfterViewInit(): void;
    bindResizeListener(): void;
    unbindResizeListener(): void;
    observeChanges(): void;
    recalculateColumns(): void;
    _frozen: boolean;
    updateStickyPosition(): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FrozenColumn, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FrozenColumn, "[pFrozenColumn]", never, { "frozen": { "alias": "frozen"; "required": false; "isSignal": true; }; "alignFrozen": { "alias": "alignFrozen"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class SortableColumn extends BaseComponent {
    dataTable: Table<any>;
    readonly field: _angular_core.InputSignal<string | undefined>;
    readonly pSortableColumnDisabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    role: string | null;
    sorted: boolean | undefined;
    sortOrder: string | undefined;
    subscription: Subscription | undefined;
    _componentStyle: TableStyle;
    constructor();
    onInit(): void;
    updateSortState(): void;
    onClick(event: MouseEvent): void;
    onEnterKey(event: MouseEvent): void;
    isEnabled(): boolean;
    isFilterElement(element: HTMLElement): any;
    private isFilterElementIconOrButton;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SortableColumn, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SortableColumn, "[pSortableColumn]", never, { "field": { "alias": "pSortableColumn"; "required": false; "isSignal": true; }; "pSortableColumnDisabled": { "alias": "pSortableColumnDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class SortIcon extends BaseComponent {
    dataTable: Table<any>;
    cd: ChangeDetectorRef;
    readonly field: _angular_core.InputSignal<string | undefined>;
    subscription: Subscription | undefined;
    sortOrder: number | undefined;
    _componentStyle: TableStyle;
    constructor();
    onInit(): void;
    onClick(event: Event): void;
    updateSortState(): void;
    getMultiSortMetaIndex(): number;
    getBadgeValue(): number;
    isMultiSorted(): boolean;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SortIcon, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SortIcon, "p-sortIcon, p-sort-icon, p-sorticon", never, { "field": { "alias": "field"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class SelectableRow extends BaseComponent {
    dataTable: Table<any>;
    tableService: TableService;
    readonly data: _angular_core.InputSignal<any>;
    readonly index: _angular_core.InputSignal<number | undefined>;
    readonly pSelectableRowDisabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    selected: boolean | undefined;
    subscription: Subscription | undefined;
    _componentStyle: TableStyle;
    constructor();
    setRowTabIndex(): 0 | -1 | undefined;
    onInit(): void;
    onClick(event: Event): void;
    onTouchEnd(): void;
    onKeyDown(event: KeyboardEvent): void;
    onArrowDownKey(event: KeyboardEvent): void;
    onArrowUpKey(event: KeyboardEvent): void;
    onEnterKey(event: KeyboardEvent): void;
    onEndKey(event: KeyboardEvent): void;
    onHomeKey(event: KeyboardEvent): void;
    onSpaceKey(event: any): void;
    focusRowChange(firstFocusableRow: any, currentFocusedRow: any): void;
    findLastSelectableRow(): any;
    findFirstSelectableRow(): any;
    findNextSelectableRow(row: HTMLTableRowElement): HTMLTableRowElement | null;
    findPrevSelectableRow(row: HTMLTableRowElement): HTMLTableRowElement | null;
    isEnabled(): boolean;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectableRow, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SelectableRow, "[pSelectableRow]", never, { "data": { "alias": "pSelectableRow"; "required": false; "isSignal": true; }; "index": { "alias": "pSelectableRowIndex"; "required": false; "isSignal": true; }; "pSelectableRowDisabled": { "alias": "pSelectableRowDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class SelectableRowDblClick extends BaseComponent {
    dataTable: Table<any>;
    tableService: TableService;
    readonly data: _angular_core.InputSignal<any>;
    readonly index: _angular_core.InputSignal<number | undefined>;
    readonly pSelectableRowDisabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    selected: boolean | undefined;
    subscription: Subscription | undefined;
    _componentStyle: TableStyle;
    constructor();
    onInit(): void;
    onClick(event: Event): void;
    isEnabled(): boolean;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectableRowDblClick, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SelectableRowDblClick, "[pSelectableRowDblClick]", never, { "data": { "alias": "pSelectableRowDblClick"; "required": false; "isSignal": true; }; "index": { "alias": "pSelectableRowIndex"; "required": false; "isSignal": true; }; "pSelectableRowDisabled": { "alias": "pSelectableRowDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class ContextMenuRow extends BaseComponent {
    dataTable: Table<any>;
    tableService: TableService;
    readonly data: _angular_core.InputSignal<any>;
    readonly index: _angular_core.InputSignal<number | undefined>;
    readonly pContextMenuRowDisabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    selected: boolean | undefined;
    subscription: Subscription | undefined;
    _componentStyle: TableStyle;
    constructor();
    onContextMenu(event: Event): void;
    isEnabled(): boolean;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ContextMenuRow, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ContextMenuRow, "[pContextMenuRow]", never, { "data": { "alias": "pContextMenuRow"; "required": false; "isSignal": true; }; "index": { "alias": "pContextMenuRowIndex"; "required": false; "isSignal": true; }; "pContextMenuRowDisabled": { "alias": "pContextMenuRowDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class RowToggler extends BaseComponent {
    dataTable: Table<any>;
    readonly data: _angular_core.InputSignal<any>;
    readonly pRowTogglerDisabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    onClick(event: Event): void;
    isEnabled(): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RowToggler, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<RowToggler, "[pRowToggler]", never, { "data": { "alias": "pRowToggler"; "required": false; "isSignal": true; }; "pRowTogglerDisabled": { "alias": "pRowTogglerDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class ResizableColumn extends BaseComponent {
    dataTable: Table<any>;
    zone: NgZone;
    readonly pResizableColumnDisabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    resizer: HTMLSpanElement | undefined;
    resizerMouseDownListener: VoidListener;
    resizerTouchStartListener: VoidListener;
    resizerTouchMoveListener: VoidListener;
    resizerTouchEndListener: VoidListener;
    documentMouseMoveListener: VoidListener;
    documentMouseUpListener: VoidListener;
    _componentStyle: TableStyle;
    onAfterViewInit(): void;
    bindDocumentEvents(): void;
    unbindDocumentEvents(): void;
    onMouseDown(event: MouseEvent): void;
    onTouchStart(event: TouchEvent): void;
    onTouchMove(event: TouchEvent): void;
    onDocumentMouseMove(event: MouseEvent): void;
    onDocumentMouseUp(): void;
    onTouchEnd(): void;
    isEnabled(): boolean;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ResizableColumn, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ResizableColumn, "[pResizableColumn]", never, { "pResizableColumnDisabled": { "alias": "pResizableColumnDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class ReorderableColumn extends BaseComponent {
    dataTable: Table<any>;
    el: ElementRef<any>;
    zone: NgZone;
    readonly pReorderableColumnDisabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    dragStartListener: VoidListener;
    dragOverListener: VoidListener;
    dragEnterListener: VoidListener;
    dragLeaveListener: VoidListener;
    mouseDownListener: VoidListener;
    _componentStyle: TableStyle;
    onAfterViewInit(): void;
    bindEvents(): void;
    unbindEvents(): void;
    onMouseDown(event: any): void;
    onDragStart(event: any): void;
    onDragOver(event: any): void;
    onDragEnter(event: any): void;
    onDragLeave(event: any): void;
    onDrop(event: any): void;
    isEnabled(): boolean;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ReorderableColumn, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ReorderableColumn, "[pReorderableColumn]", never, { "pReorderableColumnDisabled": { "alias": "pReorderableColumnDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class EditableColumn extends BaseComponent {
    dataTable: Table<any>;
    zone: NgZone;
    readonly data: _angular_core.InputSignal<any>;
    readonly field: _angular_core.InputSignal<any>;
    readonly rowIndex: _angular_core.InputSignal<number | undefined>;
    readonly pEditableColumnDisabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly pFocusCellSelector: _angular_core.InputSignal<string | undefined>;
    overlayEventListener: any;
    onChanges(changes: SimpleChanges): void;
    onAfterViewInit(): void;
    onClick(event: MouseEvent): void;
    openCell(): void;
    closeEditingCell(completed: any, event: Event): void;
    onEnterKeyDown(event: KeyboardEvent): void;
    onTabKeyDown(event: KeyboardEvent): void;
    onEscapeKeyDown(event: KeyboardEvent): void;
    onShiftKeyDown(event: KeyboardEvent): void;
    onArrowDown(event: KeyboardEvent): void;
    onArrowUp(event: KeyboardEvent): void;
    onArrowLeft(event: KeyboardEvent): void;
    onArrowRight(event: KeyboardEvent): void;
    findCell(element: any): any;
    moveToPreviousCell(event: KeyboardEvent): void;
    moveToNextCell(event: KeyboardEvent): void;
    findPreviousEditableColumn(cell: any): HTMLTableCellElement | null;
    findNextEditableColumn(cell: any): HTMLTableCellElement | null;
    findNextEditableColumnByIndex(cell: Element, index: number): Element | null;
    findPrevEditableColumnByIndex(cell: Element, index: number): Element | null;
    isEnabled(): boolean;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<EditableColumn, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<EditableColumn, "[pEditableColumn]", never, { "data": { "alias": "pEditableColumn"; "required": false; "isSignal": true; }; "field": { "alias": "pEditableColumnField"; "required": false; "isSignal": true; }; "rowIndex": { "alias": "pEditableColumnRowIndex"; "required": false; "isSignal": true; }; "pEditableColumnDisabled": { "alias": "pEditableColumnDisabled"; "required": false; "isSignal": true; }; "pFocusCellSelector": { "alias": "pFocusCellSelector"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class EditableRow extends BaseComponent {
    readonly data: _angular_core.InputSignal<any>;
    readonly pEditableRowDisabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    isEnabled(): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<EditableRow, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<EditableRow, "[pEditableRow]", never, { "data": { "alias": "pEditableRow"; "required": false; "isSignal": true; }; "pEditableRowDisabled": { "alias": "pEditableRowDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class InitEditableRow extends BaseComponent {
    dataTable: Table<any>;
    editableRow: EditableRow;
    onClick(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InitEditableRow, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<InitEditableRow, "[pInitEditableRow]", never, {}, {}, never, never, true, never>;
}
declare class SaveEditableRow extends BaseComponent {
    dataTable: Table<any>;
    editableRow: EditableRow;
    onClick(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SaveEditableRow, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SaveEditableRow, "[pSaveEditableRow]", never, {}, {}, never, never, true, never>;
}
declare class CancelEditableRow extends BaseComponent {
    dataTable: Table<any>;
    editableRow: EditableRow;
    _componentStyle: TableStyle;
    onClick(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CancelEditableRow, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CancelEditableRow, "[pCancelEditableRow]", never, {}, {}, never, never, true, never>;
}
declare class CellEditor extends BaseComponent {
    dataTable: Table<any>;
    editableColumn: EditableColumn | null;
    editableRow: EditableRow | null;
    readonly _templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    readonly _inputTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    readonly _outputTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    inputTemplate: Nullable<TemplateRef<any>>;
    outputTemplate: Nullable<TemplateRef<any>>;
    onAfterContentInit(): void;
    get editing(): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CellEditor, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CellEditor, "p-cellEditor, p-cell-editor, p-celleditor", never, {}, {}, ["_templates", "_inputTemplate", "_outputTemplate"], never, true, never>;
}
declare class TableRadioButton extends BaseComponent {
    dataTable: Table<any>;
    cd: ChangeDetectorRef;
    readonly value: _angular_core.InputSignal<any>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly index: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly name: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    _ariaLabel: string | undefined;
    readonly inputViewChild: _angular_core.Signal<Nullable<RadioButton>>;
    checked: boolean | undefined;
    subscription: Subscription;
    constructor();
    onInit(): void;
    onClick(event: RadioButtonClickEvent): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableRadioButton, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TableRadioButton, "p-tableRadioButton, p-table-radio-button, p-tableradiobutton", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "index": { "alias": "index"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class TableCheckbox extends BaseComponent {
    dataTable: Table<any>;
    tableService: TableService;
    readonly value: _angular_core.InputSignal<any>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly required: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly index: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly name: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    _ariaLabel: string | undefined;
    checked: boolean | undefined;
    subscription: Subscription;
    constructor();
    onInit(): void;
    onClick({ originalEvent }: CheckboxChangeEvent): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableCheckbox, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TableCheckbox, "p-tableCheckbox, p-table-checkbox, p-tablecheckbox", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "index": { "alias": "index"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class TableHeaderCheckbox extends BaseComponent {
    dataTable: Table<any>;
    tableService: TableService;
    hostName: string;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    readonly name: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    _ariaLabel: string | undefined;
    checked: boolean | undefined;
    selectionChangeSubscription: Subscription;
    valueChangeSubscription: Subscription;
    constructor();
    onInit(): void;
    onClick(event: CheckboxChangeEvent): void;
    isDisabled(): boolean;
    onDestroy(): void;
    updateCheckedState(): any;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableHeaderCheckbox, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TableHeaderCheckbox, "p-tableHeaderCheckbox, p-table-header-checkbox, p-tableheadercheckbox", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class ReorderableRowHandle extends BaseComponent {
    el: ElementRef<any>;
    hostName: string;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    _componentStyle: TableStyle;
    onAfterViewInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ReorderableRowHandle, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ReorderableRowHandle, "[pReorderableRowHandle]", never, {}, {}, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class ReorderableRow extends BaseComponent {
    dataTable: Table<any>;
    zone: NgZone;
    hostName: string;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    readonly index: _angular_core.InputSignal<number | undefined>;
    readonly pReorderableRowDisabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    mouseDownListener: VoidListener;
    dragStartListener: VoidListener;
    dragEndListener: VoidListener;
    dragOverListener: VoidListener;
    dragLeaveListener: VoidListener;
    dropListener: VoidListener;
    onAfterViewInit(): void;
    bindEvents(): void;
    unbindEvents(): void;
    onMouseDown(event: Event): void;
    isHandleElement(element: HTMLElement): boolean;
    onDragStart(event: DragEvent): void;
    onDragEnd(): void;
    onDragOver(event: DragEvent): void;
    onDragLeave(event: DragEvent): void;
    isEnabled(): boolean;
    onDrop(event: DragEvent): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ReorderableRow, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ReorderableRow, "[pReorderableRow]", never, { "index": { "alias": "pReorderableRow"; "required": false; "isSignal": true; }; "pReorderableRowDisabled": { "alias": "pReorderableRowDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
/**
 * Column Filter Component.
 * @group Components
 */
declare class ColumnFilter extends BaseComponent {
    hostName: string;
    bindDirectiveInstance: Bind;
    _componentStyle: TableStyle;
    onAfterViewChecked(): void;
    ptmFilterConstraintOptions(matchMode: any): {
        context: {
            highlighted: any;
        };
    };
    /**
     * Property represented by the column.
     * @group Props
     */
    readonly field: _angular_core.InputSignal<string | undefined>;
    /**
     * Type of the input.
     * @group Props
     */
    readonly type: _angular_core.InputSignal<string>;
    /**
     * Filter display.
     * @group Props
     */
    readonly display: _angular_core.InputSignal<string>;
    /**
     * Decides whether to display filter menu popup.
     * @group Props
     */
    readonly showMenu: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Filter match mode.
     * @group Props
     */
    readonly matchMode: _angular_core.InputSignal<string | undefined>;
    /**
     * Filter operator.
     * @defaultValue 'AND'
     * @group Props
     */
    readonly operator: _angular_core.InputSignal<string>;
    /**
     * Decides whether to display filter operator.
     * @group Props
     */
    readonly showOperator: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Decides whether to display clear filter button when display is menu.
     * @defaultValue true
     * @group Props
     */
    readonly showClearButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Decides whether to display apply filter button when display is menu.
     * @group Props
     */
    readonly showApplyButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Decides whether to display filter match modes when display is menu.
     * @group Props
     */
    readonly showMatchModes: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Decides whether to display add filter button when display is menu.
     * @group Props
     */
    readonly showAddButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Decides whether to close popup on clear button click.
     * @group Props
     */
    readonly hideOnClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Filter placeholder.
     * @group Props
     */
    readonly placeholder: _angular_core.InputSignal<string | undefined>;
    /**
     * Filter match mode options.
     * @group Props
     */
    readonly matchModeOptions: _angular_core.InputSignal<SelectItem<any>[] | undefined>;
    /**
     * Defines maximum amount of constraints.
     * @group Props
     */
    readonly maxConstraints: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Defines minimum fraction of digits.
     * @group Props
     */
    readonly minFractionDigits: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Defines maximum fraction of digits.
     * @group Props
     */
    readonly maxFractionDigits: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Defines prefix of the filter.
     * @group Props
     */
    readonly prefix: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines suffix of the filter.
     * @group Props
     */
    readonly suffix: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines filter locale.
     * @group Props
     */
    readonly locale: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines filter locale matcher.
     * @group Props
     */
    readonly localeMatcher: _angular_core.InputSignal<string | undefined>;
    /**
     * Enables currency input.
     * @group Props
     */
    readonly currency: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines the display of the currency input.
     * @group Props
     */
    readonly currencyDisplay: _angular_core.InputSignal<string | undefined>;
    /**
     * Default trigger to run filtering on built-in text and numeric filters, valid values are 'enter' and 'input'.
     * @defaultValue enter
     * @group Props
     */
    readonly filterOn: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines if filter grouping will be enabled.
     * @group Props
     */
    readonly useGrouping: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Defines the visibility of buttons.
     * @group Props
     */
    readonly showButtons: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Defines the aria-label of the form element.
     * @group Props
     */
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Used to pass all filter button property object
     * @defaultValue {
     filter: { severity: 'secondary', text: true, rounded: true },
     inline: {
        clear: { severity: 'secondary', text: true, rounded: true }
     },
     popover: {
         addRule: { severity: 'info', text: true, size: 'small' },
         removeRule: { severity: 'danger', text: true, size: 'small' },
         apply: { size: 'small' },
         clear: { outlined: true, size: 'small' }
        }
     }
     @group Props
     */
    readonly filterButtonProps: _angular_core.InputSignal<TableFilterButtonPropsOptions>;
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    computedMotionOptions: _angular_core.Signal<MotionOptions>;
    /**
     * Callback to invoke on overlay is shown.
     * @param {AnimationEvent} originalEvent - animation event.
     * @group Emits
     */
    readonly onShow: _angular_core.OutputEmitterRef<{
        originalEvent: AnimationEvent;
    }>;
    /**
     * Callback to invoke on overlay is hidden.
     * @param {AnimationEvent} originalEvent - animation event.
     * @group Emits
     */
    readonly onHide: _angular_core.OutputEmitterRef<{
        originalEvent: AnimationEvent;
    }>;
    readonly icon: _angular_core.Signal<ElementRef<any> | undefined>;
    readonly clearButtonViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly _templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    overlaySubscription: Subscription | undefined;
    renderOverlay: _angular_core.WritableSignal<boolean>;
    /**
     * Custom header template.
     * @group Templates
     */
    readonly headerTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    _headerTemplate: Nullable<TemplateRef<any>>;
    /**
     * Custom filter template.
     * @group Templates
     */
    readonly filterTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    _filterTemplate: Nullable<TemplateRef<any>>;
    /**
     * Custom footer template.
     * @group Templates
     */
    readonly footerTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    _footerTemplate: Nullable<TemplateRef<any>>;
    /**
     * Custom filter icon template.
     * @group Templates
     */
    filterIconTemplate: TemplateRef<any>;
    _filterIconTemplate: Nullable<TemplateRef<any>>;
    /**
     * Custom remove rule button icon template.
     * @group Templates
     */
    readonly removeRuleIconTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    _removeRuleIconTemplate: Nullable<TemplateRef<any>>;
    /**
     * Custom add rule button icon template.
     * @group Templates
     */
    readonly addRuleIconTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    _addRuleIconTemplate: Nullable<TemplateRef<any>>;
    readonly clearFilterIconTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    _clearFilterIconTemplate: Nullable<TemplateRef<any>>;
    operatorOptions: any[] | undefined;
    overlayVisible: boolean | undefined;
    overlay: HTMLElement | undefined | null;
    scrollHandler: ConnectedOverlayScrollHandler | null | undefined;
    documentClickListener: VoidListener;
    _operator: string | undefined;
    constructor();
    documentResizeListener: VoidListener;
    matchModes: SelectItem[] | undefined;
    translationSubscription: Subscription | undefined;
    resetSubscription: Subscription | undefined;
    selfClick: boolean | undefined;
    overlayEventListener: any;
    overlayId: any;
    get fieldConstraints(): FilterMetadata[] | undefined | null;
    get showRemoveIcon(): boolean;
    get showMenuButton(): boolean;
    get isShowOperator(): boolean;
    get isShowAddConstraint(): boolean | undefined | null;
    get showMenuButtonLabel(): any;
    get applyButtonLabel(): string;
    get clearButtonLabel(): string;
    get addRuleButtonLabel(): string;
    get removeRuleButtonLabel(): string;
    get noFilterLabel(): string;
    get filterMenuButtonAriaLabel(): string | undefined;
    get removeRuleButtonAriaLabel(): string | undefined;
    get filterOperatorAriaLabel(): string | undefined;
    get filterConstraintAriaLabel(): string | undefined;
    dataTable: Table<any>;
    overlayService: OverlayService;
    onInit(): void;
    generateMatchModeOptions(): void;
    generateOperatorOptions(): void;
    onAfterContentInit(): void;
    initFieldFilterConstraint(): void;
    onMenuMatchModeChange(value: any, filterMeta: FilterMetadata): void;
    onRowMatchModeChange(matchMode: string): void;
    onRowMatchModeKeyDown(event: KeyboardEvent): void;
    onRowClearItemClick(): void;
    isRowMatchModeSelected(matchMode: string): boolean;
    addConstraint(): void;
    removeConstraint(filterMeta: FilterMetadata): void;
    onOperatorChange(value: any): void;
    toggleMenu(event: Event): void;
    onToggleButtonKeyDown(event: KeyboardEvent): void;
    onEscape(): void;
    findNextItem(item: HTMLLIElement): any;
    findPrevItem(item: HTMLLIElement): any;
    onContentClick(): void;
    onOverlayBeforeEnter(event: MotionEvent): void;
    onOverlayAnimationAfterLeave(event: MotionEvent): void;
    restoreOverlayAppend(): void;
    focusOnFirstElement(): void;
    getDefaultMatchMode(): string;
    getDefaultOperator(): string | undefined;
    hasRowFilter(): boolean;
    get hasFilter(): boolean;
    isOutsideClicked(event: any): boolean;
    bindDocumentClickListener(): void;
    unbindDocumentClickListener(): void;
    bindDocumentResizeListener(): void;
    unbindDocumentResizeListener(): void;
    bindScrollListener(): void;
    unbindScrollListener(): void;
    hide(): void;
    onOverlayHide(): void;
    clearFilter(): void;
    applyFilter(): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ColumnFilter, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ColumnFilter, "p-columnFilter, p-column-filter, p-columnfilter", never, { "field": { "alias": "field"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "display": { "alias": "display"; "required": false; "isSignal": true; }; "showMenu": { "alias": "showMenu"; "required": false; "isSignal": true; }; "matchMode": { "alias": "matchMode"; "required": false; "isSignal": true; }; "operator": { "alias": "operator"; "required": false; "isSignal": true; }; "showOperator": { "alias": "showOperator"; "required": false; "isSignal": true; }; "showClearButton": { "alias": "showClearButton"; "required": false; "isSignal": true; }; "showApplyButton": { "alias": "showApplyButton"; "required": false; "isSignal": true; }; "showMatchModes": { "alias": "showMatchModes"; "required": false; "isSignal": true; }; "showAddButton": { "alias": "showAddButton"; "required": false; "isSignal": true; }; "hideOnClear": { "alias": "hideOnClear"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "matchModeOptions": { "alias": "matchModeOptions"; "required": false; "isSignal": true; }; "maxConstraints": { "alias": "maxConstraints"; "required": false; "isSignal": true; }; "minFractionDigits": { "alias": "minFractionDigits"; "required": false; "isSignal": true; }; "maxFractionDigits": { "alias": "maxFractionDigits"; "required": false; "isSignal": true; }; "prefix": { "alias": "prefix"; "required": false; "isSignal": true; }; "suffix": { "alias": "suffix"; "required": false; "isSignal": true; }; "locale": { "alias": "locale"; "required": false; "isSignal": true; }; "localeMatcher": { "alias": "localeMatcher"; "required": false; "isSignal": true; }; "currency": { "alias": "currency"; "required": false; "isSignal": true; }; "currencyDisplay": { "alias": "currencyDisplay"; "required": false; "isSignal": true; }; "filterOn": { "alias": "filterOn"; "required": false; "isSignal": true; }; "useGrouping": { "alias": "useGrouping"; "required": false; "isSignal": true; }; "showButtons": { "alias": "showButtons"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "filterButtonProps": { "alias": "filterButtonProps"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; }, { "onShow": "onShow"; "onHide": "onHide"; }, ["_templates", "headerTemplate", "filterTemplate", "footerTemplate", "removeRuleIconTemplate", "addRuleIconTemplate", "clearFilterIconTemplate", "filterIconTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class ColumnFilterFormElement extends BaseComponent<ColumnFilterPassThrough> {
    dataTable: Table<any>;
    private colFilter;
    hostName: string;
    bindDirectiveInstance: Bind;
    _componentStyle: TableStyle;
    onAfterViewChecked(): void;
    readonly field: _angular_core.InputSignal<string | undefined>;
    readonly type: _angular_core.InputSignal<string | undefined>;
    readonly filterConstraint: _angular_core.InputSignal<FilterMetadata | undefined>;
    readonly filterTemplate: _angular_core.InputSignal<Nullable<TemplateRef<any>>>;
    readonly placeholder: _angular_core.InputSignal<string | undefined>;
    readonly minFractionDigits: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly maxFractionDigits: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly prefix: _angular_core.InputSignal<string | undefined>;
    readonly suffix: _angular_core.InputSignal<string | undefined>;
    readonly locale: _angular_core.InputSignal<string | undefined>;
    readonly localeMatcher: _angular_core.InputSignal<string | undefined>;
    readonly currency: _angular_core.InputSignal<string | undefined>;
    readonly currencyDisplay: _angular_core.InputSignal<string | undefined>;
    readonly useGrouping: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    readonly filterOn: _angular_core.InputSignal<string | undefined>;
    get showButtons(): boolean;
    filterCallback: any;
    onInit(): void;
    onModelChange(value: any): void;
    onTextInputEnterKeyDown(event: KeyboardEvent): void;
    onNumericInputKeyDown(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ColumnFilterFormElement, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ColumnFilterFormElement, "p-columnFilterFormElement, p-column-filter-form-element, p-columnfilterformelement", never, { "field": { "alias": "field"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "filterConstraint": { "alias": "filterConstraint"; "required": false; "isSignal": true; }; "filterTemplate": { "alias": "filterTemplate"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "minFractionDigits": { "alias": "minFractionDigits"; "required": false; "isSignal": true; }; "maxFractionDigits": { "alias": "maxFractionDigits"; "required": false; "isSignal": true; }; "prefix": { "alias": "prefix"; "required": false; "isSignal": true; }; "suffix": { "alias": "suffix"; "required": false; "isSignal": true; }; "locale": { "alias": "locale"; "required": false; "isSignal": true; }; "localeMatcher": { "alias": "localeMatcher"; "required": false; "isSignal": true; }; "currency": { "alias": "currency"; "required": false; "isSignal": true; }; "currencyDisplay": { "alias": "currencyDisplay"; "required": false; "isSignal": true; }; "useGrouping": { "alias": "useGrouping"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "filterOn": { "alias": "filterOn"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class TableModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<TableModule, never, [typeof i2.CommonModule, typeof i3.PaginatorModule, typeof i4.InputTextModule, typeof i5.SelectModule, typeof i6.FormsModule, typeof i7.ButtonModule, typeof i8.SelectButtonModule, typeof i9.DatePickerModule, typeof i10.InputNumberModule, typeof i11.BadgeModule, typeof i12.CheckboxModule, typeof i13.ScrollerModule, typeof i14.ArrowDownIcon, typeof i15.ArrowUpIcon, typeof i16.SpinnerIcon, typeof i17.SortAltIcon, typeof i18.SortAmountUpAltIcon, typeof i19.SortAmountDownIcon, typeof i20.FilterIcon, typeof i21.FilterFillIcon, typeof i22.FilterSlashIcon, typeof i23.PlusIcon, typeof i24.TrashIcon, typeof i25.RadioButtonModule, typeof i1.BindModule, typeof i26.MotionModule, typeof Table, typeof SortableColumn, typeof FrozenColumn, typeof RowGroupHeader, typeof SelectableRow, typeof RowToggler, typeof ContextMenuRow, typeof ResizableColumn, typeof ReorderableColumn, typeof EditableColumn, typeof CellEditor, typeof TableBody, typeof SortIcon, typeof TableRadioButton, typeof TableCheckbox, typeof TableHeaderCheckbox, typeof ReorderableRowHandle, typeof ReorderableRow, typeof SelectableRowDblClick, typeof EditableRow, typeof InitEditableRow, typeof SaveEditableRow, typeof CancelEditableRow, typeof ColumnFilter, typeof ColumnFilterFormElement], [typeof Table, typeof i27.SharedModule, typeof SortableColumn, typeof FrozenColumn, typeof RowGroupHeader, typeof SelectableRow, typeof RowToggler, typeof ContextMenuRow, typeof ResizableColumn, typeof ReorderableColumn, typeof EditableColumn, typeof CellEditor, typeof SortIcon, typeof TableRadioButton, typeof TableCheckbox, typeof TableHeaderCheckbox, typeof ReorderableRowHandle, typeof ReorderableRow, typeof SelectableRowDblClick, typeof EditableRow, typeof InitEditableRow, typeof SaveEditableRow, typeof CancelEditableRow, typeof ColumnFilter, typeof ColumnFilterFormElement, typeof i13.ScrollerModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<TableModule>;
}

export { CancelEditableRow, CellEditor, ColumnFilter, ColumnFilterFormElement, ContextMenuRow, EditableColumn, EditableRow, FrozenColumn, InitEditableRow, ReorderableColumn, ReorderableRow, ReorderableRowHandle, ResizableColumn, RowGroupHeader, RowToggler, SaveEditableRow, SelectableRow, SelectableRowDblClick, SortIcon, SortableColumn, Table, TableBody, TableCheckbox, TableClasses, TableHeaderCheckbox, TableModule, TableRadioButton, TableService, TableStyle };
