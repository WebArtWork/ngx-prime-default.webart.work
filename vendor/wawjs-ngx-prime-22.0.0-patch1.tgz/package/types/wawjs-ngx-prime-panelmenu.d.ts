import { PanelMenuPassThrough, PanelMenuItemTemplateContext } from '@wawjs/ngx-prime/types/panelmenu';
export * from '@wawjs/ngx-prime/types/panelmenu';
import * as _angular_core from '@angular/core';
import { ElementRef, TemplateRef } from '@angular/core';
import { MotionOptions } from '@wawjs/css-prime-motion';
import * as i2 from '@wawjs/ngx-prime/api';
import { MenuItem, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class PanelMenuStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: () => string[];
        panel: string;
        header: ({ instance, item }: {
            instance: any;
            item: any;
        }) => (string | {
            'p-panelmenu-header-active': any;
            'p-disabled': any;
        })[];
        headerContent: string;
        headerLink: string;
        headerIcon: string;
        headerLabel: string;
        contentContainer: ({ instance, processedItem }: {
            instance: any;
            processedItem: any;
        }) => (string | {
            'p-panelmenu-expanded': any;
        })[];
        contentWrapper: string;
        content: string;
        rootList: string;
        item: ({ instance, processedItem }: {
            instance: any;
            processedItem: any;
        }) => (string | {
            'p-focus': any;
            'p-disabled': any;
        })[];
        itemContent: string;
        itemLink: string;
        itemIcon: string;
        itemLabel: string;
        submenuIcon: string;
        submenu: string;
        separator: string;
        badge: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PanelMenuStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<PanelMenuStyle>;
}
/**
 *
 * PanelMenu is a hybrid of Accordion and Tree components.
 *
 * [Live Demo](https://www.ngx-prime.org/panelmenu/)
 *
 * @module panelmenustyle
 *
 */
declare enum PanelMenuClasses {
    /**
     * Class name of the root element
     */
    root = "p-panelmenu",
    /**
     * Class name of the panel element
     */
    panel = "p-panelmenu-panel",
    /**
     * Class name of the header element
     */
    header = "p-panelmenu-header",
    /**
     * Class name of the header content element
     */
    headerContent = "p-panelmenu-header-content",
    /**
     * Class name of the header link element
     */
    headerLink = "p-panelmenu-header-link",
    /**
     * Class name of the header icon element
     */
    headerIcon = "p-panelmenu-header-icon",
    /**
     * Class name of the header label element
     */
    headerLabel = "p-panelmenu-header-label",
    /**
     * Class name of the content container element
     */
    contentContainer = "p-panelmenu-content-container",
    /**
     * Class name of the content element
     */
    content = "p-panelmenu-content",
    /**
     * Class name of the root list element
     */
    rootList = "p-panelmenu-root-list",
    /**
     * Class name of the item element
     */
    item = "p-panelmenu-item",
    /**
     * Class name of the item content element
     */
    itemContent = "p-panelmenu-item-content",
    /**
     * Class name of the item link element
     */
    itemLink = "p-panelmenu-item-link",
    /**
     * Class name of the item icon element
     */
    itemIcon = "p-panelmenu-item-icon",
    /**
     * Class name of the item label element
     */
    itemLabel = "p-panelmenu-item-label",
    /**
     * Class name of the submenu icon element
     */
    submenuIcon = "p-panelmenu-submenu-icon",
    /**
     * Class name of the submenu element
     */
    submenu = "p-panelmenu-submenu",
    separator = "p-menuitem-separator"
}

declare class PanelMenuSub extends BaseComponent {
    panelId: _angular_core.InputSignal<string | undefined>;
    focusedItemId: _angular_core.InputSignal<string | undefined>;
    items: _angular_core.InputSignal<any[] | undefined>;
    itemTemplate: _angular_core.InputSignal<TemplateRef<PanelMenuItemTemplateContext> | undefined>;
    level: _angular_core.InputSignalWithTransform<number, unknown>;
    activeItemPath: _angular_core.InputSignal<any[] | undefined>;
    root: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    transitionOptions: _angular_core.InputSignal<string | undefined>;
    parentExpanded: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    itemToggle: _angular_core.OutputEmitterRef<any>;
    menuFocus: _angular_core.OutputEmitterRef<any>;
    menuBlur: _angular_core.OutputEmitterRef<any>;
    menuKeyDown: _angular_core.OutputEmitterRef<any>;
    listViewChild: ElementRef;
    panelMenu: PanelMenu;
    _componentStyle: PanelMenuStyle;
    bindDirectiveInstance: Bind;
    $pcPanelMenu: PanelMenu | undefined;
    onAfterViewChecked(): void;
    getPTOptions(processedItem: any, index: number, key: string): any;
    getItemId(processedItem: any): any;
    getItemKey(processedItem: any): any;
    getItemClass(processedItem: any): {
        'p-panelmenu-item': boolean;
        'p-disabled': any;
        'p-focus': boolean;
    };
    getItemProp(processedItem: any, name?: any, params?: any): any;
    getItemLabel(processedItem: any): any;
    isItemExpanded(processedItem: any): any;
    isItemActive(processedItem: any): any;
    isItemVisible(processedItem: any): boolean;
    isItemDisabled(processedItem: any): any;
    isItemFocused(processedItem: any): boolean;
    isItemGroup(processedItem: any): boolean;
    getAriaSetSize(): number;
    getAriaPosInset(index: any): number;
    onItemClick(event: any, processedItem: any): void;
    onItemToggle(event: any): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PanelMenuSub, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PanelMenuSub, "ul[pPanelMenuSub]", never, { "panelId": { "alias": "panelId"; "required": false; "isSignal": true; }; "focusedItemId": { "alias": "focusedItemId"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": false; "isSignal": true; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; "isSignal": true; }; "level": { "alias": "level"; "required": false; "isSignal": true; }; "activeItemPath": { "alias": "activeItemPath"; "required": false; "isSignal": true; }; "root": { "alias": "root"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "transitionOptions": { "alias": "transitionOptions"; "required": false; "isSignal": true; }; "parentExpanded": { "alias": "parentExpanded"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; }, { "itemToggle": "itemToggle"; "menuFocus": "menuFocus"; "menuBlur": "menuBlur"; "menuKeyDown": "menuKeyDown"; }, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class PanelMenuList extends BaseComponent {
    panelId: _angular_core.InputSignal<string | undefined>;
    id: _angular_core.InputSignal<string | undefined>;
    items: _angular_core.InputSignal<any[] | undefined>;
    itemTemplate: _angular_core.InputSignal<TemplateRef<PanelMenuItemTemplateContext> | undefined>;
    parentExpanded: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    expanded: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    transitionOptions: _angular_core.InputSignal<string | undefined>;
    root: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    activeItem: _angular_core.InputSignal<any>;
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    itemToggle: _angular_core.OutputEmitterRef<any>;
    headerFocus: _angular_core.OutputEmitterRef<any>;
    readonly subMenuViewChild: _angular_core.Signal<PanelMenuSub>;
    searchTimeout: any;
    searchValue: any;
    focused: boolean | undefined;
    focusedItem: _angular_core.WritableSignal<any>;
    activeItemPath: _angular_core.WritableSignal<any[]>;
    processedItems: _angular_core.WritableSignal<any[]>;
    visibleItems: _angular_core.Signal<never[]>;
    get focusedItemId(): any;
    constructor();
    getItemProp(processedItem: any, name: any): any;
    getItemLabel(processedItem: any): any;
    isItemVisible(processedItem: any): boolean;
    isItemDisabled(processedItem: any): any;
    isItemActive(processedItem: any): boolean;
    isItemGroup(processedItem: any): boolean;
    isElementInPanel(event: any, element: any): any;
    isItemMatched(processedItem: any): any;
    isVisibleItem(processedItem: any): boolean;
    isValidItem(processedItem: any): boolean;
    findFirstItem(): undefined;
    findLastItem(): undefined;
    findItemByEventTarget(target: EventTarget): undefined | any;
    createProcessedItems(items: any, level?: number, parent?: {}, parentKey?: string): any;
    findProcessedItemByItemKey(key: any, processedItems?: any, level?: number): any;
    flatItems(processedItems: any, processedFlattenItems?: never[]): never[];
    changeFocusedItem(event: any): void;
    scrollInView(): void;
    onFocus(event: any): void;
    onBlur(event: any): void;
    onItemToggle(event: any): void;
    onKeyDown(event: any): void;
    onArrowDownKey(event: any): void;
    onArrowUpKey(event: any): void;
    onArrowLeftKey(event: any): void;
    onArrowRightKey(event: any): void;
    onHomeKey(event: any): void;
    onEndKey(event: any): void;
    onEnterKey(event: any): void;
    onSpaceKey(event: any): void;
    findNextItem(processedItem: any): any;
    findPrevItem(processedItem: any): any;
    searchItems(event: any, char: any): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PanelMenuList, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PanelMenuList, "ul[pPanelMenuList]", never, { "panelId": { "alias": "panelId"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": false; "isSignal": true; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; "isSignal": true; }; "parentExpanded": { "alias": "parentExpanded"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; "transitionOptions": { "alias": "transitionOptions"; "required": false; "isSignal": true; }; "root": { "alias": "root"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "activeItem": { "alias": "activeItem"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; }, { "itemToggle": "itemToggle"; "headerFocus": "headerFocus"; }, never, never, true, never>;
}
/**
 * PanelMenu is a hybrid of Accordion and Tree components.
 * @group Components
 */
declare class PanelMenu extends BaseComponent<PanelMenuPassThrough> {
    componentName: string;
    /**
     * An array of menuitems.
     * @group Props
     */
    model: _angular_core.InputSignal<MenuItem[] | undefined>;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether multiple tabs can be activated at the same time or not.
     * @group Props
     */
    multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Transition options of the animation.
     * @group Props
     * @deprecated since v21.0.0, use `motionOptions` instead.
     */
    transitionOptions: _angular_core.InputSignal<string>;
    /**
     * The motion options.
     * @group Props
     */
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    computedMotionOptions: _angular_core.Signal<MotionOptions>;
    /**
     * Current id state as a string.
     * @group Props
     */
    id: _angular_core.InputSignal<string | undefined>;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly containerViewChild: _angular_core.Signal<ElementRef<any> | undefined>;
    /**
     * Template option of submenu icon.
     * @group Templates
     */
    readonly submenuIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Template option of header icon.
     * @group Templates
     */
    readonly headerIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Template option of item.
     * @param {PanelMenuItemTemplateContext} context - item context.
     * @see {@link PanelMenuItemTemplateContext}
     * @group Templates
     */
    readonly itemTemplate: _angular_core.Signal<TemplateRef<PanelMenuItemTemplateContext> | undefined>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _submenuIconTemplate: TemplateRef<void> | undefined;
    _headerIconTemplate: TemplateRef<void> | undefined;
    _itemTemplate: TemplateRef<PanelMenuItemTemplateContext> | undefined;
    activeItem: _angular_core.WritableSignal<any>;
    _componentStyle: PanelMenuStyle;
    bindDirectiveInstance: Bind;
    $pcPanelMenu: PanelMenu | undefined;
    private _generatedId;
    get resolvedId(): string;
    onAfterViewChecked(): void;
    getPTOptions(key: string, item: any, index: number): any;
    onAfterContentInit(): void;
    /**
     * Collapses open panels.
     * @group Method
     */
    collapseAll(): void;
    changeActiveItem(event: any, item: any, index?: number, selfActive?: boolean): void;
    getItemProp(item: any, name: any): any;
    getItemLabel(item: any): any;
    isItemActive(item: any): any;
    isItemVisible(item: any): boolean;
    isItemDisabled(item: any): any;
    isItemGroup(item: any): boolean;
    getPanelId(index: any, item?: any): any;
    getHeaderId(item: any, index: any): string;
    getContentId(item: any, index: any): string;
    updateFocusedHeader(event: any): void;
    changeFocusedHeader(event: any, element: any): void;
    findNextHeader(panelElement: any, selfCheck?: boolean): any;
    findPrevHeader(panelElement: any, selfCheck?: boolean): any;
    findFirstHeader(): any;
    findLastHeader(): any;
    onHeaderClick(event: any, item: any, index: any): void;
    onHeaderKeyDown(event: any, item: any, index: any): void;
    onHeaderArrowDownKey(event: any): void;
    onHeaderArrowUpKey(event: any): void;
    onHeaderHomeKey(event: any): void;
    onHeaderEndKey(event: any): void;
    onHeaderEnterKey(event: any, item: any, index: any): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PanelMenu, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PanelMenu, "p-panelMenu, p-panelmenu, p-panel-menu", never, { "model": { "alias": "model"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "transitionOptions": { "alias": "transitionOptions"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; }, {}, ["submenuIconTemplate", "headerIconTemplate", "itemTemplate", "templates"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class PanelMenuModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PanelMenuModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<PanelMenuModule, never, [typeof PanelMenu, typeof i2.SharedModule], [typeof PanelMenu, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<PanelMenuModule>;
}

export { PanelMenu, PanelMenuClasses, PanelMenuList, PanelMenuModule, PanelMenuStyle, PanelMenuSub };
