import { TreePassThrough, TreeNodeSelectEvent, TreeNodeDropEvent, TreeLazyLoadEvent, TreeScrollEvent, TreeFilterEvent, TreeFilterTemplateContext, TreeLoaderTemplateContext, TreeTogglerIconTemplateContext, TreeCheckboxIconTemplateContext } from '@wawjs/ngx-prime/types/tree';
export * from '@wawjs/ngx-prime/types/tree';
import * as _angular_core from '@angular/core';
import { TemplateRef, ElementRef } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { BlockableUI, TreeDragDropService, TreeNode, ScrollerOptions } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Scroller } from '@wawjs/ngx-prime/scroller';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import { Subscription } from 'rxjs';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class TreeStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-tree-selectable': boolean;
            'p-tree-loading': any;
            'p-tree-flex-scrollable': boolean;
            'p-tree-node-dragover': any;
        })[];
        mask: string;
        loadingIcon: string;
        pcFilterInput: string;
        wrapper: string;
        rootChildren: string;
        node: ({ instance }: {
            instance: any;
        }) => {
            'p-tree-node': boolean;
            'p-tree-node-leaf': any;
        };
        nodeContent: ({ instance }: {
            instance: any;
        }) => {
            'p-tree-node-content': boolean;
            'p-tree-node-selectable': any;
            'p-tree-node-dragover': any;
            'p-tree-node-selected': any;
            'p-tree-node-contextmenu-selected': any;
        };
        nodeToggleButton: string;
        nodeToggleIcon: string;
        nodeCheckbox: string;
        nodeIcon: string;
        nodeLabel: string;
        nodeChildren: string;
        emptyMessage: string;
        dropPoint: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TreeStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TreeStyle>;
}
/**
 *
 * Tree is used to display hierarchical data.
 *
 * [Live Demo](https://www.ngx-prime.org/tree/)
 *
 * @module treestyle
 *
 */
declare enum TreeClasses {
    /**
     * Class name of the root element
     */
    root = "p-tree",
    /**
     * Class name of the mask element
     */
    mask = "p-tree-mask",
    /**
     * Class name of the loading icon element
     */
    loadingIcon = "p-tree-loading-icon",
    /**
     * Class name of the filter input element
     */
    pcFilterInput = "p-tree-filter-input",
    /**
     * Class name of the wrapper element
     */
    wrapper = "p-tree-root",
    /**
     * Class name of the root children element
     */
    rootChildren = "p-tree-root-children",
    /**
     * Class name of the node element
     */
    node = "p-tree-node",
    /**
     * Class name of the node content element
     */
    nodeContent = "p-tree-node-content",
    /**
     * Class name of the node toggle button element
     */
    nodeToggleButton = "p-tree-node-toggle-button",
    /**
     * Class name of the node toggle icon element
     */
    nodeToggleIcon = "p-tree-node-toggle-icon",
    /**
     * Class name of the node checkbox element
     */
    nodeCheckbox = "p-tree-node-checkbox",
    /**
     * Class name of the node icon element
     */
    nodeIcon = "p-tree-node-icon",
    /**
     * Class name of the node label element
     */
    nodeLabel = "p-tree-node-label",
    /**
     * Class name of the node children element
     */
    nodeChildren = "p-tree-node-children",
    /**
     * Class name of the empty message element
     */
    emptyMessage = "p-tree-empty-message",
    /**
     * Class name of the drop point element
     */
    dropPoint = "p-tree-node-droppoint"
}

declare class UITreeNode extends BaseComponent<TreePassThrough> {
    $pcTreeNode: UITreeNode | undefined;
    static ICON_CLASS: string;
    readonly rowNode: _angular_core.InputSignal<any>;
    readonly node: _angular_core.InputSignal<TreeNode<any> | undefined>;
    readonly parentNode: _angular_core.InputSignal<TreeNode<any> | undefined>;
    readonly root: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly index: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly firstChild: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly lastChild: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly level: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly indentation: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly itemSize: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly loadingMode: _angular_core.InputSignal<string>;
    tree: Tree;
    timeout: any;
    isPrevDropPointHovered: _angular_core.WritableSignal<boolean>;
    isNextDropPointHovered: _angular_core.WritableSignal<boolean>;
    isNodeDropHovered: _angular_core.WritableSignal<boolean>;
    isPrevDropPointActive: _angular_core.Signal<boolean | undefined>;
    isNextDropPointActive: _angular_core.Signal<boolean | undefined>;
    isNodeDropActive: _angular_core.Signal<boolean | undefined>;
    dropPosition: _angular_core.Signal<1 | -1 | 0>;
    _componentStyle: TreeStyle;
    /**
     * Computed signal that reactively tracks selection state.
     */
    private _selected;
    /**
     * Computed signal that reactively tracks context menu selection state.
     */
    private _contextMenuSelected;
    get selected(): boolean | undefined;
    get checked(): boolean | undefined;
    get nodeClass(): {
        'p-tree-node': boolean;
        'p-tree-node-leaf': any;
    };
    get selectable(): boolean;
    get subNodes(): TreeNode[] | undefined;
    getPTOptions(key: string): any;
    onInit(): void;
    getIcon(): string;
    isLeaf(): boolean;
    isSelected(): boolean;
    isContextMenuSelected(): boolean | "" | undefined;
    isSameNode(event: any): any;
    isDraggable(): boolean | undefined;
    isDroppable(): boolean | undefined;
    isNodeDroppable(): boolean | undefined;
    isNodeDraggable(): boolean | undefined;
    toggle(event: Event): void;
    expand(event: Event): void;
    collapse(event: Event): void;
    onNodeClick(event: MouseEvent): void;
    onNodeKeydown(event: KeyboardEvent): void;
    onNodeTouchEnd(): void;
    onNodeRightClick(event: MouseEvent): void;
    onNodeDblClick(event: MouseEvent): void;
    insertNodeOnDrop(): void;
    onNodeDrop(event: any): void;
    onNodeDragStart(event: any): void;
    onNodeDragOver(event: any): void;
    onNodeDragLeave(): void;
    onNodeDragEnd(event: any): void;
    onKeyDown(event: KeyboardEvent): void;
    onArrowUp(event: KeyboardEvent): void;
    onArrowDown(event: KeyboardEvent): void;
    onArrowRight(event: KeyboardEvent): void;
    onArrowLeft(event: KeyboardEvent): false | undefined;
    onEnter(event: KeyboardEvent): void;
    setAllNodesTabIndexes(): void;
    setTabIndexForSelectionMode(event: any, nodeTouched: any): void;
    findNextSiblingOfAncestor(nodeElement: any): any;
    findLastVisibleDescendant(nodeElement: any): any;
    getParentNodeElement(nodeElement: HTMLElement | Element): HTMLElement | null;
    focusNode(element: any): void;
    focusRowChange(firstFocusableRow: any, currentFocusedRow: any, lastVisibleDescendant?: any): void;
    focusVirtualNode(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UITreeNode, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UITreeNode, "p-tree-node", never, { "rowNode": { "alias": "rowNode"; "required": false; "isSignal": true; }; "node": { "alias": "node"; "required": false; "isSignal": true; }; "parentNode": { "alias": "parentNode"; "required": false; "isSignal": true; }; "root": { "alias": "root"; "required": false; "isSignal": true; }; "index": { "alias": "index"; "required": false; "isSignal": true; }; "firstChild": { "alias": "firstChild"; "required": false; "isSignal": true; }; "lastChild": { "alias": "lastChild"; "required": false; "isSignal": true; }; "level": { "alias": "level"; "required": false; "isSignal": true; }; "indentation": { "alias": "indentation"; "required": false; "isSignal": true; }; "itemSize": { "alias": "itemSize"; "required": false; "isSignal": true; }; "loadingMode": { "alias": "loadingMode"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/**
 * Tree is used to display hierarchical data.
 * @group Components
 */
declare class Tree extends BaseComponent<TreePassThrough> implements BlockableUI {
    dragDropService: TreeDragDropService | null;
    componentName: string;
    bindDirectiveInstance: Bind;
    $pcTree: Tree | undefined;
    onAfterViewChecked(): void;
    /**
     * An array of treenodes.
     * @group Props
     */
    readonly value: _angular_core.InputSignal<any>;
    /**
     * Defines the selection mode.
     * @group Props
     */
    readonly selectionMode: _angular_core.InputSignal<"checkbox" | "single" | "multiple" | null | undefined>;
    /**
     * Loading mode display.
     * @group Props
     */
    readonly loadingMode: _angular_core.InputSignal<"mask" | "icon">;
    /**
     * A single treenode instance or an array to refer to the selections.
     * @group Props
     */
    selection: _angular_core.ModelSignal<TreeNode<any> | TreeNode<any>[] | null | undefined>;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    readonly styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Context menu instance.
     * @group Props
     */
    readonly contextMenu: _angular_core.InputSignal<any>;
    /**
     * Defines the behavior of context menu selection, in "separate" mode context menu updates contextMenuSelection property whereas in joint mode selection property is used instead so that when row selection is enabled, both row selection and context menu selection use the same property.
     * @group Props
     */
    readonly contextMenuSelectionMode: _angular_core.InputSignal<"separate" | "joint">;
    /**
     * Selected node with a context menu.
     * @group Props
     */
    contextMenuSelection: _angular_core.ModelSignal<TreeNode<any> | null>;
    /**
     * Scope of the draggable nodes to match a droppableScope.
     * @group Props
     */
    readonly draggableScope: _angular_core.InputSignal<any>;
    /**
     * Scope of the droppable nodes to match a draggableScope.
     * @group Props
     */
    readonly droppableScope: _angular_core.InputSignal<any>;
    /**
     * Whether the nodes are draggable.
     * @group Props
     */
    readonly draggableNodes: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Whether the nodes are droppable.
     * @group Props
     */
    readonly droppableNodes: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Defines how multiple items can be selected, when true metaKey needs to be pressed to select or unselect an item and when set to false selection of each item can be toggled individually. On touch enabled devices, metaKeySelection is turned off automatically.
     * @group Props
     */
    readonly metaKeySelection: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether checkbox selections propagate to ancestor nodes.
     * @group Props
     */
    readonly propagateSelectionUp: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether checkbox selections propagate to descendant nodes.
     * @group Props
     */
    readonly propagateSelectionDown: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Displays a loader to indicate data load is in progress.
     * @group Props
     */
    readonly loading: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * The icon to show while indicating data load is in progress.
     * @group Props
     */
    readonly loadingIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Text to display when there is no data.
     * @group Props
     */
    readonly emptyMessage: _angular_core.InputSignal<string>;
    /**
     * Used to define a string that labels the tree.
     * @group Props
     */
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the toggler icon for accessibility.
     * @group Props
     */
    readonly togglerAriaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * When enabled, drop can be accepted or rejected based on condition defined at onNodeDrop.
     * @group Props
     */
    readonly validateDrop: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When specified, displays an input field to filter the items.
     * @group Props
     */
    readonly filter: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Determines whether the filter input should be automatically focused when the component is rendered.
     * @group Props
     */
    readonly filterInputAutoFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When filtering is enabled, filterBy decides which field or fields (comma separated) to search against.
     * @group Props
     */
    readonly filterBy: _angular_core.InputSignal<string>;
    /**
     * Mode for filtering valid values are "lenient" and "strict". Default is lenient.
     * @group Props
     */
    readonly filterMode: _angular_core.InputSignal<string>;
    /**
     * Mode for filtering valid values are "lenient" and "strict". Default is lenient.
     * @group Props
     */
    readonly filterOptions: _angular_core.InputSignal<any>;
    /**
     * Placeholder text to show when filter input is empty.
     * @group Props
     */
    readonly filterPlaceholder: _angular_core.InputSignal<string | undefined>;
    /**
     * Values after the tree nodes are filtered.
     * @group Props
     */
    readonly filteredNodes: _angular_core.InputSignal<TreeNode<any>[] | null | undefined>;
    /**
     * Locale to use in filtering. The default locale is the host environment's current locale.
     * @group Props
     */
    readonly filterLocale: _angular_core.InputSignal<string | undefined>;
    /**
     * Height of the scrollable viewport.
     * @group Props
     */
    readonly scrollHeight: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines if data is loaded and interacted with in lazy manner.
     * @group Props
     */
    readonly lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether the data should be loaded on demand during scroll.
     * @group Props
     */
    readonly virtualScroll: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Height of an item in the list for VirtualScrolling.
     * @group Props
     */
    readonly virtualScrollItemSize: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Whether to use the scroller feature. The properties of scroller component can be used like an object in it.
     * @group Props
     */
    readonly virtualScrollOptions: _angular_core.InputSignal<ScrollerOptions | undefined>;
    /**
     * Indentation factor for spacing of the nested node when virtual scrolling is enabled.
     * @group Props
     */
    readonly indentation: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Custom templates of the component.
     * @group Props
     */
    readonly _templateMap: _angular_core.InputSignal<any>;
    /**
     * Function to optimize the node list rendering, default algorithm checks for object identity.
     * @group Props
     */
    readonly trackBy: _angular_core.InputSignal<(...args: any[]) => any>;
    /**
     * Highlights the node on select.
     * @group Props
     */
    readonly highlightOnSelect: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Callback to invoke when a node is selected.
     * @param {TreeNodeSelectEvent} event - Node select event.
     * @group Emits
     */
    onNodeSelect: _angular_core.OutputEmitterRef<TreeNodeSelectEvent>;
    /**
     * Callback to invoke when a node is unselected.
     * @param {TreeNodeUnSelectEvent} event - Node unselect event.
     * @group Emits
     */
    onNodeUnselect: _angular_core.OutputEmitterRef<TreeNodeSelectEvent>;
    /**
     * Callback to invoke when a node is expanded.
     * @param {TreeNodeExpandEvent} event - Node expand event.
     * @group Emits
     */
    onNodeExpand: _angular_core.OutputEmitterRef<TreeNodeSelectEvent>;
    /**
     * Callback to invoke when a node is collapsed.
     * @param {TreeNodeCollapseEvent} event - Node collapse event.
     * @group Emits
     */
    onNodeCollapse: _angular_core.OutputEmitterRef<TreeNodeSelectEvent>;
    /**
     * Callback to invoke when a node is selected with right click.
     * @param {onNodeContextMenuSelect} event - Node context menu select event.
     * @group Emits
     */
    onNodeContextMenuSelect: _angular_core.OutputEmitterRef<TreeNodeSelectEvent>;
    /**
     * Callback to invoke when a node is double clicked.
     * @param {TreeNodeDoubleClickEvent} event - Node double click event.
     * @group Emits
     */
    onNodeDoubleClick: _angular_core.OutputEmitterRef<TreeNodeSelectEvent>;
    /**
     * Callback to invoke when a node is dropped.
     * @param {TreeNodeDropEvent} event - Node drop event.
     * @group Emits
     */
    onNodeDrop: _angular_core.OutputEmitterRef<TreeNodeDropEvent>;
    /**
     * Callback to invoke in lazy mode to load new data.
     * @param {TreeLazyLoadEvent} event - Custom lazy load event.
     * @group Emits
     */
    onLazyLoad: _angular_core.OutputEmitterRef<TreeLazyLoadEvent>;
    /**
     * Callback to invoke in virtual scroll mode when scroll position changes.
     * @param {TreeScrollEvent} event - Custom scroll event.
     * @group Emits
     */
    onScroll: _angular_core.OutputEmitterRef<TreeScrollEvent>;
    /**
     * Callback to invoke in virtual scroll mode when scroll position and item's range in view changes.
     * @param {TreeScrollIndexChangeEvent} event - Scroll index change event.
     * @group Emits
     */
    onScrollIndexChange: _angular_core.OutputEmitterRef<TreeLazyLoadEvent>;
    /**
     * Callback to invoke when data is filtered.
     * @param {TreeFilterEvent} event - Custom filter event.
     * @group Emits
     */
    onFilter: _angular_core.OutputEmitterRef<TreeFilterEvent>;
    /**
     * Custom filter template.
     * @param {TreeFilterTemplateContext} context - filter context.
     * @see {@link TreeFilterTemplateContext}
     * @group Templates
     */
    filterTemplate: TemplateRef<TreeFilterTemplateContext> | undefined;
    /**
     * Custom node template.
     * @group Templates
     */
    readonly nodeTemplate: _angular_core.Signal<TemplateRef<any> | undefined>;
    /**
     * Custom header template.
     * @group Templates
     */
    readonly headerTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom footer template.
     * @group Templates
     */
    readonly footerTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom loader template.
     * @param {TreeLoaderTemplateContext} context - loader context.
     * @see {@link TreeLoaderTemplateContext}
     * @group Templates
     */
    loaderTemplate: TemplateRef<TreeLoaderTemplateContext> | undefined;
    /**
     * Custom empty message template.
     * @group Templates
     */
    readonly emptyTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom toggler icon template.
     * @param {TreeTogglerIconTemplateContext} context - toggler icon context.
     * @see {@link TreeTogglerIconTemplateContext}
     * @group Templates
     */
    togglerIconTemplate: TemplateRef<TreeTogglerIconTemplateContext> | undefined;
    /**
     * Custom checkbox icon template.
     * @param {TreeCheckboxIconTemplateContext} context - checkbox icon context.
     * @see {@link TreeCheckboxIconTemplateContext}
     * @group Templates
     */
    checkboxIconTemplate: TemplateRef<TreeCheckboxIconTemplateContext> | undefined;
    /**
     * Custom loading icon template.
     * @group Templates
     */
    loadingIconTemplate: TemplateRef<void> | undefined;
    /**
     * Custom filter icon template.
     * @group Templates
     */
    filterIconTemplate: TemplateRef<void> | undefined;
    readonly filterViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly scroller: _angular_core.Signal<Nullable<Scroller>>;
    readonly wrapperViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly contentViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    private readonly templates;
    _headerTemplate: TemplateRef<void> | undefined;
    _emptyTemplate: TemplateRef<void> | undefined;
    _footerTemplate: TemplateRef<void> | undefined;
    _loaderTemplate: TemplateRef<TreeLoaderTemplateContext> | undefined;
    _togglerIconTemplate: TemplateRef<TreeTogglerIconTemplateContext> | undefined;
    _checkboxIconTemplate: TemplateRef<TreeCheckboxIconTemplateContext> | undefined;
    _loadingIconTemplate: TemplateRef<void> | undefined;
    _filterIconTemplate: TemplateRef<void> | undefined;
    _filterTemplate: TemplateRef<TreeFilterTemplateContext> | undefined;
    onAfterContentInit(): void;
    serializedValue: Nullable<TreeNode<any>[]>;
    nodeTouched: boolean | undefined | null;
    dragNodeTree: Tree | undefined | null;
    dragNode: TreeNode<any> | undefined | null;
    dragNodeSubNodes: TreeNode<any>[] | undefined | null;
    dragNodeIndex: number | undefined | null;
    dragNodeScope: any;
    dragHover: boolean | undefined | null;
    dragStartSubscription: Subscription | undefined | null;
    dragStopSubscription: Subscription | undefined | null;
    _componentStyle: TreeStyle;
    handleDropEvent(event: DragEvent): void;
    handleDragOverEvent(event: DragEvent): void;
    handleDragEnterEvent(): void;
    handleDragLeaveEvent(event: DragEvent): void;
    _templateMapBacking: any;
    _filterOptionsBacking: any;
    _filteredNodesBacking: TreeNode<any>[] | null | undefined;
    _valueBacking: TreeNode<any> | TreeNode<any>[] | any[] | any;
    constructor();
    onInit(): void;
    get emptyMessageLabel(): string;
    updateSerializedValue(): void;
    serializeNodes(parent: TreeNode<any> | null, nodes: TreeNode<any>[] | any, level: number, visible: boolean): void;
    onNodeClick(event: Event, node: TreeNode): void;
    onNodeTouchEnd(): void;
    onNodeRightClick(event: MouseEvent, node: TreeNode<any>): void;
    onNodeDblClick(event: MouseEvent, node: TreeNode<any>): void;
    findIndexInSelection(node: TreeNode): number;
    syncNodeOption(node: TreeNode, parentNodes: TreeNode<any>[], option: any, value?: any): void;
    hasFilteredNodes(): number | false | null | undefined;
    hasFilterActive(): boolean | undefined;
    getNodeWithKey(key: string, nodes: TreeNode<any>[]): TreeNode<any> | undefined;
    propagateUp(node: TreeNode, select: boolean): void;
    propagateDown(node: TreeNode, select: boolean): void;
    isSelected(node: TreeNode): boolean;
    isSingleSelectionMode(): boolean | null | undefined;
    isMultipleSelectionMode(): boolean | null | undefined;
    isCheckboxSelectionMode(): boolean | null | undefined;
    isNodeLeaf(node: TreeNode): boolean;
    getRootNode(): any;
    getTemplateForNode(node: TreeNode): TemplateRef<any> | null;
    onDragOver(event: DragEvent): void;
    onDrop(event: DragEvent): void;
    processTreeDrop(dragNode: TreeNode, dragNodeIndex: number): void;
    onDragEnter(): void;
    onDragLeave(event: DragEvent): void;
    allowDrop(dragNode: TreeNode, dropNode: TreeNode<any> | null, dragNodeScope: any): boolean;
    hasCommonScope(dragScope: any, dropScope: any): boolean;
    isSameTreeScope(dragScope: any): boolean;
    isValidDragScope(dragScope: any): boolean;
    _filter(value: string): void;
    /**
     * Resets filter.
     * @group Method
     */
    resetFilter(): void;
    /**
     * Scrolls to virtual index.
     * @param {number} number - Index to be scrolled.
     * @group Method
     */
    scrollToVirtualIndex(index: number): void;
    /**
     * Scrolls to virtual index.
     * @param {ScrollToOptions} options - Scroll options.
     * @group Method
     */
    scrollTo(options: any): void;
    findFilteredNodes(node: TreeNode, paramsWithoutNode: any): true | undefined;
    isFilterMatched(node: TreeNode, params: any): boolean;
    getIndex(options: any, index: number): any;
    getBlockableElement(): HTMLElement;
    onDestroy(): void;
    get containerDataP(): string | undefined;
    get wrapperDataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Tree, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Tree, "p-tree", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "selectionMode": { "alias": "selectionMode"; "required": false; "isSignal": true; }; "loadingMode": { "alias": "loadingMode"; "required": false; "isSignal": true; }; "selection": { "alias": "selection"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "contextMenu": { "alias": "contextMenu"; "required": false; "isSignal": true; }; "contextMenuSelectionMode": { "alias": "contextMenuSelectionMode"; "required": false; "isSignal": true; }; "contextMenuSelection": { "alias": "contextMenuSelection"; "required": false; "isSignal": true; }; "draggableScope": { "alias": "draggableScope"; "required": false; "isSignal": true; }; "droppableScope": { "alias": "droppableScope"; "required": false; "isSignal": true; }; "draggableNodes": { "alias": "draggableNodes"; "required": false; "isSignal": true; }; "droppableNodes": { "alias": "droppableNodes"; "required": false; "isSignal": true; }; "metaKeySelection": { "alias": "metaKeySelection"; "required": false; "isSignal": true; }; "propagateSelectionUp": { "alias": "propagateSelectionUp"; "required": false; "isSignal": true; }; "propagateSelectionDown": { "alias": "propagateSelectionDown"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "loadingIcon": { "alias": "loadingIcon"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "togglerAriaLabel": { "alias": "togglerAriaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "validateDrop": { "alias": "validateDrop"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "filterInputAutoFocus": { "alias": "filterInputAutoFocus"; "required": false; "isSignal": true; }; "filterBy": { "alias": "filterBy"; "required": false; "isSignal": true; }; "filterMode": { "alias": "filterMode"; "required": false; "isSignal": true; }; "filterOptions": { "alias": "filterOptions"; "required": false; "isSignal": true; }; "filterPlaceholder": { "alias": "filterPlaceholder"; "required": false; "isSignal": true; }; "filteredNodes": { "alias": "filteredNodes"; "required": false; "isSignal": true; }; "filterLocale": { "alias": "filterLocale"; "required": false; "isSignal": true; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "virtualScroll": { "alias": "virtualScroll"; "required": false; "isSignal": true; }; "virtualScrollItemSize": { "alias": "virtualScrollItemSize"; "required": false; "isSignal": true; }; "virtualScrollOptions": { "alias": "virtualScrollOptions"; "required": false; "isSignal": true; }; "indentation": { "alias": "indentation"; "required": false; "isSignal": true; }; "_templateMap": { "alias": "_templateMap"; "required": false; "isSignal": true; }; "trackBy": { "alias": "trackBy"; "required": false; "isSignal": true; }; "highlightOnSelect": { "alias": "highlightOnSelect"; "required": false; "isSignal": true; }; }, { "selection": "selectionChange"; "contextMenuSelection": "contextMenuSelectionChange"; "onNodeSelect": "onNodeSelect"; "onNodeUnselect": "onNodeUnselect"; "onNodeExpand": "onNodeExpand"; "onNodeCollapse": "onNodeCollapse"; "onNodeContextMenuSelect": "onNodeContextMenuSelect"; "onNodeDoubleClick": "onNodeDoubleClick"; "onNodeDrop": "onNodeDrop"; "onLazyLoad": "onLazyLoad"; "onScroll": "onScroll"; "onScrollIndexChange": "onScrollIndexChange"; "onFilter": "onFilter"; }, ["nodeTemplate", "headerTemplate", "footerTemplate", "emptyTemplate", "templates", "filterTemplate", "loaderTemplate", "togglerIconTemplate", "checkboxIconTemplate", "loadingIconTemplate", "filterIconTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class TreeModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TreeModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<TreeModule, never, [typeof Tree, typeof i2.SharedModule], [typeof Tree, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<TreeModule>;
}

export { Tree, TreeClasses, TreeModule, TreeStyle, UITreeNode };
