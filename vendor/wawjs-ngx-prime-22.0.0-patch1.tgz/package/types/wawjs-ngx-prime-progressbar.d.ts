import { ProgressBarPassThrough, ProgressBarContentTemplateContext } from '@wawjs/ngx-prime/types/progressbar';
export * from '@wawjs/ngx-prime/types/progressbar';
import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class ProgressBarStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-progressbar-determinate': boolean;
            'p-progressbar-indeterminate': boolean;
        })[];
        value: string;
        label: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ProgressBarStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ProgressBarStyle>;
}
/**
 *
 * ProgressBar is a process status indicator.
 *
 * [Live Demo](https://www.ngx-prime.org/progressbar)
 *
 * @module progressbarstyle
 *
 */
declare enum ProgressBarClasses {
    /**
     * Class name of the root element
     */
    root = "p-progressbar",
    /**
     * Class name of the value element
     */
    value = "p-progressbar-value",
    /**
     * Class name of the label element
     */
    label = "p-progressbar-label"
}

/**
 * ProgressBar is a process status indicator.
 * @group Components
 */
declare class ProgressBar extends BaseComponent<ProgressBarPassThrough> {
    componentName: string;
    $pcProgressBar: ProgressBar | undefined;
    bindDirectiveInstance: Bind;
    /**
     * Current value of the progress.
     * @group Props
     */
    value: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Whether to display the progress bar value.
     * @group Props
     */
    showValue: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Style class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the value element.
     * @group Props
     */
    valueStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Unit sign appended to the value.
     * @group Props
     */
    unit: _angular_core.InputSignal<string>;
    /**
     * Defines the mode of the progress
     * @defaultValue 'determinate'
     * @group Props
     */
    mode: _angular_core.InputSignal<"determinate" | "indeterminate">;
    /**
     * Color for the background of the progress.
     * @group Props
     */
    color: _angular_core.InputSignal<string | undefined>;
    /**
     * Template of the content.
     * @param {ProgressBarContentTemplateContext} context - content context.
     * @see {@link ProgressBarContentTemplateContext}
     * @group Templates
     */
    readonly contentTemplate: _angular_core.Signal<TemplateRef<ProgressBarContentTemplateContext> | undefined>;
    onAfterViewChecked(): void;
    _componentStyle: ProgressBarStyle;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _contentTemplate: TemplateRef<ProgressBarContentTemplateContext> | undefined;
    onAfterContentInit(): void;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ProgressBar, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ProgressBar, "p-progressBar, p-progressbar, p-progress-bar", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "showValue": { "alias": "showValue"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "valueStyleClass": { "alias": "valueStyleClass"; "required": false; "isSignal": true; }; "unit": { "alias": "unit"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; }, {}, ["contentTemplate", "templates"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class ProgressBarModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ProgressBarModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<ProgressBarModule, never, [typeof ProgressBar, typeof i2.SharedModule], [typeof ProgressBar, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<ProgressBarModule>;
}

export { ProgressBar, ProgressBarClasses, ProgressBarModule, ProgressBarStyle };
