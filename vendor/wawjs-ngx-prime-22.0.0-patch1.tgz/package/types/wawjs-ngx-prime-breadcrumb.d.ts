import { BreadcrumbPassThrough, BreadcrumbItemClickEvent, BreadcrumbItemTemplateContext } from '@wawjs/ngx-prime/types/breadcrumb';
export * from '@wawjs/ngx-prime/types/breadcrumb';
import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import * as i2 from '@wawjs/ngx-prime/api';
import { MenuItem, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class BreadCrumbStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: () => string[];
        list: string;
        homeItem: string;
        separator: string;
        item: ({ menuitem }: {
            menuitem: any;
        }) => (string | {
            'p-disabled': any;
        })[];
        itemLink: string;
        itemIcon: string;
        itemLabel: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BreadCrumbStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<BreadCrumbStyle>;
}
/**
 *
 * Breadcrumb provides contextual information about page hierarchy.
 *
 * [Live Demo](https://www.ngx-prime.org/breadcrumb/)
 *
 * @module breadcrumbstyle
 *
 */
declare enum BreadcrumbClasses {
    /**
     * Class name of the root element
     */
    root = "p-breadcrumb",
    /**
     * Class name of the list element
     */
    list = "p-breadcrumb-list",
    /**
     * Class name of the home item element
     */
    homeItem = "p-breadcrumb-home-item",
    /**
     * Class name of the separator element
     */
    separator = "p-breadcrumb-separator",
    /**
     * Class name of the item element
     */
    item = "p-breadcrumb-item",
    /**
     * Class name of the item link element
     */
    itemLink = "p-breadcrumb-item-link",
    /**
     * Class name of the item icon element
     */
    itemIcon = "p-breadcrumb-item-icon",
    /**
     * Class name of the item label element
     */
    itemLabel = "p-breadcrumb-item-label"
}
type BreadcrumbStyle = BaseStyle;

/**
 * Breadcrumb provides contextual information about page hierarchy.
 * @group Components
 */
declare class Breadcrumb extends BaseComponent<BreadcrumbPassThrough> {
    componentName: string;
    bindDirectiveInstance: Bind;
    /**
     * An array of menuitems.
     * @group Props
     */
    model: _angular_core.InputSignal<MenuItem[] | undefined>;
    /**
     * Inline style of the component.
     * @group Props
     */
    style: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the component.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * MenuItem configuration for the home icon.
     * @group Props
     */
    home: _angular_core.InputSignal<MenuItem | undefined>;
    /**
     * Defines a string that labels the home icon for accessibility.
     * @group Props
     */
    homeAriaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Fired when an item is selected.
     * @param {BreadcrumbItemClickEvent} event - custom click event.
     * @group Emits
     */
    onItemClick: _angular_core.OutputEmitterRef<BreadcrumbItemClickEvent>;
    _componentStyle: BreadCrumbStyle;
    router: Router;
    onClick(event: MouseEvent, item: MenuItem): void;
    /**
     * Custom item template.
     * @group Templates
     */
    itemTemplate: TemplateRef<BreadcrumbItemTemplateContext> | undefined;
    /**
     * Custom separator template.
     * @group Templates
     */
    readonly separatorTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _separatorTemplate: TemplateRef<void> | undefined;
    _itemTemplate: TemplateRef<BreadcrumbItemTemplateContext> | undefined;
    onAfterContentInit(): void;
    onAfterViewChecked(): void;
    getPTOptions(item: MenuItem, index: number, key: string): any;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Breadcrumb, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Breadcrumb, "p-breadcrumb", never, { "model": { "alias": "model"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "home": { "alias": "home"; "required": false; "isSignal": true; }; "homeAriaLabel": { "alias": "homeAriaLabel"; "required": false; "isSignal": true; }; }, { "onItemClick": "onItemClick"; }, ["separatorTemplate", "templates", "itemTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class BreadcrumbModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BreadcrumbModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<BreadcrumbModule, never, [typeof Breadcrumb, typeof i2.SharedModule], [typeof Breadcrumb, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<BreadcrumbModule>;
}

export { BreadCrumbStyle, Breadcrumb, BreadcrumbClasses, BreadcrumbModule };
export type { BreadcrumbStyle };
