import * as i0 from '@angular/core';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { ProgressSpinnerPassThrough } from '@wawjs/ngx-prime/types/progressspinner';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i2 from '@wawjs/ngx-prime/api';

declare class ProgressSpinnerStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: () => string[];
        spin: string;
        circle: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressSpinnerStyle, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProgressSpinnerStyle>;
}
/**
 *
 * ProgressSpinner is a process status indicator.
 *
 * [Live Demo](https://www.ngx-prime.org/progressspinner)
 *
 * @module progressspinnerstyle
 *
 */
declare enum ProgressSpinnerClasses {
    /**
     * Class name of the root element
     */
    root = "p-progressspinner",
    /**
     * Class name of the spin element
     */
    spin = "p-progressspinner-spin",
    /**
     * Class name of the circle element
     */
    circle = "p-progressspinner-circle"
}

/**
 * ProgressSpinner is a process status indicator.
 * @group Components
 */
declare class ProgressSpinner extends BaseComponent<ProgressSpinnerPassThrough> {
    componentName: string;
    $pcProgressSpinner: ProgressSpinner | undefined;
    bindDirectiveInstance: Bind;
    /**
     * Class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: i0.InputSignal<string | undefined>;
    /**
     * Width of the circle stroke.
     * @group Props
     */
    strokeWidth: i0.InputSignal<string>;
    /**
     * Color for the background of the circle.
     * @group Props
     */
    fill: i0.InputSignal<string>;
    /**
     * Duration of the rotate animation.
     * @group Props
     */
    animationDuration: i0.InputSignal<string>;
    /**
     * Used to define a aria label attribute the current element.
     * @group Props
     */
    ariaLabel: i0.InputSignal<string | undefined>;
    onAfterViewChecked(): void;
    _componentStyle: ProgressSpinnerStyle;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressSpinner, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ProgressSpinner, "p-progressSpinner, p-progress-spinner, p-progressspinner", never, { "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "strokeWidth": { "alias": "strokeWidth"; "required": false; "isSignal": true; }; "fill": { "alias": "fill"; "required": false; "isSignal": true; }; "animationDuration": { "alias": "animationDuration"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class ProgressSpinnerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ProgressSpinnerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ProgressSpinnerModule, never, [typeof ProgressSpinner, typeof i2.SharedModule], [typeof ProgressSpinner, typeof i2.SharedModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ProgressSpinnerModule>;
}

export { ProgressSpinner, ProgressSpinnerClasses, ProgressSpinnerModule, ProgressSpinnerStyle };
