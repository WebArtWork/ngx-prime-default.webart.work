import { SplitterPassThrough, SplitterResizeStartEvent } from '@wawjs/ngx-prime/types/splitter';
export * from '@wawjs/ngx-prime/types/splitter';
import * as _angular_core from '@angular/core';
import { ElementRef } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { VoidListener, Nullable } from '@wawjs/ngx-prime/ts-helpers';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class SplitterStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => string[];
        panel: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-splitterpanel-nested': any;
        })[];
        gutter: string;
        gutterHandle: string;
    };
    inlineStyles: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            display: string;
            'flex-wrap': string;
            'flex-direction'?: undefined;
        } | {
            'flex-direction': string;
            display?: undefined;
            'flex-wrap'?: undefined;
        })[];
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SplitterStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SplitterStyle>;
}
/**
 *
 * Splitter is utilized to separate and resize panels.
 *
 * [Live Demo](https://www.ngx-prime.org/splitter/)
 *
 * @module splitterstyle
 *
 */
declare enum SplitterClasses {
    /**
     * Class name of the root element
     */
    root = "p-splitter",
    /**
     * Class name of the gutter element
     */
    gutter = "p-splitter-gutter",
    /**
     * Class name of the gutter handle element
     */
    gutterHandle = "p-splitter-gutter-handle"
}

/**
 * Splitter is utilized to separate and resize panels.
 * @group Components
 */
declare class Splitter extends BaseComponent<SplitterPassThrough> {
    componentName: string;
    $pcSplitter: Splitter | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Style class of the component.
     * @deprecated since v20. Use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the panel.
     * @group Props
     */
    panelStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the panel.
     * @group Props
     */
    panelStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Defines where a stateful splitter keeps its state, valid values are 'session' for sessionStorage and 'local' for localStorage.
     * @group Props
     */
    stateStorage: _angular_core.InputSignal<string | undefined>;
    /**
     * Storage identifier of a stateful Splitter.
     * @group Props
     */
    stateKey: _angular_core.InputSignal<string | null | undefined>;
    /**
     * Orientation of the panels. Valid values are 'horizontal' and 'vertical'.
     * @group Props
     */
    layout: _angular_core.InputSignal<string | undefined>;
    /**
     * Size of the divider in pixels.
     * @group Props
     */
    gutterSize: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Step factor to increment/decrement the size of the panels while pressing the arrow keys.
     * @group Props
     */
    step: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Minimum size of the elements relative to 100%.
     * @group Props
     */
    minSizes: _angular_core.InputSignal<number[]>;
    /**
     * Size of the elements relative to 100%.
     * @group Props
     */
    panelSizes: _angular_core.InputSignal<number[]>;
    /**
     * Callback to invoke when resize ends.
     * @param {SplitterResizeEndEvent} event - Custom panel resize end event
     * @group Emits
     */
    onResizeEnd: _angular_core.OutputEmitterRef<SplitterResizeStartEvent>;
    /**
     * Callback to invoke when resize starts.
     * @param {SplitterResizeStartEvent} event - Custom panel resize start event
     * @group Emits
     */
    onResizeStart: _angular_core.OutputEmitterRef<SplitterResizeStartEvent>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    readonly panelChildren: _angular_core.Signal<readonly ElementRef<any>[]>;
    splitter: _angular_core.Signal<any>;
    nestedState: _angular_core.Signal<any>;
    panels: any[];
    dragging: boolean;
    mouseMoveListener: VoidListener;
    mouseUpListener: VoidListener;
    touchMoveListener: VoidListener;
    touchEndListener: VoidListener;
    size: Nullable<number>;
    gutterElement: Nullable<ElementRef | HTMLElement>;
    startPos: Nullable<number>;
    prevPanelElement: Nullable<ElementRef | HTMLElement>;
    nextPanelElement: Nullable<ElementRef | HTMLElement>;
    nextPanelSize: Nullable<number>;
    prevPanelSize: Nullable<number>;
    _panelSizes: number[];
    prevPanelIndex: Nullable<number>;
    timer: any;
    prevSize: any;
    _componentStyle: SplitterStyle;
    constructor();
    onAfterContentInit(): void;
    onAfterViewInit(): void;
    resizeStart(event: TouchEvent | MouseEvent, index: number, isKeyDown?: boolean): void;
    onResize(event: MouseEvent, step?: number, isKeyDown?: boolean): void;
    resizeEnd(event: MouseEvent | TouchEvent): void;
    onGutterMouseDown(event: MouseEvent, index: number): void;
    onGutterTouchStart(event: TouchEvent, index: number): void;
    onGutterTouchMove(event: any): void;
    onGutterTouchEnd(event: TouchEvent): void;
    repeat(event: any, index: any, step: any): void;
    setTimer(event: any, index: any, step: any): void;
    clearTimer(): void;
    onGutterKeyUp(event: any): void;
    onGutterKeyDown(event: any, index: any): void;
    validateResize(newPrevPanelSize: number, newNextPanelSize: number): boolean;
    bindMouseListeners(): void;
    bindTouchListeners(): void;
    unbindMouseListeners(): void;
    unbindTouchListeners(): void;
    clear(): void;
    isStateful(): boolean;
    getStorage(): Storage | undefined;
    saveState(): void;
    restoreState(): boolean;
    gutterStyle(): {
        width: string;
        height?: undefined;
    } | {
        height: string;
        width?: undefined;
    };
    horizontal(): boolean;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Splitter, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Splitter, "p-splitter", never, { "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "panelStyleClass": { "alias": "panelStyleClass"; "required": false; "isSignal": true; }; "panelStyle": { "alias": "panelStyle"; "required": false; "isSignal": true; }; "stateStorage": { "alias": "stateStorage"; "required": false; "isSignal": true; }; "stateKey": { "alias": "stateKey"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; "gutterSize": { "alias": "gutterSize"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "minSizes": { "alias": "minSizes"; "required": false; "isSignal": true; }; "panelSizes": { "alias": "panelSizes"; "required": false; "isSignal": true; }; }, { "onResizeEnd": "onResizeEnd"; "onResizeStart": "onResizeStart"; }, ["templates", "panelChildren", "splitter"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class SplitterModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SplitterModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<SplitterModule, never, [typeof Splitter, typeof i2.SharedModule, typeof i1.BindModule], [typeof Splitter, typeof i2.SharedModule, typeof i1.BindModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<SplitterModule>;
}

export { Splitter, SplitterClasses, SplitterModule, SplitterStyle };
