import { TimelinePassThrough, TimelineItemTemplateContext } from '@wawjs/ngx-prime/types/timeline';
export * from '@wawjs/ngx-prime/types/timeline';
import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { BlockableUI, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class TimelineStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => string[];
        event: string;
        eventOpposite: string;
        eventSeparator: string;
        eventMarker: string;
        eventConnector: string;
        eventContent: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TimelineStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TimelineStyle>;
}
/**
 *
 * Timeline visualizes a series of chained events.
 *
 * [Live Demo](https://ngx-prime.org/timeline)
 *
 * @module timelinestyle
 *
 */
declare enum TimelineClasses {
    /**
     * Class name of the root element
     */
    root = "p-timeline",
    /**
     * Class name of the event element
     */
    event = "p-timeline-event",
    /**
     * Class name of the event opposite element
     */
    eventOpposite = "p-timeline-event-opposite",
    /**
     * Class name of the event separator element
     */
    eventSeparator = "p-timeline-event-separator",
    /**
     * Class name of the event marker element
     */
    eventMarker = "p-timeline-event-marker",
    /**
     * Class name of the event connector element
     */
    eventConnector = "p-timeline-event-connector",
    /**
     * Class name of the event content element
     */
    eventContent = "p-timeline-event-content"
}

/**
 * Timeline visualizes a series of chained events.
 * @group Components
 */
declare class Timeline extends BaseComponent<TimelinePassThrough> implements BlockableUI {
    componentName: string;
    bindDirectiveInstance: Bind;
    $pcTimeline: Timeline | undefined;
    onAfterViewChecked(): void;
    /**
     * An array of events to display.
     * @group Props
     */
    value: _angular_core.InputSignal<any[] | undefined>;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Position of the timeline bar relative to the content. Valid values are "left", "right" for vertical layout and "top", "bottom" for horizontal layout.
     * @group Props
     */
    align: _angular_core.InputSignal<string>;
    /**
     * Orientation of the timeline.
     * @group Props
     */
    layout: _angular_core.InputSignal<"vertical" | "horizontal">;
    /**
     * Custom content template.
     * @param {TimelineItemTemplateContext} context - item context.
     * @see {@link TimelineItemTemplateContext}
     * @group Templates
     */
    readonly contentTemplate: _angular_core.Signal<Nullable<TemplateRef<TimelineItemTemplateContext<any>>>>;
    /**
     * Custom opposite item template.
     * @param {TimelineItemTemplateContext} context - item context.
     * @see {@link TimelineItemTemplateContext}
     * @group Templates
     */
    readonly oppositeTemplate: _angular_core.Signal<Nullable<TemplateRef<TimelineItemTemplateContext<any>>>>;
    /**
     * Custom marker template.
     * @param {TimelineItemTemplateContext} context - item context.
     * @see {@link TimelineItemTemplateContext}
     * @group Templates
     */
    markerTemplate: Nullable<TemplateRef<TimelineItemTemplateContext>>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _contentTemplate: TemplateRef<TimelineItemTemplateContext> | undefined;
    _oppositeTemplate: TemplateRef<TimelineItemTemplateContext> | undefined;
    _markerTemplate: TemplateRef<TimelineItemTemplateContext> | undefined;
    _componentStyle: TimelineStyle;
    getBlockableElement(): HTMLElement;
    onAfterContentInit(): void;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Timeline, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Timeline, "p-timeline", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "align": { "alias": "align"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; }, {}, ["contentTemplate", "oppositeTemplate", "templates", "markerTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class TimelineModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TimelineModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<TimelineModule, never, [typeof Timeline, typeof i2.SharedModule], [typeof Timeline, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<TimelineModule>;
}

export { Timeline, TimelineClasses, TimelineModule, TimelineStyle };
