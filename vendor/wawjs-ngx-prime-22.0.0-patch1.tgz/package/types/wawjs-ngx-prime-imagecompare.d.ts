import * as i0 from '@angular/core';
import { TemplateRef, QueryList } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { ImageComparePassThrough } from '@wawjs/ngx-prime/types/imagecompare';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class ImageCompareStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: string;
        slider: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageCompareStyle, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ImageCompareStyle>;
}
/**
 *
 * ImageCompare compares two images side by side with a slider.
 *
 * [Live Demo](https://www.ngx-prime.org/imagecompare/)
 *
 * @module imagecomparestyle
 *
 */
declare enum ImageCompareClasses {
    /**
     * Class name of the root element
     */
    root = "p-imagecompare",
    /**
     * Class name of the slider element
     */
    slider = "p-imagecompare-slider"
}

/**
 * Compare two images side by side with a slider.
 * @group Components
 */
declare class ImageCompare extends BaseComponent<ImageComparePassThrough> {
    componentName: string;
    $pcImageCompare: ImageCompare | undefined;
    bindDirectiveInstance: Bind;
    /**
     * Index of the element in tabbing order.
     * @defaultValue 0
     * @group Props
     */
    tabindex: i0.InputSignal<number | undefined>;
    /**
     * Defines a string value that labels an interactive element.
     * @group Props
     */
    ariaLabelledby: i0.InputSignal<string | undefined>;
    /**
     * Identifier of the underlying input element.
     * @group Props
     */
    ariaLabel: i0.InputSignal<string | undefined>;
    /**
     * Custom left side template.
     * @group Templates
     */
    readonly leftTemplate: i0.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom right side template.
     * @group Templates
     */
    readonly rightTemplate: i0.Signal<TemplateRef<void> | undefined>;
    _leftTemplate: TemplateRef<void> | undefined;
    _rightTemplate: TemplateRef<void> | undefined;
    templates: QueryList<PrimeTemplate> | undefined;
    _componentStyle: ImageCompareStyle;
    mutationObserver: MutationObserver;
    isRTL: boolean;
    onAfterViewChecked(): void;
    onInit(): void;
    onAfterContentInit(): void;
    onSlide(event: any): void;
    updateDirection(): void;
    observeDirectionChanges(): void;
    onDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageCompare, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ImageCompare, "p-imageCompare, p-imagecompare, p-image-compare", never, { "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "ariaLabelledby": { "alias": "ariaLabelledby"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, ["leftTemplate", "rightTemplate", "templates"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class ImageCompareModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ImageCompareModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ImageCompareModule, never, [typeof ImageCompare, typeof i2.SharedModule], [typeof ImageCompare, typeof i2.SharedModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ImageCompareModule>;
}

export { ImageCompare, ImageCompareClasses, ImageCompareModule, ImageCompareStyle };
