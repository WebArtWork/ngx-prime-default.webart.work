import * as _angular_core from '@angular/core';
import { ElementRef } from '@angular/core';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { ChartPassThrough } from '@wawjs/ngx-prime/types/chart';
import * as i2 from '@wawjs/ngx-prime/api';

declare class ChartStyle extends BaseStyle {
    name: string;
    classes: {
        root: string;
    };
    inlineStyles: {
        root: ({ instance }: {
            instance: any;
        }) => {
            display: string;
            position: string;
            width: any;
            height: any;
        };
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChartStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ChartStyle>;
}
/**
 *
 * Chart groups a collection of contents in tabs.
 *
 * [Live Demo](https://www.ngx-prime.org/chart/)
 *
 * @module chartstyle
 *
 */
declare enum ChartClasses {
    /**
     * Class name of the root element
     */
    root = "p-chart"
}

/**
 * Chart groups a collection of contents in tabs.
 * @group Components
 */
declare class UIChart extends BaseComponent<ChartPassThrough> {
    el: ElementRef<any>;
    private zone;
    componentName: string;
    $pcChart: UIChart | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Type of the chart.
     * @group Props
     */
    type: _angular_core.InputSignal<"bar" | "line" | "scatter" | "bubble" | "pie" | "doughnut" | "polarArea" | "radar" | undefined>;
    /**
     * Array of per-chart plugins to customize the chart behaviour.
     * @group Props
     */
    plugins: _angular_core.InputSignal<any[]>;
    /**
     * Width of the chart.
     * @group Props
     */
    width: _angular_core.InputSignal<string | undefined>;
    /**
     * Height of the chart.
     * @group Props
     */
    height: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether the chart is redrawn on screen size change.
     * @group Props
     */
    responsive: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Used to define a string that autocomplete attribute the current element.
     * @group Props
     */
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Data to display.
     * @group Props
     */
    data: _angular_core.InputSignal<any>;
    /**
     * Options to customize the chart.
     * @group Props
     */
    options: _angular_core.InputSignal<any>;
    /**
     * Callback to execute when an element on chart is clicked.
     * @group Emits
     */
    onDataSelect: _angular_core.OutputEmitterRef<any>;
    isBrowser: boolean;
    initialized: boolean | undefined;
    chart: any;
    _componentStyle: ChartStyle;
    constructor();
    onAfterViewInit(): void;
    onCanvasClick(event: Event): void;
    initChart(): void;
    getCanvas(): any;
    getBase64Image(): any;
    generateLegend(): any;
    refresh(): void;
    reinit(): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UIChart, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UIChart, "p-chart", never, { "type": { "alias": "type"; "required": false; "isSignal": true; }; "plugins": { "alias": "plugins"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "responsive": { "alias": "responsive"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "data": { "alias": "data"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; }, { "onDataSelect": "onDataSelect"; }, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class ChartModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChartModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<ChartModule, never, [typeof UIChart, typeof i2.SharedModule], [typeof UIChart, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<ChartModule>;
}

export { ChartClasses, ChartModule, ChartStyle, UIChart };
