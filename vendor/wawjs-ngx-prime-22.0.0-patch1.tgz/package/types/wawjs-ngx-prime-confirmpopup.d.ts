import { ConfirmPopupPassThrough, ConfirmPopupContentTemplateContext, ConfirmPopupHeadlessTemplateContext } from '@wawjs/ngx-prime/types/confirmpopup';
export * from '@wawjs/ngx-prime/types/confirmpopup';
import * as _angular_core from '@angular/core';
import { ElementRef, Renderer2, ChangeDetectorRef, TemplateRef } from '@angular/core';
import { MotionOptions, MotionEvent } from '@wawjs/css-prime-motion';
import * as i2 from '@wawjs/ngx-prime/api';
import { OverlayService, Confirmation, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { ConnectedOverlayScrollHandler } from '@wawjs/ngx-prime/dom';
import { Nullable, VoidListener } from '@wawjs/ngx-prime/ts-helpers';
import { Subscription } from 'rxjs';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class ConfirmPopupStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: () => string[];
        content: string;
        icon: ({ instance }: {
            instance: any;
        }) => any[];
        message: string;
        footer: string;
        pcRejectButton: string;
        pcAcceptButton: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ConfirmPopupStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ConfirmPopupStyle>;
}
/**
 *
 * ConfirmPopup displays a confirmation overlay displayed relatively to its target.
 *
 * [Live Demo](https://www.ngx-prime.org/confirmpopup)
 *
 * @module confirmpopupstyle
 *
 */
declare enum ConfirmPopupClasses {
    /**
     * Class name of the root element
     */
    root = "p-confirmpopup",
    /**
     * Class name of the content element
     */
    content = "p-confirmpopup-content",
    /**
     * Class name of the icon element
     */
    icon = "p-confirmpopup-icon",
    /**
     * Class name of the message element
     */
    message = "p-confirmpopup-message",
    /**
     * Class name of the footer element
     */
    footer = "p-confirmpopup-footer",
    /**
     * Class name of the reject button element
     */
    pcRejectButton = "p-confirmpopup-reject-button",
    /**
     * Class name of the accept button element
     */
    pcAcceptButton = "p-confirmpopup-accept-button"
}

/**
 * ConfirmPopup displays a confirmation overlay displayed relatively to its target.
 * @group Components
 */
declare class ConfirmPopup extends BaseComponent<ConfirmPopupPassThrough> {
    el: ElementRef<any>;
    private confirmationService;
    renderer: Renderer2;
    cd: ChangeDetectorRef;
    overlayService: OverlayService;
    document: Document;
    componentName: string;
    $pcConfirmPopup: ConfirmPopup | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Optional key to match the key of confirm object, necessary to use when component tree has multiple confirm dialogs.
     * @group Props
     */
    readonly key: _angular_core.InputSignal<string | undefined>;
    /**
     * Element to receive the focus when the popup gets visible, valid values are "accept", "reject", and "none".
     * @group Props
     */
    readonly defaultFocus: _angular_core.InputSignal<string>;
    /**
     * Transition options of the show animation.
     * @group Props
     * @deprecated since v21.0.0. Use `motionOptions` instead.
     */
    showTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * Transition options of the hide animation.
     * @group Props
     * @deprecated since v21.0.0. Use `motionOptions` instead.
     */
    hideTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * Whether to automatically manage layering.
     * @group Props
     */
    autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Base zIndex value to use in layering.
     * @group Props
     */
    baseZIndex: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Inline style of the component.
     * @group Props
     */
    style: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the component.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines if the component is visible.
     * @group Props
     */
    visible: _angular_core.InputSignal<boolean | undefined>;
    private _visible;
    computedVisible: _angular_core.Signal<boolean>;
    render: _angular_core.WritableSignal<boolean>;
    /**
     * The motion options.
     * @group Props
     */
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    computedMotionOptions: _angular_core.Signal<MotionOptions>;
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'body'
     * @group Props
     */
    appendTo: _angular_core.InputSignal<any>;
    $appendTo: _angular_core.Signal<any>;
    container: HTMLElement | null;
    subscription: Subscription;
    confirmation: Nullable<Confirmation>;
    autoFocusAccept: boolean;
    autoFocusReject: boolean;
    /**
     * Custom content template.
     * @group Templates
     */
    contentTemplate: Nullable<TemplateRef<ConfirmPopupContentTemplateContext>>;
    /**
     * Custom accept icon template.
     * @group Templates
     */
    readonly acceptIconTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom reject icon template.
     * @group Templates
     */
    readonly rejectIconTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom headless template.
     * @group Templates
     */
    headlessTemplate: Nullable<TemplateRef<ConfirmPopupHeadlessTemplateContext>>;
    acceptButtonViewChild: _angular_core.Signal<ElementRef<any> | undefined>;
    rejectButtonViewChild: _angular_core.Signal<ElementRef<any> | undefined>;
    _contentTemplate: TemplateRef<ConfirmPopupContentTemplateContext> | undefined;
    _acceptIconTemplate: TemplateRef<void> | undefined;
    _rejectIconTemplate: TemplateRef<void> | undefined;
    _headlessTemplate: TemplateRef<ConfirmPopupHeadlessTemplateContext> | undefined;
    documentClickListener: VoidListener;
    documentResizeListener: VoidListener;
    scrollHandler: Nullable<ConnectedOverlayScrollHandler>;
    private window;
    _componentStyle: ConfirmPopupStyle;
    constructor();
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    onAfterContentInit(): void;
    option(name: string, k?: string): any;
    onEscapeKeydown(): void;
    onBeforeEnter(event: MotionEvent): void;
    handleFocus(): void;
    onAfterLeave(): void;
    getAcceptButtonProps(): any;
    getRejectButtonProps(): any;
    alignOverlay(): void;
    setZIndex(): void;
    alignArrow(): void;
    appendOverlay(): void;
    restoreAppend(): void;
    hide(): void;
    onAccept(): void;
    onReject(): void;
    onOverlayClick(event: MouseEvent): void;
    bindListeners(): void;
    unbindListeners(): void;
    bindDocumentClickListener(): void;
    unbindDocumentClickListener(): void;
    onWindowResize(): void;
    bindDocumentResizeListener(): void;
    unbindDocumentResizeListener(): void;
    bindScrollListener(): void;
    unbindScrollListener(): void;
    unsubscribeConfirmationSubscriptions(): void;
    onContainerDestroy(): void;
    get acceptButtonLabel(): string;
    get rejectButtonLabel(): string;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ConfirmPopup, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ConfirmPopup, "p-confirmpopup", never, { "key": { "alias": "key"; "required": false; "isSignal": true; }; "defaultFocus": { "alias": "defaultFocus"; "required": false; "isSignal": true; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; "isSignal": true; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "visible": { "alias": "visible"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; }, {}, ["acceptIconTemplate", "rejectIconTemplate", "templates", "contentTemplate", "headlessTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class ConfirmPopupModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ConfirmPopupModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<ConfirmPopupModule, never, [typeof ConfirmPopup, typeof i2.SharedModule], [typeof ConfirmPopup, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<ConfirmPopupModule>;
}

export { ConfirmPopup, ConfirmPopupClasses, ConfirmPopupModule, ConfirmPopupStyle };
