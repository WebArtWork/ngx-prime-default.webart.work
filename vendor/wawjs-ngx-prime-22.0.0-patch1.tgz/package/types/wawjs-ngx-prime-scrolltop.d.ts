import { ScrollTopPassThrough, ScrollTopIconTemplateContext } from '@wawjs/ngx-prime/types/scrolltop';
export * from '@wawjs/ngx-prime/types/scrolltop';
import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';
import { MotionOptions, MotionEvent } from '@wawjs/css-prime-motion';
import * as i2 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { ButtonProps } from '@wawjs/ngx-prime/button';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class ScrollTopStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-scrolltop-sticky': boolean;
        })[];
        icon: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ScrollTopStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ScrollTopStyle>;
}
/**
 *
 * ScrollTop gets displayed after a certain scroll position and used to navigates to the top of the page quickly.
 *
 * [Live Demo](https://www.ngx-prime.org/scrolltop/)
 *
 * @module scrolltopstyle
 *
 */
declare enum ScrollTopClasses {
    /**
     * Class name of the root element
     */
    root = "p-scrolltop",
    /**
     * Class name of the icon element
     */
    icon = "p-scrolltop-icon"
}

/**
 * ScrollTop gets displayed after a certain scroll position and used to navigates to the top of the page quickly.
 * @group Components
 */
declare class ScrollTop extends BaseComponent<ScrollTopPassThrough> {
    componentName: string;
    $pcScrollTop: ScrollTop | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Class of the element.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the element.
     * @group Props
     */
    style: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Target of the ScrollTop.
     * @group Props
     */
    target: _angular_core.InputSignal<"window" | "parent">;
    /**
     * Defines the threshold value of the vertical scroll position of the target to toggle the visibility.
     * @group Props
     */
    threshold: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Name of the icon or JSX.Element for icon.
     * @group Props
     */
    icon: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines the scrolling behavior, "smooth" adds an animation and "auto" scrolls with a jump.
     * @group Props
     */
    behavior: _angular_core.InputSignal<"auto" | "smooth">;
    /**
     * A string value used to determine the display transition options.
     * @group Props
     * @deprecated since v21.0.0. Use `motionOptions` instead.
     */
    showTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * A string value used to determine the hiding transition options.
     * @group Props
     * @deprecated since v21.0.0. Use `motionOptions` instead.
     */
    hideTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * The motion options.
     * @group Props
     */
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    computedMotionOptions: _angular_core.Signal<MotionOptions>;
    /**
     * Establishes a string value that labels the scroll-top button.
     * @group Props
     */
    buttonAriaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Used to pass all properties of the ButtonProps to the Button component.
     * @group Props
     */
    buttonProps: _angular_core.InputSignal<ButtonProps>;
    /**
     * Custom icon template.
     * @param {ScrollTopIconTemplateContext} context - icon context.
     * @see {@link ScrollTopIconTemplateContext}
     * @group Templates
     */
    readonly iconTemplate: _angular_core.Signal<TemplateRef<ScrollTopIconTemplateContext> | undefined>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _iconTemplate: TemplateRef<ScrollTopIconTemplateContext> | undefined;
    _icon: string | undefined;
    constructor();
    documentScrollListener: VoidFunction | null | undefined;
    parentScrollListener: VoidFunction | null | undefined;
    visible: _angular_core.WritableSignal<boolean>;
    render: _angular_core.WritableSignal<boolean>;
    overlay: any;
    _componentStyle: ScrollTopStyle;
    onInit(): void;
    onAfterContentInit(): void;
    onClick(): void;
    onBeforeEnter(event: MotionEvent): void;
    onBeforeLeave(): void;
    onAfterLeave(): void;
    checkVisibility(scrollY: number): void;
    bindParentScrollListener(): void;
    bindDocumentScrollListener(): void;
    unbindParentScrollListener(): void;
    unbindDocumentScrollListener(): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ScrollTop, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ScrollTop, "p-scrollTop, p-scrolltop, p-scroll-top", never, { "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "target": { "alias": "target"; "required": false; "isSignal": true; }; "threshold": { "alias": "threshold"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "behavior": { "alias": "behavior"; "required": false; "isSignal": true; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; "isSignal": true; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; "buttonAriaLabel": { "alias": "buttonAriaLabel"; "required": false; "isSignal": true; }; "buttonProps": { "alias": "buttonProps"; "required": false; "isSignal": true; }; }, {}, ["iconTemplate", "templates"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class ScrollTopModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ScrollTopModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<ScrollTopModule, never, [typeof ScrollTop, typeof i2.SharedModule], [typeof ScrollTop, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<ScrollTopModule>;
}

export { ScrollTop, ScrollTopClasses, ScrollTopModule, ScrollTopStyle };
