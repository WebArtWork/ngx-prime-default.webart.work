import { MeterGroupPassThrough, MeterItem, MeterGroupLabelTemplateContext, MeterGroupMeterTemplateContext, MeterGroupIconTemplateContext } from '@wawjs/ngx-prime/types/metergroup';
export * from '@wawjs/ngx-prime/types/metergroup';
import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class MeterGroupStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-metergroup-horizontal': boolean;
            'p-metergroup-vertical': boolean;
        })[];
        meters: string;
        meter: string;
        labelList: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-metergroup-label-list-vertical': boolean;
            'p-metergroup-label-list-horizontal': boolean;
        })[];
        label: string;
        labelIcon: string;
        labelMarker: string;
        labelText: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MeterGroupStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<MeterGroupStyle>;
}
/**
 *
 * MeterGroup is a group of process status indicators.
 *
 * [Live Demo](https://www.ngx-prime.org/metergroup)
 *
 * @module metergroupstyle
 *
 */
declare enum MeterGroupClasses {
    /**
     * Class name of the root element
     */
    root = "p-metergroup",
    /**
     * Class name of the meters element
     */
    meters = "p-metergroup-meters",
    /**
     * Class name of the meter element
     */
    meter = "p-metergroup-meter",
    /**
     * Class name of the label list element
     */
    labelList = "p-metergroup-label-list",
    /**
     * Class name of the label element
     */
    label = "p-metergroup-label",
    /**
     * Class name of the label icon element
     */
    labelIcon = "p-metergroup-label-icon",
    /**
     * Class name of the label marker element
     */
    labelMarker = "p-metergroup-label-marker",
    /**
     * Class name of the label text element
     */
    labelText = "p-metergroup-label-text"
}

declare class MeterGroupLabel extends BaseComponent<MeterGroupPassThrough> {
    value: _angular_core.InputSignal<any[]>;
    labelPosition: _angular_core.InputSignal<"start" | "end">;
    labelOrientation: _angular_core.InputSignal<"horizontal" | "vertical">;
    min: _angular_core.InputSignal<number | undefined>;
    max: _angular_core.InputSignal<number | undefined>;
    iconTemplate: _angular_core.InputSignal<TemplateRef<MeterGroupIconTemplateContext> | undefined>;
    parentInstance: MeterGroup;
    _componentStyle: MeterGroupStyle;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MeterGroupLabel, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MeterGroupLabel, "p-meterGroupLabel, p-metergrouplabel", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "labelPosition": { "alias": "labelPosition"; "required": false; "isSignal": true; }; "labelOrientation": { "alias": "labelOrientation"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "iconTemplate": { "alias": "iconTemplate"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/**
 * MeterGroup displays scalar measurements within a known range.
 * @group Components
 */
declare class MeterGroup extends BaseComponent<MeterGroupPassThrough> {
    componentName: string;
    $pcMeterGroup: MeterGroup | undefined;
    bindDirectiveInstance: Bind;
    /**
     * Current value of the metergroup.
     * @group Props
     */
    value: _angular_core.InputSignal<MeterItem[] | undefined>;
    /**
     * Mininum boundary value.
     * @group Props
     */
    min: _angular_core.InputSignal<number>;
    /**
     * Maximum boundary value.
     * @group Props
     */
    max: _angular_core.InputSignal<number>;
    /**
     * Specifies the layout of the component, valid values are 'horizontal' and 'vertical'.
     * @group Props
     */
    orientation: _angular_core.InputSignal<"horizontal" | "vertical">;
    /**
     * Specifies the label position of the component, valid values are 'start' and 'end'.
     * @group Props
     */
    labelPosition: _angular_core.InputSignal<"start" | "end">;
    /**
     * Specifies the label orientation of the component, valid values are 'horizontal' and 'vertical'.
     * @group Props
     */
    labelOrientation: _angular_core.InputSignal<"horizontal" | "vertical" | undefined>;
    /**
     * Style class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    get vertical(): boolean;
    /**
     * Custom label template.
     * @param {MeterGroupLabelTemplateContext} context - label context.
     * @see {@link MeterGroupLabelTemplateContext}
     * @group Templates
     */
    readonly labelTemplate: _angular_core.Signal<TemplateRef<MeterGroupLabelTemplateContext> | undefined>;
    /**
     * Custom meter template.
     * @param {MeterGroupMeterTemplateContext} context - meter context.
     * @see {@link MeterGroupMeterTemplateContext}
     * @group Templates
     */
    readonly meterTemplate: _angular_core.Signal<TemplateRef<MeterGroupMeterTemplateContext> | undefined>;
    /**
     * Custom end template.
     * @param {MeterGroupLabelTemplateContext} context - end context.
     * @see {@link MeterGroupLabelTemplateContext}
     * @group Templates
     */
    readonly endTemplate: _angular_core.Signal<TemplateRef<MeterGroupLabelTemplateContext> | undefined>;
    /**
     * Custom start template.
     * @param {MeterGroupLabelTemplateContext} context - start context.
     * @see {@link MeterGroupLabelTemplateContext}
     * @group Templates
     */
    readonly startTemplate: _angular_core.Signal<TemplateRef<MeterGroupLabelTemplateContext> | undefined>;
    /**
     * Custom icon template.
     * @param {MeterGroupIconTemplateContext} context - icon context.
     * @see {@link MeterGroupIconTemplateContext}
     * @group Templates
     */
    readonly iconTemplate: _angular_core.Signal<TemplateRef<MeterGroupIconTemplateContext> | undefined>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _labelTemplate: TemplateRef<MeterGroupLabelTemplateContext> | undefined;
    _meterTemplate: TemplateRef<MeterGroupMeterTemplateContext> | undefined;
    _endTemplate: TemplateRef<MeterGroupLabelTemplateContext> | undefined;
    _startTemplate: TemplateRef<MeterGroupLabelTemplateContext> | undefined;
    _iconTemplate: TemplateRef<MeterGroupIconTemplateContext> | undefined;
    onAfterViewChecked(): void;
    _componentStyle: MeterGroupStyle;
    constructor();
    onAfterViewInit(): void;
    onAfterContentInit(): void;
    percent(meter?: number): number;
    percentValue(meter: number): string;
    meterStyle(val: MeterItem): {
        backgroundColor: string | undefined;
        width: string | false;
        height: string | false;
    };
    totalPercent(): number;
    percentages(): number[];
    trackByFn(index: number): number;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MeterGroup, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MeterGroup, "p-meterGroup, p-metergroup, p-meter-group", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "labelPosition": { "alias": "labelPosition"; "required": false; "isSignal": true; }; "labelOrientation": { "alias": "labelOrientation"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, {}, ["labelTemplate", "meterTemplate", "endTemplate", "startTemplate", "iconTemplate", "templates"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class MeterGroupModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MeterGroupModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<MeterGroupModule, never, [typeof MeterGroup, typeof i2.SharedModule], [typeof MeterGroup, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<MeterGroupModule>;
}

export { MeterGroup, MeterGroupClasses, MeterGroupLabel, MeterGroupModule, MeterGroupStyle };
