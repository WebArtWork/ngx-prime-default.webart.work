import * as i0 from '@angular/core';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { InputGroupAddonPassThrough } from '@wawjs/ngx-prime/types/inputgroupaddon';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i2 from '@wawjs/ngx-prime/api';

declare class InputGroupAddonStyle extends BaseStyle {
    name: string;
    classes: {
        root: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<InputGroupAddonStyle, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InputGroupAddonStyle>;
}

/**
 * InputGroupAddon displays text, icon, buttons and other content can be grouped next to an input.
 * @group Components
 */
declare class InputGroupAddon extends BaseComponent<InputGroupAddonPassThrough> {
    componentName: string;
    _componentStyle: InputGroupAddonStyle;
    $pcInputGroupAddon: InputGroupAddon | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Inline style of the element.
     * @group Props
     */
    style: i0.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Class of the element.
     * @group Props
     */
    styleClass: i0.InputSignal<string | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<InputGroupAddon, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InputGroupAddon, "p-inputgroup-addon, p-inputGroupAddon", never, { "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class InputGroupAddonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<InputGroupAddonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<InputGroupAddonModule, never, [typeof InputGroupAddon, typeof i2.SharedModule], [typeof InputGroupAddon, typeof i2.SharedModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<InputGroupAddonModule>;
}

export { InputGroupAddon, InputGroupAddonModule, InputGroupAddonStyle };
