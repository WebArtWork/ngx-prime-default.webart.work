import { ToggleSwitchPassThrough, ToggleSwitchChangeEvent, ToggleSwitchHandleTemplateContext } from '@wawjs/ngx-prime/types/toggleswitch';
export * from '@wawjs/ngx-prime/types/toggleswitch';
import * as _angular_core from '@angular/core';
import { ElementRef, TemplateRef } from '@angular/core';
import * as i3 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class ToggleSwitchStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-toggleswitch p-component': boolean;
            'p-toggleswitch-checked': any;
            'p-disabled': any;
            'p-invalid': any;
        })[];
        input: string;
        slider: string;
        handle: string;
    };
    inlineStyles: {
        root: {
            position: string;
        };
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ToggleSwitchStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ToggleSwitchStyle>;
}
/**
 *
 * ToggleSwitch is used to select a boolean value.
 *
 * [Live Demo](https://www.ngx-prime.org/toggleswitch/)
 *
 * @module toggleswitchstyle
 *
 */
declare enum ToggleSwitchClasses {
    /**
     * Class name of the root element
     */
    root = "p-toggleswitch",
    /**
     * Class name of the input element
     */
    input = "p-toggleswitch-input",
    /**
     * Class name of the slider element
     */
    slider = "p-toggleswitch-slider"
}

/** Adds switch semantics and Prime state attributes to a native checkbox. */
declare class ToggleSwitchDirective extends BaseEditableHolder<ToggleSwitchPassThrough> {
    componentName: string;
    private readonly element;
    _componentStyle: ToggleSwitchStyle;
    private readonly bindDirectiveInstance;
    /** @deprecated Use the native `class` attribute instead. */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /** Compatibility input for the directive pass-through configuration. */
    ptToggleSwitch: _angular_core.InputSignal<ToggleSwitchPassThrough>;
    /** Pass-through configuration for the native toggle switch. */
    pToggleSwitchPT: _angular_core.InputSignal<ToggleSwitchPassThrough>;
    /** Enables unstyled mode for this native toggle switch. */
    pToggleSwitchUnstyled: _angular_core.InputSignal<boolean | undefined>;
    readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    inputId: _angular_core.InputSignal<string | undefined>;
    autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    trueValue: _angular_core.InputSignal<unknown>;
    falseValue: _angular_core.InputSignal<unknown>;
    size: _angular_core.InputSignal<"small" | "large" | undefined>;
    onChange: _angular_core.OutputEmitterRef<ToggleSwitchChangeEvent>;
    onFocus: _angular_core.OutputEmitterRef<Event>;
    onBlur: _angular_core.OutputEmitterRef<Event>;
    touch: _angular_core.OutputEmitterRef<void>;
    onInputClick(event: MouseEvent): void;
    onInputChange(event: Event): void;
    onInputFocus(event: Event): void;
    onInputBlur(event: Event): void;
    checked(): boolean;
    constructor();
    onAfterViewChecked(): void;
    focus(options?: FocusOptions): void;
    writeControlValue(value: unknown, setModelValue: (value: unknown) => void): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ToggleSwitchDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ToggleSwitchDirective, "input[type='checkbox'][pToggleSwitch]", never, { "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "ptToggleSwitch": { "alias": "ptToggleSwitch"; "required": false; "isSignal": true; }; "pToggleSwitchPT": { "alias": "pToggleSwitchPT"; "required": false; "isSignal": true; }; "pToggleSwitchUnstyled": { "alias": "pToggleSwitchUnstyled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "trueValue": { "alias": "trueValue"; "required": false; "isSignal": true; }; "falseValue": { "alias": "falseValue"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, { "onChange": "onChange"; "onFocus": "onFocus"; "onBlur": "onBlur"; "touch": "touch"; }, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}

declare const TOGGLESWITCH_VALUE_ACCESSOR: any;
/**
 * ToggleSwitch is used to select a boolean value.
 *
 * @deprecated Use a native `<input type="checkbox" pToggleSwitch>` instead.
 * The native control uses the browser indicator; custom handle templates are
 * not available. This component remains available for compatibility and is
 * planned for removal in v23.
 * @group Components
 */
declare class ToggleSwitch extends BaseEditableHolder<ToggleSwitchPassThrough> {
    componentName: string;
    $pcToggleSwitch: ToggleSwitch | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Identifier of the input element.
     * @group Props
     */
    inputId: _angular_core.InputSignal<string | undefined>;
    /**
     * When present, it specifies that the component cannot be edited.
     * @group Props
     */
    readonly: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Value in checked state.
     * @group Props
     */
    trueValue: _angular_core.InputSignal<any>;
    /**
     * Value in unchecked state.
     * @group Props
     */
    falseValue: _angular_core.InputSignal<any>;
    /**
     * Used to define a string that autocomplete attribute the current element.
     * @group Props
     */
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Specifies the size of the component.
     * @defaultValue undefined
     * @group Props
     */
    size: _angular_core.InputSignal<"small" | "large" | undefined>;
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Callback to invoke when the on value change.
     * @param {ToggleSwitchChangeEvent} event - Custom change event.
     * @group Emits
     */
    onChange: _angular_core.OutputEmitterRef<ToggleSwitchChangeEvent>;
    input: ElementRef;
    /**
     * Custom handle template.
     * @param {ToggleSwitchHandleTemplateContext} context - handle context.
     * @see {@link ToggleSwitchHandleTemplateContext}
     * @group Templates
     */
    handleTemplate: TemplateRef<ToggleSwitchHandleTemplateContext> | undefined;
    _handleTemplate: TemplateRef<ToggleSwitchHandleTemplateContext> | undefined;
    focused: boolean;
    _componentStyle: ToggleSwitchStyle;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    onHostClick(event: MouseEvent): void;
    onAfterContentInit(): void;
    onClick(event: Event): void;
    onFocus(): void;
    onBlur(): void;
    checked(): boolean;
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value: any, setModelValue: (value: any) => void): void;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ToggleSwitch, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ToggleSwitch, "p-toggleswitch, p-toggleSwitch, p-toggle-switch", never, { "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "trueValue": { "alias": "trueValue"; "required": false; "isSignal": true; }; "falseValue": { "alias": "falseValue"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; }, { "onChange": "onChange"; }, ["templates", "handleTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class ToggleSwitchModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ToggleSwitchModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<ToggleSwitchModule, never, [typeof ToggleSwitch, typeof ToggleSwitchDirective, typeof i3.SharedModule], [typeof ToggleSwitch, typeof ToggleSwitchDirective, typeof i3.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<ToggleSwitchModule>;
}

export { TOGGLESWITCH_VALUE_ACCESSOR, ToggleSwitch, ToggleSwitchClasses, ToggleSwitchDirective, ToggleSwitchModule, ToggleSwitchStyle };
