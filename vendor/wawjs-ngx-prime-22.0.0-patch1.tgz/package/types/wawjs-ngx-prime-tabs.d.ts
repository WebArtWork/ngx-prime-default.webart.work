import * as _angular_core from '@angular/core';
import { TemplateRef, ElementRef } from '@angular/core';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { TabsPassThrough, TabPanelsPassThrough, TabPanelPassThrough, TabListPassThrough, TabPassThrough } from '@wawjs/ngx-prime/types/tabs';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import * as i1$1 from '@wawjs/ngx-prime/ripple';

declare class TabsStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-tabs-scrollable': any;
        })[];
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabsStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TabsStyle>;
}
/**
 *
 * Tabs facilitates seamless switching between different views.
 *
 * [Live Demo](https://www.ngx-prime.org/tabs/)
 *
 * @module tabsstyle
 *
 */
declare enum TabsClasses {
    /**
     * Class name of the root element
     */
    root = "p-tabs",
    /**
     * Class name of the wrapper element
     */
    list = "p-tablist",
    /**
     * Class name of the content element
     */
    content = "p-tablist-content",
    /**
     * Class name of the tab list element
     */
    tablist = "p-tablist-tab-list",
    /**
     * Class name of the tab list element
     */
    tab = "p-tab",
    /**
     * Class name of the inkbar element
     */
    inkbar = "p-tablist-active-bar",
    /**
     * Class name of the navigation buttons
     */
    button = "p-tablist-nav-button",
    /**
     * Class name of the tab panels wrapper
     */
    tabpanels = "p-tabpanels",
    /**
     * Class name of the tab panel element
     */
    tabpanel = "p-tabs-panel"
}

/**
 * Tabs facilitates seamless switching between different views.
 * @group Components
 */
declare class Tabs extends BaseComponent<TabsPassThrough> {
    componentName: string;
    $pcTabs: Tabs | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Value of the active tab.
     * @defaultValue undefined
     * @group Props
     */
    value: _angular_core.ModelSignal<string | number | undefined>;
    /**
     * When specified, enables horizontal and/or vertical scrolling.
     * @type boolean
     * @defaultValue false
     * @group Props
     */
    scrollable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When enabled, tabs are not rendered until activation.
     * @type boolean
     * @defaultValue false
     * @group Props
     */
    lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When enabled, the focused tab is activated.
     * @type boolean
     * @defaultValue false
     * @group Props
     */
    selectOnFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to display navigation buttons in container when scrollable is enabled.
     * @type boolean
     * @defaultValue true
     * @group Props
     */
    showNavigators: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Tabindex of the tab buttons.
     * @type number
     * @defaultValue 0
     * @group Props
     */
    tabindex: _angular_core.InputSignalWithTransform<number, unknown>;
    id: _angular_core.WritableSignal<string>;
    _componentStyle: TabsStyle;
    updateValue(newValue: any): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Tabs, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Tabs, "p-tabs", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "scrollable": { "alias": "scrollable"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "selectOnFocus": { "alias": "selectOnFocus"; "required": false; "isSignal": true; }; "showNavigators": { "alias": "showNavigators"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}

declare class TabPanelsStyle extends BaseStyle {
    name: string;
    classes: {
        root: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabPanelsStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TabPanelsStyle>;
}

/**
 * TabPanels is a helper component for Tabs component.
 * @group Components
 */
declare class TabPanels extends BaseComponent<TabPanelsPassThrough> {
    componentName: string;
    $pcTabPanels: TabPanels | undefined;
    bindDirectiveInstance: Bind;
    _componentStyle: TabPanelsStyle;
    onAfterViewChecked(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabPanels, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TabPanels, "p-tabpanels", never, {}, {}, never, ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}

declare class TabPanelStyle extends BaseStyle {
    name: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-tabpanel-active': any;
        })[];
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabPanelStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TabPanelStyle>;
}

/**
 * TabPanel is a helper component for Tabs component.
 * @group Components
 */
declare class TabPanel extends BaseComponent<TabPanelPassThrough> {
    componentName: string;
    $pcTabPanel: TabPanel | undefined;
    bindDirectiveInstance: Bind;
    pcTabs: Tabs;
    onAfterViewChecked(): void;
    /**
     * When enabled, tab is not rendered until activation.
     * @type boolean
     * @defaultValue false
     * @group Props
     */
    lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Value of the active tab.
     * @defaultValue undefined
     * @group Props
     */
    value: _angular_core.ModelSignal<string | number | undefined>;
    /**
     * Template for initializing complex content when lazy is enabled.
     * @group Templates
     */
    content: _angular_core.Signal<unknown>;
    id: _angular_core.Signal<string>;
    ariaLabelledby: _angular_core.Signal<string>;
    active: _angular_core.Signal<boolean>;
    isLazyEnabled: _angular_core.Signal<boolean>;
    private hasBeenRendered;
    shouldRender: _angular_core.Signal<boolean>;
    _componentStyle: TabPanelStyle;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabPanel, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TabPanel, "p-tabpanel", never, { "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, ["content"], ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}

declare class TabListStyle extends BaseStyle {
    name: string;
    classes: {
        root: string;
        content: string;
        tabList: string;
        activeBar: string;
        prevButton: string;
        nextButton: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabListStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TabListStyle>;
}

/**
 * TabList is a helper component for Tabs component.
 * @group Components
 */
declare class TabList extends BaseComponent<TabListPassThrough> {
    componentName: string;
    $pcTabList: TabList | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * A template reference variable that represents the previous icon in a UI component.
     * @type {TemplateRef<any> | undefined}
     * @group Templates
     */
    prevIconTemplate: TemplateRef<any> | undefined;
    /**
     * A template reference variable that represents the next icon in a UI component.
     * @type {TemplateRef<any> | undefined}
     * @group Templates
     */
    nextIconTemplate: TemplateRef<any> | undefined;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    readonly content: _angular_core.Signal<ElementRef<HTMLDivElement>>;
    readonly prevButton: _angular_core.Signal<ElementRef<HTMLButtonElement>>;
    readonly nextButton: _angular_core.Signal<ElementRef<HTMLButtonElement>>;
    readonly inkbar: _angular_core.Signal<ElementRef<HTMLSpanElement>>;
    readonly tabs: _angular_core.Signal<ElementRef<HTMLDivElement>>;
    pcTabs: any;
    isPrevButtonEnabled: _angular_core.WritableSignal<boolean>;
    isNextButtonEnabled: _angular_core.WritableSignal<boolean>;
    resizeObserver: ResizeObserver;
    showNavigators: _angular_core.Signal<any>;
    tabindex: _angular_core.Signal<any>;
    scrollable: _angular_core.Signal<any>;
    _componentStyle: TabListStyle;
    constructor();
    get prevButtonAriaLabel(): string | undefined;
    get nextButtonAriaLabel(): string | undefined;
    onAfterViewInit(): void;
    _prevIconTemplate: TemplateRef<any> | undefined;
    _nextIconTemplate: TemplateRef<any> | undefined;
    onAfterContentInit(): void;
    onDestroy(): void;
    onScroll(event: Event): void;
    onPrevButtonClick(): void;
    onNextButtonClick(): void;
    updateButtonState(): void;
    updateInkBar(): void;
    getVisibleButtonWidths(): number;
    bindResizeObserver(): void;
    unbindResizeObserver(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabList, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TabList, "p-tablist", never, {}, {}, ["templates", "prevIconTemplate", "nextIconTemplate"], ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}

declare class TabStyle extends BaseStyle {
    name: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-tab-active': any;
            'p-disabled': any;
        })[];
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TabStyle>;
}

/**
 * Defines valid properties in Tab component.
 * @group Components
 */
declare class Tab extends BaseComponent<TabPassThrough> {
    componentName: string;
    $pcTab: Tab | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Value of tab.
     * @defaultValue undefined
     * @group Props
     */
    value: _angular_core.ModelSignal<string | number | undefined>;
    /**
     * Whether the tab is disabled.
     * @defaultValue false
     * @group Props
     */
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    pcTabs: any;
    pcTabList: any;
    el: ElementRef<any>;
    _componentStyle: TabStyle;
    ripple: _angular_core.Signal<boolean>;
    id: _angular_core.Signal<string>;
    ariaControls: _angular_core.Signal<string>;
    active: _angular_core.Signal<boolean>;
    tabindex: _angular_core.Signal<any>;
    mutationObserver: MutationObserver | undefined;
    onFocus(): void;
    onClick(): void;
    onKeyDown(event: KeyboardEvent): void;
    onAfterViewInit(): void;
    onArrowRightKey(event: any): void;
    onArrowLeftKey(event: any): void;
    onHomeKey(event: any): void;
    onEndKey(event: any): void;
    onPageDownKey(event: any): void;
    onPageUpKey(event: any): void;
    onEnterKey(event: any): void;
    findNextTab(tabElement: any, selfCheck?: boolean): any;
    findPrevTab(tabElement: any, selfCheck?: boolean): any;
    findFirstTab(): any;
    findLastTab(): any;
    changeActiveValue(): void;
    changeFocusedTab(event: any, element: any): void;
    scrollInView(element: any): void;
    bindMutationObserver(): void;
    unbindMutationObserver(): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Tab, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Tab, "p-tab", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; }, never, ["*"], true, [{ directive: typeof i1$1.Ripple; inputs: {}; outputs: {}; }, { directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}

declare class TabsModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabsModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<TabsModule, never, [typeof Tabs, typeof TabPanels, typeof TabPanel, typeof TabList, typeof Tab, typeof i1.BindModule], [typeof Tabs, typeof TabPanels, typeof TabPanel, typeof TabList, typeof Tab, typeof i1.BindModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<TabsModule>;
}

export { Tab, TabList, TabPanel, TabPanels, Tabs, TabsClasses, TabsModule, TabsStyle };
