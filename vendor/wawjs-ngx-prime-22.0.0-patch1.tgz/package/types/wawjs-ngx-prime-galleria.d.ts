import { GalleriaPassThrough, GalleriaResponsiveOptions, GalleriaIndicatorTemplateContext, GalleriaCaptionTemplateContext, GalleriaItemTemplateContext, GalleriaThumbnailTemplateContext } from '@wawjs/ngx-prime/types/galleria';
export * from '@wawjs/ngx-prime/types/galleria';
import * as _angular_core from '@angular/core';
import { ElementRef, TemplateRef, QueryList } from '@angular/core';
import { MotionOptions, MotionEvent } from '@wawjs/css-prime-motion';
import * as i3 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { VoidListener } from '@wawjs/ngx-prime/ts-helpers';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i2 from '@angular/common';
import * as i4 from '@wawjs/ngx-prime/ripple';
import * as i5 from '@wawjs/ngx-prime/icons';
import * as i6 from '@wawjs/ngx-prime/focustrap';
import * as i7 from '@wawjs/ngx-prime/motion';

declare class GalleriaStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        mask: string;
        root: ({ instance }: {
            instance: any;
        }) => any[];
        closeButton: string;
        closeIcon: string;
        header: string;
        content: string;
        footer: string;
        itemsContainer: string;
        items: string;
        prevButton: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-disabled': any;
        })[];
        prevIcon: string;
        item: string;
        nextButton: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-disabled': any;
        })[];
        nextIcon: string;
        caption: string;
        indicatorList: string;
        indicator: ({ instance, index }: {
            instance: any;
            index: any;
        }) => (string | {
            'p-galleria-indicator-active': any;
        })[];
        indicatorButton: string;
        thumbnails: string;
        thumbnailContent: string;
        thumbnailPrevButton: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-disabled': any;
        })[];
        thumbnailPrevIcon: string;
        thumbnailsViewport: string;
        thumbnailItems: string;
        thumbnailItem: ({ instance, index, activeIndex }: {
            instance: any;
            index: any;
            activeIndex: any;
        }) => (string | {
            'p-galleria-thumbnail-item-current': boolean;
            'p-galleria-thumbnail-item-active': any;
            'p-galleria-thumbnail-item-start': boolean;
            'p-galleria-thumbnail-item-end': boolean;
        })[];
        thumbnail: string;
        thumbnailNextButton: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-disabled': any;
        })[];
        thumbnailNextIcon: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<GalleriaStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<GalleriaStyle>;
}
/**
 *
 * Galleria is an advanced content gallery component.
 *
 * [Live Demo](https://www.ngx-prime.org/galleria/)
 *
 * @module galleriastyle
 *
 */
declare enum GalleriaClasses {
    /**
     * Class name of the mask element
     */
    mask = "p-galleria-mask",
    /**
     * Class name of the root element
     */
    root = "p-galleria",
    /**
     * Class name of the close button element
     */
    closeButton = "p-galleria-close-button",
    /**
     * Class name of the close icon element
     */
    closeIcon = "p-galleria-close-icon",
    /**
     * Class name of the header element
     */
    header = "p-galleria-header",
    /**
     * Class name of the content element
     */
    content = "p-galleria-content",
    /**
     * Class name of the footer element
     */
    footer = "p-galleria-footer",
    /**
     * Class name of the items container element
     */
    itemsContainer = "p-galleria-items-container",
    /**
     * Class name of the items element
     */
    items = "p-galleria-items",
    /**
     * Class name of the previous item button element
     */
    prevButton = "p-galleria-prev-button",
    /**
     * Class name of the previous item icon element
     */
    prevIcon = "p-galleria-prev-icon",
    /**
     * Class name of the item element
     */
    item = "p-galleria-item",
    /**
     * Class name of the next item button element
     */
    nextButton = "p-galleria-next-button",
    /**
     * Class name of the next item icon element
     */
    nextIcon = "p-galleria-next-icon",
    /**
     * Class name of the caption element
     */
    caption = "p-galleria-caption",
    /**
     * Class name of the indicator list element
     */
    indicatorList = "p-galleria-indicator-list",
    /**
     * Class name of the indicator element
     */
    indicator = "p-galleria-indicator",
    /**
     * Class name of the indicator button element
     */
    indicatorButton = "p-galleria-indicator-button",
    /**
     * Class name of the thumbnails element
     */
    thumbnails = "p-galleria-thumbnails",
    /**
     * Class name of the thumbnail content element
     */
    thumbnailContent = "p-galleria-thumbnails-content",
    /**
     * Class name of the previous thumbnail button element
     */
    previousThumbnailButton = "p-galleria-thumbnail-prev-button",
    /**
     * Class name of the previous thumbnail icon element
     */
    previousThumbnailIcon = "p-galleria-thumbnail-prev-icon",
    /**
     * Class name of the thumbnails viewport element
     */
    thumbnailsViewport = "p-galleria-thumbnails-viewport",
    /**
     * Class name of the thumbnail items element
     */
    thumbnailItems = "p-galleria-thumbnail-items",
    /**
     * Class name of the thumbnail item element
     */
    thumbnailItem = "p-galleria-thumbnail-item",
    /**
     * Class name of the thumbnail element
     */
    thumbnail = "p-galleria-thumbnail",
    /**
     * Class name of the next thumbnail button element
     */
    nextThumbnailButton = "p-galleria-thumbnail-next-button",
    /**
     * Class name of the next thumbnail icon element
     */
    nextThumbnailIcon = "p-galleria-thumbnail-next-icon"
}

/**
 * Galleria is an advanced content gallery component.
 * @group Components
 */
declare class Galleria extends BaseComponent<GalleriaPassThrough> {
    element: ElementRef<any>;
    componentName: string;
    bindDirectiveInstance: Bind;
    $pcGalleria: Galleria | undefined;
    onAfterViewChecked(): void;
    /**
     * Index of the first item.
     * @group Props
     */
    readonly activeIndex: _angular_core.ModelSignal<number>;
    /**
     * Whether to display the component on fullscreen.
     * @group Props
     */
    readonly fullScreen: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Unique identifier of the element.
     * @group Props
     */
    readonly id: _angular_core.InputSignal<string | undefined>;
    /**
     * An array of objects to display.
     * @group Props
     */
    readonly value: _angular_core.InputSignal<any[] | undefined>;
    /**
     * Number of items per page.
     * @group Props
     */
    readonly numVisible: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * An array of options for responsive design.
     * @see {GalleriaResponsiveOptions}
     * @group Props
     */
    readonly responsiveOptions: _angular_core.InputSignal<GalleriaResponsiveOptions[] | undefined>;
    /**
     * Whether to display navigation buttons in item section.
     * @group Props
     */
    readonly showItemNavigators: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to display navigation buttons in thumbnail container.
     * @group Props
     */
    readonly showThumbnailNavigators: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to display navigation buttons on item hover.
     * @group Props
     */
    readonly showItemNavigatorsOnHover: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When enabled, item is changed on indicator hover.
     * @group Props
     */
    readonly changeItemOnIndicatorHover: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Defines if scrolling would be infinite.
     * @group Props
     */
    readonly circular: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Items are displayed with a slideshow in autoPlay mode.
     * @group Props
     */
    readonly autoPlay: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When enabled, autorun should stop by click.
     * @group Props
     */
    readonly shouldStopAutoplayByClick: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Time in milliseconds to scroll items.
     * @group Props
     */
    readonly transitionInterval: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Whether to display thumbnail container.
     * @group Props
     */
    readonly showThumbnails: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Position of thumbnails.
     * @group Props
     */
    readonly thumbnailsPosition: _angular_core.InputSignal<"bottom" | "top" | "left" | "right" | undefined>;
    /**
     * Height of the viewport in vertical thumbnail.
     * @group Props
     */
    readonly verticalThumbnailViewPortHeight: _angular_core.InputSignal<string>;
    /**
     * Whether to display indicator container.
     * @group Props
     */
    readonly showIndicators: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When enabled, indicator container is displayed on item container.
     * @group Props
     */
    readonly showIndicatorsOnItem: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Position of indicators.
     * @group Props
     */
    readonly indicatorsPosition: _angular_core.InputSignal<"bottom" | "top" | "left" | "right" | undefined>;
    /**
     * Base zIndex value to use in layering.
     * @group Props
     */
    readonly baseZIndex: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Style class of the mask on fullscreen mode.
     * @group Props
     */
    readonly maskClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the component on fullscreen mode. Otherwise, the 'class' property can be used.
     * @group Props
     */
    readonly containerClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the component on fullscreen mode. Otherwise, the 'style' property can be used.
     * @group Props
     */
    readonly containerStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Transition options of the show animation.
     * @deprecated since v21.0.0. Use `motionOptions` instead.
     * @group Props
     */
    readonly showTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * Transition options of the hide animation.
     * @deprecated since v21.0.0. Use `motionOptions` instead.
     * @group Props
     */
    readonly hideTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * The motion options.
     * @group Props
     */
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    computedMotionOptions: _angular_core.Signal<MotionOptions>;
    /**
     * The mask motion options.
     * @group Props
     */
    maskMotionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    computedMaskMotionOptions: _angular_core.Signal<MotionOptions>;
    /**
     * Specifies the visibility of the mask on fullscreen mode.
     * @group Props
     */
    readonly visible: _angular_core.ModelSignal<boolean>;
    renderMask: _angular_core.WritableSignal<boolean>;
    renderContent: _angular_core.WritableSignal<boolean>;
    container: ElementRef | undefined;
    /**
     * Custom header template.
     * @group Templates
     */
    readonly headerTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    headerFacet: TemplateRef<void> | undefined;
    /**
     * Custom footer template.
     * @group Templates
     */
    readonly footerTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    footerFacet: TemplateRef<void> | undefined;
    /**
     * Custom indicator template.
     * @group Templates
     */
    readonly indicatorTemplate: _angular_core.Signal<TemplateRef<GalleriaIndicatorTemplateContext> | undefined>;
    indicatorFacet: TemplateRef<GalleriaIndicatorTemplateContext> | undefined;
    /**
     * Custom caption template.
     * @group Templates
     */
    readonly captionTemplate: _angular_core.Signal<TemplateRef<GalleriaCaptionTemplateContext<any>> | undefined>;
    captionFacet: TemplateRef<GalleriaCaptionTemplateContext> | undefined;
    /**
     * Custom close icon template.
     * @group Templates
     */
    readonly _closeIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    closeIconTemplate: TemplateRef<void> | undefined;
    /**
     * Custom previous thumbnail icon template.
     * @group Templates
     */
    readonly _previousThumbnailIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    previousThumbnailIconTemplate: TemplateRef<void> | undefined;
    /**
     * Custom next thumbnail icon template.
     * @group Templates
     */
    readonly _nextThumbnailIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    nextThumbnailIconTemplate: TemplateRef<void> | undefined;
    /**
     * Custom item previous icon template.
     * @group Templates
     */
    readonly _itemPreviousIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    itemPreviousIconTemplate: TemplateRef<void> | undefined;
    /**
     * Custom item next icon template.
     * @group Templates
     */
    readonly _itemNextIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    itemNextIconTemplate: TemplateRef<void> | undefined;
    /**
     * Custom item template.
     * @group Templates
     */
    readonly _itemTemplate: _angular_core.Signal<TemplateRef<GalleriaItemTemplateContext<any>> | undefined>;
    itemTemplate: TemplateRef<GalleriaItemTemplateContext> | undefined;
    /**
     * Custom thumbnail template.
     * @group Templates
     */
    readonly _thumbnailTemplate: _angular_core.Signal<TemplateRef<GalleriaThumbnailTemplateContext<any>> | undefined>;
    thumbnailTemplate: TemplateRef<GalleriaThumbnailTemplateContext> | undefined;
    maskVisible: boolean;
    numVisibleLimit: number;
    _componentStyle: GalleriaStyle;
    mask: HTMLElement;
    templates: QueryList<PrimeTemplate> | undefined;
    constructor();
    onAfterContentInit(): void;
    onMaskHide(event?: MouseEvent): void;
    onActiveItemChange(index: number): void;
    onBeforeEnter(event: MotionEvent): void;
    onBeforeLeave(): void;
    onAfterLeave(): void;
    onMaskAfterLeave(): void;
    enableModality(): void;
    disableModality(): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Galleria, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Galleria, "p-galleria", never, { "activeIndex": { "alias": "activeIndex"; "required": false; "isSignal": true; }; "fullScreen": { "alias": "fullScreen"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "numVisible": { "alias": "numVisible"; "required": false; "isSignal": true; }; "responsiveOptions": { "alias": "responsiveOptions"; "required": false; "isSignal": true; }; "showItemNavigators": { "alias": "showItemNavigators"; "required": false; "isSignal": true; }; "showThumbnailNavigators": { "alias": "showThumbnailNavigators"; "required": false; "isSignal": true; }; "showItemNavigatorsOnHover": { "alias": "showItemNavigatorsOnHover"; "required": false; "isSignal": true; }; "changeItemOnIndicatorHover": { "alias": "changeItemOnIndicatorHover"; "required": false; "isSignal": true; }; "circular": { "alias": "circular"; "required": false; "isSignal": true; }; "autoPlay": { "alias": "autoPlay"; "required": false; "isSignal": true; }; "shouldStopAutoplayByClick": { "alias": "shouldStopAutoplayByClick"; "required": false; "isSignal": true; }; "transitionInterval": { "alias": "transitionInterval"; "required": false; "isSignal": true; }; "showThumbnails": { "alias": "showThumbnails"; "required": false; "isSignal": true; }; "thumbnailsPosition": { "alias": "thumbnailsPosition"; "required": false; "isSignal": true; }; "verticalThumbnailViewPortHeight": { "alias": "verticalThumbnailViewPortHeight"; "required": false; "isSignal": true; }; "showIndicators": { "alias": "showIndicators"; "required": false; "isSignal": true; }; "showIndicatorsOnItem": { "alias": "showIndicatorsOnItem"; "required": false; "isSignal": true; }; "indicatorsPosition": { "alias": "indicatorsPosition"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "maskClass": { "alias": "maskClass"; "required": false; "isSignal": true; }; "containerClass": { "alias": "containerClass"; "required": false; "isSignal": true; }; "containerStyle": { "alias": "containerStyle"; "required": false; "isSignal": true; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; "isSignal": true; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; "maskMotionOptions": { "alias": "maskMotionOptions"; "required": false; "isSignal": true; }; "visible": { "alias": "visible"; "required": false; "isSignal": true; }; }, { "activeIndex": "activeIndexChange"; "visible": "visibleChange"; }, ["headerTemplate", "footerTemplate", "indicatorTemplate", "captionTemplate", "_closeIconTemplate", "_previousThumbnailIconTemplate", "_nextThumbnailIconTemplate", "_itemPreviousIconTemplate", "_itemNextIconTemplate", "_itemTemplate", "_thumbnailTemplate", "templates"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class GalleriaContent extends BaseComponent<GalleriaPassThrough> {
    galleria: Galleria;
    private differs;
    hostName: string;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    readonly activeIndex: _angular_core.InputSignal<number>;
    _activeIndexBacking: number;
    readonly value: _angular_core.InputSignal<any[]>;
    readonly numVisible: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly fullScreen: _angular_core.InputSignalWithTransform<boolean, unknown>;
    _fullScreenBacking: boolean;
    maskHide: _angular_core.OutputEmitterRef<boolean>;
    activeItemChange: _angular_core.OutputEmitterRef<number>;
    readonly closeButton: _angular_core.Signal<ElementRef<any> | undefined>;
    _componentStyle: GalleriaStyle;
    $pcGalleria: Galleria | undefined;
    id: string;
    slideShowActive: boolean;
    interval: any;
    styleClass: string | undefined;
    private differ;
    constructor();
    handleFullscreenChange(): void;
    onDoCheck(): void;
    shouldRenderFooter(): true | TemplateRef<void> | undefined;
    startSlideShow(): void;
    stopSlideShow(): void;
    getPositionClass(preClassName: string, position: string): string;
    isVertical(): boolean;
    onActiveIndexChange(index: number): void;
    closeAriaLabel(): string | undefined;
    getPTOptions(key: string): any;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<GalleriaContent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<GalleriaContent, "div[pGalleriaContent]", never, { "activeIndex": { "alias": "activeIndex"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "numVisible": { "alias": "numVisible"; "required": false; "isSignal": true; }; "fullScreen": { "alias": "fullScreen"; "required": false; "isSignal": true; }; }, { "maskHide": "maskHide"; "activeItemChange": "activeItemChange"; }, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class GalleriaItemSlot extends BaseComponent<GalleriaPassThrough> {
    hostName: string;
    readonly templates: _angular_core.InputSignal<QueryList<PrimeTemplate> | undefined>;
    readonly index: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly item: _angular_core.InputSignal<any>;
    constructor();
    shouldRender(): TemplateRef<any> | undefined;
    galleria: Galleria;
    $pcGalleria: Galleria | undefined;
    getTemplateFromQueryList(type: string): TemplateRef<any> | undefined;
    getContentTemplate(): void;
    readonly type: _angular_core.InputSignal<string | undefined>;
    contentTemplate: TemplateRef<any> | undefined;
    context: any;
    onAfterContentInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<GalleriaItemSlot, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<GalleriaItemSlot, "div[pGalleriaItemSlot]", never, { "templates": { "alias": "templates"; "required": false; "isSignal": true; }; "index": { "alias": "index"; "required": false; "isSignal": true; }; "item": { "alias": "item"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class GalleriaItem extends BaseComponent<GalleriaPassThrough> {
    galleria: Galleria;
    hostName: string;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly circular: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly value: _angular_core.InputSignal<any[] | undefined>;
    readonly showItemNavigators: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showIndicators: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly slideShowActive: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly changeItemOnIndicatorHover: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly autoPlay: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly templates: _angular_core.InputSignal<QueryList<PrimeTemplate> | undefined>;
    readonly indicatorFacet: _angular_core.InputSignal<any>;
    readonly captionFacet: _angular_core.InputSignal<any>;
    startSlideShow: _angular_core.OutputEmitterRef<Event | undefined>;
    stopSlideShow: _angular_core.OutputEmitterRef<Event | undefined>;
    onActiveIndexChange: _angular_core.OutputEmitterRef<number>;
    _componentStyle: GalleriaStyle;
    readonly activeIndex: _angular_core.InputSignal<number>;
    get activeItem(): any;
    leftButtonFocused: boolean;
    rightButtonFocused: boolean;
    constructor();
    getIndicatorPTOptions(index: number): any;
    next(): void;
    prev(): void;
    onButtonFocus(pos: 'left' | 'right'): void;
    onButtonBlur(pos: 'left' | 'right'): void;
    stopTheSlideShow(): void;
    navForward(e: MouseEvent): void;
    navBackward(e: MouseEvent): void;
    onIndicatorClick(index: number): void;
    onIndicatorMouseEnter(index: number): void;
    onIndicatorKeyDown(event: any, index: number): void;
    isNavForwardDisabled(): boolean;
    isNavBackwardDisabled(): boolean;
    isIndicatorItemActive(index: number): boolean;
    ariaSlideLabel(): string | undefined;
    ariaSlideNumber(value: any): string | undefined;
    ariaPageLabel(value: any): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<GalleriaItem, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<GalleriaItem, "div[pGalleriaItem]", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "circular": { "alias": "circular"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "showItemNavigators": { "alias": "showItemNavigators"; "required": false; "isSignal": true; }; "showIndicators": { "alias": "showIndicators"; "required": false; "isSignal": true; }; "slideShowActive": { "alias": "slideShowActive"; "required": false; "isSignal": true; }; "changeItemOnIndicatorHover": { "alias": "changeItemOnIndicatorHover"; "required": false; "isSignal": true; }; "autoPlay": { "alias": "autoPlay"; "required": false; "isSignal": true; }; "templates": { "alias": "templates"; "required": false; "isSignal": true; }; "indicatorFacet": { "alias": "indicatorFacet"; "required": false; "isSignal": true; }; "captionFacet": { "alias": "captionFacet"; "required": false; "isSignal": true; }; "activeIndex": { "alias": "activeIndex"; "required": false; "isSignal": true; }; }, { "startSlideShow": "startSlideShow"; "stopSlideShow": "stopSlideShow"; "onActiveIndexChange": "onActiveIndexChange"; }, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class GalleriaThumbnails extends BaseComponent<GalleriaPassThrough> {
    galleria: Galleria;
    hostName: string;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    readonly containerId: _angular_core.InputSignal<string | undefined>;
    readonly value: _angular_core.InputSignal<any[] | undefined>;
    readonly isVertical: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly slideShowActive: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly circular: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly responsiveOptions: _angular_core.InputSignal<GalleriaResponsiveOptions[] | undefined>;
    readonly contentHeight: _angular_core.InputSignal<string>;
    readonly showThumbnailNavigators: _angular_core.InputSignal<boolean>;
    readonly templates: _angular_core.InputSignal<QueryList<PrimeTemplate> | undefined>;
    onActiveIndexChange: _angular_core.OutputEmitterRef<number>;
    stopSlideShow: _angular_core.OutputEmitterRef<Event | undefined>;
    readonly itemsContainer: _angular_core.Signal<ElementRef<any> | undefined>;
    readonly numVisible: _angular_core.InputSignal<number>;
    readonly activeIndex: _angular_core.InputSignal<number>;
    constructor();
    index: number | undefined;
    startPos: {
        x: number;
        y: number;
    } | null;
    thumbnailsStyle: HTMLStyleElement | null;
    sortedResponsiveOptions: GalleriaResponsiveOptions[] | null;
    totalShiftedItems: number;
    page: number;
    documentResizeListener: VoidListener;
    _numVisible: number;
    d_numVisible: number;
    _oldNumVisible: number;
    _activeIndex: number;
    _oldactiveIndex: number;
    _componentStyle: GalleriaStyle;
    onInit(): void;
    onAfterContentChecked(): void;
    onAfterViewInit(): void;
    createStyle(): void;
    calculatePosition(): void;
    getTabIndex(index: number): 0 | null;
    navForward(e: TouchEvent | MouseEvent): void;
    navBackward(e: TouchEvent | MouseEvent): void;
    onItemClick(index: number): void;
    onThumbnailKeydown(event: KeyboardEvent, index: number): void;
    onRightKey(): void;
    onLeftKey(): void;
    onHomeKey(): void;
    onEndKey(): void;
    onTabKey(): void;
    findFocusedIndicatorIndex(): number;
    changedFocusedIndicator(prevInd: number, nextInd: number): void;
    step(dir: number): void;
    stopTheSlideShow(): void;
    changePageOnTouch(e: TouchEvent, diff: number): void;
    getTotalPageNumber(): number;
    getMedianItemIndex(): number;
    onTransitionEnd(): void;
    onTouchEnd(e: TouchEvent): void;
    onTouchMove(e: TouchEvent): void;
    onTouchStart(e: TouchEvent): void;
    isNavBackwardDisabled(): boolean;
    isNavForwardDisabled(): boolean;
    firstItemAciveIndex(): number;
    lastItemActiveIndex(): number;
    isItemActive(index: number): boolean;
    bindDocumentListeners(): void;
    unbindDocumentListeners(): void;
    onDestroy(): void;
    ariaPrevButtonLabel(): string | undefined;
    ariaNextButtonLabel(): string | undefined;
    ariaPageLabel(value: any): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<GalleriaThumbnails, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<GalleriaThumbnails, "div[pGalleriaThumbnails]", never, { "containerId": { "alias": "containerId"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "isVertical": { "alias": "isVertical"; "required": false; "isSignal": true; }; "slideShowActive": { "alias": "slideShowActive"; "required": false; "isSignal": true; }; "circular": { "alias": "circular"; "required": false; "isSignal": true; }; "responsiveOptions": { "alias": "responsiveOptions"; "required": false; "isSignal": true; }; "contentHeight": { "alias": "contentHeight"; "required": false; "isSignal": true; }; "showThumbnailNavigators": { "alias": "showThumbnailNavigators"; "required": false; "isSignal": true; }; "templates": { "alias": "templates"; "required": false; "isSignal": true; }; "numVisible": { "alias": "numVisible"; "required": false; "isSignal": true; }; "activeIndex": { "alias": "activeIndex"; "required": false; "isSignal": true; }; }, { "onActiveIndexChange": "onActiveIndexChange"; "stopSlideShow": "stopSlideShow"; }, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class GalleriaModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<GalleriaModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<GalleriaModule, never, [typeof i2.CommonModule, typeof i3.SharedModule, typeof i4.Ripple, typeof i5.TimesIcon, typeof i5.ChevronRightIcon, typeof i5.ChevronUpIcon, typeof i5.ChevronDownIcon, typeof i5.ChevronLeftIcon, typeof i6.FocusTrap, typeof i1.BindModule, typeof i7.MotionModule, typeof Galleria, typeof GalleriaContent, typeof GalleriaItemSlot, typeof GalleriaItem, typeof GalleriaThumbnails], [typeof i2.CommonModule, typeof Galleria, typeof GalleriaContent, typeof GalleriaItemSlot, typeof GalleriaItem, typeof GalleriaThumbnails, typeof i3.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<GalleriaModule>;
}

export { Galleria, GalleriaClasses, GalleriaContent, GalleriaItem, GalleriaItemSlot, GalleriaModule, GalleriaStyle, GalleriaThumbnails };
