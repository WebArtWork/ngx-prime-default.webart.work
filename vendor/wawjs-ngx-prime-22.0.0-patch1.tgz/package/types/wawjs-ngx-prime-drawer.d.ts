import { DrawerPassThrough } from '@wawjs/ngx-prime/types/drawer';
export * from '@wawjs/ngx-prime/types/drawer';
import * as _angular_core from '@angular/core';
import { ElementRef, TemplateRef } from '@angular/core';
import { MotionOptions, MotionEvent } from '@wawjs/css-prime-motion';
import * as i2 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { ButtonProps } from '@wawjs/ngx-prime/button';
import { Nullable, VoidListener } from '@wawjs/ngx-prime/ts-helpers';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class DrawerStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        mask: ({ instance }: {
            instance: any;
        }) => (string | {
            "p-overlay-mask p-overlay-mask-enter-active": any;
            'p-drawer-full'?: undefined;
        } | {
            'p-drawer-full': any;
            "p-overlay-mask p-overlay-mask-enter-active"?: undefined;
        })[];
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-drawer-full': any;
            'p-drawer-open': any;
        })[];
        header: string;
        title: string;
        pcCloseButton: string;
        content: string;
        footer: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DrawerStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<DrawerStyle>;
}
/**
 *
 * Drawer is a panel component displayed as an overlay at the edges of the screen.
 *
 * [Live Demo](https://www.ngx-prime.org/drawer)
 *
 * @module drawerstyle
 *
 */
declare enum DrawerClasses {
    /**
     * Class name of the mask element
     */
    mask = "p-drawer-mask",
    /**
     * Class name of the root element
     */
    root = "p-drawer",
    /**
     * Class name of the header element
     */
    header = "p-drawer-header",
    /**
     * Class name of the title element
     */
    title = "p-drawer-title",
    /**
     * Class name of the close button element
     */
    pcCloseButton = "p-drawer-close-button",
    /**
     * Class name of the content element
     */
    content = "p-drawer-content"
}

/**
 * Sidebar is a panel component displayed as an overlay at the edges of the screen.
 * @group Components
 */
declare class Drawer extends BaseComponent<DrawerPassThrough> {
    componentName: string;
    $pcDrawer: Drawer | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'self'
     * @group Props
     */
    appendTo: _angular_core.InputSignal<any>;
    /**
     * The motion options.
     * @group Props
     */
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    computedMotionOptions: _angular_core.Signal<MotionOptions>;
    /**
     * Whether to block scrolling of the document when drawer is active.
     * @group Props
     */
    blockScroll: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Inline style of the component.
     * @group Props
     */
    style: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the component.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Aria label of the close icon.
     * @group Props
     */
    ariaCloseLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to automatically manage layering.
     * @group Props
     */
    autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Base zIndex value to use in layering.
     * @group Props
     */
    baseZIndex: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Whether an overlay mask is displayed behind the drawer.
     * @group Props
     */
    modal: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Used to pass all properties of the ButtonProps to the Button component.
     * @group Props
     */
    closeButtonProps: _angular_core.InputSignal<ButtonProps>;
    /**
     * Whether to dismiss drawer on click of the mask.
     * @group Props
     */
    dismissible: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to display the close icon.
     * @group Props
     * @deprecated use 'closable' instead.
     */
    showCloseIcon: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Specifies if pressing escape key should hide the drawer.
     * @group Props
     */
    closeOnEscape: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Transition options of the animation.
     * @group Props
     * @deprecated since v21.0.0. Use `motionOptions` instead.
     */
    transitionOptions: _angular_core.InputSignal<string>;
    /**
     * The visible property is an input that determines the visibility of the component.
     * @defaultValue false
     * @group Props
     */
    visible: _angular_core.ModelSignal<boolean>;
    /**
     * Specifies the position of the drawer, valid values are "left", "right", "bottom" and "top".
     * @defaultValue 'left'
     * @group Props
     */
    position: _angular_core.InputSignal<"left" | "right" | "bottom" | "top" | "full">;
    /**
     * Adds a close icon to the header to hide the dialog.
     * @defaultValue false
     * @group Props
     */
    fullScreen: _angular_core.InputSignal<boolean>;
    $enterAnimation: _angular_core.Signal<string>;
    $leaveAnimation: _angular_core.Signal<string>;
    /**
     * Title content of the dialog.
     * @group Props
     */
    header: _angular_core.InputSignal<string | undefined>;
    /**
     * Style of the mask.
     * @group Props
     */
    maskStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Whether to display close button.
     * @group Props
     * @defaultValue true
     */
    closable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Callback to invoke when dialog is shown.
     * @group Emits
     */
    onShow: _angular_core.OutputEmitterRef<any>;
    /**
     * Callback to invoke when dialog is hidden.
     * @group Emits
     */
    onHide: _angular_core.OutputEmitterRef<any>;
    readonly containerViewChild: _angular_core.Signal<ElementRef<any> | undefined>;
    readonly closeButtonViewChild: _angular_core.Signal<ElementRef<any> | undefined>;
    initialized: boolean | undefined;
    _position: string;
    _fullScreen: boolean;
    modalVisible: boolean;
    container: Nullable<HTMLDivElement>;
    mask: Nullable<HTMLDivElement>;
    maskClickListener: VoidListener;
    documentEscapeListener: VoidListener;
    animationEndListener: VoidListener;
    _componentStyle: DrawerStyle;
    constructor();
    onAfterViewInit(): void;
    /**
     * Custom header template.
     * @group Templates
     */
    readonly headerTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom footer template.
     * @group Templates
     */
    footerTemplate: TemplateRef<void> | undefined;
    /**
     * Custom content template.
     * @group Templates
     */
    readonly contentTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom close icon template.
     * @group Templates
     */
    readonly closeIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom headless template to replace the entire drawer content.
     * @group Templates
     */
    headlessTemplate: TemplateRef<void> | undefined;
    $appendTo: _angular_core.Signal<any>;
    _headerTemplate: TemplateRef<void> | undefined;
    _footerTemplate: TemplateRef<void> | undefined;
    _contentTemplate: TemplateRef<void> | undefined;
    _closeIconTemplate: TemplateRef<void> | undefined;
    _headlessTemplate: TemplateRef<void> | undefined;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    onAfterContentInit(): void;
    onKeyDown(event: KeyboardEvent): void;
    show(): void;
    hide(emit?: boolean): void;
    close(event: Event): void;
    enableModality(): void;
    getMaskStyle(): string;
    disableModality(): void;
    destroyModal(): void;
    onBeforeEnter(event: MotionEvent): void;
    onAfterLeave(): void;
    appendContainer(): void;
    bindDocumentEscapeListener(): void;
    unbindDocumentEscapeListener(): void;
    unbindMaskClickListener(): void;
    unbindGlobalListeners(): void;
    unbindAnimationEndListener(): void;
    onDestroy(): void;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Drawer, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Drawer, "p-drawer", never, { "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; "blockScroll": { "alias": "blockScroll"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "ariaCloseLabel": { "alias": "ariaCloseLabel"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "modal": { "alias": "modal"; "required": false; "isSignal": true; }; "closeButtonProps": { "alias": "closeButtonProps"; "required": false; "isSignal": true; }; "dismissible": { "alias": "dismissible"; "required": false; "isSignal": true; }; "showCloseIcon": { "alias": "showCloseIcon"; "required": false; "isSignal": true; }; "closeOnEscape": { "alias": "closeOnEscape"; "required": false; "isSignal": true; }; "transitionOptions": { "alias": "transitionOptions"; "required": false; "isSignal": true; }; "visible": { "alias": "visible"; "required": false; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; "fullScreen": { "alias": "fullScreen"; "required": false; "isSignal": true; }; "header": { "alias": "header"; "required": false; "isSignal": true; }; "maskStyle": { "alias": "maskStyle"; "required": false; "isSignal": true; }; "closable": { "alias": "closable"; "required": false; "isSignal": true; }; }, { "visible": "visibleChange"; "onShow": "onShow"; "onHide": "onHide"; }, ["headerTemplate", "contentTemplate", "closeIconTemplate", "templates", "footerTemplate", "headlessTemplate"], ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class DrawerModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DrawerModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<DrawerModule, never, [typeof Drawer, typeof i2.SharedModule], [typeof Drawer, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<DrawerModule>;
}

export { Drawer, DrawerClasses, DrawerModule, DrawerStyle };
