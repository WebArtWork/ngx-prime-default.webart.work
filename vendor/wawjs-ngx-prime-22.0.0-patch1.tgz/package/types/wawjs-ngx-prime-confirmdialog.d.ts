import * as _angular_core from '@angular/core';
import { OnInit, AfterContentInit, OnDestroy, NgZone, TemplateRef } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { ConfirmEventType, Footer, PrimeTemplate, Confirmation } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Dialog } from '@wawjs/ngx-prime/dialog';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import { ConfirmDialogPassThrough, ConfirmDialogMessageTemplateContext, ConfirmDialogHeadlessTemplateContext } from '@wawjs/ngx-prime/types/confirmdialog';
export * from '@wawjs/ngx-prime/types/confirmdialog';
import { Subscription } from 'rxjs';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class ConfirmDialogStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: string;
        icon: string;
        message: string;
        pcRejectButton: string;
        pcAcceptButton: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ConfirmDialogStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ConfirmDialogStyle>;
}
/**
 *
 * ConfirmDialog uses a Dialog UI with confirmDialog method or <ConfirmDialog> tag.
 *
 * [Live Demo](https://www.ngx-prime.org/confirmdialog)
 *
 * @module confirmdialogstyle
 *
 */
declare enum ConfirmDialogClasses {
    /**
     * Class name of the root element
     */
    root = "p-confirmdialog",
    /**
     * Class name of the icon element
     */
    icon = "p-confirmdialog-icon",
    /**
     * Class name of the message element
     */
    message = "p-confirmdialog-message",
    /**
     * Class name of the reject button element
     */
    pcRejectButton = "p-confirmdialog-reject-button",
    /**
     * Class name of the accept button element
     */
    pcAcceptButton = "p-confirmdialog-accept-button"
}

/**
 * ConfirmDialog uses a Dialog UI that is integrated with the Confirmation API.
 * @group Components
 */
declare class ConfirmDialog extends BaseComponent<ConfirmDialogPassThrough> implements OnInit, AfterContentInit, OnDestroy {
    private confirmationService;
    zone: NgZone;
    componentName: string;
    $pcConfirmDialog: ConfirmDialog | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Title text of the dialog.
     * @group Props
     */
    readonly header: _angular_core.InputSignal<string | undefined>;
    /**
     * Icon to display next to message.
     * @group Props
     */
    readonly icon: _angular_core.InputSignal<string | undefined>;
    /**
     * Message of the confirmation.
     * @group Props
     */
    readonly message: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the element.
     * @group Props
     */
    style: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Class of the element.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Specify the CSS class(es) for styling the mask element
     * @group Props
     */
    maskStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Icon of the accept button.
     * @group Props
     */
    readonly acceptIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Label of the accept button.
     * @group Props
     */
    readonly acceptLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the close button for accessibility.
     * @group Props
     */
    closeAriaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the accept button for accessibility.
     * @group Props
     */
    acceptAriaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Visibility of the accept button.
     * @group Props
     */
    readonly acceptVisible: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Icon of the reject button.
     * @group Props
     */
    readonly rejectIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Label of the reject button.
     * @group Props
     */
    readonly rejectLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the reject button for accessibility.
     * @group Props
     */
    rejectAriaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Visibility of the reject button.
     * @group Props
     */
    readonly rejectVisible: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Style class of the accept button.
     * @group Props
     */
    readonly acceptButtonStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the reject button.
     * @group Props
     */
    readonly rejectButtonStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Specifies if pressing escape key should hide the dialog.
     * @group Props
     */
    readonly closeOnEscape: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Specifies if clicking the modal background should hide the dialog.
     * @group Props
     */
    readonly dismissableMask: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Determines whether scrolling behavior should be blocked within the component.
     * @group Props
     */
    readonly blockScroll: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When enabled dialog is displayed in RTL direction.
     * @group Props
     */
    rtl: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Adds a close icon to the header to hide the dialog.
     * @group Props
     */
    readonly closable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'body'
     * @group Props
     */
    appendTo: _angular_core.InputSignal<any>;
    /**
     * Optional key to match the key of confirm object, necessary to use when component tree has multiple confirm dialogs.
     * @group Props
     */
    readonly key: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to automatically manage layering.
     * @group Props
     */
    autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Base zIndex value to use in layering.
     * @group Props
     */
    baseZIndex: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Transition options of the animation.
     * @group Props
     */
    transitionOptions: _angular_core.InputSignal<string>;
    /**
     * When enabled, can only focus on elements inside the confirm dialog.
     * @group Props
     */
    focusTrap: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Element to receive the focus when the dialog gets visible.
     * @group Props
     */
    readonly defaultFocus: _angular_core.InputSignal<"accept" | "reject" | "close" | "none">;
    /**
     * Object literal to define widths per screen size.
     * @group Props
     */
    breakpoints: _angular_core.InputSignal<any>;
    /**
     * Defines if background should be blocked when dialog is displayed.
     * @group Props
     */
    readonly modal: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Current visible state as a boolean.
     * @group Props
     */
    visible: _angular_core.ModelSignal<any>;
    /**
     *  Allows getting the position of the component.
     * @group Props
     */
    readonly position: _angular_core.InputSignal<"center" | "top" | "bottom" | "left" | "right" | "topleft" | "topright" | "bottomleft" | "bottomright">;
    /**
     * Enables dragging to change the position using header.
     * @group Props
     */
    draggable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Callback to invoke when dialog is hidden.
     * @param {ConfirmEventType} enum - Custom confirm event.
     * @group Emits
     */
    onHide: _angular_core.OutputEmitterRef<ConfirmEventType>;
    readonly footer: _angular_core.Signal<Footer | undefined>;
    _componentStyle: ConfirmDialogStyle;
    /**
     * Custom header template.
     * @group Templates
     */
    headerTemplate: Nullable<TemplateRef<void>>;
    /**
     * Custom footer template.
     * @group Templates
     */
    footerTemplate: Nullable<TemplateRef<void>>;
    /**
     * Custom reject icon template.
     * @group Templates
     */
    readonly rejectIconTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom accept icon template.
     * @group Templates
     */
    readonly acceptIconTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom message template.
     * @group Templates
     */
    messageTemplate: Nullable<TemplateRef<ConfirmDialogMessageTemplateContext>>;
    /**
     * Custom icon template.
     * @group Templates
     */
    iconTemplate: Nullable<TemplateRef<void>>;
    /**
     * Custom headless template.
     * @group Templates
     */
    headlessTemplate: Nullable<TemplateRef<ConfirmDialogHeadlessTemplateContext>>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    $appendTo: _angular_core.Signal<any>;
    _headerTemplate: TemplateRef<void> | undefined;
    _footerTemplate: TemplateRef<void> | undefined;
    _rejectIconTemplate: TemplateRef<void> | undefined;
    _acceptIconTemplate: TemplateRef<void> | undefined;
    _messageTemplate: TemplateRef<ConfirmDialogMessageTemplateContext> | undefined;
    _iconTemplate: TemplateRef<void> | undefined;
    _headlessTemplate: TemplateRef<ConfirmDialogHeadlessTemplateContext> | undefined;
    confirmation: Nullable<Confirmation>;
    maskVisible: boolean | undefined;
    dialog: Nullable<Dialog>;
    wrapper: Nullable<HTMLElement>;
    contentContainer: Nullable<HTMLDivElement>;
    subscription: Subscription;
    preWidth: number | undefined;
    styleElement: any;
    id: string;
    ariaLabelledBy: string | null;
    translationSubscription: Subscription | undefined;
    constructor();
    onInit(): void;
    onAfterContentInit(): void;
    getAriaLabelledBy(): string | null;
    option(name: string, k?: string): any;
    getButtonStyleClass(cx: string, opt: string): string;
    getElementToFocus(): Element | null | undefined;
    createStyle(): void;
    close(): void;
    hide(type?: ConfirmEventType): void;
    onDialogHide(): void;
    destroyStyle(): void;
    onDestroy(): void;
    onVisibleChange(value: boolean): void;
    onAccept(): void;
    onReject(): void;
    unsubscribeConfirmationEvents(): void;
    get acceptButtonLabel(): string;
    get rejectButtonLabel(): string;
    getAcceptButtonProps(): any;
    getRejectButtonProps(): any;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ConfirmDialog, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ConfirmDialog, "p-confirmDialog, p-confirmdialog, p-confirm-dialog", never, { "header": { "alias": "header"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "message": { "alias": "message"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "maskStyleClass": { "alias": "maskStyleClass"; "required": false; "isSignal": true; }; "acceptIcon": { "alias": "acceptIcon"; "required": false; "isSignal": true; }; "acceptLabel": { "alias": "acceptLabel"; "required": false; "isSignal": true; }; "closeAriaLabel": { "alias": "closeAriaLabel"; "required": false; "isSignal": true; }; "acceptAriaLabel": { "alias": "acceptAriaLabel"; "required": false; "isSignal": true; }; "acceptVisible": { "alias": "acceptVisible"; "required": false; "isSignal": true; }; "rejectIcon": { "alias": "rejectIcon"; "required": false; "isSignal": true; }; "rejectLabel": { "alias": "rejectLabel"; "required": false; "isSignal": true; }; "rejectAriaLabel": { "alias": "rejectAriaLabel"; "required": false; "isSignal": true; }; "rejectVisible": { "alias": "rejectVisible"; "required": false; "isSignal": true; }; "acceptButtonStyleClass": { "alias": "acceptButtonStyleClass"; "required": false; "isSignal": true; }; "rejectButtonStyleClass": { "alias": "rejectButtonStyleClass"; "required": false; "isSignal": true; }; "closeOnEscape": { "alias": "closeOnEscape"; "required": false; "isSignal": true; }; "dismissableMask": { "alias": "dismissableMask"; "required": false; "isSignal": true; }; "blockScroll": { "alias": "blockScroll"; "required": false; "isSignal": true; }; "rtl": { "alias": "rtl"; "required": false; "isSignal": true; }; "closable": { "alias": "closable"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "key": { "alias": "key"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "transitionOptions": { "alias": "transitionOptions"; "required": false; "isSignal": true; }; "focusTrap": { "alias": "focusTrap"; "required": false; "isSignal": true; }; "defaultFocus": { "alias": "defaultFocus"; "required": false; "isSignal": true; }; "breakpoints": { "alias": "breakpoints"; "required": false; "isSignal": true; }; "modal": { "alias": "modal"; "required": false; "isSignal": true; }; "visible": { "alias": "visible"; "required": false; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; "draggable": { "alias": "draggable"; "required": false; "isSignal": true; }; }, { "visible": "visibleChange"; "onHide": "onHide"; }, ["footer", "rejectIconTemplate", "acceptIconTemplate", "templates", "headerTemplate", "footerTemplate", "messageTemplate", "iconTemplate", "headlessTemplate"], ["p-footer"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class ConfirmDialogModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ConfirmDialogModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<ConfirmDialogModule, never, [typeof ConfirmDialog, typeof i2.SharedModule], [typeof ConfirmDialog, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<ConfirmDialogModule>;
}

export { ConfirmDialog, ConfirmDialogClasses, ConfirmDialogModule, ConfirmDialogStyle };
