import { TerminalPassThrough } from '@wawjs/ngx-prime/types/terminal';
export * from '@wawjs/ngx-prime/types/terminal';
import * as i0 from '@angular/core';
import { AfterViewInit, AfterViewChecked, OnDestroy, ElementRef } from '@angular/core';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import * as rxjs from 'rxjs';
import { Subscription } from 'rxjs';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i2 from '@wawjs/ngx-prime/api';

declare class TerminalStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: () => string[];
        welcomeMessage: string;
        commandList: string;
        command: string;
        commandValue: string;
        commandResponse: string;
        prompt: string;
        promptLabel: string;
        promptValue: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<TerminalStyle, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TerminalStyle>;
}
/**
 *
 * Terminal is a text based user interface.
 *
 * [Live Demo](https://www.ngx-prime.org/terminal)
 *
 * @module terminalstyle
 *
 */
declare enum TerminalClasses {
    /**
     * Class name of the root element
     */
    root = "p-terminal",
    /**
     * Class name of the welcome message element
     */
    welcomeMessage = "p-terminal-welcome-message",
    /**
     * Class name of the command list element
     */
    commandList = "p-terminal-command-list",
    /**
     * Class name of the command element
     */
    command = "p-terminal-command",
    /**
     * Class name of the command value element
     */
    commandValue = "p-terminal-command-value",
    /**
     * Class name of the command response element
     */
    commandResponse = "p-terminal-command-response",
    /**
     * Class name of the prompt element
     */
    prompt = "p-terminal-prompt",
    /**
     * Class name of the prompt label element
     */
    promptLabel = "p-terminal-prompt-label",
    /**
     * Class name of the prompt value element
     */
    promptValue = "p-terminal-prompt-value"
}

declare class TerminalService {
    private commandSource;
    private responseSource;
    commandHandler: rxjs.Observable<string>;
    responseHandler: rxjs.Observable<string>;
    sendCommand(command: string): void;
    sendResponse(response: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TerminalService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TerminalService>;
}

/**
 * Terminal is a text based user interface.
 * @group Components
 */
declare class Terminal extends BaseComponent<TerminalPassThrough> implements AfterViewInit, AfterViewChecked, OnDestroy {
    terminalService: TerminalService;
    componentName: string;
    $pcTerminal: Terminal | undefined;
    bindDirectiveInstance: Bind;
    /**
     * Initial text to display on terminal.
     * @group Props
     */
    welcomeMessage: i0.InputSignal<string | undefined>;
    /**
     * Prompt text for each command.
     * @group Props
     */
    prompt: i0.InputSignal<string | undefined>;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: i0.InputSignal<string | undefined>;
    /**
     * Response to display for the last command.
     * @group Props
     */
    response: i0.InputSignal<string | undefined>;
    commands: any[];
    command: string;
    container: Element;
    commandProcessed: boolean;
    subscription: Subscription;
    _componentStyle: TerminalStyle;
    readonly inputRef: i0.Signal<ElementRef<HTMLInputElement>>;
    onHostClick(): void;
    constructor();
    onAfterViewInit(): void;
    onAfterViewChecked(): void;
    handleCommand(event: KeyboardEvent): void;
    focus(element: HTMLElement): void;
    onDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<Terminal, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Terminal, "p-terminal", never, { "welcomeMessage": { "alias": "welcomeMessage"; "required": false; "isSignal": true; }; "prompt": { "alias": "prompt"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "response": { "alias": "response"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class TerminalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TerminalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TerminalModule, never, [typeof Terminal, typeof i2.SharedModule], [typeof Terminal, typeof i2.SharedModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TerminalModule>;
}

export { Terminal, TerminalClasses, TerminalModule, TerminalService, TerminalStyle };
