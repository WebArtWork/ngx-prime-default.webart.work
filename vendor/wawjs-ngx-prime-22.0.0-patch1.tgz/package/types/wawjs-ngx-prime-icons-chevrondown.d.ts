import { BaseIcon } from '@wawjs/ngx-prime/icons/baseicon';
import * as i0 from '@angular/core';

declare class ChevronDownIcon extends BaseIcon {
    static ɵfac: i0.ɵɵFactoryDeclaration<ChevronDownIcon, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChevronDownIcon, "[data-p-icon=\"chevron-down\"]", never, {}, {}, never, never, true, never>;
}

export { ChevronDownIcon };
