import * as _angular_core from '@angular/core';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { OverlayBadgePassThrough } from '@wawjs/ngx-prime/types/overlaybadge';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i2 from '@wawjs/ngx-prime/api';

declare class OverlayBadgeStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OverlayBadgeStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<OverlayBadgeStyle>;
}

/**
 * OverlayPanel is a container component positioned as connected to its target.
 * @group Components
 */
declare class OverlayBadge extends BaseComponent<OverlayBadgePassThrough> {
    componentName: string;
    $pcOverlayBadge: OverlayBadge | undefined;
    bindDirectiveInstance: Bind;
    /**
     * Class of the element.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the element.
     * @group Props
     */
    style: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Size of the badge, valid options are "large" and "xlarge".
     * @group Props
     */
    badgeSize: _angular_core.InputSignal<"small" | "large" | "xlarge" | null | undefined>;
    /**
     * Severity type of the badge.
     * @group Props
     */
    severity: _angular_core.InputSignal<"secondary" | "info" | "success" | "warn" | "danger" | "contrast" | null | undefined>;
    /**
     * Value to display inside the badge.
     * @group Props
     */
    value: _angular_core.InputSignal<string | number | null | undefined>;
    /**
     * When specified, disables the component.
     * @group Props
     */
    badgeDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Size of the badge, valid options are "large" and "xlarge".
     * @group Props
     * @deprecated use badgeSize instead.
     */
    size: _angular_core.InputSignal<"small" | "large" | "xlarge" | null | undefined>;
    onAfterViewChecked(): void;
    _componentStyle: OverlayBadgeStyle;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OverlayBadge, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<OverlayBadge, "p-overlayBadge, p-overlay-badge, p-overlaybadge", never, { "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "badgeSize": { "alias": "badgeSize"; "required": false; "isSignal": true; }; "severity": { "alias": "severity"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "badgeDisabled": { "alias": "badgeDisabled"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class OverlayBadgeModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OverlayBadgeModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<OverlayBadgeModule, never, [typeof OverlayBadge, typeof i2.SharedModule], [typeof OverlayBadge, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<OverlayBadgeModule>;
}

export { OverlayBadge, OverlayBadgeModule, OverlayBadgeStyle };
