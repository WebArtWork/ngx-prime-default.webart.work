import { AutoCompletePassThrough, AutoCompleteCompleteEvent, AutoCompleteSelectEvent, AutoCompleteUnselectEvent, AutoCompleteAddEvent, AutoCompleteDropdownClickEvent, AutoCompleteLazyLoadEvent, AutoCompleteItemTemplateContext, AutoCompleteSelectedItemTemplateContext, AutoCompleteGroupTemplateContext, AutoCompleteLoaderTemplateContext, AutoCompleteRemoveIconTemplateContext } from '@wawjs/ngx-prime/types/autocomplete';
export * from '@wawjs/ngx-prime/types/autocomplete';
import * as _angular_core from '@angular/core';
import { ElementRef, TemplateRef } from '@angular/core';
import { MotionOptions } from '@wawjs/css-prime-motion';
import * as i2 from '@wawjs/ngx-prime/api';
import { OverlayService, ScrollerOptions, OverlayOptions, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseInput } from '@wawjs/ngx-prime/baseinput';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { ConnectedOverlayScrollHandler } from '@wawjs/ngx-prime/dom';
import { Overlay } from '@wawjs/ngx-prime/overlay';
import { Scroller } from '@wawjs/ngx-prime/scroller';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class AutoCompleteStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-invalid': any;
            'p-focus': any;
            'p-inputwrapper-filled': any;
            'p-inputwrapper-focus': any;
            'p-autocomplete-open': any;
            'p-autocomplete-clearable': any;
            'p-autocomplete-fluid': any;
        })[];
        pcInputText: string;
        inputMultiple: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-disabled': any;
            'p-variant-filled': boolean;
        })[];
        chipItem: ({ instance, i }: {
            instance: any;
            i: any;
        }) => (string | {
            'p-focus': boolean;
        })[];
        pcChip: string;
        chipIcon: string;
        inputChip: string;
        loader: string;
        dropdown: string;
        overlay: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-input-filled': boolean;
            'p-ripple-disabled': boolean;
        })[];
        listContainer: string;
        list: string;
        optionGroup: string;
        option: ({ instance, option, i, scrollerOptions }: {
            instance: any;
            option: any;
            i: any;
            scrollerOptions: any;
        }) => {
            'p-autocomplete-option': boolean;
            'p-autocomplete-option-selected': any;
            'p-focus': boolean;
            'p-disabled': any;
        };
        emptyMessage: string;
        clearIcon: string;
    };
    inlineStyles: {
        root: {
            position: string;
        };
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AutoCompleteStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<AutoCompleteStyle>;
}
/**
 *
 * AutoComplete is an input component that provides real-time suggestions while being typed.
 *
 * [Live Demo](https://www.ngx-prime.org/autocomplete/)
 *
 * @module autocompletestyle
 *
 */
declare enum AutoCompleteClasses {
    /**
     * Class name of the root element
     */
    root = "p-autocomplete",
    /**
     * Class name of the input element
     */
    pcInputText = "p-autocomplete-input",
    /**
     * Class name of the input multiple element
     */
    inputMultiple = "p-autocomplete-input-multiple",
    /**
     * Class name of the chip item element
     */
    chipItem = "p-autocomplete-chip-item",
    /**
     * Class name of the chip element
     */
    pcChip = "p-autocomplete-chip",
    /**
     * Class name of the chip icon element
     */
    chipIcon = "p-autocomplete-chip-icon",
    /**
     * Class name of the input chip element
     */
    inputChip = "p-autocomplete-input-chip",
    /**
     * Class name of the loader element
     */
    loader = "p-autocomplete-loader",
    /**
     * Class name of the dropdown element
     */
    dropdown = "p-autocomplete-dropdown",
    /**
     * Class name of the panel element
     */
    panel = "p-autocomplete-overlay",
    /**
     * Class name of the list element
     */
    list = "p-autocomplete-list",
    /**
     * Class name of the option group element
     */
    optionGroup = "p-autocomplete-option-group",
    /**
     * Class name of the option element
     */
    option = "p-autocomplete-option",
    /**
     * Class name of the empty message element
     */
    emptyMessage = "p-autocomplete-empty-message",
    /**
     * Class name of the clear icon
     */
    clearIcon = "p-autocomplete-clear-icon"
}

declare const AUTOCOMPLETE_VALUE_ACCESSOR: any;
/**
 * AutoComplete is an input component that provides real-time suggestions when being typed.
 * @group Components
 */
declare class AutoComplete extends BaseInput<AutoCompletePassThrough> {
    overlayService: OverlayService;
    private zone;
    componentName: string;
    $pcAutoComplete: AutoComplete | undefined;
    bindDirectiveInstance: Bind;
    /**
     * Minimum number of characters to initiate a search.
     * @deprecated since v20.0.0, use `minQueryLength` instead.
     * @group Props
     */
    readonly minLength: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Minimum number of characters to initiate a search.
     * @group Props
     */
    readonly minQueryLength: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Delay between keystrokes to wait before sending a query.
     * @group Props
     */
    readonly delay: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Inline style of the overlay panel element.
     * @group Props
     */
    readonly panelStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    readonly styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the overlay panel element.
     * @group Props
     */
    readonly panelStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the input field.
     * @group Props
     */
    readonly inputStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Identifier of the focus input to match a label defined for the component.
     * @group Props
     */
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the input field.
     * @group Props
     */
    readonly inputStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Hint text for the input field.
     * @group Props
     */
    readonly placeholder: _angular_core.InputSignal<string | undefined>;
    /**
     * When present, it specifies that the input cannot be typed.
     * @group Props
     */
    readonly readonly: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Maximum height of the suggestions panel.
     * @group Props
     */
    readonly scrollHeight: _angular_core.InputSignal<string>;
    /**
     * Defines if data is loaded and interacted with in lazy manner.
     * @group Props
     */
    readonly lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether the data should be loaded on demand during scroll.
     * @group Props
     */
    readonly virtualScroll: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Height of an item in the list for VirtualScrolling.
     * @group Props
     */
    readonly virtualScrollItemSize: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Whether to use the scroller feature. The properties of scroller component can be used like an object in it.
     * @group Props
     */
    readonly virtualScrollOptions: _angular_core.InputSignal<ScrollerOptions | undefined>;
    /**
     * When enabled, highlights the first item in the list by default.
     * @group Props
     */
    readonly autoHighlight: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When present, autocomplete clears the manual input if it does not match of the suggestions to force only accepting values from the suggestions.
     * @group Props
     */
    readonly forceSelection: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Type of the input, defaults to "text".
     * @group Props
     */
    readonly type: _angular_core.InputSignal<string>;
    /**
     * Whether to automatically manage layering.
     * @group Props
     */
    readonly autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Base zIndex value to use in layering.
     * @group Props
     */
    readonly baseZIndex: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Defines a string that labels the input for accessibility.
     * @group Props
     */
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the dropdown button for accessibility.
     * @group Props
     */
    readonly dropdownAriaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Specifies one or more IDs in the DOM that labels the input field.
     * @group Props
     */
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Icon class of the dropdown icon.
     * @group Props
     */
    readonly dropdownIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Ensures uniqueness of selected items on multiple mode.
     * @group Props
     */
    readonly unique: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to display options as grouped when nested options are provided.
     * @group Props
     */
    readonly group: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Whether to run a query when input receives focus.
     * @group Props
     */
    readonly completeOnFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When enabled, a clear icon is displayed to clear the value.
     * @group Props
     */
    readonly showClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Displays a button next to the input field when enabled.
     * @group Props
     */
    readonly dropdown: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Whether to show the empty message or not.
     * @group Props
     */
    readonly showEmptyMessage: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Specifies the behavior dropdown button. Default "blank" mode sends an empty string and "current" mode sends the input value.
     * @group Props
     */
    readonly dropdownMode: _angular_core.InputSignal<string>;
    /**
     * Specifies if multiple values can be selected.
     * @group Props
     */
    readonly multiple: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When enabled, the input value is added to the selected items on tab key press when multiple is true and typeahead is false.
     * @group Props
     */
    readonly addOnTab: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    readonly tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * A property to uniquely identify a value in options.
     * @group Props
     */
    readonly dataKey: _angular_core.InputSignal<string | undefined>;
    /**
     * Text to display when there is no data. Defaults to global value in i18n translation configuration.
     * @group Props
     */
    readonly emptyMessage: _angular_core.InputSignal<string | undefined>;
    /**
     * Transition options of the show animation.
     * @group Props
     * @deprecated since v21.0.0, use `motionOptions` instead.
     */
    readonly showTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * Transition options of the hide animation.
     * @group Props
     * @deprecated since v21.0.0, use `motionOptions` instead.
     */
    readonly hideTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Used to define a string that autocomplete attribute the current element.
     * @group Props
     */
    readonly autocomplete: _angular_core.InputSignal<string>;
    /**
     * Name of the options field of an option group.
     * @group Props
     */
    readonly optionGroupChildren: _angular_core.InputSignal<string | undefined>;
    /**
     * Name of the label field of an option group.
     * @group Props
     */
    readonly optionGroupLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Options for the overlay element.
     * @group Props
     */
    readonly overlayOptions: _angular_core.InputSignal<OverlayOptions | undefined>;
    /**
     * An array of suggestions to display.
     * @group Props
     */
    readonly suggestions: _angular_core.InputSignal<any[] | undefined>;
    /**
     * Property name or getter function to use as the label of an option.
     * @group Props
     */
    readonly optionLabel: _angular_core.InputSignal<string | ((item: any) => string) | undefined>;
    /**
     * Property name or getter function to use as the value of an option.
     * @group Props
     */
    readonly optionValue: _angular_core.InputSignal<string | ((item: any) => string) | undefined>;
    /**
     * Unique identifier of the component.
     * @group Props
     */
    readonly id: _angular_core.InputSignal<string | undefined>;
    private _generatedId;
    get resolvedId(): string;
    /**
     * Text to display when the search is active. Defaults to global value in i18n translation configuration.
     * @group Props
     * @defaultValue '{0} results are available'
     */
    readonly searchMessage: _angular_core.InputSignal<string | undefined>;
    /**
     * Text to display when filtering does not return any results. Defaults to global value in i18n translation configuration.
     * @group Props
     * @defaultValue 'No selected item'
     */
    readonly emptySelectionMessage: _angular_core.InputSignal<string | undefined>;
    /**
     * Text to be displayed in hidden accessible field when options are selected. Defaults to global value in i18n translation configuration.
     * @group Props
     * @defaultValue '{0} items selected'
     */
    readonly selectionMessage: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to focus on the first visible or selected element when the overlay panel is shown.
     * @group Props
     */
    readonly autoOptionFocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When enabled, the focused option is selected.
     * @group Props
     */
    readonly selectOnFocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Locale to use in searching. The default locale is the host environment's current locale.
     * @group Props
     */
    readonly searchLocale: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Property name or getter function to use as the disabled flag of an option, defaults to false when not defined.
     * @group Props
     */
    readonly optionDisabled: _angular_core.InputSignal<string | ((item: any) => string) | undefined>;
    /**
     * When enabled, the hovered option will be focused.
     * @group Props
     */
    readonly focusOnHover: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Whether typeahead is active or not.
     * @defaultValue true
     * @group Props
     */
    readonly typeahead: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to add an item on blur event if the input has value and typeahead is false with multiple mode.
     * @defaultValue false
     * @group Props
     */
    readonly addOnBlur: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Separator char to add item when typeahead is false and multiple mode is enabled.
     * @group Props
     */
    readonly separator: _angular_core.InputSignal<string | RegExp | undefined>;
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'self'
     * @group Props
     */
    appendTo: _angular_core.InputSignal<any>;
    /**
     * The motion options.
     * @group Props
     */
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    /**
     * Callback to invoke to search for suggestions.
     * @param {AutoCompleteCompleteEvent} event - Custom complete event.
     * @group Emits
     */
    completeMethod: _angular_core.OutputEmitterRef<AutoCompleteCompleteEvent>;
    /**
     * Callback to invoke when a suggestion is selected.
     * @param {AutoCompleteSelectEvent} event - custom select event.
     * @group Emits
     */
    onSelect: _angular_core.OutputEmitterRef<AutoCompleteSelectEvent>;
    /**
     * Callback to invoke when a selected value is removed.
     * @param {AutoCompleteUnselectEvent} event - custom unselect event.
     * @group Emits
     */
    onUnselect: _angular_core.OutputEmitterRef<AutoCompleteUnselectEvent>;
    /**
     * Callback to invoke when an item is added via addOnBlur or separator features.
     * @param {AutoCompleteAddEvent} event - Custom add event.
     * @group Emits
     */
    onAdd: _angular_core.OutputEmitterRef<AutoCompleteAddEvent>;
    /**
     * Callback to invoke when the component receives focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onFocus: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke when the component loses focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onBlur: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke to when dropdown button is clicked.
     * @param {AutoCompleteDropdownClickEvent} event - custom dropdown click event.
     * @group Emits
     */
    onDropdownClick: _angular_core.OutputEmitterRef<AutoCompleteDropdownClickEvent>;
    /**
     * Callback to invoke when clear button is clicked.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onClear: _angular_core.OutputEmitterRef<Event | undefined>;
    /**
     * Callback to invoke on input key down.
     * @param {KeyboardEvent} event - Keyboard event.
     * @group Emits
     */
    onInputKeydown: _angular_core.OutputEmitterRef<KeyboardEvent>;
    /**
     * Callback to invoke on input key up.
     * @param {KeyboardEvent} event - Keyboard event.
     * @group Emits
     */
    onKeyUp: _angular_core.OutputEmitterRef<KeyboardEvent>;
    /**
     * Callback to invoke on overlay is shown.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onShow: _angular_core.OutputEmitterRef<Event | undefined>;
    /**
     * Callback to invoke on overlay is hidden.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onHide: _angular_core.OutputEmitterRef<Event | undefined>;
    /**
     * Callback to invoke on lazy load data.
     * @param {AutoCompleteLazyLoadEvent} event - Lazy load event.
     * @group Emits
     */
    onLazyLoad: _angular_core.OutputEmitterRef<AutoCompleteLazyLoadEvent>;
    readonly inputEL: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly multiInputEl: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly multiContainerEL: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly dropdownButton: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly itemsViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly scroller: _angular_core.Signal<Nullable<Scroller>>;
    readonly overlayViewChild: _angular_core.Signal<Overlay>;
    itemsWrapper: Nullable<HTMLDivElement>;
    /**
     * Custom item template.
     * @group Templates
     */
    readonly itemTemplate: _angular_core.Signal<Nullable<TemplateRef<AutoCompleteItemTemplateContext<any>>>>;
    /**
     * Custom empty message template.
     * @group Templates
     */
    readonly emptyTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom header template.
     * @group Templates
     */
    readonly headerTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom footer template.
     * @group Templates
     */
    readonly footerTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom selected item template.
     * @group Templates
     */
    readonly selectedItemTemplate: _angular_core.Signal<Nullable<TemplateRef<AutoCompleteSelectedItemTemplateContext<any>>>>;
    /**
     * Custom group template.
     * @group Templates
     */
    readonly groupTemplate: _angular_core.Signal<Nullable<TemplateRef<AutoCompleteGroupTemplateContext<any>>>>;
    /**
     * Custom loader template.
     * @group Templates
     */
    loaderTemplate: Nullable<TemplateRef<AutoCompleteLoaderTemplateContext>>;
    /**
     * Custom remove icon template.
     * @group Templates
     */
    removeIconTemplate: Nullable<TemplateRef<AutoCompleteRemoveIconTemplateContext>>;
    /**
     * Custom loading icon template.
     * @group Templates
     */
    loadingIconTemplate: Nullable<TemplateRef<void>>;
    /**
     * Custom clear icon template.
     * @group Templates
     */
    clearIconTemplate: Nullable<TemplateRef<void>>;
    /**
     * Custom dropdown icon template.
     * @group Templates
     */
    readonly dropdownIconTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    onHostClick(event: MouseEvent): void;
    value: string | any;
    _suggestions: _angular_core.WritableSignal<any>;
    timeout: Nullable<any>;
    overlayVisible: boolean | undefined;
    suggestionsUpdated: Nullable<boolean>;
    highlightOption: any;
    highlightOptionChanged: Nullable<boolean>;
    focused: boolean;
    loading: Nullable<boolean>;
    scrollHandler: Nullable<ConnectedOverlayScrollHandler>;
    listId: string | undefined;
    searchTimeout: any;
    dirty: boolean;
    _itemTemplate: TemplateRef<AutoCompleteItemTemplateContext> | undefined;
    _groupTemplate: TemplateRef<AutoCompleteGroupTemplateContext> | undefined;
    _selectedItemTemplate: TemplateRef<AutoCompleteSelectedItemTemplateContext> | undefined;
    _headerTemplate: TemplateRef<void> | undefined;
    _emptyTemplate: TemplateRef<void> | undefined;
    _footerTemplate: TemplateRef<void> | undefined;
    _loaderTemplate: TemplateRef<AutoCompleteLoaderTemplateContext> | undefined;
    _removeIconTemplate: TemplateRef<AutoCompleteRemoveIconTemplateContext> | undefined;
    _loadingIconTemplate: TemplateRef<void> | undefined;
    _clearIconTemplate: TemplateRef<void> | undefined;
    _dropdownIconTemplate: TemplateRef<void> | undefined;
    focusedMultipleOptionIndex: _angular_core.WritableSignal<number>;
    focusedOptionIndex: _angular_core.WritableSignal<number>;
    _componentStyle: AutoCompleteStyle;
    $appendTo: _angular_core.Signal<any>;
    visibleOptions: _angular_core.Signal<any>;
    inputValue: _angular_core.Signal<any>;
    get focusedMultipleOptionId(): string | null;
    get focusedOptionId(): string | null;
    get searchResultMessageText(): string;
    get searchMessageText(): string;
    get emptySearchMessageText(): string;
    get selectionMessageText(): string;
    get emptySelectionMessageText(): string;
    get selectedMessageText(): string;
    get ariaSetSize(): any;
    get listLabel(): string;
    get virtualScrollerDisabled(): boolean;
    get optionValueSelected(): string | false | ((item: any) => string) | undefined;
    chipItemClass(index: any): (string | {
        'p-focus': boolean;
    })[];
    constructor();
    onInit(): void;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    onAfterContentInit(): void;
    onAfterViewChecked(): void;
    handleSuggestionsChange(): void;
    flatOptions(options: any): any;
    isOptionGroup(option: any): any;
    findFirstOptionIndex(): any;
    findLastOptionIndex(): number;
    findFirstFocusedOptionIndex(): any;
    findLastFocusedOptionIndex(): any;
    findSelectedOptionIndex(): any;
    findNextOptionIndex(index: any): any;
    findPrevOptionIndex(index: any): any;
    isValidSelectedOption(option: any): any;
    isValidOption(option: any): any;
    isOptionDisabled(option: any): any;
    isSelected(option: any): boolean;
    isOptionMatched(option: any, value: any): any;
    isInputClicked(event: any): boolean;
    isDropdownClicked(event: any): any;
    equalityKey(): string | undefined;
    onContainerClick(event: any): void;
    handleDropdownClick(event: any): void;
    onInput(event: any): void;
    onInputChange(event: any): void;
    onInputFocus(event: any): void;
    onMultipleContainerFocus(): void;
    onMultipleContainerBlur(): void;
    onMultipleContainerKeyDown(event: any): void;
    onInputBlur(event: any): void;
    onInputPaste(event: any): void;
    onInputKeyUp(event: any): void;
    onKeyDown(event: any): void;
    handleSeparatorKey(event: any): void;
    onArrowDownKey(event: any): void;
    onArrowUpKey(event: any): void;
    onArrowLeftKey(event: any): void;
    onArrowRightKey(event: any): void;
    onHomeKey(event: any): void;
    onEndKey(event: any): void;
    onPageDownKey(event: any): void;
    onPageUpKey(event: any): void;
    onEnterKey(event: any): void;
    onEscapeKey(event: any): void;
    onTabKey(event: any): void;
    onBackspaceKey(event: any): void;
    onArrowLeftKeyOnMultiple(): void;
    onArrowRightKeyOnMultiple(): void;
    onBackspaceKeyOnMultiple(event: any): void;
    onOptionSelect(event: any, option: any, isHide?: boolean): void;
    onOptionMouseEnter(event: any, index: any): void;
    search(event: any, query: any, source: any): void;
    removeOption(event: any, index: any): void;
    updateModel(options: any): void;
    updateInputValue(): void;
    updateInputWithForceSelection(event: any): void;
    autoUpdateModel(): void;
    scrollInView(index?: number): void;
    changeFocusedOptionIndex(event: any, index: any): void;
    show(isFocus?: boolean): void;
    hide(isFocus?: boolean): void;
    clear(): void;
    hasSelectedOption(): boolean;
    getAriaPosInset(index: any): any;
    getOptionLabel(option: any): any;
    getOptionValue(option: any): any;
    getOptionIndex(index: any, scrollerOptions: any): any;
    getOptionGroupLabel(optionGroup: any): any;
    getOptionGroupChildren(optionGroup: any): any;
    getPTOptions(option: any, scrollerOptions: any, index: number, key: string): any;
    onOverlayBeforeEnter(): void;
    get containerDataP(): string | undefined;
    get overlayDataP(): string | undefined;
    get inputMultipleDataP(): string | undefined;
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value: any, setModelValue: (value: any) => void): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AutoComplete, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AutoComplete, "p-autoComplete, p-autocomplete, p-auto-complete", never, { "minLength": { "alias": "minLength"; "required": false; "isSignal": true; }; "minQueryLength": { "alias": "minQueryLength"; "required": false; "isSignal": true; }; "delay": { "alias": "delay"; "required": false; "isSignal": true; }; "panelStyle": { "alias": "panelStyle"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "panelStyleClass": { "alias": "panelStyleClass"; "required": false; "isSignal": true; }; "inputStyle": { "alias": "inputStyle"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "inputStyleClass": { "alias": "inputStyleClass"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "virtualScroll": { "alias": "virtualScroll"; "required": false; "isSignal": true; }; "virtualScrollItemSize": { "alias": "virtualScrollItemSize"; "required": false; "isSignal": true; }; "virtualScrollOptions": { "alias": "virtualScrollOptions"; "required": false; "isSignal": true; }; "autoHighlight": { "alias": "autoHighlight"; "required": false; "isSignal": true; }; "forceSelection": { "alias": "forceSelection"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "dropdownAriaLabel": { "alias": "dropdownAriaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "dropdownIcon": { "alias": "dropdownIcon"; "required": false; "isSignal": true; }; "unique": { "alias": "unique"; "required": false; "isSignal": true; }; "group": { "alias": "group"; "required": false; "isSignal": true; }; "completeOnFocus": { "alias": "completeOnFocus"; "required": false; "isSignal": true; }; "showClear": { "alias": "showClear"; "required": false; "isSignal": true; }; "dropdown": { "alias": "dropdown"; "required": false; "isSignal": true; }; "showEmptyMessage": { "alias": "showEmptyMessage"; "required": false; "isSignal": true; }; "dropdownMode": { "alias": "dropdownMode"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "addOnTab": { "alias": "addOnTab"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; "isSignal": true; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; "optionGroupChildren": { "alias": "optionGroupChildren"; "required": false; "isSignal": true; }; "optionGroupLabel": { "alias": "optionGroupLabel"; "required": false; "isSignal": true; }; "overlayOptions": { "alias": "overlayOptions"; "required": false; "isSignal": true; }; "suggestions": { "alias": "suggestions"; "required": false; "isSignal": true; }; "optionLabel": { "alias": "optionLabel"; "required": false; "isSignal": true; }; "optionValue": { "alias": "optionValue"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "searchMessage": { "alias": "searchMessage"; "required": false; "isSignal": true; }; "emptySelectionMessage": { "alias": "emptySelectionMessage"; "required": false; "isSignal": true; }; "selectionMessage": { "alias": "selectionMessage"; "required": false; "isSignal": true; }; "autoOptionFocus": { "alias": "autoOptionFocus"; "required": false; "isSignal": true; }; "selectOnFocus": { "alias": "selectOnFocus"; "required": false; "isSignal": true; }; "searchLocale": { "alias": "searchLocale"; "required": false; "isSignal": true; }; "optionDisabled": { "alias": "optionDisabled"; "required": false; "isSignal": true; }; "focusOnHover": { "alias": "focusOnHover"; "required": false; "isSignal": true; }; "typeahead": { "alias": "typeahead"; "required": false; "isSignal": true; }; "addOnBlur": { "alias": "addOnBlur"; "required": false; "isSignal": true; }; "separator": { "alias": "separator"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; }, { "completeMethod": "completeMethod"; "onSelect": "onSelect"; "onUnselect": "onUnselect"; "onAdd": "onAdd"; "onFocus": "onFocus"; "onBlur": "onBlur"; "onDropdownClick": "onDropdownClick"; "onClear": "onClear"; "onInputKeydown": "onInputKeydown"; "onKeyUp": "onKeyUp"; "onShow": "onShow"; "onHide": "onHide"; "onLazyLoad": "onLazyLoad"; }, ["itemTemplate", "emptyTemplate", "headerTemplate", "footerTemplate", "selectedItemTemplate", "groupTemplate", "dropdownIconTemplate", "templates", "loaderTemplate", "removeIconTemplate", "loadingIconTemplate", "clearIconTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class AutoCompleteModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AutoCompleteModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<AutoCompleteModule, never, [typeof AutoComplete, typeof i2.SharedModule], [typeof AutoComplete, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<AutoCompleteModule>;
}

export { AUTOCOMPLETE_VALUE_ACCESSOR, AutoComplete, AutoCompleteClasses, AutoCompleteModule, AutoCompleteStyle };
