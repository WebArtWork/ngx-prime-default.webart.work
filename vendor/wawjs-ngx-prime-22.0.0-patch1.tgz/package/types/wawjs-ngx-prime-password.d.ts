import { PasswordPassThrough, PasswordIconTemplateContext } from '@wawjs/ngx-prime/types/password';
export * from '@wawjs/ngx-prime/types/password';
import * as _angular_core from '@angular/core';
import { PipeTransform, ElementRef, TemplateRef, NgZone } from '@angular/core';
import { MotionOptions } from '@wawjs/css-prime-motion';
import * as i2 from '@wawjs/ngx-prime/api';
import { OverlayOptions, PrimeTemplate, OverlayService } from '@wawjs/ngx-prime/api';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import { BaseInput } from '@wawjs/ngx-prime/baseinput';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { ConnectedOverlayScrollHandler } from '@wawjs/ngx-prime/dom';
import { Fluid } from '@wawjs/ngx-prime/fluid';
import { Overlay } from '@wawjs/ngx-prime/overlay';
import { Nullable, VoidListener } from '@wawjs/ngx-prime/ts-helpers';
import { Subscription } from 'rxjs';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class PasswordStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-inputwrapper-filled': any;
            'p-variant-filled': boolean;
            'p-inputwrapper-focus': any;
            'p-password-fluid': any;
        })[];
        rootDirective: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-inputwrapper-filled': any;
            'p-variant-filled': boolean;
            'p-password-fluid-directive': any;
        })[];
        pcInputText: string;
        maskIcon: string;
        unmaskIcon: string;
        overlay: string;
        content: string;
        meter: string;
        meterLabel: ({ instance }: {
            instance: any;
        }) => string;
        meterText: string;
        clearIcon: string;
    };
    inlineStyles: {
        root: ({ instance }: {
            instance: any;
        }) => {
            position: string | undefined;
        };
        overlay: {
            position: string;
        };
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PasswordStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<PasswordStyle>;
}
/**
 *
 * Password displays strength indicator for password fields.
 *
 * [Live Demo](https://www.ngx-prime.org/password/)
 *
 * @module passwordstyle
 *
 */
declare enum PasswordClasses {
    /**
     * Class name of the root element
     */
    root = "p-password",
    /**
     * Class name of the pt input element
     */
    pcInputText = "p-password-input",
    /**
     * Class name of the mask icon element
     */
    maskIcon = "p-password-mask-icon",
    /**
     * Class name of the unmask icon element
     */
    unmaskIcon = "p-password-unmask-icon",
    /**
     * Class name of the overlay element
     */
    overlay = "p-password-overlay",
    /**
     * Class name of the meter element
     */
    meter = "p-password-meter",
    /**
     * Class name of the meter label element
     */
    meterLabel = "p-password-meter-label",
    /**
     * Class name of the meter text element
     */
    meterText = "p-password-meter-text",
    /**
     * Class name of the clear icon
     */
    clearIcon = "p-password-clear-icon"
}

type Meter = {
    strength: string;
    width: string;
};
/**
 * Adds password feedback and form integration to a native input.
 * @group Components
 */
declare class PasswordDirective extends BaseEditableHolder {
    zone: NgZone;
    bindDirectiveInstance: Bind;
    $pcPasswordDirective: PasswordDirective | undefined;
    /**
     * Used to pass attributes to DOM elements inside the Password component.
     * @defaultValue undefined
     * @group Props
     */
    pPasswordPT: _angular_core.InputSignal<PasswordPassThrough>;
    /**
     * Indicates whether the component should be rendered without styles.
     * @defaultValue undefined
     * @group Props
     */
    pPasswordUnstyled: _angular_core.InputSignal<boolean | undefined>;
    /** Signals that a Signal Forms field has been touched. */
    touch: _angular_core.OutputEmitterRef<void>;
    /** Emits when the native input receives focus. */
    onFocus: _angular_core.OutputEmitterRef<Event>;
    /** Emits when the native input loses focus. */
    onBlur: _angular_core.OutputEmitterRef<Event>;
    /** Emits whenever the password visibility changes. */
    onMaskChange: _angular_core.OutputEmitterRef<boolean>;
    /** Emits after a native password input has been cleared. */
    onClear: _angular_core.OutputEmitterRef<void>;
    onAfterViewChecked(): void;
    /**
     * Text to prompt password entry. Defaults to ngx-prime I18N API configuration.
     * @group Props
     */
    promptLabel: _angular_core.InputSignal<string>;
    /**
     * Text for a weak password. Defaults to ngx-prime I18N API configuration.
     * @group Props
     */
    weakLabel: _angular_core.InputSignal<string>;
    /**
     * Text for a medium password. Defaults to ngx-prime I18N API configuration.
     * @group Props
     */
    mediumLabel: _angular_core.InputSignal<string>;
    /**
     * Text for a strong password. Defaults to ngx-prime I18N API configuration.
     * @group Props
     */
    strongLabel: _angular_core.InputSignal<string>;
    /** Regex used to classify medium-strength passwords. */
    mediumRegex: _angular_core.InputSignal<string>;
    /** Regex used to classify strong passwords. */
    strongRegex: _angular_core.InputSignal<string>;
    /**
     * Whether to show the strength indicator or not.
     * @group Props
     */
    feedback: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Sets the visibility of the password field.
     * @defaultValue false
     * @type boolean
     * @group Props
     */
    showPassword: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Whether the native input is currently shown as plain text. */
    readonly visible: _angular_core.WritableSignal<boolean>;
    /**
     * Specifies the input variant of the component.
     * @defaultValue 'outlined'
     * @group Props
     */
    variant: _angular_core.InputSignal<"filled" | "outlined" | undefined>;
    /**
     * Spans 100% width of the container when enabled.
     * @defaultValue false
     * @group Props
     */
    fluid: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Specifies the size of the component.
     * @defaultValue undefined
     * @group Props
     */
    size: _angular_core.InputSignal<"large" | "small" | undefined>;
    pcFluid: Fluid | null;
    $variant: _angular_core.Signal<"filled" | "outlined" | null>;
    get hasFluid(): boolean;
    panel: Nullable<HTMLDivElement>;
    meter: Nullable<HTMLDivElement>;
    info: Nullable<HTMLDivElement>;
    filled: Nullable<boolean>;
    content: Nullable<HTMLDivElement>;
    label: Nullable<HTMLLabelElement>;
    scrollHandler: Nullable<ConnectedOverlayScrollHandler>;
    documentResizeListener: VoidListener;
    _componentStyle: PasswordStyle;
    constructor();
    onInput(event?: Event): void;
    createPanel(): void;
    showOverlay(): void;
    hideOverlay(): void;
    handleFocus(event?: Event): void;
    handleBlur(event?: Event): void;
    labelSignal: _angular_core.WritableSignal<string>;
    onKeyup(e: Event): void;
    updateMeter(): void;
    /** Toggles between password and plain-text display while preserving focus. */
    toggleMask(): void;
    focus(options?: FocusOptions): void;
    clear(): void;
    private setVisible;
    private updateFeedback;
    getWidth(label: string): "" | "33.33%" | "66.66%" | "100%";
    strengthClass(label: any): string;
    testStrength(str: string): number;
    normalize(x: number, y: number): number;
    bindScrollListener(): void;
    unbindScrollListener(): void;
    bindDocumentResizeListener(): void;
    unbindDocumentResizeListener(): void;
    onWindowResize(): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PasswordDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<PasswordDirective, "input[pPassword]", ["pPassword"], { "pPasswordPT": { "alias": "pPasswordPT"; "required": false; "isSignal": true; }; "pPasswordUnstyled": { "alias": "pPasswordUnstyled"; "required": false; "isSignal": true; }; "promptLabel": { "alias": "promptLabel"; "required": false; "isSignal": true; }; "weakLabel": { "alias": "weakLabel"; "required": false; "isSignal": true; }; "mediumLabel": { "alias": "mediumLabel"; "required": false; "isSignal": true; }; "strongLabel": { "alias": "strongLabel"; "required": false; "isSignal": true; }; "mediumRegex": { "alias": "mediumRegex"; "required": false; "isSignal": true; }; "strongRegex": { "alias": "strongRegex"; "required": false; "isSignal": true; }; "feedback": { "alias": "feedback"; "required": false; "isSignal": true; }; "showPassword": { "alias": "showPassword"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; "size": { "alias": "pSize"; "required": false; "isSignal": true; }; }, { "touch": "touch"; "onFocus": "onFocus"; "onBlur": "onBlur"; "onMaskChange": "onMaskChange"; "onClear": "onClear"; }, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
/**
 * Attaches an accessible visibility toggle to a native `pPassword` input.
 *
 * @example
 * ```html
 * <input pPassword #password="pPassword" />
 * <button type="button" [pPasswordToggleMask]="password">Show password</button>
 * ```
 */
declare class PasswordToggleMaskDirective {
    password: _angular_core.InputSignal<PasswordDirective>;
    showLabel: _angular_core.InputSignal<string>;
    hideLabel: _angular_core.InputSignal<string>;
    ariaLabel: _angular_core.Signal<string>;
    toggle(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PasswordToggleMaskDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<PasswordToggleMaskDirective, "button[pPasswordToggleMask]", never, { "password": { "alias": "pPasswordToggleMask"; "required": true; "isSignal": true; }; "showLabel": { "alias": "showLabel"; "required": false; "isSignal": true; }; "hideLabel": { "alias": "hideLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/** Clears a native `pPassword` input while retaining normal form semantics. */
declare class PasswordClearDirective {
    password: _angular_core.InputSignal<PasswordDirective>;
    ariaLabel: _angular_core.InputSignal<string>;
    clear(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PasswordClearDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<PasswordClearDirective, "button[pPasswordClear]", never, { "password": { "alias": "pPasswordClear"; "required": true; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
type Mapper<T, G> = (item: T, ...args: any[]) => G;
declare class MapperPipe implements PipeTransform {
    transform<T, G>(value: T, mapper: Mapper<T, G>, ...args: unknown[]): G;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MapperPipe, never>;
    static ɵpipe: _angular_core.ɵɵPipeDeclaration<MapperPipe, "mapper", true>;
}
declare const Password_VALUE_ACCESSOR: any;
/**
 * Password displays strength indicator for password fields.
 *
 * @deprecated Use a native `<input type="password" pPassword>` instead.
 * Compose optional visibility and clear controls with `pPasswordToggleMask`
 * and `pPasswordClear`. This component remains available for compatibility
 * and is planned for removal in v23.
 * @group Components
 */
declare class Password extends BaseInput<PasswordPassThrough> {
    componentName: string;
    bindDirectiveInstance: Bind;
    $pcPassword: Password | undefined;
    onAfterViewChecked(): void;
    /**
     * Defines a string that labels the input for accessibility.
     * @group Props
     */
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Specifies one or more IDs in the DOM that labels the input field.
     * @group Props
     */
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Label of the input for accessibility.
     * @group Props
     */
    label: _angular_core.InputSignal<string | undefined>;
    /**
     * Text to prompt password entry. Defaults to ngx-prime I18N API configuration.
     * @group Props
     */
    promptLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Regex value for medium regex.
     * @group Props
     */
    mediumRegex: _angular_core.InputSignal<string>;
    /**
     * Regex value for strong regex.
     * @group Props
     */
    strongRegex: _angular_core.InputSignal<string>;
    /**
     * Text for a weak password. Defaults to ngx-prime I18N API configuration.
     * @group Props
     */
    weakLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Text for a medium password. Defaults to ngx-prime I18N API configuration.
     * @group Props
     */
    mediumLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * specifies the maximum number of characters allowed in the input element.
     * @deprecated since v20.0.0, use maxlength instead.
     * @group Props
     */
    maxLength: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Text for a strong password. Defaults to ngx-prime I18N API configuration.
     * @group Props
     */
    strongLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Identifier of the accessible input element.
     * @group Props
     */
    inputId: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to show the strength indicator or not.
     * @group Props
     */
    feedback: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to show an icon to display the password as plain text.
     * @group Props
     */
    toggleMask: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Style class of the input field.
     * @group Props
     */
    inputStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the input field.
     * @group Props
     */
    inputStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Transition options of the show animation.
     * @group Props
     * @deprecated since v21.0.0, use `motionOptions` instead.
     */
    showTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * Transition options of the hide animation.
     * @group Props
     * @deprecated since v21.0.0, use `motionOptions` instead.
     */
    hideTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * Specify automated assistance in filling out password by browser.
     * @group Props
     */
    autocomplete: _angular_core.InputSignal<string | undefined>;
    /**
     * Advisory information to display on input.
     * @group Props
     */
    placeholder: _angular_core.InputSignal<string | undefined>;
    /**
     * When enabled, a clear icon is displayed to clear the value.
     * @group Props
     */
    showClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'self'
     * @group Props
     */
    appendTo: _angular_core.InputSignal<any>;
    /**
     * The motion options.
     * @group Props
     */
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    /**
     * Whether to use overlay API feature. The properties of overlay API can be used like an object in it.
     * @group Props
     */
    overlayOptions: _angular_core.InputSignal<OverlayOptions | undefined>;
    /**
     * Callback to invoke when the component receives focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onFocus: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke when the component loses focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onBlur: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke when clear button is clicked.
     * @group Emits
     */
    onClear: _angular_core.OutputEmitterRef<any>;
    readonly overlayViewChild: _angular_core.Signal<Overlay>;
    readonly input: _angular_core.Signal<ElementRef<any>>;
    /**
     * Custom template of content.
     * @group Templates
     */
    contentTemplate: Nullable<TemplateRef<void>>;
    /**
     * Custom template of footer.
     * @group Templates
     */
    readonly footerTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom template of header.
     * @group Templates
     */
    readonly headerTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom template of clear icon.
     * @group Templates
     */
    readonly clearIconTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom template of hide icon.
     * @param {PasswordIconTemplateContext} context - icon context.
     * @see {@link PasswordIconTemplateContext}
     * @group Templates
     */
    hideIconTemplate: Nullable<TemplateRef<PasswordIconTemplateContext>>;
    /**
     * Custom template of show icon.
     * @param {PasswordIconTemplateContext} context - icon context.
     * @see {@link PasswordIconTemplateContext}
     * @group Templates
     */
    showIconTemplate: Nullable<TemplateRef<PasswordIconTemplateContext>>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    $appendTo: _angular_core.Signal<any>;
    _contentTemplate: TemplateRef<void> | undefined;
    _footerTemplate: TemplateRef<void> | undefined;
    _headerTemplate: TemplateRef<void> | undefined;
    _clearIconTemplate: TemplateRef<void> | undefined;
    _hideIconTemplate: TemplateRef<PasswordIconTemplateContext> | undefined;
    _showIconTemplate: TemplateRef<PasswordIconTemplateContext> | undefined;
    overlayVisible: boolean;
    meter: Nullable<Meter>;
    infoText: Nullable<string>;
    focused: boolean;
    unmasked: boolean;
    mediumCheckRegExp: RegExp;
    strongCheckRegExp: RegExp;
    resizeListener: VoidListener;
    scrollHandler: Nullable<ConnectedOverlayScrollHandler>;
    value: Nullable<string>;
    translationSubscription: Nullable<Subscription>;
    _componentStyle: PasswordStyle;
    overlayService: OverlayService;
    onInit(): void;
    onAfterContentInit(): void;
    onInput(event: Event): void;
    onInputFocus(event: Event): void;
    onInputBlur(event: Event): void;
    onKeyUp(event: KeyboardEvent): void;
    updateUI(value: string): void;
    onMaskToggle(): void;
    onOverlayClick(event: Event): void;
    testStrength(str: string): number;
    promptText(): any;
    weakText(): any;
    mediumText(): any;
    strongText(): any;
    inputType(unmasked: boolean): "password" | "text";
    getTranslation(option: string): any;
    clear(): void;
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value: any, setModelValue: (value: any) => void): void;
    onDestroy(): void;
    get containerDataP(): string | undefined;
    get meterDataP(): string | undefined;
    get overlayDataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Password, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Password, "p-password", never, { "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "promptLabel": { "alias": "promptLabel"; "required": false; "isSignal": true; }; "mediumRegex": { "alias": "mediumRegex"; "required": false; "isSignal": true; }; "strongRegex": { "alias": "strongRegex"; "required": false; "isSignal": true; }; "weakLabel": { "alias": "weakLabel"; "required": false; "isSignal": true; }; "mediumLabel": { "alias": "mediumLabel"; "required": false; "isSignal": true; }; "maxLength": { "alias": "maxLength"; "required": false; "isSignal": true; }; "strongLabel": { "alias": "strongLabel"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "feedback": { "alias": "feedback"; "required": false; "isSignal": true; }; "toggleMask": { "alias": "toggleMask"; "required": false; "isSignal": true; }; "inputStyleClass": { "alias": "inputStyleClass"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "inputStyle": { "alias": "inputStyle"; "required": false; "isSignal": true; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; "isSignal": true; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; "isSignal": true; }; "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "showClear": { "alias": "showClear"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; "overlayOptions": { "alias": "overlayOptions"; "required": false; "isSignal": true; }; }, { "onFocus": "onFocus"; "onBlur": "onBlur"; "onClear": "onClear"; }, ["footerTemplate", "headerTemplate", "clearIconTemplate", "templates", "contentTemplate", "hideIconTemplate", "showIconTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class PasswordModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PasswordModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<PasswordModule, never, [typeof Password, typeof PasswordDirective, typeof PasswordToggleMaskDirective, typeof PasswordClearDirective, typeof i2.SharedModule, typeof i1.BindModule], [typeof PasswordDirective, typeof PasswordToggleMaskDirective, typeof PasswordClearDirective, typeof Password, typeof i2.SharedModule, typeof i1.BindModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<PasswordModule>;
}

export { MapperPipe, Password, PasswordClasses, PasswordClearDirective, PasswordDirective, PasswordModule, PasswordStyle, PasswordToggleMaskDirective, Password_VALUE_ACCESSOR };
