import { SplitButtonPassThrough, ButtonProps, MenuButtonProps } from '@wawjs/ngx-prime/types/splitbutton';
export * from '@wawjs/ngx-prime/types/splitbutton';
import * as _angular_core from '@angular/core';
import { ElementRef, TemplateRef } from '@angular/core';
import { MotionOptions } from '@wawjs/css-prime-motion';
import * as i2 from '@wawjs/ngx-prime/api';
import { MenuItem, TooltipOptions, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { TieredMenu } from '@wawjs/ngx-prime/tieredmenu';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class SplitButtonStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            [x: string]: any;
            'p-splitbutton-raised': any;
            'p-splitbutton-rounded': any;
            'p-splitbutton-outlined': any;
            'p-splitbutton-text': any;
        })[];
        pcButton: string;
        pcDropdown: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SplitButtonStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SplitButtonStyle>;
}
/**
 *
 * SplitButton groups a set of commands in an overlay with a default command.
 *
 * [Live Demo](https://www.ngx-prime.org/splitbutton/)
 *
 * @module splitbuttonstyle
 *
 */
declare enum SplitButtonClasses {
    /**
     * Class name of the root element
     */
    root = "p-splitbutton",
    /**
     * Class name of the button element
     */
    pcButton = "p-splitbutton-button",
    /**
     * Class name of the dropdown element
     */
    pcDropdown = "p-splitbutton-dropdown"
}

type SplitButtonIconPosition = 'left' | 'right';
/**
 * SplitButton groups a set of commands in an overlay with a default command.
 * @group Components
 */
declare class SplitButton extends BaseComponent<SplitButtonPassThrough> {
    componentName: string;
    $pcSplitButton: SplitButton | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * MenuModel instance to define the overlay items.
     * @group Props
     */
    model: _angular_core.InputSignal<MenuItem[] | undefined>;
    /**
     * Defines the style of the button.
     * @group Props
     */
    severity: _angular_core.InputSignal<"success" | "info" | "warn" | "danger" | "help" | "primary" | "secondary" | "contrast" | null | undefined>;
    /**
     * Add a shadow to indicate elevation.
     * @group Props
     */
    raised: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Add a circular border radius to the button.
     * @group Props
     */
    rounded: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Add a textual class to the button without a background initially.
     * @group Props
     */
    text: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Add a border class without a background initially.
     * @group Props
     */
    outlined: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Defines the size of the button.
     * @group Props
     */
    size: _angular_core.InputSignal<"small" | "large" | null | undefined>;
    /**
     * Add a plain textual class to the button without a background initially.
     * @group Props
     */
    plain: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Name of the icon.
     * @group Props
     */
    icon: _angular_core.InputSignal<string | undefined>;
    /**
     * Position of the icon.
     * @group Props
     */
    iconPos: _angular_core.InputSignal<SplitButtonIconPosition>;
    /**
     * Text of the button.
     * @group Props
     */
    label: _angular_core.InputSignal<string | undefined>;
    /**
     * Tooltip for the main button.
     * @group Props
     */
    tooltip: _angular_core.InputSignal<string | undefined>;
    /**
     * Tooltip options for the main button.
     * @group Props
     */
    tooltipOptions: _angular_core.InputSignal<TooltipOptions | undefined>;
    /**
     * Class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the overlay menu.
     * @group Props
     */
    menuStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the overlay menu.
     * @group Props
     */
    menuStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Name of the dropdown icon.
     * @group Props
     */
    dropdownIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'body'
     * @group Props
     */
    appendTo: _angular_core.InputSignal<any>;
    /**
     * Indicates the direction of the element.
     * @group Props
     */
    dir: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the expand button for accessibility.
     * @group Props
     */
    expandAriaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Transition options of the show animation.
     * @group Props
     * @deprecated since v21.0.0. Use `motionOptions` instead.
     */
    showTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * Transition options of the hide animation.
     * @group Props
     * @deprecated since v21.0.0. Use `motionOptions` instead.
     */
    hideTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * The motion options.
     * @group Props
     */
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    computedMotionOptions: _angular_core.Signal<MotionOptions>;
    /**
     * Button Props
     */
    buttonProps: _angular_core.InputSignal<ButtonProps | undefined>;
    /**
     * Menu Button Props
     */
    menuButtonProps: _angular_core.InputSignal<MenuButtonProps | undefined>;
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When present, it specifies that the element should be disabled.
     * @group Props
     */
    disabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * When present, it specifies that the menu button element should be disabled.
     * @group Props
     */
    menuButtonDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When present, it specifies that the button element should be disabled.
     * @group Props
     */
    buttonDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * `disabled`, when explicitly set, overrides the per-button disabled flags.
     */
    $buttonDisabled: _angular_core.Signal<boolean>;
    $menuButtonDisabled: _angular_core.Signal<boolean>;
    /**
     * Callback to invoke when default command button is clicked.
     * @param {MouseEvent} event - Mouse event.
     * @group Emits
     */
    onClick: _angular_core.OutputEmitterRef<MouseEvent>;
    /**
     * Callback to invoke when overlay menu is hidden.
     * @group Emits
     */
    onMenuHide: _angular_core.OutputEmitterRef<any>;
    /**
     * Callback to invoke when overlay menu is shown.
     * @group Emits
     */
    onMenuShow: _angular_core.OutputEmitterRef<any>;
    /**
     * Callback to invoke when dropdown button is clicked.
     * @param {MouseEvent} event - Mouse event.
     * @group Emits
     */
    onDropdownClick: _angular_core.OutputEmitterRef<MouseEvent | undefined>;
    readonly buttonViewChild: _angular_core.Signal<ElementRef<any> | undefined>;
    readonly menu: _angular_core.Signal<TieredMenu | undefined>;
    /**
     * Custom content template.
     * @group Templates
     */
    contentTemplate: TemplateRef<void> | undefined;
    /**
     * Custom dropdown icon template.
     * @group Templates
     **/
    readonly dropdownIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    ariaId: string | undefined;
    isExpanded: _angular_core.WritableSignal<boolean>;
    _componentStyle: SplitButtonStyle;
    _contentTemplate: TemplateRef<void> | undefined;
    _dropdownIconTemplate: TemplateRef<void> | undefined;
    $appendTo: _angular_core.Signal<any>;
    onInit(): void;
    onAfterContentInit(): void;
    onDefaultButtonClick(event: MouseEvent): void;
    onDropdownButtonClick(event?: MouseEvent): void;
    onDropdownButtonKeydown(event: KeyboardEvent): void;
    onHide(): void;
    onShow(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SplitButton, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SplitButton, "p-splitbutton, p-splitButton, p-split-button", never, { "model": { "alias": "model"; "required": false; "isSignal": true; }; "severity": { "alias": "severity"; "required": false; "isSignal": true; }; "raised": { "alias": "raised"; "required": false; "isSignal": true; }; "rounded": { "alias": "rounded"; "required": false; "isSignal": true; }; "text": { "alias": "text"; "required": false; "isSignal": true; }; "outlined": { "alias": "outlined"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "plain": { "alias": "plain"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "iconPos": { "alias": "iconPos"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "tooltip": { "alias": "tooltip"; "required": false; "isSignal": true; }; "tooltipOptions": { "alias": "tooltipOptions"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "menuStyle": { "alias": "menuStyle"; "required": false; "isSignal": true; }; "menuStyleClass": { "alias": "menuStyleClass"; "required": false; "isSignal": true; }; "dropdownIcon": { "alias": "dropdownIcon"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "dir": { "alias": "dir"; "required": false; "isSignal": true; }; "expandAriaLabel": { "alias": "expandAriaLabel"; "required": false; "isSignal": true; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; "isSignal": true; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; "buttonProps": { "alias": "buttonProps"; "required": false; "isSignal": true; }; "menuButtonProps": { "alias": "menuButtonProps"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "menuButtonDisabled": { "alias": "menuButtonDisabled"; "required": false; "isSignal": true; }; "buttonDisabled": { "alias": "buttonDisabled"; "required": false; "isSignal": true; }; }, { "onClick": "onClick"; "onMenuHide": "onMenuHide"; "onMenuShow": "onMenuShow"; "onDropdownClick": "onDropdownClick"; }, ["dropdownIconTemplate", "templates", "contentTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class SplitButtonModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SplitButtonModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<SplitButtonModule, never, [typeof SplitButton, typeof i2.SharedModule], [typeof SplitButton, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<SplitButtonModule>;
}

export { SplitButton, SplitButtonClasses, SplitButtonModule, SplitButtonStyle };
