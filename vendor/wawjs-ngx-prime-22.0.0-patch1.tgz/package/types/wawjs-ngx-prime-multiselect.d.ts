import { MultiSelectPassThrough, MultiSelectChangeEvent, MultiSelectFilterEvent, MultiSelectFocusEvent, MultiSelectLazyLoadEvent, MultiSelectRemoveEvent, MultiSelectSelectAllChangeEvent, MultiSelectItemTemplateContext, MultiSelectGroupTemplateContext, MultiSelectLoaderTemplateContext, MultiSelectFilterTemplateContext, MultiSelectSelectedItemsTemplateContext, MultiSelectChipIconTemplateContext, MultiSelectDropdownIconTemplateContext, MultiSelectItemCheckboxIconTemplateContext, MultiSelectHeaderCheckboxIconTemplateContext, MultiSelectFilterOptions } from '@wawjs/ngx-prime/types/multiselect';
export * from '@wawjs/ngx-prime/types/multiselect';
import * as _angular_core from '@angular/core';
import { ElementRef, TemplateRef } from '@angular/core';
import { MotionOptions } from '@wawjs/css-prime-motion';
import * as i2 from '@wawjs/ngx-prime/api';
import { FilterService, OverlayService, ScrollerOptions, OverlayOptions, Footer, Header, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Checkbox } from '@wawjs/ngx-prime/checkbox';
import { Fluid } from '@wawjs/ngx-prime/fluid';
import { Overlay } from '@wawjs/ngx-prime/overlay';
import { Scroller } from '@wawjs/ngx-prime/scroller';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class MultiSelectStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-multiselect p-component p-inputwrapper': boolean;
            'p-multiselect-display-chip': boolean;
            'p-disabled': any;
            'p-invalid': any;
            'p-variant-filled': boolean;
            'p-focus': any;
            'p-inputwrapper-filled': any;
            'p-inputwrapper-focus': any;
            'p-multiselect-open': any;
            'p-multiselect-fluid': any;
            'p-multiselect-sm p-inputfield-sm': boolean;
            'p-multiselect-lg p-inputfield-lg': boolean;
        })[];
        labelContainer: string;
        label: ({ instance }: {
            instance: any;
        }) => {
            'p-multiselect-label': boolean;
            'p-placeholder': boolean;
            'p-multiselect-label-empty': boolean;
        };
        chipItem: string;
        pcChip: string;
        chipIcon: string;
        dropdown: string;
        loadingIcon: string;
        dropdownIcon: string;
        overlay: string;
        header: string;
        pcFilterContainer: string;
        pcFilter: string;
        listContainer: string;
        list: string;
        optionGroup: string;
        option: ({ instance }: {
            instance: any;
        }) => {
            'p-multiselect-option': boolean;
            'p-multiselect-option-selected': any;
            'p-disabled': any;
            'p-focus': any;
        };
        emptyMessage: string;
        clearIcon: string;
    };
    inlineStyles: {
        root: ({ instance }: {
            instance: any;
        }) => {
            position: string | undefined;
        };
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MultiSelectStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<MultiSelectStyle>;
}
/**
 *
 * MultiSelect is used to select multiple items from a collection.
 *
 * [Live Demo](https://www.ngx-prime.org/multiselect/)
 *
 * @module multiselectstyle
 *
 */
declare enum MultiSelectClasses {
    /**
     * Class name of the root element
     */
    root = "p-multiselect",
    /**
     * Class name of the label container element
     */
    labelContainer = "p-multiselect-label-container",
    /**
     * Class name of the label element
     */
    label = "p-multiselect-label",
    /**
     * Class name of the chip item element
     */
    chipItem = "p-multiselect-chip-item",
    /**
     * Class name of the chip element
     */
    pcChip = "p-multiselect-chip",
    /**
     * Class name of the chip icon element
     */
    chipIcon = "p-multiselect-chip-icon",
    /**
     * Class name of the dropdown element
     */
    dropdown = "p-multiselect-dropdown",
    /**
     * Class name of the loading icon element
     */
    loadingIcon = "p-multiselect-loading-icon",
    /**
     * Class name of the dropdown icon element
     */
    dropdownIcon = "p-multiselect-dropdown-icon",
    /**
     * Class name of the overlay element
     */
    overlay = "p-multiselect-overlay",
    /**
     * Class name of the header element
     */
    header = "p-multiselect-header",
    /**
     * Class name of the filter container element
     */
    pcFilterContainer = "p-multiselect-filter-container",
    /**
     * Class name of the filter element
     */
    pcFilter = "p-multiselect-filter",
    /**
     * Class name of the list container element
     */
    listContainer = "p-multiselect-list-container",
    /**
     * Class name of the list element
     */
    list = "p-multiselect-list",
    /**
     * Class name of the option group element
     */
    optionGroup = "p-multiselect-option-group",
    /**
     * Class name of the option element
     */
    option = "p-multiselect-option",
    /**
     * Class name of the empty message element
     */
    emptyMessage = "p-multiselect-empty-message",
    /**
     * Class name of the clear icon
     */
    clearIcon = "p-autocomplete-clear-icon"
}

declare const MULTISELECT_VALUE_ACCESSOR: any;
declare class MultiSelectItem extends BaseComponent {
    $pcMultiSelectItem: MultiSelectItem | undefined;
    hostName: string;
    getPTOptions(key: any): any;
    readonly option: _angular_core.InputSignal<any>;
    readonly selected: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly itemSize: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly focused: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly ariaPosInset: _angular_core.InputSignal<string | undefined>;
    readonly ariaSetSize: _angular_core.InputSignal<string | undefined>;
    readonly variant: _angular_core.InputSignal<"filled" | "outlined">;
    readonly template: _angular_core.InputSignal<TemplateRef<MultiSelectItemTemplateContext<any>> | undefined>;
    readonly checkIconTemplate: _angular_core.InputSignal<TemplateRef<MultiSelectItemCheckboxIconTemplateContext> | undefined>;
    readonly itemCheckboxIconTemplate: _angular_core.InputSignal<TemplateRef<MultiSelectItemCheckboxIconTemplateContext> | undefined>;
    readonly highlightOnSelect: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    onClick: _angular_core.OutputEmitterRef<any>;
    onMouseEnter: _angular_core.OutputEmitterRef<any>;
    _componentStyle: MultiSelectStyle;
    onOptionClick(event: Event): void;
    onOptionMouseEnter(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MultiSelectItem, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MultiSelectItem, "li[pMultiSelectItem]", never, { "option": { "alias": "option"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "itemSize": { "alias": "itemSize"; "required": false; "isSignal": true; }; "focused": { "alias": "focused"; "required": false; "isSignal": true; }; "ariaPosInset": { "alias": "ariaPosInset"; "required": false; "isSignal": true; }; "ariaSetSize": { "alias": "ariaSetSize"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "template": { "alias": "template"; "required": false; "isSignal": true; }; "checkIconTemplate": { "alias": "checkIconTemplate"; "required": false; "isSignal": true; }; "itemCheckboxIconTemplate": { "alias": "itemCheckboxIconTemplate"; "required": false; "isSignal": true; }; "highlightOnSelect": { "alias": "highlightOnSelect"; "required": false; "isSignal": true; }; }, { "onClick": "onClick"; "onMouseEnter": "onMouseEnter"; }, never, never, true, never>;
}
/**
 * MultiSelect is used to select multiple items from a collection.
 * @group Components
 */
declare class MultiSelect extends BaseEditableHolder<MultiSelectPassThrough> {
    private zone;
    filterService: FilterService;
    overlayService: OverlayService;
    componentName: string;
    /**
     * Unique identifier of the component
     * @group Props
     */
    readonly id: _angular_core.InputSignal<string | undefined>;
    private _generatedId;
    get resolvedId(): string;
    /**
     * Defines a string that labels the input for accessibility.
     * @group Props
     */
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    readonly styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the overlay panel.
     * @group Props
     */
    readonly panelStyle: _angular_core.InputSignal<any>;
    /**
     * Style class of the overlay panel element.
     * @group Props
     */
    readonly panelStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Identifier of the focus input to match a label defined for the component.
     * @group Props
     */
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    /**
     * When present, it specifies that the component cannot be edited.
     * @group Props
     */
    readonly readonly: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Whether to display options as grouped when nested options are provided.
     * @group Props
     */
    readonly group: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When specified, displays an input field to filter the items on keyup.
     * @group Props
     */
    readonly filter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Defines placeholder of the filter input.
     * @group Props
     */
    readonly filterPlaceHolder: _angular_core.InputSignal<string | undefined>;
    /**
     * Locale to use in filtering. The default locale is the host environment's current locale.
     * @group Props
     */
    readonly filterLocale: _angular_core.InputSignal<string | undefined>;
    /**
     * Specifies the visibility of the options panel.
     * @group Props
     */
    readonly overlayVisible: _angular_core.ModelSignal<boolean | undefined>;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    readonly tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * A property to uniquely identify a value in options.
     * @group Props
     */
    readonly dataKey: _angular_core.InputSignal<string | undefined>;
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to show labels of selected item labels or use default label.
     * @group Props
     * @defaultValue true
     */
    readonly displaySelectedLabel: _angular_core.InputSignal<boolean>;
    /**
     * Decides how many selected item labels to show at most.
     * @group Props
     * @defaultValue 3
     */
    readonly maxSelectedLabels: _angular_core.InputSignal<number | null | undefined>;
    /**
     * Maximum number of selectable items.
     * @group Props
     */
    readonly selectionLimit: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Label to display after exceeding max selected labels e.g. ({0} items selected), defaults "ellipsis" keyword to indicate a text-overflow.
     * @group Props
     */
    readonly selectedItemsLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to show the checkbox at header to toggle all items at once.
     * @group Props
     */
    readonly showToggleAll: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Text to display when filtering does not return any results.
     * @group Props
     */
    readonly emptyFilterMessage: _angular_core.InputSignal<string>;
    /**
     * Text to display when there is no data. Defaults to global value in i18n translation configuration.
     * @group Props
     */
    readonly emptyMessage: _angular_core.InputSignal<string>;
    /**
     * Clears the filter value when hiding the dropdown.
     * @group Props
     */
    readonly resetFilterOnHide: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Icon class of the dropdown icon.
     * @group Props
     */
    readonly dropdownIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Icon class of the chip icon.
     * @group Props
     */
    readonly chipIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Name of the label field of an option.
     * @group Props
     */
    readonly optionLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Name of the value field of an option.
     * @group Props
     */
    readonly optionValue: _angular_core.InputSignal<string | undefined>;
    /**
     * Name of the disabled field of an option.
     * @group Props
     */
    readonly optionDisabled: _angular_core.InputSignal<string | undefined>;
    /**
     * Name of the label field of an option group.
     * @group Props
     */
    readonly optionGroupLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Name of the options field of an option group.
     * @group Props
     */
    readonly optionGroupChildren: _angular_core.InputSignal<string>;
    /**
     * Whether to show the header.
     * @group Props
     */
    readonly showHeader: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When filtering is enabled, filterBy decides which field or fields (comma separated) to search against.
     * @group Props
     */
    readonly filterBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Height of the viewport in pixels, a scrollbar is defined if height of list exceeds this value.
     * @group Props
     */
    readonly scrollHeight: _angular_core.InputSignal<string>;
    /**
     * Defines if data is loaded and interacted with in lazy manner.
     * @group Props
     */
    readonly lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether the data should be loaded on demand during scroll.
     * @group Props
     */
    readonly virtualScroll: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Whether the multiselect is in loading state.
     * @group Props
     */
    readonly loading: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Height of an item in the list for VirtualScrolling.
     * @group Props
     */
    readonly virtualScrollItemSize: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Icon to display in loading state.
     * @group Props
     */
    readonly loadingIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to use the scroller feature. The properties of scroller component can be used like an object in it.
     * @group Props
     */
    readonly virtualScrollOptions: _angular_core.InputSignal<ScrollerOptions | undefined>;
    /**
     * Whether to use overlay API feature. The properties of overlay API can be used like an object in it.
     * @group Props
     */
    readonly overlayOptions: _angular_core.InputSignal<OverlayOptions | undefined>;
    /**
     * Defines a string that labels the filter input.
     * @group Props
     */
    readonly ariaFilterLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines how the items are filtered.
     * @group Props
     */
    readonly filterMatchMode: _angular_core.InputSignal<"contains" | "startsWith" | "endsWith" | "equals" | "notEquals" | "in" | "lt" | "lte" | "gt" | "gte">;
    /**
     * Advisory information to display in a tooltip on hover.
     * @group Props
     */
    readonly tooltip: _angular_core.InputSignal<string>;
    /**
     * Position of the tooltip.
     * @group Props
     */
    readonly tooltipPosition: _angular_core.InputSignal<"top" | "left" | "right" | "bottom">;
    /**
     * Type of CSS position.
     * @group Props
     */
    readonly tooltipPositionStyle: _angular_core.InputSignal<string>;
    /**
     * Style class of the tooltip.
     * @group Props
     */
    readonly tooltipStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Applies focus to the filter element when the overlay is shown.
     * @group Props
     */
    readonly autofocusFilter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Defines how the selected items are displayed.
     * @group Props
     */
    readonly display: _angular_core.InputSignal<string>;
    /**
     * Defines the autocomplete is active.
     * @group Props
     */
    readonly autocomplete: _angular_core.InputSignal<string>;
    /**
     * When enabled, a clear icon is displayed to clear the value.
     * @group Props
     */
    readonly showClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Label to display when there are no selections.
     * @group Props
     */
    readonly placeholder: _angular_core.InputSignal<string | undefined>;
    /**
     * An array of objects to display as the available options.
     * @group Props
     */
    readonly options: _angular_core.InputSignal<any[] | undefined>;
    /**
     * When specified, filter displays with this value.
     * @group Props
     */
    readonly filterValue: _angular_core.InputSignal<string | null | undefined>;
    /**
     * Whether all data is selected.
     * @group Props
     */
    readonly selectAll: _angular_core.InputSignal<boolean | null | undefined>;
    /**
     * Indicates whether to focus on options when hovering over them, defaults to optionLabel.
     * @group Props
     */
    readonly focusOnHover: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Fields used when filtering the options, defaults to optionLabel.
     * @group Props
     */
    readonly filterFields: _angular_core.InputSignal<any[] | undefined>;
    /**
     * Determines if the option will be selected on focus.
     * @group Props
     */
    readonly selectOnFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to focus on the first visible or selected element when the overlay panel is shown.
     * @group Props
     */
    readonly autoOptionFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether the selected option will be add highlight class.
     * @group Props
     */
    readonly highlightOnSelect: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Specifies the size of the component.
     * @defaultValue undefined
     * @group Props
     */
    size: _angular_core.InputSignal<"small" | "large" | undefined>;
    /**
     * Specifies the input variant of the component.
     * @defaultValue undefined
     * @group Props
     */
    variant: _angular_core.InputSignal<"filled" | "outlined" | undefined>;
    /**
     * Spans 100% width of the container when enabled.
     * @defaultValue undefined
     * @group Props
     */
    fluid: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'self'
     * @group Props
     */
    appendTo: _angular_core.InputSignal<any>;
    /**
     * The motion options.
     * @group Props
     */
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    /**
     * Callback to invoke when value changes.
     * @param {MultiSelectChangeEvent} event - Custom change event.
     * @group Emits
     */
    onChange: _angular_core.OutputEmitterRef<MultiSelectChangeEvent>;
    /**
     * Callback to invoke when data is filtered.
     * @param {MultiSelectFilterEvent} event - Custom filter event.
     * @group Emits
     */
    onFilter: _angular_core.OutputEmitterRef<MultiSelectFilterEvent>;
    /**
     * Callback to invoke when multiselect receives focus.
     * @param {MultiSelectFocusEvent} event - Custom focus event.
     * @group Emits
     */
    onFocus: _angular_core.OutputEmitterRef<MultiSelectFocusEvent>;
    /**
     * Callback to invoke when multiselect loses focus.
     * @param {MultiSelectBlurEvent} event - Custom blur event.
     * @group Emits
     */
    onBlur: _angular_core.OutputEmitterRef<MultiSelectFocusEvent>;
    /**
     * Callback to invoke when component is clicked.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onClick: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke when input field is cleared.
     * @group Emits
     */
    onClear: _angular_core.OutputEmitterRef<void>;
    /**
     * Callback to invoke when overlay panel becomes visible.
     * @param {AnimationEvent} event - Animation event.
     * @group Emits
     */
    onPanelShow: _angular_core.OutputEmitterRef<AnimationEvent>;
    /**
     * Callback to invoke when overlay panel becomes hidden.
     * @param {AnimationEvent} event - Animation event.
     * @group Emits
     */
    onPanelHide: _angular_core.OutputEmitterRef<AnimationEvent>;
    /**
     * Callback to invoke in lazy mode to load new data.
     * @param {MultiSelectLazyLoadEvent} event - Lazy load event.
     * @group Emits
     */
    onLazyLoad: _angular_core.OutputEmitterRef<MultiSelectLazyLoadEvent>;
    /**
     * Callback to invoke in lazy mode to load new data.
     * @param {MultiSelectRemoveEvent} event - Remove event.
     * @group Emits
     */
    onRemove: _angular_core.OutputEmitterRef<MultiSelectRemoveEvent>;
    /**
     * Callback to invoke when all data is selected.
     * @param {MultiSelectSelectAllChangeEvent} event - Custom select event.
     * @group Emits
     */
    onSelectAllChange: _angular_core.OutputEmitterRef<MultiSelectSelectAllChangeEvent>;
    readonly overlayViewChild: _angular_core.Signal<Nullable<Overlay>>;
    readonly filterInputChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly focusInputViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly itemsViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly scroller: _angular_core.Signal<Nullable<Scroller>>;
    readonly lastHiddenFocusableElementOnOverlay: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly firstHiddenFocusableElementOnOverlay: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly headerCheckboxViewChild: _angular_core.Signal<Nullable<Checkbox>>;
    readonly footerFacet: _angular_core.Signal<Footer | undefined>;
    readonly headerFacet: _angular_core.Signal<Header | undefined>;
    _componentStyle: MultiSelectStyle;
    bindDirectiveInstance: Bind;
    searchValue: Nullable<string>;
    searchTimeout: any;
    _selectAll: boolean | undefined | null;
    _placeholder: _angular_core.WritableSignal<string | undefined>;
    _disableTooltip: boolean;
    value: any[];
    _filteredOptions: any[] | undefined | null;
    focus: boolean | undefined;
    filtered: boolean | undefined;
    /**
     * Custom item template.
     * @group Templates
     */
    readonly itemTemplate: _angular_core.Signal<TemplateRef<MultiSelectItemTemplateContext<any>> | undefined>;
    /**
     * Custom group template.
     * @group Templates
     */
    groupTemplate: TemplateRef<MultiSelectGroupTemplateContext> | undefined;
    /**
     * Custom loader template.
     * @group Templates
     */
    loaderTemplate: TemplateRef<MultiSelectLoaderTemplateContext> | undefined;
    /**
     * Custom header template.
     * @group Templates
     */
    readonly headerTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom filter template.
     * @group Templates
     */
    filterTemplate: TemplateRef<MultiSelectFilterTemplateContext> | undefined;
    /**
     * Custom footer template.
     * @group Templates
     */
    footerTemplate: TemplateRef<void> | undefined;
    /**
     * Custom empty filter template.
     * @group Templates
     */
    readonly emptyFilterTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom empty template.
     * @group Templates
     */
    readonly emptyTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom selected items template.
     * @group Templates
     */
    selectedItemsTemplate: TemplateRef<MultiSelectSelectedItemsTemplateContext> | undefined;
    /**
     * Custom loading icon template.
     * @group Templates
     */
    loadingIconTemplate: TemplateRef<void> | undefined;
    /**
     * Custom filter icon template.
     * @group Templates
     */
    filterIconTemplate: TemplateRef<void> | undefined;
    /**
     * Custom remove token icon template.
     * @group Templates
     */
    removeTokenIconTemplate: TemplateRef<MultiSelectChipIconTemplateContext> | undefined;
    /**
     * Custom chip icon template.
     * @group Templates
     */
    chipIconTemplate: TemplateRef<MultiSelectChipIconTemplateContext> | undefined;
    /**
     * Custom clear icon template.
     * @group Templates
     */
    clearIconTemplate: TemplateRef<void> | undefined;
    /**
     * Custom dropdown icon template.
     * @group Templates
     */
    dropdownIconTemplate: TemplateRef<MultiSelectDropdownIconTemplateContext> | undefined;
    /**
     * Custom item checkbox icon template.
     * @group Templates
     */
    readonly itemCheckboxIconTemplate: _angular_core.Signal<TemplateRef<MultiSelectItemCheckboxIconTemplateContext> | undefined>;
    /**
     * Custom header checkbox icon template.
     * @group Templates
     */
    readonly headerCheckboxIconTemplate: _angular_core.Signal<TemplateRef<MultiSelectHeaderCheckboxIconTemplateContext> | undefined>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _itemTemplate: TemplateRef<MultiSelectItemTemplateContext> | undefined;
    _groupTemplate: TemplateRef<MultiSelectGroupTemplateContext> | undefined;
    _loaderTemplate: TemplateRef<MultiSelectLoaderTemplateContext> | undefined;
    _headerTemplate: TemplateRef<void> | undefined;
    _filterTemplate: TemplateRef<MultiSelectFilterTemplateContext> | undefined;
    _footerTemplate: TemplateRef<void> | undefined;
    _emptyFilterTemplate: TemplateRef<void> | undefined;
    _emptyTemplate: TemplateRef<void> | undefined;
    _selectedItemsTemplate: TemplateRef<MultiSelectSelectedItemsTemplateContext> | undefined;
    _loadingIconTemplate: TemplateRef<void> | undefined;
    _filterIconTemplate: TemplateRef<void> | undefined;
    _removeTokenIconTemplate: TemplateRef<MultiSelectChipIconTemplateContext> | undefined;
    _chipIconTemplate: TemplateRef<MultiSelectChipIconTemplateContext> | undefined;
    _clearIconTemplate: TemplateRef<void> | undefined;
    _dropdownIconTemplate: TemplateRef<MultiSelectDropdownIconTemplateContext> | undefined;
    _itemCheckboxIconTemplate: TemplateRef<MultiSelectItemCheckboxIconTemplateContext> | undefined;
    _headerCheckboxIconTemplate: TemplateRef<MultiSelectHeaderCheckboxIconTemplateContext> | undefined;
    $variant: _angular_core.Signal<"filled" | "outlined" | null>;
    $appendTo: _angular_core.Signal<any>;
    $pcMultiSelect: MultiSelect | undefined;
    pcFluid: Fluid | null;
    get hasFluid(): boolean;
    onAfterContentInit(): void;
    headerCheckboxFocus: boolean | undefined;
    filterOptions: MultiSelectFilterOptions | undefined;
    preventModelTouched: boolean | undefined;
    focused: boolean;
    itemsWrapper: any;
    _displaySelectedLabel: boolean;
    _maxSelectedLabels: number | null | undefined;
    modelValue: _angular_core.WritableSignal<any>;
    _filterValue: _angular_core.WritableSignal<any>;
    _options: _angular_core.WritableSignal<any[]>;
    startRangeIndex: _angular_core.WritableSignal<number>;
    focusedOptionIndex: _angular_core.WritableSignal<number>;
    selectedOptions: any;
    clickInProgress: boolean;
    get emptyMessageLabel(): string;
    get emptyFilterMessageLabel(): string;
    get isVisibleClearIcon(): boolean | undefined;
    get toggleAllAriaLabel(): string | undefined;
    get listLabel(): string;
    private getAllVisibleAndNonVisibleOptions;
    visibleOptions: _angular_core.Signal<any>;
    label: _angular_core.Signal<any>;
    chipSelectedItems: _angular_core.Signal<any>;
    constructor();
    onInit(): void;
    maxSelectionLimitReached(): any;
    onAfterViewInit(): void;
    onAfterViewChecked(): void;
    flatOptions(options: any): any;
    autoUpdateModel(): void;
    /**
     * Updates the model value.
     * @group Method
     */
    updateModel(value: any, event?: any): void;
    onInputClick(event: any): void;
    onOptionSelect(event: any, isFocus?: boolean, index?: number): void;
    findSelectedOptionIndex(): any;
    onOptionSelectRange(event: any, start?: number, end?: number): void;
    searchFields(): string[];
    findNearestSelectedOptionIndex(index: any, firstCheckUp?: boolean): any;
    findPrevSelectedOptionIndex(index: any): number;
    findFirstFocusedOptionIndex(): any;
    findFirstOptionIndex(): any;
    findFirstSelectedOptionIndex(): any;
    findNextSelectedOptionIndex(index: any): any;
    equalityKey(): string | null | undefined;
    hasSelectedOption(): boolean;
    isValidSelectedOption(option: any): any;
    isOptionGroup(option: any): any;
    isValidOption(option: any): any;
    isOptionDisabled(option: any): any;
    isSelected(option: any): any;
    isOptionMatched(option: any): any;
    isEmpty(): any;
    getOptionIndex(index: any, scrollerOptions: any): any;
    getAriaPosInset(index: any): any;
    get ariaSetSize(): any;
    getLabelByValue(value: any): any;
    getSelectedItemsLabel(): any;
    getOptionLabel(option: any): any;
    getOptionValue(option: any): any;
    getOptionGroupLabel(optionGroup: any): any;
    getOptionGroupChildren(optionGroup: any): any;
    onKeyDown(event: KeyboardEvent): void;
    onFilterKeyDown(event: KeyboardEvent): void;
    onArrowLeftKey(event: KeyboardEvent, pressedInInputText?: boolean): void;
    onArrowDownKey(event: any): void;
    onArrowUpKey(event: any, pressedInInputText?: boolean): void;
    onHomeKey(event: any, pressedInInputText?: boolean): void;
    onEndKey(event: any, pressedInInputText?: boolean): void;
    onPageDownKey(event: any): void;
    onPageUpKey(event: any): void;
    onEnterKey(event: any): void;
    onEscapeKey(event: KeyboardEvent): void;
    onTabKey(event: any, pressedInInputText?: boolean): void;
    onShiftKey(): void;
    onContainerClick(event: any): void;
    onFirstHiddenFocus(event: any): void;
    onInputFocus(event: Event): void;
    onInputBlur(event: Event): void;
    onFilterInputChange(event: Event): void;
    onLastHiddenFocus(event: any): void;
    onOptionMouseEnter(event: any, index: any): void;
    onFilterBlur(): void;
    onToggleAll(event: any): void;
    changeFocusedOptionIndex(event: any, index: any): void;
    get virtualScrollerDisabled(): boolean;
    scrollInView(index?: number): void;
    get focusedOptionId(): string | null;
    allSelected(): any;
    partialSelected(): any;
    /**
     * Displays the panel.
     * @group Method
     */
    show(isFocus?: any): void;
    /**
     * Hides the panel.
     * @group Method
     */
    hide(isFocus?: any): void;
    onOverlayBeforeEnter(event: any): void;
    onOverlayAfterLeave(event: any): void;
    resetFilter(): void;
    onOverlayHide(): void;
    close(event: Event): void;
    clear(event: Event): void;
    labelContainerMouseLeave(): void;
    removeOption(optionValue: any, event: any): void;
    findNextOptionIndex(index: any): any;
    findPrevOptionIndex(index: any): any;
    findLastSelectedOptionIndex(): number;
    findLastFocusedOptionIndex(): number;
    findLastOptionIndex(): number;
    searchOptions(event: any, char: any): boolean;
    hasFocusableElements(): boolean;
    hasFilter(): any;
    get containerDataP(): string | undefined;
    get labelDataP(): string | undefined;
    get dropdownIconDataP(): string | undefined;
    get overlayDataP(): string | undefined;
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value: any, setModelValue: (value: any) => void): void;
    getHeaderCheckboxPTOptions(key: string): any;
    getPTOptions(option: any, itemOptions: any, index: any, key: any): any;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MultiSelect, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MultiSelect, "p-multiSelect, p-multiselect, p-multi-select", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "panelStyle": { "alias": "panelStyle"; "required": false; "isSignal": true; }; "panelStyleClass": { "alias": "panelStyleClass"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "group": { "alias": "group"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "filterPlaceHolder": { "alias": "filterPlaceHolder"; "required": false; "isSignal": true; }; "filterLocale": { "alias": "filterLocale"; "required": false; "isSignal": true; }; "overlayVisible": { "alias": "overlayVisible"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "displaySelectedLabel": { "alias": "displaySelectedLabel"; "required": false; "isSignal": true; }; "maxSelectedLabels": { "alias": "maxSelectedLabels"; "required": false; "isSignal": true; }; "selectionLimit": { "alias": "selectionLimit"; "required": false; "isSignal": true; }; "selectedItemsLabel": { "alias": "selectedItemsLabel"; "required": false; "isSignal": true; }; "showToggleAll": { "alias": "showToggleAll"; "required": false; "isSignal": true; }; "emptyFilterMessage": { "alias": "emptyFilterMessage"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "resetFilterOnHide": { "alias": "resetFilterOnHide"; "required": false; "isSignal": true; }; "dropdownIcon": { "alias": "dropdownIcon"; "required": false; "isSignal": true; }; "chipIcon": { "alias": "chipIcon"; "required": false; "isSignal": true; }; "optionLabel": { "alias": "optionLabel"; "required": false; "isSignal": true; }; "optionValue": { "alias": "optionValue"; "required": false; "isSignal": true; }; "optionDisabled": { "alias": "optionDisabled"; "required": false; "isSignal": true; }; "optionGroupLabel": { "alias": "optionGroupLabel"; "required": false; "isSignal": true; }; "optionGroupChildren": { "alias": "optionGroupChildren"; "required": false; "isSignal": true; }; "showHeader": { "alias": "showHeader"; "required": false; "isSignal": true; }; "filterBy": { "alias": "filterBy"; "required": false; "isSignal": true; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "virtualScroll": { "alias": "virtualScroll"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "virtualScrollItemSize": { "alias": "virtualScrollItemSize"; "required": false; "isSignal": true; }; "loadingIcon": { "alias": "loadingIcon"; "required": false; "isSignal": true; }; "virtualScrollOptions": { "alias": "virtualScrollOptions"; "required": false; "isSignal": true; }; "overlayOptions": { "alias": "overlayOptions"; "required": false; "isSignal": true; }; "ariaFilterLabel": { "alias": "ariaFilterLabel"; "required": false; "isSignal": true; }; "filterMatchMode": { "alias": "filterMatchMode"; "required": false; "isSignal": true; }; "tooltip": { "alias": "tooltip"; "required": false; "isSignal": true; }; "tooltipPosition": { "alias": "tooltipPosition"; "required": false; "isSignal": true; }; "tooltipPositionStyle": { "alias": "tooltipPositionStyle"; "required": false; "isSignal": true; }; "tooltipStyleClass": { "alias": "tooltipStyleClass"; "required": false; "isSignal": true; }; "autofocusFilter": { "alias": "autofocusFilter"; "required": false; "isSignal": true; }; "display": { "alias": "display"; "required": false; "isSignal": true; }; "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; "showClear": { "alias": "showClear"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "filterValue": { "alias": "filterValue"; "required": false; "isSignal": true; }; "selectAll": { "alias": "selectAll"; "required": false; "isSignal": true; }; "focusOnHover": { "alias": "focusOnHover"; "required": false; "isSignal": true; }; "filterFields": { "alias": "filterFields"; "required": false; "isSignal": true; }; "selectOnFocus": { "alias": "selectOnFocus"; "required": false; "isSignal": true; }; "autoOptionFocus": { "alias": "autoOptionFocus"; "required": false; "isSignal": true; }; "highlightOnSelect": { "alias": "highlightOnSelect"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; }, { "overlayVisible": "overlayVisibleChange"; "onChange": "onChange"; "onFilter": "onFilter"; "onFocus": "onFocus"; "onBlur": "onBlur"; "onClick": "onClick"; "onClear": "onClear"; "onPanelShow": "onPanelShow"; "onPanelHide": "onPanelHide"; "onLazyLoad": "onLazyLoad"; "onRemove": "onRemove"; "onSelectAllChange": "onSelectAllChange"; }, ["footerFacet", "headerFacet", "itemTemplate", "headerTemplate", "emptyFilterTemplate", "emptyTemplate", "itemCheckboxIconTemplate", "headerCheckboxIconTemplate", "templates", "groupTemplate", "loaderTemplate", "filterTemplate", "footerTemplate", "selectedItemsTemplate", "loadingIconTemplate", "filterIconTemplate", "removeTokenIconTemplate", "chipIconTemplate", "clearIconTemplate", "dropdownIconTemplate"], ["p-header", "p-footer"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class MultiSelectModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MultiSelectModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<MultiSelectModule, never, [typeof MultiSelect, typeof i2.SharedModule], [typeof MultiSelect, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<MultiSelectModule>;
}

export { MULTISELECT_VALUE_ACCESSOR, MultiSelect, MultiSelectClasses, MultiSelectItem, MultiSelectModule, MultiSelectStyle };
