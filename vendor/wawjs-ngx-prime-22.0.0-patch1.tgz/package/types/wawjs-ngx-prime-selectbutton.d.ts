import { SelectButtonPassThrough, SelectButtonOptionClickEvent, SelectButtonChangeEvent, SelectButtonItemTemplateContext } from '@wawjs/ngx-prime/types/selectbutton';
export * from '@wawjs/ngx-prime/types/selectbutton';
import * as _angular_core from '@angular/core';
import { ElementRef, AfterViewChecked, TemplateRef } from '@angular/core';
import * as i3 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class SelectButtonStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-invalid': any;
            'p-disabled': any;
            'p-selectbutton-fluid': any;
        })[];
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectButtonStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SelectButtonStyle>;
}
/**
 *
 * SelectButton is used to choose single or multiple items from a list using buttons.
 *
 * [Live Demo](https://www.ngx-prime.org/selectbutton/)
 *
 * @module selectbuttonstyle
 *
 */
declare enum SelectButtonClasses {
    /**
     * Class name of the root element
     */
    root = "p-selectbutton"
}

/** Manages selection for a group of native `button[pSelectButtonOption]` elements. */
declare class SelectButtonDirective extends BaseEditableHolder<SelectButtonPassThrough> {
    componentName: string;
    _componentStyle: SelectButtonStyle;
    readonly element: ElementRef<HTMLElement>;
    private readonly bindDirectiveInstance;
    multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    allowEmpty: _angular_core.InputSignalWithTransform<boolean, unknown>;
    unselectable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    dataKey: _angular_core.InputSignal<string | undefined>;
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    ariaDescribedBy: _angular_core.InputSignal<string | undefined>;
    fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    onOptionClick: _angular_core.OutputEmitterRef<SelectButtonOptionClickEvent>;
    onChange: _angular_core.OutputEmitterRef<SelectButtonChangeEvent>;
    onFocus: _angular_core.OutputEmitterRef<FocusEvent>;
    onBlur: _angular_core.OutputEmitterRef<FocusEvent>;
    /** Signal Forms value contract. */
    value: _angular_core.ModelSignal<unknown>;
    touch: _angular_core.OutputEmitterRef<void>;
    readonly optionDirectives: _angular_core.Signal<readonly SelectButtonOptionDirective[]>;
    role: _angular_core.Signal<"group" | "radiogroup">;
    onAfterViewChecked(): void;
    isSelected(value: unknown): boolean;
    select(event: Event, option: unknown, index?: number): void;
    getOptionIndex(option: SelectButtonOptionDirective): number;
    isFirstEnabledOption(option: SelectButtonOptionDirective): boolean;
    onKeyDown(event: KeyboardEvent): void;
    onFocusOut(event: FocusEvent): void;
    writeControlValue(value: unknown, setModelValue: (value: unknown) => void): void;
    focus(options?: FocusOptions): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectButtonDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SelectButtonDirective, "[pSelectButton]", never, { "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "allowEmpty": { "alias": "allowEmpty"; "required": false; "isSignal": true; }; "unselectable": { "alias": "unselectable"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "ariaDescribedBy": { "alias": "ariaDescribedBy"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "onOptionClick": "onOptionClick"; "onChange": "onChange"; "onFocus": "onFocus"; "onBlur": "onBlur"; "value": "valueChange"; "touch": "touch"; }, ["optionDirectives"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
/** Registers a native button as an option in a `pSelectButton` group. */
declare class SelectButtonOptionDirective {
    readonly group: SelectButtonDirective;
    readonly element: ElementRef<HTMLButtonElement>;
    private readonly bindDirectiveInstance;
    value: _angular_core.InputSignal<unknown>;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    type: _angular_core.InputSignal<"button" | "submit" | "reset">;
    index: _angular_core.InputSignal<number | undefined>;
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    ariaDescribedBy: _angular_core.InputSignal<string | undefined>;
    selected: () => boolean;
    resolvedIndex: _angular_core.Signal<number>;
    tabindex: _angular_core.Signal<0 | -1>;
    onAfterViewChecked(): void;
    isDisabled(): boolean;
    select(event: Event): void;
    focus(options?: FocusOptions): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectButtonOptionDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SelectButtonOptionDirective, "button[pSelectButtonOption]", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "index": { "alias": "index"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "ariaDescribedBy": { "alias": "ariaDescribedBy"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}

declare const SELECTBUTTON_VALUE_ACCESSOR: any;
/**
 * Legacy SelectButton component.
 * @deprecated since v22, use native `pSelectButton` and `pSelectButtonOption` directives. The legacy component selectors will be removed in v23.
 * @group Components
 */
declare class SelectButton extends BaseEditableHolder<SelectButtonPassThrough> implements AfterViewChecked {
    componentName: string;
    /**
     * An array of selectitems to display as the available options.
     * @group Props
     */
    options: _angular_core.InputSignal<any[] | undefined>;
    /**
     * Name of the label field of an option.
     * @group Props
     */
    optionLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Name of the value field of an option.
     * @group Props
     */
    optionValue: _angular_core.InputSignal<string | undefined>;
    /**
     * Name of the disabled field of an option.
     * @group Props
     */
    optionDisabled: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether selection can be cleared.
     * @group Props
     */
    unselectable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * When specified, allows selecting multiple values.
     * @group Props
     */
    multiple: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Whether selection can not be cleared.
     * @group Props
     */
    allowEmpty: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Style class of the component.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * A property to uniquely identify a value in options.
     * @group Props
     */
    dataKey: _angular_core.InputSignal<string | undefined>;
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Specifies the size of the component.
     * @defaultValue undefined
     * @group Props
     */
    size: _angular_core.InputSignal<"large" | "small" | undefined>;
    /**
     * Spans 100% width of the container when enabled.
     * @defaultValue undefined
     * @group Props
     */
    fluid: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Callback to invoke on input click.
     * @param {SelectButtonOptionClickEvent} event - Custom click event.
     * @group Emits
     */
    onOptionClick: _angular_core.OutputEmitterRef<SelectButtonOptionClickEvent>;
    /**
     * Callback to invoke on selection change.
     * @param {SelectButtonChangeEvent} event - Custom change event.
     * @group Emits
     */
    onChange: _angular_core.OutputEmitterRef<SelectButtonChangeEvent>;
    /**
     * Custom item template.
     * @param {SelectButtonItemTemplateContext} context - item context.
     * @see {@link SelectButtonItemTemplateContext}
     * @group Templates
     */
    itemTemplate: TemplateRef<SelectButtonItemTemplateContext> | undefined;
    _itemTemplate: TemplateRef<SelectButtonItemTemplateContext> | undefined;
    get equalityKey(): string | null | undefined;
    value: any;
    focusedIndex: number;
    _componentStyle: SelectButtonStyle;
    $pcSelectButton: SelectButton | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    getAllowEmpty(): boolean;
    getOptionLabel(option: any): any;
    getOptionValue(option: any): any;
    isOptionDisabled(option: any): any;
    onOptionSelect(event: any, option: any, index: any): void;
    changeTabIndexes(event: any, direction: any): void;
    onFocus(event: Event, index: number): void;
    onBlur(): void;
    removeOption(option: any): void;
    isSelected(option: any): boolean;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    onAfterContentInit(): void;
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value: any, setModelValue: (value: any) => void): void;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectButton, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SelectButton, "p-selectButton, p-selectbutton, p-select-button", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "optionLabel": { "alias": "optionLabel"; "required": false; "isSignal": true; }; "optionValue": { "alias": "optionValue"; "required": false; "isSignal": true; }; "optionDisabled": { "alias": "optionDisabled"; "required": false; "isSignal": true; }; "unselectable": { "alias": "unselectable"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "allowEmpty": { "alias": "allowEmpty"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; }, { "onOptionClick": "onOptionClick"; "onChange": "onChange"; }, ["templates", "itemTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class SelectButtonModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectButtonModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<SelectButtonModule, never, [typeof SelectButton, typeof SelectButtonDirective, typeof SelectButtonOptionDirective, typeof i3.SharedModule], [typeof SelectButton, typeof SelectButtonDirective, typeof SelectButtonOptionDirective, typeof i3.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<SelectButtonModule>;
}

export { SELECTBUTTON_VALUE_ACCESSOR, SelectButton, SelectButtonClasses, SelectButtonDirective, SelectButtonModule, SelectButtonOptionDirective, SelectButtonStyle };
