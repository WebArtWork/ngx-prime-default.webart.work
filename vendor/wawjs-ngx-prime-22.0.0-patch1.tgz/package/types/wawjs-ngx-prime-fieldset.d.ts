import { FieldsetPassThrough, FieldsetAfterToggleEvent } from '@wawjs/ngx-prime/types/fieldset';
export * from '@wawjs/ngx-prime/types/fieldset';
import * as _angular_core from '@angular/core';
import { ElementRef, TemplateRef } from '@angular/core';
import { MotionOptions, MotionEvent } from '@wawjs/css-prime-motion';
import * as i2 from '@wawjs/ngx-prime/api';
import { BlockableUI, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class FieldsetStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-fieldset-toggleable': any;
            'p-fieldset-collapsed': any;
        })[];
        legend: string;
        legendLabel: string;
        toggleButton: string;
        toggleIcon: string;
        contentContainer: string;
        contentWrapper: string;
        content: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FieldsetStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<FieldsetStyle>;
}
/**
 *
 * Fieldset is a grouping component with the optional content toggle feature.
 *
 * [Live Demo](https://www.ngx-prime.org/fieldset/)
 *
 * @module fieldsetstyle
 *
 */
declare enum FieldsetClasses {
    /**
     * Class name of the root element
     */
    root = "p-fieldset",
    /**
     * Class name of the legend element
     */
    legend = "p-fieldset-legend",
    /**
     * Class name of the legend label element
     */
    legendLabel = "p-fieldset-legend-label",
    /**
     * Class name of the toggle icon element
     */
    toggleIcon = "p-fieldset-toggle-icon",
    /**
     * Class name of the content container element
     */
    contentContainer = "p-fieldset-content-container",
    /**
     * Class name of the content wrapper element
     */
    contentWrapper = "p-fieldset-content-wrapper",
    /**
     * Class name of the content element
     */
    content = "p-fieldset-content"
}

/**
 * Fieldset is a grouping component with the optional content toggle feature.
 * @group Components
 */
declare class Fieldset extends BaseComponent<FieldsetPassThrough> implements BlockableUI {
    componentName: string;
    $pcFieldset: Fieldset | undefined;
    _componentStyle: FieldsetStyle;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    get dataP(): string | undefined;
    /**
     * Header text of the fieldset.
     * @group Props
     */
    legend: _angular_core.InputSignal<string | undefined>;
    /**
     * When specified, content can toggled by clicking the legend.
     * @group Props
     * @defaultValue false
     */
    toggleable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Inline style of the component.
     * @group Props
     */
    style: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the component.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Transition options of the panel animation.
     * @group Props
     * @deprecated since v21.0.0, use `motionOptions` instead.
     */
    transitionOptions: _angular_core.InputSignal<string>;
    /**
     * The motion options.
     * @group Props
     */
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    computedMotionOptions: _angular_core.Signal<MotionOptions>;
    /**
     * Callback to invoke before panel toggle.
     * @param {PanelBeforeToggleEvent} event - Custom toggle event
     * @group Emits
     */
    onBeforeToggle: _angular_core.OutputEmitterRef<FieldsetAfterToggleEvent>;
    /**
     * Callback to invoke after panel toggle.
     * @param {PanelAfterToggleEvent} event - Custom toggle event
     * @group Emits
     */
    onAfterToggle: _angular_core.OutputEmitterRef<FieldsetAfterToggleEvent>;
    readonly contentWrapperViewChild: _angular_core.Signal<ElementRef<any>>;
    private _id;
    get id(): string;
    get buttonAriaLabel(): string | undefined;
    /**
     * Defines the initial state of content, supports one or two-way binding as well.
     * @group Props
     */
    collapsed: _angular_core.ModelSignal<boolean | undefined>;
    /**
     * Custom header template.
     * @group Templates
     */
    readonly headerTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom expand icon template.
     * @group Templates
     */
    expandIconTemplate: TemplateRef<void> | undefined;
    /**
     * Custom collapse icon template.
     * @group Templates
     */
    collapseIconTemplate: TemplateRef<void> | undefined;
    /**
     * Custom content template.
     * @group Templates
     */
    readonly contentTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    toggle(event: MouseEvent): void;
    onKeyDown(event: any): void;
    expand(): void;
    collapse(): void;
    getBlockableElement(): HTMLElement;
    updateTabIndex(): void;
    onToggleDone(event: MotionEvent): void;
    _headerTemplate: TemplateRef<void> | undefined;
    _expandIconTemplate: TemplateRef<void> | undefined;
    _collapseIconTemplate: TemplateRef<void> | undefined;
    _contentTemplate: TemplateRef<void> | undefined;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    onAfterContentInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Fieldset, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Fieldset, "p-fieldset", never, { "legend": { "alias": "legend"; "required": false; "isSignal": true; }; "toggleable": { "alias": "toggleable"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "transitionOptions": { "alias": "transitionOptions"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; "collapsed": { "alias": "collapsed"; "required": false; "isSignal": true; }; }, { "onBeforeToggle": "onBeforeToggle"; "onAfterToggle": "onAfterToggle"; "collapsed": "collapsedChange"; }, ["headerTemplate", "contentTemplate", "templates", "expandIconTemplate", "collapseIconTemplate"], ["p-header", "p-header", "*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class FieldsetModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FieldsetModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<FieldsetModule, never, [typeof Fieldset, typeof i2.SharedModule, typeof i1.BindModule], [typeof Fieldset, typeof i2.SharedModule, typeof i1.BindModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<FieldsetModule>;
}

export { Fieldset, FieldsetClasses, FieldsetModule, FieldsetStyle };
