import { TreeTablePassThrough, TreeTableFilterEvent, TreeTableNodeExpandEvent, TreeTableNodeCollapseEvent, TreeTablePaginatorState, TreeTableLazyLoadEvent, TreeTableSortEvent, TreeTableColResizeEvent, TreeTableColumnReorderEvent, TreeTableNodeUnSelectEvent, TreeTableContextMenuSelectEvent, TreeTableHeaderCheckboxToggleEvent, TreeTableEditEvent, TreeTableColumnsTemplateContext, TreeTableBodyTemplateContext, TreeTableEmptyMessageTemplateContext, TreeTableSortIconTemplateContext, TreeTableCheckboxIconTemplateContext, TreeTableHeaderCheckboxIconTemplateContext, TreeTableTogglerIconTemplateContext, TreeTableFilterOptions } from '@wawjs/ngx-prime/types/treetable';
export * from '@wawjs/ngx-prime/types/treetable';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as _angular_core from '@angular/core';
import { ElementRef, TemplateRef, NgZone, ChangeDetectorRef } from '@angular/core';
import * as rxjs from 'rxjs';
import { Subscription } from 'rxjs';
import * as i9 from '@wawjs/ngx-prime/api';
import { BlockableUI, ScrollerOptions, FilterMetadata, SortMeta, TreeNode, TreeTableNode, PrimeTemplate, FilterService } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import * as i5 from '@wawjs/ngx-prime/scroller';
import { Scroller } from '@wawjs/ngx-prime/scroller';
import { Nullable, VoidListener } from '@wawjs/ngx-prime/ts-helpers';
import * as i2 from '@angular/common';
import * as i3 from '@wawjs/ngx-prime/paginator';
import * as i4 from '@wawjs/ngx-prime/ripple';
import * as i6 from '@wawjs/ngx-prime/icons';
import * as i7 from '@wawjs/ngx-prime/badge';
import * as i8 from '@wawjs/ngx-prime/checkbox';
import * as i10 from '@angular/forms';

declare class TreeTableStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-treetable-gridlines': any;
            'p-treetable-hoverable-rows': any;
            'p-treetable-auto-layout': any;
            'p-treetable-resizable': any;
            'p-treetable-resizable-fit': any;
            'p-treetable-flex-scrollable': any;
        })[];
        loading: string;
        mask: string;
        loadingIcon: string;
        header: string;
        pcPaginator: ({ instance }: {
            instance: any;
        }) => any[];
        tableContainer: string;
        table: ({ instance }: {
            instance: any;
        }) => {
            'p-treetable-table': boolean;
            'p-treetable-scrollable-table': any;
            'p-treetable-resizable-table': any;
            'p-treetable-resizable-table-fit': any;
        };
        thead: string;
        sortableColumn: ({ instance }: {
            instance: any;
        }) => {
            'p-sortable-column': any;
            'p-treetable-column-sorted': any;
        };
        sortableColumnIcon: string;
        sortableColumnBadge: string;
        columnResizer: string;
        columnHeaderContent: string;
        columnTitle: string;
        sortIcon: string;
        pcSortBadge: string;
        tbody: string;
        row: ({ instance }: {
            instance: any;
        }) => {
            'p-treetable-row-selected': any;
        };
        contextMenuRow: ({ instance }: {
            instance: any;
        }) => {
            'p-treetable-contextmenu-row-selected': any;
        };
        toggler: string;
        nodeToggleButton: string;
        nodeToggleIcon: string;
        pcNodeCheckbox: string;
        tfoot: string;
        footerCell: ({ instance }: {
            instance: any;
        }) => {
            'p-treetable-frozen-column': any;
        };
        footer: string;
        columnResizeIndicator: string;
        wrapper: string;
        scrollableWrapper: string;
        scrollableView: string;
        frozenView: string;
        columnResizerHelper: string;
        reorderIndicatorUp: string;
        reorderIndicatorDown: string;
        scrollableHeader: string;
        scrollableHeaderBox: string;
        scrollableHeaderTable: string;
        scrollableBody: string;
        scrollableFooter: string;
        scrollableFooterBox: string;
        scrollableFooterTable: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TreeTableStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TreeTableStyle>;
}
/**
 *
 * TreeTable is used to display hierarchical data in tabular format.
 *
 * [Live Demo](https://www.ngx-prime.org/treetable/)
 *
 * @module treetablestyle
 *
 */
declare enum TreeTableClasses {
    /**
     * Class name of the root element
     */
    root = "p-treetable",
    /**
     * Class name of the loading element
     */
    loading = "p-treetable-loading",
    /**
     * Class name of the mask element
     */
    mask = "p-treetable-mask",
    /**
     * Class name of the loading icon element
     */
    loadingIcon = "p-treetable-loading-icon",
    /**
     * Class name of the header element
     */
    header = "p-treetable-header",
    /**
     * Class name of the paginator element
     */
    pcPaginator = "p-treetable-paginator-[position]",
    /**
     * Class name of the table container element
     */
    tableContainer = "p-treetable-table-container",
    /**
     * Class name of the table element
     */
    table = "p-treetable-table",
    /**
     * Class name of the thead element
     */
    thead = "p-treetable-thead",
    /**
     * Class name of the column resizer element
     */
    columnResizer = "p-treetable-column-resizer",
    /**
     * Class name of the column title element
     */
    columnTitle = "p-treetable-column-title",
    /**
     * Class name of the sort icon element
     */
    sortIcon = "p-treetable-sort-icon",
    /**
     * Class name of the sort badge element
     */
    pcSortBadge = "p-treetable-sort-badge",
    /**
     * Class name of the tbody element
     */
    tbody = "p-treetable-tbody",
    /**
     * Class name of the node toggle button element
     */
    nodeToggleButton = "p-treetable-node-toggle-button",
    /**
     * Class name of the node toggle icon element
     */
    nodeToggleIcon = "p-treetable-node-toggle-icon",
    /**
     * Class name of the node checkbox element
     */
    pcNodeCheckbox = "p-treetable-node-checkbox",
    /**
     * Class name of the empty message element
     */
    emptyMessage = "p-treetable-empty-message",
    /**
     * Class name of the tfoot element
     */
    tfoot = "p-treetable-tfoot",
    /**
     * Class name of the footer element
     */
    footer = "p-treetable-footer",
    /**
     * Class name of the column resize indicator element
     */
    columnResizeIndicator = "p-treetable-column-resize-indicator",
    /**
     * Class name of the wrapper element
     */
    wrapper = "p-treetable-wrapper",
    /**
     * Class name of the scrollable wrapper element
     */
    scrollableWrapper = "p-treetable-scrollable-wrapper",
    /**
     * Class name of the scrollable view element
     */
    scrollableView = "p-treetable-scrollable-view",
    /**
     * Class name of the frozen view element
     */
    frozenView = "p-treetable-frozen-view",
    /**
     * Class name of the column resizer helper element
     */
    columnResizerHelper = "p-treetable-column-resizer-helper",
    /**
     * Class name of the reorder indicator up element
     */
    reorderIndicatorUp = "p-treetable-reorder-indicator-up",
    /**
     * Class name of the reorder indicator down element
     */
    reorderIndicatorDown = "p-treetable-reorder-indicator-down",
    /**
     * Class name of the scrollable header element
     */
    scrollableHeader = "p-treetable-scrollable-header",
    /**
     * Class name of the scrollable header box element
     */
    scrollableHeaderBox = "p-treetable-scrollable-header-box",
    /**
     * Class name of the scrollable header table element
     */
    scrollableHeaderTable = "p-treetable-scrollable-header-table",
    /**
     * Class name of the scrollable body element
     */
    scrollableBody = "p-treetable-scrollable-body",
    /**
     * Class name of the scrollable footer element
     */
    scrollableFooter = "p-treetable-scrollable-footer",
    /**
     * Class name of the scrollable footer box element
     */
    scrollableFooterBox = "p-treetable-scrollable-footer-box",
    /**
     * Class name of the scrollable footer table element
     */
    scrollableFooterTable = "p-treetable-scrollable-footer-table",
    /**
     * Class name of the sortable column icon element
     */
    sortableColumnIcon = "p-sortable-column-icon"
}

declare class TreeTableService {
    private sortSource;
    private selectionSource;
    private contextMenuSource;
    private uiUpdateSource;
    private totalRecordsSource;
    sortSource$: rxjs.Observable<SortMeta | SortMeta[] | null>;
    selectionSource$: rxjs.Observable<unknown>;
    contextMenuSource$: rxjs.Observable<any>;
    uiUpdateSource$: rxjs.Observable<any>;
    totalRecordsSource$: rxjs.Observable<any>;
    onSort(sortMeta: SortMeta | SortMeta[] | null): void;
    onSelectionChange(): void;
    onContextMenu(node: any): void;
    onUIUpdate(value: any): void;
    onTotalRecordsChange(value: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TreeTableService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TreeTableService>;
}
/**
 * TreeTable is used to display hierarchical data in tabular format.
 * @group Components
 */
declare class TreeTable extends BaseComponent<TreeTablePassThrough> implements BlockableUI {
    componentName: string;
    _componentStyle: TreeTableStyle;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * An array of objects to represent dynamic columns.
     * @group Props
     */
    readonly columns: _angular_core.InputSignal<any[] | undefined>;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    readonly styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the table.
     * @group Props
     */
    readonly tableStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the table.
     * @group Props
     */
    readonly tableStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether the cell widths scale according to their content or not.
     * @group Props
     */
    readonly autoLayout: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Defines if data is loaded and interacted with in lazy manner.
     * @group Props
     */
    readonly lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to call lazy loading on initialization.
     * @group Props
     */
    readonly lazyLoadOnInit: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When specified as true, enables the pagination.
     * @group Props
     */
    readonly paginator: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Number of rows to display per page.
     * @group Props
     */
    readonly rows: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Index of the first row to be displayed.
     * @group Props
     */
    readonly first: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Number of page links to display in paginator.
     * @group Props
     */
    readonly pageLinks: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Array of integer/object values to display inside rows per page dropdown of paginator
     * @group Props
     */
    readonly rowsPerPageOptions: _angular_core.InputSignal<any[] | undefined>;
    /**
     * Whether to show it even there is only one page.
     * @group Props
     */
    readonly alwaysShowPaginator: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Position of the paginator.
     * @group Props
     */
    readonly paginatorPosition: _angular_core.InputSignal<"top" | "bottom" | "both">;
    /**
     * Custom style class for paginator
     * @group Props
     */
    readonly paginatorStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Target element to attach the paginator dropdown overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @group Props
     */
    readonly paginatorDropdownAppendTo: _angular_core.InputSignal<any>;
    /**
     * Template of the current page report element. Available placeholders are {currentPage},{totalPages},{rows},{first},{last} and {totalRecords}
     * @group Props
     */
    readonly currentPageReportTemplate: _angular_core.InputSignal<string>;
    /**
     * Whether to display current page report.
     * @group Props
     */
    readonly showCurrentPageReport: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Whether to display a dropdown to navigate to any page.
     * @group Props
     */
    readonly showJumpToPageDropdown: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When enabled, icons are displayed on paginator to go first and last page.
     * @group Props
     */
    readonly showFirstLastIcon: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to show page links.
     * @group Props
     */
    readonly showPageLinks: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Sort order to use when an unsorted column gets sorted by user interaction.
     * @group Props
     */
    readonly defaultSortOrder: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Defines whether sorting works on single column or on multiple columns.
     * @group Props
     */
    readonly sortMode: _angular_core.InputSignal<"single" | "multiple">;
    /**
     * When true, resets paginator to first page after sorting.
     * @group Props
     */
    readonly resetPageOnSort: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to use the default sorting or a custom one using sortFunction.
     * @group Props
     */
    readonly customSort: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Specifies the selection mode, valid values are "single" and "multiple".
     * @group Props
     */
    readonly selectionMode: _angular_core.InputSignal<string | undefined>;
    /**
     * Selected row with a context menu.
     * @group Props
     */
    readonly contextMenuSelection: _angular_core.InputSignal<any>;
    /**
     * Mode of the contet menu selection.
     * @group Props
     */
    readonly contextMenuSelectionMode: _angular_core.InputSignal<string>;
    /**
     * A property to uniquely identify a record in data.
     * @group Props
     */
    readonly dataKey: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines whether metaKey is should be considered for the selection. On touch enabled devices, metaKeySelection is turned off automatically.
     * @group Props
     */
    readonly metaKeySelection: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Algorithm to define if a row is selected, valid values are "equals" that compares by reference and "deepEquals" that compares all fields.
     * @group Props
     */
    readonly compareSelectionBy: _angular_core.InputSignal<string>;
    /**
     * Adds hover effect to rows without the need for selectionMode.
     * @group Props
     */
    readonly rowHover: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Displays a loader to indicate data load is in progress.
     * @group Props
     */
    readonly loading: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * The icon to show while indicating data load is in progress.
     * @group Props
     */
    readonly loadingIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to show the loading mask when loading property is true.
     * @group Props
     */
    readonly showLoader: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When specified, enables horizontal and/or vertical scrolling.
     * @group Props
     */
    readonly scrollable: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Height of the scroll viewport in fixed pixels or the "flex" keyword for a dynamic size.
     * @group Props
     */
    readonly scrollHeight: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether the data should be loaded on demand during scroll.
     * @group Props
     */
    readonly virtualScroll: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Height of a row to use in calculations of virtual scrolling.
     * @group Props
     */
    readonly virtualScrollItemSize: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Whether to use the scroller feature. The properties of scroller component can be used like an object in it.
     * @group Props
     */
    readonly virtualScrollOptions: _angular_core.InputSignal<ScrollerOptions | undefined>;
    /**
     * The delay (in milliseconds) before triggering the virtual scroll. This determines the time gap between the user's scroll action and the actual rendering of the next set of items in the virtual scroll.
     * @group Props
     */
    readonly virtualScrollDelay: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Width of the frozen columns container.
     * @group Props
     */
    readonly frozenWidth: _angular_core.InputSignal<string | undefined>;
    /**
     * An array of objects to represent dynamic columns that are frozen.
     * @group Props
     */
    readonly frozenColumns: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * When enabled, columns can be resized using drag and drop.
     * @group Props
     */
    readonly resizableColumns: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Defines whether the overall table width should change on column resize, valid values are "fit" and "expand".
     * @group Props
     */
    readonly columnResizeMode: _angular_core.InputSignal<string>;
    /**
     * When enabled, columns can be reordered using drag and drop.
     * @group Props
     */
    readonly reorderableColumns: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Local ng-template varilable of a ContextMenu.
     * @group Props
     */
    readonly contextMenu: _angular_core.InputSignal<any>;
    /**
     * Function to optimize the dom operations by delegating to ngForTrackBy, default algorithm checks for object identity.
     * @group Props
     */
    readonly rowTrackBy: _angular_core.InputSignal<(...args: any[]) => any>;
    /**
     * An array of FilterMetadata objects to provide external filters.
     * @group Props
     */
    readonly filters: _angular_core.InputSignal<{
        [s: string]: FilterMetadata | undefined;
    }>;
    /**
     * An array of fields as string to use in global filtering.
     * @group Props
     */
    readonly globalFilterFields: _angular_core.InputSignal<string[] | undefined>;
    /**
     * Delay in milliseconds before filtering the data.
     * @group Props
     */
    readonly filterDelay: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Mode for filtering valid values are "lenient" and "strict". Default is lenient.
     * @group Props
     */
    readonly filterMode: _angular_core.InputSignal<string>;
    /**
     * Locale to use in filtering. The default locale is the host environment's current locale.
     * @group Props
     */
    readonly filterLocale: _angular_core.InputSignal<string | undefined>;
    /**
     * Locale to be used in paginator formatting.
     * @group Props
     */
    readonly paginatorLocale: _angular_core.InputSignal<string | undefined>;
    /**
     * Number of total records, defaults to length of value when not defined.
     * @group Props
     */
    readonly totalRecords: _angular_core.InputSignal<number>;
    /**
     * Name of the field to sort data by default.
     * @group Props
     */
    readonly sortField: _angular_core.InputSignal<string | null | undefined>;
    /**
     * Order to sort when default sorting is enabled.
     * @defaultValue 1
     * @group Props
     */
    readonly sortOrder: _angular_core.InputSignal<number>;
    /**
     * An array of SortMeta objects to sort the data by default in multiple sort mode.
     * @defaultValue null
     * @group Props
     */
    readonly multiSortMeta: _angular_core.InputSignal<SortMeta[] | null | undefined>;
    /**
     * Selected row in single mode or an array of values in multiple mode.
     * @defaultValue null
     * @group Props
     */
    readonly selection: _angular_core.InputSignal<any>;
    /**
     * An array of objects to display.
     * @defaultValue null
     * @group Props
     */
    readonly value: _angular_core.InputSignal<TreeNode<any>[] | undefined>;
    /**
     * Indicates the height of rows to be scrolled.
     * @defaultValue 28
     * @group Props
     * @deprecated use virtualScrollItemSize property instead.
     */
    readonly virtualRowHeight: _angular_core.InputSignal<number>;
    /**
     * A map of keys to control the selection state.
     * @group Props
     */
    readonly selectionKeys: _angular_core.InputSignal<any>;
    /**
     * Whether to show grid lines between cells.
     * @defaultValue false
     * @group Props
     */
    readonly showGridlines: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Callback to invoke on selected node change.
     * @param {TreeTableNode} object - Node instance.
     * @group Emits
     */
    selectionChange: _angular_core.OutputEmitterRef<TreeTableNode<any> | TreeTableNode<any>[] | null>;
    /**
     * Callback to invoke on context menu selection change.
     * @param {TreeTableNode} object - Node instance.
     * @group Emits
     */
    contextMenuSelectionChange: _angular_core.OutputEmitterRef<TreeTableNode<any>>;
    /**
     * Callback to invoke when data is filtered.
     * @param {TreeTableFilterEvent} event - Custom filter event.
     * @group Emits
     */
    onFilter: _angular_core.OutputEmitterRef<TreeTableFilterEvent>;
    /**
     * Callback to invoke when a node is expanded.
     * @param {TreeTableNodeExpandEvent} event - Node expand event.
     * @group Emits
     */
    onNodeExpand: _angular_core.OutputEmitterRef<TreeTableNodeExpandEvent>;
    /**
     * Callback to invoke when a node is collapsed.
     * @param {TreeTableNodeCollapseEvent} event - Node collapse event.
     * @group Emits
     */
    onNodeCollapse: _angular_core.OutputEmitterRef<TreeTableNodeCollapseEvent<any>>;
    /**
     * Callback to invoke when pagination occurs.
     * @param {TreeTablePaginatorState} object - Paginator state.
     * @group Emits
     */
    onPage: _angular_core.OutputEmitterRef<TreeTablePaginatorState>;
    /**
     * Callback to invoke when a column gets sorted.
     * @param {Object} Object - Sort data.
     * @group Emits
     */
    onSort: _angular_core.OutputEmitterRef<any>;
    /**
     * Callback to invoke when paging, sorting or filtering happens in lazy mode.
     * @param {TreeTableLazyLoadEvent} event - Custom lazy load event.
     * @group Emits
     */
    onLazyLoad: _angular_core.OutputEmitterRef<TreeTableLazyLoadEvent>;
    /**
     * An event emitter to invoke on custom sorting, refer to sorting section for details.
     * @param {TreeTableSortEvent} event - Custom sort event.
     * @group Emits
     */
    sortFunction: _angular_core.OutputEmitterRef<TreeTableSortEvent>;
    /**
     * Callback to invoke when a column is resized.
     * @param {TreeTableColResizeEvent} event - Custom column resize event.
     * @group Emits
     */
    onColResize: _angular_core.OutputEmitterRef<TreeTableColResizeEvent>;
    /**
     * Callback to invoke when a column is reordered.
     * @param {TreeTableColumnReorderEvent} event - Custom column reorder.
     * @group Emits
     */
    onColReorder: _angular_core.OutputEmitterRef<TreeTableColumnReorderEvent>;
    /**
     * Callback to invoke when a node is selected.
     * @param {TreeTableNode} object - Node instance.
     * @group Emits
     */
    onNodeSelect: _angular_core.OutputEmitterRef<TreeTableNode<any>>;
    /**
     * Callback to invoke when a node is unselected.
     * @param {TreeTableNodeUnSelectEvent} event - Custom node unselect event.
     * @group Emits
     */
    onNodeUnselect: _angular_core.OutputEmitterRef<TreeTableNodeUnSelectEvent>;
    /**
     * Callback to invoke when a node is selected with right click.
     * @param {TreeTableContextMenuSelectEvent} event - Custom context menu select event.
     * @group Emits
     */
    onContextMenuSelect: _angular_core.OutputEmitterRef<TreeTableContextMenuSelectEvent>;
    /**
     * Callback to invoke when state of header checkbox changes.
     * @param {TreeTableHeaderCheckboxToggleEvent} event - Custom checkbox toggle event.
     * @group Emits
     */
    onHeaderCheckboxToggle: _angular_core.OutputEmitterRef<TreeTableHeaderCheckboxToggleEvent>;
    /**
     * Callback to invoke when a cell switches to edit mode.
     * @param {TreeTableEditEvent} event - Custom edit event.
     * @group Emits
     */
    onEditInit: _angular_core.OutputEmitterRef<TreeTableEditEvent>;
    /**
     * Callback to invoke when cell edit is completed.
     * @param {TreeTableEditEvent} event - Custom edit event.
     * @group Emits
     */
    onEditComplete: _angular_core.OutputEmitterRef<TreeTableEditEvent>;
    /**
     * Callback to invoke when cell edit is cancelled with escape key.
     * @param {TreeTableEditEvent} event - Custom edit event.
     * @group Emits
     */
    onEditCancel: _angular_core.OutputEmitterRef<TreeTableEditEvent>;
    /**
     * Callback to invoke when selectionKeys are changed.
     * @param {Object} object - updated value of the selectionKeys.
     * @group Emits
     */
    selectionKeysChange: _angular_core.OutputEmitterRef<any>;
    readonly resizeHelperViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly reorderIndicatorUpViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly reorderIndicatorDownViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly tableViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly scrollableViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly scrollableFrozenViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    _value: TreeNode<any>[] | undefined;
    _virtualRowHeight: number;
    _selectionKeys: any;
    serializedValue: any[] | undefined | null;
    _totalRecords: number;
    _multiSortMeta: SortMeta[] | undefined | null;
    _sortField: string | undefined | null;
    _sortOrder: number;
    _first: number;
    _rows: number | undefined;
    _filters: {
        [key: string]: any;
    };
    _contextMenuSelection: any;
    filteredNodes: Nullable<any[]>;
    filterTimeout: any;
    readonly _colGroupTemplate: _angular_core.Signal<Nullable<TemplateRef<TreeTableColumnsTemplateContext>>>;
    colGroupTemplate: Nullable<TemplateRef<TreeTableColumnsTemplateContext>>;
    _captionTemplate: Nullable<TemplateRef<void>>;
    captionTemplate: Nullable<TemplateRef<void>>;
    readonly _headerTemplate: _angular_core.Signal<Nullable<TemplateRef<TreeTableColumnsTemplateContext>>>;
    headerTemplate: Nullable<TemplateRef<TreeTableColumnsTemplateContext>>;
    readonly _bodyTemplate: _angular_core.Signal<Nullable<TemplateRef<TreeTableBodyTemplateContext>>>;
    bodyTemplate: Nullable<TemplateRef<TreeTableBodyTemplateContext>>;
    _footerTemplate: Nullable<TemplateRef<TreeTableColumnsTemplateContext>>;
    footerTemplate: Nullable<TemplateRef<TreeTableColumnsTemplateContext>>;
    _summaryTemplate: Nullable<TemplateRef<void>>;
    summaryTemplate: Nullable<TemplateRef<void>>;
    readonly _emptyMessageTemplate: _angular_core.Signal<Nullable<TemplateRef<TreeTableEmptyMessageTemplateContext>>>;
    emptyMessageTemplate: Nullable<TemplateRef<TreeTableEmptyMessageTemplateContext>>;
    readonly _paginatorLeftTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    paginatorLeftTemplate: Nullable<TemplateRef<void>>;
    readonly _paginatorRightTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    paginatorRightTemplate: Nullable<TemplateRef<void>>;
    readonly _paginatorDropdownItemTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    paginatorDropdownItemTemplate: Nullable<TemplateRef<void>>;
    readonly _frozenHeaderTemplate: _angular_core.Signal<Nullable<TemplateRef<TreeTableColumnsTemplateContext>>>;
    frozenHeaderTemplate: Nullable<TemplateRef<TreeTableColumnsTemplateContext>>;
    readonly _frozenBodyTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    frozenBodyTemplate: Nullable<TemplateRef<void>>;
    readonly _frozenFooterTemplate: _angular_core.Signal<Nullable<TemplateRef<TreeTableColumnsTemplateContext>>>;
    frozenFooterTemplate: Nullable<TemplateRef<TreeTableColumnsTemplateContext>>;
    readonly _frozenColGroupTemplate: _angular_core.Signal<Nullable<TemplateRef<TreeTableColumnsTemplateContext>>>;
    frozenColGroupTemplate: Nullable<TemplateRef<TreeTableColumnsTemplateContext>>;
    _loadingIconTemplate: Nullable<TemplateRef<void>>;
    loadingIconTemplate: Nullable<TemplateRef<void>>;
    readonly _reorderIndicatorUpIconTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    reorderIndicatorUpIconTemplate: Nullable<TemplateRef<void>>;
    readonly _reorderIndicatorDownIconTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    reorderIndicatorDownIconTemplate: Nullable<TemplateRef<void>>;
    _sortIconTemplate: Nullable<TemplateRef<TreeTableSortIconTemplateContext>>;
    sortIconTemplate: Nullable<TemplateRef<TreeTableSortIconTemplateContext>>;
    _checkboxIconTemplate: Nullable<TemplateRef<TreeTableCheckboxIconTemplateContext>>;
    checkboxIconTemplate: Nullable<TemplateRef<TreeTableCheckboxIconTemplateContext>>;
    _headerCheckboxIconTemplate: Nullable<TemplateRef<TreeTableHeaderCheckboxIconTemplateContext>>;
    headerCheckboxIconTemplate: Nullable<TemplateRef<TreeTableHeaderCheckboxIconTemplateContext>>;
    readonly _togglerIconTemplate: _angular_core.Signal<Nullable<TemplateRef<TreeTableTogglerIconTemplateContext>>>;
    togglerIconTemplate: Nullable<TemplateRef<TreeTableTogglerIconTemplateContext>>;
    _paginatorFirstPageLinkIconTemplate: Nullable<TemplateRef<void>>;
    paginatorFirstPageLinkIconTemplate: Nullable<TemplateRef<void>>;
    _paginatorLastPageLinkIconTemplate: Nullable<TemplateRef<void>>;
    paginatorLastPageLinkIconTemplate: Nullable<TemplateRef<void>>;
    _paginatorPreviousPageLinkIconTemplate: Nullable<TemplateRef<void>>;
    paginatorPreviousPageLinkIconTemplate: Nullable<TemplateRef<void>>;
    _paginatorNextPageLinkIconTemplate: Nullable<TemplateRef<void>>;
    paginatorNextPageLinkIconTemplate: Nullable<TemplateRef<void>>;
    _loaderTemplate: Nullable<TemplateRef<void>>;
    loaderTemplate: Nullable<TemplateRef<void>>;
    lastResizerHelperX: Nullable<number>;
    reorderIconWidth: Nullable<number>;
    reorderIconHeight: Nullable<number>;
    draggedColumn: Nullable<any[]>;
    dropPosition: Nullable<number>;
    preventSelectionSetterPropagation: Nullable<boolean>;
    _selection: any;
    selectedKeys: any;
    rowTouched: Nullable<boolean>;
    editingCell: Nullable<Element>;
    editingCellData: any | undefined | null;
    editingCellField: any | undefined | null;
    editingCellClick: Nullable<boolean>;
    documentEditListener: VoidListener;
    initialized: Nullable<boolean>;
    toggleRowIndex: Nullable<number>;
    onInit(): void;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    onAfterContentInit(): void;
    filterService: FilterService;
    tableService: TreeTableService;
    zone: NgZone;
    private _prevValue;
    private _prevSortField;
    private _prevSortOrder;
    private _prevMultiSortMeta;
    private _prevSelection;
    constructor();
    updateSerializedValue(): void;
    serializeNodes(parent: Nullable<TreeTableNode>, nodes: Nullable<TreeNode[]>, level: Nullable<number>, visible: Nullable<boolean>): void;
    serializePageNodes(): void;
    updateselectedKeys(): void;
    onPageChange(event: TreeTablePaginatorState): void;
    sort(event: TreeTableSortEvent): void;
    sortSingle(): void;
    sortNodes(nodes: TreeNode[]): void;
    sortMultiple(): void;
    sortMultipleNodes(nodes: TreeNode[]): void;
    multisortField(node1: TreeTableNode, node2: TreeTableNode, multiSortMeta: SortMeta[], index: number): number;
    getSortMeta(field: string): SortMeta | null;
    isSorted(field: string): boolean | "" | null | undefined;
    createLazyLoadMetadata(): any;
    onLazyItemLoad(event: TreeTableLazyLoadEvent): void;
    /**
     * Resets scroll to top.
     * @group Method
     */
    resetScrollTop(): void;
    /**
     * Scrolls to given index when using virtual scroll.
     * @param {number} index - index of the element.
     * @group Method
     */
    scrollToVirtualIndex(index: number): void;
    /**
     * Scrolls to given index.
     * @param {ScrollToOptions} options - Scroll options.
     * @group Method
     */
    scrollTo(options: ScrollToOptions): void;
    isEmpty(): boolean;
    getBlockableElement(): HTMLElement;
    onColumnResizeBegin(event: MouseEvent): void;
    onColumnResize(event: MouseEvent): void;
    onColumnResizeEnd(event: MouseEvent, column: any): void;
    findParentScrollableView(column: any): any;
    resizeColGroup(table: Nullable<HTMLElement>, resizeColumnIndex: Nullable<number>, newColumnWidth: Nullable<number>, nextColumnWidth: Nullable<number>): void;
    onColumnDragStart(event: DragEvent, columnElement: any): void;
    onColumnDragEnter(event: DragEvent, dropHeader: any): void;
    onColumnDragLeave(event: DragEvent): void;
    onColumnDrop(event: DragEvent, dropColumn: any): void;
    handleRowClick(event: any): void;
    handleRowTouchEnd(): void;
    handleRowRightClick(event: any): void;
    toggleNodeWithCheckbox(event: any): void;
    toggleNodesWithCheckbox(event: Event, check: boolean): void;
    toggleAll(checked: boolean): void;
    propagateSelectionUp(node: TreeTableNode, select: boolean): void;
    propagateSelectionDown(node: TreeTableNode, select: boolean): void;
    isSelected(node: TreeTableNode): boolean | undefined;
    isNodeSelected(node: any): boolean;
    isNodePartialSelected(node: any): boolean;
    nodeKey(node: any): any;
    toggleCheckbox(event: any): void;
    propagateDown(node: any, check: any): void;
    propagateUp(node: any, check: any): void;
    findIndexInSelection(node: any): number;
    isSingleSelectionMode(): boolean;
    isMultipleSelectionMode(): boolean;
    equals(node1: TreeTableNode, node2: TreeTableNode): boolean;
    filter(value: string | string[], field: string, matchMode: string): void;
    filterGlobal(value: string, matchMode: string): void;
    isFilterBlank(filter: any): boolean;
    _filter(): void;
    findFilteredNodes(node: TreeTableNode, paramsWithoutNode: any): true | undefined;
    isFilterMatched(node: TreeTableNode, filterOptions: TreeTableFilterOptions): boolean;
    isNodeLeaf(node: TreeTableNode): boolean;
    hasFilter(): boolean;
    /**
     * Clears the sort and paginator state.
     * @group Method
     */
    reset(): void;
    updateEditingCell(cell: any, data: any, field: string): void;
    isEditingCellValid(): boolean | null | undefined;
    bindDocumentEditListener(): void;
    unbindDocumentEditListener(): void;
    onDestroy(): void;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TreeTable, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TreeTable, "p-treeTable, p-treetable, p-tree-table", never, { "columns": { "alias": "columns"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "tableStyle": { "alias": "tableStyle"; "required": false; "isSignal": true; }; "tableStyleClass": { "alias": "tableStyleClass"; "required": false; "isSignal": true; }; "autoLayout": { "alias": "autoLayout"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "lazyLoadOnInit": { "alias": "lazyLoadOnInit"; "required": false; "isSignal": true; }; "paginator": { "alias": "paginator"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "first": { "alias": "first"; "required": false; "isSignal": true; }; "pageLinks": { "alias": "pageLinks"; "required": false; "isSignal": true; }; "rowsPerPageOptions": { "alias": "rowsPerPageOptions"; "required": false; "isSignal": true; }; "alwaysShowPaginator": { "alias": "alwaysShowPaginator"; "required": false; "isSignal": true; }; "paginatorPosition": { "alias": "paginatorPosition"; "required": false; "isSignal": true; }; "paginatorStyleClass": { "alias": "paginatorStyleClass"; "required": false; "isSignal": true; }; "paginatorDropdownAppendTo": { "alias": "paginatorDropdownAppendTo"; "required": false; "isSignal": true; }; "currentPageReportTemplate": { "alias": "currentPageReportTemplate"; "required": false; "isSignal": true; }; "showCurrentPageReport": { "alias": "showCurrentPageReport"; "required": false; "isSignal": true; }; "showJumpToPageDropdown": { "alias": "showJumpToPageDropdown"; "required": false; "isSignal": true; }; "showFirstLastIcon": { "alias": "showFirstLastIcon"; "required": false; "isSignal": true; }; "showPageLinks": { "alias": "showPageLinks"; "required": false; "isSignal": true; }; "defaultSortOrder": { "alias": "defaultSortOrder"; "required": false; "isSignal": true; }; "sortMode": { "alias": "sortMode"; "required": false; "isSignal": true; }; "resetPageOnSort": { "alias": "resetPageOnSort"; "required": false; "isSignal": true; }; "customSort": { "alias": "customSort"; "required": false; "isSignal": true; }; "selectionMode": { "alias": "selectionMode"; "required": false; "isSignal": true; }; "contextMenuSelection": { "alias": "contextMenuSelection"; "required": false; "isSignal": true; }; "contextMenuSelectionMode": { "alias": "contextMenuSelectionMode"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "metaKeySelection": { "alias": "metaKeySelection"; "required": false; "isSignal": true; }; "compareSelectionBy": { "alias": "compareSelectionBy"; "required": false; "isSignal": true; }; "rowHover": { "alias": "rowHover"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "loadingIcon": { "alias": "loadingIcon"; "required": false; "isSignal": true; }; "showLoader": { "alias": "showLoader"; "required": false; "isSignal": true; }; "scrollable": { "alias": "scrollable"; "required": false; "isSignal": true; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; "isSignal": true; }; "virtualScroll": { "alias": "virtualScroll"; "required": false; "isSignal": true; }; "virtualScrollItemSize": { "alias": "virtualScrollItemSize"; "required": false; "isSignal": true; }; "virtualScrollOptions": { "alias": "virtualScrollOptions"; "required": false; "isSignal": true; }; "virtualScrollDelay": { "alias": "virtualScrollDelay"; "required": false; "isSignal": true; }; "frozenWidth": { "alias": "frozenWidth"; "required": false; "isSignal": true; }; "frozenColumns": { "alias": "frozenColumns"; "required": false; "isSignal": true; }; "resizableColumns": { "alias": "resizableColumns"; "required": false; "isSignal": true; }; "columnResizeMode": { "alias": "columnResizeMode"; "required": false; "isSignal": true; }; "reorderableColumns": { "alias": "reorderableColumns"; "required": false; "isSignal": true; }; "contextMenu": { "alias": "contextMenu"; "required": false; "isSignal": true; }; "rowTrackBy": { "alias": "rowTrackBy"; "required": false; "isSignal": true; }; "filters": { "alias": "filters"; "required": false; "isSignal": true; }; "globalFilterFields": { "alias": "globalFilterFields"; "required": false; "isSignal": true; }; "filterDelay": { "alias": "filterDelay"; "required": false; "isSignal": true; }; "filterMode": { "alias": "filterMode"; "required": false; "isSignal": true; }; "filterLocale": { "alias": "filterLocale"; "required": false; "isSignal": true; }; "paginatorLocale": { "alias": "paginatorLocale"; "required": false; "isSignal": true; }; "totalRecords": { "alias": "totalRecords"; "required": false; "isSignal": true; }; "sortField": { "alias": "sortField"; "required": false; "isSignal": true; }; "sortOrder": { "alias": "sortOrder"; "required": false; "isSignal": true; }; "multiSortMeta": { "alias": "multiSortMeta"; "required": false; "isSignal": true; }; "selection": { "alias": "selection"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "virtualRowHeight": { "alias": "virtualRowHeight"; "required": false; "isSignal": true; }; "selectionKeys": { "alias": "selectionKeys"; "required": false; "isSignal": true; }; "showGridlines": { "alias": "showGridlines"; "required": false; "isSignal": true; }; }, { "selectionChange": "selectionChange"; "contextMenuSelectionChange": "contextMenuSelectionChange"; "onFilter": "onFilter"; "onNodeExpand": "onNodeExpand"; "onNodeCollapse": "onNodeCollapse"; "onPage": "onPage"; "onSort": "onSort"; "onLazyLoad": "onLazyLoad"; "sortFunction": "sortFunction"; "onColResize": "onColResize"; "onColReorder": "onColReorder"; "onNodeSelect": "onNodeSelect"; "onNodeUnselect": "onNodeUnselect"; "onContextMenuSelect": "onContextMenuSelect"; "onHeaderCheckboxToggle": "onHeaderCheckboxToggle"; "onEditInit": "onEditInit"; "onEditComplete": "onEditComplete"; "onEditCancel": "onEditCancel"; "selectionKeysChange": "selectionKeysChange"; }, ["_colGroupTemplate", "_headerTemplate", "_bodyTemplate", "_emptyMessageTemplate", "_paginatorLeftTemplate", "_paginatorRightTemplate", "_paginatorDropdownItemTemplate", "_frozenHeaderTemplate", "_frozenBodyTemplate", "_frozenFooterTemplate", "_frozenColGroupTemplate", "_reorderIndicatorUpIconTemplate", "_reorderIndicatorDownIconTemplate", "_togglerIconTemplate", "templates", "_captionTemplate", "_footerTemplate", "_summaryTemplate", "_loadingIconTemplate", "_sortIconTemplate", "_checkboxIconTemplate", "_headerCheckboxIconTemplate", "_paginatorFirstPageLinkIconTemplate", "_paginatorLastPageLinkIconTemplate", "_paginatorPreviousPageLinkIconTemplate", "_paginatorNextPageLinkIconTemplate", "_loaderTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class TTBody extends BaseComponent {
    tt: TreeTable;
    treeTableService: TreeTableService;
    readonly columns: _angular_core.InputSignal<any[] | undefined>;
    readonly template: _angular_core.InputSignal<Nullable<TemplateRef<any>>>;
    readonly frozen: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly serializedNodes: _angular_core.InputSignal<any>;
    readonly scrollerOptions: _angular_core.InputSignal<any>;
    subscription: Subscription;
    constructor();
    getScrollerOption(option: any, options?: any): any;
    getRowIndex(rowIndex: number): any;
    onDestroy(): void;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TTBody, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TTBody, "[pTreeTableBody]", never, { "columns": { "alias": "pTreeTableBody"; "required": false; "isSignal": true; }; "template": { "alias": "pTreeTableBodyTemplate"; "required": false; "isSignal": true; }; "frozen": { "alias": "frozen"; "required": false; "isSignal": true; }; "serializedNodes": { "alias": "serializedNodes"; "required": false; "isSignal": true; }; "scrollerOptions": { "alias": "scrollerOptions"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class TTScrollableView extends BaseComponent {
    tt: TreeTable;
    zone: NgZone;
    hostName: string;
    readonly columns: _angular_core.InputSignal<any[] | undefined>;
    readonly frozen: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly scrollHeaderViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly scrollHeaderBoxViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly scrollBodyViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly scrollTableViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly scrollLoadingTableViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly scrollFooterViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly scrollFooterBoxViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly scrollableAlignerViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly scroller: _angular_core.Signal<Nullable<Scroller>>;
    headerScrollListener: VoidListener;
    bodyScrollListener: VoidListener;
    footerScrollListener: VoidListener;
    frozenSiblingBody: Nullable<Element>;
    totalRecordsSubscription: Nullable<Subscription>;
    _scrollHeight: string | undefined | null;
    preventBodyScrollPropagation: boolean | undefined;
    _componentStyle: TreeTableStyle;
    readonly scrollHeight: _angular_core.InputSignal<string | null | undefined>;
    constructor();
    onAfterViewInit(): void;
    bindEvents(): void;
    unbindEvents(): void;
    onHeaderScroll(): void;
    onFooterScroll(): void;
    onBodyScroll(event: any): void;
    scrollToVirtualIndex(index: number): void;
    scrollTo(options: ScrollToOptions): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TTScrollableView, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TTScrollableView, "[ttScrollableView]", never, { "columns": { "alias": "ttScrollableView"; "required": false; "isSignal": true; }; "frozen": { "alias": "frozen"; "required": false; "isSignal": true; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class TTSortableColumn extends BaseComponent {
    tt: TreeTable;
    hostName: string;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    readonly field: _angular_core.InputSignal<string | undefined>;
    readonly ttSortableColumnDisabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    sorted: boolean | undefined;
    subscription: Subscription | undefined;
    _componentStyle: TreeTableStyle;
    get ariaSorted(): "none" | "descending" | "ascending";
    constructor();
    onInit(): void;
    updateSortState(): void;
    onClick(event: MouseEvent): void;
    onEnterKey(event: MouseEvent): void;
    isEnabled(): boolean;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TTSortableColumn, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TTSortableColumn, "[ttSortableColumn]", never, { "field": { "alias": "ttSortableColumn"; "required": false; "isSignal": true; }; "ttSortableColumnDisabled": { "alias": "ttSortableColumnDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class TTSortIcon extends BaseComponent {
    tt: TreeTable;
    cd: ChangeDetectorRef;
    hostName: string;
    readonly field: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelDesc: _angular_core.InputSignal<string | undefined>;
    readonly ariaLabelAsc: _angular_core.InputSignal<string | undefined>;
    subscription: Subscription | undefined;
    sortOrder: number | undefined;
    _componentStyle: TreeTableStyle;
    constructor();
    onInit(): void;
    onClick(event: Event): void;
    getMultiSortMetaIndex(): number;
    updateSortState(): void;
    getBadgeValue(): number;
    isMultiSorted(): boolean;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TTSortIcon, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TTSortIcon, "p-treeTableSortIcon, p-treetable-sort-icon, p-tree-table-sort-icon", never, { "field": { "alias": "field"; "required": false; "isSignal": true; }; "ariaLabelDesc": { "alias": "ariaLabelDesc"; "required": false; "isSignal": true; }; "ariaLabelAsc": { "alias": "ariaLabelAsc"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class TTResizableColumn extends BaseComponent {
    tt: TreeTable;
    zone: NgZone;
    hostName: string;
    readonly ttResizableColumnDisabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    resizer: HTMLSpanElement | undefined;
    resizerMouseDownListener: VoidListener;
    documentMouseMoveListener: VoidListener;
    documentMouseUpListener: VoidListener;
    onAfterViewInit(): void;
    bindDocumentEvents(): void;
    unbindDocumentEvents(): void;
    onMouseDown(event: MouseEvent): void;
    onDocumentMouseMove(event: MouseEvent): void;
    onDocumentMouseUp(event: MouseEvent): void;
    isEnabled(): boolean;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TTResizableColumn, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TTResizableColumn, "[ttResizableColumn]", never, { "ttResizableColumnDisabled": { "alias": "ttResizableColumnDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class TTReorderableColumn extends BaseComponent {
    tt: TreeTable;
    zone: NgZone;
    hostName: string;
    readonly ttReorderableColumnDisabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    dragStartListener: VoidListener;
    dragOverListener: VoidListener;
    dragEnterListener: VoidListener;
    dragLeaveListener: VoidListener;
    mouseDownListener: VoidListener;
    onAfterViewInit(): void;
    bindEvents(): void;
    unbindEvents(): void;
    onMouseDown(event: any): void;
    onDragStart(event: DragEvent): void;
    onDragOver(event: DragEvent): void;
    onDragEnter(event: DragEvent): void;
    onDragLeave(event: DragEvent): void;
    onDrop(event: DragEvent): void;
    isEnabled(): boolean;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TTReorderableColumn, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TTReorderableColumn, "[ttReorderableColumn]", never, { "ttReorderableColumnDisabled": { "alias": "ttReorderableColumnDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class TTSelectableRow extends BaseComponent {
    tt: TreeTable;
    tableService: TreeTableService;
    readonly rowNode: _angular_core.InputSignal<any>;
    readonly ttSelectableRowDisabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    selected: boolean | undefined;
    subscription: Subscription | undefined;
    _componentStyle: TreeTableStyle;
    constructor();
    onInit(): void;
    onClick(event: Event): void;
    onKeyDown(event: KeyboardEvent): void;
    onTouchEnd(): void;
    onEnterKey(event: any): void;
    isEnabled(): boolean;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TTSelectableRow, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TTSelectableRow, "[ttSelectableRow]", never, { "rowNode": { "alias": "ttSelectableRow"; "required": false; "isSignal": true; }; "ttSelectableRowDisabled": { "alias": "ttSelectableRowDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class TTSelectableRowDblClick extends BaseComponent {
    tt: TreeTable;
    tableService: TreeTableService;
    readonly rowNode: _angular_core.InputSignal<any>;
    readonly ttSelectableRowDisabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    selected: boolean | undefined;
    subscription: Subscription | undefined;
    _componentStyle: TreeTableStyle;
    constructor();
    onInit(): void;
    onClick(event: Event): void;
    isEnabled(): boolean;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TTSelectableRowDblClick, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TTSelectableRowDblClick, "[ttSelectableRowDblClick]", never, { "rowNode": { "alias": "ttSelectableRowDblClick"; "required": false; "isSignal": true; }; "ttSelectableRowDisabled": { "alias": "ttSelectableRowDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class TTContextMenuRow extends BaseComponent {
    tt: TreeTable;
    tableService: TreeTableService;
    readonly rowNode: _angular_core.InputSignal<any>;
    readonly ttContextMenuRowDisabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    selected: boolean | undefined;
    subscription: Subscription | undefined;
    _componentStyle: TreeTableStyle;
    constructor();
    onContextMenu(event: Event): void;
    isEnabled(): boolean;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TTContextMenuRow, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TTContextMenuRow, "[ttContextMenuRow]", never, { "rowNode": { "alias": "ttContextMenuRow"; "required": false; "isSignal": true; }; "ttContextMenuRowDisabled": { "alias": "ttContextMenuRowDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class TTCheckbox extends BaseComponent {
    tt: TreeTable;
    tableService: TreeTableService;
    cd: ChangeDetectorRef;
    hostName: string;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly rowNode: _angular_core.InputSignal<any>;
    checked: boolean | undefined;
    partialChecked: boolean | undefined;
    focused: boolean | undefined;
    subscription: Subscription | undefined;
    _componentStyle: TreeTableStyle;
    constructor();
    onInit(): void;
    onClick(event: Event): void;
    onFocus(): void;
    onBlur(): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TTCheckbox, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TTCheckbox, "p-treeTableCheckbox, p-treetable-checkbox, p-tree-table-checkbox", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "rowNode": { "alias": "value"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class TTHeaderCheckbox extends BaseComponent {
    tt: TreeTable;
    tableService: TreeTableService;
    checked: boolean | undefined;
    disabled: boolean | undefined;
    selectionChangeSubscription: Subscription;
    valueChangeSubscription: Subscription;
    constructor();
    onInit(): void;
    onClick(event: Event): void;
    onDestroy(): void;
    updateCheckedState(): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TTHeaderCheckbox, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TTHeaderCheckbox, "p-treeTableHeaderCheckbox, p-tree-table-header-checkbox, p-treetableheadercheckbox", never, {}, {}, never, never, true, never>;
}
declare class TTEditableColumn extends BaseComponent {
    tt: TreeTable;
    zone: NgZone;
    readonly data: _angular_core.InputSignal<any>;
    readonly field: _angular_core.InputSignal<any>;
    readonly ttEditableColumnDisabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    onAfterViewInit(): void;
    onClick(): void;
    openCell(): void;
    closeEditingCell(): void;
    onKeyDown(event: KeyboardEvent): void;
    findCell(element: any): any;
    moveToPreviousCell(event: KeyboardEvent): void;
    moveToNextCell(event: KeyboardEvent): void;
    findPreviousEditableColumn(cell: any): Element | null;
    findNextEditableColumn(cell: Element): Element | null;
    isEnabled(): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TTEditableColumn, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TTEditableColumn, "[ttEditableColumn]", never, { "data": { "alias": "ttEditableColumn"; "required": false; "isSignal": true; }; "field": { "alias": "ttEditableColumnField"; "required": false; "isSignal": true; }; "ttEditableColumnDisabled": { "alias": "ttEditableColumnDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class TreeTableCellEditor extends BaseComponent {
    tt: TreeTable;
    editableColumn: TTEditableColumn;
    hostName: string;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    inputTemplate: Nullable<TemplateRef<any>>;
    outputTemplate: Nullable<TemplateRef<any>>;
    onAfterContentInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TreeTableCellEditor, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TreeTableCellEditor, "p-treeTableCellEditor, p-treetablecelleditor, p-treetable-cell-editor", never, {}, {}, ["templates"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class TTRow extends BaseComponent {
    tt: TreeTable;
    el: ElementRef<any>;
    zone: NgZone;
    hostName: string;
    bindDirectiveInstance: Bind;
    treeTable: TreeTable;
    onAfterViewChecked(): void;
    get level(): any;
    get styleClass(): any;
    get expanded(): any;
    readonly rowNode: _angular_core.InputSignal<any>;
    _componentStyle: TreeTableStyle;
    onKeyDown(event: KeyboardEvent): void;
    onArrowDownKey(event: KeyboardEvent): void;
    onArrowUpKey(event: KeyboardEvent): void;
    onArrowRightKey(event: KeyboardEvent): void;
    onArrowLeftKey(event: KeyboardEvent): void;
    onHomeKey(event: KeyboardEvent): void;
    onEndKey(event: KeyboardEvent): void;
    onTabKey(): void;
    expand(event: Event): void;
    collapse(event: Event): void;
    focusRowChange(firstFocusableRow: any, currentFocusedRow: any): void;
    restoreFocus(index?: any): void;
    ptmOptions(): {
        context: {
            selectable: boolean;
            selected: boolean | undefined;
            scrollable: boolean | undefined;
            rowNode: any;
        };
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TTRow, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TTRow, "[ttRow]", never, { "rowNode": { "alias": "ttRow"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class TreeTableToggler extends BaseComponent {
    tt: TreeTable;
    hostName: string;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    readonly rowNode: _angular_core.InputSignal<any>;
    _componentStyle: TreeTableStyle;
    get toggleButtonAriaLabel(): string | undefined;
    onClick(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TreeTableToggler, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TreeTableToggler, "p-treeTableToggler, p-treetabletoggler, p-treetable-toggler", never, { "rowNode": { "alias": "rowNode"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class TreeTableModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TreeTableModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<TreeTableModule, never, [typeof i2.CommonModule, typeof i3.PaginatorModule, typeof i4.Ripple, typeof i5.Scroller, typeof i6.SpinnerIcon, typeof i6.ArrowDownIcon, typeof i6.ArrowUpIcon, typeof i6.SortAltIcon, typeof i6.SortAmountUpAltIcon, typeof i6.SortAmountDownIcon, typeof i7.BadgeModule, typeof i6.CheckIcon, typeof i6.ChevronDownIcon, typeof i6.ChevronRightIcon, typeof i8.Checkbox, typeof i9.SharedModule, typeof i10.FormsModule, typeof i1.BindModule, typeof TreeTable, typeof TreeTableToggler, typeof TTScrollableView, typeof TTBody, typeof TTSortableColumn, typeof TTSortIcon, typeof TTResizableColumn, typeof TTRow, typeof TTReorderableColumn, typeof TTSelectableRow, typeof TTSelectableRowDblClick, typeof TTContextMenuRow, typeof TTCheckbox, typeof TTHeaderCheckbox, typeof TTEditableColumn, typeof TreeTableCellEditor], [typeof TreeTable, typeof i9.SharedModule, typeof TreeTableToggler, typeof TTSortableColumn, typeof TTSortIcon, typeof TTResizableColumn, typeof TTRow, typeof TTReorderableColumn, typeof TTSelectableRow, typeof TTSelectableRowDblClick, typeof TTContextMenuRow, typeof TTCheckbox, typeof TTHeaderCheckbox, typeof TTEditableColumn, typeof TreeTableCellEditor, typeof i5.Scroller]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<TreeTableModule>;
}

export { TTBody, TTCheckbox, TTContextMenuRow, TTEditableColumn, TTHeaderCheckbox, TTReorderableColumn, TTResizableColumn, TTRow, TTScrollableView, TTSelectableRow, TTSelectableRowDblClick, TTSortIcon, TTSortableColumn, TreeTable, TreeTableCellEditor, TreeTableClasses, TreeTableModule, TreeTableService, TreeTableStyle, TreeTableToggler };
