import { CheckboxPassThrough, CheckboxChangeEvent, CheckboxIconTemplateContext } from '@wawjs/ngx-prime/types/checkbox';
export * from '@wawjs/ngx-prime/types/checkbox';
import * as _angular_core from '@angular/core';
import { ElementRef, TemplateRef } from '@angular/core';
import { FormControl } from '@angular/forms';
import * as i3 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';

declare class CheckboxStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-checkbox-checked p-highlight': any;
            'p-disabled': any;
            'p-invalid': any;
            'p-variant-filled': boolean;
            'p-checkbox-sm p-inputfield-sm': boolean;
            'p-checkbox-lg p-inputfield-lg': boolean;
        })[];
        box: string;
        input: string;
        icon: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CheckboxStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<CheckboxStyle>;
}
/**
 *
 * Checkbox is an extension to standard checkbox element with theming.
 *
 * [Live Demo](https://www.ngx-prime.org/checkbox/)
 *
 * @module checkboxstyle
 *
 */
declare enum CheckboxClasses {
    /**
     * Class name of the root element
     */
    root = "p-checkbox",
    /**
     * Class name of the box element
     */
    box = "p-checkbox-box",
    /**
     * Class name of the input element
     */
    input = "p-checkbox-input",
    /**
     * Class name of the icon element
     */
    icon = "p-checkbox-icon"
}

/**
 * Provides the themed visual container for a native checkbox.
 *
 * Use it only when a custom checkbox icon is required. For the usual case,
 * use `<input type="checkbox" pCheckbox>` directly.
 *
 * @group Components
 */
declare class CheckboxContainerDirective extends BaseComponent<CheckboxPassThrough> {
    componentName: string;
    _componentStyle: CheckboxStyle;
    private readonly bindDirectiveInstance;
    readonly checkbox: _angular_core.Signal<CheckboxDirective | undefined>;
    get checked(): boolean;
    $disabled(): boolean;
    invalid(): boolean;
    $variant(): "filled" | "outlined" | null | undefined;
    size(): "small" | "large" | undefined;
    onAfterViewChecked(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CheckboxContainerDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CheckboxContainerDirective, "label[pCheckboxContainer]", never, {}, {}, ["checkbox"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
/**
 * Marks an element as the visual box of a `pCheckboxContainer`.
 * Its content is the custom checked icon; an empty element receives the
 * default checkmark from the checkbox theme.
 *
 * @group Components
 */
declare class CheckboxIconDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CheckboxIconDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CheckboxIconDirective, "[pCheckboxIcon]", never, {}, {}, never, never, true, never>;
}
/**
 * Adds Prime styling and accessibility attributes to a native checkbox.
 * Native form controls retain Angular's built-in checkbox value accessor.
 *
 * @group Components
 */
declare class CheckboxDirective extends BaseEditableHolder<CheckboxPassThrough> {
    componentName: string;
    private readonly element;
    private readonly container;
    _componentStyle: CheckboxStyle;
    private readonly bindDirectiveInstance;
    /** @deprecated Use the native `class` attribute instead. */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /** Compatibility input for the directive pass-through configuration. */
    ptCheckbox: _angular_core.InputSignal<CheckboxPassThrough>;
    /** Pass-through configuration for the native checkbox. */
    pCheckboxPT: _angular_core.InputSignal<CheckboxPassThrough>;
    /** Enables unstyled mode for this native checkbox. */
    pCheckboxUnstyled: _angular_core.InputSignal<boolean | undefined>;
    /** Allows a boolean value instead of an array of selected values. */
    binary: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Value represented by this checkbox in an array model. */
    value: _angular_core.InputSignal<unknown>;
    /** Accessible label for the native checkbox. */
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    /** IDs of elements that label the native checkbox. */
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /** Index of the native input in tabbing order. */
    tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /** Compatibility alias for the native input id. Prefer the native `id` attribute in new templates. */
    inputId: _angular_core.InputSignal<string | undefined>;
    /** Reflects the native checkbox indeterminate state. */
    indeterminate: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Prevents user changes while retaining the checkbox in the tab order. */
    readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Requests focus when the browser initializes the control. */
    autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    trueValue: _angular_core.InputSignal<unknown>;
    falseValue: _angular_core.InputSignal<unknown>;
    variant: _angular_core.InputSignal<"filled" | "outlined" | undefined>;
    size: _angular_core.InputSignal<"small" | "large" | undefined>;
    $variant: _angular_core.Signal<"filled" | "outlined" | null>;
    /** Emits the browser change with the native checked value. */
    onChange: _angular_core.OutputEmitterRef<CheckboxChangeEvent>;
    /** Emits when the native checkbox receives focus. */
    onFocus: _angular_core.OutputEmitterRef<Event>;
    /** Emits when the native checkbox loses focus. */
    onBlur: _angular_core.OutputEmitterRef<Event>;
    touch: _angular_core.OutputEmitterRef<void>;
    onInputClick(event: MouseEvent): void;
    onInputChange(event: Event): void;
    onInputFocus(event: Event): void;
    onInputBlur(event: Event): void;
    get checked(): boolean;
    get dataP(): string | undefined;
    constructor();
    onAfterViewChecked(): void;
    focus(options?: FocusOptions): void;
    get rootClass(): string | undefined;
    writeControlValue(value: unknown, setModelValue: (value: unknown) => void): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CheckboxDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CheckboxDirective, "input[type='checkbox'][pCheckbox]", never, { "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "ptCheckbox": { "alias": "ptCheckbox"; "required": false; "isSignal": true; }; "pCheckboxPT": { "alias": "pCheckboxPT"; "required": false; "isSignal": true; }; "pCheckboxUnstyled": { "alias": "pCheckboxUnstyled"; "required": false; "isSignal": true; }; "binary": { "alias": "binary"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "indeterminate": { "alias": "indeterminate"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "trueValue": { "alias": "trueValue"; "required": false; "isSignal": true; }; "falseValue": { "alias": "falseValue"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, { "onChange": "onChange"; "onFocus": "onFocus"; "onBlur": "onBlur"; "touch": "touch"; }, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}

declare const CHECKBOX_VALUE_ACCESSOR: any;
/**
 * Checkbox is an extension to standard checkbox element with theming.
 *
 * @deprecated Use a native `<input type="checkbox" pCheckbox>` instead. For
 * custom visual icons, use `pCheckboxContainer` and `pCheckboxIcon`. This
 * component remains available for compatibility and is planned for removal in v23.
 * @group Components
 */
declare class Checkbox extends BaseEditableHolder<CheckboxPassThrough> {
    componentName: string;
    hostName: _angular_core.InputSignal<any>;
    /**
     * Value of the checkbox.
     * @group Props
     */
    value: _angular_core.InputSignal<any>;
    /**
     * Allows to select a boolean value instead of multiple values.
     * @group Props
     */
    binary: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Used to define a string that labels the input element.
     * @group Props
     */
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Identifier of the focus input to match a label defined for the component.
     * @group Props
     */
    inputId: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the input element.
     * @group Props
     */
    inputStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the input element.
     * @group Props
     */
    inputClass: _angular_core.InputSignal<string | undefined>;
    /**
     * When present, it specifies input state as indeterminate.
     * @group Props
     */
    indeterminate: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Form control value.
     * @group Props
     */
    formControl: _angular_core.InputSignal<FormControl<any> | undefined>;
    /**
     * Icon class of the checkbox icon.
     * @group Props
     */
    checkboxIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * When present, it specifies that the component cannot be edited.
     * @group Props
     */
    readonly: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Value in checked state.
     * @group Props
     */
    trueValue: _angular_core.InputSignal<any>;
    /**
     * Value in unchecked state.
     * @group Props
     */
    falseValue: _angular_core.InputSignal<any>;
    /**
     * Specifies the input variant of the component.
     * @defaultValue undefined
     * @group Props
     */
    variant: _angular_core.InputSignal<"filled" | "outlined" | undefined>;
    /**
     * Specifies the size of the component.
     * @defaultValue undefined
     * @group Props
     */
    size: _angular_core.InputSignal<"small" | "large" | undefined>;
    /**
     * Callback to invoke on value change.
     * @param {CheckboxChangeEvent} event - Custom value change event.
     * @group Emits
     */
    onChange: _angular_core.OutputEmitterRef<CheckboxChangeEvent>;
    /**
     * Callback to invoke when the receives focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onFocus: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke when the loses focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onBlur: _angular_core.OutputEmitterRef<Event>;
    readonly inputViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    get checked(): boolean;
    _indeterminate: _angular_core.WritableSignal<any>;
    /**
     * Custom checkbox icon template.
     * @group Templates
     */
    readonly checkboxIconTemplate: _angular_core.Signal<TemplateRef<CheckboxIconTemplateContext> | undefined>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _checkboxIconTemplate: TemplateRef<CheckboxIconTemplateContext> | undefined;
    focused: boolean;
    _componentStyle: CheckboxStyle;
    bindDirectiveInstance: Bind;
    $pcCheckbox: Checkbox | undefined;
    $variant: _angular_core.Signal<"filled" | "outlined" | null>;
    constructor();
    onAfterContentInit(): void;
    onAfterViewChecked(): void;
    updateModel(event: any): void;
    handleChange(event: any): void;
    onInputFocus(event: any): void;
    onInputBlur(event: any): void;
    focus(): void;
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value: any, setModelValue: (value: any) => void): void;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Checkbox, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Checkbox, "p-checkbox, p-checkBox, p-check-box", never, { "hostName": { "alias": "hostName"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "binary": { "alias": "binary"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "inputStyle": { "alias": "inputStyle"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "inputClass": { "alias": "inputClass"; "required": false; "isSignal": true; }; "indeterminate": { "alias": "indeterminate"; "required": false; "isSignal": true; }; "formControl": { "alias": "formControl"; "required": false; "isSignal": true; }; "checkboxIcon": { "alias": "checkboxIcon"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "trueValue": { "alias": "trueValue"; "required": false; "isSignal": true; }; "falseValue": { "alias": "falseValue"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, { "onChange": "onChange"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, ["checkboxIconTemplate", "templates"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class CheckboxModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CheckboxModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<CheckboxModule, never, [typeof Checkbox, typeof CheckboxContainerDirective, typeof CheckboxDirective, typeof CheckboxIconDirective, typeof i3.SharedModule], [typeof Checkbox, typeof CheckboxContainerDirective, typeof CheckboxDirective, typeof CheckboxIconDirective, typeof i3.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<CheckboxModule>;
}

export { CHECKBOX_VALUE_ACCESSOR, Checkbox, CheckboxClasses, CheckboxContainerDirective, CheckboxDirective, CheckboxIconDirective, CheckboxModule, CheckboxStyle };
