import { MenubarPassThrough, MenubarItemTemplateContext } from '@wawjs/ngx-prime/types/menubar';
export * from '@wawjs/ngx-prime/types/menubar';
import * as _angular_core from '@angular/core';
import { ElementRef, Renderer2, ChangeDetectorRef, TemplateRef } from '@angular/core';
import * as rxjs from 'rxjs';
import { Subscription, Subject } from 'rxjs';
import * as i2 from '@wawjs/ngx-prime/api';
import { MenuItem, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { VoidListener } from '@wawjs/ngx-prime/ts-helpers';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class MenuBarStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-menubar-mobile': any;
            'p-menubar-mobile-active': any;
        })[];
        start: string;
        button: string;
        rootList: string;
        item: ({ instance, processedItem }: {
            instance: any;
            processedItem: any;
        }) => (string | {
            'p-menubar-item-active': any;
            'p-focus': any;
            'p-disabled': any;
        })[];
        itemContent: string;
        itemLink: string;
        itemIcon: string;
        itemLabel: string;
        submenuIcon: string;
        submenu: string;
        separator: string;
        end: string;
    };
    inlineStyles: {
        submenu: ({ instance, processedItem }: {
            instance: any;
            processedItem: any;
        }) => {
            display: string;
        };
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MenuBarStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<MenuBarStyle>;
}
/**
 *
 * Menubar is a horizontal menu component.
 *
 * [Live Demo](https://www.ngx-prime.org/menubar/)
 *
 * @module menubarstyle
 *
 */
declare enum MenubarClasses {
    /**
     * Class name of the root element
     */
    root = "p-menubar",
    /**
     * Class name of the start element
     */
    start = "p-menubar-start",
    /**
     * Class name of the button element
     */
    button = "p-menubar-button",
    /**
     * Class name of the root list element
     */
    rootList = "p-menubar-root-list",
    /**
     * Class name of the item element
     */
    item = "p-menubar-item",
    /**
     * Class name of the item content element
     */
    itemContent = "p-menubar-item-content",
    /**
     * Class name of the item link element
     */
    itemLink = "p-menubar-item-link",
    /**
     * Class name of the item icon element
     */
    itemIcon = "p-menubar-item-icon",
    /**
     * Class name of the item label element
     */
    itemLabel = "p-menubar-item-label",
    /**
     * Class name of the submenu icon element
     */
    submenuIcon = "p-menubar-submenu-icon",
    /**
     * Class name of the submenu element
     */
    submenu = "p-menubar-submenu",
    /**
     * Class name of the separator element
     */
    separator = "p-menubar-separator",
    /**
     * Class name of the end element
     */
    end = "p-menubar-end"
}
type MenubarStyle = BaseStyle;

declare class MenubarService {
    autoHide: boolean | undefined;
    autoHideDelay: number | undefined;
    readonly mouseLeaves: Subject<boolean>;
    readonly mouseLeft$: rxjs.Observable<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MenubarService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<MenubarService>;
}
declare class MenubarSub extends BaseComponent<MenubarPassThrough> {
    items: _angular_core.InputSignal<any[] | undefined>;
    itemTemplate: _angular_core.InputSignal<TemplateRef<MenubarItemTemplateContext> | undefined>;
    root: _angular_core.InputSignalWithTransform<boolean, unknown>;
    autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    baseZIndex: _angular_core.InputSignalWithTransform<number, unknown>;
    mobileActive: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    autoDisplay: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    menuId: _angular_core.InputSignal<string | undefined>;
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    level: _angular_core.InputSignalWithTransform<number, unknown>;
    focusedItemId: _angular_core.InputSignal<string | undefined>;
    activeItemPath: _angular_core.InputSignal<any[] | undefined>;
    inlineStyles: _angular_core.InputSignal<any>;
    submenuiconTemplate: _angular_core.InputSignal<TemplateRef<void> | undefined>;
    itemClick: _angular_core.OutputEmitterRef<any>;
    itemMouseEnter: _angular_core.OutputEmitterRef<any>;
    menuFocus: _angular_core.OutputEmitterRef<any>;
    menuBlur: _angular_core.OutputEmitterRef<any>;
    menuKeydown: _angular_core.OutputEmitterRef<any>;
    mouseLeaveSubscriber: Subscription | undefined;
    menubarService: MenubarService;
    _componentStyle: MenuBarStyle;
    hostName: string;
    onInit(): void;
    onItemClick(event: any, processedItem: any): void;
    getItemProp(processedItem: any, name: string, params?: any | null): any;
    getItemId(processedItem: any): string;
    getItemLabelId(processedItem: any): string;
    getItemLabel(processedItem: any): string;
    isItemVisible(processedItem: any): boolean;
    isItemActive(processedItem: any): boolean;
    isItemDisabled(processedItem: any): boolean;
    isItemFocused(processedItem: any): boolean;
    isItemGroup(processedItem: any): boolean;
    getAriaSetSize(): number | undefined;
    getAriaPosInset(index: number): number;
    onItemMouseEnter(param: any): void;
    getPTOptions(processedItem: any, index: number, key: string): any;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MenubarSub, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MenubarSub, "p-menubarSub, p-menubarsub, [pMenubarSub]", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; "isSignal": true; }; "root": { "alias": "root"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "mobileActive": { "alias": "mobileActive"; "required": false; "isSignal": true; }; "autoDisplay": { "alias": "autoDisplay"; "required": false; "isSignal": true; }; "menuId": { "alias": "menuId"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "level": { "alias": "level"; "required": false; "isSignal": true; }; "focusedItemId": { "alias": "focusedItemId"; "required": false; "isSignal": true; }; "activeItemPath": { "alias": "activeItemPath"; "required": false; "isSignal": true; }; "inlineStyles": { "alias": "inlineStyles"; "required": false; "isSignal": true; }; "submenuiconTemplate": { "alias": "submenuiconTemplate"; "required": false; "isSignal": true; }; }, { "itemClick": "itemClick"; "itemMouseEnter": "itemMouseEnter"; "menuFocus": "menuFocus"; "menuBlur": "menuBlur"; "menuKeydown": "menuKeydown"; }, never, never, true, never>;
}
/**
 * Menubar is a horizontal menu component.
 * @group Components
 */
declare class Menubar extends BaseComponent<MenubarPassThrough> {
    document: Document;
    platformId: Object;
    el: ElementRef<any>;
    renderer: Renderer2;
    cd: ChangeDetectorRef;
    private menubarService;
    componentName: string;
    $pcMenubar: Menubar | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * An array of menuitems.
     * @group Props
     */
    model: _angular_core.InputSignal<MenuItem[] | undefined>;
    /**
     * Class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to automatically manage layering.
     * @group Props
     */
    autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Base zIndex value to use in layering.
     * @group Props
     */
    baseZIndex: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Whether to show a root submenu on mouse over.
     * @defaultValue true
     * @group Props
     */
    autoDisplay: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to hide a root submenu when mouse leaves.
     * @group Props
     */
    autoHide: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * The breakpoint to define the maximum width boundary.
     * @group Props
     */
    breakpoint: _angular_core.InputSignal<string>;
    /**
     * Delay to hide the root submenu in milliseconds when mouse leaves.
     * @group Props
     */
    autoHideDelay: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Current id state as a string.
     * @group Props
     */
    id: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string value that labels an interactive element.
     * @group Props
     */
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Identifier of the underlying input element.
     * @group Props
     */
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Callback to execute when button is focused.
     * @param {FocusEvent} event - Focus event.
     * @group Emits
     */
    onFocus: _angular_core.OutputEmitterRef<FocusEvent>;
    /**
     * Callback to execute when button loses focus.
     * @param {FocusEvent} event - Focus event.
     * @group Emits
     */
    onBlur: _angular_core.OutputEmitterRef<FocusEvent>;
    readonly menubutton: _angular_core.Signal<ElementRef<any> | undefined>;
    rootmenu: MenubarSub | undefined;
    mobileActive: boolean | undefined;
    private matchMediaListener;
    private query;
    queryMatches: _angular_core.WritableSignal<boolean>;
    outsideClickListener: VoidListener;
    resizeListener: VoidListener;
    mouseLeaveSubscriber: Subscription | undefined;
    dirty: boolean;
    focused: boolean;
    activeItemPath: _angular_core.WritableSignal<any>;
    number: _angular_core.WritableSignal<number>;
    focusedItemInfo: _angular_core.WritableSignal<any>;
    searchValue: string;
    searchTimeout: any;
    _processedItems: any[];
    _componentStyle: MenuBarStyle;
    private _generatedId;
    get resolvedId(): string;
    get visibleItems(): any;
    get processedItems(): any[];
    get focusedItemId(): any;
    constructor();
    onInit(): void;
    /**
     * Defines template option for start.
     * @group Templates
     */
    startTemplate: TemplateRef<void> | undefined;
    /**
     * Defines template option for end.
     * @group Templates
     */
    endTemplate: TemplateRef<void> | undefined;
    /**
     * Custom item template.
     * @param {MenubarItemTemplateContext} context - item context.
     * @see {@link MenubarItemTemplateContext}
     * @group Templates
     */
    readonly itemTemplate: _angular_core.Signal<TemplateRef<MenubarItemTemplateContext> | undefined>;
    /**
     * Defines template option for menu icon.
     * @group Templates
     */
    readonly menuIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Defines template option for submenu icon.
     * @group Templates
     */
    readonly submenuIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _startTemplate: TemplateRef<void> | undefined;
    _endTemplate: TemplateRef<void> | undefined;
    _itemTemplate: TemplateRef<MenubarItemTemplateContext> | undefined;
    _menuIconTemplate: TemplateRef<void> | undefined;
    _submenuIconTemplate: TemplateRef<void> | undefined;
    onAfterContentInit(): void;
    createProcessedItems(items: any, level?: number, parent?: any, parentKey?: any): any[];
    bindMatchMediaListener(): void;
    unbindMatchMediaListener(): void;
    getItemProp(item: any, name: string): any;
    menuButtonClick(event: MouseEvent): void;
    menuButtonKeydown(event: any): void;
    onItemClick(event: any): void;
    onItemMouseEnter(event: any): void;
    onMouseLeave(): void;
    changeFocusedItemIndex(event: any, index: number): void;
    scrollInView(index?: number): void;
    onItemChange(event: any, type?: string | undefined): void;
    toggle(event: MouseEvent): void;
    hide(event?: any, isFocus?: boolean): void;
    show(): void;
    onMenuMouseDown(): void;
    onMenuFocus(event: any): void;
    onMenuBlur(event: any): void;
    onKeyDown(event: KeyboardEvent): void;
    findVisibleItem(index: any): any;
    findFirstFocusedItemIndex(): any;
    findFirstItemIndex(): any;
    findSelectedItemIndex(): any;
    isProcessedItemGroup(processedItem: any): boolean;
    isSelected(processedItem: any): boolean;
    isValidSelectedItem(processedItem: any): boolean;
    isValidItem(processedItem: any): boolean;
    isItemDisabled(item: any): boolean;
    isItemSeparator(item: any): boolean;
    isItemMatched(processedItem: any): boolean;
    isProccessedItemGroup(processedItem: any): boolean;
    searchItems(event: any, char: string): boolean;
    getProccessedItemLabel(processedItem: any): any;
    getItemLabel(item: any): any;
    onArrowDownKey(event: KeyboardEvent): void;
    onArrowRightKey(event: KeyboardEvent): void;
    onArrowUpKey(event: KeyboardEvent): void;
    onArrowLeftKey(event: KeyboardEvent): void;
    onHomeKey(event: KeyboardEvent): void;
    onEndKey(event: KeyboardEvent): void;
    onSpaceKey(event: KeyboardEvent): void;
    onEscapeKey(event: KeyboardEvent): void;
    onTabKey(event: KeyboardEvent): void;
    onEnterKey(event: KeyboardEvent): void;
    findLastFocusedItemIndex(): any;
    findLastItemIndex(): number;
    findPrevItemIndex(index: number): number;
    findNextItemIndex(index: number): any;
    bindResizeListener(): void;
    bindOutsideClickListener(): void;
    unbindOutsideClickListener(): void;
    unbindResizeListener(): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Menubar, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Menubar, "p-menubar", never, { "model": { "alias": "model"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "autoDisplay": { "alias": "autoDisplay"; "required": false; "isSignal": true; }; "autoHide": { "alias": "autoHide"; "required": false; "isSignal": true; }; "breakpoint": { "alias": "breakpoint"; "required": false; "isSignal": true; }; "autoHideDelay": { "alias": "autoHideDelay"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; }, { "onFocus": "onFocus"; "onBlur": "onBlur"; }, ["itemTemplate", "menuIconTemplate", "submenuIconTemplate", "templates", "startTemplate", "endTemplate"], ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class MenubarModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MenubarModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<MenubarModule, never, [typeof Menubar, typeof i2.SharedModule], [typeof Menubar, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<MenubarModule>;
}

export { MenuBarStyle, Menubar, MenubarClasses, MenubarModule, MenubarService, MenubarSub };
export type { MenubarStyle };
