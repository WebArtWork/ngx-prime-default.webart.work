import { DialogPassThrough } from '@wawjs/ngx-prime/types/dialog';
export * from '@wawjs/ngx-prime/types/dialog';
import * as _angular_core from '@angular/core';
import { OnInit, AfterContentInit, OnDestroy, ElementRef, TemplateRef, NgZone } from '@angular/core';
import { MotionOptions, MotionEvent } from '@wawjs/css-prime-motion';
import * as i2 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { ButtonProps } from '@wawjs/ngx-prime/button';
import { Nullable, VoidListener } from '@wawjs/ngx-prime/ts-helpers';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class DialogStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        mask: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-overlay-mask': any;
        })[];
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-dialog-maximized': any;
        })[];
        header: string;
        title: string;
        resizeHandle: string;
        headerActions: string;
        pcMaximizeButton: string;
        pcCloseButton: string;
        content: () => string[];
        footer: string;
    };
    inlineStyles: {
        mask: ({ instance }: {
            instance: any;
        }) => {
            position: string;
            height: string;
            width: string;
            left: number;
            top: number;
            display: string;
            justifyContent: string;
            alignItems: string;
            pointerEvents: string;
        };
        root: {
            display: string;
            flexDirection: string;
            pointerEvents: string;
        };
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DialogStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<DialogStyle>;
}
/**
 *
 * Dialog is a container to display content in an overlay window.
 *
 * [Live Demo](https://www.ngx-prime.org/dialog)
 *
 * @module dialogstyle
 *
 */
declare enum DialogClasses {
    /**
     * Class name of the mask element
     */
    mask = "p-dialog-mask",
    /**
     * Class name of the root element
     */
    root = "p-dialog",
    /**
     * Class name of the header element
     */
    header = "p-dialog-header",
    /**
     * Class name of the title element
     */
    title = "p-dialog-title",
    /**
     * Class name of the header actions element
     */
    headerActions = "p-dialog-header-actions",
    /**
     * Class name of the maximize button element
     */
    pcMaximizeButton = "p-dialog-maximize-button",
    /**
     * Class name of the close button element
     */
    pcCloseButton = "p-dialog-close-button",
    /**
     * Class name of the content element
     */
    content = "p-dialog-content",
    /**
     * Class name of the footer element
     */
    footer = "p-dialog-footer"
}

/**
 * Dialog is a container to display content in an overlay window.
 * @group Components
 */
declare class Dialog extends BaseComponent<DialogPassThrough> implements OnInit, AfterContentInit, OnDestroy {
    componentName: string;
    readonly hostName: _angular_core.InputSignal<string>;
    $pcDialog: Dialog | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Title text of the dialog.
     * @group Props
     */
    readonly header: _angular_core.InputSignal<string | undefined>;
    /**
     * Enables dragging to change the position using header.
     * @group Props
     */
    readonly draggable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Enables resizing of the content.
     * @group Props
     */
    readonly resizable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Style of the content section.
     * @group Props
     */
    readonly contentStyle: _angular_core.InputSignal<any>;
    /**
     * Style class of the content.
     * @group Props
     */
    readonly contentStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines if background should be blocked when dialog is displayed.
     * @group Props
     */
    readonly modal: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Specifies if pressing escape key should hide the dialog.
     * @group Props
     */
    readonly closeOnEscape: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Specifies if clicking the modal background should hide the dialog.
     * @group Props
     */
    readonly dismissableMask: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When enabled dialog is displayed in RTL direction.
     * @group Props
     */
    readonly rtl: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Adds a close icon to the header to hide the dialog.
     * @group Props
     */
    readonly closable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Object literal to define widths per screen size.
     * @group Props
     */
    readonly breakpoints: _angular_core.InputSignal<any>;
    /**
     * Style class of the component.
     * @group Props
     */
    readonly styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the mask.
     * @group Props
     */
    readonly maskStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style of the mask.
     * @group Props
     */
    readonly maskStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Whether to show the header or not.
     * @group Props
     */
    readonly showHeader: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether background scroll should be blocked when dialog is visible.
     * @group Props
     */
    readonly blockScroll: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to automatically manage layering.
     * @group Props
     */
    readonly autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Base zIndex value to use in layering.
     * @group Props
     */
    readonly baseZIndex: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Minimum value for the left coordinate of dialog in dragging.
     * @group Props
     */
    readonly minX: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Minimum value for the top coordinate of dialog in dragging.
     * @group Props
     */
    readonly minY: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * When enabled, first focusable element receives focus on show.
     * @group Props
     */
    readonly focusOnShow: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether the dialog can be displayed full screen.
     * @group Props
     */
    readonly maximizable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Keeps dialog in the viewport.
     * @group Props
     */
    readonly keepInViewport: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When enabled, can only focus on elements inside the dialog.
     * @group Props
     */
    readonly focusTrap: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Transition options of the animation.
     * @deprecated since v21.0.0. Use `motionOptions` instead.
     * @group Props
     */
    readonly transitionOptions: _angular_core.InputSignal<string>;
    /**
     * The motion options for the mask.
     * @group Props
     */
    maskMotionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    computedMaskMotionOptions: _angular_core.Signal<MotionOptions>;
    /**
     * The motion options.
     * @group Props
     */
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    computedMotionOptions: _angular_core.Signal<MotionOptions>;
    /**
     * Name of the close icon.
     * @group Props
     */
    readonly closeIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the close button for accessibility.
     * @group Props
     */
    readonly closeAriaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Index of the close button in tabbing order.
     * @group Props
     */
    readonly closeTabindex: _angular_core.InputSignal<string>;
    /**
     * Name of the minimize icon.
     * @group Props
     */
    readonly minimizeIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Name of the maximize icon.
     * @group Props
     */
    readonly maximizeIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Used to pass all properties of the ButtonProps to the Button component.
     * @group Props
     */
    readonly closeButtonProps: _angular_core.InputSignal<ButtonProps>;
    /**
     * Used to pass all properties of the ButtonProps to the Button component.
     * @group Props
     */
    readonly maximizeButtonProps: _angular_core.InputSignal<ButtonProps>;
    /**
     * Specifies the visibility of the dialog.
     * @group Props
     */
    readonly visible: _angular_core.ModelSignal<boolean>;
    /**
     * Inline style of the component.
     * @group Props
     */
    style: _angular_core.InputSignal<any>;
    /**
     * Position of the dialog.
     * @group Props
     */
    readonly position: _angular_core.InputSignal<"left" | "topleft" | "bottomleft" | "right" | "topright" | "bottomright" | "center" | "top" | "bottom">;
    /**
     * Role attribute of html element.
     * @group Emits
     */
    readonly role: _angular_core.InputSignal<string>;
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'self'
     * @group Props
     */
    appendTo: _angular_core.InputSignal<any>;
    /**
     * Callback to invoke when dialog is shown.
     * @group Emits
     */
    onShow: _angular_core.OutputEmitterRef<any>;
    /**
     * Callback to invoke when dialog is hidden.
     * @group Emits
     */
    onHide: _angular_core.OutputEmitterRef<any>;
    /**
     * Callback to invoke when dialog resizing is initiated.
     * @param {MouseEvent} event - Mouse event.
     * @group Emits
     */
    onResizeInit: _angular_core.OutputEmitterRef<MouseEvent>;
    /**
     * Callback to invoke when dialog resizing is completed.
     * @param {MouseEvent} event - Mouse event.
     * @group Emits
     */
    onResizeEnd: _angular_core.OutputEmitterRef<MouseEvent>;
    /**
     * Callback to invoke when dialog dragging is completed.
     * @param {DragEvent} event - Drag event.
     * @group Emits
     */
    onDragEnd: _angular_core.OutputEmitterRef<DragEvent>;
    /**
     * Callback to invoke when dialog maximized or unmaximized.
     * @group Emits
     */
    onMaximize: _angular_core.OutputEmitterRef<any>;
    readonly headerViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly contentViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly footerViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    /**
     * Header template.
     * @group Templates
     */
    readonly headerTemplate: _angular_core.InputSignal<TemplateRef<void> | undefined>;
    /**
     * Content template.
     * @group Templates
     */
    readonly contentTemplate: _angular_core.InputSignal<TemplateRef<void> | undefined>;
    /**
     * Footer template.
     * @group Templates
     */
    readonly footerTemplate: _angular_core.InputSignal<TemplateRef<void> | undefined>;
    /**
     * Close icon template.
     * @group Templates
     */
    readonly closeIconTemplate: _angular_core.InputSignal<TemplateRef<void> | undefined>;
    /**
     * Maximize icon template.
     * @group Templates
     */
    readonly maximizeIconTemplate: _angular_core.InputSignal<TemplateRef<void> | undefined>;
    /**
     * Minimize icon template.
     * @group Templates
     */
    readonly minimizeIconTemplate: _angular_core.InputSignal<TemplateRef<void> | undefined>;
    /**
     * Headless template.
     * @group Templates
     */
    readonly headlessTemplate: _angular_core.InputSignal<TemplateRef<void> | undefined>;
    /**
     * Custom header template.
     * @group Templates
     */
    readonly _headerTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom content template.
     * @group Templates
     */
    readonly _contentTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom footer template.
     * @group Templates
     */
    _footerTemplate: TemplateRef<void> | undefined;
    /**
     * Custom close icon template.
     * @group Templates
     */
    _closeiconTemplate: TemplateRef<void> | undefined;
    /**
     * Custom maximize icon template.
     * @group Templates
     */
    readonly _maximizeiconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom minimize icon template.
     * @group Templates
     */
    readonly _minimizeiconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom headless template.
     * @group Templates
     */
    _headlessTemplate: TemplateRef<void> | undefined;
    $appendTo: _angular_core.Signal<any>;
    renderMask: _angular_core.WritableSignal<boolean>;
    renderDialog: _angular_core.WritableSignal<boolean>;
    _visible: boolean;
    maskVisible: boolean | undefined;
    container: _angular_core.WritableSignal<Nullable<HTMLElement>>;
    wrapper: Nullable<HTMLElement>;
    dragging: boolean | undefined;
    ariaLabelledBy: string | null;
    documentDragListener: VoidListener;
    documentDragEndListener: VoidListener;
    resizing: boolean | undefined;
    documentResizeListener: VoidListener;
    documentResizeEndListener: VoidListener;
    documentEscapeListener: VoidListener;
    maskClickListener: VoidListener;
    lastPageX: number | undefined;
    lastPageY: number | undefined;
    preventVisibleChangePropagation: boolean | undefined;
    maximized: boolean | undefined;
    preMaximizeContentHeight: number | undefined;
    preMaximizeContainerWidth: number | undefined;
    preMaximizeContainerHeight: number | undefined;
    preMaximizePageX: number | undefined;
    preMaximizePageY: number | undefined;
    id: string;
    _style: any;
    originalStyle: any;
    transformOptions: any;
    styleElement: any;
    private window;
    _componentStyle: DialogStyle;
    headerT: TemplateRef<void> | undefined;
    contentT: TemplateRef<void> | undefined;
    footerT: TemplateRef<void> | undefined;
    closeIconT: TemplateRef<void> | undefined;
    maximizeIconT: TemplateRef<void> | undefined;
    minimizeIconT: TemplateRef<void> | undefined;
    headlessT: TemplateRef<void> | undefined;
    private zIndexForLayering?;
    get maximizeLabel(): string;
    get minimizeLabel(): string;
    zone: NgZone;
    private overlayService;
    get maskClass(): {
        [x: string]: string | boolean | undefined;
        'p-dialog-mask': boolean;
        'p-overlay-mask': boolean;
    };
    constructor();
    onInit(): void;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    onAfterContentInit(): void;
    getAriaLabelledBy(): string | null;
    parseDurationToMilliseconds(durationString: string): number | undefined;
    _focus(focusParentElement?: HTMLElement): boolean;
    focus(focusParentElement?: HTMLElement): void;
    close(event: Event): void;
    enableModality(): void;
    disableModality(): void;
    maximize(): void;
    unbindMaskClickListener(): void;
    moveOnTop(): void;
    createStyle(): void;
    initDrag(event: MouseEvent): void;
    onDrag(event: MouseEvent): void;
    endDrag(event: DragEvent): void;
    resetPosition(): void;
    center(): void;
    initResize(event: MouseEvent): void;
    onResize(event: MouseEvent): void;
    resizeEnd(event: MouseEvent): void;
    bindGlobalListeners(): void;
    unbindGlobalListeners(): void;
    bindDocumentDragListener(): void;
    unbindDocumentDragListener(): void;
    bindDocumentDragEndListener(): void;
    unbindDocumentDragEndListener(): void;
    bindDocumentResizeListeners(): void;
    unbindDocumentResizeListeners(): void;
    bindDocumentEscapeListener(): void;
    unbindDocumentEscapeListener(): void;
    appendContainer(): void;
    restoreAppend(): void;
    onBeforeEnter(event: MotionEvent): void;
    onAfterEnter(): void;
    onBeforeLeave(): void;
    onAfterLeave(): void;
    onMaskAfterLeave(): void;
    onContainerDestroy(): void;
    destroyStyle(): void;
    onDestroy(): void;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Dialog, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Dialog, "p-dialog", never, { "hostName": { "alias": "hostName"; "required": false; "isSignal": true; }; "header": { "alias": "header"; "required": false; "isSignal": true; }; "draggable": { "alias": "draggable"; "required": false; "isSignal": true; }; "resizable": { "alias": "resizable"; "required": false; "isSignal": true; }; "contentStyle": { "alias": "contentStyle"; "required": false; "isSignal": true; }; "contentStyleClass": { "alias": "contentStyleClass"; "required": false; "isSignal": true; }; "modal": { "alias": "modal"; "required": false; "isSignal": true; }; "closeOnEscape": { "alias": "closeOnEscape"; "required": false; "isSignal": true; }; "dismissableMask": { "alias": "dismissableMask"; "required": false; "isSignal": true; }; "rtl": { "alias": "rtl"; "required": false; "isSignal": true; }; "closable": { "alias": "closable"; "required": false; "isSignal": true; }; "breakpoints": { "alias": "breakpoints"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "maskStyleClass": { "alias": "maskStyleClass"; "required": false; "isSignal": true; }; "maskStyle": { "alias": "maskStyle"; "required": false; "isSignal": true; }; "showHeader": { "alias": "showHeader"; "required": false; "isSignal": true; }; "blockScroll": { "alias": "blockScroll"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "minX": { "alias": "minX"; "required": false; "isSignal": true; }; "minY": { "alias": "minY"; "required": false; "isSignal": true; }; "focusOnShow": { "alias": "focusOnShow"; "required": false; "isSignal": true; }; "maximizable": { "alias": "maximizable"; "required": false; "isSignal": true; }; "keepInViewport": { "alias": "keepInViewport"; "required": false; "isSignal": true; }; "focusTrap": { "alias": "focusTrap"; "required": false; "isSignal": true; }; "transitionOptions": { "alias": "transitionOptions"; "required": false; "isSignal": true; }; "maskMotionOptions": { "alias": "maskMotionOptions"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; "closeIcon": { "alias": "closeIcon"; "required": false; "isSignal": true; }; "closeAriaLabel": { "alias": "closeAriaLabel"; "required": false; "isSignal": true; }; "closeTabindex": { "alias": "closeTabindex"; "required": false; "isSignal": true; }; "minimizeIcon": { "alias": "minimizeIcon"; "required": false; "isSignal": true; }; "maximizeIcon": { "alias": "maximizeIcon"; "required": false; "isSignal": true; }; "closeButtonProps": { "alias": "closeButtonProps"; "required": false; "isSignal": true; }; "maximizeButtonProps": { "alias": "maximizeButtonProps"; "required": false; "isSignal": true; }; "visible": { "alias": "visible"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; "role": { "alias": "role"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "headerTemplate": { "alias": "headerTemplate"; "required": false; "isSignal": true; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; "isSignal": true; }; "footerTemplate": { "alias": "footerTemplate"; "required": false; "isSignal": true; }; "closeIconTemplate": { "alias": "closeIconTemplate"; "required": false; "isSignal": true; }; "maximizeIconTemplate": { "alias": "maximizeIconTemplate"; "required": false; "isSignal": true; }; "minimizeIconTemplate": { "alias": "minimizeIconTemplate"; "required": false; "isSignal": true; }; "headlessTemplate": { "alias": "headlessTemplate"; "required": false; "isSignal": true; }; }, { "visible": "visibleChange"; "onShow": "onShow"; "onHide": "onHide"; "onResizeInit": "onResizeInit"; "onResizeEnd": "onResizeEnd"; "onDragEnd": "onDragEnd"; "onMaximize": "onMaximize"; }, ["_headerTemplate", "_contentTemplate", "_maximizeiconTemplate", "_minimizeiconTemplate", "templates", "_footerTemplate", "_closeiconTemplate", "_headlessTemplate"], ["*", "p-footer"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class DialogModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DialogModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<DialogModule, never, [typeof Dialog, typeof i2.SharedModule], [typeof Dialog, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<DialogModule>;
}

export { Dialog, DialogClasses, DialogModule, DialogStyle };
