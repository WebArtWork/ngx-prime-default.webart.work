import { SelectPassThrough, SelectChangeEvent, SelectFilterEvent, SelectLazyLoadEvent, SelectItemTemplateContext, SelectGroupTemplateContext, SelectLoaderTemplateContext, SelectSelectedItemTemplateContext, SelectFilterTemplateContext, SelectIconTemplateContext, SelectFilterOptions } from '@wawjs/ngx-prime/types/select';
export * from '@wawjs/ngx-prime/types/select';
import * as _angular_core from '@angular/core';
import { AfterViewInit, AfterViewChecked, NgZone, ElementRef, TemplateRef } from '@angular/core';
import { MotionOptions } from '@wawjs/css-prime-motion';
import * as i2 from '@wawjs/ngx-prime/api';
import { FilterService, ScrollerOptions, OverlayOptions, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import { BaseInput } from '@wawjs/ngx-prime/baseinput';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Overlay } from '@wawjs/ngx-prime/overlay';
import { Scroller } from '@wawjs/ngx-prime/scroller';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class SelectStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-disabled': any;
            'p-variant-filled': boolean;
            'p-focus': any;
            'p-invalid': any;
            'p-inputwrapper-filled': any;
            'p-inputwrapper-focus': any;
            'p-select-open': any;
            'p-select-fluid': any;
            'p-select-sm p-inputfield-sm': boolean;
            'p-select-lg p-inputfield-lg': boolean;
        })[];
        label: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-placeholder': any;
            'p-select-label-empty': boolean;
        })[];
        clearIcon: string;
        dropdown: string;
        loadingIcon: string;
        dropdownIcon: string;
        overlay: string;
        header: string;
        pcFilter: string;
        listContainer: string;
        list: string;
        optionGroup: string;
        optionGroupLabel: string;
        option: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-select-option-selected': any;
            'p-disabled': any;
            'p-focus': any;
        })[];
        optionLabel: string;
        optionCheckIcon: string;
        optionBlankIcon: string;
        emptyMessage: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SelectStyle>;
}
/**
 *
 * Select also known as Select, is used to choose an item from a collection of options.
 *
 * [Live Demo](https://www.ngx-prime.org/select/)
 *
 * @module selectstyle
 *
 */
declare enum SelectClasses {
    /**
     * Class name of the root element
     */
    root = "p-select",
    /**
     * Class name of the label element
     */
    label = "p-select-label",
    /**
     * Class name of the clear icon element
     */
    clearIcon = "p-select-clear-icon",
    /**
     * Class name of the dropdown element
     */
    dropdown = "p-select-dropdown",
    /**
     * Class name of the loadingicon element
     */
    loadingIcon = "p-select-loading-icon",
    /**
     * Class name of the dropdown icon element
     */
    dropdownIcon = "p-select-dropdown-icon",
    /**
     * Class name of the overlay element
     */
    overlay = "p-select-overlay",
    /**
     * Class name of the header element
     */
    header = "p-select-header",
    /**
     * Class name of the filter element
     */
    pcFilter = "p-select-filter",
    /**
     * Class name of the list container element
     */
    listContainer = "p-select-list-container",
    /**
     * Class name of the list element
     */
    list = "p-select-list",
    /**
     * Class name of the option group element
     */
    optionGroup = "p-select-option-group",
    /**
     * Class name of the option group label element
     */
    optionGroupLabel = "p-select-option-group-label",
    /**
     * Class name of the option element
     */
    option = "p-select-option",
    /**
     * Class name of the option label element
     */
    optionLabel = "p-select-option-label",
    /**
     * Class name of the option check icon element
     */
    optionCheckIcon = "p-select-option-check-icon",
    /**
     * Class name of the option blank icon element
     */
    optionBlankIcon = "p-select-option-blank-icon",
    /**
     * Class name of the empty message element
     */
    emptyMessage = "p-select-empty-message"
}

declare const SELECT_VALUE_ACCESSOR: any;
declare class SelectItem extends BaseComponent {
    hostName: string;
    $pcSelectItem: SelectItem | undefined;
    $pcSelect: Select | undefined;
    readonly id: _angular_core.InputSignal<string | undefined>;
    readonly option: _angular_core.InputSignal<any>;
    readonly selected: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly focused: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly label: _angular_core.InputSignal<string | undefined>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly visible: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly itemSize: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly ariaPosInset: _angular_core.InputSignal<string | undefined>;
    readonly ariaSetSize: _angular_core.InputSignal<string | undefined>;
    readonly template: _angular_core.InputSignal<TemplateRef<any> | undefined>;
    readonly checkmark: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly index: _angular_core.InputSignal<number | undefined>;
    readonly scrollerOptions: _angular_core.InputSignal<any>;
    onClick: _angular_core.OutputEmitterRef<any>;
    onMouseEnter: _angular_core.OutputEmitterRef<any>;
    _componentStyle: SelectStyle;
    onOptionClick(event: Event): void;
    onOptionMouseEnter(event: Event): void;
    getPTOptions(): any;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectItem, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SelectItem, "p-select-item", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "option": { "alias": "option"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "focused": { "alias": "focused"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "visible": { "alias": "visible"; "required": false; "isSignal": true; }; "itemSize": { "alias": "itemSize"; "required": false; "isSignal": true; }; "ariaPosInset": { "alias": "ariaPosInset"; "required": false; "isSignal": true; }; "ariaSetSize": { "alias": "ariaSetSize"; "required": false; "isSignal": true; }; "template": { "alias": "template"; "required": false; "isSignal": true; }; "checkmark": { "alias": "checkmark"; "required": false; "isSignal": true; }; "index": { "alias": "index"; "required": false; "isSignal": true; }; "scrollerOptions": { "alias": "scrollerOptions"; "required": false; "isSignal": true; }; }, { "onClick": "onClick"; "onMouseEnter": "onMouseEnter"; }, never, never, true, never>;
}
/**
 * Select is used to choose an item from a collection of options.
 * @group Components
 */
declare class Select extends BaseInput<SelectPassThrough> implements AfterViewInit, AfterViewChecked {
    zone: NgZone;
    filterService: FilterService;
    componentName: string;
    bindDirectiveInstance: Bind;
    /**
     * Unique identifier of the component
     * @group Props
     */
    readonly id: _angular_core.InputSignal<string | undefined>;
    private _generatedId;
    get resolvedId(): string;
    /**
     * Height of the viewport in pixels, a scrollbar is defined if height of list exceeds this value.
     * @group Props
     */
    readonly scrollHeight: _angular_core.InputSignal<string>;
    /**
     * When specified, displays an input field to filter the items on keyup.
     * @group Props
     */
    readonly filter: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Inline style of the overlay panel element.
     * @group Props
     */
    readonly panelStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    readonly styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the overlay panel element.
     * @group Props
     */
    readonly panelStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * When present, it specifies that the component cannot be edited.
     * @group Props
     */
    readonly readonly: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When present, custom value instead of predefined options can be entered using the editable input field.
     * @group Props
     */
    readonly editable: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    readonly tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Default text to display when no option is selected.
     * @group Props
     */
    readonly placeholder: _angular_core.InputSignal<string | undefined>;
    /**
     * Icon to display in loading state.
     * @group Props
     */
    readonly loadingIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Placeholder text to show when filter input is empty.
     * @group Props
     */
    readonly filterPlaceholder: _angular_core.InputSignal<string | undefined>;
    /**
     * Locale to use in filtering. The default locale is the host environment's current locale.
     * @group Props
     */
    readonly filterLocale: _angular_core.InputSignal<string | undefined>;
    /**
     * Identifier of the accessible input element.
     * @group Props
     */
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    /**
     * A property to uniquely identify a value in options.
     * @group Props
     */
    readonly dataKey: _angular_core.InputSignal<string | undefined>;
    /**
     * When filtering is enabled, filterBy decides which field or fields (comma separated) to search against.
     * @group Props
     */
    readonly filterBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Fields used when filtering the options, defaults to optionLabel.
     * @group Props
     */
    readonly filterFields: _angular_core.InputSignal<any[] | undefined>;
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Clears the filter value when hiding the select.
     * @group Props
     */
    readonly resetFilterOnHide: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether the selected option will be shown with a check mark.
     * @group Props
     */
    readonly checkmark: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Icon class of the select icon.
     * @group Props
     */
    readonly dropdownIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether the select is in loading state.
     * @group Props
     */
    readonly loading: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Name of the label field of an option.
     * @group Props
     */
    readonly optionLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Name of the value field of an option.
     * @group Props
     */
    readonly optionValue: _angular_core.InputSignal<string | undefined>;
    /**
     * Name of the disabled field of an option.
     * @group Props
     */
    readonly optionDisabled: _angular_core.InputSignal<string | undefined>;
    /**
     * Name of the label field of an option group.
     * @group Props
     */
    readonly optionGroupLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Name of the options field of an option group.
     * @group Props
     */
    readonly optionGroupChildren: _angular_core.InputSignal<string>;
    /**
     * Whether to display options as grouped when nested options are provided.
     * @group Props
     */
    readonly group: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When enabled, a clear icon is displayed to clear the value.
     * @group Props
     */
    readonly showClear: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Text to display when filtering does not return any results. Defaults to global value in i18n translation configuration.
     * @group Props
     */
    readonly emptyFilterMessage: _angular_core.InputSignal<string>;
    /**
     * Text to display when there is no data. Defaults to global value in i18n translation configuration.
     * @group Props
     */
    readonly emptyMessage: _angular_core.InputSignal<string>;
    /**
     * Defines if data is loaded and interacted with in lazy manner.
     * @group Props
     */
    readonly lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether the data should be loaded on demand during scroll.
     * @group Props
     */
    readonly virtualScroll: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Height of an item in the list for VirtualScrolling.
     * @group Props
     */
    readonly virtualScrollItemSize: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Whether to use the scroller feature. The properties of scroller component can be used like an object in it.
     * @group Props
     */
    readonly virtualScrollOptions: _angular_core.InputSignal<ScrollerOptions | undefined>;
    /**
     * Whether to use overlay API feature. The properties of overlay API can be used like an object in it.
     * @group Props
     */
    readonly overlayOptions: _angular_core.InputSignal<OverlayOptions | undefined>;
    /**
     * Defines a string that labels the filter input.
     * @group Props
     */
    readonly ariaFilterLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Used to define a aria label attribute the current element.
     * @group Props
     */
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines how the items are filtered.
     * @group Props
     */
    readonly filterMatchMode: _angular_core.InputSignal<"contains" | "startsWith" | "endsWith" | "equals" | "notEquals" | "in" | "lt" | "lte" | "gt" | "gte">;
    /**
     * Advisory information to display in a tooltip on hover.
     * @group Props
     */
    readonly tooltip: _angular_core.InputSignal<string>;
    /**
     * Position of the tooltip.
     * @group Props
     */
    readonly tooltipPosition: _angular_core.InputSignal<"top" | "left" | "right" | "bottom">;
    /**
     * Type of CSS position.
     * @group Props
     */
    readonly tooltipPositionStyle: _angular_core.InputSignal<string>;
    /**
     * Style class of the tooltip.
     * @group Props
     */
    readonly tooltipStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Fields used when filtering the options, defaults to optionLabel.
     * @group Props
     */
    readonly focusOnHover: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Determines if the option will be selected on focus.
     * @group Props
     */
    readonly selectOnFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to focus on the first visible or selected element when the overlay panel is shown.
     * @group Props
     */
    readonly autoOptionFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Applies focus to the filter element when the overlay is shown.
     * @group Props
     */
    readonly autofocusFilter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When specified, filter displays with this value.
     * @group Props
     */
    readonly filterValue: _angular_core.InputSignal<string | null | undefined>;
    /**
     * An array of objects to display as the available options.
     * @group Props
     */
    readonly options: _angular_core.InputSignal<any[] | null | undefined>;
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'self'
     * @group Props
     */
    appendTo: _angular_core.InputSignal<any>;
    /**
     * The motion options.
     * @group Props
     */
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    /**
     * Callback to invoke when value of select changes.
     * @param {SelectChangeEvent} event - custom change event.
     * @group Emits
     */
    onChange: _angular_core.OutputEmitterRef<SelectChangeEvent>;
    /**
     * Callback to invoke when data is filtered.
     * @param {SelectFilterEvent} event - custom filter event.
     * @group Emits
     */
    onFilter: _angular_core.OutputEmitterRef<SelectFilterEvent>;
    /**
     * Callback to invoke when select gets focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onFocus: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke when select loses focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onBlur: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke when component is clicked.
     * @param {MouseEvent} event - Mouse event.
     * @group Emits
     */
    onClick: _angular_core.OutputEmitterRef<MouseEvent>;
    /**
     * Callback to invoke when select overlay gets visible.
     * @param {AnimationEvent} event - Animation event.
     * @group Emits
     */
    onShow: _angular_core.OutputEmitterRef<AnimationEvent>;
    /**
     * Callback to invoke when select overlay gets hidden.
     * @param {AnimationEvent} event - Animation event.
     * @group Emits
     */
    onHide: _angular_core.OutputEmitterRef<AnimationEvent>;
    /**
     * Callback to invoke when select clears the value.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onClear: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke in lazy mode to load new data.
     * @param {SelectLazyLoadEvent} event - Lazy load event.
     * @group Emits
     */
    onLazyLoad: _angular_core.OutputEmitterRef<SelectLazyLoadEvent>;
    _componentStyle: SelectStyle;
    readonly filterViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly focusInputViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly editableInputViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly itemsViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly scroller: _angular_core.Signal<Nullable<Scroller>>;
    readonly overlayViewChild: _angular_core.Signal<Nullable<Overlay>>;
    readonly firstHiddenFocusableElementOnOverlay: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly lastHiddenFocusableElementOnOverlay: _angular_core.Signal<Nullable<ElementRef<any>>>;
    itemsWrapper: Nullable<HTMLDivElement>;
    $appendTo: _angular_core.Signal<any>;
    /**
     * Custom item template.
     * @group Templates
     */
    readonly itemTemplate: _angular_core.Signal<Nullable<TemplateRef<SelectItemTemplateContext<any>>>>;
    /**
     * Custom group template.
     * @group Templates
     */
    readonly groupTemplate: _angular_core.Signal<Nullable<TemplateRef<SelectGroupTemplateContext<any>>>>;
    /**
     * Custom loader template.
     * @group Templates
     */
    loaderTemplate: Nullable<TemplateRef<SelectLoaderTemplateContext>>;
    /**
     * Custom selected item template.
     * @group Templates
     */
    selectedItemTemplate: Nullable<TemplateRef<SelectSelectedItemTemplateContext>>;
    /**
     * Custom header template.
     * @group Templates
     */
    readonly headerTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom filter template.
     * @group Templates
     */
    filterTemplate: Nullable<TemplateRef<SelectFilterTemplateContext>>;
    /**
     * Custom footer template.
     * @group Templates
     */
    readonly footerTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom empty filter template.
     * @group Templates
     */
    readonly emptyFilterTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom empty template.
     * @group Templates
     */
    readonly emptyTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom dropdown icon template.
     * @group Templates
     */
    dropdownIconTemplate: Nullable<TemplateRef<SelectIconTemplateContext>>;
    /**
     * Custom loading icon template.
     * @group Templates
     */
    loadingIconTemplate: Nullable<TemplateRef<void>>;
    /**
     * Custom clear icon template.
     * @group Templates
     */
    clearIconTemplate: Nullable<TemplateRef<SelectIconTemplateContext>>;
    /**
     * Custom filter icon template.
     * @group Templates
     */
    filterIconTemplate: Nullable<TemplateRef<void>>;
    /**
     * Custom on icon template.
     * @group Templates
     */
    readonly onIconTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom off icon template.
     * @group Templates
     */
    readonly offIconTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom cancel icon template.
     * @group Templates
     */
    readonly cancelIconTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _itemTemplate: TemplateRef<SelectItemTemplateContext> | undefined;
    _selectedItemTemplate: TemplateRef<SelectSelectedItemTemplateContext> | undefined;
    _headerTemplate: TemplateRef<void> | undefined;
    _filterTemplate: TemplateRef<SelectFilterTemplateContext> | undefined;
    _footerTemplate: TemplateRef<void> | undefined;
    _emptyFilterTemplate: TemplateRef<void> | undefined;
    _emptyTemplate: TemplateRef<void> | undefined;
    _groupTemplate: TemplateRef<SelectGroupTemplateContext> | undefined;
    _loaderTemplate: TemplateRef<SelectLoaderTemplateContext> | undefined;
    _dropdownIconTemplate: TemplateRef<SelectIconTemplateContext> | undefined;
    _loadingIconTemplate: TemplateRef<void> | undefined;
    _clearIconTemplate: TemplateRef<SelectIconTemplateContext> | undefined;
    _filterIconTemplate: TemplateRef<void> | undefined;
    _cancelIconTemplate: TemplateRef<void> | undefined;
    _onIconTemplate: TemplateRef<void> | undefined;
    _offIconTemplate: TemplateRef<void> | undefined;
    filterOptions: SelectFilterOptions | undefined;
    _options: _angular_core.WritableSignal<any[] | null | undefined>;
    _placeholder: _angular_core.WritableSignal<string | undefined>;
    value: any;
    hover: Nullable<boolean>;
    focused: Nullable<boolean>;
    overlayVisible: Nullable<boolean>;
    optionsChanged: Nullable<boolean>;
    panel: Nullable<HTMLDivElement>;
    dimensionsUpdated: Nullable<boolean>;
    hoveredItem: any;
    selectedOptionUpdated: Nullable<boolean>;
    _filterValue: _angular_core.WritableSignal<any>;
    searchValue: Nullable<string>;
    searchIndex: Nullable<number>;
    searchTimeout: any;
    previousSearchChar: Nullable<string>;
    currentSearchChar: Nullable<string>;
    preventModelTouched: Nullable<boolean>;
    focusedOptionIndex: _angular_core.WritableSignal<number>;
    labelId: Nullable<string>;
    listId: Nullable<string>;
    clicked: _angular_core.WritableSignal<boolean>;
    get emptyMessageLabel(): string;
    get emptyFilterMessageLabel(): string;
    get isVisibleClearIcon(): boolean | undefined;
    get listLabel(): string;
    get focusedOptionId(): string | null;
    visibleOptions: _angular_core.Signal<any>;
    label: _angular_core.Signal<any>;
    selectedOption: any;
    constructor();
    private isModelValueNotSet;
    private getAllVisibleAndNonVisibleOptions;
    onInit(): void;
    onAfterContentInit(): void;
    onAfterViewChecked(): void;
    flatOptions(options: any): any;
    autoUpdateModel(): void;
    onOptionSelect(event: any, option: any, isHide?: boolean, preventChange?: boolean): void;
    onOptionMouseEnter(event: any, index: any): void;
    updateModel(value: any, event?: any): void;
    allowModelChange(): boolean;
    isSelected(option: any): boolean;
    private isOptionValueEqualsModelValue;
    onAfterViewInit(): void;
    updatePlaceHolderForFloatingLabel(): void;
    updateEditableLabel(): void;
    clearEditableLabel(): void;
    getOptionIndex(index: any, scrollerOptions: any): any;
    getOptionLabel(option: any): any;
    getOptionValue(option: any): any;
    getPTItemOptions(option: any, itemOptions: any, index: number, key: string): any;
    isSelectedOptionEmpty(): boolean;
    isOptionDisabled(option: any): any;
    getOptionGroupLabel(optionGroup: any): any;
    getOptionGroupChildren(optionGroup: any): any;
    getAriaPosInset(index: any): any;
    get ariaSetSize(): any;
    /**
     * Callback to invoke on filter reset.
     * @group Method
     */
    resetFilter(): void;
    onContainerClick(event: any): void;
    isEmpty(): any;
    onEditableInput(event: Event): void;
    /**
     * Displays the panel.
     * @group Method
     */
    show(isFocus?: any): void;
    onOverlayBeforeEnter(event: any): void;
    onOverlayAfterLeave(event: any): void;
    /**
     * Hides the panel.
     * @group Method
     */
    hide(isFocus?: any): void;
    onInputFocus(event: Event): void;
    onInputBlur(event: Event): void;
    onKeyDown(event: KeyboardEvent, search?: boolean): void;
    onFilterKeyDown(event: any): void;
    onFilterBlur(): void;
    onArrowDownKey(event: KeyboardEvent): void;
    changeFocusedOptionIndex(event: any, index: any): void;
    get virtualScrollerDisabled(): boolean;
    scrollInView(index?: number): void;
    hasSelectedOption(): boolean;
    isValidSelectedOption(option: any): boolean;
    equalityKey(): string | undefined;
    findFirstFocusedOptionIndex(): any;
    findFirstOptionIndex(): any;
    findSelectedOptionIndex(): any;
    findNextOptionIndex(index: any): any;
    findPrevOptionIndex(index: any): any;
    findLastOptionIndex(): number;
    findLastFocusedOptionIndex(): any;
    isValidOption(option: any): boolean;
    isOptionGroup(option: any): any;
    onArrowUpKey(event: KeyboardEvent, pressedInInputText?: boolean): void;
    onArrowLeftKey(event: KeyboardEvent, pressedInInputText?: boolean): void;
    onDeleteKey(event: KeyboardEvent): void;
    onHomeKey(event: any, pressedInInputText?: boolean): void;
    onEndKey(event: any, pressedInInputText?: boolean): void;
    onPageDownKey(event: KeyboardEvent): void;
    onPageUpKey(event: KeyboardEvent): void;
    onSpaceKey(event: KeyboardEvent, pressedInInputText?: boolean): void;
    onEnterKey(event: any, pressedInInput?: boolean): void;
    onEscapeKey(event: KeyboardEvent): void;
    onTabKey(event: any, pressedInInputText?: boolean): void;
    onFirstHiddenFocus(event: any): void;
    onLastHiddenFocus(event: any): void;
    hasFocusableElements(): boolean;
    onBackspaceKey(event: KeyboardEvent, pressedInInputText?: boolean): void;
    searchFields(): any[];
    searchOptions(event: any, char: any): boolean;
    isOptionMatched(option: any): any;
    onFilterInputChange(event: Event | any): void;
    applyFocus(): void;
    /**
     * Applies focus.
     * @group Method
     */
    focus(): void;
    /**
     * Clears the model.
     * @group Method
     */
    clear(event?: Event): void;
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value: any, setModelValue: (value: any) => void): void;
    get containerDataP(): string | undefined;
    get labelDataP(): string | undefined;
    get dropdownIconDataP(): string | undefined;
    get overlayDataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Select, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Select, "p-select", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "panelStyle": { "alias": "panelStyle"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "panelStyleClass": { "alias": "panelStyleClass"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "editable": { "alias": "editable"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "loadingIcon": { "alias": "loadingIcon"; "required": false; "isSignal": true; }; "filterPlaceholder": { "alias": "filterPlaceholder"; "required": false; "isSignal": true; }; "filterLocale": { "alias": "filterLocale"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "filterBy": { "alias": "filterBy"; "required": false; "isSignal": true; }; "filterFields": { "alias": "filterFields"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "resetFilterOnHide": { "alias": "resetFilterOnHide"; "required": false; "isSignal": true; }; "checkmark": { "alias": "checkmark"; "required": false; "isSignal": true; }; "dropdownIcon": { "alias": "dropdownIcon"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "optionLabel": { "alias": "optionLabel"; "required": false; "isSignal": true; }; "optionValue": { "alias": "optionValue"; "required": false; "isSignal": true; }; "optionDisabled": { "alias": "optionDisabled"; "required": false; "isSignal": true; }; "optionGroupLabel": { "alias": "optionGroupLabel"; "required": false; "isSignal": true; }; "optionGroupChildren": { "alias": "optionGroupChildren"; "required": false; "isSignal": true; }; "group": { "alias": "group"; "required": false; "isSignal": true; }; "showClear": { "alias": "showClear"; "required": false; "isSignal": true; }; "emptyFilterMessage": { "alias": "emptyFilterMessage"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "virtualScroll": { "alias": "virtualScroll"; "required": false; "isSignal": true; }; "virtualScrollItemSize": { "alias": "virtualScrollItemSize"; "required": false; "isSignal": true; }; "virtualScrollOptions": { "alias": "virtualScrollOptions"; "required": false; "isSignal": true; }; "overlayOptions": { "alias": "overlayOptions"; "required": false; "isSignal": true; }; "ariaFilterLabel": { "alias": "ariaFilterLabel"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "filterMatchMode": { "alias": "filterMatchMode"; "required": false; "isSignal": true; }; "tooltip": { "alias": "tooltip"; "required": false; "isSignal": true; }; "tooltipPosition": { "alias": "tooltipPosition"; "required": false; "isSignal": true; }; "tooltipPositionStyle": { "alias": "tooltipPositionStyle"; "required": false; "isSignal": true; }; "tooltipStyleClass": { "alias": "tooltipStyleClass"; "required": false; "isSignal": true; }; "focusOnHover": { "alias": "focusOnHover"; "required": false; "isSignal": true; }; "selectOnFocus": { "alias": "selectOnFocus"; "required": false; "isSignal": true; }; "autoOptionFocus": { "alias": "autoOptionFocus"; "required": false; "isSignal": true; }; "autofocusFilter": { "alias": "autofocusFilter"; "required": false; "isSignal": true; }; "filterValue": { "alias": "filterValue"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; }, { "onChange": "onChange"; "onFilter": "onFilter"; "onFocus": "onFocus"; "onBlur": "onBlur"; "onClick": "onClick"; "onShow": "onShow"; "onHide": "onHide"; "onClear": "onClear"; "onLazyLoad": "onLazyLoad"; }, ["itemTemplate", "groupTemplate", "headerTemplate", "footerTemplate", "emptyFilterTemplate", "emptyTemplate", "onIconTemplate", "offIconTemplate", "cancelIconTemplate", "templates", "loaderTemplate", "selectedItemTemplate", "filterTemplate", "dropdownIconTemplate", "loadingIconTemplate", "clearIconTemplate", "filterIconTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class SelectModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<SelectModule, never, [typeof Select, typeof i2.SharedModule], [typeof Select, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<SelectModule>;
}

export { SELECT_VALUE_ACCESSOR, Select, SelectClasses, SelectItem, SelectModule, SelectStyle };
