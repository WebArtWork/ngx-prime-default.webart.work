import { ListBoxPassThrough, ListboxChangeEvent, ListboxClickEvent, ListboxFilterEvent, ListboxSelectAllChangeEvent, ListboxItemTemplateContext, ListboxGroupTemplateContext, ListboxHeaderTemplateContext, ListboxFilterTemplateContext, ListboxFooterTemplateContext, ListboxCheckIconTemplateContext, ListboxCheckmarkTemplateContext, ListboxLoaderTemplateContext, ListboxFilterOptions } from '@wawjs/ngx-prime/types/listbox';
export * from '@wawjs/ngx-prime/types/listbox';
import * as _angular_core from '@angular/core';
import { ElementRef, TemplateRef } from '@angular/core';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import * as i2 from '@wawjs/ngx-prime/api';
import { FilterService, ScrollerOptions, Header, Footer, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { ScrollerLazyLoadEvent, Scroller } from '@wawjs/ngx-prime/scroller';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import { Subscription } from 'rxjs';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class ListBoxStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-listbox-striped': any;
            'p-disabled': any;
            'p-invalid': any;
            'p-listbox-fluid': any;
            'p-listbox-dragging': any;
        })[];
        header: string;
        pcFilter: string;
        listContainer: string;
        list: string;
        optionGroup: string;
        option: ({ instance, option, i, scrollerOptions }: {
            instance: any;
            option: any;
            i: any;
            scrollerOptions: any;
        }) => (string | {
            'p-listbox-option-selected': any;
            'p-focus': boolean;
            'p-disabled': any;
        })[];
        optionCheckIcon: string;
        optionBlankIcon: string;
        emptyMessage: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ListBoxStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ListBoxStyle>;
}
/**
 *
 * ListBox is used to select one or more values from a list of items.
 *
 * [Live Demo](https://www.ngx-prime.org/listbox/)
 *
 * @module listboxstyle
 *
 */
declare enum ListboxClasses {
    /**
     * Class name of the root element
     */
    root = "p-listbox",
    /**
     * Class name of the header element
     */
    header = "p-listbox-header",
    /**
     * Class name of the filter element
     */
    pcFilter = "p-listbox-filter",
    /**
     * Class name of the list container element
     */
    listContainer = "p-listbox-list-container",
    /**
     * Class name of the list element
     */
    list = "p-listbox-list",
    /**
     * Class name of the option group element
     */
    optionGroup = "p-listbox-option-group",
    /**
     * Class name of the option element
     */
    option = "p-listbox-option",
    /**
     * Class name of the option check icon element
     */
    optionCheckIcon = "p-listbox-option-check-icon",
    /**
     * Class name of the option blank icon element
     */
    optionBlankIcon = "p-listbox-option-blank-icon",
    /**
     * Class name of the empty message element
     */
    emptyMessage = "p-listbox-empty-message"
}
type ListboxStyle = BaseStyle;

declare const LISTBOX_VALUE_ACCESSOR: any;
/**
 * ListBox is used to select one or more values from a list of items.
 * @group Components
 */
declare class Listbox extends BaseEditableHolder<ListBoxPassThrough> {
    filterService: FilterService;
    componentName: string;
    readonly hostName: _angular_core.InputSignal<any>;
    bindDirectiveInstance: Bind;
    $pcListbox: Listbox | undefined;
    onAfterViewChecked(): void;
    /**
     * Unique identifier of the component.
     * @group Props
     */
    readonly id: _angular_core.InputSignal<string | undefined>;
    private _generatedId;
    get resolvedId(): string;
    /**
     * Text to display when the search is active. Defaults to global value in i18n translation configuration.
     * @group Props
     * @defaultValue '{0} results are available'
     */
    readonly searchMessage: _angular_core.InputSignal<string | undefined>;
    /**
     * Text to display when filtering does not return any results. Defaults to global value in i18n translation configuration.
     * @group Props
     * @defaultValue 'No selected item'
     */
    readonly emptySelectionMessage: _angular_core.InputSignal<string | undefined>;
    /**
     * Text to be displayed in hidden accessible field when options are selected. Defaults to global value in i18n translation configuration.
     * @group Props
     * @defaultValue '{0} items selected'
     */
    readonly selectionMessage: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to focus on the first visible or selected element when the overlay panel is shown.
     * @group Props
     */
    readonly autoOptionFocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Defines a string that labels the input for accessibility.
     * @group Props
     */
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * When enabled, the focused option is selected.
     * @group Props
     */
    readonly selectOnFocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Locale to use in searching. The default locale is the host environment's current locale.
     * @group Props
     */
    readonly searchLocale: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When enabled, the hovered option will be focused.
     * @group Props
     */
    readonly focusOnHover: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Text to display when filtering.
     * @group Props
     */
    readonly filterMessage: _angular_core.InputSignal<string | undefined>;
    /**
     * Fields used when filtering the options, defaults to optionLabel.
     * @group Props
     */
    readonly filterFields: _angular_core.InputSignal<any[] | undefined>;
    /**
     * Defines if data is loaded and interacted with in lazy manner.
     * @group Props
     */
    readonly lazy: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether the data should be loaded on demand during scroll.
     * @group Props
     */
    readonly virtualScroll: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Height of an item in the list for VirtualScrolling.
     * @group Props
     */
    readonly virtualScrollItemSize: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Whether to use the scroller feature. The properties of scroller component can be used like an object in it.
     * @group Props
     */
    readonly virtualScrollOptions: _angular_core.InputSignal<ScrollerOptions | undefined>;
    /**
     * Height of the viewport in pixels, a scrollbar is defined if height of list exceeds this value.
     * @group Props
     */
    readonly scrollHeight: _angular_core.InputSignal<string>;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    readonly tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * When specified, allows selecting multiple values.
     * @group Props
     */
    readonly multiple: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Style class of the container.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    readonly styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the list element.
     * @group Props
     */
    readonly listStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the list element.
     * @group Props
     */
    readonly listStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * When present, it specifies that the element value cannot be changed.
     * @group Props
     */
    readonly readonly: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When specified, allows selecting items with checkboxes.
     * @group Props
     */
    readonly checkbox: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When specified, displays a filter input at header.
     * @group Props
     */
    readonly filter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When filtering is enabled, filterBy decides which field or fields (comma separated) to search against.
     * @group Props
     */
    readonly filterBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines how the items are filtered.
     * @group Props
     */
    readonly filterMatchMode: _angular_core.InputSignal<string>;
    /**
     * Locale to use in filtering. The default locale is the host environment's current locale.
     * @group Props
     */
    readonly filterLocale: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines how multiple items can be selected, when true metaKey needs to be pressed to select or unselect an item and when set to false selection of each item can be toggled individually. On touch enabled devices, metaKeySelection is turned off automatically.
     * @group Props
     */
    readonly metaKeySelection: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * A property to uniquely identify a value in options.
     * @group Props
     */
    readonly dataKey: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether header checkbox is shown in multiple mode.
     * @group Props
     */
    readonly showToggleAll: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Name of the label field of an option.
     * @group Props
     */
    readonly optionLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Name of the value field of an option.
     * @group Props
     */
    readonly optionValue: _angular_core.InputSignal<string | undefined>;
    /**
     * Name of the options field of an option group.
     * @group Props
     */
    readonly optionGroupChildren: _angular_core.InputSignal<string | undefined>;
    /**
     * Name of the label field of an option group.
     * @group Props
     */
    readonly optionGroupLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Name of the disabled field of an option or function to determine disabled state.
     * @group Props
     */
    readonly optionDisabled: _angular_core.InputSignal<string | ((item: any) => boolean) | undefined>;
    /**
     * Defines a string that labels the filter input.
     * @group Props
     */
    readonly ariaFilterLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines placeholder of the filter input.
     * @group Props
     */
    readonly filterPlaceHolder: _angular_core.InputSignal<string | undefined>;
    /**
     * Text to display when filtering does not return any results.
     * @group Props
     */
    readonly emptyFilterMessage: _angular_core.InputSignal<string | undefined>;
    /**
     * Text to display when there is no data. Defaults to global value in i18n translation configuration.
     * @group Props
     */
    readonly emptyMessage: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to display options as grouped when nested options are provided.
     * @group Props
     */
    readonly group: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * An array of selectitems to display as the available options.
     * @group Props
     */
    readonly options: _angular_core.InputSignal<any[] | undefined>;
    /**
     * When specified, filter displays with this value.
     * @group Props
     */
    readonly filterValue: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether all data is selected.
     * @group Props
     */
    readonly selectAll: _angular_core.InputSignal<boolean | null | undefined>;
    /**
     * Whether to displays rows with alternating colors.
     * @group Props
     * @defaultValue false
     */
    readonly striped: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Whether the selected option will be add highlight class.
     * @group Props
     * @defaultValue true
     */
    readonly highlightOnSelect: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether the selected option will be shown with a check mark.
     * @group Props
     * @defaultValue false
     */
    readonly checkmark: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to enable dragdrop based reordering.
     * @group Props
     */
    readonly dragdrop: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Array to use for CDK drop list data binding. When not provided, uses options array.
     * @group Props
     */
    readonly dropListData: _angular_core.InputSignal<any[] | undefined>;
    /**
     * Computed property for stable CDK drop list data reference
     */
    cdkDropData: _angular_core.Signal<any>;
    /**
     * Spans 100% width of the container when enabled.
     * @defaultValue undefined
     * @group Props
     */
    fluid: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Callback to invoke on value change.
     * @param {ListboxChangeEvent} event - Custom change event.
     * @group Emits
     */
    onChange: _angular_core.OutputEmitterRef<ListboxChangeEvent>;
    /**
     * Callback to invoke when option is clicked.
     * @param {ListboxClickEvent} event - Custom click event.
     * @group Emits
     */
    onClick: _angular_core.OutputEmitterRef<ListboxClickEvent>;
    /**
     * Callback to invoke when option is double clicked.
     * @param {ListboxDoubleClickEvent} event - Custom double click event.
     * @group Emits
     */
    onDblClick: _angular_core.OutputEmitterRef<ListboxClickEvent>;
    /**
     * Callback to invoke when data is filtered.
     * @param {ListboxFilterEvent} event - Custom filter event.
     * @group Emits
     */
    onFilter: _angular_core.OutputEmitterRef<ListboxFilterEvent>;
    /**
     * Callback to invoke when component receives focus.
     * @param {FocusEvent} event - Focus event.
     * @group Emits
     */
    onFocus: _angular_core.OutputEmitterRef<FocusEvent>;
    /**
     * Callback to invoke when component loses focus.
     * @param {FocusEvent} event - Blur event.
     * @group Emits
     */
    onBlur: _angular_core.OutputEmitterRef<FocusEvent>;
    /**
     * Callback to invoke when all data is selected.
     * @param {ListboxSelectAllChangeEvent} event - Custom select event.
     * @group Emits
     */
    onSelectAllChange: _angular_core.OutputEmitterRef<ListboxSelectAllChangeEvent>;
    /**
     * Emits on lazy load.
     * @param {ScrollerLazyLoadEvent} event - Scroller lazy load event.
     * @group Emits
     */
    onLazyLoad: _angular_core.OutputEmitterRef<ScrollerLazyLoadEvent>;
    /**
     * Emits on item is dropped.
     * @param {CdkDragDrop<string[]>} event - Scroller lazy load event.
     * @group Emits
     */
    onDrop: _angular_core.OutputEmitterRef<CdkDragDrop<string[], string[], any>>;
    readonly headerCheckboxViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly filterViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly lastHiddenFocusableElement: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly firstHiddenFocusableElement: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly scroller: _angular_core.Signal<Nullable<Scroller>>;
    readonly listViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly containerViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly headerFacet: _angular_core.Signal<Header | undefined>;
    readonly footerFacet: _angular_core.Signal<Footer | undefined>;
    /**
     * Custom item template.
     * @param {ListboxItemTemplateContext} context - item context.
     * @see {@link ListboxItemTemplateContext}
     * @group Templates
     */
    readonly itemTemplate: _angular_core.Signal<TemplateRef<ListboxItemTemplateContext<any>> | undefined>;
    /**
     * Custom group template.
     * @param {ListboxGroupTemplateContext} context - group context.
     * @see {@link ListboxGroupTemplateContext}
     * @group Templates
     */
    readonly groupTemplate: _angular_core.Signal<TemplateRef<ListboxGroupTemplateContext<any>> | undefined>;
    /**
     * Custom header template.
     * @param {ListboxHeaderTemplateContext} context - header context.
     * @see {@link ListboxHeaderTemplateContext}
     * @group Templates
     */
    headerTemplate: TemplateRef<ListboxHeaderTemplateContext> | undefined;
    /**
     * Custom filter template.
     * @param {ListboxFilterTemplateContext} context - filter context.
     * @see {@link ListboxFilterTemplateContext}
     * @group Templates
     */
    filterTemplate: TemplateRef<ListboxFilterTemplateContext> | undefined;
    /**
     * Custom footer template.
     * @param {ListboxFooterTemplateContext} context - footer context.
     * @see {@link ListboxFooterTemplateContext}
     * @group Templates
     */
    footerTemplate: TemplateRef<ListboxFooterTemplateContext> | undefined;
    /**
     * Custom empty filter message template.
     * @group Templates
     */
    readonly emptyFilterTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom empty message template.
     * @group Templates
     */
    readonly emptyTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom filter icon template.
     * @group Templates
     */
    filterIconTemplate: TemplateRef<void> | undefined;
    /**
     * Custom check icon template.
     * @param {ListboxCheckIconTemplateContext} context - check icon context.
     * @see {@link ListboxCheckIconTemplateContext}
     * @group Templates
     */
    checkIconTemplate: TemplateRef<ListboxCheckIconTemplateContext> | undefined;
    /**
     * Custom checkmark icon template.
     * @param {ListboxCheckmarkTemplateContext} context - checkmark context.
     * @see {@link ListboxCheckmarkTemplateContext}
     * @group Templates
     */
    readonly checkmarkTemplate: _angular_core.Signal<TemplateRef<ListboxCheckmarkTemplateContext> | undefined>;
    /**
     * Custom loader template.
     * @param {ListboxLoaderTemplateContext} context - loader context.
     * @see {@link ListboxLoaderTemplateContext}
     * @group Templates
     */
    loaderTemplate: TemplateRef<ListboxLoaderTemplateContext> | undefined;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _itemTemplate: TemplateRef<ListboxItemTemplateContext> | undefined;
    _groupTemplate: TemplateRef<ListboxGroupTemplateContext> | undefined;
    _headerTemplate: TemplateRef<ListboxHeaderTemplateContext> | undefined;
    _filterTemplate: TemplateRef<ListboxFilterTemplateContext> | undefined;
    _footerTemplate: TemplateRef<ListboxFooterTemplateContext> | undefined;
    _emptyFilterTemplate: TemplateRef<void> | undefined;
    _emptyTemplate: TemplateRef<void> | undefined;
    _filterIconTemplate: TemplateRef<void> | undefined;
    _checkIconTemplate: TemplateRef<ListboxCheckIconTemplateContext> | undefined;
    _checkmarkTemplate: TemplateRef<ListboxCheckmarkTemplateContext> | undefined;
    _loaderTemplate: TemplateRef<ListboxLoaderTemplateContext> | undefined;
    _filterValue: _angular_core.WritableSignal<string | null | undefined>;
    _filteredOptions: any[] | undefined | null;
    filterOptions: ListboxFilterOptions | undefined;
    filtered: boolean | undefined | null;
    value: any | undefined | null;
    optionTouched: boolean | undefined | null;
    focus: boolean | undefined | null;
    headerCheckboxFocus: boolean | undefined | null;
    translationSubscription: Nullable<Subscription>;
    focused: boolean | undefined;
    scrollerTabIndex: string;
    _componentStyle: ListBoxStyle;
    get focusedOptionId(): string | null;
    get filterResultMessageText(): string;
    get filterMessageText(): string;
    get searchMessageText(): string;
    get emptyFilterMessageText(): string;
    get selectionMessageText(): string;
    get emptySelectionMessageText(): string;
    get selectedMessageText(): string;
    get ariaSetSize(): any;
    get virtualScrollerDisabled(): boolean;
    get searchFields(): any[];
    get toggleAllAriaLabel(): string | undefined;
    searchValue: string | undefined;
    searchTimeout: any;
    _options: _angular_core.WritableSignal<any>;
    startRangeIndex: _angular_core.WritableSignal<number>;
    focusedOptionIndex: _angular_core.WritableSignal<number>;
    isDragging: _angular_core.WritableSignal<boolean>;
    onHostFocusOut(event: FocusEvent): void;
    visibleOptions: _angular_core.Signal<any>;
    constructor();
    onInit(): void;
    onAfterContentInit(): void;
    flatOptions(options: any): any;
    autoUpdateModel(): void;
    /**
     * Updates the model value.
     * @group Method
     */
    updateModel(value: any, event?: any): void;
    removeOption(option: any): any;
    onOptionSelect(event: any, option: any, index?: number): void;
    onOptionSelectMultiple(event: any, option: any): void;
    onOptionSelectSingle(event: any, option: any): void;
    onOptionSelectRange(event: any, start?: number, end?: number): void;
    onToggleAll(event: any): void;
    allSelected(): any;
    onOptionTouchEnd(): void;
    onOptionMouseDown(event: MouseEvent, index: number): void;
    onOptionMouseEnter(event: MouseEvent, index: number): void;
    onOptionDoubleClick(event: MouseEvent, option: any): void;
    onFirstHiddenFocus(): void;
    onLastHiddenFocus(event: FocusEvent): void;
    onFocusout(event: FocusEvent): void;
    onListFocus(event: FocusEvent): void;
    onListBlur(event: FocusEvent): void;
    onHeaderCheckboxKeyDown(event: any): void;
    onHeaderCheckboxTabKeyDown(event: any): void;
    onFilterChange(event: Event): void;
    onFilterBlur(): void;
    onListKeyDown(event: KeyboardEvent): void;
    onFilterKeyDown(event: KeyboardEvent): void;
    onArrowDownKey(event: KeyboardEvent): void;
    onArrowUpKey(event: KeyboardEvent): void;
    onArrowLeftKey(event: KeyboardEvent, pressedInInputText?: boolean): void;
    onHomeKey(event: KeyboardEvent, pressedInInputText?: boolean): void;
    onEndKey(event: KeyboardEvent, pressedInInputText?: boolean): void;
    onPageDownKey(event: KeyboardEvent): void;
    onPageUpKey(event: KeyboardEvent): void;
    onEnterKey(event: any): void;
    onSpaceKey(event: KeyboardEvent): void;
    onShiftKey(): void;
    getOptionGroupChildren(optionGroup: any): any;
    getOptionGroupLabel(optionGroup: any): any;
    getOptionLabel(option: any): any;
    getOptionIndex(index: any, scrollerOptions: any): any;
    getOptionValue(option: any): any;
    getAriaPosInset(index: number): number;
    getPTOptions(option: any, itemOptions: any, index: number, key: string): any;
    hasSelectedOption(): boolean;
    isOptionGroup(option: any): any;
    changeFocusedOptionIndex(event: any, index: any): void;
    searchOptions(event: any, char: any): boolean;
    isOptionMatched(option: any): any;
    scrollInView(index?: number): void;
    findFirstOptionIndex(): any;
    findLastOptionIndex(): number;
    findFirstFocusedOptionIndex(): any;
    findLastFocusedOptionIndex(): number;
    findLastSelectedOptionIndex(): number;
    findNextOptionIndex(index: any): any;
    findNextSelectedOptionIndex(index: any): any;
    findPrevSelectedOptionIndex(index: any): number;
    findFirstSelectedOptionIndex(): any;
    findPrevOptionIndex(index: any): any;
    findSelectedOptionIndex(): any;
    findNearestSelectedOptionIndex(index: any, firstCheckUp?: boolean): any;
    equalityKey(): string | null | undefined;
    isValidSelectedOption(option: any): any;
    isOptionDisabled(option: any): any;
    isEquals(value1: any, value2: any): boolean;
    isSelected(option: any): any;
    isValidOption(option: any): any;
    isEmpty(): boolean;
    hasFilter(): boolean | "" | null | undefined;
    resetFilter(): void;
    onDragEntered(): void;
    onDragExited(): void;
    drop(event: CdkDragDrop<string[]>): void;
    get containerDataP(): string | undefined;
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value: any, setModelValue: (value: any) => void): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Listbox, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Listbox, "p-listbox, p-listBox, p-list-box", never, { "hostName": { "alias": "hostName"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "searchMessage": { "alias": "searchMessage"; "required": false; "isSignal": true; }; "emptySelectionMessage": { "alias": "emptySelectionMessage"; "required": false; "isSignal": true; }; "selectionMessage": { "alias": "selectionMessage"; "required": false; "isSignal": true; }; "autoOptionFocus": { "alias": "autoOptionFocus"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "selectOnFocus": { "alias": "selectOnFocus"; "required": false; "isSignal": true; }; "searchLocale": { "alias": "searchLocale"; "required": false; "isSignal": true; }; "focusOnHover": { "alias": "focusOnHover"; "required": false; "isSignal": true; }; "filterMessage": { "alias": "filterMessage"; "required": false; "isSignal": true; }; "filterFields": { "alias": "filterFields"; "required": false; "isSignal": true; }; "lazy": { "alias": "lazy"; "required": false; "isSignal": true; }; "virtualScroll": { "alias": "virtualScroll"; "required": false; "isSignal": true; }; "virtualScrollItemSize": { "alias": "virtualScrollItemSize"; "required": false; "isSignal": true; }; "virtualScrollOptions": { "alias": "virtualScrollOptions"; "required": false; "isSignal": true; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "listStyle": { "alias": "listStyle"; "required": false; "isSignal": true; }; "listStyleClass": { "alias": "listStyleClass"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "checkbox": { "alias": "checkbox"; "required": false; "isSignal": true; }; "filter": { "alias": "filter"; "required": false; "isSignal": true; }; "filterBy": { "alias": "filterBy"; "required": false; "isSignal": true; }; "filterMatchMode": { "alias": "filterMatchMode"; "required": false; "isSignal": true; }; "filterLocale": { "alias": "filterLocale"; "required": false; "isSignal": true; }; "metaKeySelection": { "alias": "metaKeySelection"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "showToggleAll": { "alias": "showToggleAll"; "required": false; "isSignal": true; }; "optionLabel": { "alias": "optionLabel"; "required": false; "isSignal": true; }; "optionValue": { "alias": "optionValue"; "required": false; "isSignal": true; }; "optionGroupChildren": { "alias": "optionGroupChildren"; "required": false; "isSignal": true; }; "optionGroupLabel": { "alias": "optionGroupLabel"; "required": false; "isSignal": true; }; "optionDisabled": { "alias": "optionDisabled"; "required": false; "isSignal": true; }; "ariaFilterLabel": { "alias": "ariaFilterLabel"; "required": false; "isSignal": true; }; "filterPlaceHolder": { "alias": "filterPlaceHolder"; "required": false; "isSignal": true; }; "emptyFilterMessage": { "alias": "emptyFilterMessage"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "group": { "alias": "group"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "filterValue": { "alias": "filterValue"; "required": false; "isSignal": true; }; "selectAll": { "alias": "selectAll"; "required": false; "isSignal": true; }; "striped": { "alias": "striped"; "required": false; "isSignal": true; }; "highlightOnSelect": { "alias": "highlightOnSelect"; "required": false; "isSignal": true; }; "checkmark": { "alias": "checkmark"; "required": false; "isSignal": true; }; "dragdrop": { "alias": "dragdrop"; "required": false; "isSignal": true; }; "dropListData": { "alias": "dropListData"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; }, { "onChange": "onChange"; "onClick": "onClick"; "onDblClick": "onDblClick"; "onFilter": "onFilter"; "onFocus": "onFocus"; "onBlur": "onBlur"; "onSelectAllChange": "onSelectAllChange"; "onLazyLoad": "onLazyLoad"; "onDrop": "onDrop"; }, ["headerFacet", "footerFacet", "itemTemplate", "groupTemplate", "emptyFilterTemplate", "emptyTemplate", "checkmarkTemplate", "templates", "headerTemplate", "filterTemplate", "footerTemplate", "filterIconTemplate", "checkIconTemplate", "loaderTemplate"], ["p-header", "p-footer"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class ListboxModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ListboxModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<ListboxModule, never, [typeof Listbox, typeof i2.SharedModule], [typeof Listbox, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<ListboxModule>;
}

export { LISTBOX_VALUE_ACCESSOR, ListBoxStyle, Listbox, ListboxClasses, ListboxModule };
export type { ListboxStyle };
