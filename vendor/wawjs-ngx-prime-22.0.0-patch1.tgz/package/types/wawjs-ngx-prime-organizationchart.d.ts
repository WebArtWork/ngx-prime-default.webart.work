import { OrganizationChartPassThrough, OrganizationChartNodeSelectEvent } from '@wawjs/ngx-prime/types/organizationchart';
export * from '@wawjs/ngx-prime/types/organizationchart';
import * as rxjs from 'rxjs';
import { Subscription } from 'rxjs';
import * as _angular_core from '@angular/core';
import { AfterViewChecked, ElementRef, ChangeDetectorRef, TemplateRef } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { TreeNode, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class OrganizationChartStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-organizationchart-preservespace': any;
        })[];
        table: string;
        node: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-organizationchart-node': boolean;
            'p-organizationchart-node-selectable': any;
            'p-organizationchart-node-selected': any;
        })[];
        nodeToggleButton: string;
        nodeToggleButtonIcon: string;
        connectors: string;
        connectorDown: string;
        connectorLeft: ({ first }: {
            first: any;
        }) => (string | {
            'p-organizationchart-connector-top': boolean;
        })[];
        connectorRight: ({ last }: {
            last: any;
        }) => (string | {
            'p-organizationchart-connector-top': boolean;
        })[];
        nodeChildren: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OrganizationChartStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<OrganizationChartStyle>;
}
/**
 *
 * OrganizationChart visualizes hierarchical organization data.
 *
 * [Live Demo](https://www.ngx-prime.org/organizationchart)
 *
 * @module organizationchartstyle
 *
 */
declare enum OrganizationChartClasses {
    /**
     * Class name of the root element
     */
    root = "p-organizationchart",
    /**
     * Class name of the table element
     */
    table = "p-organizationchart-table",
    /**
     * Class name of the node element
     */
    node = "p-organizationchart-node",
    /**
     * Class name of the node toggle button element
     */
    nodeToggleButton = "p-organizationchart-node-toggle-button",
    /**
     * Class name of the node toggle button icon element
     */
    nodeToggleButtonIcon = "p-organizationchart-node-toggle-button-icon",
    /**
     * Class name of the connectors element
     */
    connectors = "p-organizationchart-connectors",
    /**
     * Class name of the connector down element
     */
    connectorDown = "p-organizationchart-connector-down",
    /**
     * Class name of the connector left element
     */
    connectorLeft = "p-organizationchart-connector-left",
    /**
     * Class name of the connector right element
     */
    connectorRight = "p-organizationchart-connector-right",
    /**
     * Class name of the node children element
     */
    nodeChildren = "p-organizationchart-node-children"
}

declare class OrganizationChartNode extends BaseComponent {
    cd: ChangeDetectorRef;
    node: _angular_core.InputSignal<TreeNode<any> | undefined>;
    root: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    first: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    last: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    collapsible: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    chart: OrganizationChart;
    subscription: Subscription;
    _componentStyle: OrganizationChartStyle;
    constructor();
    get leaf(): boolean | undefined;
    get colspan(): number | null | undefined;
    getChildStyle(node: TreeNode<any>): {
        visibility: string;
    };
    getPTOptions(key: string): any;
    getNodeOptions(lineTop: boolean, key: string): any;
    onNodeClick(event: Event, node: TreeNode): void;
    toggleNode(event: Event, node: TreeNode): void;
    isSelected(): boolean;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OrganizationChartNode, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<OrganizationChartNode, "[pOrganizationChartNode]", never, { "node": { "alias": "node"; "required": false; "isSignal": true; }; "root": { "alias": "root"; "required": false; "isSignal": true; }; "first": { "alias": "first"; "required": false; "isSignal": true; }; "last": { "alias": "last"; "required": false; "isSignal": true; }; "collapsible": { "alias": "collapsible"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/**
 * OrganizationChart visualizes hierarchical organization data.
 * @group Components
 */
declare class OrganizationChart extends BaseComponent<OrganizationChartPassThrough> implements AfterViewChecked {
    el: ElementRef<any>;
    cd: ChangeDetectorRef;
    componentName: string;
    /**
     * An array of nested TreeNodes.
     * @group Props
     */
    value: _angular_core.InputSignal<TreeNode<any>[] | undefined>;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines the selection mode.
     * @group Props
     */
    selectionMode: _angular_core.InputSignal<"single" | "multiple" | null | undefined>;
    /**
     * Whether the nodes can be expanded or toggled.
     * @group Props
     */
    collapsible: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Whether the space allocated by a node is preserved when hidden.
     * @deprecated since v20.0.0.
     * @group Props
     */
    preserveSpace: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * A single treenode instance or an array to refer to the selections.
     * @group Props
     */
    selection: _angular_core.ModelSignal<any>;
    /**
     * Callback to invoke when a node is selected.
     * @param {OrganizationChartNodeSelectEvent} event - custom node select event.
     * @group Emits
     */
    onNodeSelect: _angular_core.OutputEmitterRef<OrganizationChartNodeSelectEvent>;
    /**
     * Callback to invoke when a node is unselected.
     * @param {OrganizationChartNodeUnSelectEvent} event - custom node unselect event.
     * @group Emits
     */
    onNodeUnselect: _angular_core.OutputEmitterRef<OrganizationChartNodeSelectEvent>;
    /**
     * Callback to invoke when a node is expanded.
     * @param {OrganizationChartNodeExpandEvent} event - custom node expand event.
     * @group Emits
     */
    onNodeExpand: _angular_core.OutputEmitterRef<OrganizationChartNodeSelectEvent>;
    /**
     * Callback to invoke when a node is collapsed.
     * @param {OrganizationChartNodeCollapseEvent} event - custom node collapse event.
     * @group Emits
     */
    onNodeCollapse: _angular_core.OutputEmitterRef<OrganizationChartNodeSelectEvent>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    togglerIconTemplate: TemplateRef<any> | undefined;
    templateMap: any;
    _togglerIconTemplate: Nullable<TemplateRef<any>>;
    private selectionSource;
    initialized: Nullable<boolean>;
    selectionSource$: rxjs.Observable<any>;
    _componentStyle: OrganizationChartStyle;
    bindDirectiveInstance: Bind;
    $pcOrganizationChart: OrganizationChart | undefined;
    constructor();
    ngAfterViewChecked(): void;
    get root(): TreeNode<any> | null;
    onAfterContentInit(): void;
    getTemplateForNode(node: TreeNode): TemplateRef<any> | null;
    onNodeClick(event: Event, node: TreeNode): void;
    findIndexInSelection(node: TreeNode): number;
    isSelected(node: TreeNode): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OrganizationChart, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<OrganizationChart, "p-organizationChart, p-organization-chart, p-organizationchart", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "selectionMode": { "alias": "selectionMode"; "required": false; "isSignal": true; }; "collapsible": { "alias": "collapsible"; "required": false; "isSignal": true; }; "preserveSpace": { "alias": "preserveSpace"; "required": false; "isSignal": true; }; "selection": { "alias": "selection"; "required": false; "isSignal": true; }; }, { "selection": "selectionChange"; "onNodeSelect": "onNodeSelect"; "onNodeUnselect": "onNodeUnselect"; "onNodeExpand": "onNodeExpand"; "onNodeCollapse": "onNodeCollapse"; }, ["templates", "togglerIconTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class OrganizationChartModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OrganizationChartModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<OrganizationChartModule, never, [typeof OrganizationChart, typeof OrganizationChartNode, typeof i2.SharedModule], [typeof OrganizationChart, typeof OrganizationChartNode, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<OrganizationChartModule>;
}

export { OrganizationChart, OrganizationChartClasses, OrganizationChartModule, OrganizationChartNode, OrganizationChartStyle };
