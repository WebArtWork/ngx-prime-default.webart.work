import { PopoverPassThrough, PopoverContentTemplateContext } from '@wawjs/ngx-prime/types/popover';
export * from '@wawjs/ngx-prime/types/popover';
import * as _angular_core from '@angular/core';
import { TemplateRef, NgZone } from '@angular/core';
import { MotionOptions, MotionEvent } from '@wawjs/css-prime-motion';
import * as i2 from '@wawjs/ngx-prime/api';
import { PrimeTemplate, OverlayService } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { ConnectedOverlayScrollHandler } from '@wawjs/ngx-prime/dom';
import { Nullable, VoidListener } from '@wawjs/ngx-prime/ts-helpers';
import { Subscription } from 'rxjs';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class PopoverStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: string;
        content: string;
    };
    inlineStyles: {
        root: () => {
            position: string;
        };
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PopoverStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<PopoverStyle>;
}

/**
 * Popover is a container component that can overlay other components on page.
 * @group Components
 */
declare class Popover extends BaseComponent<PopoverPassThrough> {
    componentName: string;
    $pcPopover: Popover | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Defines a string that labels the input for accessibility.
     * @group Props
     */
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Enables to hide the overlay when outside is clicked.
     * @group Props
     */
    dismissable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Inline style of the component.
     * @group Props
     */
    style: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the component.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'self'
     * @group Props
     */
    appendTo: _angular_core.InputSignal<any>;
    /**
     * Whether to automatically manage layering.
     * @group Props
     */
    autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Aria label of the close icon.
     * @group Props
     */
    ariaCloseLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Base zIndex value to use in layering.
     * @group Props
     */
    baseZIndex: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * When enabled, first button receives focus on show.
     * @group Props
     */
    focusOnShow: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Transition options of the show animation.
     * @group Props
     * @deprecated since v21.0.0. Use `motionOptions` instead.
     */
    showTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * Transition options of the hide animation.
     * @group Props
     * @deprecated since v21.0.0. Use `motionOptions` instead.
     */
    hideTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * The motion options.
     * @group Props
     */
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    computedMotionOptions: _angular_core.Signal<MotionOptions>;
    /**
     * Callback to invoke when an overlay becomes visible.
     * @group Emits
     */
    onShow: _angular_core.OutputEmitterRef<any>;
    /**
     * Callback to invoke when an overlay gets hidden.
     * @group Emits
     */
    onHide: _angular_core.OutputEmitterRef<any>;
    $appendTo: _angular_core.Signal<any>;
    container: Nullable<HTMLDivElement>;
    overlayVisible: boolean;
    render: boolean;
    selfClick: boolean;
    documentClickListener: VoidListener;
    target: any;
    willHide: Nullable<boolean>;
    scrollHandler: Nullable<ConnectedOverlayScrollHandler>;
    documentResizeListener: VoidListener;
    /**
     * Custom content template.
     * @param {PopoverContentTemplateContext} context - content context.
     * @see {@link PopoverContentTemplateContext}
     * @group Templates
     */
    readonly contentTemplate: _angular_core.Signal<Nullable<TemplateRef<PopoverContentTemplateContext>>>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _contentTemplate: TemplateRef<PopoverContentTemplateContext> | undefined;
    destroyCallback: Nullable<(...args: any[]) => any>;
    overlayEventListener: Nullable<(event?: any) => void>;
    overlaySubscription: Subscription | undefined;
    _componentStyle: PopoverStyle;
    zone: NgZone;
    overlayService: OverlayService;
    onAfterContentInit(): void;
    bindDocumentClickListener(): void;
    unbindDocumentClickListener(): void;
    /**
     * Toggles the visibility of the panel.
     * @param {Event} event - Browser event
     * @param {Target} target - Target element.
     * @group Method
     */
    toggle(event: any, target?: any): void;
    /**
     * Displays the panel.
     * @param {Event} event - Browser event
     * @param {Target} target - Target element.
     * @group Method
     */
    show(event: any, target?: any): void;
    onOverlayClick(event: MouseEvent): void;
    onContentClick(event: MouseEvent): void;
    hasTargetChanged(event: any, target: any): boolean;
    appendOverlay(): void;
    restoreAppend(): void;
    setZIndex(): void;
    align(): void;
    onAnimationStart(event: MotionEvent): void;
    onAnimationEnd(): void;
    focus(): void;
    /**
     * Hides the panel.
     * @group Method
     */
    hide(): void;
    onCloseClick(event: MouseEvent): void;
    onEscapeKeydown(): void;
    onWindowResize(): void;
    bindDocumentResizeListener(): void;
    unbindDocumentResizeListener(): void;
    bindScrollListener(): void;
    unbindScrollListener(): void;
    onContainerDestroy(): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Popover, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Popover, "p-popover", never, { "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "dismissable": { "alias": "dismissable"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "ariaCloseLabel": { "alias": "ariaCloseLabel"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "focusOnShow": { "alias": "focusOnShow"; "required": false; "isSignal": true; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; "isSignal": true; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; }, { "onShow": "onShow"; "onHide": "onHide"; }, ["contentTemplate", "templates"], ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class PopoverModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PopoverModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<PopoverModule, never, [typeof Popover, typeof i2.SharedModule], [typeof Popover, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<PopoverModule>;
}

export { Popover, PopoverModule, PopoverStyle };
