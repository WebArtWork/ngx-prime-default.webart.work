import { MegaMenuPassThrough, MegaMenuItemTemplateContext } from '@wawjs/ngx-prime/types/megamenu';
export * from '@wawjs/ngx-prime/types/megamenu';
import * as _angular_core from '@angular/core';
import { TemplateRef, ElementRef } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { MegaMenuItem, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { VoidListener } from '@wawjs/ngx-prime/ts-helpers';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class MegaMenuStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-megamenu-mobile': any;
            'p-megamenu-mobile-active': any;
            'p-megamenu-horizontal': boolean;
            'p-megamenu-vertical': boolean;
        })[];
        start: string;
        button: string;
        rootList: string;
        submenuLabel: ({ instance, processedItem }: {
            instance: any;
            processedItem: any;
        }) => (string | {
            'p-disabled': any;
        })[];
        item: ({ instance, processedItem }: {
            instance: any;
            processedItem: any;
        }) => any[];
        itemContent: string;
        itemLink: string;
        itemIcon: string;
        itemLabel: string;
        submenuIcon: string;
        overlay: string;
        grid: string;
        column: ({ instance, processedItem }: {
            instance: any;
            processedItem: any;
        }) => any;
        submenu: string;
        separator: string;
        end: string;
    };
    inlineStyles: {
        rootList: ({ instance }: {
            instance: any;
        }) => {
            'max-height': any;
            overflow: string;
        };
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MegaMenuStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<MegaMenuStyle>;
}
/**
 *
 * MegaMenu is navigation component that displays submenus together.
 *
 * [Live Demo](https://www.ngx-prime.org/megamenu/)
 *
 * @module megamenustyle
 *
 */
declare enum MegaMenuClasses {
    /**
     * Class name of the root element
     */
    root = "p-megamenu",
    /**
     * Class name of the start element
     */
    start = "p-megamenu-start",
    /**
     * Class name of the button element
     */
    button = "p-megamenu-button",
    /**
     * Class name of the root list element
     */
    rootList = "p-megamenu-root-list",
    /**
     * Class name of the submenu item element
     */
    submenuItem = "p-megamenu-submenu-item",
    /**
     * Class name of the item element
     */
    item = "p-megamenu-item",
    /**
     * Class name of the item content element
     */
    itemContent = "p-megamenu-item-content",
    /**
     * Class name of the item link element
     */
    itemLink = "p-megamenu-item-link",
    /**
     * Class name of the item icon element
     */
    itemIcon = "p-megamenu-item-icon",
    /**
     * Class name of the item label element
     */
    itemLabel = "p-megamenu-item-label",
    /**
     * Class name of the submenu icon element
     */
    submenuIcon = "p-megamenu-submenu-icon",
    /**
     * Class name of the panel element
     */
    panel = "p-megamenu-panel",
    /**
     * Class name of the grid element
     */
    grid = "p-megamenu-grid",
    /**
     * Class name of the submenu element
     */
    submenu = "p-megamenu-submenu",
    /**
     * Class name of the submenu item label element
     */
    submenuItemLabel = "p-megamenu-submenu-item-label",
    /**
     * Class name of the separator element
     */
    separator = "p-megamenu-separator",
    /**
     * Class name of the end element
     */
    end = "p-megamenu-end"
}

declare class MegaMenuSub extends BaseComponent<MegaMenuPassThrough> {
    bindDirectiveInstance: Bind;
    $pcMegaMenu: MegaMenu | undefined;
    $pcMegaMenuSub: MegaMenuSub | undefined;
    id: _angular_core.InputSignal<string | undefined>;
    items: _angular_core.InputSignal<any[] | undefined>;
    itemTemplate: _angular_core.InputSignal<TemplateRef<MegaMenuItemTemplateContext> | undefined>;
    menuId: _angular_core.InputSignal<string | undefined>;
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    level: _angular_core.InputSignalWithTransform<number, unknown>;
    focusedItemId: _angular_core.InputSignal<string | undefined>;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    orientation: _angular_core.InputSignal<string | undefined>;
    activeItem: _angular_core.InputSignal<any>;
    submenu: _angular_core.InputSignal<any>;
    queryMatches: _angular_core.InputSignalWithTransform<boolean, unknown>;
    mobileActive: _angular_core.InputSignalWithTransform<boolean, unknown>;
    scrollHeight: _angular_core.InputSignal<string | undefined>;
    tabindex: _angular_core.InputSignalWithTransform<number, unknown>;
    root: _angular_core.InputSignalWithTransform<boolean, unknown>;
    itemClick: _angular_core.OutputEmitterRef<any>;
    itemMouseEnter: _angular_core.OutputEmitterRef<any>;
    menuFocus: _angular_core.OutputEmitterRef<any>;
    menuBlur: _angular_core.OutputEmitterRef<any>;
    menuKeydown: _angular_core.OutputEmitterRef<any>;
    menuMouseDown: _angular_core.OutputEmitterRef<any>;
    megaMenu: MegaMenu;
    _componentStyle: MegaMenuStyle;
    onAfterViewChecked(): void;
    onItemClick(event: any, processedItem: any): void;
    getItemProp(processedItem: any, name: string, params?: any | null): any;
    getItemId(processedItem: any): string;
    getSubListId(processedItem: any): string;
    getItemLabel(processedItem: any): string;
    isSubmenuVisible(submenu: any): boolean;
    isItemVisible(processedItem: any): boolean;
    isItemActive(processedItem: any): boolean;
    isItemDisabled(processedItem: any): boolean;
    isItemFocused(processedItem: any): boolean;
    isItemGroup(processedItem: any): boolean;
    getAriaSetSize(): number | undefined;
    getAriaPosInset(index: number): number;
    onItemMouseEnter(param: any): void;
    getPTOptions(processedItem: any, index: number, key: string): any;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MegaMenuSub, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MegaMenuSub, "p-megaMenuSub, p-megamenu-sub, ul[pMegaMenuSub]", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": false; "isSignal": true; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; "isSignal": true; }; "menuId": { "alias": "menuId"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "level": { "alias": "level"; "required": false; "isSignal": true; }; "focusedItemId": { "alias": "focusedItemId"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "activeItem": { "alias": "activeItem"; "required": false; "isSignal": true; }; "submenu": { "alias": "submenu"; "required": false; "isSignal": true; }; "queryMatches": { "alias": "queryMatches"; "required": false; "isSignal": true; }; "mobileActive": { "alias": "mobileActive"; "required": false; "isSignal": true; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "root": { "alias": "root"; "required": false; "isSignal": true; }; }, { "itemClick": "itemClick"; "itemMouseEnter": "itemMouseEnter"; "menuFocus": "menuFocus"; "menuBlur": "menuBlur"; "menuKeydown": "menuKeydown"; "menuMouseDown": "menuMouseDown"; }, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
/**
 * MegaMenu is navigation component that displays submenus together.
 * @group Components
 */
declare class MegaMenu extends BaseComponent<MegaMenuPassThrough> {
    componentName: string;
    bindDirectiveInstance: Bind;
    /**
     * An array of menuitems.
     * @group Props
     */
    model: _angular_core.InputSignal<MegaMenuItem[] | undefined>;
    /**
     * Class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines the orientation.
     * @group Props
     */
    orientation: _angular_core.InputSignal<string>;
    /**
     * Current id state as a string.
     * @group Props
     */
    id: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string value that labels an interactive element.
     * @group Props
     */
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Identifier of the underlying input element.
     * @group Props
     */
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * The breakpoint to define the maximum width boundary.
     * @group Props
     */
    breakpoint: _angular_core.InputSignal<string>;
    /**
     * Height of the viewport, a scrollbar is defined if height of list exceeds this value.
     * @group Props
     */
    scrollHeight: _angular_core.InputSignal<string>;
    /**
     * When present, it specifies that the component should be disabled.
     * @group Props
     */
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Defines template option for start.
     * @group Templates
     */
    startTemplate: TemplateRef<void> | undefined;
    /**
     * Defines template option for end.
     * @group Templates
     */
    endTemplate: TemplateRef<void> | undefined;
    /**
     * Defines template option for menu icon.
     * @group Templates
     */
    readonly menuIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Defines template option for submenu icon.
     * @group Templates
     */
    readonly submenuIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom item template.
     * @param {MegaMenuItemTemplateContext} context - item context.
     * @see {@link MegaMenuItemTemplateContext}
     * @group Templates
     */
    readonly itemTemplate: _angular_core.Signal<TemplateRef<MegaMenuItemTemplateContext> | undefined>;
    /**
     * Custom menu button template on responsive mode.
     * @group Templates
     */
    readonly buttonTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom menu button icon template on responsive mode.
     * @group Templates
     */
    readonly buttonIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    readonly menubuttonViewChild: _angular_core.Signal<ElementRef<any> | undefined>;
    readonly rootmenu: _angular_core.Signal<MegaMenuSub | undefined>;
    _startTemplate: TemplateRef<void> | undefined;
    _endTemplate: TemplateRef<void> | undefined;
    _menuIconTemplate: TemplateRef<void> | undefined;
    _submenuIconTemplate: TemplateRef<void> | undefined;
    _itemTemplate: TemplateRef<MegaMenuItemTemplateContext> | undefined;
    _buttonTemplate: TemplateRef<void> | undefined;
    _buttonIconTemplate: TemplateRef<void> | undefined;
    outsideClickListener: VoidListener;
    resizeListener: (event: any) => void;
    dirty: boolean;
    focused: boolean;
    activeItem: _angular_core.WritableSignal<any>;
    focusedItemInfo: _angular_core.WritableSignal<any>;
    searchValue: string;
    searchTimeout: any;
    _processedItems: any[];
    _componentStyle: MegaMenuStyle;
    private matchMediaListener;
    private query;
    queryMatches: _angular_core.WritableSignal<boolean>;
    mobileActive: boolean;
    private _generatedId;
    get resolvedId(): string;
    get visibleItems(): any;
    get processedItems(): any[];
    get focusedItemId(): any;
    constructor();
    onInit(): void;
    onAfterViewChecked(): void;
    onAfterContentInit(): void;
    bindMatchMediaListener(): void;
    unbindMatchMediaListener(): void;
    createProcessedItems(items: any, level?: number, parent?: {}, parentKey?: string, columnIndex?: any): any[];
    getItemProp(item: any, name: string): any;
    onItemClick(event: any): void;
    onItemMouseEnter(event: any): void;
    menuButtonClick(event: any): void;
    menuButtonKeydown(event: any): void;
    toggle(event: MouseEvent): void;
    show(): void;
    scrollInView(index?: number): void;
    onItemChange(event: any): void;
    hide(event?: any, isFocus?: boolean): void;
    onMenuMouseDown(): void;
    onMenuFocus(event: any): void;
    onMenuBlur(event: any): void;
    onKeyDown(event: KeyboardEvent): void;
    findFirstFocusedItemIndex(): any;
    findFirstItemIndex(): any;
    findSelectedItemIndex(): any;
    isProcessedItemGroup(processedItem: any): boolean;
    isSelected(processedItem: any): boolean;
    isValidSelectedItem(processedItem: any): boolean;
    isValidItem(processedItem: any): boolean;
    isItemDisabled(item: any): boolean;
    isItemSeparator(item: any): boolean;
    isItemMatched(processedItem: any): boolean;
    isProccessedItemGroup(processedItem: any): boolean;
    searchItems(event: any, char: string): boolean;
    getProccessedItemLabel(processedItem: any): any;
    getItemLabel(item: any): any;
    changeFocusedItemInfo(event: any, index: any): void;
    onArrowDownKey(event: KeyboardEvent): void;
    onArrowRightKey(event: KeyboardEvent): void;
    onArrowUpKey(event: KeyboardEvent): void;
    onArrowLeftKey(event: KeyboardEvent): void;
    onHomeKey(event: KeyboardEvent): void;
    onEndKey(event: KeyboardEvent): void;
    onSpaceKey(event: KeyboardEvent): void;
    onEscapeKey(event: KeyboardEvent): void;
    onTabKey(event: KeyboardEvent): void;
    onEnterKey(event: KeyboardEvent): void;
    findVisibleItem(index: any): any;
    findLastFocusedItemIndex(): any;
    findLastItemIndex(): number;
    findPrevItemIndex(index: number): number;
    findNextItemIndex(index: number): any;
    bindResizeListener(): void;
    bindOutsideClickListener(): void;
    unbindOutsideClickListener(): void;
    unbindResizeListener(): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MegaMenu, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MegaMenu, "p-megaMenu, p-megamenu, p-mega-menu", never, { "model": { "alias": "model"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "breakpoint": { "alias": "breakpoint"; "required": false; "isSignal": true; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; }, {}, ["menuIconTemplate", "submenuIconTemplate", "itemTemplate", "buttonTemplate", "buttonIconTemplate", "templates", "startTemplate", "endTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class MegaMenuModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MegaMenuModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<MegaMenuModule, never, [typeof MegaMenu, typeof i2.SharedModule], [typeof MegaMenu, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<MegaMenuModule>;
}

export { MegaMenu, MegaMenuClasses, MegaMenuModule, MegaMenuStyle, MegaMenuSub };
