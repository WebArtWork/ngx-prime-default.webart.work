import { InplacePassThrough, InplaceContentTemplateContext } from '@wawjs/ngx-prime/types/inplace';
export * from '@wawjs/ngx-prime/types/inplace';
import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class InplaceStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: () => string[];
        display: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-disabled': any;
        })[];
        content: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InplaceStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<InplaceStyle>;
}
/**
 *
 * Inplace provides an easy to do editing and display at the same time where clicking the output displays the actual content.
 *
 * [Live Demo](https://www.ngx-prime.org/inplace)
 *
 * @module inplacestyle
 *
 */
declare enum InplaceClasses {
    /**
     * Class name of the root element
     */
    root = "p-inplace",
    /**
     * Class name of the display element
     */
    display = "p-inplace-display",
    /**
     * Class name of the content element
     */
    content = "p-inplace-content"
}

declare class InplaceDisplay extends BaseComponent {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InplaceDisplay, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<InplaceDisplay, "p-inplacedisplay, p-inplaceDisplay", never, {}, {}, never, ["*"], true, never>;
}
declare class InplaceContent extends BaseComponent {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InplaceContent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<InplaceContent, "p-inplacecontent, p-inplaceContent", never, {}, {}, never, ["*"], true, never>;
}
/**
 * Inplace provides an easy to do editing and display at the same time where clicking the output displays the actual content.
 * @group Components
 */
declare class Inplace extends BaseComponent<InplacePassThrough> {
    componentName: string;
    $pcInplace: Inplace | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Whether the content is displayed or not.
     * @group Props
     */
    active: _angular_core.ModelSignal<boolean>;
    /**
     * Displays a button to switch back to display mode.
     * @deprecated since v20.0.0, use `closeCallback` within content template.
     * @group Props
     */
    closable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When present, it specifies that the element should be disabled.
     * @group Props
     */
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Allows to prevent clicking.
     * @group Props
     */
    preventClick: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Icon to display in the close button.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    closeIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Establishes a string value that labels the close button.
     * @group Props
     */
    closeAriaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Callback to invoke when inplace is opened.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onActivate: _angular_core.OutputEmitterRef<Event | undefined>;
    /**
     * Callback to invoke when inplace is closed.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onDeactivate: _angular_core.OutputEmitterRef<Event | undefined>;
    hover: boolean;
    /**
     * Custom display template.
     * @group Templates
     */
    readonly displayTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom content template.
     * @group Templates
     */
    readonly contentTemplate: _angular_core.Signal<TemplateRef<InplaceContentTemplateContext> | undefined>;
    /**
     * Custom close icon template.
     * @group Templates
     */
    readonly closeIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    _componentStyle: InplaceStyle;
    onActivateClick(event: MouseEvent): void;
    onDeactivateClick(event: MouseEvent): void;
    /**
     * Activates the content.
     * @param {Event} event - Browser event.
     * @group Method
     */
    activate(event?: Event): void;
    /**
     * Deactivates the content.
     * @param {Event} event - Browser event.
     * @group Method
     */
    deactivate(event?: Event): void;
    onKeydown(event: KeyboardEvent): void;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _displayTemplate: TemplateRef<void> | undefined;
    _closeIconTemplate: TemplateRef<void> | undefined;
    _contentTemplate: TemplateRef<InplaceContentTemplateContext> | undefined;
    onAfterContentInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Inplace, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Inplace, "p-inplace", never, { "active": { "alias": "active"; "required": false; "isSignal": true; }; "closable": { "alias": "closable"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "preventClick": { "alias": "preventClick"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "closeIcon": { "alias": "closeIcon"; "required": false; "isSignal": true; }; "closeAriaLabel": { "alias": "closeAriaLabel"; "required": false; "isSignal": true; }; }, { "active": "activeChange"; "onActivate": "onActivate"; "onDeactivate": "onDeactivate"; }, ["displayTemplate", "contentTemplate", "closeIconTemplate", "templates"], ["[pInplaceDisplay]", "[pInplaceContent]"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class InplaceModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InplaceModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<InplaceModule, never, [typeof Inplace, typeof InplaceContent, typeof InplaceDisplay, typeof i2.SharedModule], [typeof Inplace, typeof InplaceContent, typeof InplaceDisplay, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<InplaceModule>;
}

export { Inplace, InplaceClasses, InplaceContent, InplaceDisplay, InplaceModule, InplaceStyle };
