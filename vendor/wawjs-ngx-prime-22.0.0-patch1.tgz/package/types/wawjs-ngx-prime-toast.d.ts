import { ToastPassThrough, ToastPositionType, ToastCloseEvent, ToastMessageTemplateContext, ToastHeadlessTemplateContext, ToastItemCloseEvent } from '@wawjs/ngx-prime/types/toast';
export * from '@wawjs/ngx-prime/types/toast';
import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';
import { MotionOptions, MotionEvent } from '@wawjs/css-prime-motion';
import * as i2 from '@wawjs/ngx-prime/api';
import { ToastMessageOptions, MessageService, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Subscription } from 'rxjs';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class ToastStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => string[];
        message: ({ instance }: {
            instance: any;
        }) => {
            'p-toast-message': boolean;
            'p-toast-message-info': boolean;
            'p-toast-message-warn': boolean;
            'p-toast-message-error': boolean;
            'p-toast-message-success': boolean;
            'p-toast-message-secondary': boolean;
            'p-toast-message-contrast': boolean;
        };
        messageContent: string;
        messageIcon: ({ instance }: {
            instance: any;
        }) => {
            [x: string]: boolean;
            'p-toast-message-icon': boolean;
        };
        messageText: string;
        summary: string;
        detail: string;
        closeButton: string;
        closeIcon: ({ instance }: {
            instance: any;
        }) => {
            [x: string]: boolean;
            'p-toast-close-icon': boolean;
        };
    };
    inlineStyles: {
        root: ({ instance }: {
            instance: any;
        }) => {
            position: string;
            top: string | null;
            right: string | false;
            bottom: string | false;
            left: string | null;
        };
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ToastStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ToastStyle>;
}
/**
 *
 * Toast is used to display messages in an overlay.
 *
 * [Live Demo](https://www.ngx-prime.org/toast/)
 *
 * @module toaststyle
 *
 */
declare enum ToastClasses {
    /**
     * Class name of the root element
     */
    root = "p-toast",
    /**
     * Class name of the message element
     */
    message = "p-toast-message",
    /**
     * Class name of the message content element
     */
    messageContent = "p-toast-message-content",
    /**
     * Class name of the message icon element
     */
    messageIcon = "p-toast-message-icon",
    /**
     * Class name of the message text element
     */
    messageText = "p-toast-message-text",
    /**
     * Class name of the summary element
     */
    summary = "p-toast-summary",
    /**
     * Class name of the detail element
     */
    detail = "p-toast-detail",
    /**
     * Class name of the close button element
     */
    closeButton = "p-toast-close-button",
    /**
     * Class name of the close icon element
     */
    closeIcon = "p-toast-close-icon"
}

declare class ToastItem extends BaseComponent<ToastPassThrough> {
    private zone;
    message: _angular_core.InputSignal<ToastMessageOptions | null | undefined>;
    index: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    life: _angular_core.InputSignal<number | undefined>;
    template: _angular_core.InputSignal<TemplateRef<ToastMessageTemplateContext> | undefined>;
    headlessTemplate: _angular_core.InputSignal<TemplateRef<ToastHeadlessTemplateContext> | undefined>;
    showTransformOptions: _angular_core.InputSignal<string | undefined>;
    hideTransformOptions: _angular_core.InputSignal<string | undefined>;
    showTransitionOptions: _angular_core.InputSignal<string | undefined>;
    hideTransitionOptions: _angular_core.InputSignal<string | undefined>;
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    clearAll: _angular_core.InputSignal<any>;
    onAnimationStart: _angular_core.OutputEmitterRef<HTMLElement>;
    onAnimationEnd: _angular_core.OutputEmitterRef<HTMLElement>;
    onBeforeEnter(event: MotionEvent): void;
    onAfterLeave(event: MotionEvent): void;
    onClose: _angular_core.OutputEmitterRef<ToastItemCloseEvent>;
    _componentStyle: ToastStyle;
    timeout: any;
    visible: _angular_core.WritableSignal<boolean | undefined>;
    private isDestroyed;
    private isClosing;
    constructor();
    onAfterViewInit(): void;
    initTimeout(): void;
    clearTimeout(): void;
    onMouseEnter(): void;
    onMouseLeave(): void;
    onCloseIconClick: (event: Event) => void;
    get closeAriaLabel(): string | undefined;
    onDestroy(): void;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ToastItem, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ToastItem, "p-toast-item", never, { "message": { "alias": "message"; "required": false; "isSignal": true; }; "index": { "alias": "index"; "required": false; "isSignal": true; }; "life": { "alias": "life"; "required": false; "isSignal": true; }; "template": { "alias": "template"; "required": false; "isSignal": true; }; "headlessTemplate": { "alias": "headlessTemplate"; "required": false; "isSignal": true; }; "showTransformOptions": { "alias": "showTransformOptions"; "required": false; "isSignal": true; }; "hideTransformOptions": { "alias": "hideTransformOptions"; "required": false; "isSignal": true; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; "isSignal": true; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; "clearAll": { "alias": "clearAll"; "required": false; "isSignal": true; }; }, { "onAnimationStart": "onAnimationStart"; "onAnimationEnd": "onAnimationEnd"; "onClose": "onClose"; }, never, never, true, never>;
}
/**
 * Toast is used to display messages in an overlay.
 * @group Components
 */
declare class Toast extends BaseComponent<ToastPassThrough> {
    componentName: string;
    $pcToast: Toast | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Key of the message in case message is targeted to a specific toast component.
     * @group Props
     */
    key: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to automatically manage layering.
     * @group Props
     */
    autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Base zIndex value to use in layering.
     * @group Props
     */
    baseZIndex: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * The default time to display messages for in milliseconds.
     * @group Props
     */
    life: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Inline class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Position of the toast in viewport.
     * @group Props
     */
    position: _angular_core.InputSignal<ToastPositionType>;
    /**
     * It does not add the new message if there is already a toast displayed with the same content
     * @group Props
     */
    preventOpenDuplicates: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Displays only once a message with the same content.
     * @group Props
     */
    preventDuplicates: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Transform options of the show animation.
     * @group Props
     * @deprecated since v21.0.0. Use `motionOptions` instead.
     */
    showTransformOptions: _angular_core.InputSignal<string>;
    /**
     * Transform options of the hide animation.
     * @group Props
     * @deprecated since v21.0.0. Use `motionOptions` instead.
     */
    hideTransformOptions: _angular_core.InputSignal<string>;
    /**
     * Transition options of the show animation.
     * @group Props
     * @deprecated since v21.0.0. Use `motionOptions` instead.
     */
    showTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * Transition options of the hide animation.
     * @group Props
     * @deprecated since v21.0.0. Use `motionOptions` instead.
     */
    hideTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * The motion options.
     * @group Props
     */
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    computedMotionOptions: _angular_core.Signal<MotionOptions>;
    /**
     * Object literal to define styles per screen size.
     * @group Props
     */
    breakpoints: _angular_core.InputSignal<{
        [key: string]: any;
    } | undefined>;
    /**
     * Callback to invoke when a message is closed.
     * @param {ToastCloseEvent} event - custom close event.
     * @group Emits
     */
    onClose: _angular_core.OutputEmitterRef<ToastCloseEvent>;
    /**
     * Custom message template.
     * @param {ToastMessageTemplateContext} context - message context.
     * @see {@link ToastMessageTemplateContext}
     * @group Templates
     */
    readonly template: _angular_core.Signal<TemplateRef<ToastMessageTemplateContext> | undefined>;
    /**
     * Custom headless template.
     * @param {ToastHeadlessTemplateContext} context - headless context.
     * @see {@link ToastHeadlessTemplateContext}
     * @group Templates
     */
    readonly headlessTemplate: _angular_core.Signal<TemplateRef<ToastHeadlessTemplateContext> | undefined>;
    messageSubscription: Subscription | undefined;
    clearSubscription: Subscription | undefined;
    messages: ToastMessageOptions[] | null | undefined;
    messagesArchieve: ToastMessageOptions[] | undefined;
    messageService: MessageService;
    _componentStyle: ToastStyle;
    styleElement: any;
    id: string;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    clearAllTrigger: _angular_core.WritableSignal<object | null>;
    constructor();
    onInit(): void;
    clearAll(): void;
    _template: TemplateRef<ToastMessageTemplateContext> | undefined;
    _headlessTemplate: TemplateRef<ToastHeadlessTemplateContext> | undefined;
    onAfterContentInit(): void;
    onAfterViewInit(): void;
    add(messages: ToastMessageOptions[]): void;
    canAdd(message: ToastMessageOptions): boolean;
    containsMessage(collection: ToastMessageOptions[], message: ToastMessageOptions): boolean;
    onMessageClose(event: ToastItemCloseEvent): void;
    onAnimationStart(): void;
    onAnimationEnd(): void;
    createStyle(): void;
    destroyStyle(): void;
    onDestroy(): void;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Toast, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Toast, "p-toast", never, { "key": { "alias": "key"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "life": { "alias": "life"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; "preventOpenDuplicates": { "alias": "preventOpenDuplicates"; "required": false; "isSignal": true; }; "preventDuplicates": { "alias": "preventDuplicates"; "required": false; "isSignal": true; }; "showTransformOptions": { "alias": "showTransformOptions"; "required": false; "isSignal": true; }; "hideTransformOptions": { "alias": "hideTransformOptions"; "required": false; "isSignal": true; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; "isSignal": true; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; "breakpoints": { "alias": "breakpoints"; "required": false; "isSignal": true; }; }, { "onClose": "onClose"; }, ["template", "headlessTemplate", "templates"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class ToastModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ToastModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<ToastModule, never, [typeof Toast, typeof i2.SharedModule], [typeof Toast, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<ToastModule>;
}

export { Toast, ToastClasses, ToastItem, ToastModule, ToastStyle };
