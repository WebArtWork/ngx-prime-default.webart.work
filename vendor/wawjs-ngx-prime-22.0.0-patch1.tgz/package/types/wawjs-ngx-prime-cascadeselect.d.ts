import * as _angular_core from '@angular/core';
import { ElementRef, TemplateRef } from '@angular/core';
import { MotionOptions } from '@wawjs/css-prime-motion';
import * as i2 from '@wawjs/ngx-prime/api';
import { OverlayService, OverlayOptions, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Fluid } from '@wawjs/ngx-prime/fluid';
import { Overlay } from '@wawjs/ngx-prime/overlay';
import { Nullable, VoidListener } from '@wawjs/ngx-prime/ts-helpers';
import { CascadeSelectPassThrough, CascadeSelectChangeEvent, CascadeSelectShowEvent, CascadeSelectValueTemplateContext, CascadeSelectOptionTemplateContext } from '@wawjs/ngx-prime/types/cascadeselect';
export * from '@wawjs/ngx-prime/types/cascadeselect';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class CascadeSelectStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-cascadeselect p-component p-inputwrapper': boolean;
            'p-cascadeselect-clearable': any;
            'p-cascadeselect-mobile': any;
            'p-disabled': any;
            'p-invalid': any;
            'p-focus': any;
            'p-inputwrapper-filled': any;
            'p-variant-filled': boolean;
            'p-inputwrapper-focus': any;
            'p-cascadeselect-open': any;
            'p-cascadeselect-fluid': any;
            'p-cascadeselect-sm p-inputfield-sm': boolean;
            'p-cascadeselect-lg p-inputfield-lg': boolean;
        })[];
        label: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-placeholder': boolean;
            'p-cascadeselect-label-empty': boolean;
        })[];
        clearIcon: string;
        dropdown: string;
        loadingIcon: string;
        dropdownIcon: string;
        overlay: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-cascadeselect-mobile-active': any;
        })[];
        listContainer: string;
        list: string;
        option: ({ instance, processedOption }: {
            instance: any;
            processedOption: any;
        }) => (string | {
            'p-cascadeselect-option-group': any;
            'p-cascadeselect-option-active': any;
            'p-cascadeselect-option-selected': any;
            'p-focus': any;
            'p-disabled': any;
        })[];
        optionContent: string;
        optionText: string;
        groupIcon: string;
        optionList: string;
    };
    inlineStyles: {
        root: ({ instance }: {
            instance: any;
        }) => {
            position: string | undefined;
        };
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CascadeSelectStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<CascadeSelectStyle>;
}
/**
 *
 * CascadeSelect is a form component to select a value from a nested structure of options.
 *
 * [Live Demo](https://www.ngx-prime.org/cascadeselect/)
 *
 * @module cascadeselectstyle
 *
 */
declare enum CascadeSelectClasses {
    /**
     * Class name of the root element
     */
    root = "p-cascadeselect",
    /**
     * Class name of the label element
     */
    label = "p-cascadeselect-label",
    /**
     * Class name of the dropdown element
     */
    dropdown = "p-cascadeselect-dropdown",
    /**
     * Class name of the loading icon element
     */
    loadingIcon = "p-cascadeselect-loading-icon",
    /**
     * Class name of the dropdown icon element
     */
    clearIcon = "p-cascadeselect-clear-icon",
    /**
     * Class name of the dropdown icon element
     */
    dropdownIcon = "p-cascadeselect-dropdown-icon",
    /**
     * Class name of the overlay element
     */
    overlay = "p-cascadeselect-overlay",
    /**
     * Class name of the list container element
     */
    listContainer = "p-cascadeselect-list-container",
    /**
     * Class name of the list element
     */
    list = "p-cascadeselect-list",
    /**
     * Class name of the item element
     */
    item = "p-cascadeselect-item",
    /**
     * Class name of the item content element
     */
    itemContent = "p-cascadeselect-item-content",
    /**
     * Class name of the item text element
     */
    itemText = "p-cascadeselect-item-text",
    /**
     * Class name of the group icon element
     */
    groupIcon = "p-cascadeselect-group-icon",
    /**
     * Class name of the item list element
     */
    itemList = "p-cascadeselect-item-list"
}

declare const CASCADESELECT_VALUE_ACCESSOR: any;
declare class CascadeSelectSub extends BaseComponent {
    cascadeselect: CascadeSelect;
    readonly selectId: _angular_core.InputSignal<string | undefined>;
    readonly activeOptionPath: _angular_core.InputSignal<any[]>;
    readonly optionDisabled: _angular_core.InputSignal<any[]>;
    readonly focusedOptionId: _angular_core.InputSignal<string | undefined>;
    readonly options: _angular_core.InputSignal<string | any[] | string[] | null | undefined>;
    readonly optionGroupChildren: _angular_core.InputSignal<string | string[] | null | undefined>;
    readonly optionTemplate: _angular_core.InputSignal<Nullable<TemplateRef<any>>>;
    readonly groupicon: _angular_core.InputSignal<Nullable<TemplateRef<any>>>;
    readonly level: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly optionLabel: _angular_core.InputSignal<string | undefined>;
    readonly optionValue: _angular_core.InputSignal<string | undefined>;
    readonly optionGroupLabel: _angular_core.InputSignal<string | undefined>;
    readonly dirty: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    readonly root: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    onChange: _angular_core.OutputEmitterRef<any>;
    onFocusChange: _angular_core.OutputEmitterRef<any>;
    onFocusEnterChange: _angular_core.OutputEmitterRef<any>;
    _componentStyle: CascadeSelectStyle;
    getPTOptions(processedOption: any, index: number, key: string): any;
    onInit(): void;
    onOptionClick(event: any, processedOption: any): void;
    onOptionMouseEnter(event: any, processedOption: any): void;
    onOptionMouseMove(event: any, processedOption: any): void;
    getOptionId(processedOption: any): string;
    getOptionLabel(processedOption: any): any;
    getOptionValue(processedOption: any): any;
    getOptionLabelToRender(processedOption: any): any;
    isOptionDisabled(processedOption: any): any;
    getOptionGroupLabel(processedOption: any): any;
    getOptionGroupChildren(processedOption: any): any;
    isOptionGroup(processedOption: any): boolean;
    isOptionSelected(processedOption: any): boolean;
    isOptionActive(processedOption: any): boolean;
    isOptionFocused(processedOption: any): boolean;
    position(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CascadeSelectSub, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CascadeSelectSub, "ul[pCascadeSelectSub]", never, { "selectId": { "alias": "selectId"; "required": false; "isSignal": true; }; "activeOptionPath": { "alias": "activeOptionPath"; "required": false; "isSignal": true; }; "optionDisabled": { "alias": "optionDisabled"; "required": false; "isSignal": true; }; "focusedOptionId": { "alias": "focusedOptionId"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "optionGroupChildren": { "alias": "optionGroupChildren"; "required": false; "isSignal": true; }; "optionTemplate": { "alias": "optionTemplate"; "required": false; "isSignal": true; }; "groupicon": { "alias": "groupicon"; "required": false; "isSignal": true; }; "level": { "alias": "level"; "required": false; "isSignal": true; }; "optionLabel": { "alias": "optionLabel"; "required": false; "isSignal": true; }; "optionValue": { "alias": "optionValue"; "required": false; "isSignal": true; }; "optionGroupLabel": { "alias": "optionGroupLabel"; "required": false; "isSignal": true; }; "dirty": { "alias": "dirty"; "required": false; "isSignal": true; }; "root": { "alias": "root"; "required": false; "isSignal": true; }; }, { "onChange": "onChange"; "onFocusChange": "onFocusChange"; "onFocusEnterChange": "onFocusEnterChange"; }, never, never, true, never>;
}
/**
 * CascadeSelect is a form component to select a value from a nested structure of options.
 * @group Components
 */
declare class CascadeSelect extends BaseEditableHolder<CascadeSelectPassThrough> {
    overlayService: OverlayService;
    componentName: string;
    $pcCascadeSelect: CascadeSelect | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Unique identifier of the component
     * @group Props
     */
    readonly id: _angular_core.InputSignal<string | undefined>;
    private _generatedId;
    get resolvedId(): string;
    /**
     * Text to display when the search is active. Defaults to global value in i18n translation configuration.
     * @group Props
     * @defaultValue '{0} results are available'
     */
    readonly searchMessage: _angular_core.InputSignal<string | undefined>;
    /**
     * Text to display when there is no data. Defaults to global value in i18n translation configuration.
     * @group Props
     */
    readonly emptyMessage: _angular_core.InputSignal<string | undefined>;
    /**
     * Text to be displayed in hidden accessible field when options are selected. Defaults to global value in i18n translation configuration.
     * @group Props
     * @defaultValue '{0} items selected'
     */
    readonly selectionMessage: _angular_core.InputSignal<string | undefined>;
    /**
     * Text to display when filtering does not return any results. Defaults to value from ngx-prime locale configuration.
     * @group Props
     * @defaultValue 'No available options'
     */
    readonly emptySearchMessage: _angular_core.InputSignal<string | undefined>;
    /**
     * Text to display when filtering does not return any results. Defaults to global value in i18n translation configuration.
     * @group Props
     * @defaultValue 'No selected item'
     */
    readonly emptySelectionMessage: _angular_core.InputSignal<string | undefined>;
    /**
     * Locale to use in searching. The default locale is the host environment's current locale.
     * @group Props
     */
    readonly searchLocale: _angular_core.InputSignal<string | undefined>;
    /**
     * Name of the disabled field of an option.
     * @group Props
     */
    readonly optionDisabled: _angular_core.InputSignal<any>;
    /**
     * Fields used when filtering the options, defaults to optionLabel.
     * @group Props
     */
    readonly focusOnHover: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Determines if the option will be selected on focus.
     * @group Props
     */
    readonly selectOnFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to focus on the first visible or selected element when the overlay panel is shown.
     * @group Props
     */
    readonly autoOptionFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    readonly styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * An array of selectitems to display as the available options.
     * @group Props
     */
    readonly options: _angular_core.InputSignal<string | string[] | undefined>;
    /**
     * Property name or getter function to use as the label of an option.
     * @group Props
     */
    readonly optionLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Property name or getter function to use as the value of an option, defaults to the option itself when not defined.
     * @group Props
     */
    readonly optionValue: _angular_core.InputSignal<string | undefined>;
    /**
     * Property name or getter function to use as the label of an option group.
     * @group Props
     */
    readonly optionGroupLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Property name or getter function to retrieve the items of a group.
     * @group Props
     */
    readonly optionGroupChildren: _angular_core.InputSignal<string | string[] | null | undefined>;
    /**
     * Default text to display when no option is selected.
     * @group Props
     */
    readonly placeholder: _angular_core.InputSignal<string | undefined>;
    /**
     * Selected value of the component.
     * @group Props
     */
    readonly value: _angular_core.InputSignal<string | null | undefined>;
    /**
     * A property to uniquely identify an option.
     * @group Props
     */
    readonly dataKey: _angular_core.InputSignal<string | undefined>;
    /**
     * Identifier of the underlying input element.
     * @group Props
     */
    readonly inputId: _angular_core.InputSignal<string | undefined>;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    readonly tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    readonly ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Label of the input for accessibility.
     * @group Props
     */
    readonly inputLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the input for accessibility.
     * @group Props
     */
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * When enabled, a clear icon is displayed to clear the value.
     * @group Props
     */
    readonly showClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Style class of the overlay panel.
     * @group Props
     */
    readonly panelStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the overlay panel.
     * @group Props
     */
    readonly panelStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Whether to use overlay API feature. The properties of overlay API can be used like an object in it.
     * @group Props
     */
    readonly overlayOptions: _angular_core.InputSignal<OverlayOptions | undefined>;
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Whether the dropdown is in loading state.
     * @group Props
     */
    readonly loading: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Icon to display in loading state.
     * @group Props
     */
    readonly loadingIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * The breakpoint to define the maximum width boundary.
     * @group Props
     */
    readonly breakpoint: _angular_core.InputSignal<string>;
    /**
     * Specifies the size of the component.
     * @defaultValue undefined
     * @group Props
     */
    size: _angular_core.InputSignal<"small" | "large" | undefined>;
    /**
     * Specifies the input variant of the component.
     * @defaultValue undefined
     * @group Props
     */
    variant: _angular_core.InputSignal<"filled" | "outlined" | undefined>;
    /**
     * Spans 100% width of the container when enabled.
     * @defaultValue undefined
     * @group Props
     */
    fluid: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'self'
     * @group Props
     */
    appendTo: _angular_core.InputSignal<any>;
    /**
     * The motion options.
     * @group Props
     */
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    /**
     * Callback to invoke on value change.
     * @param {CascadeSelectChangeEvent} event - Custom change event.
     * @group Emits
     */
    onChange: _angular_core.OutputEmitterRef<CascadeSelectChangeEvent>;
    /**
     * Callback to invoke when a group changes.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onGroupChange: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke when the overlay is shown.
     * @param {CascadeSelectShowEvent} event - Custom overlay show event.
     * @group Emits
     */
    onShow: _angular_core.OutputEmitterRef<CascadeSelectShowEvent>;
    /**
     * Callback to invoke when the overlay is hidden.
     * @param {CascadeSelectHideEvent} event - Custom overlay hide event.
     * @group Emits
     */
    onHide: _angular_core.OutputEmitterRef<CascadeSelectShowEvent>;
    /**
     * Callback to invoke when the clear token is clicked.
     * @group Emits
     */
    onClear: _angular_core.OutputEmitterRef<any>;
    /**
     * Callback to invoke before overlay is shown.
     * @param {CascadeSelectBeforeShowEvent} event - Custom overlay show event.
     * @group Emits
     */
    onBeforeShow: _angular_core.OutputEmitterRef<CascadeSelectShowEvent>;
    /**
     * Callback to invoke before overlay is hidden.
     * @param {CascadeSelectBeforeHideEvent} event - Custom overlay hide event.
     * @group Emits
     */
    onBeforeHide: _angular_core.OutputEmitterRef<CascadeSelectShowEvent>;
    /**
     * Callback to invoke when input receives focus.
     * @param {FocusEvent} event - Focus event.
     * @group Emits
     */
    onFocus: _angular_core.OutputEmitterRef<FocusEvent>;
    /**
     * Callback to invoke when input loses focus.
     * @param {FocusEvent} event - Focus event.
     * @group Emits
     */
    onBlur: _angular_core.OutputEmitterRef<FocusEvent>;
    readonly focusInputViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly panelViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly overlayViewChild: _angular_core.Signal<Nullable<Overlay>>;
    /**
     * Custom value template.
     * @group Templates
     */
    valueTemplate: Nullable<TemplateRef<CascadeSelectValueTemplateContext>>;
    /**
     * Custom option template.
     * @group Templates
     */
    readonly optionTemplate: _angular_core.Signal<Nullable<TemplateRef<CascadeSelectOptionTemplateContext<any>>>>;
    /**
     * Custom header template.
     * @group Templates
     */
    readonly headerTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom footer template.
     * @group Templates
     */
    readonly footerTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom trigger icon template.
     * @group Templates
     */
    triggerIconTemplate: Nullable<TemplateRef<void>>;
    /**
     * Custom loading icon template.
     * @group Templates
     */
    loadingIconTemplate: Nullable<TemplateRef<void>>;
    /**
     * Custom option group icon template.
     * @group Templates
     */
    readonly groupIconTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom clear icon template.
     * @group Templates
     */
    clearIconTemplate: Nullable<TemplateRef<void>>;
    _valueTemplate: TemplateRef<CascadeSelectValueTemplateContext> | undefined;
    _optionTemplate: TemplateRef<CascadeSelectOptionTemplateContext> | undefined;
    _headerTemplate: TemplateRef<void> | undefined;
    _footerTemplate: TemplateRef<void> | undefined;
    _triggerIconTemplate: TemplateRef<void> | undefined;
    _loadingIconTemplate: TemplateRef<void> | undefined;
    _groupIconTemplate: TemplateRef<void> | undefined;
    _clearIconTemplate: TemplateRef<void> | undefined;
    selectionPath: any;
    focused: boolean;
    overlayVisible: boolean;
    clicked: boolean;
    dirty: boolean;
    searchValue: string | undefined;
    searchTimeout: any;
    focusedOptionInfo: _angular_core.WritableSignal<any>;
    activeOptionPath: _angular_core.WritableSignal<any>;
    processedOptions: string[] | string | undefined;
    _componentStyle: CascadeSelectStyle;
    initialized: boolean;
    $variant: _angular_core.Signal<"filled" | "outlined" | null>;
    $appendTo: _angular_core.Signal<any>;
    pcFluid: Fluid | null;
    get hasFluid(): boolean;
    onHostClick(event: MouseEvent): void;
    get listLabel(): string;
    get focusedOptionId(): string | null;
    get searchResultMessageText(): string;
    get searchMessageText(): string;
    get emptySearchMessageText(): string;
    get emptyMessageText(): string;
    get selectionMessageText(): string;
    get emptySelectionMessageText(): string;
    get selectedMessageText(): string;
    visibleOptions: _angular_core.Signal<any>;
    label: _angular_core.Signal<any>;
    get _label(): any;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    onAfterContentInit(): void;
    hasSelectedOption(): boolean;
    createProcessedOptions(options: any, level?: number, parent?: {}, parentKey?: string): any[];
    onInputFocus(event: FocusEvent): void;
    onInputBlur(event: FocusEvent): void;
    onInputKeyDown(event: KeyboardEvent): void;
    onArrowDownKey(event: any): void;
    onArrowUpKey(event: any): void;
    onArrowLeftKey(event: any): void;
    onArrowRightKey(event: any): void;
    onHomeKey(event: any): void;
    onEndKey(event: any): void;
    onEnterKey(event: any): void;
    onSpaceKey(event: any): void;
    onEscapeKey(event: any): void;
    onTabKey(event: any): void;
    onBackspaceKey(event: any): void;
    equalityKey(): string | undefined;
    updateModel(value: any, event?: any): void;
    autoUpdateModel(): void;
    scrollInView(index?: number): void;
    changeFocusedOptionIndex(event: any, index: any, preventSelection?: boolean): void;
    matchMediaListener: VoidListener;
    onOptionSelect(event: any): void;
    onOptionGroupSelect(event: any): void;
    onContainerClick(event: MouseEvent): void;
    isOptionMatched(processedOption: any): any;
    isOptionDisabled(option: any): any;
    isValidOption(processedOption: any): boolean;
    isValidSelectedOption(processedOption: any): any;
    isSelected(processedOption: any): any;
    findOptionPathByValue(value: any, processedOptions?: any, level?: number): any;
    findFirstOptionIndex(): any;
    findLastOptionIndex(): number;
    findNextOptionIndex(index: any): any;
    findPrevOptionIndex(index: any): any;
    findSelectedOptionIndex(): any;
    findFirstFocusedOptionIndex(): any;
    findLastFocusedOptionIndex(): any;
    searchOptions(event: any, char: any): boolean;
    hide(event?: any, isFocus?: boolean): void;
    show(event?: any, isFocus?: boolean): void;
    clear(event?: MouseEvent): void;
    getOptionLabel(option: any): any;
    getOptionValue(option: any): any;
    getOptionGroupLabel(optionGroup: any): any;
    getOptionGroupChildren(optionGroup: any, level: any): any;
    isOptionGroup(option: any, level: any): any;
    isProccessedOptionGroup(processedOption: any): boolean;
    getProccessedOptionLabel(processedOption: any): any;
    constructor();
    query: any;
    queryMatches: _angular_core.WritableSignal<boolean>;
    mobileActive: _angular_core.WritableSignal<boolean>;
    onOptionChange(event: any): void;
    onOptionClick(event: any): void;
    onOptionMouseEnter(event: any): void;
    onOptionMouseMove(event: any): void;
    onInit(): void;
    onAfterViewInit(): void;
    bindMatchMediaListener(): void;
    unbindMatchMediaListener(): void;
    onOverlayAfterLeave(): void;
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value: any, setModelValue: (value: any) => void): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CascadeSelect, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CascadeSelect, "p-cascadeSelect, p-cascadeselect, p-cascade-select", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "searchMessage": { "alias": "searchMessage"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "selectionMessage": { "alias": "selectionMessage"; "required": false; "isSignal": true; }; "emptySearchMessage": { "alias": "emptySearchMessage"; "required": false; "isSignal": true; }; "emptySelectionMessage": { "alias": "emptySelectionMessage"; "required": false; "isSignal": true; }; "searchLocale": { "alias": "searchLocale"; "required": false; "isSignal": true; }; "optionDisabled": { "alias": "optionDisabled"; "required": false; "isSignal": true; }; "focusOnHover": { "alias": "focusOnHover"; "required": false; "isSignal": true; }; "selectOnFocus": { "alias": "selectOnFocus"; "required": false; "isSignal": true; }; "autoOptionFocus": { "alias": "autoOptionFocus"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "optionLabel": { "alias": "optionLabel"; "required": false; "isSignal": true; }; "optionValue": { "alias": "optionValue"; "required": false; "isSignal": true; }; "optionGroupLabel": { "alias": "optionGroupLabel"; "required": false; "isSignal": true; }; "optionGroupChildren": { "alias": "optionGroupChildren"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "inputLabel": { "alias": "inputLabel"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "showClear": { "alias": "showClear"; "required": false; "isSignal": true; }; "panelStyleClass": { "alias": "panelStyleClass"; "required": false; "isSignal": true; }; "panelStyle": { "alias": "panelStyle"; "required": false; "isSignal": true; }; "overlayOptions": { "alias": "overlayOptions"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "loadingIcon": { "alias": "loadingIcon"; "required": false; "isSignal": true; }; "breakpoint": { "alias": "breakpoint"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; }, { "onChange": "onChange"; "onGroupChange": "onGroupChange"; "onShow": "onShow"; "onHide": "onHide"; "onClear": "onClear"; "onBeforeShow": "onBeforeShow"; "onBeforeHide": "onBeforeHide"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, ["optionTemplate", "headerTemplate", "footerTemplate", "groupIconTemplate", "templates", "valueTemplate", "triggerIconTemplate", "loadingIconTemplate", "clearIconTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class CascadeSelectModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CascadeSelectModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<CascadeSelectModule, never, [typeof CascadeSelect, typeof i2.SharedModule], [typeof CascadeSelect, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<CascadeSelectModule>;
}

export { CASCADESELECT_VALUE_ACCESSOR, CascadeSelect, CascadeSelectClasses, CascadeSelectModule, CascadeSelectStyle, CascadeSelectSub };
