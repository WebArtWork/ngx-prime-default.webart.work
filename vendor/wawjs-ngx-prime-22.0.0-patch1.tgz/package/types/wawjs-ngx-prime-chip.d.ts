import { ChipPassThrough, ChipProps } from '@wawjs/ngx-prime/types/chip';
export * from '@wawjs/ngx-prime/types/chip';
import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class ChipStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-disabled': any;
        })[];
        image: string;
        icon: string;
        label: string;
        removeIcon: string;
    };
    inlineStyles: {
        root: ({ instance }: {
            instance: any;
        }) => {
            display: string | false;
        };
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChipStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ChipStyle>;
}
/**
 *
 * Chip represents people using icons, labels and images.
 *
 * [Live Demo](https://www.ngx-prime.org/chip)
 *
 * @module chipstyle
 *
 */
declare enum ChipClasses {
    /**
     * Class name of the root element
     */
    root = "p-chip",
    /**
     * Class name of the image element
     */
    image = "p-chip-image",
    /**
     * Class name of the icon element
     */
    icon = "p-chip-icon",
    /**
     * Class name of the label element
     */
    label = "p-chip-label",
    /**
     * Class name of the remove icon element
     */
    removeIcon = "p-chip-remove-icon"
}

/**
 * Chip represents people using icons, labels and images.
 * @group Components
 */
declare class Chip extends BaseComponent<ChipPassThrough> {
    componentName: string;
    $pcChip: Chip | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Defines the text to display.
     * @group Props
     */
    label: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines the icon to display.
     * @group Props
     */
    icon: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines the image to display.
     * @group Props
     */
    image: _angular_core.InputSignal<string | undefined>;
    /**
     * Alt attribute of the image.
     * @group Props
     */
    alt: _angular_core.InputSignal<string | undefined>;
    /**
     * Class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * When present, it specifies that the element should be disabled.
     * @group Props
     */
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to display a remove icon.
     * @group Props
     */
    removable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Icon of the remove element.
     * @group Props
     */
    removeIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Callback to invoke when a chip is removed.
     * @param {MouseEvent} event - Mouse event.
     * @group Emits
     */
    onRemove: _angular_core.OutputEmitterRef<MouseEvent>;
    /**
     * This event is triggered if an error occurs while loading an image file.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onImageError: _angular_core.OutputEmitterRef<Event>;
    visible: boolean;
    get removeAriaLabel(): any;
    /**
     * Used to pass all properties of the chipProps to the Chip component.
     * @group Props
     */
    chipProps: _angular_core.InputSignal<ChipProps | undefined>;
    readonly resolvedLabel: _angular_core.Signal<string | undefined>;
    readonly resolvedIcon: _angular_core.Signal<string | undefined>;
    readonly resolvedImage: _angular_core.Signal<string | undefined>;
    readonly resolvedAlt: _angular_core.Signal<string | undefined>;
    readonly resolvedStyleClass: _angular_core.Signal<string | undefined>;
    readonly resolvedRemovable: _angular_core.Signal<boolean>;
    readonly resolvedRemoveIcon: _angular_core.Signal<string | undefined>;
    _componentStyle: ChipStyle;
    /**
     * Custom remove icon template.
     * @group Templates
     */
    removeIconTemplate: TemplateRef<void> | undefined;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _removeIconTemplate: TemplateRef<void> | undefined;
    onAfterContentInit(): void;
    close(event: MouseEvent): void;
    onKeydown(event: any): void;
    imageError(event: Event): void;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Chip, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Chip, "p-chip", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "image": { "alias": "image"; "required": false; "isSignal": true; }; "alt": { "alias": "alt"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "removable": { "alias": "removable"; "required": false; "isSignal": true; }; "removeIcon": { "alias": "removeIcon"; "required": false; "isSignal": true; }; "chipProps": { "alias": "chipProps"; "required": false; "isSignal": true; }; }, { "onRemove": "onRemove"; "onImageError": "onImageError"; }, ["templates", "removeIconTemplate"], ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class ChipModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChipModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<ChipModule, never, [typeof Chip, typeof i2.SharedModule], [typeof Chip, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<ChipModule>;
}

export { Chip, ChipClasses, ChipModule, ChipStyle };
