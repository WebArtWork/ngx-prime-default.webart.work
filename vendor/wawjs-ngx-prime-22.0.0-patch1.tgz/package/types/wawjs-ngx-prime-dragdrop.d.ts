import * as _angular_core from '@angular/core';
import { AfterViewInit, OnDestroy, ElementRef, NgZone } from '@angular/core';
import { VoidListener } from '@wawjs/ngx-prime/ts-helpers';

/**
 * pDraggable directive apply draggable behavior to any element.
 * @group Components
 */
declare class Draggable implements AfterViewInit, OnDestroy {
    el: ElementRef<any>;
    zone: NgZone;
    private renderer;
    scope: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines the cursor style.
     * @group Props
     */
    dragEffect: _angular_core.InputSignal<"none" | "copy" | "copyLink" | "copyMove" | "link" | "linkMove" | "move" | "all" | "uninitialized" | undefined>;
    /**
     * Selector to define the drag handle, by default anywhere on the target element is a drag handle to start dragging.
     * @group Props
     */
    dragHandle: _angular_core.InputSignal<string | undefined>;
    /**
     * Callback to invoke when drag begins.
     * @param {DragEvent} event - Drag event.
     * @group Emits
     */
    onDragStart: _angular_core.OutputEmitterRef<DragEvent>;
    /**
     * Callback to invoke when drag ends.
     * @param {DragEvent} event - Drag event.
     * @group Emits
     */
    onDragEnd: _angular_core.OutputEmitterRef<DragEvent>;
    /**
     * Callback to invoke on dragging.
     * @param {DragEvent} event - Drag event.
     * @group Emits
     */
    onDrag: _angular_core.OutputEmitterRef<DragEvent>;
    handle: any;
    dragListener: VoidListener;
    mouseDownListener: VoidListener;
    mouseUpListener: VoidListener;
    pDraggableDisabled: _angular_core.InputSignal<boolean>;
    constructor();
    ngAfterViewInit(): void;
    bindDragListener(): void;
    unbindDragListener(): void;
    bindMouseListeners(): void;
    unbindMouseListeners(): void;
    drag(event: DragEvent): void;
    dragStart(event: DragEvent): void;
    dragEnd(event: DragEvent): void;
    mousedown(event: MouseEvent): void;
    mouseup(): void;
    allowDrag(): boolean;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Draggable, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<Draggable, "[pDraggable]", never, { "scope": { "alias": "pDraggable"; "required": false; "isSignal": true; }; "dragEffect": { "alias": "dragEffect"; "required": false; "isSignal": true; }; "dragHandle": { "alias": "dragHandle"; "required": false; "isSignal": true; }; "pDraggableDisabled": { "alias": "pDraggableDisabled"; "required": false; "isSignal": true; }; }, { "onDragStart": "onDragStart"; "onDragEnd": "onDragEnd"; "onDrag": "onDrag"; }, never, never, true, never>;
}
/**
 * pDroppable directive apply droppable behavior to any element.
 * @group Components
 */
declare class Droppable implements AfterViewInit, OnDestroy {
    el: ElementRef<any>;
    zone: NgZone;
    private renderer;
    scope: _angular_core.InputSignal<string | string[] | undefined>;
    /**
     * Whether the element is droppable, useful for conditional cases.
     * @group Props
     */
    pDroppableDisabled: _angular_core.InputSignal<boolean>;
    /**
     * Defines the cursor style, valid values are none, copy, move, link, copyMove, copyLink, linkMove and all.
     * @group Props
     */
    dropEffect: _angular_core.InputSignal<"none" | "copy" | "link" | "move" | undefined>;
    /**
     * Callback to invoke when a draggable enters drop area.
     * @group Emits
     */
    onDragEnter: _angular_core.OutputEmitterRef<DragEvent>;
    /**
     * Callback to invoke when a draggable leave drop area.
     * @group Emits
     */
    onDragLeave: _angular_core.OutputEmitterRef<DragEvent>;
    /**
     * Callback to invoke when a draggable is dropped onto drop area.
     * @group Emits
     */
    onDrop: _angular_core.OutputEmitterRef<DragEvent>;
    dragOverListener: VoidListener;
    constructor();
    ngAfterViewInit(): void;
    bindDragOverListener(): void;
    unbindDragOverListener(): void;
    dragOver(event: DragEvent): void;
    drop(event: DragEvent): void;
    dragEnter(event: DragEvent): void;
    dragLeave(event: DragEvent): void;
    allowDrop(event: DragEvent): boolean;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Droppable, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<Droppable, "[pDroppable]", never, { "scope": { "alias": "pDroppable"; "required": false; "isSignal": true; }; "pDroppableDisabled": { "alias": "pDroppableDisabled"; "required": false; "isSignal": true; }; "dropEffect": { "alias": "dropEffect"; "required": false; "isSignal": true; }; }, { "onDragEnter": "onDragEnter"; "onDragLeave": "onDragLeave"; "onDrop": "onDrop"; }, never, never, true, never>;
}
declare class DragDropModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DragDropModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<DragDropModule, never, [typeof Draggable, typeof Droppable], [typeof Draggable, typeof Droppable]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<DragDropModule>;
}

export { DragDropModule, Draggable, Droppable };
