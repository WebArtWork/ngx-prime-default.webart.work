import { BaseIcon } from '@wawjs/ngx-prime/icons/baseicon';
import * as i0 from '@angular/core';

declare class ThLargeIcon extends BaseIcon {
    pathId: string;
    onInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ThLargeIcon, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ThLargeIcon, "[data-p-icon=\"th-large\"]", never, {}, {}, never, never, true, never>;
}

export { ThLargeIcon };
