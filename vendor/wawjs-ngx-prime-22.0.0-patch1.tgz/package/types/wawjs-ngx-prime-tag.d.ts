import { TagPassThrough } from '@wawjs/ngx-prime/types/tag';
export * from '@wawjs/ngx-prime/types/tag';
import * as i0 from '@angular/core';
import { AfterContentInit, TemplateRef } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class TagStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-tag-info': boolean;
            'p-tag-success': boolean;
            'p-tag-warn': boolean;
            'p-tag-danger': boolean;
            'p-tag-secondary': boolean;
            'p-tag-contrast': boolean;
            'p-tag-rounded': any;
        })[];
        icon: string;
        label: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<TagStyle, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TagStyle>;
}
/**
 *
 * Tag component is used to categorize content.
 *
 * [Live Demo](https://www.ngx-prime.org/tag)
 *
 * @module tagstyle
 *
 */
declare enum TagClasses {
    /**
     * Class name of the root element
     */
    root = "p-tag",
    /**
     * Class name of the icon element
     */
    icon = "p-tag-icon",
    /**
     * Class name of the label element
     */
    label = "p-tag-label"
}

/**
 * Tag component is used to categorize content.
 * @group Components
 */
declare class Tag extends BaseComponent<TagPassThrough> implements AfterContentInit {
    componentName: string;
    $pcTag: Tag | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: i0.InputSignal<string | undefined>;
    /**
     * Severity type of the tag.
     * @group Props
     */
    severity: i0.InputSignal<"info" | "success" | "warn" | "danger" | "secondary" | "contrast" | null | undefined>;
    /**
     * Value to display inside the tag.
     * @group Props
     */
    value: i0.InputSignal<string | undefined>;
    /**
     * Icon of the tag to display next to the value.
     * @group Props
     */
    icon: i0.InputSignal<string | undefined>;
    /**
     * Whether the corners of the tag are rounded.
     * @group Props
     */
    rounded: i0.InputSignalWithTransform<boolean, unknown>;
    /**
     * Custom icon template.
     * @group Templates
     */
    iconTemplate: TemplateRef<void> | undefined;
    readonly templates: i0.Signal<readonly PrimeTemplate[]>;
    _iconTemplate: TemplateRef<void> | undefined;
    _componentStyle: TagStyle;
    onAfterContentInit(): void;
    get dataP(): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<Tag, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Tag, "p-tag", never, { "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "severity": { "alias": "severity"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "rounded": { "alias": "rounded"; "required": false; "isSignal": true; }; }, {}, ["templates", "iconTemplate"], ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class TagModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TagModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TagModule, never, [typeof Tag, typeof i2.SharedModule], [typeof Tag, typeof i2.SharedModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TagModule>;
}

export { Tag, TagClasses, TagModule, TagStyle };
