import { BaseIcon } from '@wawjs/ngx-prime/icons/baseicon';
import * as i0 from '@angular/core';

declare class MinusIcon extends BaseIcon {
    static ɵfac: i0.ɵɵFactoryDeclaration<MinusIcon, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MinusIcon, "[data-p-icon=\"minus\"]", never, {}, {}, never, never, true, never>;
}

export { MinusIcon };
