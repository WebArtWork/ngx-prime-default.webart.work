import { ToggleButtonPassThrough, ToggleButtonChangeEvent, ToggleButtonIconTemplateContext, ToggleButtonContentTemplateContext } from '@wawjs/ngx-prime/types/togglebutton';
export * from '@wawjs/ngx-prime/types/togglebutton';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';
import * as i4 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import * as i1$1 from '@wawjs/ngx-prime/ripple';

declare class ToggleButtonStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-togglebutton-checked': any;
            'p-invalid': any;
            'p-disabled': any;
            'p-togglebutton-sm p-inputfield-sm': boolean;
            'p-togglebutton-lg p-inputfield-lg': boolean;
            'p-togglebutton-fluid': any;
        })[];
        content: string;
        icon: string;
        iconLeft: string;
        iconRight: string;
        label: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ToggleButtonStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ToggleButtonStyle>;
}
/**
 *
 * ToggleButton is used to select a boolean value using a button.
 *
 * [Live Demo](https://www.ngx-prime.org/togglebutton/)
 *
 * @module togglebuttonstyle
 *
 */
declare enum ToggleButtonClasses {
    /**
     * Class name of the root element
     */
    root = "p-togglebutton",
    /**
     * Class name of the icon element
     */
    icon = "p-togglebutton-icon",
    /**
     * Class name of the left icon
     */
    iconLeft = "p-togglebutton-icon-left",
    /**
     * Class name of the right icon
     */
    iconRight = "p-togglebutton-icon-right",
    /**
     * Class name of the label element
     */
    label = "p-togglebutton-label"
}

/** Adds toggle semantics to a native button. */
declare class ToggleButtonDirective extends BaseEditableHolder<ToggleButtonPassThrough> {
    componentName: string;
    _componentStyle: ToggleButtonStyle;
    private readonly element;
    private readonly bindDirectiveInstance;
    /** Signal Forms checkbox contract; binds publicly as `[(pressed)]`. */
    checked: _angular_core.ModelSignal<boolean>;
    allowEmpty: _angular_core.InputSignalWithTransform<boolean, unknown>;
    type: _angular_core.InputSignal<"button" | "submit" | "reset">;
    tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    size: _angular_core.InputSignal<"small" | "large" | undefined>;
    fluid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    inputId: _angular_core.InputSignal<string | undefined>;
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    ariaDescribedBy: _angular_core.InputSignal<string | undefined>;
    onChange: _angular_core.OutputEmitterRef<ToggleButtonChangeEvent>;
    onFocus: _angular_core.OutputEmitterRef<Event>;
    onBlur: _angular_core.OutputEmitterRef<Event>;
    touch: _angular_core.OutputEmitterRef<void>;
    onAfterViewChecked(): void;
    toggle(event: MouseEvent): void;
    handleBlur(event: Event): void;
    focus(options?: FocusOptions): void;
    writeControlValue(value: unknown, setModelValue: (value: unknown) => void): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ToggleButtonDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ToggleButtonDirective, "button[pToggleButton]", never, { "checked": { "alias": "pressed"; "required": false; "isSignal": true; }; "allowEmpty": { "alias": "allowEmpty"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "ariaDescribedBy": { "alias": "ariaDescribedBy"; "required": false; "isSignal": true; }; }, { "checked": "pressedChange"; "onChange": "onChange"; "onFocus": "onFocus"; "onBlur": "onBlur"; "touch": "touch"; }, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}

declare const TOGGLEBUTTON_VALUE_ACCESSOR: any;
/**
 * Legacy ToggleButton component.
 * @deprecated since v22, use `<button pToggleButton>` for native toggle buttons. The legacy component selectors will be removed in v23.
 * @group Components
 */
declare class ToggleButton extends BaseEditableHolder<ToggleButtonPassThrough> {
    componentName: string;
    readonly nbsp: string;
    $pcToggleButton: ToggleButton | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    onKeyDown(event: KeyboardEvent): void;
    toggle(event: Event): void;
    /**
     * Label for the on state.
     * @group Props
     */
    onLabel: _angular_core.InputSignal<string>;
    /**
     * Label for the off state.
     * @group Props
     */
    offLabel: _angular_core.InputSignal<string>;
    /**
     * Icon for the on state.
     * @group Props
     */
    onIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Icon for the off state.
     * @group Props
     */
    offIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the input for accessibility.
     * @group Props
     */
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Identifier of the focus input to match a label defined for the component.
     * @group Props
     */
    inputId: _angular_core.InputSignal<string | undefined>;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Position of the icon.
     * @group Props
     */
    iconPos: _angular_core.InputSignal<"left" | "right">;
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Defines the size of the component.
     * @group Props
     */
    size: _angular_core.InputSignal<"small" | "large" | undefined>;
    /**
     * Whether selection can not be cleared.
     * @group Props
     */
    allowEmpty: _angular_core.InputSignal<boolean | undefined>;
    /**
     * Spans 100% width of the container when enabled.
     * @defaultValue undefined
     * @group Props
     */
    fluid: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Callback to invoke on value change.
     * @param {ToggleButtonChangeEvent} event - Custom change event.
     * @group Emits
     */
    onChange: _angular_core.OutputEmitterRef<ToggleButtonChangeEvent>;
    /**
     * Custom icon template.
     * @param {ToggleButtonIconTemplateContext} context - icon context.
     * @see {@link ToggleButtonIconTemplateContext}
     * @group Templates
     */
    readonly iconTemplate: _angular_core.Signal<Nullable<TemplateRef<ToggleButtonIconTemplateContext>>>;
    /**
     * Custom content template.
     * @param {ToggleButtonContentTemplateContext} context - content context.
     * @see {@link ToggleButtonContentTemplateContext}
     * @group Templates
     */
    readonly contentTemplate: _angular_core.Signal<Nullable<TemplateRef<ToggleButtonContentTemplateContext>>>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    checked: boolean;
    onInit(): void;
    _componentStyle: ToggleButtonStyle;
    onBlur(): void;
    get hasOnLabel(): boolean;
    get hasOffLabel(): boolean;
    get active(): boolean;
    _iconTemplate: TemplateRef<ToggleButtonIconTemplateContext> | undefined;
    _contentTemplate: TemplateRef<ToggleButtonContentTemplateContext> | undefined;
    onAfterContentInit(): void;
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value: any, setModelValue: (value: any) => void): void;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ToggleButton, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ToggleButton, "p-toggleButton, p-togglebutton, p-toggle-button", never, { "onLabel": { "alias": "onLabel"; "required": false; "isSignal": true; }; "offLabel": { "alias": "offLabel"; "required": false; "isSignal": true; }; "onIcon": { "alias": "onIcon"; "required": false; "isSignal": true; }; "offIcon": { "alias": "offIcon"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "iconPos": { "alias": "iconPos"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "allowEmpty": { "alias": "allowEmpty"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; }, { "onChange": "onChange"; }, ["iconTemplate", "contentTemplate", "templates"], never, true, [{ directive: typeof i1$1.Ripple; inputs: {}; outputs: {}; }, { directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class ToggleButtonModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ToggleButtonModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<ToggleButtonModule, never, [typeof ToggleButton, typeof ToggleButtonDirective, typeof i4.SharedModule], [typeof ToggleButton, typeof ToggleButtonDirective, typeof i4.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<ToggleButtonModule>;
}

export { TOGGLEBUTTON_VALUE_ACCESSOR, ToggleButton, ToggleButtonClasses, ToggleButtonDirective, ToggleButtonModule, ToggleButtonStyle };
