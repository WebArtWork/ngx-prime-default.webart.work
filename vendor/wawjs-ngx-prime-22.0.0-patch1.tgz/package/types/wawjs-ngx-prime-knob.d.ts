import * as _angular_core from '@angular/core';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { VoidListener } from '@wawjs/ngx-prime/ts-helpers';
import { KnobPassThrough } from '@wawjs/ngx-prime/types/knob';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i2 from '@wawjs/ngx-prime/api';

declare class KnobStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-disabled': any;
        })[];
        range: string;
        value: string;
        text: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<KnobStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<KnobStyle>;
}
/**
 *
 * Knob is a form component to define number inputs with a dial.
 *
 * [Live Demo](https://www.ngx-prime.org/knob/)
 *
 * @module knobstyle
 *
 */
declare enum KnobClasses {
    /**
     * Class name of the root element
     */
    root = "p-knob",
    /**
     * Class name of the range element
     */
    range = "p-knob-range",
    /**
     * Class name of the value element
     */
    value = "p-knob-value",
    /**
     * Class name of the text element
     */
    text = "p-knob-text"
}

declare const KNOB_VALUE_ACCESSOR: any;
/**
 * Knob is a form component to define number inputs with a dial.
 * @group Components
 */
declare class Knob extends BaseEditableHolder<KnobPassThrough> {
    componentName: string;
    $pcKnob: Knob | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the input for accessibility.
     * @group Props
     */
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Specifies one or more IDs in the DOM that labels the input field.
     * @group Props
     */
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Background of the value.
     * @group Props
     */
    valueColor: _angular_core.InputSignal<string>;
    /**
     * Background color of the range.
     * @group Props
     */
    rangeColor: _angular_core.InputSignal<string>;
    /**
     * Color of the value text.
     * @group Props
     */
    textColor: _angular_core.InputSignal<string>;
    /**
     * Template string of the value.
     * @group Props
     */
    valueTemplate: _angular_core.InputSignal<string>;
    /**
     * Size of the component in pixels.
     * @group Props
     */
    size: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Mininum boundary value.
     * @group Props
     */
    min: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Maximum boundary value.
     * @group Props
     */
    max: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Step factor to increment/decrement the value.
     * @group Props
     */
    step: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Width of the knob stroke.
     * @group Props
     */
    strokeWidth: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Whether the show the value inside the knob.
     * @group Props
     */
    showValue: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When present, it specifies that the component value cannot be edited.
     * @group Props
     */
    readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Callback to invoke on value change.
     * @param {number} value - New value.
     * @group Emits
     */
    onChange: _angular_core.OutputEmitterRef<number>;
    radius: number;
    midX: number;
    midY: number;
    minRadians: number;
    maxRadians: number;
    value: _angular_core.WritableSignal<number>;
    windowMouseMoveListener: VoidListener;
    windowMouseUpListener: VoidListener;
    windowTouchMoveListener: VoidListener;
    windowTouchEndListener: VoidListener;
    _componentStyle: KnobStyle;
    mapRange(x: number, inMin: number, inMax: number, outMin: number, outMax: number): number;
    onClick(event: MouseEvent): void;
    updateValue(offsetX: number, offsetY: number): void;
    updateModel(angle: number, start: number): void;
    onMouseDown(event: MouseEvent): void;
    onMouseUp(event: MouseEvent): void;
    onTouchStart(event: TouchEvent): void;
    onTouchEnd(event: TouchEvent): void;
    onMouseMove(event: MouseEvent): void;
    onTouchMove(event: Event): void;
    updateModelValue(newValue: any): void;
    onKeyDown(event: KeyboardEvent): void;
    rangePath(): string;
    valuePath(): string;
    zeroRadians(): number;
    valueRadians(): number;
    minX(): number;
    minY(): number;
    maxX(): number;
    maxY(): number;
    zeroX(): number;
    zeroY(): number;
    valueX(): number;
    valueY(): number;
    largeArc(): 0 | 1;
    sweep(): 0 | 1;
    valueToDisplay(): string;
    get _value(): number;
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value: any, setModelValue: (value: any) => void): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Knob, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Knob, "p-knob", never, { "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "valueColor": { "alias": "valueColor"; "required": false; "isSignal": true; }; "rangeColor": { "alias": "rangeColor"; "required": false; "isSignal": true; }; "textColor": { "alias": "textColor"; "required": false; "isSignal": true; }; "valueTemplate": { "alias": "valueTemplate"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "strokeWidth": { "alias": "strokeWidth"; "required": false; "isSignal": true; }; "showValue": { "alias": "showValue"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; }, { "onChange": "onChange"; }, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class KnobModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<KnobModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<KnobModule, never, [typeof Knob, typeof i2.SharedModule], [typeof Knob, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<KnobModule>;
}

export { KNOB_VALUE_ACCESSOR, Knob, KnobClasses, KnobModule, KnobStyle };
