import * as _angular_core from '@angular/core';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { BadgePassThrough } from '@wawjs/ngx-prime/types/badge';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i2 from '@wawjs/ngx-prime/api';

declare class BadgeStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-badge-circle': boolean;
            'p-badge-dot': boolean;
            'p-badge-sm': boolean;
            'p-badge-lg': boolean;
            'p-badge-xl': boolean;
            'p-badge-info': boolean;
            'p-badge-success': boolean;
            'p-badge-warn': boolean;
            'p-badge-danger': boolean;
            'p-badge-secondary': boolean;
            'p-badge-contrast': boolean;
        })[];
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BadgeStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<BadgeStyle>;
}
/**
 *
 * Badge represents people using icons, labels and images.
 *
 * [Live Demo](https://www.ngx-prime.org/badge)
 *
 * @module badgestyle
 *
 */
declare enum BadgeClasses {
    /**
     * Class name of the root element
     */
    root = "p-badge"
}

/**
 * Badge Directive is directive usage of badge component.
 * @group Components
 */
declare class BadgeDirective extends BaseComponent {
    $pcBadgeDirective: BadgeDirective | undefined;
    /**
     * Used to pass attributes to DOM elements inside the Badge component.
     * @defaultValue undefined
     * @deprecated use pBadgePT instead.
     * @group Props
     */
    ptBadgeDirective: _angular_core.InputSignal<BadgePassThrough>;
    /**
     * Used to pass attributes to DOM elements inside the Badge component.
     * @defaultValue undefined
     * @group Props
     */
    pBadgePT: _angular_core.InputSignal<BadgePassThrough>;
    /**
     * Indicates whether the component should be rendered without styles.
     * @defaultValue undefined
     * @group Props
     */
    pBadgeUnstyled: _angular_core.InputSignal<boolean | undefined>;
    /**
     * When specified, disables the component.
     * @group Props
     */
    disabled: _angular_core.InputSignal<boolean>;
    /**
     * Size of the badge, valid options are "large" and "xlarge".
     * @group Props
     */
    badgeSize: _angular_core.InputSignal<"small" | "large" | "xlarge" | null | undefined>;
    /**
     * Size of the badge, valid options are "large" and "xlarge".
     * @group Props
     * @deprecated use badgeSize instead.
     */
    size: _angular_core.InputSignal<"small" | "large" | "xlarge" | null | undefined>;
    /**
     * Severity type of the badge.
     * @group Props
     */
    severity: _angular_core.InputSignal<"info" | "success" | "warn" | "danger" | "secondary" | "contrast" | null | undefined>;
    /**
     * Value to display inside the badge.
     * @group Props
     */
    value: _angular_core.InputSignal<string | number | undefined>;
    /**
     * Inline style of the element.
     * @group Props
     */
    badgeStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Class of the element.
     * @group Props
     */
    badgeStyleClass: _angular_core.InputSignal<string | undefined>;
    private id;
    badgeEl: HTMLElement;
    _componentStyle: BadgeStyle;
    private get activeElement();
    private get canUpdateBadge();
    constructor();
    private prevSeverity?;
    onAfterViewInit(): void;
    private setValue;
    private setSizeClasses;
    private renderBadgeContent;
    private applyStyles;
    private setSeverity;
    private toggleDisableState;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BadgeDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BadgeDirective, "[pBadge]", never, { "ptBadgeDirective": { "alias": "ptBadgeDirective"; "required": false; "isSignal": true; }; "pBadgePT": { "alias": "pBadgePT"; "required": false; "isSignal": true; }; "pBadgeUnstyled": { "alias": "pBadgeUnstyled"; "required": false; "isSignal": true; }; "disabled": { "alias": "badgeDisabled"; "required": false; "isSignal": true; }; "badgeSize": { "alias": "badgeSize"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "severity": { "alias": "severity"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "badgeStyle": { "alias": "badgeStyle"; "required": false; "isSignal": true; }; "badgeStyleClass": { "alias": "badgeStyleClass"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/**
 * Badge is a small status indicator for another element.
 * @group Components
 */
declare class Badge extends BaseComponent<BadgePassThrough> {
    componentName: string;
    $pcBadge: Badge | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Size of the badge, valid options are "large" and "xlarge".
     * @group Props
     */
    badgeSize: _angular_core.InputSignal<"small" | "large" | "xlarge" | null | undefined>;
    /**
     * Size of the badge, valid options are "large" and "xlarge".
     * @group Props
     */
    size: _angular_core.InputSignal<"small" | "large" | "xlarge" | null | undefined>;
    /**
     * Severity type of the badge.
     * @group Props
     */
    severity: _angular_core.InputSignal<"info" | "success" | "warn" | "danger" | "secondary" | "contrast" | null | undefined>;
    /**
     * Value to display inside the badge.
     * @group Props
     */
    value: _angular_core.InputSignal<string | number | null | undefined>;
    /**
     * When specified, disables the component.
     * @group Props
     */
    badgeDisabled: _angular_core.InputSignalWithTransform<boolean, boolean>;
    _componentStyle: BadgeStyle;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Badge, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Badge, "p-badge", never, { "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "badgeSize": { "alias": "badgeSize"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "severity": { "alias": "severity"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "badgeDisabled": { "alias": "badgeDisabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class BadgeModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BadgeModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<BadgeModule, never, [typeof Badge, typeof BadgeDirective, typeof i2.SharedModule], [typeof Badge, typeof BadgeDirective, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<BadgeModule>;
}

export { Badge, BadgeClasses, BadgeDirective, BadgeModule, BadgeStyle };
