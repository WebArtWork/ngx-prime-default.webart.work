import { RadioButtonPassThrough, RadioButtonClickEvent } from '@wawjs/ngx-prime/types/radiobutton';
export * from '@wawjs/ngx-prime/types/radiobutton';
import * as _angular_core from '@angular/core';
import { ElementRef, Injector } from '@angular/core';
import { NgControl } from '@angular/forms';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i3 from '@wawjs/ngx-prime/api';

declare class RadioButtonStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-radiobutton-checked': any;
            'p-disabled': any;
            'p-invalid': any;
            'p-variant-filled': boolean;
            'p-radiobutton-sm p-inputfield-sm': boolean;
            'p-radiobutton-lg p-inputfield-lg': boolean;
        })[];
        box: string;
        input: string;
        icon: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RadioButtonStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<RadioButtonStyle>;
}
/**
 *
 * RadioButton is an extension to standard radio button element with theming.
 *
 * [Live Demo](https://www.ngx-prime.org/radiobutton/)
 *
 * @module radiobuttonstyle
 *
 */
declare enum RadioButtonClasses {
    /**
     * Class name of the root element
     */
    root = "p-radiobutton",
    /**
     * Class name of the box element
     */
    box = "p-radiobutton-box",
    /**
     * Class name of the input element
     */
    input = "p-radiobutton-input",
    /**
     * Class name of the icon element
     */
    icon = "p-radiobutton-icon"
}

/**
 * Adds Prime styling and accessibility attributes to a native radio input.
 * Native radios retain Angular's built-in radio value accessor and grouping.
 *
 * @group Components
 */
declare class RadioButtonDirective extends BaseEditableHolder<RadioButtonPassThrough> {
    componentName: string;
    private readonly element;
    _componentStyle: RadioButtonStyle;
    private readonly bindDirectiveInstance;
    /** @deprecated Use the native `class` attribute instead. */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /** Compatibility input for the directive pass-through configuration. */
    ptRadioButton: _angular_core.InputSignal<RadioButtonPassThrough>;
    /** Pass-through configuration for the native radio button. */
    pRadioButtonPT: _angular_core.InputSignal<RadioButtonPassThrough>;
    /** Enables unstyled mode for this native radio button. */
    pRadioButtonUnstyled: _angular_core.InputSignal<boolean | undefined>;
    value: _angular_core.InputSignal<unknown>;
    binary: _angular_core.InputSignalWithTransform<boolean, unknown>;
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    inputId: _angular_core.InputSignal<string | undefined>;
    autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    variant: _angular_core.InputSignal<"filled" | "outlined" | undefined>;
    size: _angular_core.InputSignal<"small" | "large" | undefined>;
    $variant: _angular_core.Signal<"filled" | "outlined" | null>;
    /** Emits when this native radio input is selected. */
    onClick: _angular_core.OutputEmitterRef<RadioButtonClickEvent>;
    onFocus: _angular_core.OutputEmitterRef<Event>;
    onBlur: _angular_core.OutputEmitterRef<Event>;
    touch: _angular_core.OutputEmitterRef<void>;
    onInputChange(event: Event): void;
    onInputFocus(event: Event): void;
    onInputBlur(event: Event): void;
    get checked(): boolean;
    get dataP(): string | undefined;
    constructor();
    onAfterViewChecked(): void;
    focus(options?: FocusOptions): void;
    writeControlValue(value: unknown, setModelValue: (value: unknown) => void): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RadioButtonDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<RadioButtonDirective, "input[type='radio'][pRadioButton]", never, { "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "ptRadioButton": { "alias": "ptRadioButton"; "required": false; "isSignal": true; }; "pRadioButtonPT": { "alias": "pRadioButtonPT"; "required": false; "isSignal": true; }; "pRadioButtonUnstyled": { "alias": "pRadioButtonUnstyled"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "binary": { "alias": "binary"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, { "onClick": "onClick"; "onFocus": "onFocus"; "onBlur": "onBlur"; "touch": "touch"; }, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}

declare const RADIO_VALUE_ACCESSOR: any;
declare class RadioControlRegistry {
    private accessors;
    add(control: NgControl, accessor: RadioButton): void;
    remove(accessor: RadioButton): void;
    select(accessor: RadioButton): void;
    private isSameGroup;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RadioControlRegistry, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<RadioControlRegistry>;
}
/**
 * RadioButton is an extension to standard radio button element with theming.
 *
 * @deprecated Use a native `<input type="radio" pRadioButton>` instead. This
 * component remains available for compatibility and is planned for removal in v23.
 * @group Components
 */
declare class RadioButton extends BaseEditableHolder<RadioButtonPassThrough> {
    componentName: string;
    $pcRadioButton: RadioButton | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Value of the radiobutton.
     * @group Props
     */
    value: _angular_core.InputSignal<any>;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Identifier of the focus input to match a label defined for the component.
     * @group Props
     */
    inputId: _angular_core.InputSignal<string | undefined>;
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Used to define a string that labels the input element.
     * @group Props
     */
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Allows to select a boolean value.
     * @group Props
     */
    binary: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Specifies the input variant of the component.
     * @defaultValue undefined
     * @group Props
     */
    variant: _angular_core.InputSignal<"filled" | "outlined" | undefined>;
    /**
     * Specifies the size of the component.
     * @defaultValue undefined
     * @group Props
     */
    size: _angular_core.InputSignal<"small" | "large" | undefined>;
    /**
     * Callback to invoke on radio button click.
     * @param {RadioButtonClickEvent} event - Custom click event.
     * @group Emits
     */
    onClick: _angular_core.OutputEmitterRef<RadioButtonClickEvent>;
    /**
     * Callback to invoke when the receives focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onFocus: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke when the loses focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onBlur: _angular_core.OutputEmitterRef<Event>;
    readonly inputViewChild: _angular_core.Signal<ElementRef<any>>;
    $variant: _angular_core.Signal<"filled" | "outlined" | null>;
    checked: Nullable<boolean>;
    focused: Nullable<boolean>;
    control: Nullable<NgControl>;
    _componentStyle: RadioButtonStyle;
    injector: Injector;
    registry: RadioControlRegistry;
    onInit(): void;
    onChange(event: any): void;
    select(event: Event): void;
    onInputFocus(event: Event): void;
    onInputBlur(event: Event): void;
    /**
     * Applies focus to input field.
     * @group Method
     */
    focus(): void;
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value: any, setModelValue: (value: any) => void): void;
    onDestroy(): void;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RadioButton, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RadioButton, "p-radioButton, p-radiobutton, p-radio-button", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "binary": { "alias": "binary"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, { "onClick": "onClick"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class RadioButtonModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RadioButtonModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<RadioButtonModule, never, [typeof RadioButton, typeof RadioButtonDirective, typeof i3.SharedModule], [typeof RadioButton, typeof RadioButtonDirective, typeof i3.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<RadioButtonModule>;
}

export { RADIO_VALUE_ACCESSOR, RadioButton, RadioButtonClasses, RadioButtonDirective, RadioButtonModule, RadioButtonStyle, RadioControlRegistry };
