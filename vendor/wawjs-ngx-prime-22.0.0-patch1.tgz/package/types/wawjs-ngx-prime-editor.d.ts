import { EditorPassThrough, EditorInitEvent, EditorTextChangeEvent, EditorSelectionChangeEvent, EditorChangeEvent, EditorFocusEvent, EditorBlurEvent } from '@wawjs/ngx-prime/types/editor';
export * from '@wawjs/ngx-prime/types/editor';
import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { Header, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class EditorStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-invalid': any;
        })[];
        toolbar: string;
        content: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<EditorStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<EditorStyle>;
}
/**
 *
 * Editor groups a collection of contents in tabs.
 *
 * [Live Demo](https://www.ngx-prime.org/editor/)
 *
 * @module editorstyle
 *
 */
declare enum EditorClasses {
    /**
     * Class name of the root element
     */
    root = "p-editor",
    /**
     * Class name of the toolbar element
     */
    toolbar = "p-editor-toolbar",
    /**
     * Class name of the content element
     */
    content = "p-editor-content"
}

declare const EDITOR_VALUE_ACCESSOR: any;
/**
 * Editor groups a collection of contents in tabs.
 * @group Components
 */
declare class Editor extends BaseEditableHolder<EditorPassThrough> {
    componentName: string;
    $pcEditor: Editor | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Inline style of the container.
     * @group Props
     */
    style: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the container.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Placeholder text to show when editor is empty.
     * @group Props
     */
    placeholder: _angular_core.InputSignal<string | undefined>;
    /**
     * Whitelist of formats to display, see [here](https://quilljs.com/docs/formats/) for available options.
     * @group Props
     */
    formats: _angular_core.InputSignal<string[] | undefined>;
    /**
     * Modules configuration of Editor, see [here](https://quilljs.com/docs/modules/) for available options.
     * @group Props
     */
    modules: _angular_core.InputSignal<object | undefined>;
    /**
     * DOM Element or a CSS selector for a DOM Element, within which the editorâ€™s p elements (i.e. tooltips, etc.) should be confined. Currently, it only considers left and right boundaries.
     * @group Props
     */
    bounds: _angular_core.InputSignal<string | HTMLElement | undefined>;
    /**
     * DOM Element or a CSS selector for a DOM Element, specifying which container has the scrollbars (i.e. overflow-y: auto), if is has been changed from the default ql-editor with custom CSS. Necessary to fix scroll jumping bugs when Quill is set to auto grow its height, and another ancestor container is responsible from the scrolling..
     * @group Props
     */
    scrollingContainer: _angular_core.InputSignal<string | HTMLElement | undefined>;
    /**
     * Shortcut for debug. Note debug is a static method and will affect other instances of Quill editors on the page. Only warning and error messages are enabled by default.
     * @group Props
     */
    debug: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to instantiate the editor to read-only mode.
     * @group Props
     */
    readonly: _angular_core.InputSignal<boolean>;
    /**
     * Callback to invoke when the quill modules are loaded.
     * @param {EditorInitEvent} event - custom event.
     * @group Emits
     */
    onEditorInit: _angular_core.OutputEmitterRef<EditorInitEvent>;
    /**
     * Callback to invoke when text of editor changes.
     * @param {EditorTextChangeEvent} event - custom event.
     * @group Emits
     */
    onTextChange: _angular_core.OutputEmitterRef<EditorTextChangeEvent>;
    /**
     * Callback to invoke when selection of the text changes.
     * @param {EditorSelectionChangeEvent} event - custom event.
     * @group Emits
     */
    onSelectionChange: _angular_core.OutputEmitterRef<EditorSelectionChangeEvent>;
    /**
     * Callback to invoke when editor content changes (combines both text and selection changes).
     * @param {EditorChangeEvent} event - custom event.
     * @group Emits
     */
    onEditorChange: _angular_core.OutputEmitterRef<EditorChangeEvent>;
    /**
     * Callback to invoke when editor receives focus.
     * @param {EditorFocusEvent} event - custom event.
     * @group Emits
     */
    onFocus: _angular_core.OutputEmitterRef<EditorFocusEvent>;
    /**
     * Callback to invoke when editor loses focus.
     * @param {EditorBlurEvent} event - custom event.
     * @group Emits
     */
    onBlur: _angular_core.OutputEmitterRef<EditorBlurEvent>;
    readonly toolbar: _angular_core.Signal<Header | undefined>;
    value: Nullable<string>;
    delayedCommand: ((...args: any[]) => any) | null;
    quill: any;
    dynamicQuill: any;
    /**
     * Custom item template.
     * @group Templates
     */
    headerTemplate: Nullable<TemplateRef<any>>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _headerTemplate: TemplateRef<any> | undefined;
    private get isAttachedQuillEditorToDOM();
    private quillElements;
    private focusListener;
    private blurListener;
    _componentStyle: EditorStyle;
    constructor();
    onAfterContentInit(): void;
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value: any): void;
    getQuill(): any;
    private initQuillEditor;
    private createQuillEditor;
    onDestroy(): void;
    private initQuillElements;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Editor, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Editor, "p-editor", never, { "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "formats": { "alias": "formats"; "required": false; "isSignal": true; }; "modules": { "alias": "modules"; "required": false; "isSignal": true; }; "bounds": { "alias": "bounds"; "required": false; "isSignal": true; }; "scrollingContainer": { "alias": "scrollingContainer"; "required": false; "isSignal": true; }; "debug": { "alias": "debug"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; }, { "onEditorInit": "onInit"; "onTextChange": "onTextChange"; "onSelectionChange": "onSelectionChange"; "onEditorChange": "onEditorChange"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, ["toolbar", "templates", "headerTemplate"], ["p-header"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class EditorModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<EditorModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<EditorModule, never, [typeof Editor, typeof i2.SharedModule], [typeof Editor, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<EditorModule>;
}

export { EDITOR_VALUE_ACCESSOR, Editor, EditorClasses, EditorModule, EditorStyle };
