import * as i0 from '@angular/core';
import { AfterViewChecked } from '@angular/core';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { FloatLabelPassThrough } from '@wawjs/ngx-prime/types/floatlabel';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i2 from '@wawjs/ngx-prime/api';

declare class FloatLabelStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-floatlabel-over': boolean;
            'p-floatlabel-on': boolean;
            'p-floatlabel-in': boolean;
        })[];
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<FloatLabelStyle, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FloatLabelStyle>;
}
/**
 *
 * FloatLabel visually integrates a label with its form element.
 *
 * [Live Demo](https://www.ngx-prime.org/floatlabel/)
 *
 * @module floatlabelstyle
 *
 */
declare enum FloatLabelClasses {
    /**
     * Class name of the root element
     */
    root = "p-floatlabel"
}

/**
 * FloatLabel appears on top of the input field when focused.
 * @group Components
 */
declare class FloatLabel extends BaseComponent<FloatLabelPassThrough> implements AfterViewChecked {
    componentName: string;
    _componentStyle: FloatLabelStyle;
    $pcFloatLabel: FloatLabel | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Defines the positioning of the label relative to the input.
     * @group Props
     */
    variant: i0.InputSignal<"over" | "on" | "in">;
    static ɵfac: i0.ɵɵFactoryDeclaration<FloatLabel, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FloatLabel, "p-floatlabel, p-floatLabel, p-float-label", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class FloatLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FloatLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FloatLabelModule, never, [typeof FloatLabel, typeof i2.SharedModule], [typeof FloatLabel, typeof i2.SharedModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FloatLabelModule>;
}

export { FloatLabel, FloatLabelClasses, FloatLabelModule, FloatLabelStyle };
