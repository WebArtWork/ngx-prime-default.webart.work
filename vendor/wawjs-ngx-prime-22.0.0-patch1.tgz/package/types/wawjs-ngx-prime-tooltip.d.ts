import * as _angular_core from '@angular/core';
import { NgZone, TemplateRef } from '@angular/core';
import { TooltipOptions } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import { TooltipPassThroughOptions, TooltipPassThrough } from '@wawjs/ngx-prime/types/tooltip';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i1 from '@wawjs/ngx-prime/bind';

declare class TooltipStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: string;
        arrow: string;
        text: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TooltipStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TooltipStyle>;
}
/**
 *
 * Tooltip directive provides advisory information for a component.
 *
 * [Live Demo](https://www.ngx-prime.org/tooltip)
 *
 * @module tooltipstyle
 *
 */
declare enum TooltipClasses {
    /**
     * Class name of the root element
     */
    root = "p-tooltip",
    /**
     * Class name of the arrow element
     */
    arrow = "p-tooltip-arrow",
    /**
     * Class name of the text element
     */
    text = "p-tooltip-text"
}

/**
 * Tooltip directive provides advisory information for a component.
 * @group Components
 */
declare class Tooltip extends BaseComponent<TooltipPassThroughOptions> {
    zone: NgZone;
    private viewContainer;
    componentName: string;
    $pcTooltip: Tooltip | undefined;
    /**
     * Position of the tooltip.
     * @group Props
     */
    tooltipPosition: _angular_core.InputSignal<string | undefined>;
    /**
     * Event to show the tooltip.
     * @group Props
     */
    tooltipEvent: _angular_core.InputSignal<"hover" | "focus" | "both">;
    /**
     * Type of CSS position.
     * @group Props
     */
    positionStyle: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the tooltip.
     * @group Props
     */
    tooltipStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether the z-index should be managed automatically to always go on top or have a fixed value.
     * @group Props
     */
    tooltipZIndex: _angular_core.InputSignal<string | undefined>;
    /**
     * By default the tooltip contents are rendered as text. Set to false to support html tags in the content.
     * @group Props
     */
    escape: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Delay to show the tooltip in milliseconds.
     * @group Props
     */
    showDelay: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Delay to hide the tooltip in milliseconds.
     * @group Props
     */
    hideDelay: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Time to wait in milliseconds to hide the tooltip even it is active.
     * @group Props
     */
    life: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Specifies the additional vertical offset of the tooltip from its default position.
     * @group Props
     */
    positionTop: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Specifies the additional horizontal offset of the tooltip from its default position.
     * @group Props
     */
    positionLeft: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Whether to hide tooltip when hovering over tooltip content.
     * @group Props
     */
    autoHide: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Automatically adjusts the element position when there is not enough space on the selected position.
     * @group Props
     */
    fitContent: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to hide tooltip on escape key press.
     * @group Props
     */
    hideOnEscape: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to show the tooltip only when the target text overflows (e.g., ellipsis is active).
     * @group Props
     */
    showOnEllipsis: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Content of the tooltip.
     * @group Props
     */
    content: _angular_core.InputSignal<string | TemplateRef<HTMLElement> | undefined>;
    /**
     * When present, it specifies that the component should be disabled.
     * @defaultValue false
     * @group Props
     */
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Specifies the tooltip configuration options for the component.
     * @group Props
     */
    tooltipOptions: _angular_core.InputSignal<TooltipOptions | undefined>;
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'self'
     * @group Props
     */
    appendTo: _angular_core.InputSignal<any>;
    $appendTo: _angular_core.Signal<any>;
    _tooltipOptions: Record<string, any>;
    container: any;
    styleClass: string | undefined;
    tooltipText: any;
    rootPTClasses: string;
    showTimeout: any;
    hideTimeout: any;
    active: boolean | undefined;
    mouseEnterListener: Nullable<(...args: any[]) => any>;
    mouseLeaveListener: Nullable<(...args: any[]) => any>;
    containerMouseleaveListener: Nullable<(...args: any[]) => any>;
    clickListener: Nullable<(...args: any[]) => any>;
    focusListener: Nullable<(...args: any[]) => any>;
    blurListener: Nullable<(...args: any[]) => any>;
    touchStartListener: Nullable<(...args: any[]) => any>;
    touchEndListener: Nullable<(...args: any[]) => any>;
    documentTouchListener: Nullable<(...args: any[]) => any>;
    documentEscapeListener: Nullable<(...args: any[]) => any>;
    scrollHandler: any;
    resizeListener: any;
    _componentStyle: TooltipStyle;
    interactionInProgress: boolean;
    /**
     * Used to pass attributes to DOM elements inside the Tooltip component.
     * @defaultValue undefined
     * @deprecated use pTooltipPT instead.
     * @group Props
     */
    ptTooltip: _angular_core.InputSignal<TooltipPassThrough>;
    /**
     * Used to pass attributes to DOM elements inside the Tooltip component.
     * @defaultValue undefined
     * @group Props
     */
    pTooltipPT: _angular_core.InputSignal<TooltipPassThrough>;
    /**
     * Indicates whether the component should be rendered without styles.
     * @defaultValue undefined
     * @group Props
     */
    pTooltipUnstyled: _angular_core.InputSignal<boolean | undefined>;
    constructor();
    onAfterViewInit(): void;
    isAutoHide(): boolean;
    onMouseEnter(): void;
    onMouseLeave(e: MouseEvent): void;
    onTouchStart(): void;
    onTouchEnd(): void;
    bindDocumentTouchListener(): void;
    unbindDocumentTouchListener(): void;
    onFocus(): void;
    onBlur(): void;
    onInputClick(): void;
    hasEllipsis(): boolean;
    activate(): void;
    deactivate(): void;
    create(): void;
    bindContainerMouseleaveListener(): void;
    unbindContainerMouseleaveListener(): void;
    show(): void;
    hide(): void;
    updateText(): void;
    align(): void;
    getHostOffset(): {
        left: any;
        top: any;
    };
    private get activeElement();
    alignRight(): void;
    alignLeft(): void;
    alignTop(): void;
    getArrowElement(): any;
    alignBottom(): void;
    alignTooltip(offsetLeft: any, offsetTop: any): void;
    setOption(option: any): void;
    getOption(option: string): any;
    getTarget(el: Element): Element | null;
    preAlign(position: string): void;
    isOutOfBounds(): boolean;
    onWindowResize(): void;
    bindDocumentResizeListener(): void;
    unbindDocumentResizeListener(): void;
    bindScrollListener(): void;
    unbindScrollListener(): void;
    unbindEvents(): void;
    remove(): void;
    clearShowTimeout(): void;
    clearHideTimeout(): void;
    clearTimeouts(): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Tooltip, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<Tooltip, "[pTooltip]", never, { "tooltipPosition": { "alias": "tooltipPosition"; "required": false; "isSignal": true; }; "tooltipEvent": { "alias": "tooltipEvent"; "required": false; "isSignal": true; }; "positionStyle": { "alias": "positionStyle"; "required": false; "isSignal": true; }; "tooltipStyleClass": { "alias": "tooltipStyleClass"; "required": false; "isSignal": true; }; "tooltipZIndex": { "alias": "tooltipZIndex"; "required": false; "isSignal": true; }; "escape": { "alias": "escape"; "required": false; "isSignal": true; }; "showDelay": { "alias": "showDelay"; "required": false; "isSignal": true; }; "hideDelay": { "alias": "hideDelay"; "required": false; "isSignal": true; }; "life": { "alias": "life"; "required": false; "isSignal": true; }; "positionTop": { "alias": "positionTop"; "required": false; "isSignal": true; }; "positionLeft": { "alias": "positionLeft"; "required": false; "isSignal": true; }; "autoHide": { "alias": "autoHide"; "required": false; "isSignal": true; }; "fitContent": { "alias": "fitContent"; "required": false; "isSignal": true; }; "hideOnEscape": { "alias": "hideOnEscape"; "required": false; "isSignal": true; }; "showOnEllipsis": { "alias": "showOnEllipsis"; "required": false; "isSignal": true; }; "content": { "alias": "pTooltip"; "required": false; "isSignal": true; }; "disabled": { "alias": "tooltipDisabled"; "required": false; "isSignal": true; }; "tooltipOptions": { "alias": "tooltipOptions"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "ptTooltip": { "alias": "ptTooltip"; "required": false; "isSignal": true; }; "pTooltipPT": { "alias": "pTooltipPT"; "required": false; "isSignal": true; }; "pTooltipUnstyled": { "alias": "pTooltipUnstyled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class TooltipModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TooltipModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<TooltipModule, never, [typeof Tooltip, typeof i1.BindModule], [typeof Tooltip, typeof i1.BindModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<TooltipModule>;
}

export { Tooltip, TooltipClasses, TooltipModule, TooltipStyle };
