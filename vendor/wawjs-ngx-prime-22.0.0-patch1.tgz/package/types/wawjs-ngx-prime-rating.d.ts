import { RatingPassThrough, RatingRateEvent, RatingIconTemplateContext } from '@wawjs/ngx-prime/types/rating';
export * from '@wawjs/ngx-prime/types/rating';
import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';
import * as i3 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class RatingStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-readonly': any;
            'p-disabled': any;
        })[];
        option: ({ instance, star, value }: {
            instance: any;
            star: any;
            value: any;
        }) => (string | {
            'p-rating-option-active': boolean;
            'p-focus-visible': any;
        })[];
        onIcon: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-invalid': any;
        })[];
        offIcon: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-invalid': any;
        })[];
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RatingStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<RatingStyle>;
}
/**
 *
 * Rating component is a star based selection input.
 *
 * [Live Demo](https://www.ngx-prime.org/rating/)
 *
 * @module ratingstyle
 *
 */
declare enum RatingClasses {
    /**
     * Class name of the root element
     */
    root = "p-rating",
    /**
     * Class name of the option element
     */
    option = "p-rating-option",
    /**
     * Class name of the on icon element
     */
    onIcon = "p-rating-on-icon",
    /**
     * Class name of the off icon element
     */
    offIcon = "p-rating-off-icon"
}

/** Adds Prime state attributes to a native radio used in a rating group. */
declare class RatingDirective extends BaseEditableHolder<RatingPassThrough> {
    componentName: string;
    _componentStyle: RatingStyle;
    readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    value: _angular_core.InputSignalWithTransform<number, unknown>;
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    onRate: _angular_core.OutputEmitterRef<RatingRateEvent>;
    onFocus: _angular_core.OutputEmitterRef<FocusEvent>;
    onBlur: _angular_core.OutputEmitterRef<FocusEvent>;
    touch: _angular_core.OutputEmitterRef<void>;
    onInputClick(event: MouseEvent): void;
    onInputChange(event: Event): void;
    onInputFocus(event: FocusEvent): void;
    onInputBlur(event: FocusEvent): void;
    get checked(): boolean;
    private setRating;
    writeControlValue(value: unknown, setModelValue: (value: unknown) => void): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RatingDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<RatingDirective, "input[type='radio'][pRating]", never, { "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; }, { "onRate": "onRate"; "onFocus": "onFocus"; "onBlur": "onBlur"; "touch": "touch"; }, never, never, true, never>;
}

declare const RATING_VALUE_ACCESSOR: any;
/**
 * Rating is an extension to standard radio button element with theming.
 * @group Components
 */
declare class Rating extends BaseEditableHolder<RatingPassThrough> {
    componentName: string;
    $pcRating: Rating | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * When present, changing the value is not possible.
     * @group Props
     */
    readonly: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Number of stars.
     * @group Props
     */
    stars: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Style class of the on icon.
     * @group Props
     */
    iconOnClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the on icon.
     * @group Props
     */
    iconOnStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the off icon.
     * @group Props
     */
    iconOffClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the off icon.
     * @group Props
     */
    iconOffStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Emitted on value change.
     * @param {RatingRateEvent} value - Custom rate event.
     * @group Emits
     */
    onRate: _angular_core.OutputEmitterRef<RatingRateEvent>;
    /**
     * Emitted when the rating receives focus.
     * @param {Event} value - Browser event.
     * @group Emits
     */
    onFocus: _angular_core.OutputEmitterRef<FocusEvent>;
    /**
     * Emitted when the rating loses focus.
     * @param {Event} value - Browser event.
     * @group Emits
     */
    onBlur: _angular_core.OutputEmitterRef<FocusEvent>;
    /**
     * Custom on icon template.
     * @param {RatingIconTemplateContext} context - icon context.
     * @see {@link RatingIconTemplateContext}
     * @group Templates
     */
    onIconTemplate: Nullable<TemplateRef<RatingIconTemplateContext>>;
    /**
     * Custom off icon template.
     * @param {RatingIconTemplateContext} context - icon context.
     * @see {@link RatingIconTemplateContext}
     * @group Templates
     */
    offIconTemplate: Nullable<TemplateRef<RatingIconTemplateContext>>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    value: Nullable<number>;
    starsArray: Nullable<number[]>;
    isFocusVisibleItem: boolean;
    focusedOptionIndex: _angular_core.WritableSignal<number>;
    nameattr: string | undefined;
    _componentStyle: RatingStyle;
    _onIconTemplate: TemplateRef<RatingIconTemplateContext> | undefined;
    _offIconTemplate: TemplateRef<RatingIconTemplateContext> | undefined;
    onInit(): void;
    onAfterContentInit(): void;
    onOptionClick(event: any, value: any): void;
    onOptionSelect(event: any, value: any): void;
    onChange(event: any, value: any): void;
    onInputBlur(event: any): void;
    onInputFocus(event: any, value: any): void;
    updateModel(event: any, value: any): void;
    starAriaLabel(value: any): string | undefined;
    getIconTemplate(i: number): Nullable<TemplateRef<RatingIconTemplateContext>>;
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value: any, setModelValue: (value: any) => void): void;
    get isCustomIcon(): boolean;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Rating, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Rating, "p-rating", never, { "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "stars": { "alias": "stars"; "required": false; "isSignal": true; }; "iconOnClass": { "alias": "iconOnClass"; "required": false; "isSignal": true; }; "iconOnStyle": { "alias": "iconOnStyle"; "required": false; "isSignal": true; }; "iconOffClass": { "alias": "iconOffClass"; "required": false; "isSignal": true; }; "iconOffStyle": { "alias": "iconOffStyle"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; }, { "onRate": "onRate"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, ["templates", "onIconTemplate", "offIconTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class RatingModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RatingModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<RatingModule, never, [typeof Rating, typeof RatingDirective, typeof i3.SharedModule], [typeof Rating, typeof RatingDirective, typeof i3.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<RatingModule>;
}

export { RATING_VALUE_ACCESSOR, Rating, RatingClasses, RatingDirective, RatingModule, RatingStyle };
