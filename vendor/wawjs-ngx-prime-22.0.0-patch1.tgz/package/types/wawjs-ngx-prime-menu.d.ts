import { MenuPassThrough, MenuItemTemplateContext, MenuSubmenuHeaderTemplateContext } from '@wawjs/ngx-prime/types/menu';
export * from '@wawjs/ngx-prime/types/menu';
import * as _angular_core from '@angular/core';
import { ElementRef, TemplateRef, PipeTransform } from '@angular/core';
import { SafeHtml } from '@angular/platform-browser';
import { MotionOptions, MotionEvent } from '@wawjs/css-prime-motion';
import * as i2 from '@wawjs/ngx-prime/api';
import { OverlayService, MenuItem, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { ConnectedOverlayScrollHandler } from '@wawjs/ngx-prime/dom';
import { VoidListener } from '@wawjs/ngx-prime/ts-helpers';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class MenuStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-menu-overlay': any;
        })[];
        start: string;
        list: string;
        submenuLabel: string;
        separator: string;
        end: string;
        item: ({ instance, item, id }: {
            instance: any;
            item: any;
            id: any;
        }) => any[];
        itemContent: string;
        itemLink: string;
        itemIcon: ({ item }: {
            item: any;
        }) => any[];
        itemLabel: string;
    };
    inlineStyles: {
        root: ({ instance }: {
            instance: any;
        }) => {
            position: string;
        };
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MenuStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<MenuStyle>;
}
/**
 *
 * Menu is a navigation / command component that supports dynamic and static positioning.
 *
 * [Live Demo](https://www.ngx-prime.org/menu/)
 *
 * @module menustyle
 *
 */
declare enum MenuClasses {
    /**
     * Class name of the root element
     */
    root = "p-menu",
    /**
     * Class name of the start element
     */
    start = "p-menu-start",
    /**
     * Class name of the list element
     */
    list = "p-menu-list",
    /**
     * Class name of the submenu item element
     */
    submenuItem = "p-menu-submenu-item",
    /**
     * Class name of the separator element
     */
    separator = "p-menu-separator",
    /**
     * Class name of the end element
     */
    end = "p-menu-end",
    /**
     * Class name of the item element
     */
    item = "p-menu-item",
    /**
     * Class name of the item content element
     */
    itemContent = "p-menu-item-content",
    /**
     * Class name of the item link element
     */
    itemLink = "p-menu-item-link",
    /**
     * Class name of the item icon element
     */
    itemIcon = "p-menu-item-icon",
    /**
     * Class name of the item label element
     */
    itemLabel = "p-menu-item-label"
}

declare class SafeHtmlPipe implements PipeTransform {
    private readonly platformId;
    private readonly sanitizer;
    transform(value: string): SafeHtml;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SafeHtmlPipe, never>;
    static ɵpipe: _angular_core.ɵɵPipeDeclaration<SafeHtmlPipe, "safeHtml", true>;
}
declare class MenuItemContent extends BaseComponent {
    item: _angular_core.InputSignal<MenuItem | undefined>;
    itemTemplate: _angular_core.InputSignal<any>;
    menuitemId: _angular_core.InputSignal<string>;
    idx: _angular_core.InputSignal<number>;
    onMenuItemClick: _angular_core.OutputEmitterRef<any>;
    menu: Menu;
    _componentStyle: MenuStyle;
    hostName: string;
    constructor();
    onItemClick(event: any, item: any): void;
    getPTOptions(key: string): any;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MenuItemContent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MenuItemContent, "[pMenuItemContent]", never, { "item": { "alias": "pMenuItemContent"; "required": false; "isSignal": true; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; "isSignal": true; }; "menuitemId": { "alias": "menuitemId"; "required": false; "isSignal": true; }; "idx": { "alias": "idx"; "required": false; "isSignal": true; }; }, { "onMenuItemClick": "onMenuItemClick"; }, never, never, true, never>;
}
/**
 * Menu is a navigation / command component that supports dynamic and static positioning.
 * @group Components
 */
declare class Menu extends BaseComponent<MenuPassThrough> {
    overlayService: OverlayService;
    componentName: string;
    /**
     * An array of menuitems.
     * @group Props
     */
    model: _angular_core.InputSignal<MenuItem[] | undefined>;
    /**
     * Defines if menu would displayed as a popup.
     * @group Props
     */
    popup: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Inline style of the component.
     * @group Props
     */
    style: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the component.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to automatically manage layering.
     * @group Props
     */
    autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Base zIndex value to use in layering.
     * @group Props
     */
    baseZIndex: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Transition options of the show animation.
     * @deprecated since v21.0.0, use `motionOptions` instead.
     * @group Props
     */
    showTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * Transition options of the hide animation.
     * @deprecated since v21.0.0, use `motionOptions` instead.
     * @group Props
     */
    hideTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * Defines a string value that labels an interactive element.
     * @group Props
     */
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Identifier of the underlying input element.
     * @group Props
     */
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Current id state as a string.
     * @group Props
     */
    id: _angular_core.InputSignal<string | undefined>;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'self'
     * @group Props
     */
    appendTo: _angular_core.InputSignal<any>;
    /**
     * The motion options.
     * @group Props
     */
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    computedMotionOptions: _angular_core.Signal<MotionOptions>;
    /**
     * Callback to invoke when overlay menu is shown.
     * @group Emits
     */
    onShow: _angular_core.OutputEmitterRef<any>;
    /**
     * Callback to invoke when overlay menu is hidden.
     * @group Emits
     */
    onHide: _angular_core.OutputEmitterRef<any>;
    /**
     * Callback to invoke when the list loses focus.
     * @param {Event} event - blur event.
     * @group Emits
     */
    onBlur: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke when the list receives focus.
     * @param {Event} event - focus event.
     * @group Emits
     */
    onFocus: _angular_core.OutputEmitterRef<Event>;
    listViewChild: _angular_core.Signal<ElementRef<any> | undefined>;
    containerViewChild: _angular_core.Signal<ElementRef<any> | undefined>;
    $appendTo: _angular_core.Signal<any>;
    container: any;
    scrollHandler: ConnectedOverlayScrollHandler | null | undefined;
    documentClickListener: VoidListener;
    documentResizeListener: VoidListener;
    preventDocumentDefault: boolean | undefined;
    target: any;
    visible: boolean | undefined;
    focusedOptionId: _angular_core.Signal<any>;
    focusedOptionIndex: any;
    selectedOptionIndex: any;
    focused: boolean | undefined;
    overlayVisible: boolean | undefined;
    $pcMenu: Menu | undefined;
    _componentStyle: MenuStyle;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    private _generatedId;
    get resolvedId(): string;
    getPTOptions(key: string, item: any, index: number, id: string): any;
    /**
     * Toggles the visibility of the popup menu.
     * @param {Event} event - Browser event.
     * @group Method
     */
    toggle(event: Event): void;
    /**
     * Displays the popup menu.
     * @param {Event} event - Browser event.
     * @group Method
     */
    show(event: any): void;
    onInit(): void;
    /**
     * Defines template option for start.
     * @group Templates
     */
    startTemplate: TemplateRef<void> | undefined;
    _startTemplate: TemplateRef<void> | undefined;
    /**
     * Defines template option for end.
     * @group Templates
     */
    endTemplate: TemplateRef<void> | undefined;
    _endTemplate: TemplateRef<void> | undefined;
    /**
     * Defines template option for header.
     * @group Templates
     */
    readonly headerTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    _headerTemplate: TemplateRef<void> | undefined;
    /**
     * Custom item template.
     * @param {MenuItemTemplateContext} context - item context.
     * @see {@link MenuItemTemplateContext}
     * @group Templates
     */
    readonly itemTemplate: _angular_core.Signal<TemplateRef<MenuItemTemplateContext> | undefined>;
    _itemTemplate: TemplateRef<MenuItemTemplateContext> | undefined;
    /**
     * Custom submenu header template.
     * @param {MenuSubmenuHeaderTemplateContext} context - submenu header context.
     * @see {@link MenuSubmenuHeaderTemplateContext}
     * @group Templates
     */
    readonly submenuHeaderTemplate: _angular_core.Signal<TemplateRef<MenuSubmenuHeaderTemplateContext> | undefined>;
    _submenuHeaderTemplate: TemplateRef<MenuSubmenuHeaderTemplateContext> | undefined;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    onAfterContentInit(): void;
    getTabIndexValue(): string | null;
    onOverlayBeforeEnter(event: MotionEvent): void;
    onOverlayAfterLeave(): void;
    appendOverlay(): void;
    restoreOverlayAppend(): void;
    moveOnTop(): void;
    /**
     * Hides the popup menu.
     * @group Method
     */
    hide(): void;
    onWindowResize(): void;
    menuitemId(item: MenuItem, id: string | any, index?: string | number, childIndex?: string | number): string;
    isItemFocused(id: any): boolean;
    label(label: any): any;
    disabled(disabled: any): any;
    activedescendant(): any;
    onListFocus(event: Event): void;
    onListBlur(event: FocusEvent | MouseEvent): void;
    onListKeyDown(event: any): void;
    onArrowDownKey(event: any): void;
    onArrowUpKey(event: any): void;
    onHomeKey(event: any): void;
    onEndKey(event: any): void;
    onEnterKey(event: any): void;
    onSpaceKey(event: any): void;
    findNextOptionIndex(index: any): number;
    findPrevOptionIndex(index: any): number;
    changeFocusedOptionIndex(index: any): void;
    itemClick(event: any, id: string): void;
    onOverlayClick(event: Event): void;
    bindDocumentClickListener(): void;
    unbindDocumentClickListener(): void;
    bindDocumentResizeListener(): void;
    unbindDocumentResizeListener(): void;
    bindScrollListener(): void;
    unbindScrollListener(): void;
    onOverlayHide(): void;
    onDestroy(): void;
    hasSubMenu(): boolean;
    isItemHidden(item: any): boolean;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Menu, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Menu, "p-menu", never, { "model": { "alias": "model"; "required": false; "isSignal": true; }; "popup": { "alias": "popup"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "baseZIndex": { "alias": "baseZIndex"; "required": false; "isSignal": true; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; "isSignal": true; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; }, { "onShow": "onShow"; "onHide": "onHide"; "onBlur": "onBlur"; "onFocus": "onFocus"; }, ["headerTemplate", "itemTemplate", "submenuHeaderTemplate", "templates", "startTemplate", "endTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class MenuModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MenuModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<MenuModule, never, [typeof Menu, typeof i2.SharedModule, typeof SafeHtmlPipe], [typeof Menu, typeof i2.SharedModule, typeof SafeHtmlPipe]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<MenuModule>;
}

export { Menu, MenuClasses, MenuItemContent, MenuModule, MenuStyle, SafeHtmlPipe };
