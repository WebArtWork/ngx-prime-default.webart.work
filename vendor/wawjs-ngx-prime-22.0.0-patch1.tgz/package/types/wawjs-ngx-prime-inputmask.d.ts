import { InputMaskPassThrough, Caret } from '@wawjs/ngx-prime/types/inputmask';
export * from '@wawjs/ngx-prime/types/inputmask';
import * as _angular_core from '@angular/core';
import { TemplateRef, ElementRef } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import { BaseInput } from '@wawjs/ngx-prime/baseinput';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class InputMaskStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-variant-filled': boolean;
        })[];
        clearIcon: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InputMaskStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<InputMaskStyle>;
}
/**
 *
 * InputMask component is used to enter input in a certain format such as numeric, date, currency, email and phone.
 *
 * [Live Demo](https://www.ngx-prime.org/inputmask/)
 *
 * @module inputmaskstyle
 *
 */
declare enum InputMaskClasses {
    /**
     * Class name of the root element
     */
    root = "p-inputmask",
    /**
     * Class name of the clear icon element
     */
    clearIcon = "p-inputmask-clear-icon"
}

/**
 * InputMask directive is applied directly to input elements to enable masked input.
 * @group Components
 */
declare class InputMaskDirective extends BaseComponent<InputMaskPassThrough> {
    $pcInputMaskDirective: InputMaskDirective | undefined;
    _componentStyle: InputMaskStyle;
    /**
     * Used to pass attributes to DOM elements inside the InputMask directive.
     * @defaultValue undefined
     * @group Props
     */
    pInputMaskPT: _angular_core.InputSignal<any>;
    /**
     * Indicates whether the component should be rendered without styles.
     * @defaultValue undefined
     * @group Props
     */
    pInputMaskUnstyled: _angular_core.InputSignal<boolean | undefined>;
    /**
     * Mask pattern.
     * @group Props
     */
    pInputMask: _angular_core.InputSignal<string | undefined>;
    /**
     * Placeholder character in mask, default is underscore.
     * @group Props
     */
    slotChar: _angular_core.InputSignal<string>;
    /**
     * Clears the incomplete value on blur.
     * @group Props
     */
    autoClear: _angular_core.InputSignalWithTransform<boolean, boolean>;
    /**
     * Regex pattern for alpha characters.
     * @group Props
     */
    characterPattern: _angular_core.InputSignal<string>;
    /**
     * When present, it specifies that whether to clean buffer value from model.
     * @group Props
     */
    keepBuffer: _angular_core.InputSignalWithTransform<boolean, boolean>;
    /**
     * Callback to invoke when the mask is completed.
     * @group Emits
     */
    onCompleteEvent: _angular_core.OutputEmitterRef<void>;
    /**
     * Callback to invoke when value changes, emits unmasked value.
     * @group Emits
     */
    onUnmaskedChange: _angular_core.OutputEmitterRef<string>;
    /** Signals that a Signal Forms field has been touched. */
    touch: _angular_core.OutputEmitterRef<void>;
    defs: Nullable<{
        [klass: string]: any;
    }>;
    tests: RegExp[] | any;
    partialPosition: Nullable<number>;
    firstNonMaskPos: Nullable<number>;
    lastRequiredNonMaskPos: Nullable<number>;
    len: Nullable<number>;
    oldVal: Nullable<string>;
    buffer: string[] | any;
    defaultBuffer: Nullable<string>;
    focusText: Nullable<string>;
    caretTimeoutId: any;
    androidChrome: boolean;
    focused: Nullable<boolean>;
    private _inputElement;
    private _listeners;
    private isInputVisible;
    private get inputElement();
    constructor();
    onAfterViewInit(): void;
    onDestroy(): void;
    initMask(): void;
    onInputFocus(): void;
    onInputBlur(): void;
    onInputKeydown(e: KeyboardEvent): void;
    onKeyPress(e: KeyboardEvent): void;
    onInputChange(event: Event): void;
    onPaste(): void;
    caret(first?: number, last?: number): Caret | undefined;
    isCompleted(): boolean;
    getPlaceholder(i: number): string;
    seekNext(pos: number): number;
    seekPrev(pos: number): number;
    shiftL(begin: number, end: number): void;
    shiftR(pos: number): void;
    handleAndroidInput(): void;
    handleInputChange(): void;
    clearBuffer(start: number, end: number): void;
    writeBuffer(): void;
    /**
     * Dispatches an input event on the host element.
     * This is needed to notify parent components of value changes
     * since programmatic value changes don't trigger native input events.
     */
    dispatchInputEvent(): void;
    checkVal(allow?: boolean): number;
    getUnmaskedValue(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InputMaskDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<InputMaskDirective, "[pInputMask]", never, { "pInputMaskPT": { "alias": "pInputMaskPT"; "required": false; "isSignal": true; }; "pInputMaskUnstyled": { "alias": "pInputMaskUnstyled"; "required": false; "isSignal": true; }; "pInputMask": { "alias": "pInputMask"; "required": false; "isSignal": true; }; "slotChar": { "alias": "slotChar"; "required": false; "isSignal": true; }; "autoClear": { "alias": "autoClear"; "required": false; "isSignal": true; }; "characterPattern": { "alias": "characterPattern"; "required": false; "isSignal": true; }; "keepBuffer": { "alias": "keepBuffer"; "required": false; "isSignal": true; }; }, { "onCompleteEvent": "onComplete"; "onUnmaskedChange": "onUnmaskedChange"; "touch": "touch"; }, never, never, true, never>;
}
declare const INPUTMASK_VALUE_ACCESSOR: any;
/**
 * InputMask component is used to enter input in a certain format such as numeric, date, currency, email and phone.
 *
 * @deprecated Use a native `<input pInputMask>` instead. Native attributes
 * replace wrapper-only styling and clear-icon APIs. This component remains
 * available for compatibility and is planned for removal in v23.
 * @group Components
 */
declare class InputMask extends BaseInput<InputMaskPassThrough> {
    componentName: string;
    _componentStyle: InputMaskStyle;
    $pcInputMask: InputMask | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    ptmParams: _angular_core.Signal<{
        context: {
            filled: boolean;
        };
    }>;
    /**
     * HTML5 input type.
     * @group Props
     */
    type: _angular_core.InputSignal<string>;
    /**
     * Placeholder character in mask, default is underscore.
     * @group Props
     */
    slotChar: _angular_core.InputSignal<string>;
    /**
     * Clears the incomplete value on blur.
     * @group Props
     */
    autoClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When enabled, a clear icon is displayed to clear the value.
     * @group Props
     */
    showClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Inline style of the input field.
     * @group Props
     */
    style: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Identifier of the focus input to match a label defined for the component.
     * @group Props
     */
    inputId: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the input field.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Advisory information to display on input.
     * @group Props
     */
    placeholder: _angular_core.InputSignal<string | undefined>;
    /**
     * Specifies tab order of the element.
     * @group Props
     */
    tabindex: _angular_core.InputSignal<string | undefined>;
    /**
     * Title text of the input text.
     * @group Props
     */
    title: _angular_core.InputSignal<string | undefined>;
    /**
     * Used to define a string that labels the input element.
     * @group Props
     */
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Used to indicate that user input is required on an element before a form can be submitted.
     * @group Props
     */
    ariaRequired: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When present, it specifies that an input field is read-only.
     * @group Props
     */
    readonly: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Defines if ngModel sets the raw unmasked value to bound value or the formatted mask value.
     * @group Props
     */
    unmask: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Regex pattern for alpha characters
     * @group Props
     */
    characterPattern: _angular_core.InputSignal<string>;
    /**
     * When present, the input gets a focus automatically on load.
     * @group Props
     */
    autofocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Used to define a string that autocomplete attribute the current element.
     * @group Props
     */
    autocomplete: _angular_core.InputSignal<string | undefined>;
    /**
     * When present, it specifies that whether to clean buffer value from model.
     * @group Props
     */
    keepBuffer: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Mask pattern.
     * @group Props
     */
    mask: _angular_core.InputSignal<string | null | undefined>;
    /**
     * Callback to invoke when the mask is completed.
     * @group Emits
     */
    onComplete: _angular_core.OutputEmitterRef<any>;
    /**
     * Callback to invoke when the component receives focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onFocus: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke when the component loses focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onBlur: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke on input.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onInput: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke on input key press.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onKeydown: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke when input field is cleared.
     * @group Emits
     */
    onClear: _angular_core.OutputEmitterRef<any>;
    /**
     * Custom clear icon template.
     * @group Templates
     */
    clearIconTemplate: Nullable<TemplateRef<void>>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    inputViewChild: Nullable<ElementRef>;
    value: Nullable<string>;
    input: Nullable<HTMLInputElement>;
    defs: Nullable<{
        [klass: string]: any;
    }>;
    tests: RegExp[] | any;
    partialPosition: Nullable<number>;
    firstNonMaskPos: Nullable<number>;
    lastRequiredNonMaskPos: Nullable<number>;
    len: Nullable<number>;
    oldVal: Nullable<string>;
    buffer: string[] | any;
    defaultBuffer: Nullable<string>;
    focusText: Nullable<string>;
    caretTimeoutId: any;
    androidChrome: boolean;
    focused: Nullable<boolean>;
    constructor();
    onInit(): void;
    _clearIconTemplate: TemplateRef<void> | undefined;
    onAfterContentInit(): void;
    initMask(): void;
    caret(first?: number, last?: number): Caret | undefined;
    isCompleted(): boolean;
    getPlaceholder(i: number): string;
    seekNext(pos: number): number;
    seekPrev(pos: number): number;
    shiftL(begin: number, end: number): void;
    shiftR(pos: number): void;
    handleAndroidInput(e: Event): void;
    onInputBlur(e: Event): void;
    onInputKeydown(e: KeyboardEvent): void;
    onKeyPress(e: KeyboardEvent): void;
    clearBuffer(start: number, end: number): void;
    writeBuffer(): void;
    checkVal(allow?: boolean): number;
    onInputFocus(event: Event): void;
    onInputChange(event: Event): void;
    handleInputChange(event: Event): void;
    getUnmaskedValue(): string;
    updateModel(e: Event): void;
    focus(): void;
    clear(): void;
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value: any, setModelValue: (value: any) => void): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InputMask, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<InputMask, "p-inputmask, p-inputMask, p-input-mask", never, { "type": { "alias": "type"; "required": false; "isSignal": true; }; "slotChar": { "alias": "slotChar"; "required": false; "isSignal": true; }; "autoClear": { "alias": "autoClear"; "required": false; "isSignal": true; }; "showClear": { "alias": "showClear"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "ariaRequired": { "alias": "ariaRequired"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "unmask": { "alias": "unmask"; "required": false; "isSignal": true; }; "characterPattern": { "alias": "characterPattern"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; "keepBuffer": { "alias": "keepBuffer"; "required": false; "isSignal": true; }; "mask": { "alias": "mask"; "required": false; "isSignal": true; }; }, { "onComplete": "onComplete"; "onFocus": "onFocus"; "onBlur": "onBlur"; "onInput": "onInput"; "onKeydown": "onKeydown"; "onClear": "onClear"; }, ["templates", "clearIconTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class InputMaskModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InputMaskModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<InputMaskModule, never, [typeof InputMask, typeof InputMaskDirective, typeof i2.SharedModule], [typeof InputMask, typeof InputMaskDirective, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<InputMaskModule>;
}

export { INPUTMASK_VALUE_ACCESSOR, InputMask, InputMaskClasses, InputMaskDirective, InputMaskModule, InputMaskStyle };
