import * as _angular_core from '@angular/core';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { SkeletonPassThrough } from '@wawjs/ngx-prime/types/skeleton';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i2 from '@wawjs/ngx-prime/api';

declare class SkeletonStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-skeleton-circle': boolean;
            'p-skeleton-animation-none': boolean;
        })[];
    };
    inlineStyles: {
        root: {
            position: string;
        };
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkeletonStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SkeletonStyle>;
}
/**
 *
 * Skeleton is a placeholder to display instead of the actual content.
 *
 * [Live Demo](https://www.ngx-prime.org/skeleton/)
 *
 * @module skeletonstyle
 *
 */
declare enum SkeletonClasses {
    /**
     * Class name of the root element
     */
    root = "p-skeleton"
}

/**
 * Skeleton is a placeholder to display instead of the actual content.
 * @group Components
 */
declare class Skeleton extends BaseComponent<SkeletonPassThrough> {
    componentName: string;
    $pcSkeleton: Skeleton | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Shape of the element.
     * @group Props
     */
    shape: _angular_core.InputSignal<string>;
    /**
     * Type of the animation.
     * @gruop Props
     */
    animation: _angular_core.InputSignal<string>;
    /**
     * Border radius of the element, defaults to value from theme.
     * @group Props
     */
    borderRadius: _angular_core.InputSignal<string | undefined>;
    /**
     * Size of the skeleton.
     * @group Props
     */
    size: _angular_core.InputSignal<string | undefined>;
    /**
     * Width of the element.
     * @group Props
     */
    width: _angular_core.InputSignal<string>;
    /**
     * Height of the element.
     * @group Props
     */
    height: _angular_core.InputSignal<string>;
    _componentStyle: SkeletonStyle;
    get containerStyle(): any;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Skeleton, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Skeleton, "p-skeleton", never, { "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "shape": { "alias": "shape"; "required": false; "isSignal": true; }; "animation": { "alias": "animation"; "required": false; "isSignal": true; }; "borderRadius": { "alias": "borderRadius"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class SkeletonModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SkeletonModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<SkeletonModule, never, [typeof Skeleton, typeof i2.SharedModule], [typeof Skeleton, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<SkeletonModule>;
}

export { Skeleton, SkeletonClasses, SkeletonModule, SkeletonStyle };
