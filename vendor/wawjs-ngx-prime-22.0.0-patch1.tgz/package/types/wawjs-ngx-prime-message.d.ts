import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';
import { MotionOptions } from '@wawjs/css-prime-motion';
import * as i2 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { MessagePassThrough, MessageContainerTemplateContext } from '@wawjs/ngx-prime/types/message';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class MessageStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => any[];
        contentWrapper: string;
        content: string;
        icon: string;
        text: string;
        closeButton: string;
        closeIcon: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MessageStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<MessageStyle>;
}
/**
 *
 * Message groups a collection of contents in tabs.
 *
 * [Live Demo](https://www.ngx-prime.org/message/)
 *
 * @module messagestyle
 *
 */
declare enum MessageClasses {
    /**
     * Class name of the root element
     */
    root = "p-message",
    /**
     * Class name of the content element
     */
    content = "p-message-content",
    /**
     * Class name of the icon element
     */
    icon = "p-message-icon",
    /**
     * Class name of the text element
     */
    text = "p-message-text",
    /**
     * Class name of the close button element
     */
    closeButton = "p-message-close-button",
    /**
     * Class name of the close icon element
     */
    closeIcon = "p-message-close-icon"
}

/**
 * Message groups a collection of contents in tabs.
 * @group Components
 */
declare class Message extends BaseComponent<MessagePassThrough> {
    componentName: string;
    _componentStyle: MessageStyle;
    bindDirectiveInstance: Bind;
    $pcMessage: Message | undefined;
    onAfterViewChecked(): void;
    /**
     * Severity level of the message.
     * @defaultValue 'info'
     * @group Props
     */
    severity: _angular_core.InputSignal<"success" | "info" | "warn" | "error" | "secondary" | "contrast" | null | undefined>;
    /**
     * Text content.
     * @deprecated since v20.0.0. Use content projection instead '<p-message>Content</p-message>'.
     * @group Props
     */
    text: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether displaying messages would be escaped or not.
     * @deprecated since v20.0.0. Use content projection instead '<p-message>Content</p-message>'.
     * @group Props
     */
    escape: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Inline style of the component.
     * @group Props
     */
    style: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the component.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether the message can be closed manually using the close icon.
     * @group Props
     * @defaultValue false
     */
    closable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Icon to display in the message.
     * @group Props
     * @defaultValue undefined
     */
    icon: _angular_core.InputSignal<string | undefined>;
    /**
     * Icon to display in the message close button.
     * @group Props
     * @defaultValue undefined
     */
    closeIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Delay in milliseconds to close the message automatically.
     * @defaultValue undefined
     */
    life: _angular_core.InputSignal<number | undefined>;
    /**
     * Transition options of the show animation.
     * @defaultValue '300ms ease-out'
     * @group Props
     * @deprecated since v21.0.0, use `motionOptions` instead.
     */
    showTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * Transition options of the hide animation.
     * @defaultValue '200ms cubic-bezier(0.86, 0, 0.07, 1)'
     * @group Props
     * @deprecated since v21.0.0, use `motionOptions` instead.
     */
    hideTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * Defines the size of the component.
     * @group Props
     */
    size: _angular_core.InputSignal<"small" | "large" | undefined>;
    /**
     * Specifies the input variant of the component.
     * @group Props
     */
    variant: _angular_core.InputSignal<"outlined" | "text" | "simple" | undefined>;
    /**
     * The motion options.
     * @group Props
     */
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    computedMotionOptions: _angular_core.Signal<MotionOptions>;
    /**
     * Emits when the message is closed.
     * @param {{ originalEvent: Event }} event - The event object containing the original event.
     * @group Emits
     */
    onClose: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
    }>;
    get closeAriaLabel(): string | undefined;
    visible: _angular_core.WritableSignal<boolean>;
    /**
     * Custom template of the message container.
     * @param {MessageContainerTemplateContext} context - container context.
     * @see {@link MessageContainerTemplateContext}
     * @group Templates
     */
    containerTemplate: TemplateRef<MessageContainerTemplateContext> | undefined;
    /**
     * Custom template of the message icon.
     * @group Templates
     */
    iconTemplate: TemplateRef<void> | undefined;
    /**
     * Custom template of the close icon.
     * @group Templates
     */
    closeIconTemplate: TemplateRef<void> | undefined;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _containerTemplate: TemplateRef<MessageContainerTemplateContext> | undefined;
    _iconTemplate: TemplateRef<void> | undefined;
    _closeIconTemplate: TemplateRef<void> | undefined;
    closeCallback: (event: Event) => void;
    onInit(): void;
    onAfterContentInit(): void;
    /**
     * Closes the message.
     * @param {Event} event - Browser event.
     * @group Method
     */
    close(event: Event): void;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Message, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Message, "p-message", never, { "severity": { "alias": "severity"; "required": false; "isSignal": true; }; "text": { "alias": "text"; "required": false; "isSignal": true; }; "escape": { "alias": "escape"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "closable": { "alias": "closable"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "closeIcon": { "alias": "closeIcon"; "required": false; "isSignal": true; }; "life": { "alias": "life"; "required": false; "isSignal": true; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; "isSignal": true; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; }, { "onClose": "onClose"; }, ["templates", "containerTemplate", "iconTemplate", "closeIconTemplate"], ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class MessageModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MessageModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<MessageModule, never, [typeof Message, typeof i2.SharedModule], [typeof Message, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<MessageModule>;
}

export { Message, MessageClasses, MessageModule, MessageStyle };
