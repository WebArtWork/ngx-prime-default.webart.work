import * as _angular_core from '@angular/core';
import { ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import * as i1 from '@wawjs/ngx-prime/api';
import { MenuItem } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import { Subscription } from 'rxjs';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class StepsStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-readonly': any;
        })[];
        list: string;
        item: ({ instance, item, index }: {
            instance: any;
            item: any;
            index: any;
        }) => (string | {
            'p-steps-item-active': any;
            'p-disabled': any;
        })[];
        itemLink: string;
        itemNumber: string;
        itemLabel: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<StepsStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<StepsStyle>;
}
/**
 *
 * Steps components is an indicator for the steps in a wizard workflow. Example below uses nested routes with Steps.
 *
 * [Live Demo](https://www.ngx-prime.org/steps/)
 *
 * @module stepsstyle
 *
 */
declare enum StepsClasses {
    /**
     * Class name of the root element
     */
    root = "p-steps",
    /**
     * Class name of the list element
     */
    list = "p-steps-list",
    /**
     * Class name of the item element
     */
    item = "p-steps-item",
    /**
     * Class name of the item link element
     */
    itemLink = "p-steps-item-link",
    /**
     * Class name of the item number element
     */
    itemNumber = "p-steps-item-number",
    /**
     * Class name of the item label element
     */
    itemLabel = "p-steps-item-label"
}

/**
 * Steps components is an indicator for the steps in a wizard workflow.
 * @group Components
 */
declare class Steps extends BaseComponent {
    componentName: string;
    /**
     * Index of the active item.
     * @group Props
     */
    activeIndex: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * An array of menu items.
     * @group Props
     */
    model: _angular_core.InputSignal<MenuItem[] | undefined>;
    /**
     * Whether the items are clickable or not.
     * @group Props
     */
    readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Inline style of the component.
     * @group Props
     */
    style: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the component.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to apply 'router-link-active-exact' class if route exactly matches the item path.
     * @group Props
     */
    exact: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Callback to invoke when the new step is selected.
     * @param {number} number - current index.
     * @group Emits
     */
    activeIndexChange: _angular_core.OutputEmitterRef<number>;
    readonly listViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    router: Router;
    route: ActivatedRoute;
    _componentStyle: StepsStyle;
    subscription: Subscription | undefined;
    onInit(): void;
    onItemClick(event: Event, item: MenuItem, i: number): void;
    onItemKeydown(event: KeyboardEvent, item: MenuItem, i: number): void;
    navigateToNextItem(target: any): void;
    navigateToPrevItem(target: any): void;
    navigateToFirstItem(target: any): void;
    navigateToLastItem(target: any): void;
    findNextItem(item: any): any;
    findPrevItem(item: any): any;
    findFirstItem(): Element | null;
    findLastItem(): Element | null;
    setFocusToMenuitem(target: any, focusableItem: any): void;
    isClickableRouterLink(item: MenuItem): any;
    isItemDisabled(item: MenuItem, index: number): boolean;
    isActive(item: MenuItem, index: number): boolean;
    getItemTabIndex(item: MenuItem, index: number): string;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Steps, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Steps, "p-steps", never, { "activeIndex": { "alias": "activeIndex"; "required": false; "isSignal": true; }; "model": { "alias": "model"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "exact": { "alias": "exact"; "required": false; "isSignal": true; }; }, { "activeIndexChange": "activeIndexChange"; }, never, never, true, never>;
}
declare class StepsModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<StepsModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<StepsModule, never, [typeof Steps, typeof i1.SharedModule], [typeof Steps, typeof i1.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<StepsModule>;
}

export { Steps, StepsClasses, StepsModule, StepsStyle };
