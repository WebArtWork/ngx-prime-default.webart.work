import * as i0 from '@angular/core';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { AvatarGroupPassThrough } from '@wawjs/ngx-prime/types/avatargroup';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i2 from '@wawjs/ngx-prime/api';

declare class AvatarGroupStyle extends BaseStyle {
    name: string;
    classes: {
        root: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<AvatarGroupStyle, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AvatarGroupStyle>;
}
/**
 *
 * A set of Avatars can be displayed together using the AvatarGroup component.
 *
 * [Live Demo](https://www.ngx-prime.org/avatar/)
 *
 * @module avatargroupstyle
 *
 */
declare enum AvatarGroupClasses {
    root = "p-avatar-group"
}

/**
 * AvatarGroup is a helper component for Avatar.
 * @group Components
 */
declare class AvatarGroup extends BaseComponent<AvatarGroupPassThrough> {
    componentName: string;
    $pcAvatarGroup: AvatarGroup | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Style class of the component
     * @group Props
     */
    styleClass: i0.InputSignal<string | undefined>;
    /**
     * Inline style of the component.
     * @group Props
     */
    style: i0.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    _componentStyle: AvatarGroupStyle;
    static ɵfac: i0.ɵɵFactoryDeclaration<AvatarGroup, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AvatarGroup, "p-avatarGroup, p-avatar-group, p-avatargroup", never, { "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class AvatarGroupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AvatarGroupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AvatarGroupModule, never, [typeof AvatarGroup, typeof i2.SharedModule], [typeof AvatarGroup, typeof i2.SharedModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AvatarGroupModule>;
}

export { AvatarGroup, AvatarGroupClasses, AvatarGroupModule, AvatarGroupStyle };
