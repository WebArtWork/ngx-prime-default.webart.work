import { ButtonPassThrough, ButtonSeverity, ButtonProps, ButtonLoadingIconTemplateContext, ButtonIconTemplateContext } from '@wawjs/ngx-prime/types/button';
export * from '@wawjs/ngx-prime/types/button';
import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';
import * as i3 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Fluid } from '@wawjs/ngx-prime/fluid';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i2 from '@angular/common';

declare class ButtonStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            [x: string]: any;
            'p-button-icon-only': any;
            'p-button-vertical': any;
            'p-button-loading': any;
            'p-button-link': any;
            'p-button-raised': any;
            'p-button-rounded': any;
            'p-button-text': any;
            'p-button-outlined': any;
            'p-button-sm': boolean;
            'p-button-lg': boolean;
            'p-button-plain': any;
            'p-button-fluid': any;
        })[];
        loadingIcon: string;
        icon: ({ instance }: {
            instance: any;
        }) => any[];
        spinnerIcon: ({ instance }: {
            instance: any;
        }) => string;
        label: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ButtonStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ButtonStyle>;
}
/**
 *
 * Button is an extension to standard button element with icons and theming.
 *
 * [Live Demo](https://www.ngx-prime.org/button/)
 *
 * @module buttonstyle
 *
 */
declare enum ButtonClasses {
    /**
     * Class name of the root element
     */
    root = "p-button",
    /**
     * Class name of the loading icon element
     */
    loadingIcon = "p-button-loading-icon",
    /**
     * Class name of the icon element
     */
    icon = "p-button-icon",
    /**
     * Class name of the label element
     */
    label = "p-button-label"
}

type ButtonIconPosition = 'left' | 'right' | 'top' | 'bottom';
declare class ButtonLabel extends BaseComponent {
    componentName: string;
    /**
     * Used to pass attributes to DOM elements inside the pButtonLabel.
     * @defaultValue undefined
     * @deprecated use pButtonLabelPT instead.
     * @group Props
     */
    ptButtonLabel: _angular_core.InputSignal<any>;
    /**
     * Used to pass attributes to DOM elements inside the pButtonLabel.
     * @defaultValue undefined
     * @group Props
     */
    pButtonLabelPT: _angular_core.InputSignal<any>;
    /**
     * Indicates whether the component should be rendered without styles.
     * @defaultValue undefined
     * @group Props
     */
    pButtonLabelUnstyled: _angular_core.InputSignal<boolean | undefined>;
    $pcButtonLabel: ButtonLabel | undefined;
    bindDirectiveInstance: Bind;
    constructor();
    onAfterViewChecked(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ButtonLabel, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ButtonLabel, "[pButtonLabel]", never, { "ptButtonLabel": { "alias": "ptButtonLabel"; "required": false; "isSignal": true; }; "pButtonLabelPT": { "alias": "pButtonLabelPT"; "required": false; "isSignal": true; }; "pButtonLabelUnstyled": { "alias": "pButtonLabelUnstyled"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class ButtonIcon extends BaseComponent {
    componentName: string;
    /**
     * Used to pass attributes to DOM elements inside the pButtonIcon.
     * @defaultValue undefined
     * @deprecated use pButtonIconPT instead.
     * @group Props
     */
    ptButtonIcon: _angular_core.InputSignal<any>;
    /**
     * Used to pass attributes to DOM elements inside the pButtonIcon.
     * @defaultValue undefined
     * @group Props
     */
    pButtonIconPT: _angular_core.InputSignal<any>;
    /**
     * Indicates whether the component should be rendered without styles.
     * @defaultValue undefined
     * @group Props
     */
    pButtonUnstyled: _angular_core.InputSignal<boolean | undefined>;
    $pcButtonIcon: ButtonIcon | undefined;
    bindDirectiveInstance: Bind;
    constructor();
    onAfterViewChecked(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ButtonIcon, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ButtonIcon, "[pButtonIcon]", never, { "ptButtonIcon": { "alias": "ptButtonIcon"; "required": false; "isSignal": true; }; "pButtonIconPT": { "alias": "pButtonIconPT"; "required": false; "isSignal": true; }; "pButtonUnstyled": { "alias": "pButtonUnstyled"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
/**
 * Button directive is an extension to button component.
 * @group Components
 */
declare class ButtonDirective extends BaseComponent {
    componentName: string;
    $pcButtonDirective: ButtonDirective | undefined;
    bindDirectiveInstance: Bind;
    _componentStyle: ButtonStyle;
    /**
     * Used to pass attributes to DOM elements inside the Button component.
     * @defaultValue undefined
     * @deprecated use pButtonPT instead.
     * @group Props
     */
    ptButtonDirective: _angular_core.InputSignal<ButtonPassThrough>;
    /**
     * Used to pass attributes to DOM elements inside the Button component.
     * @defaultValue undefined
     * @group Props
     */
    pButtonPT: _angular_core.InputSignal<ButtonPassThrough>;
    /**
     * Indicates whether the component should be rendered without styles.
     * @defaultValue undefined
     * @group Props
     */
    pButtonUnstyled: _angular_core.InputSignal<boolean | undefined>;
    readonly hostName: _angular_core.InputSignal<any>;
    onAfterViewChecked(): void;
    constructor();
    /**
     * Add a textual class to the button without a background initially.
     * @group Props
     */
    readonly text: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Add a plain textual class to the button without a background initially.
     * @group Props
     */
    readonly plain: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Add a shadow to indicate elevation.
     * @group Props
     */
    readonly raised: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Defines the size of the button.
     * @group Props
     */
    readonly size: _angular_core.InputSignal<"small" | "large" | undefined>;
    /**
     * Add a border class without a background initially.
     * @group Props
     */
    readonly outlined: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Add a circular border radius to the button.
     * @group Props
     */
    readonly rounded: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Position of the icon.
     * @group Props
     */
    readonly iconPos: _angular_core.InputSignal<ButtonIconPosition>;
    /**
     * Icon to display in loading state.
     * @group Props
     */
    readonly loadingIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Spans 100% width of the container when enabled.
     * @defaultValue undefined
     * @group Props
     */
    fluid: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    private iconSignal;
    private labelSignal;
    isIconOnly: _angular_core.Signal<boolean>;
    _label: string | undefined;
    _icon: string | undefined;
    _loading: boolean;
    private _severity;
    _buttonProps: ButtonProps;
    initialized: boolean | undefined;
    private get htmlElement();
    private _internalClasses;
    pcFluid: Fluid | null;
    isTextButton: _angular_core.Signal<boolean>;
    /**
     * Text of the button.
     * @deprecated use pButtonLabel directive instead.
     * @group Props
     */
    readonly label: _angular_core.InputSignal<string | undefined>;
    /**
     * Name of the icon.
     * @deprecated use pButtonIcon directive instead
     * @group Props
     */
    readonly icon: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether the button is in loading state.
     * @group Props
     */
    readonly loading: _angular_core.InputSignal<boolean>;
    /**
     * Used to pass all properties of the ButtonProps to the Button component.
     * @deprecated assign props directly to the button element.
     * @group Props
     */
    readonly buttonProps: _angular_core.InputSignal<ButtonProps | undefined>;
    /**
     * Defines the style of the button.
     * @group Props
     */
    readonly severity: _angular_core.InputSignal<ButtonSeverity>;
    spinnerIcon: string;
    onAfterViewInit(): void;
    getStyleClass(): string[];
    get hasFluid(): boolean;
    setStyleClass(): void;
    removeExistingSeverityClass(): void;
    createLabel(): void;
    createIcon(): void;
    updateLabel(): void;
    updateIcon(): void;
    getIconClass(): string;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ButtonDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ButtonDirective, "[pButton]", never, { "ptButtonDirective": { "alias": "ptButtonDirective"; "required": false; "isSignal": true; }; "pButtonPT": { "alias": "pButtonPT"; "required": false; "isSignal": true; }; "pButtonUnstyled": { "alias": "pButtonUnstyled"; "required": false; "isSignal": true; }; "hostName": { "alias": "hostName"; "required": false; "isSignal": true; }; "text": { "alias": "text"; "required": false; "isSignal": true; }; "plain": { "alias": "plain"; "required": false; "isSignal": true; }; "raised": { "alias": "raised"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "outlined": { "alias": "outlined"; "required": false; "isSignal": true; }; "rounded": { "alias": "rounded"; "required": false; "isSignal": true; }; "iconPos": { "alias": "iconPos"; "required": false; "isSignal": true; }; "loadingIcon": { "alias": "loadingIcon"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "buttonProps": { "alias": "buttonProps"; "required": false; "isSignal": true; }; "severity": { "alias": "severity"; "required": false; "isSignal": true; }; }, {}, ["iconSignal", "labelSignal"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
/**
 * Button is an extension to standard button element with icons and theming.
 *
 * @deprecated Use a native `<button pButton>` instead. This component remains
 * available for compatibility and is planned for removal in v23.
 * @group Components
 */
declare class Button extends BaseComponent<ButtonPassThrough> {
    componentName: string;
    readonly hostName: _angular_core.InputSignal<any>;
    $pcButton: Button | undefined;
    bindDirectiveInstance: Bind;
    _componentStyle: ButtonStyle;
    onAfterViewChecked(): void;
    /**
     * Type of the button.
     * @group Props
     */
    readonly type: _angular_core.InputSignal<string>;
    /**
     * Value of the badge.
     * @group Props
     */
    readonly badge: _angular_core.InputSignal<string | undefined>;
    /**
     * When present, it specifies that the component should be disabled.
     * @group Props
     */
    readonly disabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Add a shadow to indicate elevation.
     * @group Props
     */
    readonly raised: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Add a circular border radius to the button.
     * @group Props
     */
    readonly rounded: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Add a textual class to the button without a background initially.
     * @group Props
     */
    readonly text: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Add a plain textual class to the button without a background initially.
     * @group Props
     */
    readonly plain: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Add a border class without a background initially.
     * @group Props
     */
    readonly outlined: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Add a link style to the button.
     * @group Props
     */
    readonly link: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Add a tabindex to the button.
     * @group Props
     */
    readonly tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Defines the size of the button.
     * @group Props
     */
    readonly size: _angular_core.InputSignal<"small" | "large" | undefined>;
    /**
     * Specifies the variant of the component.
     * @group Props
     */
    readonly variant: _angular_core.InputSignal<"text" | "outlined" | undefined>;
    /**
     * Inline style of the element.
     * @group Props
     */
    readonly style: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Class of the element.
     * @group Props
     */
    readonly styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the badge.
     * @group Props
     * @deprecated use badgeSeverity instead.
     */
    readonly badgeClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Severity type of the badge.
     * @group Props
     * @defaultValue secondary
     */
    readonly badgeSeverity: _angular_core.InputSignal<"success" | "info" | "warn" | "danger" | "help" | "primary" | "secondary" | "contrast" | null | undefined>;
    /**
     * Used to define a string that autocomplete attribute the current element.
     * @group Props
     */
    readonly ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    readonly autofocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Position of the icon.
     * @group Props
     */
    readonly iconPos: _angular_core.InputSignal<ButtonIconPosition>;
    /**
     * Name of the icon.
     * @group Props
     */
    readonly icon: _angular_core.InputSignal<string | undefined>;
    /**
     * Text of the button.
     * @group Props
     */
    readonly label: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether the button is in loading state.
     * @group Props
     */
    readonly loading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Icon to display in loading state.
     * @group Props
     */
    readonly loadingIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines the style of the button.
     * @group Props
     */
    readonly severity: _angular_core.InputSignal<ButtonSeverity>;
    /**
     * Used to pass all properties of the ButtonProps to the Button component.
     * @group Props
     */
    readonly buttonProps: _angular_core.InputSignal<ButtonProps | undefined>;
    /**
     * Spans 100% width of the container when enabled.
     * @defaultValue undefined
     * @group Props
     */
    fluid: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Callback to execute when button is clicked.
     * This event is intended to be used with the <p-button> component. Using a regular <button> element, use (click).
     * @param {MouseEvent} event - Mouse event.
     * @group Emits
     */
    readonly onClick: _angular_core.OutputEmitterRef<MouseEvent>;
    /**
     * Callback to execute when button is focused.
     * This event is intended to be used with the <p-button> component. Using a regular <button> element, use (focus).
     * @param {FocusEvent} event - Focus event.
     * @group Emits
     */
    readonly onFocus: _angular_core.OutputEmitterRef<FocusEvent>;
    /**
     * Callback to execute when button loses focus.
     * This event is intended to be used with the <p-button> component. Using a regular <button> element, use (blur).
     * @param {FocusEvent} event - Focus event.
     * @group Emits
     */
    readonly onBlur: _angular_core.OutputEmitterRef<FocusEvent>;
    /**
     * Custom content template.
     * @group Templates
     **/
    readonly contentTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom loading icon template.
     * @group Templates
     **/
    readonly loadingIconTemplate: _angular_core.Signal<TemplateRef<ButtonLoadingIconTemplateContext> | undefined>;
    /**
     * Custom icon template.
     * @group Templates
     **/
    readonly iconTemplate: _angular_core.Signal<TemplateRef<ButtonIconTemplateContext> | undefined>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    pcFluid: Fluid | null;
    get hasFluid(): boolean;
    get hasIcon(): string | TemplateRef<ButtonLoadingIconTemplateContext> | undefined;
    _contentTemplate: TemplateRef<void> | undefined;
    _iconTemplate: TemplateRef<ButtonIconTemplateContext> | undefined;
    _loadingIconTemplate: TemplateRef<ButtonLoadingIconTemplateContext> | undefined;
    onAfterContentInit(): void;
    get dataP(): string | undefined;
    get dataIconP(): string | undefined;
    get dataLabelP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Button, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Button, "p-button", never, { "hostName": { "alias": "hostName"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "badge": { "alias": "badge"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "raised": { "alias": "raised"; "required": false; "isSignal": true; }; "rounded": { "alias": "rounded"; "required": false; "isSignal": true; }; "text": { "alias": "text"; "required": false; "isSignal": true; }; "plain": { "alias": "plain"; "required": false; "isSignal": true; }; "outlined": { "alias": "outlined"; "required": false; "isSignal": true; }; "link": { "alias": "link"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "badgeClass": { "alias": "badgeClass"; "required": false; "isSignal": true; }; "badgeSeverity": { "alias": "badgeSeverity"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "iconPos": { "alias": "iconPos"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "loadingIcon": { "alias": "loadingIcon"; "required": false; "isSignal": true; }; "severity": { "alias": "severity"; "required": false; "isSignal": true; }; "buttonProps": { "alias": "buttonProps"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; }, { "onClick": "onClick"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, ["contentTemplate", "loadingIconTemplate", "iconTemplate", "templates"], ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class ButtonModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ButtonModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<ButtonModule, never, [typeof i2.CommonModule, typeof ButtonDirective, typeof Button, typeof i3.SharedModule, typeof ButtonLabel, typeof ButtonIcon], [typeof ButtonDirective, typeof Button, typeof ButtonLabel, typeof ButtonIcon, typeof i3.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<ButtonModule>;
}

export { Button, ButtonClasses, ButtonDirective, ButtonIcon, ButtonLabel, ButtonModule, ButtonStyle };
export type { ButtonIconPosition };
