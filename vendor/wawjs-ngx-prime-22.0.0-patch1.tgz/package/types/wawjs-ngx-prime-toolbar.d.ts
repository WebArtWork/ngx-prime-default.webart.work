import { ToolbarPassThrough } from '@wawjs/ngx-prime/types/toolbar';
export * from '@wawjs/ngx-prime/types/toolbar';
import * as i0 from '@angular/core';
import { TemplateRef } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { BlockableUI, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class ToolbarStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: () => string[];
        start: string;
        center: string;
        end: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarStyle, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ToolbarStyle>;
}
/**
 *
 * Toolbar is a grouping component for buttons and other content.
 *
 * [Live Demo](https://www.ngx-prime.org/toolbar/)
 *
 * @module toolbarstyle
 *
 */
declare enum ToolbarClasses {
    /**
     * Class name of the root element
     */
    root = "p-toolbar",
    /**
     * Class name of the start element
     */
    start = "p-toolbar-start",
    /**
     * Class name of the center element
     */
    center = "p-toolbar-center",
    /**
     * Class name of the end element
     */
    end = "p-toolbar-end"
}

/**
 * Toolbar is a grouping component for buttons and other content.
 * @group Components
 */
declare class Toolbar extends BaseComponent<ToolbarPassThrough> implements BlockableUI {
    componentName: string;
    $pcToolbar: Toolbar | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: i0.InputSignal<string | undefined>;
    /**
     * Defines a string value that labels an interactive element.
     * @group Props
     */
    ariaLabelledBy: i0.InputSignal<string | undefined>;
    _componentStyle: ToolbarStyle;
    getBlockableElement(): HTMLElement;
    /**
     * Custom start template.
     * @group Templates
     */
    startTemplate: TemplateRef<void> | undefined;
    /**
     * Custom end template.
     * @group Templates
     */
    endTemplate: TemplateRef<void> | undefined;
    /**
     * Custom center template.
     * @group Templates
     */
    centerTemplate: TemplateRef<void> | undefined;
    readonly templates: i0.Signal<readonly PrimeTemplate[]>;
    _startTemplate: TemplateRef<void> | undefined;
    _endTemplate: TemplateRef<void> | undefined;
    _centerTemplate: TemplateRef<void> | undefined;
    onAfterContentInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<Toolbar, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Toolbar, "p-toolbar", never, { "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; }, {}, ["templates", "startTemplate", "endTemplate", "centerTemplate"], ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class ToolbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ToolbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ToolbarModule, never, [typeof Toolbar, typeof i2.SharedModule, typeof i1.BindModule], [typeof Toolbar, typeof i2.SharedModule, typeof i1.BindModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ToolbarModule>;
}

export { Toolbar, ToolbarClasses, ToolbarModule, ToolbarStyle };
