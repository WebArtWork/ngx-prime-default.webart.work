import * as i0 from '@angular/core';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { InputIconPassThrough } from '@wawjs/ngx-prime/types/inputicon';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i2 from '@wawjs/ngx-prime/api';

declare class InputIconStyle extends BaseStyle {
    name: string;
    classes: {
        root: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<InputIconStyle, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InputIconStyle>;
}

/**
 * InputIcon displays an icon.
 * @group Components
 */
declare class InputIcon extends BaseComponent<InputIconPassThrough> {
    componentName: string;
    hostName: i0.InputSignal<any>;
    /**
     * Style class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: i0.InputSignal<string | undefined>;
    _componentStyle: InputIconStyle;
    $pcInputIcon: InputIcon | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InputIcon, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InputIcon, "p-inputicon, p-inputIcon", never, { "hostName": { "alias": "hostName"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class InputIconModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<InputIconModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<InputIconModule, never, [typeof InputIcon, typeof i2.SharedModule], [typeof InputIcon, typeof i2.SharedModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<InputIconModule>;
}

export { InputIcon, InputIconModule, InputIconStyle };
