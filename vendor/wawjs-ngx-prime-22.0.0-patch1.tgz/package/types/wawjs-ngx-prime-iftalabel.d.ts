import * as i0 from '@angular/core';
import { AfterViewChecked } from '@angular/core';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { IftaLabelPassThrough } from '@wawjs/ngx-prime/types/iftalabel';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i2 from '@angular/common';
import * as i3 from '@wawjs/ngx-prime/api';
import * as i4 from '@angular/router';

declare class IftaLabelStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<IftaLabelStyle, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IftaLabelStyle>;
}
/**
 *
 * IftaLabel visually integrates a label within its form element.
 *
 * [Live Demo](https://www.ngx-prime.org/iftalabel/)
 *
 * @module iftalabelstyle
 *
 */
declare enum IftaLabelClasses {
    /**
     * Class name of the root element
     */
    root = "p-iftalabel"
}

/**
 * IftaLabel is used to create infield top aligned labels.
 * @group Components
 */
declare class IftaLabel extends BaseComponent<IftaLabelPassThrough> implements AfterViewChecked {
    componentName: string;
    _componentStyle: IftaLabelStyle;
    $pcIftaLabel: IftaLabel | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IftaLabel, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IftaLabel, "p-iftalabel, p-iftaLabel, p-ifta-label", never, {}, {}, never, ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class IftaLabelModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<IftaLabelModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<IftaLabelModule, never, [typeof IftaLabel, typeof i2.CommonModule, typeof i3.SharedModule, typeof i4.RouterModule], [typeof IftaLabel, typeof i3.SharedModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<IftaLabelModule>;
}

export { IftaLabel, IftaLabelClasses, IftaLabelModule, IftaLabelStyle };
