import * as _angular_core from '@angular/core';
import { Injector, TemplateRef, ElementRef } from '@angular/core';
import * as i3 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseInput } from '@wawjs/ngx-prime/baseinput';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import { InputNumberInputEvent, InputNumberPassThrough } from '@wawjs/ngx-prime/types/inputnumber';
export * from '@wawjs/ngx-prime/types/inputnumber';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class InputNumberStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-inputwrapper-filled': any;
            'p-inputwrapper-focus': any;
            'p-inputnumber-stacked': any;
            'p-inputnumber-horizontal': any;
            'p-inputnumber-vertical': any;
            'p-inputnumber-fluid': any;
            'p-invalid': any;
        })[];
        pcInputText: string;
        buttonGroup: string;
        incrementButton: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-disabled': any;
        })[];
        decrementButton: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-disabled': any;
        })[];
        clearIcon: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InputNumberStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<InputNumberStyle>;
}
/**
 *
 * InputNumber is an input component to provide numerical input.
 *
 * [Live Demo](https://www.ngx-prime.org/inputnumber/)
 *
 * @module inputnumberstyle
 *
 */
declare enum InputNumberClasses {
    /**
     * Class name of the root element
     */
    root = "p-inputnumber",
    /**
     * Class name of the input element
     */
    pcInputText = "p-inputnumber-input",
    /**
     * Class name of the button group element
     */
    buttonGroup = "p-inputnumber-button-group",
    /**
     * Class name of the increment button element
     */
    incrementButton = "p-inputnumber-increment-button",
    /**
     * Class name of the decrement button element
     */
    decrementButton = "p-inputnumber-decrement-button",
    /**
     * Class name of the clear icon
     */
    clearIcon = "p-autocomplete-clear-icon"
}

/** Adds Prime state attributes to a native number input. */
declare class InputNumberDirective {
    private readonly element;
    invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    min: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    max: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    step: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    inputId: _angular_core.InputSignal<string | undefined>;
    name: _angular_core.InputSignal<string | undefined>;
    tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    placeholder: _angular_core.InputSignal<string | undefined>;
    title: _angular_core.InputSignal<string | undefined>;
    autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    ariaDescribedBy: _angular_core.InputSignal<string | undefined>;
    /** Signal Forms marks a field as touched when this emits after blur. */
    touch: _angular_core.OutputEmitterRef<void>;
    onInput: _angular_core.OutputEmitterRef<InputNumberInputEvent>;
    onFocus: _angular_core.OutputEmitterRef<Event>;
    onBlur: _angular_core.OutputEmitterRef<Event>;
    onKeyDown: _angular_core.OutputEmitterRef<KeyboardEvent>;
    $disabled(): boolean;
    get valueAsNumber(): number | null;
    onNativeInput(event: Event): void;
    onNativeBlur(event: Event): void;
    increment(steps?: number): void;
    decrement(steps?: number): void;
    focus(options?: FocusOptions): void;
    private stepBy;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InputNumberDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<InputNumberDirective, "input[type='number'][pInputNumber]", never, { "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "ariaDescribedBy": { "alias": "ariaDescribedBy"; "required": false; "isSignal": true; }; }, { "touch": "touch"; "onInput": "onInput"; "onFocus": "onFocus"; "onBlur": "onBlur"; "onKeyDown": "onKeyDown"; }, never, never, true, never>;
}

declare const INPUTNUMBER_VALUE_ACCESSOR: any;
/**
 * InputNumber is an input component to provide numerical input.
 *
 * @deprecated Use a native `<input type="number" pInputNumber>` instead.
 * Locale/currency formatting, prefixes/suffixes, and custom spinner/template
 * UI are wrapper-only features. This component remains available for
 * compatibility and is planned for removal in v23.
 * @group Components
 */
declare class InputNumber extends BaseInput<InputNumberPassThrough> {
    readonly injector: Injector;
    componentName: string;
    $pcInputNumber: InputNumber | undefined;
    _componentStyle: InputNumberStyle;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Displays spinner buttons.
     * @group Props
     */
    showButtons: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to format the value.
     * @group Props
     */
    format: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Layout of the buttons, valid values are "stacked" (default), "horizontal" and "vertical".
     * @group Props
     */
    buttonLayout: _angular_core.InputSignal<string>;
    /**
     * Identifier of the focus input to match a label defined for the component.
     * @group Props
     */
    inputId: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Advisory information to display on input.
     * @group Props
     */
    placeholder: _angular_core.InputSignal<string | undefined>;
    /**
     * Specifies tab order of the element.
     * @group Props
     */
    tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Title text of the input text.
     * @group Props
     */
    title: _angular_core.InputSignal<string | undefined>;
    /**
     * Specifies one or more IDs in the DOM that labels the input field.
     * @group Props
     */
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Specifies one or more IDs in the DOM that describes the input field.
     * @group Props
     */
    ariaDescribedBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Used to define a string that labels the input element.
     * @group Props
     */
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Used to indicate that user input is required on an element before a form can be submitted.
     * @group Props
     */
    ariaRequired: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Used to define a string that autocomplete attribute the current element.
     * @group Props
     */
    autocomplete: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the increment button.
     * @group Props
     */
    incrementButtonClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the decrement button.
     * @group Props
     */
    decrementButtonClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the increment button.
     * @group Props
     */
    incrementButtonIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the decrement button.
     * @group Props
     */
    decrementButtonIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * When present, it specifies that an input field is read-only.
     * @group Props
     */
    readonly: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Determines whether the input field is empty.
     * @group Props
     */
    allowEmpty: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Locale to be used in formatting.
     * @group Props
     */
    locale: _angular_core.InputSignal<string | undefined>;
    /**
     * The locale matching algorithm to use. Possible values are "lookup" and "best fit"; the default is "best fit". See Locale Negotiation for details.
     * @group Props
     */
    localeMatcher: _angular_core.InputSignal<any>;
    /**
     * Defines the behavior of the component, valid values are "decimal" and "currency".
     * @group Props
     */
    mode: _angular_core.InputSignal<any>;
    /**
     * The currency to use in currency formatting. Possible values are the ISO 4217 currency codes, such as "USD" for the US dollar, "EUR" for the euro, or "CNY" for the Chinese RMB. There is no default value; if the style is "currency", the currency property must be provided.
     * @group Props
     */
    currency: _angular_core.InputSignal<string | undefined>;
    /**
     * How to display the currency in currency formatting. Possible values are "symbol" to use a localized currency symbol such as â‚¬, Ã¼"code" to use the ISO currency code, "name" to use a localized currency name such as "dollar"; the default is "symbol".
     * @group Props
     */
    currencyDisplay: _angular_core.InputSignal<any>;
    /**
     * Whether to use grouping separators, such as thousands separators or thousand/lakh/crore separators.
     * @group Props
     */
    useGrouping: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * The minimum number of fraction digits to use. Possible values are from 0 to 20; the default for plain number and percent formatting is 0; the default for currency formatting is the number of minor unit digits provided by the ISO 4217 currency code list (2 if the list doesn't provide that information).
     * @group Props
     */
    minFractionDigits: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * The maximum number of fraction digits to use. Possible values are from 0 to 20; the default for plain number formatting is the larger of minimumFractionDigits and 3; the default for currency formatting is the larger of minimumFractionDigits and the number of minor unit digits provided by the ISO 4217 currency code list (2 if the list doesn't provide that information).
     * @group Props
     */
    maxFractionDigits: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Text to display before the value.
     * @group Props
     */
    prefix: _angular_core.InputSignal<string | undefined>;
    /**
     * Text to display after the value.
     * @group Props
     */
    suffix: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the input field.
     * @group Props
     */
    inputStyle: _angular_core.InputSignal<any>;
    /**
     * Style class of the input field.
     * @group Props
     */
    inputStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * When enabled, a clear icon is displayed to clear the value.
     * @group Props
     */
    showClear: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Callback to invoke on input.
     * @param {InputNumberInputEvent} event - Custom input event.
     * @group Emits
     */
    onInput: _angular_core.OutputEmitterRef<InputNumberInputEvent>;
    /**
     * Callback to invoke when the component receives focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onFocus: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke when the component loses focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onBlur: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke on input key press.
     * @param {KeyboardEvent} event - Keyboard event.
     * @group Emits
     */
    onKeyDown: _angular_core.OutputEmitterRef<KeyboardEvent>;
    /**
     * Callback to invoke when clear token is clicked.
     * @group Emits
     */
    onClear: _angular_core.OutputEmitterRef<void>;
    /**
     * Custom clear icon template.
     * @group Templates
     */
    clearIconTemplate: Nullable<TemplateRef<void>>;
    /**
     * Custom increment button icon template.
     * @group Templates
     */
    readonly incrementButtonIconTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    /**
     * Custom decrement button icon template.
     * @group Templates
     */
    readonly decrementButtonIconTemplate: _angular_core.Signal<Nullable<TemplateRef<void>>>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    readonly input: _angular_core.Signal<ElementRef<HTMLInputElement>>;
    _clearIconTemplate: TemplateRef<void> | undefined;
    _incrementButtonIconTemplate: TemplateRef<void> | undefined;
    _decrementButtonIconTemplate: TemplateRef<void> | undefined;
    value: Nullable<number>;
    focused: Nullable<boolean>;
    initialized: Nullable<boolean>;
    groupChar: string;
    prefixChar: string;
    suffixChar: string;
    isSpecialChar: Nullable<boolean>;
    timer: any;
    lastValue: Nullable<string>;
    _numeral: any;
    numberFormat: any;
    _decimal: any;
    _decimalChar: string;
    _group: any;
    _minusSign: any;
    _currency: Nullable<RegExp | string>;
    _prefix: Nullable<RegExp>;
    _suffix: Nullable<RegExp>;
    _index: number | any;
    private ngControl;
    constructor();
    onInit(): void;
    onAfterContentInit(): void;
    getOptions(): {
        localeMatcher: any;
        style: any;
        currency: string | undefined;
        currencyDisplay: any;
        useGrouping: boolean;
        minimumFractionDigits: number | undefined;
        maximumFractionDigits: number | undefined;
    };
    constructParser(): void;
    updateConstructParser(): void;
    escapeRegExp(text: string): string;
    getDecimalExpression(): RegExp;
    getDecimalChar(): string;
    getGroupingExpression(): RegExp;
    getMinusSignExpression(): RegExp;
    getCurrencyExpression(): RegExp;
    getPrefixExpression(): RegExp;
    getSuffixExpression(): RegExp;
    formatValue(value: any): any;
    parseValue(text: any): any;
    repeat(event: Event, interval: number | null, dir: number): void;
    spin(event: Event, dir: number): void;
    clear(): void;
    onUpButtonMouseDown(event: MouseEvent): void;
    onUpButtonMouseUp(): void;
    onUpButtonMouseLeave(): void;
    onUpButtonKeyDown(event: KeyboardEvent): void;
    onUpButtonKeyUp(): void;
    onDownButtonMouseDown(event: MouseEvent): void;
    onDownButtonMouseUp(): void;
    onDownButtonMouseLeave(): void;
    onDownButtonKeyUp(): void;
    onDownButtonKeyDown(event: KeyboardEvent): void;
    onUserInput(event: Event): void;
    onInputKeyDown(event: KeyboardEvent): void;
    onInputKeyPress(event: KeyboardEvent): void;
    onPaste(event: ClipboardEvent): void;
    allowMinusSign(): boolean;
    isMinusSign(char: string): boolean;
    isDecimalSign(char: string): boolean;
    isDecimalMode(): boolean;
    getDecimalCharIndexes(val: string): {
        decimalCharIndex: number;
        decimalCharIndexWithoutPrefix: number;
    };
    getCharIndexes(val: string): {
        decimalCharIndex: number;
        minusCharIndex: number;
        suffixCharIndex: number;
        currencyCharIndex: number;
    };
    insert(event: Event, text: string, sign?: {
        isDecimalSign: boolean;
        isMinusSign: boolean;
    }): void;
    insertText(value: string, text: string, start: number, end: number): any;
    deleteRange(value: string, start: number, end: number): any;
    initCursor(): any;
    onInputClick(): void;
    isNumeralChar(char: string): boolean;
    resetRegex(): void;
    updateValue(event: Event, valueStr: Nullable<string>, insertedValueStr: Nullable<string>, operation: Nullable<string>): void;
    handleOnInput(event: Event, currentValue: string, newValue: any): void;
    isValueChanged(currentValue: string, newValue: string): boolean;
    validateValue(value: number | string): string | number | null | undefined;
    updateInput(value: any, insertedValueStr: Nullable<string>, operation: Nullable<string>, valueStr: Nullable<string>): void;
    concatValues(val1: string, val2: string): string;
    getDecimalLength(value: string): number;
    onInputFocus(event: Event): void;
    onInputBlur(event: Event): void;
    formattedValue(): any;
    updateModel(event: Event, value: any): void;
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value: any, setModelValue: (value: any) => void): void;
    clearTimer(): void;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InputNumber, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<InputNumber, "p-inputNumber, p-inputnumber, p-input-number", never, { "showButtons": { "alias": "showButtons"; "required": false; "isSignal": true; }; "format": { "alias": "format"; "required": false; "isSignal": true; }; "buttonLayout": { "alias": "buttonLayout"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "ariaDescribedBy": { "alias": "ariaDescribedBy"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaRequired": { "alias": "ariaRequired"; "required": false; "isSignal": true; }; "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; "incrementButtonClass": { "alias": "incrementButtonClass"; "required": false; "isSignal": true; }; "decrementButtonClass": { "alias": "decrementButtonClass"; "required": false; "isSignal": true; }; "incrementButtonIcon": { "alias": "incrementButtonIcon"; "required": false; "isSignal": true; }; "decrementButtonIcon": { "alias": "decrementButtonIcon"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "allowEmpty": { "alias": "allowEmpty"; "required": false; "isSignal": true; }; "locale": { "alias": "locale"; "required": false; "isSignal": true; }; "localeMatcher": { "alias": "localeMatcher"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "currency": { "alias": "currency"; "required": false; "isSignal": true; }; "currencyDisplay": { "alias": "currencyDisplay"; "required": false; "isSignal": true; }; "useGrouping": { "alias": "useGrouping"; "required": false; "isSignal": true; }; "minFractionDigits": { "alias": "minFractionDigits"; "required": false; "isSignal": true; }; "maxFractionDigits": { "alias": "maxFractionDigits"; "required": false; "isSignal": true; }; "prefix": { "alias": "prefix"; "required": false; "isSignal": true; }; "suffix": { "alias": "suffix"; "required": false; "isSignal": true; }; "inputStyle": { "alias": "inputStyle"; "required": false; "isSignal": true; }; "inputStyleClass": { "alias": "inputStyleClass"; "required": false; "isSignal": true; }; "showClear": { "alias": "showClear"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; }, { "onInput": "onInput"; "onFocus": "onFocus"; "onBlur": "onBlur"; "onKeyDown": "onKeyDown"; "onClear": "onClear"; }, ["incrementButtonIconTemplate", "decrementButtonIconTemplate", "templates", "clearIconTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class InputNumberModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InputNumberModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<InputNumberModule, never, [typeof InputNumber, typeof InputNumberDirective, typeof i3.SharedModule], [typeof InputNumber, typeof InputNumberDirective, typeof i3.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<InputNumberModule>;
}

export { INPUTNUMBER_VALUE_ACCESSOR, InputNumber, InputNumberClasses, InputNumberDirective, InputNumberModule, InputNumberStyle };
