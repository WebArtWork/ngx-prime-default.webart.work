import { PickListMoveToSourceEvent, PickListSourceSelectEvent, PickListSourceFilterEvent, PickListFilterOptions, PickListItemTemplateContext, PickListFilterTemplateContext, PickListTransferIconTemplateContext } from '@wawjs/ngx-prime/types/picklist';
export * from '@wawjs/ngx-prime/types/picklist';
import * as _angular_core from '@angular/core';
import { OutputEmitterRef, ElementRef, TemplateRef } from '@angular/core';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import * as i2 from '@wawjs/ngx-prime/api';
import { FilterService, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { ButtonProps } from '@wawjs/ngx-prime/button';
import { Listbox, ListboxChangeEvent } from '@wawjs/ngx-prime/listbox';
import { Nullable, VoidListener } from '@wawjs/ngx-prime/ts-helpers';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class PickListStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: () => string[];
        sourceControls: string;
        sourceListContainer: string;
        transferControls: string;
        targetListContainer: string;
        targetControls: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PickListStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<PickListStyle>;
}
/**
 *
 * PickList is used to reorder items between different lists.
 *
 * [Live Demo](https://www.ngx-prime.org/picklist)
 *
 * @module pickliststyle
 *
 */
declare enum PickListClasses {
    /**
     * Class name of the root element
     */
    root = "p-picklist",
    /**
     * Class name of the source controls element
     */
    sourceControls = "p-picklist-source-controls",
    /**
     * Class name of the source list container element
     */
    sourceListContainer = "p-picklist-source-list-container",
    /**
     * Class name of the transfer controls element
     */
    transferControls = "p-picklist-transfer-controls",
    /**
     * Class name of the target list container element
     */
    targetListContainer = "p-picklist-target-list-container",
    /**
     * Class name of the target controls element
     */
    targetControls = "p-picklist-target-controls"
}

/**
 * PickList is used to reorder items between different lists.
 * @group Components
 */
declare class PickList extends BaseComponent {
    componentName: string;
    readonly hostName: _angular_core.InputSignal<any>;
    bindDirectiveInstance: Bind;
    $pcPickList: PickList | undefined;
    onAfterViewChecked(): void;
    /**
     * An array of objects for the source list.
     * @group Props
     */
    source: _angular_core.ModelSignal<any[]>;
    /**
     * An array of objects for the target list.
     * @group Props
     */
    target: _angular_core.ModelSignal<any[]>;
    /**
     * Name of the field that uniquely identifies the options.
     * @group Props
     */
    readonly dataKey: _angular_core.InputSignal<string | undefined>;
    /**
     * Text for the source list caption
     * @group Props
     */
    readonly sourceHeader: _angular_core.InputSignal<string | undefined>;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    readonly tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Defines a string that labels the move to right button for accessibility.
     * @group Props
     */
    readonly rightButtonAriaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the move to left button for accessibility.
     * @group Props
     */
    readonly leftButtonAriaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the move to all right button for accessibility.
     * @group Props
     */
    readonly allRightButtonAriaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the move to all left button for accessibility.
     * @group Props
     */
    readonly allLeftButtonAriaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the move to up button for accessibility.
     * @group Props
     */
    readonly upButtonAriaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the move to down button for accessibility.
     * @group Props
     */
    readonly downButtonAriaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the move to top button for accessibility.
     * @group Props
     */
    readonly topButtonAriaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the move to bottom button for accessibility.
     * @group Props
     */
    readonly bottomButtonAriaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the source list.
     * @group Props
     */
    readonly sourceAriaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the target list.
     * @group Props
     */
    readonly targetAriaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Text for the target list caption
     * @group Props
     */
    readonly targetHeader: _angular_core.InputSignal<string | undefined>;
    /**
     * When enabled orderlist adjusts its controls based on screen size.
     * @group Props
     */
    readonly responsive: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When specified displays an input field to filter the items on keyup and decides which field to search (Accepts multiple fields with a comma).
     * @group Props
     */
    readonly filterBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Locale to use in filtering. The default locale is the host environment's current locale.
     * @group Props
     */
    readonly filterLocale: _angular_core.InputSignal<string | undefined>;
    /**
     * Function to optimize the dom operations by delegating to ngForTrackBy, default algorithm checks for object identity. Use sourceTrackBy or targetTrackBy in case different algorithms are needed per list.
     * @group Props
     */
    readonly trackBy: _angular_core.InputSignal<(...args: any[]) => any>;
    /**
     * Function to optimize the dom operations by delegating to ngForTrackBy in source list, default algorithm checks for object identity.
     * @group Props
     */
    readonly sourceTrackBy: _angular_core.InputSignal<(...args: any[]) => any | undefined>;
    /**
     * Function to optimize the dom operations by delegating to ngForTrackBy in target list, default algorithm checks for object identity.
     * @group Props
     */
    readonly targetTrackBy: _angular_core.InputSignal<(...args: any[]) => any | undefined>;
    /**
     * Whether to show filter input for source list when filterBy is enabled.
     * @group Props
     */
    readonly showSourceFilter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to show filter input for target list when filterBy is enabled.
     * @group Props
     */
    readonly showTargetFilter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Defines how multiple items can be selected, when true metaKey needs to be pressed to select or unselect an item and when set to false selection of each item can be toggled individually. On touch enabled devices, metaKeySelection is turned off automatically.
     * @group Props
     */
    readonly metaKeySelection: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to enable dragdrop based reordering.
     * @group Props
     */
    readonly dragdrop: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Inline style of the component.
     * @group Props
     */
    readonly style: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the component.
     * @group Props
     */
    readonly styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the source list element.
     * @group Props
     */
    readonly sourceStyle: _angular_core.InputSignal<any>;
    /**
     * Inline style of the target list element.
     * @group Props
     */
    readonly targetStyle: _angular_core.InputSignal<any>;
    /**
     * Whether to show buttons of source list.
     * @group Props
     */
    readonly showSourceControls: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to show buttons of target list.
     * @group Props
     */
    readonly showTargetControls: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Placeholder text on source filter input.
     * @group Props
     */
    readonly sourceFilterPlaceholder: _angular_core.InputSignal<string | undefined>;
    /**
     * Placeholder text on target filter input.
     * @group Props
     */
    readonly targetFilterPlaceholder: _angular_core.InputSignal<string | undefined>;
    /**
     * When present, it specifies that the component should be disabled.
     * @group Props
     */
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Name of the disabled field of a target option or function to determine disabled state.
     * @group Props
     */
    readonly sourceOptionDisabled: _angular_core.InputSignal<string | ((item: any) => boolean) | undefined>;
    /**
     * Name of the disabled field of a target option or function to determine disabled state.
     * @group Props
     */
    readonly targetOptionDisabled: _angular_core.InputSignal<string | ((item: any) => boolean) | undefined>;
    /**
     * Defines a string that labels the filter input of source list.
     * @group Props
     */
    readonly ariaSourceFilterLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the filter input of target list.
     * @group Props
     */
    readonly ariaTargetFilterLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines how the items are filtered.
     * @group Props
     */
    readonly filterMatchMode: _angular_core.InputSignal<string>;
    /**
     * Whether to displays rows with alternating colors.
     * @group Props
     */
    readonly stripedRows: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Keeps selection on the transfer list.
     * @group Props
     */
    readonly keepSelection: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Height of the viewport, a scrollbar is defined if height of list exceeds this value.
     * @group Props
     */
    readonly scrollHeight: _angular_core.InputSignal<string>;
    /**
     * Whether to focus on the first visible or selected element.
     * @group Props
     */
    readonly autoOptionFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Used to pass all properties of the ButtonProps to the Button component.
     * @group Props
     */
    readonly buttonProps: _angular_core.InputSignal<ButtonProps>;
    /**
     * Used to pass all properties of the ButtonProps to the move up button inside the component.
     * @group Props
     */
    readonly moveUpButtonProps: _angular_core.InputSignal<ButtonProps | undefined>;
    /**
     * 	Used to pass all properties of the ButtonProps to the move top button inside the component.
     * @group Props
     */
    readonly moveTopButtonProps: _angular_core.InputSignal<ButtonProps | undefined>;
    /**
     * 	Used to pass all properties of the ButtonProps to the move down button inside the component.
     * @group Props
     */
    readonly moveDownButtonProps: _angular_core.InputSignal<ButtonProps | undefined>;
    /**
     * 	Used to pass all properties of the ButtonProps to the move bottom button inside the component.
     * @group Props
     */
    readonly moveBottomButtonProps: _angular_core.InputSignal<ButtonProps | undefined>;
    /**
     * 	Used to pass all properties of the ButtonProps to the move to target button inside the component.
     * @group Props
     */
    readonly moveToTargetProps: _angular_core.InputSignal<ButtonProps | undefined>;
    /**
     * 	Used to pass all properties of the ButtonProps to the move all to target button inside the component.
     * @group Props
     */
    readonly moveAllToTargetProps: _angular_core.InputSignal<ButtonProps | undefined>;
    /**
     *  Used to pass all properties of the ButtonProps to the move to source button inside the component.
     * @group Props
     */
    readonly moveToSourceProps: _angular_core.InputSignal<ButtonProps | undefined>;
    /**
     *  Used to pass all properties of the ButtonProps to the move all to source button inside the component.
     * @group Props
     */
    readonly moveAllToSourceProps: _angular_core.InputSignal<ButtonProps | undefined>;
    /**
     * Indicates the width of the screen at which the component should change its behavior.
     * @group Props
     */
    readonly breakpoint: _angular_core.InputSignal<string>;
    /**
     * Callback to invoke when items are moved from target to source.
     * @param {PickListMoveToSourceEvent} event - Custom move to source event.
     * @group Emits
     */
    onMoveToSource: OutputEmitterRef<PickListMoveToSourceEvent>;
    /**
     * Callback to invoke when all items are moved from target to source.
     * @param {PickListMoveAllToSourceEvent} event - Custom move all to source event.
     * @group Emits
     */
    onMoveAllToSource: OutputEmitterRef<PickListMoveToSourceEvent>;
    /**
     * Callback to invoke when all items are moved from source to target.
     * @param {PickListMoveAllToTargetEvent} event - Custom move all to target event.
     * @group Emits
     */
    onMoveAllToTarget: OutputEmitterRef<PickListMoveToSourceEvent>;
    /**
     * Callback to invoke when items are moved from source to target.
     * @param {PickListMoveToTargetEvent} event - Custom move to target event.
     * @group Emits
     */
    onMoveToTarget: OutputEmitterRef<PickListMoveToSourceEvent>;
    /**
     * Callback to invoke when items are reordered within source list.
     * @param {PickListSourceReorderEvent} event - Custom source reorder event.
     * @group Emits
     */
    onSourceReorder: OutputEmitterRef<PickListMoveToSourceEvent>;
    /**
     * Callback to invoke when items are reordered within target list.
     * @param {PickListTargetReorderEvent} event - Custom target reorder event.
     * @group Emits
     */
    onTargetReorder: OutputEmitterRef<PickListMoveToSourceEvent>;
    /**
     * Callback to invoke when items are selected within source list.
     * @param {PickListSourceSelectEvent} event - Custom source select event.
     * @group Emits
     */
    onSourceSelect: OutputEmitterRef<PickListSourceSelectEvent>;
    /**
     * Callback to invoke when items are selected within target list.
     * @param {PickListTargetSelectEvent} event - Custom target select event.
     * @group Emits
     */
    onTargetSelect: OutputEmitterRef<PickListSourceSelectEvent>;
    /**
     * Callback to invoke when the source list is filtered
     * @param {PickListSourceFilterEvent} event - Custom source filter event.
     * @group Emits
     */
    onSourceFilter: OutputEmitterRef<PickListSourceFilterEvent>;
    /**
     * Callback to invoke when the target list is filtered
     * @param {PickListTargetFilterEvent} event - Custom target filter event.
     * @group Emits
     */
    onTargetFilter: OutputEmitterRef<PickListSourceFilterEvent>;
    /**
     * Callback to invoke when the list is focused
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onFocus: OutputEmitterRef<Event>;
    /**
     * Callback to invoke when the list is blurred
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onBlur: OutputEmitterRef<Event>;
    readonly listViewSourceChild: _angular_core.Signal<Listbox>;
    readonly listViewTargetChild: _angular_core.Signal<Listbox>;
    readonly sourceFilterViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly targetFilterViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    getButtonProps(direction: string): ButtonProps;
    get targetOptions(): any[];
    get sourceOptions(): any[];
    get moveUpAriaLabel(): string | undefined;
    get moveTopAriaLabel(): string | undefined;
    get moveDownAriaLabel(): string | undefined;
    get moveBottomAriaLabel(): string | undefined;
    get moveToTargetAriaLabel(): string | undefined;
    get moveAllToTargetAriaLabel(): string | undefined;
    get moveToSourceAriaLabel(): string | undefined;
    get moveAllToSourceAriaLabel(): string | undefined;
    get idSource(): string;
    get idTarget(): string;
    visibleOptionsSource: any[] | undefined | null;
    visibleOptionsTarget: any[] | undefined | null;
    selectedItemsSource: any[];
    selectedItemsTarget: any[];
    reorderedListElement: any;
    movedUp: Nullable<boolean>;
    movedDown: Nullable<boolean>;
    itemTouched: Nullable<boolean>;
    styleElement: any;
    id: string;
    filterValueSource: Nullable<string>;
    filterValueTarget: Nullable<string>;
    fromListType: Nullable<number>;
    sourceFilterOptions: Nullable<PickListFilterOptions>;
    targetFilterOptions: Nullable<PickListFilterOptions>;
    readonly SOURCE_LIST: number;
    readonly TARGET_LIST: number;
    window: Window;
    media: MediaQueryList | null | undefined;
    viewChanged: boolean | undefined;
    _componentStyle: PickListStyle;
    mediaChangeListener: VoidListener;
    filterService: FilterService;
    constructor();
    onInit(): void;
    /**
     * Custom item template.
     * @param {PickListItemTemplateContext} context - item context.
     * @see {@link PickListItemTemplateContext}
     * @group Templates
     */
    itemTemplate: TemplateRef<PickListItemTemplateContext>;
    /**
     * Custom source header template.
     * @group Templates
     */
    sourceHeaderTemplate: TemplateRef<void>;
    /**
     * Custom target header template.
     * @group Templates
     */
    targetHeaderTemplate: TemplateRef<void>;
    /**
     * Custom source filter template.
     * @param {PickListFilterTemplateContext} context - filter context.
     * @see {@link PickListFilterTemplateContext}
     * @group Templates
     */
    sourceFilterTemplate: TemplateRef<PickListFilterTemplateContext>;
    /**
     * Custom target filter template.
     * @param {PickListFilterTemplateContext} context - filter context.
     * @see {@link PickListFilterTemplateContext}
     * @group Templates
     */
    targetFilterTemplate: TemplateRef<PickListFilterTemplateContext>;
    /**
     * Custom empty message when source is empty template.
     * @group Templates
     */
    emptyMessageSourceTemplate: TemplateRef<void>;
    /**
     * Custom empty filter message when source is empty template.
     * @group Templates
     */
    emptyFilterMessageSourceTemplate: TemplateRef<void>;
    /**
     * Custom empty message when target is empty template.
     * @group Templates
     */
    emptyMessageTargetTemplate: TemplateRef<void>;
    /**
     * Custom empty filter message when target is empty template.
     * @group Templates
     */
    emptyFilterMessageTargetTemplate: TemplateRef<void>;
    /**
     * Custom move up icon template.
     * @group Templates
     */
    readonly moveUpIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom move top icon template.
     * @group Templates
     */
    readonly moveTopIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom move down icon template.
     * @group Templates
     */
    readonly moveDownIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom move bottom icon template.
     * @group Templates
     */
    readonly moveBottomIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom move to target icon template.
     * @param {PickListTransferIconTemplateContext} context - icon context.
     * @see {@link PickListTransferIconTemplateContext}
     * @group Templates
     */
    readonly moveToTargetIconTemplate: _angular_core.Signal<TemplateRef<PickListTransferIconTemplateContext> | undefined>;
    /**
     * Custom move all to target icon template.
     * @param {PickListTransferIconTemplateContext} context - icon context.
     * @see {@link PickListTransferIconTemplateContext}
     * @group Templates
     */
    readonly moveAllToTargetIconTemplate: _angular_core.Signal<TemplateRef<PickListTransferIconTemplateContext> | undefined>;
    /**
     * Custom move to source icon template.
     * @param {PickListTransferIconTemplateContext} context - icon context.
     * @see {@link PickListTransferIconTemplateContext}
     * @group Templates
     */
    readonly moveToSourceIconTemplate: _angular_core.Signal<TemplateRef<PickListTransferIconTemplateContext> | undefined>;
    /**
     * Custom move all to source icon template.
     * @param {PickListTransferIconTemplateContext} context - icon context.
     * @see {@link PickListTransferIconTemplateContext}
     * @group Templates
     */
    readonly moveAllToSourceIconTemplate: _angular_core.Signal<TemplateRef<PickListTransferIconTemplateContext> | undefined>;
    /**
     * Custom target filter icon template.
     * @group Templates
     */
    targetFilterIconTemplate: TemplateRef<void>;
    /**
     * Custom source filter icon template.
     * @group Templates
     */
    sourceFilterIconTemplate: TemplateRef<void>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _itemTemplate: TemplateRef<PickListItemTemplateContext> | undefined;
    _sourceHeaderTemplate: TemplateRef<void> | undefined;
    _targetHeaderTemplate: TemplateRef<void> | undefined;
    _sourceFilterTemplate: TemplateRef<PickListFilterTemplateContext> | undefined;
    _targetFilterTemplate: TemplateRef<PickListFilterTemplateContext> | undefined;
    _emptyMessageSourceTemplate: TemplateRef<void> | undefined;
    _emptyFilterMessageSourceTemplate: TemplateRef<void> | undefined;
    _emptyMessageTargetTemplate: TemplateRef<void> | undefined;
    _emptyFilterMessageTargetTemplate: TemplateRef<void> | undefined;
    _moveUpIconTemplate: TemplateRef<void> | undefined;
    _moveTopIconTemplate: TemplateRef<void> | undefined;
    _moveDownIconTemplate: TemplateRef<void> | undefined;
    _moveBottomIconTemplate: TemplateRef<void> | undefined;
    _moveToTargetIconTemplate: TemplateRef<PickListTransferIconTemplateContext> | undefined;
    _moveAllToTargetIconTemplate: TemplateRef<PickListTransferIconTemplateContext> | undefined;
    _moveToSourceIconTemplate: TemplateRef<PickListTransferIconTemplateContext> | undefined;
    _moveAllToSourceIconTemplate: TemplateRef<PickListTransferIconTemplateContext> | undefined;
    _targetFilterIconTemplate: TemplateRef<void> | undefined;
    _sourceFilterIconTemplate: TemplateRef<void> | undefined;
    onAfterContentInit(): void;
    onChangeSelection(e: ListboxChangeEvent, listType: number): void;
    onSourceItemDblClick(): void;
    onTargetItemDblClick(): void;
    onFilter(event: KeyboardEvent, listType: number): void;
    filterSource(value?: any): void;
    filterTarget(value?: any): void;
    filter(data: any[], listType: number): void;
    isItemVisible(item: any, listType: number): boolean | undefined;
    isEmpty(listType: number): boolean;
    isVisibleInList(data: any[], item: any, filterValue: string): boolean | undefined;
    onItemTouchEnd(): void;
    private sortByIndexInList;
    triggerChangeDetection(): void;
    moveUp(listElement: any, list: any[], selectedItems: any[], callback: OutputEmitterRef<any>, listType: number): void;
    moveTop(listElement: any, list: any[], selectedItems: any[], callback: OutputEmitterRef<any>, listType: number): void;
    moveDown(listElement: any, list: any[], selectedItems: any[], callback: OutputEmitterRef<any>, listType: number): void;
    moveBottom(listElement: any, list: any[], selectedItems: any[], callback: OutputEmitterRef<any>, listType: number): void;
    moveRight(): void;
    moveAllRight(): void;
    moveLeft(): void;
    moveAllLeft(): void;
    isSelected(item: any, selectedItems: any[]): boolean;
    findIndexInList(item: any, selectedItems: any[]): number;
    onDrop(event: CdkDragDrop<string[]>, listType: number): void;
    onListFocus(event: any): void;
    onListBlur(event: any): void;
    getListElement(listType: number): any;
    getListItems(listType: number): Element[];
    getLatestSelectedVisibleOptionIndex(visibleList: any[], selectedItems: any[]): number;
    getVisibleList(listType: number): any[] | null;
    setSelectionList(listType: number, selectedItems: any[]): void;
    getDropIndexes(fromIndex: number, toIndex: number, droppedList: number, isTransfer: boolean, data: any[] | any): {
        previousIndex: any;
        currentIndex: any;
    };
    findFilteredCurrentIndex(visibleOptions: any[], index: number, options: any): number;
    resetSourceFilter(): void;
    resetTargetFilter(): void;
    resetFilter(): void;
    initMedia(): void;
    destroyMedia(): void;
    bindMediaChangeListener(): void;
    unbindMediaChangeListener(): void;
    createStyle(): void;
    sourceMoveDisabled(): true | undefined;
    targetMoveDisabled(): true | undefined;
    moveRightDisabled(): boolean;
    moveLeftDisabled(): boolean;
    moveAllRightDisabled(): boolean;
    moveAllLeftDisabled(): boolean;
    destroyStyle(): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PickList, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PickList, "p-pickList, p-picklist, p-pick-list", never, { "hostName": { "alias": "hostName"; "required": false; "isSignal": true; }; "source": { "alias": "source"; "required": false; "isSignal": true; }; "target": { "alias": "target"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "sourceHeader": { "alias": "sourceHeader"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "rightButtonAriaLabel": { "alias": "rightButtonAriaLabel"; "required": false; "isSignal": true; }; "leftButtonAriaLabel": { "alias": "leftButtonAriaLabel"; "required": false; "isSignal": true; }; "allRightButtonAriaLabel": { "alias": "allRightButtonAriaLabel"; "required": false; "isSignal": true; }; "allLeftButtonAriaLabel": { "alias": "allLeftButtonAriaLabel"; "required": false; "isSignal": true; }; "upButtonAriaLabel": { "alias": "upButtonAriaLabel"; "required": false; "isSignal": true; }; "downButtonAriaLabel": { "alias": "downButtonAriaLabel"; "required": false; "isSignal": true; }; "topButtonAriaLabel": { "alias": "topButtonAriaLabel"; "required": false; "isSignal": true; }; "bottomButtonAriaLabel": { "alias": "bottomButtonAriaLabel"; "required": false; "isSignal": true; }; "sourceAriaLabel": { "alias": "sourceAriaLabel"; "required": false; "isSignal": true; }; "targetAriaLabel": { "alias": "targetAriaLabel"; "required": false; "isSignal": true; }; "targetHeader": { "alias": "targetHeader"; "required": false; "isSignal": true; }; "responsive": { "alias": "responsive"; "required": false; "isSignal": true; }; "filterBy": { "alias": "filterBy"; "required": false; "isSignal": true; }; "filterLocale": { "alias": "filterLocale"; "required": false; "isSignal": true; }; "trackBy": { "alias": "trackBy"; "required": false; "isSignal": true; }; "sourceTrackBy": { "alias": "sourceTrackBy"; "required": false; "isSignal": true; }; "targetTrackBy": { "alias": "targetTrackBy"; "required": false; "isSignal": true; }; "showSourceFilter": { "alias": "showSourceFilter"; "required": false; "isSignal": true; }; "showTargetFilter": { "alias": "showTargetFilter"; "required": false; "isSignal": true; }; "metaKeySelection": { "alias": "metaKeySelection"; "required": false; "isSignal": true; }; "dragdrop": { "alias": "dragdrop"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "sourceStyle": { "alias": "sourceStyle"; "required": false; "isSignal": true; }; "targetStyle": { "alias": "targetStyle"; "required": false; "isSignal": true; }; "showSourceControls": { "alias": "showSourceControls"; "required": false; "isSignal": true; }; "showTargetControls": { "alias": "showTargetControls"; "required": false; "isSignal": true; }; "sourceFilterPlaceholder": { "alias": "sourceFilterPlaceholder"; "required": false; "isSignal": true; }; "targetFilterPlaceholder": { "alias": "targetFilterPlaceholder"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "sourceOptionDisabled": { "alias": "sourceOptionDisabled"; "required": false; "isSignal": true; }; "targetOptionDisabled": { "alias": "targetOptionDisabled"; "required": false; "isSignal": true; }; "ariaSourceFilterLabel": { "alias": "ariaSourceFilterLabel"; "required": false; "isSignal": true; }; "ariaTargetFilterLabel": { "alias": "ariaTargetFilterLabel"; "required": false; "isSignal": true; }; "filterMatchMode": { "alias": "filterMatchMode"; "required": false; "isSignal": true; }; "stripedRows": { "alias": "stripedRows"; "required": false; "isSignal": true; }; "keepSelection": { "alias": "keepSelection"; "required": false; "isSignal": true; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; "isSignal": true; }; "autoOptionFocus": { "alias": "autoOptionFocus"; "required": false; "isSignal": true; }; "buttonProps": { "alias": "buttonProps"; "required": false; "isSignal": true; }; "moveUpButtonProps": { "alias": "moveUpButtonProps"; "required": false; "isSignal": true; }; "moveTopButtonProps": { "alias": "moveTopButtonProps"; "required": false; "isSignal": true; }; "moveDownButtonProps": { "alias": "moveDownButtonProps"; "required": false; "isSignal": true; }; "moveBottomButtonProps": { "alias": "moveBottomButtonProps"; "required": false; "isSignal": true; }; "moveToTargetProps": { "alias": "moveToTargetProps"; "required": false; "isSignal": true; }; "moveAllToTargetProps": { "alias": "moveAllToTargetProps"; "required": false; "isSignal": true; }; "moveToSourceProps": { "alias": "moveToSourceProps"; "required": false; "isSignal": true; }; "moveAllToSourceProps": { "alias": "moveAllToSourceProps"; "required": false; "isSignal": true; }; "breakpoint": { "alias": "breakpoint"; "required": false; "isSignal": true; }; }, { "source": "sourceChange"; "target": "targetChange"; "onMoveToSource": "onMoveToSource"; "onMoveAllToSource": "onMoveAllToSource"; "onMoveAllToTarget": "onMoveAllToTarget"; "onMoveToTarget": "onMoveToTarget"; "onSourceReorder": "onSourceReorder"; "onTargetReorder": "onTargetReorder"; "onSourceSelect": "onSourceSelect"; "onTargetSelect": "onTargetSelect"; "onSourceFilter": "onSourceFilter"; "onTargetFilter": "onTargetFilter"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, ["moveUpIconTemplate", "moveTopIconTemplate", "moveDownIconTemplate", "moveBottomIconTemplate", "moveToTargetIconTemplate", "moveAllToTargetIconTemplate", "moveToSourceIconTemplate", "moveAllToSourceIconTemplate", "templates", "itemTemplate", "sourceHeaderTemplate", "targetHeaderTemplate", "sourceFilterTemplate", "targetFilterTemplate", "emptyMessageSourceTemplate", "emptyFilterMessageSourceTemplate", "emptyMessageTargetTemplate", "emptyFilterMessageTargetTemplate", "targetFilterIconTemplate", "sourceFilterIconTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class PickListModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PickListModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<PickListModule, never, [typeof PickList, typeof i2.SharedModule], [typeof PickList, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<PickListModule>;
}

export { PickList, PickListClasses, PickListModule, PickListStyle };
