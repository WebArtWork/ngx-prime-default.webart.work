import { AvatarPassThrough } from '@wawjs/ngx-prime/types/avatar';
export * from '@wawjs/ngx-prime/types/avatar';
import * as _angular_core from '@angular/core';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i2 from '@wawjs/ngx-prime/api';

declare class AvatarStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-avatar-image': boolean;
            'p-avatar-circle': boolean;
            'p-avatar-lg': boolean;
            'p-avatar-xl': boolean;
        })[];
        label: string;
        icon: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AvatarStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<AvatarStyle>;
}
/**
 *
 * Avatar represents people using icons, labels and images.
 *
 * - [Live Demo](https://ngx-prime.org/avatar)
 *
 * @module avatarstyle
 *
 */
declare enum AvatarClasses {
    /**
     * Class name of the root element
     */
    root = "p-avatar",
    /**
     * Class name of the label element
     */
    label = "p-avatar-label",
    /**
     * Class name of the icon element
     */
    icon = "p-avatar-icon",
    /**
     * Container element in image mode
     */
    image = "p-avatar-image",
    /**
     * Container element with a circle shape
     */
    circle = "p-avatar-circle",
    /**
     *  Container element with a large size
     */
    large = "p-avatar-lg",
    /**
     *  Container element with an xlarge size
     */
    xlarge = "p-avatar-xl"
}

/**
 * Avatar represents people using icons, labels and images.
 * @group Components
 */
declare class Avatar extends BaseComponent<AvatarPassThrough> {
    componentName: string;
    $pcAvatar: Avatar | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Defines the text to display.
     * @group Props
     */
    label: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines the icon to display.
     * @group Props
     */
    icon: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines the image to display.
     * @group Props
     */
    image: _angular_core.InputSignal<string | undefined>;
    /**
     * Size of the element.
     * @group Props
     */
    size: _angular_core.InputSignal<"large" | "xlarge" | "normal">;
    /**
     * Shape of the element.
     * @group Props
     */
    shape: _angular_core.InputSignal<"circle" | "square">;
    /**
     * Class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Establishes a string value that labels the component.
     * @group Props
     */
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * This event is triggered if an error occurs while loading an image file.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onImageError: _angular_core.OutputEmitterRef<Event>;
    _componentStyle: AvatarStyle;
    imageError(event: Event): void;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Avatar, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Avatar, "p-avatar", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "image": { "alias": "image"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "shape": { "alias": "shape"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; }, { "onImageError": "onImageError"; }, never, ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class AvatarModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AvatarModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<AvatarModule, never, [typeof Avatar, typeof i2.SharedModule], [typeof Avatar, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<AvatarModule>;
}

export { Avatar, AvatarClasses, AvatarModule, AvatarStyle };
