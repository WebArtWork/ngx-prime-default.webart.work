import { ColorPickerChangeEvent, ColorPickerPassThrough } from '@wawjs/ngx-prime/types/colorpicker';
export * from '@wawjs/ngx-prime/types/colorpicker';
import * as _angular_core from '@angular/core';
import { AfterViewChecked, ElementRef } from '@angular/core';
import { MotionOptions } from '@wawjs/css-prime-motion';
import * as i3 from '@wawjs/ngx-prime/api';
import { OverlayService, OverlayOptions } from '@wawjs/ngx-prime/api';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { ConnectedOverlayScrollHandler } from '@wawjs/ngx-prime/dom';
import { Nullable, VoidListener } from '@wawjs/ngx-prime/ts-helpers';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class ColorPickerStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-colorpicker-overlay': boolean;
            'p-colorpicker-dragging': any;
        })[];
        preview: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-disabled': any;
        })[];
        panel: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-colorpicker-panel-inline': any;
            'p-disabled': any;
        })[];
        content: string;
        colorSelector: string;
        colorBackground: string;
        colorHandle: string;
        hue: string;
        hueHandle: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ColorPickerStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ColorPickerStyle>;
}
/**
 *
 * ColorPicker groups a collection of contents in tabs.
 *
 * [Live Demo](https://www.ngx-prime.org/colorpicker/)
 *
 * @module colorpickerstyle
 *
 */
declare enum ColorPickerClasses {
    /**
     * Class name of the root element
     */
    root = "p-colorpicker",
    /**
     * Class name of the preview element
     */
    preview = "p-colorpicker-preview",
    /**
     * Class name of the panel element
     */
    panel = "p-colorpicker-panel",
    /**
     * Class name of the color selector element
     */
    colorSelector = "p-colorpicker-color-selector",
    /**
     * Class name of the color background element
     */
    colorBackground = "p-colorpicker-color-background",
    /**
     * Class name of the color handle element
     */
    colorHandle = "p-colorpicker-color-handle",
    /**
     * Class name of the hue element
     */
    hue = "p-colorpicker-hue",
    /**
     * Class name of the hue handle element
     */
    hueHandle = "p-colorpicker-hue-handle"
}

/** Enhances a browser-native color input while preserving native color selection. */
declare class ColorPickerDirective {
    private readonly element;
    invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    ariaDescribedBy: _angular_core.InputSignal<string | undefined>;
    inputId: _angular_core.InputSignal<string | undefined>;
    name: _angular_core.InputSignal<string | undefined>;
    tabindex: _angular_core.InputSignal<number | undefined>;
    colorChange: _angular_core.OutputEmitterRef<string>;
    touch: _angular_core.OutputEmitterRef<void>;
    onInputChange: _angular_core.OutputEmitterRef<ColorPickerChangeEvent>;
    onChange: _angular_core.OutputEmitterRef<ColorPickerChangeEvent>;
    onFocus: _angular_core.OutputEmitterRef<Event>;
    onBlur: _angular_core.OutputEmitterRef<Event>;
    onClear: _angular_core.OutputEmitterRef<string>;
    onInput(event: Event): void;
    onNativeBlur(event: Event): void;
    handleChange(event: Event): void;
    clear(value?: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ColorPickerDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ColorPickerDirective, "input[type='color'][pColorPicker]", ["pColorPicker"], { "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaDescribedBy": { "alias": "ariaDescribedBy"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; }, { "colorChange": "colorChange"; "touch": "touch"; "onInputChange": "onInput"; "onChange": "onChange"; "onFocus": "onFocus"; "onBlur": "onBlur"; "onClear": "onClear"; }, never, never, true, never>;
}
/** Resets a native `pColorPicker` input to its configured default color. */
declare class ColorPickerClearDirective {
    picker: _angular_core.InputSignal<ColorPickerDirective>;
    value: _angular_core.InputSignal<string>;
    ariaLabel: _angular_core.InputSignal<string>;
    clear(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ColorPickerClearDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ColorPickerClearDirective, "button[pColorPickerClear]", never, { "picker": { "alias": "pColorPickerClear"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare const COLORPICKER_VALUE_ACCESSOR: any;
/**
 * ColorPicker groups a collection of contents in tabs.
 *
 * @deprecated Use a native `<input type="color" pColorPicker>` instead.
 * Browser-native picker appearance is platform controlled. This component
 * remains available for compatibility and is planned for removal in v23.
 * @group Components
 */
declare class ColorPicker extends BaseEditableHolder<ColorPickerPassThrough> implements AfterViewChecked {
    overlayService: OverlayService;
    componentName: string;
    $pcColorPicker: ColorPicker | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Transition options of the show animation.
     * @group Props
     * @deprecated since v21.0.0, use `motionOptions` instead.
     */
    showTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * Transition options of the hide animation.
     * @group Props
     * @deprecated since v21.0.0, use `motionOptions` instead.
     */
    hideTransitionOptions: _angular_core.InputSignal<string>;
    /**
     * Whether to display as an overlay or not.
     * @group Props
     */
    inline: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Format to use in value binding.
     * @group Props
     */
    format: _angular_core.InputSignal<"hex" | "rgb" | "hsb">;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex: _angular_core.InputSignal<string | undefined>;
    /**
     * Identifier of the focus input to match a label defined for the dropdown.
     * @group Props
     */
    inputId: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to automatically manage layering.
     * @group Props
     */
    autoZIndex: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Default color to display initially when model value is not present.
     * @group Props
     */
    defaultColor: _angular_core.InputSignal<string | undefined>;
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'self'
     * @group Props
     */
    appendTo: _angular_core.InputSignal<any>;
    /**
     * Whether to use overlay API feature. The properties of overlay API can be used like an object in it.
     * @group Props
     */
    overlayOptions: _angular_core.InputSignal<OverlayOptions | undefined>;
    /**
     * The motion options.
     * @group Props
     */
    motionOptions: _angular_core.InputSignal<MotionOptions | undefined>;
    /**
     * Callback to invoke on value change.
     * @param {ColorPickerChangeEvent} event - Custom value change event.
     * @group Emits
     */
    onChange: _angular_core.OutputEmitterRef<ColorPickerChangeEvent>;
    /**
     * Callback to invoke on panel is shown.
     * @group Emits
     */
    onShow: _angular_core.OutputEmitterRef<any>;
    /**
     * Callback to invoke on panel is hidden.
     * @group Emits
     */
    onHide: _angular_core.OutputEmitterRef<any>;
    readonly inputViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    readonly overlayViewChild: _angular_core.Signal<ElementRef<HTMLDivElement>>;
    $appendTo: _angular_core.Signal<any>;
    value: any;
    inputBgColor: string | undefined;
    shown: Nullable<boolean>;
    overlayVisible: Nullable<boolean>;
    documentMousemoveListener: VoidListener;
    documentMouseupListener: VoidListener;
    documentHueMoveListener: VoidListener;
    scrollHandler: Nullable<ConnectedOverlayScrollHandler>;
    colorDragging: Nullable<boolean>;
    hueDragging: Nullable<boolean>;
    overlay: Nullable<HTMLDivElement>;
    colorSelectorViewChild: Nullable<ElementRef>;
    colorHandleViewChild: Nullable<ElementRef>;
    hueViewChild: Nullable<ElementRef>;
    hueHandleViewChild: Nullable<ElementRef>;
    _componentStyle: ColorPickerStyle;
    set colorSelector(element: ElementRef);
    set colorHandle(element: ElementRef);
    set hue(element: ElementRef);
    set hueHandle(element: ElementRef);
    get ariaLabel(): any;
    onHueMousedown(event: MouseEvent): void;
    onHueDragStart(event: TouchEvent): void;
    onColorDragStart(event: TouchEvent): void;
    pickHue(event: MouseEvent | TouchEvent, position?: any): void;
    onColorMousedown(event: MouseEvent): void;
    onDrag(event: TouchEvent): void;
    onDragEnd(): void;
    pickColor(event: MouseEvent | TouchEvent, position?: any): void;
    getValueToUpdate(): any;
    updateModel(): void;
    updateColorSelector(): void;
    updateUI(): void;
    onInputFocus(): void;
    show(): void;
    onOverlayBeforeEnter(): void;
    onOverlayAfterLeave(): void;
    hide(): void;
    onInputClick(): void;
    togglePanel(): void;
    onInputKeydown(event: KeyboardEvent): void;
    onOverlayClick(event: MouseEvent): void;
    bindDocumentMousemoveListener(): void;
    unbindDocumentMousemoveListener(): void;
    bindDocumentMouseupListener(): void;
    unbindDocumentMouseupListener(): void;
    validateHSB(hsb: {
        h: number;
        s: number;
        b: number;
    }): {
        h: number;
        s: number;
        b: number;
    };
    validateRGB(rgb: {
        r: number;
        g: number;
        b: number;
    }): {
        r: number;
        g: number;
        b: number;
    };
    validateHEX(hex: string): string;
    HEXtoRGB(hex: string): {
        r: number;
        g: number;
        b: number;
    };
    HEXtoHSB(hex: string): {
        h: number;
        s: number;
        b: number;
    };
    RGBtoHSB(rgb: {
        r: number;
        g: number;
        b: number;
    }): {
        h: number;
        s: number;
        b: number;
    };
    HSBtoRGB(hsb: {
        h: number;
        s: number;
        b: number;
    }): {
        r: number;
        g: number;
        b: number;
    };
    RGBtoHEX(rgb: {
        r: number;
        g: number;
        b: number;
    }): string;
    HSBtoHEX(hsb: {
        h: number;
        s: number;
        b: number;
    }): string;
    onAfterViewInit(): void;
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value: any): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ColorPicker, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ColorPicker, "p-colorPicker, p-colorpicker, p-color-picker", never, { "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "showTransitionOptions": { "alias": "showTransitionOptions"; "required": false; "isSignal": true; }; "hideTransitionOptions": { "alias": "hideTransitionOptions"; "required": false; "isSignal": true; }; "inline": { "alias": "inline"; "required": false; "isSignal": true; }; "format": { "alias": "format"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "autoZIndex": { "alias": "autoZIndex"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "defaultColor": { "alias": "defaultColor"; "required": false; "isSignal": true; }; "appendTo": { "alias": "appendTo"; "required": false; "isSignal": true; }; "overlayOptions": { "alias": "overlayOptions"; "required": false; "isSignal": true; }; "motionOptions": { "alias": "motionOptions"; "required": false; "isSignal": true; }; }, { "onChange": "onChange"; "onShow": "onShow"; "onHide": "onHide"; }, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class ColorPickerModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ColorPickerModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<ColorPickerModule, never, [typeof ColorPicker, typeof ColorPickerDirective, typeof i3.SharedModule], [typeof ColorPicker, typeof ColorPickerDirective, typeof i3.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<ColorPickerModule>;
}

export { COLORPICKER_VALUE_ACCESSOR, ColorPicker, ColorPickerClasses, ColorPickerClearDirective, ColorPickerDirective, ColorPickerModule, ColorPickerStyle };
