import { OrderListPassThrough, OrderListSelectionChangeEvent, OrderListFilterEvent, OrderListItemTemplateContext, OrderListFilterTemplateContext, OrderListFilterOptions } from '@wawjs/ngx-prime/types/orderlist';
export * from '@wawjs/ngx-prime/types/orderlist';
import * as _angular_core from '@angular/core';
import { ElementRef, TemplateRef } from '@angular/core';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
import * as i2 from '@wawjs/ngx-prime/api';
import { FilterService, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { ButtonProps } from '@wawjs/ngx-prime/button';
import { Listbox, ListboxChangeEvent } from '@wawjs/ngx-prime/listbox';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class OrderListStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-orderlist-controls-left': boolean;
            'p-orderlist-controls-right': boolean;
        })[];
        controls: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OrderListStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<OrderListStyle>;
}
/**
 *
 * OrderList is used to maneged the order of a collection.
 *
 * [Live Demo](https://ngx-prime.org/orderlist)
 *
 * @module orderliststyle
 *
 */
declare enum OrderListClasses {
    /**
     * Class name of the root element
     */
    root = "p-orderlist",
    /**
     * Class name of the controls element
     */
    controls = "p-orderlist-controls"
}

/**
 * OrderList is used to manage the order of a collection.
 * @group Components
 */
declare class OrderList extends BaseComponent<OrderListPassThrough> {
    componentName: string;
    bindDirectiveInstance: Bind;
    $pcOrderList: OrderList | undefined;
    onAfterViewChecked(): void;
    /**
     * Text for the caption.
     * @group Props
     */
    header: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Defines a string that labels the input for accessibility.
     * @group Props
     */
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Specifies one or more IDs in the DOM that labels the input field.
     * @group Props
     */
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the list element.
     * @group Props
     */
    listStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * A boolean value that indicates whether the component should be responsive.
     * @group Props
     */
    responsive: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When specified displays an input field to filter the items on keyup and decides which fields to search against.
     * @group Props
     */
    filterBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Placeholder of the filter input.
     * @group Props
     */
    filterPlaceholder: _angular_core.InputSignal<string | undefined>;
    /**
     * Locale to use in filtering. The default locale is the host environment's current locale.
     * @group Props
     */
    filterLocale: _angular_core.InputSignal<string | undefined>;
    /**
     * When true metaKey needs to be pressed to select or unselect an item and when set to false selection of each item can be toggled individually. On touch enabled devices, metaKeySelection is turned off automatically.
     * @group Props
     */
    metaKeySelection: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to enable dragdrop based reordering.
     * @group Props
     */
    dragdrop: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Defines the location of the buttons with respect to the list.
     * @group Props
     */
    controlsPosition: _angular_core.InputSignal<"left" | "right">;
    /**
     * Defines a string that labels the filter input.
     * @group Props
     */
    ariaFilterLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines how the items are filtered.
     * @group Props
     */
    filterMatchMode: _angular_core.InputSignal<"contains" | "startsWith" | "endsWith" | "equals" | "notEquals" | "in" | "lt" | "lte" | "gt" | "gte">;
    /**
     * Indicates the width of the screen at which the component should change its behavior.
     * @group Props
     */
    breakpoint: _angular_core.InputSignal<string>;
    /**
     * Whether to displays rows with alternating colors.
     * @group Props
     */
    stripedRows: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When present, it specifies that the component should be disabled.
     * @group Props
     */
    disabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Function to optimize the dom operations by delegating to ngForTrackBy, default algorithm checks for object identity.
     * @group Props
     */
    trackBy: _angular_core.InputSignal<(...args: any[]) => any>;
    /**
     * Height of the viewport, a scrollbar is defined if height of list exceeds this value.
     * @group Props
     */
    scrollHeight: _angular_core.InputSignal<string>;
    /**
     * Whether to focus on the first visible or selected element.
     * @group Props
     */
    autoOptionFocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Name of the field that uniquely identifies the record in the data.
     * @group Props
     */
    dataKey: _angular_core.InputSignal<string | undefined>;
    /**
     * A list of values that are currently selected.
     * @group Props
     */
    selection: _angular_core.ModelSignal<any[]>;
    /**
     * Array of values to be displayed in the component.
     * It represents the data source for the list of items.
     * @group Props
     */
    value: _angular_core.InputSignal<any[] | undefined>;
    /**
     * Used to pass all properties of the ButtonProps to the Button component.
     * @group Props
     */
    buttonProps: _angular_core.InputSignal<ButtonProps>;
    /**
     * Used to pass all properties of the ButtonProps to the move up button inside the component.
     * @group Props
     */
    moveUpButtonProps: _angular_core.InputSignal<ButtonProps | undefined>;
    /**
     * Used to pass all properties of the ButtonProps to the move top button inside the component.
     * @group Props
     */
    moveTopButtonProps: _angular_core.InputSignal<ButtonProps | undefined>;
    /**
     * Used to pass all properties of the ButtonProps to the move down button inside the component.
     * @group Props
     */
    moveDownButtonProps: _angular_core.InputSignal<ButtonProps | undefined>;
    /**
     * Used to pass all properties of the ButtonProps to the move bottom button inside the component.
     * @group Props
     */
    moveBottomButtonProps: _angular_core.InputSignal<ButtonProps | undefined>;
    /**
     * Callback to invoke when list is reordered.
     * @param {*} any - list instance.
     * @group Emits
     */
    onReorder: _angular_core.OutputEmitterRef<any>;
    /**
     * Callback to invoke when selection changes.
     * @param {OrderListSelectionChangeEvent} event - Custom change event.
     * @group Emits
     */
    onSelectionChange: _angular_core.OutputEmitterRef<OrderListSelectionChangeEvent>;
    /**
     * Callback to invoke when filtering occurs.
     * @param {OrderListFilterEvent} event - Custom filter event.
     * @group Emits
     */
    onFilterEvent: _angular_core.OutputEmitterRef<OrderListFilterEvent>;
    /**
     * Callback to invoke when the list is focused
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onFocus: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke when the list is blurred
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onBlur: _angular_core.OutputEmitterRef<Event>;
    readonly listViewChild: _angular_core.Signal<Listbox>;
    readonly filterViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    /**
     * Custom item template.
     * @param {OrderListItemTemplateContext} context - item context.
     * @see {@link OrderListItemTemplateContext}
     * @group Templates
     */
    itemTemplate: TemplateRef<OrderListItemTemplateContext> | undefined;
    /**
     * Custom empty template.
     * @group Templates
     */
    emptyMessageTemplate: TemplateRef<void> | undefined;
    /**
     * Custom empty filter template.
     * @group Templates
     */
    emptyFilterMessageTemplate: TemplateRef<void> | undefined;
    /**
     * Custom filter template.
     * @param {OrderListFilterTemplateContext} context - filter context.
     * @see {@link OrderListFilterTemplateContext}
     * @group Templates
     */
    filterTemplate: TemplateRef<OrderListFilterTemplateContext> | undefined;
    /**
     * Custom header template.
     * @group Templates
     */
    headerTemplate: TemplateRef<void> | undefined;
    /**
     * Custom move up icon template.
     * @group Templates
     */
    readonly moveUpIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom move top icon template.
     * @group Templates
     */
    readonly moveTopIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom move down icon template.
     * @group Templates
     */
    readonly moveDownIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom move bottom icon template.
     * @group Templates
     */
    readonly moveBottomIconTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom filter icon template.
     * @group Templates
     */
    filterIconTemplate: TemplateRef<void> | undefined;
    get moveUpAriaLabel(): string | undefined;
    get moveTopAriaLabel(): string | undefined;
    get moveDownAriaLabel(): string | undefined;
    get moveBottomAriaLabel(): string | undefined;
    _componentStyle: OrderListStyle;
    filterOptions: Nullable<OrderListFilterOptions>;
    d_selection: any[];
    movedUp: Nullable<boolean>;
    movedDown: Nullable<boolean>;
    itemTouched: Nullable<boolean>;
    styleElement: any;
    id: string;
    filterValue: Nullable<string>;
    visibleOptions: Nullable<any[]>;
    filterService: FilterService;
    constructor();
    getButtonProps(direction: string): ButtonProps;
    onInit(): void;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _itemTemplate: TemplateRef<OrderListItemTemplateContext> | undefined;
    _emptyMessageTemplate: TemplateRef<void> | undefined;
    _emptyFilterMessageTemplate: TemplateRef<void> | undefined;
    _filterTemplate: TemplateRef<OrderListFilterTemplateContext> | undefined;
    _headerTemplate: TemplateRef<void> | undefined;
    _moveUpIconTemplate: TemplateRef<void> | undefined;
    _moveTopIconTemplate: TemplateRef<void> | undefined;
    _moveDownIconTemplate: TemplateRef<void> | undefined;
    _moveBottomIconTemplate: TemplateRef<void> | undefined;
    _filterIconTemplate: TemplateRef<void> | undefined;
    onAfterContentInit(): void;
    onChangeSelection(e: ListboxChangeEvent): void;
    onFilterKeyup(event: KeyboardEvent): void;
    filter(): void;
    /**
     * Callback to invoke on filter reset.
     * @group Method
     */
    resetFilter(): void;
    isItemVisible(item: any): boolean | undefined;
    isSelected(item: any): boolean;
    isEmpty(): boolean;
    moveUp(): void;
    moveTop(): void;
    moveDown(): void;
    moveBottom(): void;
    onDrop(event: CdkDragDrop<string[]>): void;
    private sortByIndexInList;
    onListFocus(event: any): void;
    onListBlur(event: any): void;
    getVisibleOptions(): any[] | null;
    moveDisabled(): true | undefined;
    createStyle(): void;
    destroyStyle(): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OrderList, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<OrderList, "p-orderList, p-orderlist, p-order-list", never, { "header": { "alias": "header"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "listStyle": { "alias": "listStyle"; "required": false; "isSignal": true; }; "responsive": { "alias": "responsive"; "required": false; "isSignal": true; }; "filterBy": { "alias": "filterBy"; "required": false; "isSignal": true; }; "filterPlaceholder": { "alias": "filterPlaceholder"; "required": false; "isSignal": true; }; "filterLocale": { "alias": "filterLocale"; "required": false; "isSignal": true; }; "metaKeySelection": { "alias": "metaKeySelection"; "required": false; "isSignal": true; }; "dragdrop": { "alias": "dragdrop"; "required": false; "isSignal": true; }; "controlsPosition": { "alias": "controlsPosition"; "required": false; "isSignal": true; }; "ariaFilterLabel": { "alias": "ariaFilterLabel"; "required": false; "isSignal": true; }; "filterMatchMode": { "alias": "filterMatchMode"; "required": false; "isSignal": true; }; "breakpoint": { "alias": "breakpoint"; "required": false; "isSignal": true; }; "stripedRows": { "alias": "stripedRows"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "trackBy": { "alias": "trackBy"; "required": false; "isSignal": true; }; "scrollHeight": { "alias": "scrollHeight"; "required": false; "isSignal": true; }; "autoOptionFocus": { "alias": "autoOptionFocus"; "required": false; "isSignal": true; }; "dataKey": { "alias": "dataKey"; "required": false; "isSignal": true; }; "selection": { "alias": "selection"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "buttonProps": { "alias": "buttonProps"; "required": false; "isSignal": true; }; "moveUpButtonProps": { "alias": "moveUpButtonProps"; "required": false; "isSignal": true; }; "moveTopButtonProps": { "alias": "moveTopButtonProps"; "required": false; "isSignal": true; }; "moveDownButtonProps": { "alias": "moveDownButtonProps"; "required": false; "isSignal": true; }; "moveBottomButtonProps": { "alias": "moveBottomButtonProps"; "required": false; "isSignal": true; }; }, { "selection": "selectionChange"; "onReorder": "onReorder"; "onSelectionChange": "onSelectionChange"; "onFilterEvent": "onFilterEvent"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, ["moveUpIconTemplate", "moveTopIconTemplate", "moveDownIconTemplate", "moveBottomIconTemplate", "templates", "itemTemplate", "emptyMessageTemplate", "emptyFilterMessageTemplate", "filterTemplate", "headerTemplate", "filterIconTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class OrderListModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OrderListModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<OrderListModule, never, [typeof OrderList, typeof i2.SharedModule], [typeof OrderList, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<OrderListModule>;
}

export { OrderList, OrderListClasses, OrderListModule, OrderListStyle };
