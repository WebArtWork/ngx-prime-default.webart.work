import { DockPassThrough, DockItemTemplateContext } from '@wawjs/ngx-prime/types/dock';
export * from '@wawjs/ngx-prime/types/dock';
import * as _angular_core from '@angular/core';
import { ChangeDetectorRef, ElementRef, TemplateRef } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { MenuItem, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class DockStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-dock-mobile': any;
        })[];
        listContainer: string;
        list: string;
        item: ({ instance, item, id }: {
            instance: any;
            item: any;
            id: any;
        }) => (string | {
            'p-focus': any;
            'p-disabled': any;
        })[];
        itemContent: string;
        itemLink: string;
        itemIcon: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DockStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<DockStyle>;
}
/**
 *
 * Dock is a navigation component consisting of menuitems.
 *
 * [Live Demo](https://www.ngx-prime.org/dock/)
 *
 * @module dockstyle
 *
 */
declare enum DockClasses {
    /**
     * Class name of the root element
     */
    root = "p-dock",
    /**
     * Class name of the list container element
     */
    listContainer = "p-dock-list-container",
    /**
     * Class name of the list element
     */
    list = "p-dock-list",
    /**
     * Class name of the item element
     */
    item = "p-dock-item",
    /**
     * Class name of the item content element
     */
    itemContent = "p-dock-item-content",
    /**
     * Class name of the item link element
     */
    itemLink = "p-dock-item-link",
    /**
     * Class name of the item icon element
     */
    itemIcon = "p-dock-item-icon"
}

/**
 * Dock is a navigation component consisting of menuitems.
 * @group Components
 */
declare class Dock extends BaseComponent<DockPassThrough> {
    cd: ChangeDetectorRef;
    componentName: string;
    /**
     * Current id state as a string.
     * @group Props
     */
    id: _angular_core.InputSignal<string | undefined>;
    /**
     * Class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * MenuModel instance to define the action items.
     * @group Props
     */
    model: _angular_core.InputSignal<MenuItem[] | null | undefined>;
    /**
     * Position of element.
     * @group Props
     */
    position: _angular_core.InputSignal<"bottom" | "top" | "left" | "right">;
    /**
     * Defines a string that labels the input for accessibility.
     * @group Props
     */
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * The breakpoint to define the maximum width boundary.
     * @defaultValue 960px
     * @group Props
     */
    breakpoint: _angular_core.InputSignal<string>;
    /**
     * Defines a string that labels the dropdown button for accessibility.
     * @group Props
     */
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Callback to execute when button is focused.
     * @param {FocusEvent} event - Focus event.
     * @group Emits
     */
    onFocus: _angular_core.OutputEmitterRef<FocusEvent>;
    /**
     * Callback to invoke when the component loses focus.
     * @param {FocusEvent} event - Focus event.
     * @group Emits
     */
    onBlur: _angular_core.OutputEmitterRef<FocusEvent>;
    private _generatedId;
    get resolvedId(): string;
    readonly listViewChild: _angular_core.Signal<Nullable<ElementRef<any>>>;
    currentIndex: number;
    tabindex: number;
    focused: boolean;
    focusedOptionIndex: string | number;
    _componentStyle: DockStyle;
    bindDirectiveInstance: Bind;
    $pcDock: Dock | undefined;
    matchMediaListener: any;
    query: any;
    queryMatches: _angular_core.WritableSignal<boolean>;
    mobileActive: _angular_core.WritableSignal<boolean>;
    get focusedOptionId(): string | null;
    constructor();
    onInit(): void;
    onDestroy(): void;
    /**
     * Custom item template.
     * @param {DockItemTemplateContext} context - item template context.
     * @group Templates
     */
    readonly itemTemplate: _angular_core.Signal<TemplateRef<DockItemTemplateContext> | undefined>;
    _itemTemplate: TemplateRef<DockItemTemplateContext> | undefined;
    getItemId(item: any, index: any): any;
    getItemProp(processedItem: any, name: any): any;
    disabled(item: any): any;
    isItemActive(id: any): boolean;
    onListMouseLeave(): void;
    onItemMouseEnter(index: number): void;
    onItemClick(e: Event, item: MenuItem): void;
    onListFocus(event: any): void;
    onListBlur(event: any): void;
    onListKeyDown(event: any): void;
    onArrowDownKey(): void;
    onArrowUpKey(): void;
    onHomeKey(): void;
    onEndKey(): void;
    onSpaceKey(): void;
    findNextOptionIndex(index: any): number;
    changeFocusedOptionIndex(index: any): void;
    findPrevOptionIndex(index: any): number;
    isClickableRouterLink(item: any): boolean;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    onAfterContentInit(): void;
    onAfterViewChecked(): void;
    getPTOptions(item: MenuItem, index: number, key: string): any;
    bindMatchMediaListener(): void;
    unbindMatchMediaListener(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Dock, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Dock, "p-dock", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "model": { "alias": "model"; "required": false; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "breakpoint": { "alias": "breakpoint"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; }, { "onFocus": "onFocus"; "onBlur": "onBlur"; }, ["itemTemplate", "templates"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class DockModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DockModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<DockModule, never, [typeof Dock, typeof i2.SharedModule], [typeof Dock, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<DockModule>;
}

export { Dock, DockClasses, DockModule, DockStyle };
