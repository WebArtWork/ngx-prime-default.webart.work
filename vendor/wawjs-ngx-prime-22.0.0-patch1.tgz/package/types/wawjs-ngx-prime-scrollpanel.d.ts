import { ScrollPanelPassThrough } from '@wawjs/ngx-prime/types/scrollpanel';
export * from '@wawjs/ngx-prime/types/scrollpanel';
import * as _angular_core from '@angular/core';
import { ElementRef, TemplateRef, NgZone } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Nullable } from '@wawjs/ngx-prime/ts-helpers';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class ScrollPanelStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: string;
        contentContainer: string;
        content: string;
        barX: string;
        barY: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ScrollPanelStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ScrollPanelStyle>;
}
/**
 *
 * ScrollPanel is a cross browser, lightweight and themable alternative to native browser scrollbar.
 *
 * [Live Demo](https://www.ngx-prime.org/scrollpanel/)
 *
 * @module scrollpanelstyle
 *
 */
declare enum ScrollPanelClasses {
    /**
     * Class name of the root element
     */
    root = "p-scrollpanel",
    /**
     * Class name of the content container element
     */
    contentContainer = "p-scrollpanel-content-container",
    /**
     * Class name of the content element
     */
    content = "p-scrollpanel-content",
    /**
     * Class name of the bar x element
     */
    barX = "p-scrollpanel-bar-x",
    /**
     * Class name of the bar y element
     */
    barY = "p-scrollpanel-bar-y"
}

/**
 * ScrollPanel is a cross browser, lightweight and themable alternative to native browser scrollbar.
 * @group Components
 */
declare class ScrollPanel extends BaseComponent<ScrollPanelPassThrough> {
    componentName: string;
    $pcScrollPanel: ScrollPanel | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Step factor to scroll the content while pressing the arrow keys.
     * @group Props
     */
    step: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly contentViewChild: _angular_core.Signal<ElementRef<any> | undefined>;
    readonly xBarViewChild: _angular_core.Signal<ElementRef<any> | undefined>;
    readonly yBarViewChild: _angular_core.Signal<ElementRef<any> | undefined>;
    /**
     * Custom content template.
     * @group Templates
     */
    readonly contentTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _contentTemplate: TemplateRef<void> | undefined;
    scrollYRatio: number | undefined;
    scrollXRatio: number | undefined;
    timeoutFrame: any;
    initialized: boolean;
    lastPageY: number | undefined;
    lastPageX: number | undefined;
    isXBarClicked: boolean;
    isYBarClicked: boolean;
    lastScrollLeft: number;
    lastScrollTop: number;
    orientation: string;
    timer: any;
    contentId: string | undefined;
    windowResizeListener: VoidFunction | null | undefined;
    contentScrollListener: VoidFunction | null | undefined;
    mouseEnterListener: VoidFunction | null | undefined;
    xBarMouseDownListener: VoidFunction | null | undefined;
    yBarMouseDownListener: VoidFunction | null | undefined;
    documentMouseMoveListener: Nullable<(event?: any) => void>;
    documentMouseUpListener: Nullable<(event?: any) => void>;
    _componentStyle: ScrollPanelStyle;
    zone: NgZone;
    onInit(): void;
    onAfterViewInit(): void;
    onAfterContentInit(): void;
    calculateContainerHeight(): void;
    moveBar(): void;
    onScroll(event: any): void;
    onKeyDown(event: any): void;
    onKeyUp(): void;
    repeat(bar: any, step: any): void;
    setTimer(bar: any, step: any): void;
    clearTimer(): void;
    bindDocumentMouseListeners(): void;
    unbindDocumentMouseListeners(): void;
    onYBarMouseDown(e: MouseEvent): void;
    onXBarMouseDown(e: MouseEvent): void;
    onDocumentMouseMove(e: MouseEvent): void;
    onMouseMoveForXBar(e: MouseEvent): void;
    onMouseMoveForYBar(e: MouseEvent): void;
    /**
     * Scrolls the top location to the given value.
     * @param scrollTop
     * @group Method
     */
    scrollTop(scrollTop: number): void;
    onFocus(event: any): void;
    onBlur(): void;
    onDocumentMouseUp(): void;
    requestAnimationFrame(f: VoidFunction): void;
    unbindListeners(): void;
    onDestroy(): void;
    /**
     * Refreshes the position and size of the scrollbar.
     * @group Method
     */
    refresh(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ScrollPanel, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ScrollPanel, "p-scroll-panel, p-scrollPanel, p-scrollpanel", never, { "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; }, {}, ["contentTemplate", "templates"], ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class ScrollPanelModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ScrollPanelModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<ScrollPanelModule, never, [typeof ScrollPanel, typeof i2.SharedModule, typeof i1.BindModule], [typeof ScrollPanel, typeof i2.SharedModule, typeof i1.BindModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<ScrollPanelModule>;
}

export { ScrollPanel, ScrollPanelClasses, ScrollPanelModule, ScrollPanelStyle };
