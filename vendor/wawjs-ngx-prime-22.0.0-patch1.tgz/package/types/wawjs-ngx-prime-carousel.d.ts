import { CarouselResponsiveOptions, CarouselPageEvent, CarouselItemTemplateContext } from '@wawjs/ngx-prime/types/carousel';
export * from '@wawjs/ngx-prime/types/carousel';
import * as _angular_core from '@angular/core';
import { ElementRef, NgZone, TemplateRef } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { Header, Footer, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { ButtonProps } from '@wawjs/ngx-prime/button';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class CarouselStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-carousel-vertical': any;
            'p-carousel-horizontal': boolean;
        })[];
        header: string;
        contentContainer: string;
        content: string;
        pcPrevButton: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-disabled': any;
        })[];
        viewport: string;
        itemList: string;
        itemClone: ({ instance, index }: {
            instance: any;
            index: any;
        }) => (string | {
            'p-carousel-item-active': boolean;
            'p-carousel-item-start': boolean;
            'p-carousel-item-end': boolean;
        })[];
        item: ({ instance, index }: {
            instance: any;
            index: any;
        }) => (string | {
            'p-carousel-item-active': boolean;
            'p-carousel-item-start': boolean;
            'p-carousel-item-end': boolean;
        })[];
        pcNextButton: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-disabled': any;
        })[];
        indicatorList: ({ instance }: {
            instance: any;
        }) => any[];
        indicator: ({ instance, index }: {
            instance: any;
            index: any;
        }) => (string | {
            'p-carousel-indicator-active': boolean;
        })[];
        indicatorButton: ({ instance }: {
            instance: any;
        }) => any[];
        footer: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CarouselStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<CarouselStyle>;
}
/**
 *
 * Carousel is a content slider featuring various customization options.
 *
 * [Live Demo](https://www.ngx-prime.org/carousel/)
 *
 * @module carouselstyle
 *
 */
declare enum CarouselClasses {
    /**
     * Class name of the root element
     */
    root = "p-carousel",
    /**
     * Class name of the header element
     */
    header = "p-carousel-header",
    /**
     * Class name of the content container element
     */
    contentContainer = "p-carousel-content-container",
    /**
     * Class name of the content element
     */
    content = "p-carousel-content",
    /**
     * Class name of the previous button element
     */
    pcPrevButton = "p-carousel-prev-button",
    /**
     * Class name of the viewport element
     */
    viewport = "p-carousel-viewport",
    /**
     * Class name of the item list element
     */
    itemList = "p-carousel-item-list",
    /**
     * Class name of the item clone element
     */
    itemClone = "p-carousel-item-clone",
    /**
     * Class name of the item element
     */
    item = "p-carousel-item",
    /**
     * Class name of the next button element
     */
    pcNextButton = "p-carousel-next-button",
    /**
     * Class name of the indicator list element
     */
    indicatorList = "p-carousel-indicator-list",
    /**
     * Class name of the indicator element
     */
    indicator = "p-carousel-indicator",
    /**
     * Class name of the indicator button element
     */
    indicatorButton = "p-carousel-indicator-button",
    /**
     * Class name of the footer element
     */
    footer = "p-carousel-footer"
}

/**
 * Carousel is a content slider featuring various customization options.
 * @group Components
 */
declare class Carousel extends BaseComponent {
    el: ElementRef<any>;
    zone: NgZone;
    componentName: string;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Index of the first item.
     * @defaultValue 0
     * @group Props
     */
    page: _angular_core.InputSignal<number>;
    /**
     * Number of items per page.
     * @defaultValue 1
     * @group Props
     */
    numVisible: _angular_core.InputSignal<number>;
    /**
     * Number of items to scroll.
     * @defaultValue 1
     * @group Props
     */
    numScroll: _angular_core.InputSignal<number>;
    /**
     * An array of options for responsive design.
     * @see {CarouselResponsiveOptions}
     * @group Props
     */
    responsiveOptions: _angular_core.InputSignal<CarouselResponsiveOptions[] | undefined>;
    /**
     * Specifies the layout of the component.
     * @group Props
     */
    orientation: _angular_core.InputSignal<"horizontal" | "vertical">;
    /**
     * Height of the viewport in vertical layout.
     * @group Props
     */
    verticalViewPortHeight: _angular_core.InputSignal<string>;
    /**
     * Style class of main content.
     * @group Props
     */
    contentClass: _angular_core.InputSignal<string>;
    /**
     * Style class of the indicator items.
     * @group Props
     */
    indicatorsContentClass: _angular_core.InputSignal<string>;
    /**
     * Inline style of the indicator items.
     * @group Props
     */
    indicatorsContentStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Style class of the indicators.
     * @group Props
     */
    indicatorStyleClass: _angular_core.InputSignal<string>;
    /**
     * Style of the indicators.
     * @group Props
     */
    indicatorStyle: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * An array of objects to display.
     * @defaultValue null
     * @group Props
     */
    value: _angular_core.InputSignal<any[] | undefined>;
    /**
     * Defines if scrolling would be infinite.
     * @group Props
     */
    circular: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to display indicator container.
     * @group Props
     */
    showIndicators: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to display navigation buttons in container.
     * @group Props
     */
    showNavigators: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Time in milliseconds to scroll items automatically.
     * @group Props
     */
    autoplayInterval: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Style class of the viewport container.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Used to pass all properties of the ButtonProps to the Button component.
     * @group Props
     */
    prevButtonProps: _angular_core.InputSignal<ButtonProps>;
    /**
     * Used to pass all properties of the ButtonProps to the Button component.
     * @group Props
     */
    nextButtonProps: _angular_core.InputSignal<ButtonProps>;
    /**
     * Callback to invoke after scroll.
     * @param {CarouselPageEvent} event - Custom page event.
     * @group Emits
     */
    onPage: _angular_core.OutputEmitterRef<CarouselPageEvent>;
    readonly itemsContainer: _angular_core.Signal<ElementRef<any> | undefined>;
    readonly indicatorContent: _angular_core.Signal<ElementRef<any> | undefined>;
    readonly headerFacet: _angular_core.Signal<Header | undefined>;
    readonly footerFacet: _angular_core.Signal<Footer | undefined>;
    _numVisible: number;
    _numScroll: number;
    _oldNumScroll: number;
    prevState: any;
    defaultNumScroll: number;
    defaultNumVisible: number;
    _page: number;
    carouselStyle: any;
    id: string | undefined;
    totalShiftedItems: any;
    isRemainingItemsAdded: boolean;
    animationTimeout: any;
    translateTimeout: any;
    remainingItems: number;
    _items: any[] | undefined;
    startPos: any;
    documentResizeListener: any;
    clonedItemsForStarting: any[] | undefined;
    clonedItemsForFinishing: any[] | undefined;
    allowAutoplay: boolean | undefined;
    interval: any;
    isCreated: boolean | undefined;
    swipeThreshold: number;
    /**
     * Custom item template.
     * @group Templates
     */
    readonly itemTemplate: _angular_core.Signal<TemplateRef<CarouselItemTemplateContext<any>> | undefined>;
    /**
     * Custom header template.
     * @group Templates
     */
    headerTemplate: TemplateRef<void> | undefined;
    /**
     * Custom footer template.
     * @group Templates
     */
    footerTemplate: TemplateRef<void> | undefined;
    /**
     * Custom previous icon template.
     * @group Templates
     */
    previousIconTemplate: TemplateRef<void> | undefined;
    /**
     * Custom next icon template.
     * @group Templates
     */
    nextIconTemplate: TemplateRef<void> | undefined;
    _itemTemplate: TemplateRef<CarouselItemTemplateContext> | undefined;
    _headerTemplate: TemplateRef<void> | undefined;
    _footerTemplate: TemplateRef<void> | undefined;
    _previousIconTemplate: TemplateRef<void> | undefined;
    _nextIconTemplate: TemplateRef<void> | undefined;
    window: Window;
    _componentStyle: CarouselStyle;
    constructor();
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    onAfterContentInit(): void;
    onAfterContentChecked(): void;
    createStyle(): void;
    calculatePosition(): void;
    setCloneItems(): void;
    firstIndex(): number;
    lastIndex(): number;
    totalDots(): number;
    totalDotsArray(): any[];
    isVertical(): boolean;
    isCircular(): boolean | undefined;
    isAutoplay(): boolean | 0 | undefined;
    isForwardNavDisabled(): boolean;
    isBackwardNavDisabled(): boolean;
    isEmpty(): boolean;
    navForward(e: MouseEvent | TouchEvent, index?: number): void;
    navBackward(e: MouseEvent | TouchEvent, index?: number): void;
    onDotClick(e: MouseEvent, index: number): void;
    onIndicatorKeydown(event: KeyboardEvent): void;
    onRightKey(): void;
    onLeftKey(): void;
    onHomeKey(): void;
    onEndKey(): void;
    onTabKey(): void;
    findFocusedIndicatorIndex(): number;
    changedFocusedIndicator(prevInd: any, nextInd: any): void;
    step(dir: number, page?: number): void;
    startAutoplay(): void;
    stopAutoplay(changeAllow?: boolean): void;
    isPlaying(): boolean;
    onTransitionEnd(): void;
    onTouchStart(e: TouchEvent): void;
    onTouchMove(e: TouchEvent | MouseEvent): void;
    onTouchEnd(e: TouchEvent): void;
    changePageOnTouch(e: TouchEvent | MouseEvent, diff: number): void;
    ariaPrevButtonLabel(): string | undefined;
    ariaSlideLabel(): string | undefined;
    ariaNextButtonLabel(): string | undefined;
    ariaSlideNumber(value: any): string | undefined;
    ariaPageLabel(value: any): string | undefined;
    getIndicatorPTOptions(key: string, index: number): any;
    getItemPTOptions(key: string, index: number): any;
    bindDocumentListeners(): void;
    unbindDocumentListeners(): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Carousel, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Carousel, "p-carousel", never, { "page": { "alias": "page"; "required": false; "isSignal": true; }; "numVisible": { "alias": "numVisible"; "required": false; "isSignal": true; }; "numScroll": { "alias": "numScroll"; "required": false; "isSignal": true; }; "responsiveOptions": { "alias": "responsiveOptions"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "verticalViewPortHeight": { "alias": "verticalViewPortHeight"; "required": false; "isSignal": true; }; "contentClass": { "alias": "contentClass"; "required": false; "isSignal": true; }; "indicatorsContentClass": { "alias": "indicatorsContentClass"; "required": false; "isSignal": true; }; "indicatorsContentStyle": { "alias": "indicatorsContentStyle"; "required": false; "isSignal": true; }; "indicatorStyleClass": { "alias": "indicatorStyleClass"; "required": false; "isSignal": true; }; "indicatorStyle": { "alias": "indicatorStyle"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "circular": { "alias": "circular"; "required": false; "isSignal": true; }; "showIndicators": { "alias": "showIndicators"; "required": false; "isSignal": true; }; "showNavigators": { "alias": "showNavigators"; "required": false; "isSignal": true; }; "autoplayInterval": { "alias": "autoplayInterval"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "prevButtonProps": { "alias": "prevButtonProps"; "required": false; "isSignal": true; }; "nextButtonProps": { "alias": "nextButtonProps"; "required": false; "isSignal": true; }; }, { "onPage": "onPage"; }, ["headerFacet", "footerFacet", "itemTemplate", "templates", "headerTemplate", "footerTemplate", "previousIconTemplate", "nextIconTemplate"], ["p-header", "p-footer"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class CarouselModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CarouselModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<CarouselModule, never, [typeof Carousel, typeof i2.SharedModule], [typeof Carousel, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<CarouselModule>;
}

export { Carousel, CarouselClasses, CarouselModule, CarouselStyle };
