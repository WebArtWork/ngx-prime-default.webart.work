import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i0 from '@angular/core';

declare class ButtonGroupStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonGroupStyle, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ButtonGroupStyle>;
}
/**
 *
 * A set of Buttons can be displayed together using the ButtonGroup component.
 *
 * [Live Demo](https://www.ngx-prime.org/button/)
 *
 * @module buttongroupstyle
 *
 */
declare enum ButtonGroupClasses {
    /**
     * Class name of the root element
     */
    root = "p-buttongroup"
}

declare class ButtonGroup extends BaseComponent {
    componentName: string;
    _componentStyle: ButtonGroupStyle;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonGroup, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonGroup, "p-buttonGroup, p-buttongroup, p-button-group", never, {}, {}, never, ["*"], true, never>;
}
declare class ButtonGroupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonGroupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ButtonGroupModule, never, [typeof ButtonGroup], [typeof ButtonGroup]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ButtonGroupModule>;
}

export { ButtonGroup, ButtonGroupClasses, ButtonGroupModule, ButtonGroupStyle };
