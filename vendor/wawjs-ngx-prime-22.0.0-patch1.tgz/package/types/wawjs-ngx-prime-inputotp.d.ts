import * as _angular_core from '@angular/core';
import { AfterViewChecked, TemplateRef } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { InputOtpPassThrough, InputOtpChangeEvent, InputOtpInputTemplateContext } from '@wawjs/ngx-prime/types/inputotp';
export { InputOtpChangeEvent, InputOtpInputTemplateContext, InputOtpTemplateEvents } from '@wawjs/ngx-prime/types/inputotp';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class InputOtpStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: string;
        pcInputText: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InputOtpStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<InputOtpStyle>;
}
/**
 *
 * InputOtp is used to enter one time passwords.
 *
 * [Live Demo](https://www.ngx-prime.org/inputotp/)
 *
 * @module inputotpstyle
 *
 */
declare enum InputOtpClasses {
    /**
     * Class name of the root element
     */
    root = "p-inputotp",
    /**
     * Class name of the input element
     */
    pcInputText = "p-inputotp-input"
}

declare const INPUT_OTP_VALUE_ACCESSOR: any;

/**
 * Input Otp is used to enter one time passwords.
 * @group Components
 */
declare class InputOtp extends BaseEditableHolder<InputOtpPassThrough> implements AfterViewChecked {
    componentName: string;
    _componentStyle: InputOtpStyle;
    $pcInputOtp: InputOtp | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * When present, it specifies that an input field is read-only.
     * @group Props
     */
    readonly: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex: _angular_core.InputSignal<number | null>;
    /**
     * Number of characters to initiate.
     * @group Props
     */
    length: _angular_core.InputSignal<number>;
    /**
     * Style class of the input element.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Mask pattern.
     * @group Props
     */
    mask: _angular_core.InputSignal<boolean>;
    /**
     * When present, it specifies that an input field is integer-only.
     * @group Props
     */
    integerOnly: _angular_core.InputSignal<boolean>;
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Specifies the input variant of the component.
     * @defaultValue undefined
     * @group Props
     */
    variant: _angular_core.InputSignal<"filled" | "outlined" | undefined>;
    /**
     * Specifies the size of the component.
     * @defaultValue undefined
     * @group Props
     */
    size: _angular_core.InputSignal<"large" | "small" | undefined>;
    /**
     * Callback to invoke on value change.
     * @group Emits
     */
    onChange: _angular_core.OutputEmitterRef<InputOtpChangeEvent>;
    /**
     * Callback to invoke when the component receives focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onFocus: _angular_core.OutputEmitterRef<Event>;
    /**
     * Callback to invoke when the component loses focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onBlur: _angular_core.OutputEmitterRef<Event>;
    /**
     * Custom input template.
     * @param {InputOtpInputTemplateContext} context - Context of the template
     * @see {@link InputOtpInputTemplateContext}
     * @group Templates
     */
    inputTemplate: TemplateRef<InputOtpInputTemplateContext> | undefined;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    _inputTemplate: TemplateRef<InputOtpInputTemplateContext> | undefined;
    tokens: any;
    value: any;
    $variant: _angular_core.Signal<"filled" | "outlined" | null>;
    get inputMode(): string;
    get inputType(): string;
    onAfterContentInit(): void;
    getToken(index: any): any;
    getTemplateEvents(index: any): {
        input: (event: any) => void;
        keydown: (event: any) => void;
        focus: (event: any) => void;
        blur: (event: any) => void;
        paste: (event: any) => void;
    };
    onInput(event: any, index: any): void;
    updateModel(event: any): void;
    updateTokens(): void;
    getModelValue(i: number): any;
    getAutofocus(i: number): boolean;
    moveToPrev(event: any): void;
    moveToNext(event: any): void;
    findNextInput(element: any): any;
    findPrevInput(element: any): any;
    onInputFocus(event: any): void;
    onInputBlur(event: any): void;
    onKeyDown(event: any): void;
    onPaste(event: any): void;
    handleOnPaste(paste: any, event: any): void;
    getRange(n: number): number[];
    trackByFn(index: number): number;
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value: any, setModelValue: (value: any) => void): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InputOtp, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<InputOtp, "p-inputOtp, p-inputotp, p-input-otp", never, { "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "length": { "alias": "length"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "mask": { "alias": "mask"; "required": false; "isSignal": true; }; "integerOnly": { "alias": "integerOnly"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, { "onChange": "onChange"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, ["templates", "inputTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class InputOtpModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InputOtpModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<InputOtpModule, never, [typeof InputOtp, typeof i2.SharedModule], [typeof InputOtp, typeof i2.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<InputOtpModule>;
}

export { INPUT_OTP_VALUE_ACCESSOR, InputOtp, InputOtpClasses, InputOtpModule, InputOtpStyle };
