import * as i0 from '@angular/core';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { InputGroupPassThrough } from '@wawjs/ngx-prime/types/inputgroup';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i2 from '@wawjs/ngx-prime/api';

declare class InputGroupStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-inputgroup-fluid': any;
        })[];
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<InputGroupStyle, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<InputGroupStyle>;
}
/**
 *
 * InputGroup displays text, icon, buttons and other content can be grouped next to an input.
 *
 * [Live Demo](https://www.ngx-prime.org/inputgroup/)
 *
 * @module inputgroupstyle
 *
 */
declare enum InputGroupClasses {
    /**
     * Class name of the root element
     */
    root = "p-inputgroup"
}

/**
 * InputGroup displays text, icon, buttons and other content can be grouped next to an input.
 * @group Components
 */
declare class InputGroup extends BaseComponent<InputGroupPassThrough> {
    componentName: string;
    _componentStyle: InputGroupStyle;
    $pcInputGroup: InputGroup | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: i0.InputSignal<string | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<InputGroup, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InputGroup, "p-inputgroup, p-inputGroup, p-input-group", never, { "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class InputGroupModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<InputGroupModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<InputGroupModule, never, [typeof InputGroup, typeof i2.SharedModule], [typeof InputGroup, typeof i2.SharedModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<InputGroupModule>;
}

export { InputGroup, InputGroupClasses, InputGroupModule, InputGroupStyle };
