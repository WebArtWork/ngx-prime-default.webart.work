import * as i0 from '@angular/core';
import { AfterViewChecked } from '@angular/core';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { IconFieldPassThrough } from '@wawjs/ngx-prime/types/iconfield';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class IconFieldStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-iconfield-left': boolean;
            'p-iconfield-right': boolean;
        })[];
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<IconFieldStyle, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<IconFieldStyle>;
}
/**
 *
 * IconField wraps an input and an icon.
 *
 * [Live Demo](https://www.ngx-prime.org/iconfield/)
 *
 * @module iconfieldstyle
 *
 */
declare enum IconFieldClasses {
    /**
     * Class name of the root element
     */
    root = "p-iconfield"
}

/**
 * IconField wraps an input and an icon.
 * @group Components
 */
declare class IconField extends BaseComponent<IconFieldPassThrough> implements AfterViewChecked {
    componentName: string;
    hostName: i0.InputSignal<any>;
    _componentStyle: IconFieldStyle;
    $pcIconField: IconField | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Position of the icon.
     * @group Props
     */
    iconPosition: i0.InputSignal<"left" | "right">;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: i0.InputSignal<string | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconField, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IconField, "p-iconfield, p-iconField, p-icon-field", never, { "hostName": { "alias": "hostName"; "required": false; "isSignal": true; }; "iconPosition": { "alias": "iconPosition"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class IconFieldModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<IconFieldModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<IconFieldModule, never, [typeof IconField], [typeof IconField]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<IconFieldModule>;
}

export { IconField, IconFieldClasses, IconFieldModule, IconFieldStyle };
