import * as _angular_core from '@angular/core';
import { NgControl } from '@angular/forms';
import { BaseModelHolder } from '@wawjs/ngx-prime/basemodelholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Fluid } from '@wawjs/ngx-prime/fluid';
import { InputTextPassThrough } from '@wawjs/ngx-prime/types/inputtext';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class InputTextStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-filled': any;
            'p-inputtext-sm': boolean;
            'p-inputtext-lg': boolean;
            'p-invalid': any;
            'p-variant-filled': boolean;
            'p-inputtext-fluid': any;
        })[];
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InputTextStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<InputTextStyle>;
}
/**
 *
 * InputText renders a text field to enter data.
 *
 * [Live Demo](https://www.ngx-prime.org/inputtext/)
 *
 * @module inputtextstyle
 *
 */
declare enum InputTextClasses {
    /**
     * The class of root element
     */
    root = "p-inputtext"
}

/**
 * InputText directive is an extension to standard input element with theming.
 * @group Components
 */
declare class InputText extends BaseModelHolder<InputTextPassThrough> {
    componentName: string;
    hostName: _angular_core.InputSignal<any>;
    /**
     * Used to pass attributes to DOM elements inside the InputText component.
     * @defaultValue undefined
     * @deprecated use pInputTextPT instead.
     * @group Props
     */
    ptInputText: _angular_core.InputSignal<InputTextPassThrough>;
    /**
     * Used to pass attributes to DOM elements inside the InputText component.
     * @defaultValue undefined
     * @group Props
     */
    pInputTextPT: _angular_core.InputSignal<InputTextPassThrough>;
    /**
     * Indicates whether the component should be rendered without styles.
     * @defaultValue undefined
     * @group Props
     */
    pInputTextUnstyled: _angular_core.InputSignal<boolean | undefined>;
    bindDirectiveInstance: Bind;
    $pcInputText: InputText | undefined;
    ngControl: NgControl | null;
    pcFluid: Fluid | null;
    /**
     * Defines the size of the component.
     * @group Props
     */
    pSize: _angular_core.InputSignal<"small" | "large" | undefined>;
    /**
     * Specifies the input variant of the component.
     * @defaultValue undefined
     * @group Props
     */
    variant: _angular_core.InputSignal<"filled" | "outlined" | undefined>;
    /**
     * Spans 100% width of the container when enabled.
     * @defaultValue undefined
     * @group Props
     */
    fluid: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When present, it specifies that the component should have invalid state style.
     * @defaultValue false
     * @group Props
     */
    invalid: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    $variant: _angular_core.Signal<"filled" | "outlined" | null>;
    _componentStyle: InputTextStyle;
    constructor();
    onAfterViewInit(): void;
    onAfterViewChecked(): void;
    onDoCheck(): void;
    onInput(): void;
    get hasFluid(): boolean;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InputText, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<InputText, "[pInputText]", never, { "hostName": { "alias": "hostName"; "required": false; "isSignal": true; }; "ptInputText": { "alias": "ptInputText"; "required": false; "isSignal": true; }; "pInputTextPT": { "alias": "pInputTextPT"; "required": false; "isSignal": true; }; "pInputTextUnstyled": { "alias": "pInputTextUnstyled"; "required": false; "isSignal": true; }; "pSize": { "alias": "pSize"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class InputTextModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InputTextModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<InputTextModule, never, [typeof InputText], [typeof InputText]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<InputTextModule>;
}

export { InputText, InputTextClasses, InputTextModule, InputTextStyle };
