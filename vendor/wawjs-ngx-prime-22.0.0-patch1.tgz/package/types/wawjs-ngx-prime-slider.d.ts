import { SliderPassThrough, SliderChangeEvent, SliderSlideEndEvent } from '@wawjs/ngx-prime/types/slider';
export * from '@wawjs/ngx-prime/types/slider';
import * as _angular_core from '@angular/core';
import { ElementRef } from '@angular/core';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Nullable, VoidListener } from '@wawjs/ngx-prime/ts-helpers';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import { BaseModelHolder } from '@wawjs/ngx-prime/basemodelholder';
import * as i3 from '@wawjs/ngx-prime/api';

declare class SliderStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-disabled': any;
            'p-invalid': any;
            'p-slider-horizontal': boolean;
            'p-slider-vertical': boolean;
            'p-slider-animate': any;
        })[];
        range: string;
        handle: string;
    };
    inlineStyles: {
        handle: {
            position: string;
        };
        range: {
            position: string;
        };
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SliderStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SliderStyle>;
}
/**
 *
 * Slider is a component to provide input with a drag handle.
 *
 * [Live Demo](https://www.ngx-prime.org/slider/)
 *
 * @module sliderstyle
 *
 */
declare enum SliderClasses {
    /**
     * Class name of the root element
     */
    root = "p-slider",
    /**
     * Class name of the range element
     */
    range = "p-slider-range",
    /**
     * Class name of the handle element
     */
    handle = "p-slider-handle"
}

/** Adds Prime behavior to a native range input. */
declare class RangeDirective extends BaseModelHolder<SliderPassThrough> {
    componentName: string;
    private readonly element;
    private readonly bindDirectiveInstance;
    _componentStyle: SliderStyle;
    invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    vertical: _angular_core.InputSignalWithTransform<boolean, unknown>;
    orientation: _angular_core.InputSignal<"horizontal" | "vertical">;
    animate: _angular_core.InputSignalWithTransform<boolean, unknown>;
    min: _angular_core.InputSignalWithTransform<number, unknown>;
    max: _angular_core.InputSignalWithTransform<number, unknown>;
    step: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    ariaDescribedBy: _angular_core.InputSignal<string | undefined>;
    onChange: _angular_core.OutputEmitterRef<SliderChangeEvent>;
    onSlideEnd: _angular_core.OutputEmitterRef<SliderSlideEndEvent>;
    onInput: _angular_core.OutputEmitterRef<SliderChangeEvent>;
    onFocus: _angular_core.OutputEmitterRef<Event>;
    onBlur: _angular_core.OutputEmitterRef<Event>;
    touch: _angular_core.OutputEmitterRef<void>;
    resolvedOrientation: _angular_core.Signal<"horizontal" | "vertical">;
    onAfterViewChecked(): void;
    handleInput(event: Event): void;
    onNativeChange(event: Event): void;
    $disabled(): boolean;
    onNativeBlur(event: Event): void;
    focus(options?: FocusOptions): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RangeDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<RangeDirective, "input[type='range'][pRange]", ["pRange"], { "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "vertical": { "alias": "vertical"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "animate": { "alias": "animate"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "ariaDescribedBy": { "alias": "ariaDescribedBy"; "required": false; "isSignal": true; }; }, { "onChange": "onChange"; "onSlideEnd": "onSlideEnd"; "onInput": "onInput"; "onFocus": "onFocus"; "onBlur": "onBlur"; "touch": "touch"; }, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}

declare const SLIDER_VALUE_ACCESSOR: any;
/**
 * Legacy slider component, available through v22 under the `p-slider` and `p-range` selectors.
 * @deprecated since v22, use `<input type="range" pRange>` for single-value sliders. Both legacy selectors will be removed in v23; use a dedicated range strategy where two thumbs are required.
 * @group Components
 */
declare class Slider extends BaseEditableHolder<SliderPassThrough> {
    componentName: string;
    $pcSlider: Slider | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * When enabled, displays an animation on click of the slider bar.
     * @group Props
     */
    animate: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Mininum boundary value.
     * @group Props
     */
    min: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Maximum boundary value.
     * @group Props
     */
    max: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Orientation of the slider.
     * @group Props
     */
    orientation: _angular_core.InputSignal<"horizontal" | "vertical">;
    /**
     * Step factor to increment/decrement the value.
     * @group Props
     */
    step: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * When specified, allows two boundary values to be picked.
     * @group Props
     */
    range: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Defines a string that labels the input for accessibility.
     * @group Props
     */
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Callback to invoke on value change.
     * @param {SliderChangeEvent} event - Custom value change event.
     * @group Emits
     */
    onChange: _angular_core.OutputEmitterRef<SliderChangeEvent>;
    /**
     * Callback to invoke when slide ended.
     * @param {SliderSlideEndEvent} event - Custom slide end event.
     * @group Emits
     */
    onSlideEnd: _angular_core.OutputEmitterRef<SliderSlideEndEvent>;
    readonly sliderHandle: _angular_core.Signal<Nullable<ElementRef<any>>>;
    sliderHandleStart: Nullable<ElementRef>;
    sliderHandleEnd: Nullable<ElementRef>;
    _componentStyle: SliderStyle;
    value: Nullable<number>;
    values: Nullable<number[]>;
    handleValue: Nullable<number>;
    handleValues: number[];
    diff: Nullable<number>;
    offset: Nullable<number>;
    bottom: Nullable<number>;
    dragging: Nullable<boolean>;
    dragListener: VoidListener;
    mouseupListener: VoidListener;
    initX: Nullable<number>;
    initY: Nullable<number>;
    barWidth: Nullable<number>;
    barHeight: Nullable<number>;
    sliderHandleClick: Nullable<boolean>;
    handleIndex: number;
    startHandleValue: any;
    startx: Nullable<number>;
    starty: Nullable<number>;
    private ngZone;
    onHostClick(event: MouseEvent): void;
    onMouseDown(event: Event, index?: number): void;
    onDragStart(event: TouchEvent, index?: number): void;
    onDrag(event: TouchEvent): void;
    onDragEnd(event: TouchEvent): void;
    onBarClick(event: Event): void;
    onKeyDown(event: any, index?: any): void;
    decrementValue(event: any, index: any, pageKey?: boolean): void;
    incrementValue(event: any, index: any, pageKey?: boolean): void;
    handleChange(event: Event): void;
    bindDragListeners(): void;
    unbindDragListeners(): void;
    setValueFromHandle(event: Event, handleValue: any): void;
    handleStepChange(newValue: number, oldValue: number): void;
    get rangeStartLeft(): string | null;
    get rangeStartBottom(): string;
    get rangeEndLeft(): string | null;
    get rangeEndBottom(): string;
    isVertical(): boolean;
    updateDomData(): void;
    calculateHandleValue(event: Event): number;
    updateHandleValue(): void;
    updateDiffAndOffset(): void;
    getDiff(): number;
    getOffset(): number;
    updateValue(val: number, event?: Event): void;
    getValueFromHandle(handleValue: number): number;
    getDecimalsCount(value: number): number;
    getNormalizedValue(val: number): number;
    onDestroy(): void;
    get minVal(): number;
    get maxVal(): number;
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value: any): void;
    get dataP(): string | undefined;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Slider, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Slider, "p-slider, p-range", never, { "animate": { "alias": "animate"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "range": { "alias": "range"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; }, { "onChange": "onChange"; "onSlideEnd": "onSlideEnd"; }, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class SliderModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SliderModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<SliderModule, never, [typeof Slider, typeof RangeDirective, typeof i3.SharedModule], [typeof Slider, typeof RangeDirective, typeof i3.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<SliderModule>;
}

export { RangeDirective, SLIDER_VALUE_ACCESSOR, Slider, SliderClasses, SliderModule, SliderStyle };
