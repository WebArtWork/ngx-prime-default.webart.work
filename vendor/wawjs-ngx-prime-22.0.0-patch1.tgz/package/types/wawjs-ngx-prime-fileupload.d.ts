import { FileUploadPassThrough, FileSelectEvent, NativeFileUploadValidationErrorEvent, FileSendEvent, FileUploadEvent, FileUploadErrorEvent, FileRemoveEvent, FileProgressEvent, FileUploadHandlerEvent, RemoveUploadedFileEvent, FileUploadHeaderTemplateContext, FileUploadContentTemplateContext, FileUploadFileLabelTemplateContext } from '@wawjs/ngx-prime/types/fileupload';
export * from '@wawjs/ngx-prime/types/fileupload';
import * as _wawjs_ngx_prime_fileupload from '@wawjs/ngx-prime/fileupload';
import * as _angular_core from '@angular/core';
import { OnInit, TemplateRef, ElementRef, NgZone } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';
import * as i3 from '@wawjs/ngx-prime/api';
import { BlockableUI, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { ButtonProps } from '@wawjs/ngx-prime/button';
import { VoidListener } from '@wawjs/ngx-prime/ts-helpers';
import { Subscription } from 'rxjs';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import { BaseModelHolder } from '@wawjs/ngx-prime/basemodelholder';

declare class FileUploadStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        input: string;
        root: ({ instance }: {
            instance: any;
        }) => string;
        header: string;
        pcChooseButton: string;
        pcUploadButton: string;
        pcCancelButton: string;
        content: string;
        fileList: string;
        file: string;
        fileThumbnail: string;
        fileInfo: string;
        fileName: string;
        fileSize: string;
        pcFileBadge: string;
        fileActions: string;
        pcFileRemoveButton: string;
        basicContent: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FileUploadStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<FileUploadStyle>;
}
/**
 *
 * FileUpload is an advanced uploader with dragdrop support, multi file uploads, auto uploading, progress tracking and validations.
 *
 * [Live Demo](https://www.ngx-prime.org/fileupload/)
 *
 * @module fileuploadstyle
 *
 */
declare enum FileUploadClasses {
    /**
     * Class name of the root element
     */
    root = "p-fileupload",
    /**
     * Class name of the header element
     */
    header = "p-fileupload-header",
    /**
     * Class name of the choose button element
     */
    pcChooseButton = "p-fileupload-choose-button",
    /**
     * Class name of the upload button element
     */
    pcUploadButton = "p-fileupload-upload-button",
    /**
     * Class name of the cancel button element
     */
    pcCancelButton = "p-fileupload-cancel-button",
    /**
     * Class name of the content element
     */
    content = "p-fileupload-content",
    /**
     * Class name of the file list element
     */
    fileList = "p-fileupload-file-list",
    /**
     * Class name of the file element
     */
    file = "p-fileupload-file",
    /**
     * Class name of the file thumbnail element
     */
    fileThumbnail = "p-fileupload-file-thumbnail",
    /**
     * Class name of the file info element
     */
    fileInfo = "p-fileupload-file-info",
    /**
     * Class name of the file name element
     */
    fileName = "p-fileupload-file-name",
    /**
     * Class name of the file size element
     */
    fileSize = "p-fileupload-file-size",
    /**
     * Class name of the file badge element
     */
    pcFileBadge = "p-fileupload-file-badge",
    /**
     * Class name of the file actions element
     */
    fileActions = "p-fileupload-file-actions",
    /**
     * Class name of the file remove button element
     */
    pcFileRemoveButton = "p-fileupload-file-remove-button",
    /**
     * Class name of the content in basic mode
     */
    basicContent = "p-fileupload-basic-content"
}

/**
 * Adds Prime state attributes to a native file input and emits its selected files.
 * The browser remains responsible for file selection and form integration.
 *
 * @group Components
 */
declare class FileUploadDirective extends BaseModelHolder<FileUploadPassThrough> {
    componentName: string;
    private readonly element;
    private readonly bindDirectiveInstance;
    _componentStyle: FileUploadStyle;
    invalid: _angular_core.InputSignalWithTransform<boolean, unknown>;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    accept: _angular_core.InputSignal<string | undefined>;
    multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    capture: _angular_core.InputSignal<string | undefined>;
    webkitdirectory: _angular_core.InputSignalWithTransform<boolean, unknown>;
    inputId: _angular_core.InputSignal<string | undefined>;
    name: _angular_core.InputSignal<string | undefined>;
    tabindex: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    autofocus: _angular_core.InputSignalWithTransform<boolean, unknown>;
    ariaLabel: _angular_core.InputSignal<string | undefined>;
    ariaLabelledBy: _angular_core.InputSignal<string | undefined>;
    ariaDescribedBy: _angular_core.InputSignal<string | undefined>;
    maxFileSize: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    fileLimit: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    allowDuplicate: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Signal Forms value contract. Browsers only permit this value to be set by user selection. */
    value: _angular_core.ModelSignal<File[]>;
    touch: _angular_core.OutputEmitterRef<void>;
    filesSelected: _angular_core.OutputEmitterRef<File[]>;
    onSelect: _angular_core.OutputEmitterRef<FileSelectEvent>;
    onError: _angular_core.OutputEmitterRef<NativeFileUploadValidationErrorEvent>;
    onClear: _angular_core.OutputEmitterRef<void>;
    onFocus: _angular_core.OutputEmitterRef<FocusEvent>;
    onBlur: _angular_core.OutputEmitterRef<FocusEvent>;
    onAfterViewChecked(): void;
    onChange(event: Event): void;
    clear(): void;
    focus(options?: FocusOptions): void;
    choose(): void;
    onInputBlur(event: FocusEvent): void;
    private getValidationError;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FileUploadDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FileUploadDirective, "input[type='file'][pFileUpload]", ["pFileUpload"], { "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "accept": { "alias": "accept"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "capture": { "alias": "capture"; "required": false; "isSignal": true; }; "webkitdirectory": { "alias": "webkitdirectory"; "required": false; "isSignal": true; }; "inputId": { "alias": "inputId"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "tabindex": { "alias": "tabindex"; "required": false; "isSignal": true; }; "autofocus": { "alias": "autofocus"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaLabelledBy": { "alias": "ariaLabelledBy"; "required": false; "isSignal": true; }; "ariaDescribedBy": { "alias": "ariaDescribedBy"; "required": false; "isSignal": true; }; "maxFileSize": { "alias": "maxFileSize"; "required": false; "isSignal": true; }; "fileLimit": { "alias": "fileLimit"; "required": false; "isSignal": true; }; "allowDuplicate": { "alias": "allowDuplicate"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "touch": "touch"; "filesSelected": "filesSelected"; "onSelect": "onSelect"; "onError": "onError"; "onClear": "onClear"; "onFocus": "onFocus"; "onBlur": "onBlur"; }, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
/** Clears the selected files of a native `pFileUpload` input. */
declare class FileUploadClearDirective {
    uploader: _angular_core.InputSignal<FileUploadDirective>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FileUploadClearDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FileUploadClearDirective, "button[pFileUploadClear]", never, { "uploader": { "alias": "pFileUploadClear"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
/** Holds an explicit native upload queue and optionally sends it with XMLHttpRequest. */
declare class FileUploadQueueDirective implements OnInit {
    private readonly destroyRef;
    private request?;
    uploader: _angular_core.InputSignal<FileUploadDirective>;
    url: _angular_core.InputSignal<string | undefined>;
    method: _angular_core.InputSignal<"post" | "put">;
    name: _angular_core.InputSignal<string>;
    headers: _angular_core.InputSignal<Record<string, string>>;
    withCredentials: _angular_core.InputSignalWithTransform<boolean, unknown>;
    auto: _angular_core.InputSignalWithTransform<boolean, unknown>;
    disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    files: _angular_core.ModelSignal<File[]>;
    uploadedFiles: _angular_core.ModelSignal<File[]>;
    progress: _angular_core.ModelSignal<number>;
    uploading: _angular_core.ModelSignal<boolean>;
    onSelect: _angular_core.OutputEmitterRef<File[]>;
    onBeforeUpload: _angular_core.OutputEmitterRef<FormData>;
    onSend: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        formData: FormData;
    }>;
    onProgress: _angular_core.OutputEmitterRef<{
        originalEvent: ProgressEvent;
        progress: number;
    }>;
    onUpload: _angular_core.OutputEmitterRef<{
        originalEvent: Event;
        files: File[];
    }>;
    onError: _angular_core.OutputEmitterRef<{
        originalEvent?: Event;
        files: File[];
        error?: unknown;
    }>;
    onRemove: _angular_core.OutputEmitterRef<{
        originalEvent?: Event;
        file: File;
    }>;
    onClear: _angular_core.OutputEmitterRef<void>;
    ngOnInit(): void;
    add(files: File[]): void;
    remove(file: File, event?: Event): void;
    clear(): void;
    choose(): void;
    cancel(): void;
    upload(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FileUploadQueueDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FileUploadQueueDirective, "[pFileUploadQueue]", ["pFileUploadQueue"], { "uploader": { "alias": "pFileUploadQueue"; "required": true; "isSignal": true; }; "url": { "alias": "url"; "required": false; "isSignal": true; }; "method": { "alias": "method"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "headers": { "alias": "headers"; "required": false; "isSignal": true; }; "withCredentials": { "alias": "withCredentials"; "required": false; "isSignal": true; }; "auto": { "alias": "auto"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "files": { "alias": "files"; "required": false; "isSignal": true; }; "uploadedFiles": { "alias": "uploadedFiles"; "required": false; "isSignal": true; }; "progress": { "alias": "progress"; "required": false; "isSignal": true; }; "uploading": { "alias": "uploading"; "required": false; "isSignal": true; }; }, { "files": "filesChange"; "uploadedFiles": "uploadedFilesChange"; "progress": "progressChange"; "uploading": "uploadingChange"; "onSelect": "onSelect"; "onBeforeUpload": "onBeforeUpload"; "onSend": "onSend"; "onProgress": "onProgress"; "onUpload": "onUpload"; "onError": "onError"; "onRemove": "onRemove"; "onClear": "onClear"; }, never, never, true, never>;
}
declare class FileUploadChooseDirective {
    queue: _angular_core.InputSignal<FileUploadQueueDirective>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FileUploadChooseDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FileUploadChooseDirective, "button[pFileUploadChoose]", never, { "queue": { "alias": "pFileUploadChoose"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class FileUploadUploadDirective {
    queue: _angular_core.InputSignal<FileUploadQueueDirective>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FileUploadUploadDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FileUploadUploadDirective, "button[pFileUploadUpload]", never, { "queue": { "alias": "pFileUploadUpload"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class FileUploadCancelDirective {
    queue: _angular_core.InputSignal<FileUploadQueueDirective>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FileUploadCancelDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FileUploadCancelDirective, "button[pFileUploadCancel]", never, { "queue": { "alias": "pFileUploadCancel"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
declare class FileUploadDropZoneDirective {
    queue: _angular_core.InputSignal<FileUploadQueueDirective>;
    onDragOver(event: DragEvent): void;
    onDrop(event: DragEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FileUploadDropZoneDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FileUploadDropZoneDirective, "[pFileUploadDropZone]", never, { "queue": { "alias": "pFileUploadDropZone"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class FileContent extends BaseComponent {
    _componentStyle: FileUploadStyle;
    $pcFileUpload: FileUpload;
    onRemove: _angular_core.OutputEmitterRef<any>;
    files: _angular_core.InputSignal<any>;
    badgeSeverity: _angular_core.InputSignal<"secondary" | "info" | "success" | "warn" | "danger" | "contrast">;
    badgeValue: _angular_core.InputSignal<string | undefined>;
    previewWidth: _angular_core.InputSignal<number>;
    fileRemoveIconTemplate: _angular_core.InputSignal<any>;
    onRemoveClick(event: any, index: number): void;
    formatSize(bytes: number): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FileContent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FileContent, "[pFileContent]", never, { "files": { "alias": "files"; "required": false; "isSignal": true; }; "badgeSeverity": { "alias": "badgeSeverity"; "required": false; "isSignal": true; }; "badgeValue": { "alias": "badgeValue"; "required": false; "isSignal": true; }; "previewWidth": { "alias": "previewWidth"; "required": false; "isSignal": true; }; "fileRemoveIconTemplate": { "alias": "fileRemoveIconTemplate"; "required": false; "isSignal": true; }; }, { "onRemove": "onRemove"; }, never, never, true, never>;
}
/**
 * FileUpload is an advanced uploader with dragdrop support, multi file uploads, auto uploading, progress tracking and validations.
 *
 * @deprecated since v22. Compose `pFileUpload`, `pFileUploadQueue`, and its companion directives instead. This component remains available through v22 for compatibility.
 * @group Components
 */
declare class FileUpload extends BaseComponent<FileUploadPassThrough> implements BlockableUI {
    componentName: string;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Name of the request parameter to identify the files at backend.
     * @group Props
     */
    name: _angular_core.InputSignal<string | undefined>;
    /**
     * Remote url to upload the files.
     * @group Props
     */
    url: _angular_core.InputSignal<string | undefined>;
    /**
     * HTTP method to send the files to the url such as "post" and "put".
     * @group Props
     */
    method: _angular_core.InputSignal<"post" | "put" | undefined>;
    /**
     * Used to select multiple files at once from file dialog.
     * @group Props
     */
    multiple: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Comma-separated list of pattern to restrict the allowed file types. Can be any combination of either the MIME types (such as "image/*") or the file extensions (such as ".jpg").
     * @group Props
     */
    accept: _angular_core.InputSignal<string | undefined>;
    /**
     * Disables the upload functionality.
     * @group Props
     */
    disabled: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When enabled, upload begins automatically after selection is completed.
     * @group Props
     */
    auto: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Cross-site Access-Control requests should be made using credentials such as cookies, authorization headers or TLS client certificates.
     * @group Props
     */
    withCredentials: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Maximum file size allowed in bytes.
     * @group Props
     */
    maxFileSize: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Summary message of the invalid file size.
     * @group Props
     */
    invalidFileSizeMessageSummary: _angular_core.InputSignal<string>;
    /**
     * Detail message of the invalid file size.
     * @group Props
     */
    invalidFileSizeMessageDetail: _angular_core.InputSignal<string>;
    /**
     * Summary message of the invalid file type.
     * @group Props
     */
    invalidFileTypeMessageSummary: _angular_core.InputSignal<string>;
    /**
     * Detail message of the invalid file type.
     * @group Props
     */
    invalidFileTypeMessageDetail: _angular_core.InputSignal<string>;
    /**
     * Detail message of the invalid file type.
     * @group Props
     */
    invalidFileLimitMessageDetail: _angular_core.InputSignal<string>;
    /**
     * Summary message of the invalid file type.
     * @group Props
     */
    invalidFileLimitMessageSummary: _angular_core.InputSignal<string>;
    /**
     * Inline style of the element.
     * @group Props
     */
    style: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Class of the element.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Width of the image thumbnail in pixels.
     * @group Props
     */
    previewWidth: _angular_core.InputSignalWithTransform<number, unknown>;
    /**
     * Label of the choose button. Defaults to ngx-prime Locale configuration.
     * @group Props
     */
    chooseLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Label of the upload button. Defaults to ngx-prime Locale configuration.
     * @group Props
     */
    uploadLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Label of the cancel button. Defaults to ngx-prime Locale configuration.
     * @group Props
     */
    cancelLabel: _angular_core.InputSignal<string | undefined>;
    /**
     * Icon of the choose button.
     * @group Props
     */
    chooseIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Icon of the upload button.
     * @group Props
     */
    uploadIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Icon of the cancel button.
     * @group Props
     */
    cancelIcon: _angular_core.InputSignal<string | undefined>;
    /**
     * Whether to show the upload button.
     * @group Props
     */
    showUploadButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Whether to show the cancel button.
     * @group Props
     */
    showCancelButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Defines the UI of the component.
     * @group Props
     */
    mode: _angular_core.InputSignal<"advanced" | "basic" | undefined>;
    /**
     * HttpHeaders class represents the header configuration options for an HTTP request.
     * @group Props
     */
    headers: _angular_core.InputSignal<HttpHeaders | undefined>;
    /**
     * Whether to use the default upload or a manual implementation defined in uploadHandler callback. Defaults to ngx-prime Locale configuration.
     * @group Props
     */
    customUpload: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * Maximum number of files that can be uploaded.
     * @group Props
     */
    fileLimit: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /**
     * Style class of the upload button.
     * @group Props
     */
    uploadStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the cancel button.
     * @group Props
     */
    cancelStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the remove button.
     * @group Props
     */
    removeStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Style class of the choose button.
     * @group Props
     */
    chooseStyleClass: _angular_core.InputSignal<string | undefined>;
    /**
     * Used to pass all properties of the ButtonProps to the choose button inside the component.
     * @group Props
     */
    chooseButtonProps: _angular_core.InputSignal<ButtonProps | undefined>;
    /**
     * Used to pass all properties of the ButtonProps to the upload button inside the component.
     * @group Props
     */
    uploadButtonProps: _angular_core.InputSignal<ButtonProps>;
    /**
     * Used to pass all properties of the ButtonProps to the cancel button inside the component.
     * @group Props
     */
    cancelButtonProps: _angular_core.InputSignal<ButtonProps>;
    /**
     * Callback to invoke before file upload is initialized.
     * @param {FileBeforeUploadEvent} event - Custom upload event.
     * @group Emits
     */
    onBeforeUpload: _angular_core.OutputEmitterRef<_wawjs_ngx_prime_fileupload.FormDataEvent>;
    /**
     * An event indicating that the request was sent to the server. Useful when a request may be retried multiple times, to distinguish between retries on the final event stream.
     * @param {FileSendEvent} event - Custom send event.
     * @group Emits
     */
    onSend: _angular_core.OutputEmitterRef<FileSendEvent>;
    /**
     * Callback to invoke when file upload is complete.
     * @param {FileUploadEvent} event - Custom upload event.
     * @group Emits
     */
    onUpload: _angular_core.OutputEmitterRef<FileUploadEvent>;
    /**
     * Callback to invoke if file upload fails.
     * @param {FileUploadErrorEvent} event - Custom error event.
     * @group Emits
     */
    onError: _angular_core.OutputEmitterRef<FileUploadErrorEvent>;
    /**
     * Callback to invoke when files in queue are removed without uploading using clear all button.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onClear: _angular_core.OutputEmitterRef<Event | undefined>;
    /**
     * Callback to invoke when a file is removed without uploading using clear button of a file.
     * @param {FileRemoveEvent} event - Remove event.
     * @group Emits
     */
    onRemove: _angular_core.OutputEmitterRef<FileRemoveEvent>;
    /**
     * Callback to invoke when files are selected.
     * @param {FileSelectEvent} event - Select event.
     * @group Emits
     */
    onSelect: _angular_core.OutputEmitterRef<FileSelectEvent>;
    /**
     * Callback to invoke when files are being uploaded.
     * @param {FileProgressEvent} event - Progress event.
     * @group Emits
     */
    onProgress: _angular_core.OutputEmitterRef<FileProgressEvent>;
    /**
     * Callback to invoke in custom upload mode to upload the files manually.
     * @param {FileUploadHandlerEvent} event - Upload handler event.
     * @group Emits
     */
    uploadHandler: _angular_core.OutputEmitterRef<FileUploadHandlerEvent>;
    /**
     * This event is triggered if an error occurs while loading an image file.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onImageError: _angular_core.OutputEmitterRef<Event>;
    /**
     * This event is triggered if an error occurs while loading an image file.
     * @param {RemoveUploadedFileEvent} event - Remove event.
     * @group Emits
     */
    onRemoveUploadedFile: _angular_core.OutputEmitterRef<RemoveUploadedFileEvent>;
    /**
     * Custom file template.
     * @group Templates
     */
    readonly fileTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom header template.
     * @param {FileUploadHeaderTemplateContext} context - header template context.
     * @group Templates
     */
    readonly headerTemplate: _angular_core.Signal<TemplateRef<FileUploadHeaderTemplateContext> | undefined>;
    /**
     * Custom content template.
     * @param {FileUploadContentTemplateContext} context - content template context.
     * @group Templates
     */
    contentTemplate: TemplateRef<FileUploadContentTemplateContext> | undefined;
    /**
     * Custom toolbar template.
     * @group Templates
     */
    readonly toolbarTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom choose icon template.
     * @group Templates
     */
    chooseIconTemplate: TemplateRef<void> | undefined;
    /**
     * Custom file label template.
     * @param {FileUploadFileLabelTemplateContext} context - file label template context.
     * @group Templates
     */
    readonly fileLabelTemplate: _angular_core.Signal<TemplateRef<FileUploadFileLabelTemplateContext> | undefined>;
    /**
     * Custom upload icon template.
     * @group Templates
     */
    uploadIconTemplate: TemplateRef<void> | undefined;
    /**
     * Custom cancel icon template.
     * @group Templates
     */
    cancelIconTemplate: TemplateRef<void> | undefined;
    /**
     * Custom empty state template.
     * @group Templates
     */
    emptyTemplate: TemplateRef<void> | undefined;
    advancedFileInput: ElementRef | undefined | any;
    readonly basicFileInput: _angular_core.Signal<ElementRef<any> | undefined>;
    readonly content: _angular_core.Signal<ElementRef<any> | undefined>;
    /**
     * Accepts the public `files` binding without giving up the mutable queue
     * maintained by FileUpload itself. The queue is deliberately kept behind
     * the `files` accessor: selecting, removing and clearing files are local
     * operations, whereas a bound input replaces the complete queue.
     */
    readonly inputFiles: _angular_core.InputSignal<File[] | undefined>;
    private readonly syncInputFiles;
    set files(files: File[]);
    get files(): File[];
    get basicButtonLabel(): string;
    _files: File[];
    progress: number;
    dragHighlight: boolean | undefined;
    msgs: any[] | undefined;
    uploadedFileCount: number;
    focus: boolean | undefined;
    uploading: boolean | undefined;
    duplicateIEEvent: boolean | undefined;
    translationSubscription: Subscription | undefined;
    dragOverListener: VoidListener;
    uploadedFiles: File[];
    sanitizer: DomSanitizer;
    zone: NgZone;
    http: HttpClient;
    _componentStyle: FileUploadStyle;
    onInit(): void;
    onAfterViewInit(): void;
    _headerTemplate: TemplateRef<FileUploadHeaderTemplateContext> | undefined;
    _contentTemplate: TemplateRef<FileUploadContentTemplateContext> | undefined;
    _toolbarTemplate: TemplateRef<void> | undefined;
    _chooseIconTemplate: TemplateRef<void> | undefined;
    _uploadIconTemplate: TemplateRef<void> | undefined;
    _cancelIconTemplate: TemplateRef<void> | undefined;
    _emptyTemplate: TemplateRef<void> | undefined;
    _fileTemplate: TemplateRef<void> | undefined;
    _fileLabelTemplate: TemplateRef<FileUploadFileLabelTemplateContext> | undefined;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    onAfterContentInit(): void;
    basicFileChosenLabel(): any;
    completedLabel(): any;
    getTranslation(option: string): any;
    choose(): void;
    onFileSelect(event: any): void;
    isFileSelected(file: File): boolean;
    isIE11(): boolean | undefined;
    validate(file: File): boolean;
    private isFileTypeValid;
    getTypeClass(fileType: string): string;
    isWildcard(fileType: string): boolean;
    getFileExtension(file: File): string;
    isImage(file: File): boolean;
    onImageLoad(img: any): void;
    /**
     * Uploads the selected files.
     * @group Method
     */
    uploader(): void;
    onRemoveClick(e: any): void;
    onRemoveUploadedFileClick(e: any): void;
    /**
     * Clears the files list.
     * @group Method
     */
    clear(): void;
    /**
     * Removes a single file.
     * @param {Event} event - Browser event.
     * @param {Number} index - Index of the file.
     * @group Method
     */
    remove(event: Event, index: number): void;
    /**
     * Removes uploaded file.
     * @param {Number} index - Index of the file to be removed.
     * @group Method
     */
    removeUploadedFile(index: number): void;
    isFileLimitExceeded(): boolean | 0 | undefined;
    isChooseDisabled(): boolean | 0 | undefined;
    checkFileLimit(files: File[]): void;
    clearInputElement(): void;
    clearIEInput(): void;
    hasFiles(): boolean;
    hasUploadedFiles(): boolean;
    onDragEnter(e: DragEvent): void;
    onDragOver(e: DragEvent): void;
    onDragLeave(): void;
    onDrop(event: any): void;
    onFocus(): void;
    onBlur(): void;
    formatSize(bytes: number): string;
    upload(): void;
    onBasicUploaderClick(): void;
    onBasicKeydown(event: KeyboardEvent): void;
    imageError(event: Event): void;
    getBlockableElement(): HTMLElement;
    get chooseButtonLabel(): string;
    get uploadButtonLabel(): string;
    get cancelButtonLabel(): string;
    get browseFilesLabel(): string;
    get pendingLabel(): any;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FileUpload, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FileUpload, "p-fileupload, p-fileUpload", never, { "name": { "alias": "name"; "required": false; "isSignal": true; }; "url": { "alias": "url"; "required": false; "isSignal": true; }; "method": { "alias": "method"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "accept": { "alias": "accept"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "auto": { "alias": "auto"; "required": false; "isSignal": true; }; "withCredentials": { "alias": "withCredentials"; "required": false; "isSignal": true; }; "maxFileSize": { "alias": "maxFileSize"; "required": false; "isSignal": true; }; "invalidFileSizeMessageSummary": { "alias": "invalidFileSizeMessageSummary"; "required": false; "isSignal": true; }; "invalidFileSizeMessageDetail": { "alias": "invalidFileSizeMessageDetail"; "required": false; "isSignal": true; }; "invalidFileTypeMessageSummary": { "alias": "invalidFileTypeMessageSummary"; "required": false; "isSignal": true; }; "invalidFileTypeMessageDetail": { "alias": "invalidFileTypeMessageDetail"; "required": false; "isSignal": true; }; "invalidFileLimitMessageDetail": { "alias": "invalidFileLimitMessageDetail"; "required": false; "isSignal": true; }; "invalidFileLimitMessageSummary": { "alias": "invalidFileLimitMessageSummary"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "previewWidth": { "alias": "previewWidth"; "required": false; "isSignal": true; }; "chooseLabel": { "alias": "chooseLabel"; "required": false; "isSignal": true; }; "uploadLabel": { "alias": "uploadLabel"; "required": false; "isSignal": true; }; "cancelLabel": { "alias": "cancelLabel"; "required": false; "isSignal": true; }; "chooseIcon": { "alias": "chooseIcon"; "required": false; "isSignal": true; }; "uploadIcon": { "alias": "uploadIcon"; "required": false; "isSignal": true; }; "cancelIcon": { "alias": "cancelIcon"; "required": false; "isSignal": true; }; "showUploadButton": { "alias": "showUploadButton"; "required": false; "isSignal": true; }; "showCancelButton": { "alias": "showCancelButton"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "headers": { "alias": "headers"; "required": false; "isSignal": true; }; "customUpload": { "alias": "customUpload"; "required": false; "isSignal": true; }; "fileLimit": { "alias": "fileLimit"; "required": false; "isSignal": true; }; "uploadStyleClass": { "alias": "uploadStyleClass"; "required": false; "isSignal": true; }; "cancelStyleClass": { "alias": "cancelStyleClass"; "required": false; "isSignal": true; }; "removeStyleClass": { "alias": "removeStyleClass"; "required": false; "isSignal": true; }; "chooseStyleClass": { "alias": "chooseStyleClass"; "required": false; "isSignal": true; }; "chooseButtonProps": { "alias": "chooseButtonProps"; "required": false; "isSignal": true; }; "uploadButtonProps": { "alias": "uploadButtonProps"; "required": false; "isSignal": true; }; "cancelButtonProps": { "alias": "cancelButtonProps"; "required": false; "isSignal": true; }; "inputFiles": { "alias": "files"; "required": false; "isSignal": true; }; }, { "onBeforeUpload": "onBeforeUpload"; "onSend": "onSend"; "onUpload": "onUpload"; "onError": "onError"; "onClear": "onClear"; "onRemove": "onRemove"; "onSelect": "onSelect"; "onProgress": "onProgress"; "uploadHandler": "uploadHandler"; "onImageError": "onImageError"; "onRemoveUploadedFile": "onRemoveUploadedFile"; }, ["fileTemplate", "headerTemplate", "toolbarTemplate", "fileLabelTemplate", "templates", "contentTemplate", "chooseIconTemplate", "uploadIconTemplate", "cancelIconTemplate", "emptyTemplate"], never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class FileUploadModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FileUploadModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<FileUploadModule, never, [typeof FileUpload, typeof FileUploadDirective, typeof FileUploadClearDirective, typeof FileUploadQueueDirective, typeof FileUploadChooseDirective, typeof FileUploadUploadDirective, typeof FileUploadCancelDirective, typeof FileUploadDropZoneDirective, typeof i3.SharedModule], [typeof FileUpload, typeof FileUploadDirective, typeof FileUploadClearDirective, typeof FileUploadQueueDirective, typeof FileUploadChooseDirective, typeof FileUploadUploadDirective, typeof FileUploadCancelDirective, typeof FileUploadDropZoneDirective, typeof i3.SharedModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<FileUploadModule>;
}

export { FileContent, FileUpload, FileUploadCancelDirective, FileUploadChooseDirective, FileUploadClasses, FileUploadClearDirective, FileUploadDirective, FileUploadDropZoneDirective, FileUploadModule, FileUploadQueueDirective, FileUploadStyle, FileUploadUploadDirective };
