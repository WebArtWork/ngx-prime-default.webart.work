import * as i0 from '@angular/core';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class BaseIconStyle extends BaseStyle {
    name: string;
    css: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseIconStyle, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BaseIconStyle>;
}
/**
 *
 * [Live Demo](https://www.ngx-prime.org/)
 *
 * @module baseiconstyle
 *
 */
declare enum BaseIconClasses {
    root = "p-icon"
}

declare class BaseIcon extends BaseComponent {
    spin: i0.InputSignalWithTransform<boolean, unknown>;
    _componentStyle: BaseIconStyle;
    getClassNames(): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseIcon, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BaseIcon, "ng-component", never, { "spin": { "alias": "spin"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

export { BaseIcon, BaseIconClasses, BaseIconStyle };
