import { CardPassThrough } from '@wawjs/ngx-prime/types/card';
export * from '@wawjs/ngx-prime/types/card';
import * as _angular_core from '@angular/core';
import { TemplateRef } from '@angular/core';
import * as i2 from '@wawjs/ngx-prime/api';
import { BlockableUI, Header, Footer, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class CardStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: string;
        header: string;
        body: string;
        caption: string;
        title: string;
        subtitle: string;
        content: string;
        footer: string;
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CardStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<CardStyle>;
}
/**
 *
 * Card is a flexible container component.
 *
 * [Live Demo](https://www.ngx-prime.org/card/)
 *
 * @module cardstyle
 *
 */
declare enum CardClasses {
    /**
     * Class name of the root element
     */
    root = "p-card",
    /**
     * Class name of the header element
     */
    header = "p-card-header",
    /**
     * Class name of the body element
     */
    body = "p-card-body",
    /**
     * Class name of the caption element
     */
    caption = "p-card-caption",
    /**
     * Class name of the title element
     */
    title = "p-card-title",
    /**
     * Class name of the subtitle element
     */
    subtitle = "p-card-subtitle",
    /**
     * Class name of the content element
     */
    content = "p-card-content",
    /**
     * Class name of the footer element
     */
    footer = "p-card-footer"
}

/**
 * Card is a flexible container component.
 * @group Components
 */
declare class Card extends BaseComponent<CardPassThrough> implements BlockableUI {
    componentName: string;
    $pcCard: Card | undefined;
    bindDirectiveInstance: Bind;
    _componentStyle: CardStyle;
    onAfterViewChecked(): void;
    /**
     * Header of the card.
     * @group Props
     */
    header: _angular_core.InputSignal<string | undefined>;
    /**
     * Subheader of the card.
     * @group Props
     */
    subheader: _angular_core.InputSignal<string | undefined>;
    /**
     * Inline style of the element.
     * @group Props
     */
    style: _angular_core.InputSignal<{
        [klass: string]: any;
    } | null | undefined>;
    /**
     * Class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: _angular_core.InputSignal<string | undefined>;
    readonly headerFacet: _angular_core.Signal<Header | undefined>;
    readonly footerFacet: _angular_core.Signal<Footer | undefined>;
    /**
     * Custom header template.
     * @group Templates
     */
    headerTemplate: TemplateRef<void> | undefined;
    /**
     * Custom title template.
     * @group Templates
     */
    titleTemplate: TemplateRef<void> | undefined;
    /**
     * Custom subtitle template.
     * @group Templates
     */
    subtitleTemplate: TemplateRef<void> | undefined;
    /**
     * Custom content template.
     * @group Templates
     */
    readonly contentTemplate: _angular_core.Signal<TemplateRef<void> | undefined>;
    /**
     * Custom footer template.
     * @group Templates
     */
    footerTemplate: TemplateRef<void> | undefined;
    _headerTemplate: TemplateRef<void> | undefined;
    _titleTemplate: TemplateRef<void> | undefined;
    _subtitleTemplate: TemplateRef<void> | undefined;
    _contentTemplate: TemplateRef<void> | undefined;
    _footerTemplate: TemplateRef<void> | undefined;
    _style: _angular_core.WritableSignal<{
        [klass: string]: any;
    } | null | undefined>;
    constructor();
    getBlockableElement(): HTMLElement;
    readonly templates: _angular_core.Signal<readonly PrimeTemplate[]>;
    onAfterContentInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Card, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<Card, "p-card", never, { "header": { "alias": "header"; "required": false; "isSignal": true; }; "subheader": { "alias": "subheader"; "required": false; "isSignal": true; }; "style": { "alias": "style"; "required": false; "isSignal": true; }; "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; }, {}, ["headerFacet", "footerFacet", "contentTemplate", "templates", "headerTemplate", "titleTemplate", "subtitleTemplate", "footerTemplate"], ["p-header", "*", "p-footer"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class CardModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CardModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<CardModule, never, [typeof Card, typeof i2.SharedModule, typeof i1.BindModule], [typeof Card, typeof i2.SharedModule, typeof i1.BindModule]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<CardModule>;
}

export { Card, CardClasses, CardModule, CardStyle };
