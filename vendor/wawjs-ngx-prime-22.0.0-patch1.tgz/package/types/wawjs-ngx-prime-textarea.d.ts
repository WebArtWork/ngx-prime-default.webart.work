import * as _angular_core from '@angular/core';
import { NgControl } from '@angular/forms';
import { BaseModelHolder } from '@wawjs/ngx-prime/basemodelholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Fluid } from '@wawjs/ngx-prime/fluid';
import { TextareaPassThrough } from '@wawjs/ngx-prime/types/textarea';
import { Subscription } from 'rxjs';
import { BaseStyle } from '@wawjs/ngx-prime/base';

declare class TextareaStyle extends BaseStyle {
    name: string;
    style: string;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-filled': any;
            'p-textarea-resizable ': any;
            'p-variant-filled': boolean;
            'p-textarea-fluid': any;
            'p-inputfield-sm p-textarea-sm': boolean;
            'p-textarea-lg p-inputfield-lg': boolean;
            'p-invalid': any;
        })[];
    };
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TextareaStyle, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TextareaStyle>;
}
/**
 *
 * Textarea is a multi-line text input element.
 *
 * [Live Demo](https://www.ngx-prime.org/textarea/)
 *
 * @module textareastyle
 *
 */
declare enum TextareaClasses {
    /**
     * Class name of the root element
     */
    root = "p-textarea"
}

/**
 * Textarea adds styling and autoResize functionality to standard textarea element.
 * @group Components
 */
declare class Textarea extends BaseModelHolder<TextareaPassThrough> {
    componentName: string;
    bindDirectiveInstance: Bind;
    $pcTextarea: Textarea | undefined;
    /**
     * Used to pass attributes to DOM elements inside the Textarea component.
     * @defaultValue undefined
     * @group Props
     */
    pTextareaPT: _angular_core.InputSignal<TextareaPassThrough>;
    /**
     * Indicates whether the component should be rendered without styles.
     * @defaultValue undefined
     * @group Props
     */
    pTextareaUnstyled: _angular_core.InputSignal<boolean | undefined>;
    /**
     * When present, textarea size changes as being typed.
     * @group Props
     */
    autoResize: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /**
     * Defines the size of the component.
     * @group Props
     */
    pSize: _angular_core.InputSignal<"small" | "large" | undefined>;
    /**
     * Specifies the input variant of the component.
     * @defaultValue undefined
     * @group Props
     */
    variant: _angular_core.InputSignal<"filled" | "outlined" | undefined>;
    /**
     * Spans 100% width of the container when enabled.
     * @defaultValue undefined
     * @group Props
     */
    fluid: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    /**
     * When present, it specifies that the component should have invalid state style.
     * @defaultValue false
     * @group Props
     */
    invalid: _angular_core.InputSignalWithTransform<boolean | undefined, unknown>;
    $variant: _angular_core.Signal<"filled" | "outlined" | null>;
    /**
     * Callback to invoke on textarea resize.
     * @param {(Event | {})} event - Custom resize event.
     * @group Emits
     */
    onResize: _angular_core.OutputEmitterRef<object | Event>;
    ngControlSubscription: Subscription | undefined;
    _componentStyle: TextareaStyle;
    ngControl: NgControl | null;
    pcFluid: Fluid | null;
    get hasFluid(): boolean;
    constructor();
    onInit(): void;
    onAfterViewInit(): void;
    onAfterViewChecked(): void;
    onInput(e: Event): void;
    resize(event?: Event): void;
    updateState(): void;
    onDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<Textarea, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<Textarea, "[pTextarea], [pInputTextarea]", never, { "pTextareaPT": { "alias": "pTextareaPT"; "required": false; "isSignal": true; }; "pTextareaUnstyled": { "alias": "pTextareaUnstyled"; "required": false; "isSignal": true; }; "autoResize": { "alias": "autoResize"; "required": false; "isSignal": true; }; "pSize": { "alias": "pSize"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "fluid": { "alias": "fluid"; "required": false; "isSignal": true; }; "invalid": { "alias": "invalid"; "required": false; "isSignal": true; }; }, { "onResize": "onResize"; }, never, never, true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class TextareaModule {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TextareaModule, never>;
    static ɵmod: _angular_core.ɵɵNgModuleDeclaration<TextareaModule, never, [typeof Textarea], [typeof Textarea]>;
    static ɵinj: _angular_core.ɵɵInjectorDeclaration<TextareaModule>;
}

export { Textarea, TextareaClasses, TextareaModule, TextareaStyle };
