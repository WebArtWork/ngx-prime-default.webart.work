import * as i0 from '@angular/core';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import * as _wawjs_css_prime_styled from '@wawjs/css-prime-styled';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import { DividerPassThrough } from '@wawjs/ngx-prime/types/divider';

declare class DividerStyle extends BaseStyle {
    name: string;
    style: _wawjs_css_prime_styled.StyleType;
    classes: {
        root: ({ instance }: {
            instance: any;
        }) => (string | {
            'p-divider-left': boolean;
            'p-divider-center'?: undefined;
            'p-divider-right'?: undefined;
            'p-divider-top'?: undefined;
            'p-divider-bottom'?: undefined;
        } | {
            'p-divider-center': boolean;
            'p-divider-left'?: undefined;
            'p-divider-right'?: undefined;
            'p-divider-top'?: undefined;
            'p-divider-bottom'?: undefined;
        } | {
            'p-divider-right': boolean;
            'p-divider-left'?: undefined;
            'p-divider-center'?: undefined;
            'p-divider-top'?: undefined;
            'p-divider-bottom'?: undefined;
        } | {
            'p-divider-top': boolean;
            'p-divider-left'?: undefined;
            'p-divider-center'?: undefined;
            'p-divider-right'?: undefined;
            'p-divider-bottom'?: undefined;
        } | {
            'p-divider-bottom': boolean;
            'p-divider-left'?: undefined;
            'p-divider-center'?: undefined;
            'p-divider-right'?: undefined;
            'p-divider-top'?: undefined;
        })[];
        content: string;
    };
    inlineStyles: {
        root: ({ instance }: {
            instance: any;
        }) => {
            justifyContent: string | null;
            alignItems: string | null;
        };
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<DividerStyle, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DividerStyle>;
}
/**
 *
 * Divider is used to separate contents.
 *
 * [Live Demo](https://ngx-prime.org/divider)
 *
 * @module dividerstyle
 *
 */
declare enum DividerClasses {
    /**
     * Class name of the root element
     */
    root = "p-divider",
    /**
     * Class name of the content element
     */
    content = "p-divider-content"
}

/**
 * Divider is used to separate contents.
 * @group Components
 */
declare class Divider extends BaseComponent<DividerPassThrough> {
    componentName: string;
    $pcDivider: Divider | undefined;
    bindDirectiveInstance: Bind;
    onAfterViewChecked(): void;
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass: i0.InputSignal<string | undefined>;
    /**
     * Specifies the orientation.
     * @group Props
     */
    layout: i0.InputSignal<"horizontal" | "vertical">;
    /**
     * Border style type.
     * @group Props
     */
    type: i0.InputSignal<"solid" | "dashed" | "dotted">;
    /**
     * Alignment of the content.
     * @group Props
     */
    align: i0.InputSignal<"center" | "left" | "right" | "top" | "bottom" | undefined>;
    _componentStyle: DividerStyle;
    get dataP(): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<Divider, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<Divider, "p-divider", never, { "styleClass": { "alias": "styleClass"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "align": { "alias": "align"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, [{ directive: typeof i1.Bind; inputs: {}; outputs: {}; }]>;
}
declare class DividerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DividerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DividerModule, never, [typeof Divider, typeof i1.BindModule], [typeof Divider, typeof i1.BindModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DividerModule>;
}

export { Divider, DividerClasses, DividerModule, DividerStyle };
