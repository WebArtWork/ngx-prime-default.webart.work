import { TemplateRef } from '@angular/core';
import { MotionOptions } from '@wawjs/css-prime-motion';
import { PassThrough, PassThroughOption } from '@wawjs/ngx-prime/api';

/**
 * Custom passthrough(pt) options.
 * @see {@link Fieldset.pt}
 * @group Interface
 */
interface FieldsetPassThroughOptions<I = unknown> {
    /**
     * Used to pass attributes to the root's DOM element.
     */
    root?: PassThroughOption<HTMLFieldSetElement, I>;
    /**
     * Used to pass attributes to the legend's DOM element.
     */
    legend?: PassThroughOption<HTMLLegendElement, I>;
    /**
     * Used to pass attributes to the toggle button's DOM element.
     */
    toggleButton?: PassThroughOption<HTMLButtonElement, I>;
    /**
     * Used to pass attributes to the toggle icon's DOM element.
     */
    toggleIcon?: PassThroughOption<SVGElement | HTMLSpanElement, I>;
    /**
     * Used to pass attributes to the legend label's DOM element.
     */
    legendLabel?: PassThroughOption<HTMLSpanElement, I>;
    /**
     * Used to pass attributes to the content container's DOM element.
     */
    contentContainer?: PassThroughOption<HTMLDivElement, I>;
    /**
     * Used to pass attributes to the content wrapper DOM element.
     */
    contentWrapper?: PassThroughOption<HTMLDivElement, I>;
    /**
     * Used to pass attributes to the content's DOM element.
     */
    content?: PassThroughOption<HTMLDivElement, I>;
    /**
     * Used to pass options to the motion component/directive.
     */
    motion?: MotionOptions;
}
/**
 * Defines valid pass-through options in Fieldset component.
 * @see {@link FieldsetPassThroughOptions}
 *
 * @template I Type of instance.
 */
type FieldsetPassThrough<I = unknown> = PassThrough<I, FieldsetPassThroughOptions<I>>;
/**
 * Custom panel toggle event, emits after toggle.
 * @see {@link Fieldset.onAfterToggle}
 * @group Events
 */
interface FieldsetAfterToggleEvent {
    /**
     * Browser event.
     */
    originalEvent: Event;
    /**
     * Collapsed state of the panel.
     */
    collapsed: boolean | undefined;
}
/**
 * Custom panel toggle event, emits before toggle.
 * @see {@link Fieldset.onBeforeToggle}
 * @extends {FieldsetAfterToggleEvent}
 * @group Events
 */
type FieldsetBeforeToggleEvent = FieldsetAfterToggleEvent;
/**
 * Defines valid templates in Fieldset.
 * @group Templates
 */
interface FieldsetTemplates {
    /**
     * Custom header template.
     */
    header(): TemplateRef<void>;
    /**
     * Custom content template.
     */
    content(): TemplateRef<void>;
    /**
     * Custom expand icon template.
     */
    expandicon(): TemplateRef<void>;
    /**
     * Custom collapse icon template.
     */
    collapseicon(): TemplateRef<void>;
}

export type { FieldsetAfterToggleEvent, FieldsetBeforeToggleEvent, FieldsetPassThrough, FieldsetPassThroughOptions, FieldsetTemplates };
