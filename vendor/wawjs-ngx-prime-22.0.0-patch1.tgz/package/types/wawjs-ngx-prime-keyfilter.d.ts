import * as i0 from '@angular/core';
import { Provider, ElementRef } from '@angular/core';
import { Validator, AbstractControl } from '@angular/forms';

type KeyFilterPattern = 'pint' | 'int' | 'pnum' | 'money' | 'num' | 'hex' | 'email' | 'alpha' | 'alphanum';
declare const KEYFILTER_VALIDATOR: Provider;
/**
 * KeyFilter Directive is a built-in feature of InputText to restrict user input based on a regular expression.
 * @group Components
 */
declare class KeyFilter implements Validator {
    private document;
    private platformId;
    el: ElementRef<any>;
    /**
     * When enabled, instead of blocking keys, input is validated internally to test against the regular expression.
     * @group Props
     */
    pValidateOnly: i0.InputSignalWithTransform<boolean, unknown>;
    /**
     * Sets the pattern for key filtering.
     * @group Props
     */
    pattern: i0.InputSignal<RegExp | KeyFilterPattern | null | undefined>;
    /**
     * Emits a value whenever the ngModel of the component changes.
     * @param {(string | number)} modelValue - Custom model change event.
     * @group Emits
     */
    ngModelChange: i0.OutputEmitterRef<string | number>;
    regex: RegExp;
    isAndroid: boolean;
    lastValue: any;
    constructor();
    isNavKeyPress(e: KeyboardEvent): boolean;
    isSpecialKey(e: KeyboardEvent): boolean | "" | undefined;
    getKey(e: KeyboardEvent): any;
    getCharCode(e: KeyboardEvent): number;
    findDelta(value: string, prevValue: string): string;
    isValidChar(c: string): boolean;
    isValidString(str: string): boolean;
    onInput(): void;
    onKeyPress(e: KeyboardEvent): void;
    onPaste(e: ClipboardEvent): void;
    validate(_c: AbstractControl): {
        [key: string]: any;
    } | any;
    static ɵfac: i0.ɵɵFactoryDeclaration<KeyFilter, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<KeyFilter, "[pKeyFilter]", never, { "pValidateOnly": { "alias": "pValidateOnly"; "required": false; "isSignal": true; }; "pattern": { "alias": "pKeyFilter"; "required": false; "isSignal": true; }; }, { "ngModelChange": "ngModelChange"; }, never, never, true, never>;
}
declare class KeyFilterModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<KeyFilterModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<KeyFilterModule, never, [typeof KeyFilter], [typeof KeyFilter]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<KeyFilterModule>;
}

export { KEYFILTER_VALIDATOR, KeyFilter, KeyFilterModule };
export type { KeyFilterPattern };
