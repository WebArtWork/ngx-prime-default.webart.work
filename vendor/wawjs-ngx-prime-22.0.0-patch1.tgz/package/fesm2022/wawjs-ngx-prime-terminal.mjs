export * from '@wawjs/ngx-prime/types/terminal';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, input, viewChild, effect, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import * as i2 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { SharedModule } from '@wawjs/ngx-prime/api';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { style } from '@wawjs/css-prime-styles/terminal';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import { Subject } from 'rxjs';

const classes = {
    root: () => ['p-terminal p-component'],
    welcomeMessage: 'p-terminal-welcome-message',
    commandList: 'p-terminal-command-list',
    command: 'p-terminal-command',
    commandValue: 'p-terminal-command-value',
    commandResponse: 'p-terminal-command-response',
    prompt: 'p-terminal-prompt',
    promptLabel: 'p-terminal-prompt-label',
    promptValue: 'p-terminal-prompt-value'
};
class TerminalStyle extends BaseStyle {
    name = 'terminal';
    style = style;
    classes = classes;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TerminalStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TerminalStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TerminalStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * Terminal is a text based user interface.
 *
 * [Live Demo](https://www.ngx-prime.org/terminal)
 *
 * @module terminalstyle
 *
 */
var TerminalClasses;
(function (TerminalClasses) {
    /**
     * Class name of the root element
     */
    TerminalClasses["root"] = "p-terminal";
    /**
     * Class name of the welcome message element
     */
    TerminalClasses["welcomeMessage"] = "p-terminal-welcome-message";
    /**
     * Class name of the command list element
     */
    TerminalClasses["commandList"] = "p-terminal-command-list";
    /**
     * Class name of the command element
     */
    TerminalClasses["command"] = "p-terminal-command";
    /**
     * Class name of the command value element
     */
    TerminalClasses["commandValue"] = "p-terminal-command-value";
    /**
     * Class name of the command response element
     */
    TerminalClasses["commandResponse"] = "p-terminal-command-response";
    /**
     * Class name of the prompt element
     */
    TerminalClasses["prompt"] = "p-terminal-prompt";
    /**
     * Class name of the prompt label element
     */
    TerminalClasses["promptLabel"] = "p-terminal-prompt-label";
    /**
     * Class name of the prompt value element
     */
    TerminalClasses["promptValue"] = "p-terminal-prompt-value";
})(TerminalClasses || (TerminalClasses = {}));

class TerminalService {
    commandSource = new Subject();
    responseSource = new Subject();
    commandHandler = this.commandSource.asObservable();
    responseHandler = this.responseSource.asObservable();
    sendCommand(command) {
        if (command) {
            this.commandSource.next(command);
        }
    }
    sendResponse(response) {
        if (response) {
            this.responseSource.next(response);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TerminalService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TerminalService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TerminalService, decorators: [{
            type: Injectable
        }] });

const TERMINAL_INSTANCE = new InjectionToken('TERMINAL_INSTANCE');
/**
 * Terminal is a text based user interface.
 * @group Components
 */
class Terminal extends BaseComponent {
    terminalService = inject(TerminalService);
    componentName = 'Terminal';
    $pcTerminal = inject(TERMINAL_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    bindDirectiveInstance = inject(Bind, { self: true });
    /**
     * Initial text to display on terminal.
     * @group Props
     */
    welcomeMessage = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "welcomeMessage" }] : /* istanbul ignore next */ []));
    /**
     * Prompt text for each command.
     * @group Props
     */
    prompt = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "prompt" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Response to display for the last command.
     * @group Props
     */
    response = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "response" }] : /* istanbul ignore next */ []));
    commands = [];
    command;
    container;
    commandProcessed;
    subscription;
    _componentStyle = inject(TerminalStyle);
    inputRef = viewChild.required('in', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputRef" }] : /* istanbul ignore next */ []));
    onHostClick() {
        this.focus(this.inputRef()?.nativeElement);
    }
    constructor() {
        super();
        const terminalService = this.terminalService;
        this.subscription = terminalService.responseHandler.subscribe((response) => {
            this.commands[this.commands.length - 1].response = response;
            this.commandProcessed = true;
        });
        effect(() => {
            const value = this.response();
            if (value) {
                this.commands[this.commands.length - 1].response = value;
                this.commandProcessed = true;
            }
        });
    }
    onAfterViewInit() {
        this.container = this.el.nativeElement;
    }
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
        if (this.commandProcessed) {
            this.container.scrollTop = this.container.scrollHeight;
            this.commandProcessed = false;
        }
    }
    handleCommand(event) {
        if (event.keyCode == 13) {
            this.commands.push({ text: this.command });
            this.terminalService.sendCommand(this.command);
            this.command = '';
        }
    }
    focus(element) {
        element.focus();
    }
    onDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Terminal, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: Terminal, isStandalone: true, selector: "p-terminal", inputs: { welcomeMessage: { classPropertyName: "welcomeMessage", publicName: "welcomeMessage", isSignal: true, isRequired: false, transformFunction: null }, prompt: { classPropertyName: "prompt", publicName: "prompt", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, response: { classPropertyName: "response", publicName: "response", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "onHostClick()" }, properties: { "class": "cn(cx('root'), styleClass())" } }, providers: [TerminalStyle, { provide: TERMINAL_INSTANCE, useExisting: Terminal }, { provide: PARENT_INSTANCE, useExisting: Terminal }], viewQueries: [{ propertyName: "inputRef", first: true, predicate: ["in"], descendants: true, isSignal: true }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        @if (welcomeMessage()) {
            <div [class]="cx('welcomeMessage')" [pBind]="ptm('welcomeMessage')">{{ welcomeMessage() }}</div>
        }
        <div [class]="cx('commandList')" [pBind]="ptm('commandList')">
            @for (command of commands; track command) {
                <div [class]="cx('command')" [pBind]="ptm('command')">
                    <span [class]="cx('promptLabel')" [pBind]="ptm('promptLabel')">{{ prompt() }}</span>
                    <span [class]="cx('commandValue')" [pBind]="ptm('commandValue')">{{ command.text }}</span>
                    <div [class]="cx('commandResponse')" [pBind]="ptm('commandResponse')" [attr.aria-live]="'polite'">{{ command.response }}</div>
                </div>
            }
        </div>
        <div [class]="cx('prompt')" [pBind]="ptm('prompt')">
            <span [class]="cx('promptLabel')" [pBind]="ptm('promptLabel')">{{ prompt() }}</span>
            <input #in type="text" [(ngModel)]="command" [class]="cx('promptValue')" [pBind]="ptm('promptValue')" autocomplete="off" (keydown)="handleCommand($event)" autofocus />
        </div>
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.DefaultValueAccessor, selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: SharedModule }, { kind: "directive", type: Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Terminal, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-terminal',
                    standalone: true,
                    imports: [FormsModule, SharedModule, Bind],
                    template: `
        @if (welcomeMessage()) {
            <div [class]="cx('welcomeMessage')" [pBind]="ptm('welcomeMessage')">{{ welcomeMessage() }}</div>
        }
        <div [class]="cx('commandList')" [pBind]="ptm('commandList')">
            @for (command of commands; track command) {
                <div [class]="cx('command')" [pBind]="ptm('command')">
                    <span [class]="cx('promptLabel')" [pBind]="ptm('promptLabel')">{{ prompt() }}</span>
                    <span [class]="cx('commandValue')" [pBind]="ptm('commandValue')">{{ command.text }}</span>
                    <div [class]="cx('commandResponse')" [pBind]="ptm('commandResponse')" [attr.aria-live]="'polite'">{{ command.response }}</div>
                </div>
            }
        </div>
        <div [class]="cx('prompt')" [pBind]="ptm('prompt')">
            <span [class]="cx('promptLabel')" [pBind]="ptm('promptLabel')">{{ prompt() }}</span>
            <input #in type="text" [(ngModel)]="command" [class]="cx('promptValue')" [pBind]="ptm('promptValue')" autocomplete="off" (keydown)="handleCommand($event)" autofocus />
        </div>
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [TerminalStyle, { provide: TERMINAL_INSTANCE, useExisting: Terminal }, { provide: PARENT_INSTANCE, useExisting: Terminal }],
                    host: {
                        '[class]': "cn(cx('root'), styleClass())",
                        '(click)': 'onHostClick()'
                    },
                    hostDirectives: [Bind]
                }]
        }], ctorParameters: () => [], propDecorators: { welcomeMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "welcomeMessage", required: false }] }], prompt: [{ type: i0.Input, args: [{ isSignal: true, alias: "prompt", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], response: [{ type: i0.Input, args: [{ isSignal: true, alias: "response", required: false }] }], inputRef: [{ type: i0.ViewChild, args: ['in', { isSignal: true }] }] } });
class TerminalModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TerminalModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: TerminalModule, imports: [Terminal, SharedModule], exports: [Terminal, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TerminalModule, imports: [Terminal, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TerminalModule, decorators: [{
            type: NgModule,
            args: [{
                    exports: [Terminal, SharedModule],
                    imports: [Terminal, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { Terminal, TerminalClasses, TerminalModule, TerminalService, TerminalStyle };
//# sourceMappingURL=wawjs-ngx-prime-terminal.mjs.map
