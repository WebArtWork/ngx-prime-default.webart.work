/**
 * @todo: Add dynamic params support;
 *
 * Exp;
 * usePassThrough(pt1, pt2, pt3, pt*, { mergeSections: true });
 * usePassThrough(pt1, { mergeSections: true });
 */
const usePassThrough = (pt1 = {}, pt2 = {}, ptOptions) => ({
    _usept: ptOptions,
    originalValue: pt1,
    value: { ...pt1, ...pt2 }
});

/**
 * Generated bundle index. Do not edit.
 */

export { usePassThrough };
//# sourceMappingURL=wawjs-ngx-prime-passthrough.mjs.map
