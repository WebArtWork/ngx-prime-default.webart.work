import * as i0 from '@angular/core';
import { inject, ElementRef, NgZone, Renderer2, input, output, effect, Directive, NgModule } from '@angular/core';
import { removeClass, addClass } from '@wawjs/css-prime-utils';
import { DomHandler } from '@wawjs/ngx-prime/dom';

/**
 * pDraggable directive apply draggable behavior to any element.
 * @group Components
 */
class Draggable {
    el = inject(ElementRef);
    zone = inject(NgZone);
    renderer = inject(Renderer2);
    scope = input(undefined, { ...(ngDevMode ? { debugName: "scope" } : /* istanbul ignore next */ {}), alias: 'pDraggable' });
    /**
     * Defines the cursor style.
     * @group Props
     */
    dragEffect = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "dragEffect" }] : /* istanbul ignore next */ []));
    /**
     * Selector to define the drag handle, by default anywhere on the target element is a drag handle to start dragging.
     * @group Props
     */
    dragHandle = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "dragHandle" }] : /* istanbul ignore next */ []));
    /**
     * Callback to invoke when drag begins.
     * @param {DragEvent} event - Drag event.
     * @group Emits
     */
    onDragStart = output();
    /**
     * Callback to invoke when drag ends.
     * @param {DragEvent} event - Drag event.
     * @group Emits
     */
    onDragEnd = output();
    /**
     * Callback to invoke on dragging.
     * @param {DragEvent} event - Drag event.
     * @group Emits
     */
    onDrag = output();
    handle;
    dragListener;
    mouseDownListener;
    mouseUpListener;
    pDraggableDisabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pDraggableDisabled" }] : /* istanbul ignore next */ []));
    constructor() {
        effect(() => {
            if (this.pDraggableDisabled()) {
                this.unbindMouseListeners();
            }
            else {
                this.el.nativeElement.draggable = true;
                this.bindMouseListeners();
            }
        });
    }
    ngAfterViewInit() {
        if (!this.pDraggableDisabled()) {
            this.el.nativeElement.draggable = true;
            this.bindMouseListeners();
        }
    }
    bindDragListener() {
        if (!this.dragListener) {
            this.zone.runOutsideAngular(() => {
                this.dragListener = this.renderer.listen(this.el.nativeElement, 'drag', this.drag.bind(this));
            });
        }
    }
    unbindDragListener() {
        if (this.dragListener) {
            this.zone.runOutsideAngular(() => {
                this.dragListener && this.dragListener();
                this.dragListener = null;
            });
        }
    }
    bindMouseListeners() {
        if (!this.mouseDownListener && !this.mouseUpListener) {
            this.zone.runOutsideAngular(() => {
                this.mouseDownListener = this.renderer.listen(this.el.nativeElement, 'mousedown', this.mousedown.bind(this));
                this.mouseUpListener = this.renderer.listen(this.el.nativeElement, 'mouseup', this.mouseup.bind(this));
            });
        }
    }
    unbindMouseListeners() {
        if (this.mouseDownListener && this.mouseUpListener) {
            this.zone.runOutsideAngular(() => {
                this.mouseDownListener && this.mouseDownListener();
                this.mouseUpListener && this.mouseUpListener();
                this.mouseDownListener = null;
                this.mouseUpListener = null;
            });
        }
    }
    drag(event) {
        this.onDrag.emit(event);
    }
    dragStart(event) {
        if (this.allowDrag() && !this.pDraggableDisabled()) {
            const dragEffect = this.dragEffect();
            if (dragEffect) {
                event.dataTransfer.effectAllowed = dragEffect;
            }
            event.dataTransfer.setData('text', this.scope());
            this.onDragStart.emit(event);
            this.bindDragListener();
        }
        else {
            event.preventDefault();
        }
    }
    dragEnd(event) {
        this.onDragEnd.emit(event);
        this.unbindDragListener();
    }
    mousedown(event) {
        this.handle = event.target;
    }
    mouseup() {
        this.handle = null;
    }
    allowDrag() {
        const dragHandle = this.dragHandle();
        if (dragHandle && this.handle)
            return DomHandler.matches(this.handle, dragHandle);
        else
            return true;
    }
    ngOnDestroy() {
        this.unbindDragListener();
        this.unbindMouseListeners();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Draggable, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: Draggable, isStandalone: true, selector: "[pDraggable]", inputs: { scope: { classPropertyName: "scope", publicName: "pDraggable", isSignal: true, isRequired: false, transformFunction: null }, dragEffect: { classPropertyName: "dragEffect", publicName: "dragEffect", isSignal: true, isRequired: false, transformFunction: null }, dragHandle: { classPropertyName: "dragHandle", publicName: "dragHandle", isSignal: true, isRequired: false, transformFunction: null }, pDraggableDisabled: { classPropertyName: "pDraggableDisabled", publicName: "pDraggableDisabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onDragStart: "onDragStart", onDragEnd: "onDragEnd", onDrag: "onDrag" }, host: { listeners: { "dragstart": "dragStart($event)", "dragend": "dragEnd($event)" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Draggable, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pDraggable]',
                    standalone: true,
                    host: {
                        '(dragstart)': 'dragStart($event)',
                        '(dragend)': 'dragEnd($event)'
                    }
                }]
        }], ctorParameters: () => [], propDecorators: { scope: [{ type: i0.Input, args: [{ isSignal: true, alias: "pDraggable", required: false }] }], dragEffect: [{ type: i0.Input, args: [{ isSignal: true, alias: "dragEffect", required: false }] }], dragHandle: [{ type: i0.Input, args: [{ isSignal: true, alias: "dragHandle", required: false }] }], onDragStart: [{ type: i0.Output, args: ["onDragStart"] }], onDragEnd: [{ type: i0.Output, args: ["onDragEnd"] }], onDrag: [{ type: i0.Output, args: ["onDrag"] }], pDraggableDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "pDraggableDisabled", required: false }] }] } });
/**
 * pDroppable directive apply droppable behavior to any element.
 * @group Components
 */
class Droppable {
    el = inject(ElementRef);
    zone = inject(NgZone);
    renderer = inject(Renderer2);
    scope = input(undefined, { ...(ngDevMode ? { debugName: "scope" } : /* istanbul ignore next */ {}), alias: 'pDroppable' });
    /**
     * Whether the element is droppable, useful for conditional cases.
     * @group Props
     */
    pDroppableDisabled = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "pDroppableDisabled" }] : /* istanbul ignore next */ []));
    /**
     * Defines the cursor style, valid values are none, copy, move, link, copyMove, copyLink, linkMove and all.
     * @group Props
     */
    dropEffect = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "dropEffect" }] : /* istanbul ignore next */ []));
    /**
     * Callback to invoke when a draggable enters drop area.
     * @group Emits
     */
    onDragEnter = output();
    /**
     * Callback to invoke when a draggable leave drop area.
     * @group Emits
     */
    onDragLeave = output();
    /**
     * Callback to invoke when a draggable is dropped onto drop area.
     * @group Emits
     */
    onDrop = output();
    dragOverListener;
    constructor() {
        effect(() => {
            if (this.pDroppableDisabled()) {
                this.unbindDragOverListener();
            }
            else {
                this.bindDragOverListener();
            }
        });
    }
    ngAfterViewInit() {
        if (!this.pDroppableDisabled()) {
            this.bindDragOverListener();
        }
    }
    bindDragOverListener() {
        if (!this.dragOverListener) {
            this.zone.runOutsideAngular(() => {
                this.dragOverListener = this.renderer.listen(this.el.nativeElement, 'dragover', this.dragOver.bind(this));
            });
        }
    }
    unbindDragOverListener() {
        if (this.dragOverListener) {
            this.zone.runOutsideAngular(() => {
                this.dragOverListener && this.dragOverListener();
                this.dragOverListener = null;
            });
        }
    }
    dragOver(event) {
        event.preventDefault();
    }
    drop(event) {
        if (this.allowDrop(event)) {
            removeClass(this.el.nativeElement, 'p-draggable-enter');
            event.preventDefault();
            this.onDrop.emit(event);
        }
    }
    dragEnter(event) {
        event.preventDefault();
        const dropEffect = this.dropEffect();
        if (dropEffect) {
            event.dataTransfer.dropEffect = dropEffect;
        }
        addClass(this.el.nativeElement, 'p-draggable-enter');
        this.onDragEnter.emit(event);
    }
    dragLeave(event) {
        event.preventDefault();
        if (!this.el.nativeElement.contains(event.relatedTarget)) {
            removeClass(this.el.nativeElement, 'p-draggable-enter');
            this.onDragLeave.emit(event);
        }
    }
    allowDrop(event) {
        let dragScope = event.dataTransfer.getData('text');
        const scope = this.scope();
        if (typeof scope == 'string' && dragScope == scope) {
            return true;
        }
        else if (Array.isArray(scope)) {
            for (let j = 0; j < scope.length; j++) {
                if (dragScope == scope[j]) {
                    return true;
                }
            }
        }
        return false;
    }
    ngOnDestroy() {
        this.unbindDragOverListener();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Droppable, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: Droppable, isStandalone: true, selector: "[pDroppable]", inputs: { scope: { classPropertyName: "scope", publicName: "pDroppable", isSignal: true, isRequired: false, transformFunction: null }, pDroppableDisabled: { classPropertyName: "pDroppableDisabled", publicName: "pDroppableDisabled", isSignal: true, isRequired: false, transformFunction: null }, dropEffect: { classPropertyName: "dropEffect", publicName: "dropEffect", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onDragEnter: "onDragEnter", onDragLeave: "onDragLeave", onDrop: "onDrop" }, host: { listeners: { "drop": "drop($event)", "dragenter": "dragEnter($event)", "dragleave": "dragLeave($event)" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Droppable, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pDroppable]',
                    standalone: true,
                    host: {
                        '(drop)': 'drop($event)',
                        '(dragenter)': 'dragEnter($event)',
                        '(dragleave)': 'dragLeave($event)'
                    }
                }]
        }], ctorParameters: () => [], propDecorators: { scope: [{ type: i0.Input, args: [{ isSignal: true, alias: "pDroppable", required: false }] }], pDroppableDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "pDroppableDisabled", required: false }] }], dropEffect: [{ type: i0.Input, args: [{ isSignal: true, alias: "dropEffect", required: false }] }], onDragEnter: [{ type: i0.Output, args: ["onDragEnter"] }], onDragLeave: [{ type: i0.Output, args: ["onDragLeave"] }], onDrop: [{ type: i0.Output, args: ["onDrop"] }] } });
class DragDropModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DragDropModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: DragDropModule, imports: [Draggable, Droppable], exports: [Draggable, Droppable] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DragDropModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DragDropModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [Draggable, Droppable],
                    exports: [Draggable, Droppable]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { DragDropModule, Draggable, Droppable };
//# sourceMappingURL=wawjs-ngx-prime-dragdrop.mjs.map
