import * as i0 from '@angular/core';
import { input, booleanAttribute, signal, computed, Directive } from '@angular/core';
import { BaseModelHolder } from '@wawjs/ngx-prime/basemodelholder';

class BaseEditableHolder extends BaseModelHolder {
    /**
     * There must be a value (if set).
     * @defaultValue false
     * @group Props
     */
    required = input(undefined, { ...(ngDevMode ? { debugName: "required" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * When present, it specifies that the component should have invalid state style.
     * @defaultValue false
     * @group Props
     */
    invalid = input(undefined, { ...(ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * When present, it specifies that the component should have disabled state style.
     * @defaultValue false
     * @group Props
     */
    disabled = input(undefined, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * When present, it specifies that the name of the input.
     * @defaultValue undefined
     * @group Props
     */
    name = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "name" }] : /* istanbul ignore next */ []));
    _disabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_disabled" }] : /* istanbul ignore next */ []));
    $disabled = computed(() => this.disabled() || this._disabled(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "$disabled" }] : /* istanbul ignore next */ []));
    onModelChange = () => { };
    onModelTouched = () => { };
    writeDisabledState(value) {
        this._disabled.set(value);
    }
    // eslint-disable-next-line @typescript-eslint/no-unused-vars -- kept so subclass overrides (which do use both params) satisfy the base signature.
    writeControlValue(value, setModelValue) {
        // NOOP - this method should be overridden in the derived classes
    }
    /**** Angular ControlValueAccessors ****/
    writeValue(value) {
        this.writeControlValue(value, this.writeModelValue.bind(this));
    }
    registerOnChange(fn) {
        this.onModelChange = fn;
    }
    registerOnTouched(fn) {
        this.onModelTouched = fn;
    }
    setDisabledState(val) {
        this.writeDisabledState(val);
        this.cd.markForCheck();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BaseEditableHolder, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: BaseEditableHolder, isStandalone: true, inputs: { required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null } }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BaseEditableHolder, decorators: [{
            type: Directive,
            args: [{ standalone: true }]
        }], propDecorators: { required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { BaseEditableHolder };
//# sourceMappingURL=wawjs-ngx-prime-baseeditableholder.mjs.map
