export * from '@wawjs/ngx-prime/types/menubar';
import * as i1 from '@angular/common';
import { CommonModule, DOCUMENT, isPlatformBrowser } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, input, booleanAttribute, numberAttribute, output, inject, ViewEncapsulation, Component, PLATFORM_ID, ElementRef, Renderer2, ChangeDetectorRef, viewChild, signal, effect, contentChild, contentChildren, ContentChild, ViewChild, ChangeDetectionStrategy, NgModule } from '@angular/core';
import * as i2 from '@angular/router';
import { RouterModule } from '@angular/router';
import { resolve, isNotEmpty, uuid, isEmpty, focus, isTouchDevice, findSingle, isPrintableCharacter, findLastIndex } from '@wawjs/css-prime-utils';
import { SharedModule, PrimeTemplate } from '@wawjs/ngx-prime/api';
import * as i5 from '@wawjs/ngx-prime/badge';
import { BadgeModule } from '@wawjs/ngx-prime/badge';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i4 from '@wawjs/ngx-prime/bind';
import { BindModule, Bind } from '@wawjs/ngx-prime/bind';
import { AngleDownIcon, AngleRightIcon, BarsIcon } from '@wawjs/ngx-prime/icons';
import { Ripple } from '@wawjs/ngx-prime/ripple';
import * as i3 from '@wawjs/ngx-prime/tooltip';
import { TooltipModule } from '@wawjs/ngx-prime/tooltip';
import { ZIndexUtils } from '@wawjs/ngx-prime/utils';
import { Subject, interval } from 'rxjs';
import { debounce, filter } from 'rxjs/operators';
import { style } from '@wawjs/css-prime-styles/menubar';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const inlineStyles = {
    submenu: ({ instance, processedItem }) => ({ display: instance.isItemActive(processedItem) ? 'flex' : 'none' })
};
const classes = {
    root: ({ instance }) => [
        'p-menubar p-component',
        {
            'p-menubar-mobile': instance.queryMatches(),
            'p-menubar-mobile-active': instance.mobileActive
        }
    ],
    start: 'p-menubar-start',
    button: 'p-menubar-button',
    rootList: 'p-menubar-root-list',
    item: ({ instance, processedItem }) => [
        'p-menubar-item',
        {
            'p-menubar-item-active': instance.isItemActive(processedItem),
            'p-focus': instance.isItemFocused(processedItem),
            'p-disabled': instance.isItemDisabled(processedItem)
        }
    ],
    itemContent: 'p-menubar-item-content',
    itemLink: 'p-menubar-item-link',
    itemIcon: 'p-menubar-item-icon',
    itemLabel: 'p-menubar-item-label',
    submenuIcon: 'p-menubar-submenu-icon',
    submenu: 'p-menubar-submenu',
    separator: 'p-menubar-separator',
    end: 'p-menubar-end'
};
class MenuBarStyle extends BaseStyle {
    name = 'menubar';
    style = style;
    classes = classes;
    inlineStyles = inlineStyles;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MenuBarStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MenuBarStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MenuBarStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * Menubar is a horizontal menu component.
 *
 * [Live Demo](https://www.ngx-prime.org/menubar/)
 *
 * @module menubarstyle
 *
 */
var MenubarClasses;
(function (MenubarClasses) {
    /**
     * Class name of the root element
     */
    MenubarClasses["root"] = "p-menubar";
    /**
     * Class name of the start element
     */
    MenubarClasses["start"] = "p-menubar-start";
    /**
     * Class name of the button element
     */
    MenubarClasses["button"] = "p-menubar-button";
    /**
     * Class name of the root list element
     */
    MenubarClasses["rootList"] = "p-menubar-root-list";
    /**
     * Class name of the item element
     */
    MenubarClasses["item"] = "p-menubar-item";
    /**
     * Class name of the item content element
     */
    MenubarClasses["itemContent"] = "p-menubar-item-content";
    /**
     * Class name of the item link element
     */
    MenubarClasses["itemLink"] = "p-menubar-item-link";
    /**
     * Class name of the item icon element
     */
    MenubarClasses["itemIcon"] = "p-menubar-item-icon";
    /**
     * Class name of the item label element
     */
    MenubarClasses["itemLabel"] = "p-menubar-item-label";
    /**
     * Class name of the submenu icon element
     */
    MenubarClasses["submenuIcon"] = "p-menubar-submenu-icon";
    /**
     * Class name of the submenu element
     */
    MenubarClasses["submenu"] = "p-menubar-submenu";
    /**
     * Class name of the separator element
     */
    MenubarClasses["separator"] = "p-menubar-separator";
    /**
     * Class name of the end element
     */
    MenubarClasses["end"] = "p-menubar-end";
})(MenubarClasses || (MenubarClasses = {}));

const MENUBAR_INSTANCE = new InjectionToken('MENUBAR_INSTANCE');
class MenubarService {
    autoHide;
    autoHideDelay;
    mouseLeaves = new Subject();
    mouseLeft$ = this.mouseLeaves.pipe(debounce(() => interval(this.autoHideDelay)), filter((mouseLeft) => this.autoHide && mouseLeft));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MenubarService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MenubarService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MenubarService, decorators: [{
            type: Injectable
        }] });
class MenubarSub extends BaseComponent {
    items = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "items" }] : /* istanbul ignore next */ []));
    itemTemplate = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "itemTemplate" }] : /* istanbul ignore next */ []));
    root = input(false, { ...(ngDevMode ? { debugName: "root" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    autoZIndex = input(true, { ...(ngDevMode ? { debugName: "autoZIndex" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    baseZIndex = input(0, { ...(ngDevMode ? { debugName: "baseZIndex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    mobileActive = input(undefined, { ...(ngDevMode ? { debugName: "mobileActive" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    autoDisplay = input(undefined, { ...(ngDevMode ? { debugName: "autoDisplay" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    menuId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "menuId" }] : /* istanbul ignore next */ []));
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    level = input(0, { ...(ngDevMode ? { debugName: "level" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    focusedItemId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "focusedItemId" }] : /* istanbul ignore next */ []));
    activeItemPath = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "activeItemPath" }] : /* istanbul ignore next */ []));
    inlineStyles = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "inlineStyles" }] : /* istanbul ignore next */ []));
    submenuiconTemplate = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "submenuiconTemplate" }] : /* istanbul ignore next */ []));
    itemClick = output();
    itemMouseEnter = output();
    menuFocus = output();
    menuBlur = output();
    menuKeydown = output();
    mouseLeaveSubscriber;
    menubarService = inject(MenubarService);
    _componentStyle = inject(MenuBarStyle);
    hostName = 'Menubar';
    onInit() {
        this.mouseLeaveSubscriber = this.menubarService.mouseLeft$.subscribe(() => {
            this.cd.markForCheck();
        });
    }
    onItemClick(event, processedItem) {
        this.getItemProp(processedItem, 'command', { originalEvent: event, item: processedItem.item });
        this.itemClick.emit({ originalEvent: event, processedItem, isFocus: true });
    }
    getItemProp(processedItem, name, params = null) {
        return processedItem && processedItem.item ? resolve(processedItem.item[name], params) : undefined;
    }
    getItemId(processedItem) {
        return processedItem.item && processedItem.item?.id ? processedItem.item.id : `${this.menuId()}_${processedItem.key}`;
    }
    getItemLabelId(processedItem) {
        return `${this.menuId()}_${processedItem.key}_label`;
    }
    getItemLabel(processedItem) {
        return this.getItemProp(processedItem, 'label');
    }
    isItemVisible(processedItem) {
        return this.getItemProp(processedItem, 'visible') !== false;
    }
    isItemActive(processedItem) {
        const activeItemPath = this.activeItemPath();
        if (activeItemPath) {
            return activeItemPath.some((path) => path.key === processedItem.key);
        }
        return false;
    }
    isItemDisabled(processedItem) {
        return this.getItemProp(processedItem, 'disabled');
    }
    isItemFocused(processedItem) {
        return this.focusedItemId() === this.getItemId(processedItem);
    }
    isItemGroup(processedItem) {
        return isNotEmpty(processedItem.items);
    }
    getAriaSetSize() {
        return this.items()?.filter((processedItem) => this.isItemVisible(processedItem) && !this.getItemProp(processedItem, 'separator')).length;
    }
    getAriaPosInset(index) {
        return (index -
            (this.items()
                ?.slice(0, index)
                .filter((processedItem) => this.isItemVisible(processedItem) && this.getItemProp(processedItem, 'separator')).length || 0) +
            1);
    }
    onItemMouseEnter(param) {
        if (this.autoDisplay()) {
            const { event, processedItem } = param;
            this.itemMouseEnter.emit({ originalEvent: event, processedItem });
        }
    }
    getPTOptions(processedItem, index, key) {
        return this.ptm(key, {
            context: {
                item: processedItem.item,
                index,
                active: this.isItemActive(processedItem),
                focused: this.isItemFocused(processedItem),
                disabled: this.isItemDisabled(processedItem),
                level: this.level()
            }
        });
    }
    onDestroy() {
        this.mouseLeaveSubscriber?.unsubscribe();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MenubarSub, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: MenubarSub, isStandalone: true, selector: "p-menubarSub, p-menubarsub, [pMenubarSub]", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, itemTemplate: { classPropertyName: "itemTemplate", publicName: "itemTemplate", isSignal: true, isRequired: false, transformFunction: null }, root: { classPropertyName: "root", publicName: "root", isSignal: true, isRequired: false, transformFunction: null }, autoZIndex: { classPropertyName: "autoZIndex", publicName: "autoZIndex", isSignal: true, isRequired: false, transformFunction: null }, baseZIndex: { classPropertyName: "baseZIndex", publicName: "baseZIndex", isSignal: true, isRequired: false, transformFunction: null }, mobileActive: { classPropertyName: "mobileActive", publicName: "mobileActive", isSignal: true, isRequired: false, transformFunction: null }, autoDisplay: { classPropertyName: "autoDisplay", publicName: "autoDisplay", isSignal: true, isRequired: false, transformFunction: null }, menuId: { classPropertyName: "menuId", publicName: "menuId", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, level: { classPropertyName: "level", publicName: "level", isSignal: true, isRequired: false, transformFunction: null }, focusedItemId: { classPropertyName: "focusedItemId", publicName: "focusedItemId", isSignal: true, isRequired: false, transformFunction: null }, activeItemPath: { classPropertyName: "activeItemPath", publicName: "activeItemPath", isSignal: true, isRequired: false, transformFunction: null }, inlineStyles: { classPropertyName: "inlineStyles", publicName: "inlineStyles", isSignal: true, isRequired: false, transformFunction: null }, submenuiconTemplate: { classPropertyName: "submenuiconTemplate", publicName: "submenuiconTemplate", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { itemClick: "itemClick", itemMouseEnter: "itemMouseEnter", menuFocus: "menuFocus", menuBlur: "menuBlur", menuKeydown: "menuKeydown" }, host: { properties: { "attr.id": "root() ? menuId() : null", "attr.aria-activedescendant": "focusedItemId()", "class": "level() === 0 ? cx('rootList') : cx('submenu')", "attr.role": "'menubar'", "style": "inlineStyles()" } }, usesInheritance: true, ngImport: i0, template: `
        @for (processedItem of items(); track processedItem; let index = $index) {
            @if (isItemVisible(processedItem) && getItemProp(processedItem, 'separator')) {
                <li [attr.id]="getItemId(processedItem)" [style]="getItemProp(processedItem, 'style')" [class]="cn(cx('separator'), processedItem?.styleClass)" role="separator" [pBind]="ptm('separator')"></li>
            }
            @if (isItemVisible(processedItem) && !getItemProp(processedItem, 'separator')) {
                <li
                    #listItem
                    role="menuitem"
                    [attr.id]="getItemId(processedItem)"
                    [attr.data-p-highlight]="isItemActive(processedItem)"
                    [attr.data-p-focused]="isItemFocused(processedItem)"
                    [attr.data-p-disabled]="isItemDisabled(processedItem)"
                    [attr.aria-label]="getItemLabel(processedItem)"
                    [attr.aria-disabled]="isItemDisabled(processedItem) || undefined"
                    [attr.aria-haspopup]="isItemGroup(processedItem) && !getItemProp(processedItem, 'to') ? 'menu' : undefined"
                    [attr.aria-expanded]="isItemGroup(processedItem) ? isItemActive(processedItem) : undefined"
                    [attr.aria-setsize]="getAriaSetSize()"
                    [attr.aria-posinset]="getAriaPosInset(index)"
                    [style]="getItemProp(processedItem, 'style')"
                    [class]="cn(cx('item', { instance: this, processedItem }), getItemProp(processedItem, 'styleClass'))"
                    [pBind]="getPTOptions(processedItem, index, 'item')"
                    pTooltip
                    [tooltipOptions]="getItemProp(processedItem, 'tooltipOptions')"
                    [pTooltipUnstyled]="unstyled()"
                >
                    <div [class]="cx('itemContent')" [pBind]="getPTOptions(processedItem, index, 'itemContent')" (click)="onItemClick($event, processedItem)" (mouseenter)="onItemMouseEnter({ $event, processedItem })">
                        @if (!itemTemplate()) {
                            @if (!getItemProp(processedItem, 'routerLink')) {
                                <a
                                    [attr.href]="getItemProp(processedItem, 'url')"
                                    [attr.data-automationid]="getItemProp(processedItem, 'automationId')"
                                    [attr.title]="getItemProp(processedItem, 'title')"
                                    [attr.target]="getItemProp(processedItem, 'target')"
                                    [class]="cn(cx('itemLink'), getItemProp(processedItem, 'linkClass'))"
                                    [ngStyle]="getItemProp(processedItem, 'linkStyle')"
                                    [attr.tabindex]="-1"
                                    [pBind]="getPTOptions(processedItem, index, 'itemLink')"
                                    pRipple
                                >
                                    @if (getItemProp(processedItem, 'icon')) {
                                        <span
                                            [class]="cn(cx('itemIcon'), getItemProp(processedItem, 'icon'), getItemProp(processedItem, 'iconClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                            [attr.tabindex]="-1"
                                            [pBind]="getPTOptions(processedItem, index, 'itemIcon')"
                                        >
                                        </span>
                                    }
                                    @if (getItemProp(processedItem, 'escape')) {
                                        <span
                                            [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'labelStyle')"
                                            [id]="getItemLabelId(processedItem)"
                                            [pBind]="getPTOptions(processedItem, index, 'itemLabel')"
                                        >
                                            {{ getItemLabel(processedItem) }}
                                        </span>
                                    } @else {
                                        <span
                                            [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'labelStyle')"
                                            [innerHTML]="getItemLabel(processedItem)"
                                            [id]="getItemLabelId(processedItem)"
                                            [pBind]="getPTOptions(processedItem, index, 'itemLabel')"
                                        ></span>
                                    }
                                    @if (getItemProp(processedItem, 'badge')) {
                                        <p-badge [class]="getItemProp(processedItem, 'badgeStyleClass')" [value]="getItemProp(processedItem, 'badge')" [pt]="getPTOptions(processedItem, index, 'pcBadge')" [unstyled]="unstyled()" />
                                    }
                                    @if (isItemGroup(processedItem)) {
                                        @if (!submenuiconTemplate()) {
                                            @if (root()) {
                                                <svg data-p-icon="angle-down" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" />
                                            }
                                            @if (!root()) {
                                                <svg data-p-icon="angle-right" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" />
                                            }
                                        }
                                        <ng-template *ngTemplateOutlet="submenuiconTemplate()"></ng-template>
                                    }
                                </a>
                            }
                            @if (getItemProp(processedItem, 'routerLink')) {
                                <a
                                    [routerLink]="getItemProp(processedItem, 'routerLink')"
                                    [attr.data-automationid]="getItemProp(processedItem, 'automationId')"
                                    [attr.title]="getItemProp(processedItem, 'title')"
                                    [attr.tabindex]="-1"
                                    [queryParams]="getItemProp(processedItem, 'queryParams')"
                                    [routerLinkActive]="'p-menubar-item-link-active'"
                                    [routerLinkActiveOptions]="getItemProp(processedItem, 'routerLinkActiveOptions') || { exact: false }"
                                    [target]="getItemProp(processedItem, 'target')"
                                    [class]="cn(cx('itemLink'), getItemProp(processedItem, 'linkClass'))"
                                    [ngStyle]="getItemProp(processedItem, 'linkStyle')"
                                    [fragment]="getItemProp(processedItem, 'fragment')"
                                    [queryParamsHandling]="getItemProp(processedItem, 'queryParamsHandling')"
                                    [preserveFragment]="getItemProp(processedItem, 'preserveFragment')"
                                    [skipLocationChange]="getItemProp(processedItem, 'skipLocationChange')"
                                    [replaceUrl]="getItemProp(processedItem, 'replaceUrl')"
                                    [state]="getItemProp(processedItem, 'state')"
                                    [pBind]="getPTOptions(processedItem, index, 'itemLink')"
                                    pRipple
                                >
                                    @if (getItemProp(processedItem, 'icon')) {
                                        <span
                                            [class]="cn(cx('itemIcon'), getItemProp(processedItem, 'icon'), getItemProp(processedItem, 'iconClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                            [attr.tabindex]="-1"
                                            [pBind]="getPTOptions(processedItem, index, 'itemIcon')"
                                        ></span>
                                    }
                                    @if (getItemProp(processedItem, 'escape')) {
                                        <span [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))" [ngStyle]="getItemProp(processedItem, 'labelStyle')" [pBind]="getPTOptions(processedItem, index, 'itemLabel')">{{
                                            getItemLabel(processedItem)
                                        }}</span>
                                    } @else {
                                        <span
                                            [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'labelStyle')"
                                            [innerHTML]="getItemLabel(processedItem)"
                                            [pBind]="getPTOptions(processedItem, index, 'itemLabel')"
                                        ></span>
                                    }
                                    @if (getItemProp(processedItem, 'badge')) {
                                        <p-badge [class]="getItemProp(processedItem, 'badgeStyleClass')" [value]="getItemProp(processedItem, 'badge')" [pt]="getPTOptions(processedItem, index, 'pcBadge')" [unstyled]="unstyled()" />
                                    }
                                    @if (isItemGroup(processedItem)) {
                                        @if (!submenuiconTemplate()) {
                                            @if (root()) {
                                                <svg data-p-icon="angle-down" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" />
                                            }
                                            @if (!root()) {
                                                <svg data-p-icon="angle-right" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" />
                                            }
                                        }
                                        <ng-template *ngTemplateOutlet="submenuiconTemplate()"></ng-template>
                                    }
                                </a>
                            }
                        }
                        @if (itemTemplate()) {
                            <ng-template *ngTemplateOutlet="itemTemplate(); context: { $implicit: processedItem.item, root: root() }"></ng-template>
                        }
                    </div>
                    @if (isItemVisible(processedItem) && isItemGroup(processedItem)) {
                        <ul
                            pMenubarSub
                            [itemTemplate]="itemTemplate()"
                            [items]="processedItem.items"
                            [mobileActive]="mobileActive()"
                            [autoDisplay]="autoDisplay()"
                            [menuId]="menuId()"
                            [activeItemPath]="activeItemPath()"
                            [focusedItemId]="focusedItemId()"
                            [level]="level() + 1"
                            [attr.aria-labelledby]="getItemLabelId(processedItem)"
                            (itemClick)="itemClick.emit($event)"
                            (itemMouseEnter)="onItemMouseEnter($event)"
                            [inlineStyles]="sx('submenu', true, { instance: this, processedItem })"
                            [pt]="pt()"
                            [pBind]="ptm('submenu')"
                            [unstyled]="unstyled()"
                        ></ul>
                    }
                </li>
            }
        }
    `, isInline: true, dependencies: [{ kind: "component", type: MenubarSub, selector: "p-menubarSub, p-menubarsub, [pMenubarSub]", inputs: ["items", "itemTemplate", "root", "autoZIndex", "baseZIndex", "mobileActive", "autoDisplay", "menuId", "ariaLabel", "ariaLabelledBy", "level", "focusedItemId", "activeItemPath", "inlineStyles", "submenuiconTemplate"], outputs: ["itemClick", "itemMouseEnter", "menuFocus", "menuBlur", "menuKeydown"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i2.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "browserUrl", "routerLink"] }, { kind: "directive", type: i2.RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "directive", type: Ripple, selector: "[pRipple]" }, { kind: "ngmodule", type: TooltipModule }, { kind: "directive", type: i3.Tooltip, selector: "[pTooltip]", inputs: ["tooltipPosition", "tooltipEvent", "positionStyle", "tooltipStyleClass", "tooltipZIndex", "escape", "showDelay", "hideDelay", "life", "positionTop", "positionLeft", "autoHide", "fitContent", "hideOnEscape", "showOnEllipsis", "pTooltip", "tooltipDisabled", "tooltipOptions", "appendTo", "ptTooltip", "pTooltipPT", "pTooltipUnstyled"] }, { kind: "directive", type: i4.Bind, selector: "[pBind]", inputs: ["pBind"] }, { kind: "component", type: AngleDownIcon, selector: "[data-p-icon=\"angle-down\"]" }, { kind: "component", type: AngleRightIcon, selector: "[data-p-icon=\"angle-right\"]" }, { kind: "ngmodule", type: BadgeModule }, { kind: "component", type: i5.Badge, selector: "p-badge", inputs: ["styleClass", "badgeSize", "size", "severity", "value", "badgeDisabled"] }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: BindModule }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MenubarSub, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-menubarSub, p-menubarsub, [pMenubarSub]',
                    standalone: true,
                    imports: [CommonModule, RouterModule, Ripple, TooltipModule, AngleDownIcon, AngleRightIcon, BadgeModule, SharedModule, BindModule],
                    template: `
        @for (processedItem of items(); track processedItem; let index = $index) {
            @if (isItemVisible(processedItem) && getItemProp(processedItem, 'separator')) {
                <li [attr.id]="getItemId(processedItem)" [style]="getItemProp(processedItem, 'style')" [class]="cn(cx('separator'), processedItem?.styleClass)" role="separator" [pBind]="ptm('separator')"></li>
            }
            @if (isItemVisible(processedItem) && !getItemProp(processedItem, 'separator')) {
                <li
                    #listItem
                    role="menuitem"
                    [attr.id]="getItemId(processedItem)"
                    [attr.data-p-highlight]="isItemActive(processedItem)"
                    [attr.data-p-focused]="isItemFocused(processedItem)"
                    [attr.data-p-disabled]="isItemDisabled(processedItem)"
                    [attr.aria-label]="getItemLabel(processedItem)"
                    [attr.aria-disabled]="isItemDisabled(processedItem) || undefined"
                    [attr.aria-haspopup]="isItemGroup(processedItem) && !getItemProp(processedItem, 'to') ? 'menu' : undefined"
                    [attr.aria-expanded]="isItemGroup(processedItem) ? isItemActive(processedItem) : undefined"
                    [attr.aria-setsize]="getAriaSetSize()"
                    [attr.aria-posinset]="getAriaPosInset(index)"
                    [style]="getItemProp(processedItem, 'style')"
                    [class]="cn(cx('item', { instance: this, processedItem }), getItemProp(processedItem, 'styleClass'))"
                    [pBind]="getPTOptions(processedItem, index, 'item')"
                    pTooltip
                    [tooltipOptions]="getItemProp(processedItem, 'tooltipOptions')"
                    [pTooltipUnstyled]="unstyled()"
                >
                    <div [class]="cx('itemContent')" [pBind]="getPTOptions(processedItem, index, 'itemContent')" (click)="onItemClick($event, processedItem)" (mouseenter)="onItemMouseEnter({ $event, processedItem })">
                        @if (!itemTemplate()) {
                            @if (!getItemProp(processedItem, 'routerLink')) {
                                <a
                                    [attr.href]="getItemProp(processedItem, 'url')"
                                    [attr.data-automationid]="getItemProp(processedItem, 'automationId')"
                                    [attr.title]="getItemProp(processedItem, 'title')"
                                    [attr.target]="getItemProp(processedItem, 'target')"
                                    [class]="cn(cx('itemLink'), getItemProp(processedItem, 'linkClass'))"
                                    [ngStyle]="getItemProp(processedItem, 'linkStyle')"
                                    [attr.tabindex]="-1"
                                    [pBind]="getPTOptions(processedItem, index, 'itemLink')"
                                    pRipple
                                >
                                    @if (getItemProp(processedItem, 'icon')) {
                                        <span
                                            [class]="cn(cx('itemIcon'), getItemProp(processedItem, 'icon'), getItemProp(processedItem, 'iconClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                            [attr.tabindex]="-1"
                                            [pBind]="getPTOptions(processedItem, index, 'itemIcon')"
                                        >
                                        </span>
                                    }
                                    @if (getItemProp(processedItem, 'escape')) {
                                        <span
                                            [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'labelStyle')"
                                            [id]="getItemLabelId(processedItem)"
                                            [pBind]="getPTOptions(processedItem, index, 'itemLabel')"
                                        >
                                            {{ getItemLabel(processedItem) }}
                                        </span>
                                    } @else {
                                        <span
                                            [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'labelStyle')"
                                            [innerHTML]="getItemLabel(processedItem)"
                                            [id]="getItemLabelId(processedItem)"
                                            [pBind]="getPTOptions(processedItem, index, 'itemLabel')"
                                        ></span>
                                    }
                                    @if (getItemProp(processedItem, 'badge')) {
                                        <p-badge [class]="getItemProp(processedItem, 'badgeStyleClass')" [value]="getItemProp(processedItem, 'badge')" [pt]="getPTOptions(processedItem, index, 'pcBadge')" [unstyled]="unstyled()" />
                                    }
                                    @if (isItemGroup(processedItem)) {
                                        @if (!submenuiconTemplate()) {
                                            @if (root()) {
                                                <svg data-p-icon="angle-down" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" />
                                            }
                                            @if (!root()) {
                                                <svg data-p-icon="angle-right" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" />
                                            }
                                        }
                                        <ng-template *ngTemplateOutlet="submenuiconTemplate()"></ng-template>
                                    }
                                </a>
                            }
                            @if (getItemProp(processedItem, 'routerLink')) {
                                <a
                                    [routerLink]="getItemProp(processedItem, 'routerLink')"
                                    [attr.data-automationid]="getItemProp(processedItem, 'automationId')"
                                    [attr.title]="getItemProp(processedItem, 'title')"
                                    [attr.tabindex]="-1"
                                    [queryParams]="getItemProp(processedItem, 'queryParams')"
                                    [routerLinkActive]="'p-menubar-item-link-active'"
                                    [routerLinkActiveOptions]="getItemProp(processedItem, 'routerLinkActiveOptions') || { exact: false }"
                                    [target]="getItemProp(processedItem, 'target')"
                                    [class]="cn(cx('itemLink'), getItemProp(processedItem, 'linkClass'))"
                                    [ngStyle]="getItemProp(processedItem, 'linkStyle')"
                                    [fragment]="getItemProp(processedItem, 'fragment')"
                                    [queryParamsHandling]="getItemProp(processedItem, 'queryParamsHandling')"
                                    [preserveFragment]="getItemProp(processedItem, 'preserveFragment')"
                                    [skipLocationChange]="getItemProp(processedItem, 'skipLocationChange')"
                                    [replaceUrl]="getItemProp(processedItem, 'replaceUrl')"
                                    [state]="getItemProp(processedItem, 'state')"
                                    [pBind]="getPTOptions(processedItem, index, 'itemLink')"
                                    pRipple
                                >
                                    @if (getItemProp(processedItem, 'icon')) {
                                        <span
                                            [class]="cn(cx('itemIcon'), getItemProp(processedItem, 'icon'), getItemProp(processedItem, 'iconClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                            [attr.tabindex]="-1"
                                            [pBind]="getPTOptions(processedItem, index, 'itemIcon')"
                                        ></span>
                                    }
                                    @if (getItemProp(processedItem, 'escape')) {
                                        <span [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))" [ngStyle]="getItemProp(processedItem, 'labelStyle')" [pBind]="getPTOptions(processedItem, index, 'itemLabel')">{{
                                            getItemLabel(processedItem)
                                        }}</span>
                                    } @else {
                                        <span
                                            [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'labelStyle')"
                                            [innerHTML]="getItemLabel(processedItem)"
                                            [pBind]="getPTOptions(processedItem, index, 'itemLabel')"
                                        ></span>
                                    }
                                    @if (getItemProp(processedItem, 'badge')) {
                                        <p-badge [class]="getItemProp(processedItem, 'badgeStyleClass')" [value]="getItemProp(processedItem, 'badge')" [pt]="getPTOptions(processedItem, index, 'pcBadge')" [unstyled]="unstyled()" />
                                    }
                                    @if (isItemGroup(processedItem)) {
                                        @if (!submenuiconTemplate()) {
                                            @if (root()) {
                                                <svg data-p-icon="angle-down" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" />
                                            }
                                            @if (!root()) {
                                                <svg data-p-icon="angle-right" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" />
                                            }
                                        }
                                        <ng-template *ngTemplateOutlet="submenuiconTemplate()"></ng-template>
                                    }
                                </a>
                            }
                        }
                        @if (itemTemplate()) {
                            <ng-template *ngTemplateOutlet="itemTemplate(); context: { $implicit: processedItem.item, root: root() }"></ng-template>
                        }
                    </div>
                    @if (isItemVisible(processedItem) && isItemGroup(processedItem)) {
                        <ul
                            pMenubarSub
                            [itemTemplate]="itemTemplate()"
                            [items]="processedItem.items"
                            [mobileActive]="mobileActive()"
                            [autoDisplay]="autoDisplay()"
                            [menuId]="menuId()"
                            [activeItemPath]="activeItemPath()"
                            [focusedItemId]="focusedItemId()"
                            [level]="level() + 1"
                            [attr.aria-labelledby]="getItemLabelId(processedItem)"
                            (itemClick)="itemClick.emit($event)"
                            (itemMouseEnter)="onItemMouseEnter($event)"
                            [inlineStyles]="sx('submenu', true, { instance: this, processedItem })"
                            [pt]="pt()"
                            [pBind]="ptm('submenu')"
                            [unstyled]="unstyled()"
                        ></ul>
                    }
                </li>
            }
        }
    `,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[attr.id]': 'root() ? menuId() : null',
                        '[attr.aria-activedescendant]': 'focusedItemId()',
                        '[class]': "level() === 0 ? cx('rootList') : cx('submenu')",
                        '[attr.role]': "'menubar'",
                        '[style]': 'inlineStyles()'
                    }
                }]
        }], propDecorators: { items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }], itemTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemTemplate", required: false }] }], root: [{ type: i0.Input, args: [{ isSignal: true, alias: "root", required: false }] }], autoZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoZIndex", required: false }] }], baseZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "baseZIndex", required: false }] }], mobileActive: [{ type: i0.Input, args: [{ isSignal: true, alias: "mobileActive", required: false }] }], autoDisplay: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoDisplay", required: false }] }], menuId: [{ type: i0.Input, args: [{ isSignal: true, alias: "menuId", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], level: [{ type: i0.Input, args: [{ isSignal: true, alias: "level", required: false }] }], focusedItemId: [{ type: i0.Input, args: [{ isSignal: true, alias: "focusedItemId", required: false }] }], activeItemPath: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeItemPath", required: false }] }], inlineStyles: [{ type: i0.Input, args: [{ isSignal: true, alias: "inlineStyles", required: false }] }], submenuiconTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "submenuiconTemplate", required: false }] }], itemClick: [{ type: i0.Output, args: ["itemClick"] }], itemMouseEnter: [{ type: i0.Output, args: ["itemMouseEnter"] }], menuFocus: [{ type: i0.Output, args: ["menuFocus"] }], menuBlur: [{ type: i0.Output, args: ["menuBlur"] }], menuKeydown: [{ type: i0.Output, args: ["menuKeydown"] }] } });
/**
 * Menubar is a horizontal menu component.
 * @group Components
 */
class Menubar extends BaseComponent {
    document = inject(DOCUMENT);
    platformId = inject(PLATFORM_ID);
    el = inject(ElementRef);
    renderer = inject(Renderer2);
    cd = inject(ChangeDetectorRef);
    menubarService = inject(MenubarService);
    componentName = 'Menubar';
    $pcMenubar = inject(MENUBAR_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    /**
     * An array of menuitems.
     * @group Props
     */
    model = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "model" }] : /* istanbul ignore next */ []));
    /**
     * Class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Whether to automatically manage layering.
     * @group Props
     */
    autoZIndex = input(true, { ...(ngDevMode ? { debugName: "autoZIndex" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Base zIndex value to use in layering.
     * @group Props
     */
    baseZIndex = input(0, { ...(ngDevMode ? { debugName: "baseZIndex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Whether to show a root submenu on mouse over.
     * @defaultValue true
     * @group Props
     */
    autoDisplay = input(true, { ...(ngDevMode ? { debugName: "autoDisplay" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to hide a root submenu when mouse leaves.
     * @group Props
     */
    autoHide = input(undefined, { ...(ngDevMode ? { debugName: "autoHide" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * The breakpoint to define the maximum width boundary.
     * @group Props
     */
    breakpoint = input('960px', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "breakpoint" }] : /* istanbul ignore next */ []));
    /**
     * Delay to hide the root submenu in milliseconds when mouse leaves.
     * @group Props
     */
    autoHideDelay = input(100, { ...(ngDevMode ? { debugName: "autoHideDelay" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Current id state as a string.
     * @group Props
     */
    id = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "id" }] : /* istanbul ignore next */ []));
    /**
     * Defines a string value that labels an interactive element.
     * @group Props
     */
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /**
     * Identifier of the underlying input element.
     * @group Props
     */
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    /**
     * Callback to execute when button is focused.
     * @param {FocusEvent} event - Focus event.
     * @group Emits
     */
    onFocus = output();
    /**
     * Callback to execute when button loses focus.
     * @param {FocusEvent} event - Focus event.
     * @group Emits
     */
    onBlur = output();
    menubutton = viewChild('menubutton', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "menubutton" }] : /* istanbul ignore next */ []));
    rootmenu;
    mobileActive;
    matchMediaListener;
    query;
    queryMatches = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "queryMatches" }] : /* istanbul ignore next */ []));
    outsideClickListener;
    resizeListener;
    mouseLeaveSubscriber;
    dirty = false;
    focused = false;
    activeItemPath = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeItemPath" }] : /* istanbul ignore next */ []));
    number = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "number" }] : /* istanbul ignore next */ []));
    focusedItemInfo = signal({ index: -1, level: 0, parentKey: '', item: null }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusedItemInfo" }] : /* istanbul ignore next */ []));
    searchValue = '';
    searchTimeout;
    _processedItems;
    _componentStyle = inject(MenuBarStyle);
    _generatedId;
    get resolvedId() {
        return this.id() || (this._generatedId ??= uuid('pn_id_'));
    }
    get visibleItems() {
        const processedItem = this.activeItemPath().find((p) => p.key === this.focusedItemInfo().parentKey);
        return processedItem ? processedItem.items : this.processedItems;
    }
    get processedItems() {
        if (!this._processedItems || !this._processedItems.length) {
            this._processedItems = this.createProcessedItems(this.model() || []);
        }
        return this._processedItems;
    }
    get focusedItemId() {
        const focusedItem = this.focusedItemInfo();
        return focusedItem.item && focusedItem.item?.id ? focusedItem.item.id : focusedItem.index !== -1 ? `${this.resolvedId}${isNotEmpty(focusedItem.parentKey) ? '_' + focusedItem.parentKey : ''}_${focusedItem.index}` : null;
    }
    constructor() {
        super();
        effect(() => {
            const path = this.activeItemPath();
            if (isNotEmpty(path)) {
                this.bindOutsideClickListener();
                this.bindResizeListener();
            }
            else {
                this.unbindOutsideClickListener();
                this.unbindResizeListener();
            }
        });
        effect(() => {
            this._processedItems = this.createProcessedItems(this.model() || []);
        });
    }
    onInit() {
        this.bindMatchMediaListener();
        this.menubarService.autoHide = this.autoHide();
        this.menubarService.autoHideDelay = this.autoHideDelay();
        this.mouseLeaveSubscriber = this.menubarService.mouseLeft$.subscribe(() => {
            this.hide();
        });
    }
    /**
     * Defines template option for start.
     * @group Templates
     */
    startTemplate;
    /**
     * Defines template option for end.
     * @group Templates
     */
    endTemplate;
    /**
     * Custom item template.
     * @param {MenubarItemTemplateContext} context - item context.
     * @see {@link MenubarItemTemplateContext}
     * @group Templates
     */
    itemTemplate = contentChild('item', { ...(ngDevMode ? { debugName: "itemTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Defines template option for menu icon.
     * @group Templates
     */
    menuIconTemplate = contentChild('menuicon', { ...(ngDevMode ? { debugName: "menuIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Defines template option for submenu icon.
     * @group Templates
     */
    submenuIconTemplate = contentChild('submenuicon', { ...(ngDevMode ? { debugName: "submenuIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    _startTemplate;
    _endTemplate;
    _itemTemplate;
    _menuIconTemplate;
    _submenuIconTemplate;
    onAfterContentInit() {
        this.templates()?.forEach((item) => {
            switch (item.getType()) {
                case 'start':
                    this._startTemplate = item.template;
                    break;
                case 'end':
                    this._endTemplate = item.template;
                    break;
                case 'menuicon':
                    this._menuIconTemplate = item.template;
                    break;
                case 'submenuicon':
                    this._submenuIconTemplate = item.template;
                    break;
                case 'item':
                    this._itemTemplate = item.template;
                    break;
                default:
                    this._itemTemplate = item.template;
                    break;
            }
        });
    }
    createProcessedItems(items, level = 0, parent = {}, parentKey = '') {
        const processedItems = [];
        items &&
            items.forEach((item, index) => {
                const key = (parentKey !== '' ? parentKey + '_' : '') + index;
                const newItem = {
                    item,
                    index,
                    level,
                    key,
                    parent,
                    parentKey
                };
                newItem['items'] = this.createProcessedItems(item.items, level + 1, newItem, key);
                processedItems.push(newItem);
            });
        return processedItems;
    }
    bindMatchMediaListener() {
        if (isPlatformBrowser(this.platformId)) {
            if (!this.matchMediaListener) {
                const query = window.matchMedia(`(max-width: ${this.breakpoint()})`);
                this.query = query;
                this.queryMatches.set(query.matches);
                this.matchMediaListener = () => {
                    this.queryMatches.set(query.matches);
                    this.mobileActive = false;
                    this.cd.markForCheck();
                };
                query.addEventListener('change', this.matchMediaListener);
            }
        }
    }
    unbindMatchMediaListener() {
        if (this.matchMediaListener) {
            this.query.removeEventListener('change', this.matchMediaListener);
            this.matchMediaListener = null;
        }
    }
    getItemProp(item, name) {
        return item ? resolve(item[name]) : undefined;
    }
    menuButtonClick(event) {
        this.toggle(event);
    }
    menuButtonKeydown(event) {
        (event.code === 'Enter' || event.code === 'Space') && this.menuButtonClick(event);
    }
    onItemClick(event) {
        this.dirty = true;
        const { originalEvent, processedItem } = event;
        const grouped = this.isProcessedItemGroup(processedItem);
        const root = isEmpty(processedItem.parent);
        const selected = this.isSelected(processedItem);
        if (selected) {
            const { index, key, level, parentKey, item } = processedItem;
            this.activeItemPath.set(this.activeItemPath().filter((p) => key !== p.key && key.startsWith(p.key)));
            this.focusedItemInfo.set({ index, level, parentKey, item });
            this.dirty = !root;
            focus(this.rootmenu?.el.nativeElement);
        }
        else {
            if (grouped) {
                this.onItemChange(event);
            }
            else {
                const rootProcessedItem = root ? processedItem : this.activeItemPath().find((p) => p.parentKey === '');
                this.hide(originalEvent);
                this.changeFocusedItemIndex(originalEvent, rootProcessedItem ? rootProcessedItem.index : -1);
                this.mobileActive = false;
                focus(this.rootmenu?.el.nativeElement);
            }
        }
    }
    onItemMouseEnter(event) {
        if (!isTouchDevice()) {
            if (this.dirty) {
                this.onItemChange(event, 'hover');
            }
        }
        else {
            this.onItemChange({ event, processedItem: event.processedItem, focus: this.autoDisplay }, 'hover');
        }
    }
    onMouseLeave() {
        const autoHideEnabled = this.menubarService.autoHide;
        const autoHideDelay = this.menubarService.autoHideDelay;
        if (autoHideEnabled) {
            setTimeout(() => {
                this.menubarService.mouseLeaves.next(true);
            }, autoHideDelay);
        }
    }
    changeFocusedItemIndex(event, index) {
        const processedItem = this.findVisibleItem(index);
        if (this.focusedItemInfo().index !== index) {
            const focusedItemInfo = this.focusedItemInfo();
            this.focusedItemInfo.set({ ...focusedItemInfo, item: processedItem.item, index });
            this.scrollInView();
        }
    }
    scrollInView(index = -1) {
        const id = index !== -1 ? `${this.resolvedId}_${index}` : this.focusedItemId;
        const element = findSingle(this.rootmenu?.el.nativeElement, `li[id="${id}"]`);
        if (element) {
            element.scrollIntoView && element.scrollIntoView({ block: 'nearest', inline: 'nearest' });
        }
    }
    onItemChange(event, type) {
        const { processedItem, isFocus } = event;
        if (isEmpty(processedItem))
            return;
        const { index, key, level, parentKey, items, item } = processedItem;
        const grouped = isNotEmpty(items);
        const activeItemPath = this.activeItemPath().filter((p) => p.parentKey !== parentKey && p.parentKey !== key);
        grouped && activeItemPath.push(processedItem);
        this.focusedItemInfo.set({ index, level, parentKey, item });
        grouped && (this.dirty = true);
        isFocus && focus(this.rootmenu?.el.nativeElement);
        if (type === 'hover' && this.queryMatches()) {
            return;
        }
        this.activeItemPath.set(activeItemPath);
    }
    toggle(event) {
        if (this.mobileActive) {
            this.mobileActive = false;
            ZIndexUtils.clear(this.rootmenu?.el.nativeElement);
            this.hide();
        }
        else {
            this.mobileActive = true;
            ZIndexUtils.set('menu', this.rootmenu?.el.nativeElement, this.config.zIndex.menu);
            setTimeout(() => {
                this.show();
            }, 0);
        }
        this.bindOutsideClickListener();
        event.preventDefault();
    }
    hide(event, isFocus) {
        if (this.mobileActive) {
            setTimeout(() => {
                focus(this.menubutton()?.nativeElement);
            }, 0);
        }
        this.activeItemPath.set([]);
        this.focusedItemInfo.set({ index: -1, level: 0, parentKey: '', item: null });
        isFocus && focus(this.rootmenu?.el.nativeElement);
        this.dirty = false;
    }
    show() {
        const processedItem = this.findVisibleItem(this.findFirstFocusedItemIndex());
        this.focusedItemInfo.set({ index: this.findFirstFocusedItemIndex(), level: 0, parentKey: '', item: processedItem?.item });
        focus(this.rootmenu?.el.nativeElement);
    }
    onMenuMouseDown() {
        this.dirty = true;
    }
    onMenuFocus(event) {
        this.focused = true;
        const relatedTarget = event.relatedTarget;
        const isFromOutside = !relatedTarget || !this.el.nativeElement.contains(relatedTarget);
        if (isFromOutside && this.focusedItemInfo().index === -1 && !this.activeItemPath().length && !this.dirty) {
            const processedItem = this.findVisibleItem(this.findFirstFocusedItemIndex());
            this.focusedItemInfo.set({ index: this.findFirstFocusedItemIndex(), level: 0, parentKey: '', item: processedItem?.item });
        }
        this.onFocus.emit(event);
    }
    onMenuBlur(event) {
        const relatedTarget = event.relatedTarget;
        if (relatedTarget && this.el.nativeElement.contains(relatedTarget)) {
            return;
        }
        setTimeout(() => {
            const activeElement = this.document.activeElement;
            if (activeElement && this.el.nativeElement.contains(activeElement)) {
                return;
            }
            this.focused = false;
            this.focusedItemInfo.set({ index: -1, level: 0, parentKey: '', item: null });
            this.searchValue = '';
            this.dirty = false;
            this.onBlur.emit(event);
        });
    }
    onKeyDown(event) {
        const metaKey = event.metaKey || event.ctrlKey;
        switch (event.code) {
            case 'ArrowDown':
                this.onArrowDownKey(event);
                break;
            case 'ArrowUp':
                this.onArrowUpKey(event);
                break;
            case 'ArrowLeft':
                this.onArrowLeftKey(event);
                break;
            case 'ArrowRight':
                this.onArrowRightKey(event);
                break;
            case 'Home':
                this.onHomeKey(event);
                break;
            case 'End':
                this.onEndKey(event);
                break;
            case 'Space':
                this.onSpaceKey(event);
                break;
            case 'Enter':
                this.onEnterKey(event);
                break;
            case 'Escape':
                this.onEscapeKey(event);
                break;
            case 'Tab':
                this.onTabKey(event);
                break;
            case 'PageDown':
            case 'PageUp':
            case 'Backspace':
            case 'ShiftLeft':
            case 'ShiftRight':
                //NOOP
                break;
            default:
                if (!metaKey && isPrintableCharacter(event.key)) {
                    this.searchItems(event, event.key);
                }
                break;
        }
    }
    findVisibleItem(index) {
        return isNotEmpty(this.visibleItems) ? this.visibleItems[index] : null;
    }
    findFirstFocusedItemIndex() {
        const selectedIndex = this.findSelectedItemIndex();
        return selectedIndex < 0 ? this.findFirstItemIndex() : selectedIndex;
    }
    findFirstItemIndex() {
        return this.visibleItems.findIndex((processedItem) => this.isValidItem(processedItem));
    }
    findSelectedItemIndex() {
        return this.visibleItems.findIndex((processedItem) => this.isValidSelectedItem(processedItem));
    }
    isProcessedItemGroup(processedItem) {
        return processedItem && isNotEmpty(processedItem.items);
    }
    isSelected(processedItem) {
        return this.activeItemPath().some((p) => p.key === processedItem.key);
    }
    isValidSelectedItem(processedItem) {
        return this.isValidItem(processedItem) && this.isSelected(processedItem);
    }
    isValidItem(processedItem) {
        return !!processedItem && !this.isItemDisabled(processedItem.item) && !this.isItemSeparator(processedItem.item);
    }
    isItemDisabled(item) {
        return this.getItemProp(item, 'disabled');
    }
    isItemSeparator(item) {
        return this.getItemProp(item, 'separator');
    }
    isItemMatched(processedItem) {
        return this.isValidItem(processedItem) && this.getProccessedItemLabel(processedItem).toLocaleLowerCase().startsWith(this.searchValue.toLocaleLowerCase());
    }
    isProccessedItemGroup(processedItem) {
        return processedItem && isNotEmpty(processedItem.items);
    }
    searchItems(event, char) {
        this.searchValue = (this.searchValue || '') + char;
        let itemIndex = -1;
        let matched = false;
        if (this.focusedItemInfo().index !== -1) {
            itemIndex = this.visibleItems.slice(this.focusedItemInfo().index).findIndex((processedItem) => this.isItemMatched(processedItem));
            itemIndex = itemIndex === -1 ? this.visibleItems.slice(0, this.focusedItemInfo().index).findIndex((processedItem) => this.isItemMatched(processedItem)) : itemIndex + this.focusedItemInfo().index;
        }
        else {
            itemIndex = this.visibleItems.findIndex((processedItem) => this.isItemMatched(processedItem));
        }
        if (itemIndex !== -1) {
            matched = true;
        }
        if (itemIndex === -1 && this.focusedItemInfo().index === -1) {
            itemIndex = this.findFirstFocusedItemIndex();
        }
        if (itemIndex !== -1) {
            this.changeFocusedItemIndex(event, itemIndex);
        }
        if (this.searchTimeout) {
            clearTimeout(this.searchTimeout);
        }
        this.searchTimeout = setTimeout(() => {
            this.searchValue = '';
            this.searchTimeout = null;
        }, 500);
        return matched;
    }
    getProccessedItemLabel(processedItem) {
        return processedItem ? this.getItemLabel(processedItem.item) : undefined;
    }
    getItemLabel(item) {
        return this.getItemProp(item, 'label');
    }
    onArrowDownKey(event) {
        const processedItem = this.visibleItems[this.focusedItemInfo().index];
        const root = processedItem ? isEmpty(processedItem.parent) : null;
        if (root) {
            const grouped = this.isProccessedItemGroup(processedItem);
            if (grouped) {
                this.onItemChange({ originalEvent: event, processedItem });
                this.focusedItemInfo.set({ index: -1, parentKey: processedItem.key, item: processedItem.item });
                this.onArrowRightKey(event);
            }
        }
        else {
            const itemIndex = this.focusedItemInfo().index !== -1 ? this.findNextItemIndex(this.focusedItemInfo().index) : this.findFirstFocusedItemIndex();
            this.changeFocusedItemIndex(event, itemIndex);
            event.preventDefault();
        }
    }
    onArrowRightKey(event) {
        const processedItem = this.visibleItems[this.focusedItemInfo().index];
        const parentItem = processedItem ? this.activeItemPath().find((p) => p.key === processedItem.parentKey) : null;
        if (parentItem) {
            const grouped = this.isProccessedItemGroup(processedItem);
            if (grouped) {
                this.onItemChange({ originalEvent: event, processedItem });
                this.focusedItemInfo.set({ index: -1, parentKey: processedItem.key, item: processedItem.item });
                this.onArrowDownKey(event);
            }
        }
        else {
            const itemIndex = this.focusedItemInfo().index !== -1 ? this.findNextItemIndex(this.focusedItemInfo().index) : this.findFirstFocusedItemIndex();
            this.changeFocusedItemIndex(event, itemIndex);
            event.preventDefault();
        }
    }
    onArrowUpKey(event) {
        const processedItem = this.visibleItems[this.focusedItemInfo().index];
        const root = isEmpty(processedItem.parent);
        if (root) {
            const grouped = this.isProccessedItemGroup(processedItem);
            if (grouped) {
                this.onItemChange({ originalEvent: event, processedItem });
                this.focusedItemInfo.set({ index: -1, parentKey: processedItem.key, item: processedItem.item });
                const itemIndex = this.findLastItemIndex();
                this.changeFocusedItemIndex(event, itemIndex);
            }
        }
        else {
            const parentItem = this.activeItemPath().find((p) => p.key === processedItem.parentKey);
            if (this.focusedItemInfo().index === 0) {
                this.focusedItemInfo.set({ index: -1, parentKey: parentItem ? parentItem.parentKey : '', item: processedItem.item });
                this.searchValue = '';
                this.onArrowLeftKey(event);
                const activeItemPath = this.activeItemPath().filter((p) => p.parentKey !== this.focusedItemInfo().parentKey);
                this.activeItemPath.set(activeItemPath);
            }
            else {
                const itemIndex = this.focusedItemInfo().index !== -1 ? this.findPrevItemIndex(this.focusedItemInfo().index) : this.findLastFocusedItemIndex();
                this.changeFocusedItemIndex(event, itemIndex);
            }
        }
        event.preventDefault();
    }
    onArrowLeftKey(event) {
        const processedItem = this.visibleItems[this.focusedItemInfo().index];
        const parentItem = processedItem ? this.activeItemPath().find((p) => p.key === processedItem.parentKey) : null;
        if (parentItem) {
            this.onItemChange({ originalEvent: event, processedItem: parentItem });
            const activeItemPath = this.activeItemPath().filter((p) => p.parentKey !== this.focusedItemInfo().parentKey);
            this.activeItemPath.set(activeItemPath);
            event.preventDefault();
        }
        else {
            const itemIndex = this.focusedItemInfo().index !== -1 ? this.findPrevItemIndex(this.focusedItemInfo().index) : this.findLastFocusedItemIndex();
            this.changeFocusedItemIndex(event, itemIndex);
            event.preventDefault();
        }
    }
    onHomeKey(event) {
        this.changeFocusedItemIndex(event, this.findFirstItemIndex());
        event.preventDefault();
    }
    onEndKey(event) {
        this.changeFocusedItemIndex(event, this.findLastItemIndex());
        event.preventDefault();
    }
    onSpaceKey(event) {
        this.onEnterKey(event);
    }
    onEscapeKey(event) {
        this.hide(event, true);
        this.focusedItemInfo().index = this.findFirstFocusedItemIndex();
        event.preventDefault();
    }
    onTabKey(event) {
        if (this.focusedItemInfo().index !== -1) {
            const processedItem = this.visibleItems[this.focusedItemInfo().index];
            const grouped = this.isProccessedItemGroup(processedItem);
            !grouped && this.onItemChange({ originalEvent: event, processedItem });
        }
        this.hide();
    }
    onEnterKey(event) {
        if (this.focusedItemInfo().index !== -1) {
            const element = findSingle(this.rootmenu?.el.nativeElement, `li[id="${`${this.focusedItemId}`}"]`);
            const anchorElement = element && (findSingle(element, '[data-pc-section="itemlink"]') || findSingle(element, 'a,button'));
            anchorElement ? anchorElement.click() : element && element.click();
        }
        event.preventDefault();
    }
    findLastFocusedItemIndex() {
        const selectedIndex = this.findSelectedItemIndex();
        return selectedIndex < 0 ? this.findLastItemIndex() : selectedIndex;
    }
    findLastItemIndex() {
        return findLastIndex(this.visibleItems, (processedItem) => this.isValidItem(processedItem));
    }
    findPrevItemIndex(index) {
        const matchedItemIndex = index > 0 ? findLastIndex(this.visibleItems.slice(0, index), (processedItem) => this.isValidItem(processedItem)) : -1;
        return matchedItemIndex > -1 ? matchedItemIndex : index;
    }
    findNextItemIndex(index) {
        const matchedItemIndex = index < this.visibleItems.length - 1 ? this.visibleItems.slice(index + 1).findIndex((processedItem) => this.isValidItem(processedItem)) : -1;
        return matchedItemIndex > -1 ? matchedItemIndex + index + 1 : index;
    }
    bindResizeListener() {
        if (isPlatformBrowser(this.platformId)) {
            if (!this.resizeListener) {
                this.resizeListener = this.renderer.listen(this.document.defaultView, 'resize', (event) => {
                    if (!isTouchDevice()) {
                        this.hide(event, true);
                    }
                    this.mobileActive = false;
                });
            }
        }
    }
    bindOutsideClickListener() {
        if (isPlatformBrowser(this.platformId)) {
            if (!this.outsideClickListener) {
                this.outsideClickListener = this.renderer.listen(this.document, 'click', (event) => {
                    const isOutsideContainer = this.rootmenu?.el.nativeElement !== event.target && !this.rootmenu?.el.nativeElement?.contains(event.target);
                    const menubutton = this.menubutton();
                    const isOutsideMenuButton = this.mobileActive && menubutton?.nativeElement !== event.target && !menubutton?.nativeElement?.contains(event.target);
                    if (isOutsideContainer) {
                        isOutsideMenuButton ? (this.mobileActive = false) : this.hide();
                    }
                });
            }
        }
    }
    unbindOutsideClickListener() {
        if (this.outsideClickListener) {
            this.outsideClickListener();
            this.outsideClickListener = null;
        }
    }
    unbindResizeListener() {
        if (this.resizeListener) {
            this.resizeListener();
            this.resizeListener = null;
        }
    }
    onDestroy() {
        this.mouseLeaveSubscriber?.unsubscribe();
        this.unbindOutsideClickListener();
        this.unbindResizeListener();
        this.unbindMatchMediaListener();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Menubar, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: Menubar, isStandalone: true, selector: "p-menubar", inputs: { model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, autoZIndex: { classPropertyName: "autoZIndex", publicName: "autoZIndex", isSignal: true, isRequired: false, transformFunction: null }, baseZIndex: { classPropertyName: "baseZIndex", publicName: "baseZIndex", isSignal: true, isRequired: false, transformFunction: null }, autoDisplay: { classPropertyName: "autoDisplay", publicName: "autoDisplay", isSignal: true, isRequired: false, transformFunction: null }, autoHide: { classPropertyName: "autoHide", publicName: "autoHide", isSignal: true, isRequired: false, transformFunction: null }, breakpoint: { classPropertyName: "breakpoint", publicName: "breakpoint", isSignal: true, isRequired: false, transformFunction: null }, autoHideDelay: { classPropertyName: "autoHideDelay", publicName: "autoHideDelay", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onFocus: "onFocus", onBlur: "onBlur" }, host: { properties: { "class": "cn(cx(\"root\"), styleClass())" } }, providers: [MenubarService, MenuBarStyle, { provide: MENUBAR_INSTANCE, useExisting: Menubar }, { provide: PARENT_INSTANCE, useExisting: Menubar }], queries: [{ propertyName: "itemTemplate", first: true, predicate: ["item"], isSignal: true }, { propertyName: "menuIconTemplate", first: true, predicate: ["menuicon"], isSignal: true }, { propertyName: "submenuIconTemplate", first: true, predicate: ["submenuicon"], isSignal: true }, { propertyName: "templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "startTemplate", first: true, predicate: ["start"] }, { propertyName: "endTemplate", first: true, predicate: ["end"] }], viewQueries: [{ propertyName: "menubutton", first: true, predicate: ["menubutton"], descendants: true, isSignal: true }, { propertyName: "rootmenu", first: true, predicate: ["rootmenu"], descendants: true }], usesInheritance: true, hostDirectives: [{ directive: i4.Bind }], ngImport: i0, template: `
        @if (startTemplate || _startTemplate) {
            <div [class]="cx('start')" [pBind]="ptm('start')">
                <ng-container *ngTemplateOutlet="startTemplate || _startTemplate"></ng-container>
            </div>
        }
        @if (model() && model()!.length > 0) {
            <a
                #menubutton
                tabindex="0"
                role="button"
                [attr.aria-haspopup]="model()!.length && model()!.length > 0 ? true : false"
                [attr.aria-expanded]="mobileActive"
                [attr.aria-controls]="resolvedId"
                [attr.aria-label]="config.translation.aria.navigation"
                [class]="cx('button')"
                [pBind]="ptm('button')"
                (click)="menuButtonClick($event)"
                (keydown)="menuButtonKeydown($event)"
            >
                @if (!menuIconTemplate() && !_menuIconTemplate) {
                    <svg data-p-icon="bars" [pBind]="ptm('buttonIcon')" />
                }
                <ng-template *ngTemplateOutlet="menuIconTemplate() || _menuIconTemplate"></ng-template>
            </a>
        }
        <ul
            pMenubarSub
            #rootmenu
            [items]="processedItems"
            [itemTemplate]="itemTemplate()"
            tabindex="0"
            [menuId]="resolvedId"
            [root]="true"
            [baseZIndex]="baseZIndex()"
            [autoZIndex]="autoZIndex()"
            [mobileActive]="mobileActive"
            [autoDisplay]="autoDisplay()"
            [attr.aria-label]="ariaLabel()"
            [attr.aria-labelledby]="ariaLabelledBy()"
            [focusedItemId]="focused ? focusedItemId : undefined"
            [submenuiconTemplate]="submenuIconTemplate() || _submenuIconTemplate"
            [activeItemPath]="activeItemPath()"
            (itemClick)="onItemClick($event)"
            (mousedown)="onMenuMouseDown()"
            (focus)="onMenuFocus($event)"
            (blur)="onMenuBlur($event)"
            (keydown)="onKeyDown($event)"
            (itemMouseEnter)="onItemMouseEnter($event)"
            (mouseleave)="onMouseLeave()"
            [pt]="pt()"
            [pBind]="ptm('rootList')"
            [unstyled]="unstyled()"
        ></ul>
        @if (endTemplate || _endTemplate) {
            <div [class]="cx('end')" [pBind]="ptm('end')">
                <ng-container *ngTemplateOutlet="endTemplate || _endTemplate"></ng-container>
            </div>
        } @else {
            <div [class]="cx('end')">
                <ng-content></ng-content>
            </div>
        }
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: RouterModule }, { kind: "component", type: MenubarSub, selector: "p-menubarSub, p-menubarsub, [pMenubarSub]", inputs: ["items", "itemTemplate", "root", "autoZIndex", "baseZIndex", "mobileActive", "autoDisplay", "menuId", "ariaLabel", "ariaLabelledBy", "level", "focusedItemId", "activeItemPath", "inlineStyles", "submenuiconTemplate"], outputs: ["itemClick", "itemMouseEnter", "menuFocus", "menuBlur", "menuKeydown"] }, { kind: "ngmodule", type: TooltipModule }, { kind: "directive", type: i4.Bind, selector: "[pBind]", inputs: ["pBind"] }, { kind: "component", type: BarsIcon, selector: "[data-p-icon=\"bars\"]" }, { kind: "ngmodule", type: BadgeModule }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: BindModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Menubar, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-menubar',
                    standalone: true,
                    imports: [CommonModule, RouterModule, MenubarSub, TooltipModule, BarsIcon, BadgeModule, SharedModule, BindModule],
                    template: `
        @if (startTemplate || _startTemplate) {
            <div [class]="cx('start')" [pBind]="ptm('start')">
                <ng-container *ngTemplateOutlet="startTemplate || _startTemplate"></ng-container>
            </div>
        }
        @if (model() && model()!.length > 0) {
            <a
                #menubutton
                tabindex="0"
                role="button"
                [attr.aria-haspopup]="model()!.length && model()!.length > 0 ? true : false"
                [attr.aria-expanded]="mobileActive"
                [attr.aria-controls]="resolvedId"
                [attr.aria-label]="config.translation.aria.navigation"
                [class]="cx('button')"
                [pBind]="ptm('button')"
                (click)="menuButtonClick($event)"
                (keydown)="menuButtonKeydown($event)"
            >
                @if (!menuIconTemplate() && !_menuIconTemplate) {
                    <svg data-p-icon="bars" [pBind]="ptm('buttonIcon')" />
                }
                <ng-template *ngTemplateOutlet="menuIconTemplate() || _menuIconTemplate"></ng-template>
            </a>
        }
        <ul
            pMenubarSub
            #rootmenu
            [items]="processedItems"
            [itemTemplate]="itemTemplate()"
            tabindex="0"
            [menuId]="resolvedId"
            [root]="true"
            [baseZIndex]="baseZIndex()"
            [autoZIndex]="autoZIndex()"
            [mobileActive]="mobileActive"
            [autoDisplay]="autoDisplay()"
            [attr.aria-label]="ariaLabel()"
            [attr.aria-labelledby]="ariaLabelledBy()"
            [focusedItemId]="focused ? focusedItemId : undefined"
            [submenuiconTemplate]="submenuIconTemplate() || _submenuIconTemplate"
            [activeItemPath]="activeItemPath()"
            (itemClick)="onItemClick($event)"
            (mousedown)="onMenuMouseDown()"
            (focus)="onMenuFocus($event)"
            (blur)="onMenuBlur($event)"
            (keydown)="onKeyDown($event)"
            (itemMouseEnter)="onItemMouseEnter($event)"
            (mouseleave)="onMouseLeave()"
            [pt]="pt()"
            [pBind]="ptm('rootList')"
            [unstyled]="unstyled()"
        ></ul>
        @if (endTemplate || _endTemplate) {
            <div [class]="cx('end')" [pBind]="ptm('end')">
                <ng-container *ngTemplateOutlet="endTemplate || _endTemplate"></ng-container>
            </div>
        } @else {
            <div [class]="cx('end')">
                <ng-content></ng-content>
            </div>
        }
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [MenubarService, MenuBarStyle, { provide: MENUBAR_INSTANCE, useExisting: Menubar }, { provide: PARENT_INSTANCE, useExisting: Menubar }],
                    host: {
                        '[class]': 'cn(cx("root"), styleClass())'
                    },
                    hostDirectives: [Bind]
                }]
        }], ctorParameters: () => [], propDecorators: { model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], autoZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoZIndex", required: false }] }], baseZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "baseZIndex", required: false }] }], autoDisplay: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoDisplay", required: false }] }], autoHide: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoHide", required: false }] }], breakpoint: [{ type: i0.Input, args: [{ isSignal: true, alias: "breakpoint", required: false }] }], autoHideDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoHideDelay", required: false }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], menubutton: [{ type: i0.ViewChild, args: ['menubutton', { isSignal: true }] }], rootmenu: [{
                type: ViewChild,
                args: ['rootmenu']
            }], startTemplate: [{
                type: ContentChild,
                args: ['start', { descendants: false }]
            }], endTemplate: [{
                type: ContentChild,
                args: ['end', { descendants: false }]
            }], itemTemplate: [{ type: i0.ContentChild, args: ['item', { ...{ descendants: false }, isSignal: true }] }], menuIconTemplate: [{ type: i0.ContentChild, args: ['menuicon', { ...{ descendants: false }, isSignal: true }] }], submenuIconTemplate: [{ type: i0.ContentChild, args: ['submenuicon', { ...{ descendants: false }, isSignal: true }] }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class MenubarModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MenubarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: MenubarModule, imports: [Menubar, SharedModule], exports: [Menubar, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MenubarModule, imports: [Menubar, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MenubarModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [Menubar, SharedModule],
                    exports: [Menubar, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { MenuBarStyle, Menubar, MenubarClasses, MenubarModule, MenubarService, MenubarSub };
//# sourceMappingURL=wawjs-ngx-prime-menubar.mjs.map
