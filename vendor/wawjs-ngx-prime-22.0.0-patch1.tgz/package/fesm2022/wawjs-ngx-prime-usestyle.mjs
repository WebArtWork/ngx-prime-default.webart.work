import { DOCUMENT } from '@angular/common';
import * as i0 from '@angular/core';
import { inject, Service } from '@angular/core';
import { setAttribute, setAttributes } from '@wawjs/css-prime-utils';

let _id = 0;
class UseStyle {
    document = inject(DOCUMENT);
    use(css, options = {}) {
        let cssRef = css;
        let styleRef = null;
        const { name = `style_${++_id}`, id = undefined, media = undefined, nonce = undefined, first = false } = options;
        if (!this.document)
            return;
        styleRef = (this.document.querySelector(`style[data-ngx-prime-style-id="${name}"]`) || (id && this.document.getElementById(id)) || this.document.createElement('style'));
        if (styleRef) {
            if (!styleRef.isConnected) {
                cssRef = css;
                const HEAD = this.document.head;
                setAttribute(styleRef, 'nonce', nonce);
                first && HEAD.firstChild ? HEAD.insertBefore(styleRef, HEAD.firstChild) : HEAD.appendChild(styleRef);
                setAttributes(styleRef, {
                    type: 'text/css',
                    media,
                    nonce,
                    'data-ngx-prime-style-id': name
                });
            }
            if (styleRef.textContent !== cssRef) {
                styleRef.textContent = cssRef;
            }
        }
        return {
            id,
            name,
            el: styleRef,
            css: cssRef
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: UseStyle, deps: [], target: i0.ɵɵFactoryTarget.Service });
    static ɵprov = i0.ɵɵngDeclareService({ minVersion: "22.0.0", version: "22.1.2", ngImport: i0, type: UseStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: UseStyle, decorators: [{
            type: Service
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { UseStyle };
//# sourceMappingURL=wawjs-ngx-prime-usestyle.mjs.map
