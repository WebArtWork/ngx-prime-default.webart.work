import { DOCUMENT, isPlatformBrowser } from '@angular/common';
import * as i0 from '@angular/core';
import { input, inject, PLATFORM_ID, ElementRef, Directive, NgModule } from '@angular/core';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import { DomHandler } from '@wawjs/ngx-prime/dom';

/**
 * AutoFocus manages focus on focusable element on load.
 * @group Components
 */
class AutoFocus extends BaseComponent {
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus = input(false, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), alias: 'pAutoFocus' });
    focused = false;
    platformId = inject(PLATFORM_ID);
    document = inject(DOCUMENT);
    host = inject(ElementRef);
    onAfterContentChecked() {
        if (!this.focused) {
            this.autoFocus();
        }
    }
    onAfterViewChecked() {
        if (!this.focused) {
            this.autoFocus();
        }
    }
    autoFocus() {
        if (isPlatformBrowser(this.platformId) && this.autofocus()) {
            setTimeout(() => {
                const focusableElements = DomHandler.getFocusableElements(this.host?.nativeElement);
                if (focusableElements.length === 0) {
                    this.host.nativeElement.focus();
                }
                if (focusableElements.length > 0) {
                    focusableElements[0].focus();
                }
                this.focused = true;
            });
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AutoFocus, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: AutoFocus, isStandalone: true, selector: "[pAutoFocus]", inputs: { autofocus: { classPropertyName: "autofocus", publicName: "pAutoFocus", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.autofocus": "autofocus() ? 'true' : null" } }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AutoFocus, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pAutoFocus]',
                    standalone: true,
                    host: {
                        '[attr.autofocus]': "autofocus() ? 'true' : null"
                    }
                }]
        }], propDecorators: { autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "pAutoFocus", required: false }] }] } });
class AutoFocusModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AutoFocusModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: AutoFocusModule, imports: [AutoFocus], exports: [AutoFocus] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AutoFocusModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AutoFocusModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [AutoFocus],
                    exports: [AutoFocus]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { AutoFocus, AutoFocusModule };
//# sourceMappingURL=wawjs-ngx-prime-autofocus.mjs.map
