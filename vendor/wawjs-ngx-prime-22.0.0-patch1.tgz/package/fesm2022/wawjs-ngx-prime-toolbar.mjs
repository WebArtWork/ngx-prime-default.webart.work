export * from '@wawjs/ngx-prime/types/toolbar';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, input, contentChildren, ContentChild, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { PrimeTemplate, SharedModule } from '@wawjs/ngx-prime/api';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind, BindModule } from '@wawjs/ngx-prime/bind';
import { style } from '@wawjs/css-prime-styles/toolbar';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const classes = {
    root: () => ['p-toolbar p-component'],
    start: 'p-toolbar-start',
    center: 'p-toolbar-center',
    end: 'p-toolbar-end'
};
class ToolbarStyle extends BaseStyle {
    name = 'toolbar';
    style = style;
    classes = classes;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToolbarStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToolbarStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToolbarStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * Toolbar is a grouping component for buttons and other content.
 *
 * [Live Demo](https://www.ngx-prime.org/toolbar/)
 *
 * @module toolbarstyle
 *
 */
var ToolbarClasses;
(function (ToolbarClasses) {
    /**
     * Class name of the root element
     */
    ToolbarClasses["root"] = "p-toolbar";
    /**
     * Class name of the start element
     */
    ToolbarClasses["start"] = "p-toolbar-start";
    /**
     * Class name of the center element
     */
    ToolbarClasses["center"] = "p-toolbar-center";
    /**
     * Class name of the end element
     */
    ToolbarClasses["end"] = "p-toolbar-end";
})(ToolbarClasses || (ToolbarClasses = {}));

const TOOLBAR_INSTANCE = new InjectionToken('TOOLBAR_INSTANCE');
/**
 * Toolbar is a grouping component for buttons and other content.
 * @group Components
 */
class Toolbar extends BaseComponent {
    componentName = 'Toolbar';
    $pcToolbar = inject(TOOLBAR_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Defines a string value that labels an interactive element.
     * @group Props
     */
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    _componentStyle = inject(ToolbarStyle);
    getBlockableElement() {
        return this.el.nativeElement.children[0];
    }
    /**
     * Custom start template.
     * @group Templates
     */
    startTemplate;
    /**
     * Custom end template.
     * @group Templates
     */
    endTemplate;
    /**
     * Custom center template.
     * @group Templates
     */
    centerTemplate;
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    _startTemplate;
    _endTemplate;
    _centerTemplate;
    onAfterContentInit() {
        this.templates().forEach((item) => {
            switch (item.getType()) {
                case 'start':
                case 'left':
                    this._startTemplate = item.template;
                    break;
                case 'end':
                case 'right':
                    this._endTemplate = item.template;
                    break;
                case 'center':
                    this._centerTemplate = item.template;
                    break;
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Toolbar, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: Toolbar, isStandalone: true, selector: "p-toolbar", inputs: { styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "toolbar" }, properties: { "class": "cn(cx(\"root\"), styleClass())", "attr.aria-labelledby": "ariaLabelledBy()" } }, providers: [ToolbarStyle, { provide: TOOLBAR_INSTANCE, useExisting: Toolbar }, { provide: PARENT_INSTANCE, useExisting: Toolbar }], queries: [{ propertyName: "templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "startTemplate", first: true, predicate: ["start"] }, { propertyName: "endTemplate", first: true, predicate: ["end"] }, { propertyName: "centerTemplate", first: true, predicate: ["center"] }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        <ng-content></ng-content>
        @if (startTemplate || _startTemplate) {
            <div [class]="cx('start')" [pBind]="ptm('start')">
                <ng-container *ngTemplateOutlet="startTemplate || _startTemplate"></ng-container>
            </div>
        }
        @if (centerTemplate || _centerTemplate) {
            <div [class]="cx('center')" [pBind]="ptm('center')">
                <ng-container *ngTemplateOutlet="centerTemplate || _centerTemplate"></ng-container>
            </div>
        }
        @if (endTemplate || _endTemplate) {
            <div [class]="cx('end')" [pBind]="ptm('end')">
                <ng-container *ngTemplateOutlet="endTemplate || _endTemplate"></ng-container>
            </div>
        }
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: BindModule }, { kind: "directive", type: i1.Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Toolbar, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-toolbar',
                    standalone: true,
                    imports: [CommonModule, SharedModule, BindModule],
                    template: `
        <ng-content></ng-content>
        @if (startTemplate || _startTemplate) {
            <div [class]="cx('start')" [pBind]="ptm('start')">
                <ng-container *ngTemplateOutlet="startTemplate || _startTemplate"></ng-container>
            </div>
        }
        @if (centerTemplate || _centerTemplate) {
            <div [class]="cx('center')" [pBind]="ptm('center')">
                <ng-container *ngTemplateOutlet="centerTemplate || _centerTemplate"></ng-container>
            </div>
        }
        @if (endTemplate || _endTemplate) {
            <div [class]="cx('end')" [pBind]="ptm('end')">
                <ng-container *ngTemplateOutlet="endTemplate || _endTemplate"></ng-container>
            </div>
        }
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [ToolbarStyle, { provide: TOOLBAR_INSTANCE, useExisting: Toolbar }, { provide: PARENT_INSTANCE, useExisting: Toolbar }],
                    host: {
                        '[class]': 'cn(cx("root"), styleClass())',
                        role: 'toolbar',
                        '[attr.aria-labelledby]': 'ariaLabelledBy()'
                    },
                    hostDirectives: [Bind]
                }]
        }], propDecorators: { styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], startTemplate: [{
                type: ContentChild,
                args: ['start', { descendants: false }]
            }], endTemplate: [{
                type: ContentChild,
                args: ['end', { descendants: false }]
            }], centerTemplate: [{
                type: ContentChild,
                args: ['center', { descendants: false }]
            }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class ToolbarModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToolbarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: ToolbarModule, imports: [Toolbar, SharedModule, BindModule], exports: [Toolbar, SharedModule, BindModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToolbarModule, imports: [Toolbar, SharedModule, BindModule, SharedModule, BindModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToolbarModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [Toolbar, SharedModule, BindModule],
                    exports: [Toolbar, SharedModule, BindModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { Toolbar, ToolbarClasses, ToolbarModule, ToolbarStyle };
//# sourceMappingURL=wawjs-ngx-prime-toolbar.mjs.map
