import * as i0 from '@angular/core';
import { Injectable, InjectionToken, input, inject, booleanAttribute, computed, effect, Directive, NgModule } from '@angular/core';
import { NgControl } from '@angular/forms';
import { PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import { BaseModelHolder } from '@wawjs/ngx-prime/basemodelholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Fluid } from '@wawjs/ngx-prime/fluid';
import { style as style$1 } from '@wawjs/css-prime-styles/inputtext';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const style = /*css*/ `
    ${style$1}

    /* For ngx-prime */
   .p-inputtext.ng-invalid.ng-dirty {
        border-color: dt('inputtext.invalid.border.color');
    }

    .p-inputtext.ng-invalid.ng-dirty::placeholder {
        color: dt('inputtext.invalid.placeholder.color');
    }
`;
const classes = {
    root: ({ instance }) => [
        'p-inputtext p-component',
        {
            'p-filled': instance.$filled(),
            'p-inputtext-sm': instance.pSize() === 'small',
            'p-inputtext-lg': instance.pSize() === 'large',
            'p-invalid': instance.invalid(),
            'p-variant-filled': instance.$variant() === 'filled',
            'p-inputtext-fluid': instance.hasFluid
        }
    ]
};
class InputTextStyle extends BaseStyle {
    name = 'inputtext';
    style = style;
    classes = classes;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InputTextStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InputTextStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InputTextStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * InputText renders a text field to enter data.
 *
 * [Live Demo](https://www.ngx-prime.org/inputtext/)
 *
 * @module inputtextstyle
 *
 */
var InputTextClasses;
(function (InputTextClasses) {
    /**
     * The class of root element
     */
    InputTextClasses["root"] = "p-inputtext";
})(InputTextClasses || (InputTextClasses = {}));

const INPUTTEXT_INSTANCE = new InjectionToken('INPUTTEXT_INSTANCE');
/**
 * InputText directive is an extension to standard input element with theming.
 * @group Components
 */
class InputText extends BaseModelHolder {
    componentName = 'InputText';
    hostName = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hostName" }] : /* istanbul ignore next */ []));
    /**
     * Used to pass attributes to DOM elements inside the InputText component.
     * @defaultValue undefined
     * @deprecated use pInputTextPT instead.
     * @group Props
     */
    ptInputText = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ptInputText" }] : /* istanbul ignore next */ []));
    /**
     * Used to pass attributes to DOM elements inside the InputText component.
     * @defaultValue undefined
     * @group Props
     */
    pInputTextPT = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "pInputTextPT" }] : /* istanbul ignore next */ []));
    /**
     * Indicates whether the component should be rendered without styles.
     * @defaultValue undefined
     * @group Props
     */
    pInputTextUnstyled = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "pInputTextUnstyled" }] : /* istanbul ignore next */ []));
    bindDirectiveInstance = inject(Bind, { self: true });
    $pcInputText = inject(INPUTTEXT_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    ngControl = inject(NgControl, { optional: true, self: true });
    pcFluid = inject(Fluid, { optional: true, host: true, skipSelf: true });
    /**
     * Defines the size of the component.
     * @group Props
     */
    pSize = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "pSize" }] : /* istanbul ignore next */ []));
    /**
     * Specifies the input variant of the component.
     * @defaultValue undefined
     * @group Props
     */
    variant = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "variant" }] : /* istanbul ignore next */ []));
    /**
     * Spans 100% width of the container when enabled.
     * @defaultValue undefined
     * @group Props
     */
    fluid = input(undefined, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * When present, it specifies that the component should have invalid state style.
     * @defaultValue false
     * @group Props
     */
    invalid = input(undefined, { ...(ngDevMode ? { debugName: "invalid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    $variant = computed(() => this.variant() || this.config.inputStyle() || this.config.inputVariant(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "$variant" }] : /* istanbul ignore next */ []));
    _componentStyle = inject(InputTextStyle);
    constructor() {
        super();
        effect(() => {
            const pt = this.ptInputText() || this.pInputTextPT();
            pt && this.directivePT.set(pt);
        });
        effect(() => {
            this.pInputTextUnstyled() && this.directiveUnstyled.set(this.pInputTextUnstyled());
        });
    }
    onAfterViewInit() {
        this.writeModelValue(this.ngControl?.value ?? this.el.nativeElement.value);
        this.cd.detectChanges();
    }
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptm('root'));
    }
    onDoCheck() {
        this.writeModelValue(this.ngControl?.value ?? this.el.nativeElement.value);
    }
    onInput() {
        this.writeModelValue(this.ngControl?.value ?? this.el.nativeElement.value);
    }
    get hasFluid() {
        return this.fluid() ?? !!this.pcFluid;
    }
    get dataP() {
        return this.cn({
            invalid: this.invalid(),
            fluid: this.hasFluid,
            filled: this.$variant() === 'filled',
            [this.pSize()]: this.pSize()
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InputText, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: InputText, isStandalone: true, selector: "[pInputText]", inputs: { hostName: { classPropertyName: "hostName", publicName: "hostName", isSignal: true, isRequired: false, transformFunction: null }, ptInputText: { classPropertyName: "ptInputText", publicName: "ptInputText", isSignal: true, isRequired: false, transformFunction: null }, pInputTextPT: { classPropertyName: "pInputTextPT", publicName: "pInputTextPT", isSignal: true, isRequired: false, transformFunction: null }, pInputTextUnstyled: { classPropertyName: "pInputTextUnstyled", publicName: "pInputTextUnstyled", isSignal: true, isRequired: false, transformFunction: null }, pSize: { classPropertyName: "pSize", publicName: "pSize", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null }, invalid: { classPropertyName: "invalid", publicName: "invalid", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "input": "onInput()" }, properties: { "class": "cx('root')", "attr.data-p": "dataP" } }, providers: [InputTextStyle, { provide: INPUTTEXT_INSTANCE, useExisting: InputText }, { provide: PARENT_INSTANCE, useExisting: InputText }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InputText, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pInputText]',
                    standalone: true,
                    host: {
                        '[class]': "cx('root')",
                        '[attr.data-p]': 'dataP',
                        '(input)': 'onInput()'
                    },
                    providers: [InputTextStyle, { provide: INPUTTEXT_INSTANCE, useExisting: InputText }, { provide: PARENT_INSTANCE, useExisting: InputText }],
                    hostDirectives: [Bind]
                }]
        }], ctorParameters: () => [], propDecorators: { hostName: [{ type: i0.Input, args: [{ isSignal: true, alias: "hostName", required: false }] }], ptInputText: [{ type: i0.Input, args: [{ isSignal: true, alias: "ptInputText", required: false }] }], pInputTextPT: [{ type: i0.Input, args: [{ isSignal: true, alias: "pInputTextPT", required: false }] }], pInputTextUnstyled: [{ type: i0.Input, args: [{ isSignal: true, alias: "pInputTextUnstyled", required: false }] }], pSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "pSize", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], invalid: [{ type: i0.Input, args: [{ isSignal: true, alias: "invalid", required: false }] }] } });
class InputTextModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InputTextModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: InputTextModule, imports: [InputText], exports: [InputText] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InputTextModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InputTextModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [InputText],
                    exports: [InputText]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { InputText, InputTextClasses, InputTextModule, InputTextStyle };
//# sourceMappingURL=wawjs-ngx-prime-inputtext.mjs.map
