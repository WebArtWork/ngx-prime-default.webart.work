export * from '@wawjs/ngx-prime/types/tag';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, input, booleanAttribute, contentChildren, ContentChild, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { PrimeTemplate, SharedModule } from '@wawjs/ngx-prime/api';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { style } from '@wawjs/css-prime-styles/tag';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const classes = {
    root: ({ instance }) => [
        'p-tag p-component',
        {
            'p-tag-info': instance.severity === 'info',
            'p-tag-success': instance.severity === 'success',
            'p-tag-warn': instance.severity === 'warn',
            'p-tag-danger': instance.severity === 'danger',
            'p-tag-secondary': instance.severity === 'secondary',
            'p-tag-contrast': instance.severity === 'contrast',
            'p-tag-rounded': instance.rounded
        }
    ],
    icon: 'p-tag-icon',
    label: 'p-tag-label'
};
class TagStyle extends BaseStyle {
    name = 'tag';
    style = style;
    classes = classes;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TagStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TagStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TagStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * Tag component is used to categorize content.
 *
 * [Live Demo](https://www.ngx-prime.org/tag)
 *
 * @module tagstyle
 *
 */
var TagClasses;
(function (TagClasses) {
    /**
     * Class name of the root element
     */
    TagClasses["root"] = "p-tag";
    /**
     * Class name of the icon element
     */
    TagClasses["icon"] = "p-tag-icon";
    /**
     * Class name of the label element
     */
    TagClasses["label"] = "p-tag-label";
})(TagClasses || (TagClasses = {}));

const TAG_INSTANCE = new InjectionToken('TAG_INSTANCE');
/**
 * Tag component is used to categorize content.
 * @group Components
 */
class Tag extends BaseComponent {
    componentName = 'Tag';
    $pcTag = inject(TAG_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Severity type of the tag.
     * @group Props
     */
    severity = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "severity" }] : /* istanbul ignore next */ []));
    /**
     * Value to display inside the tag.
     * @group Props
     */
    value = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "value" }] : /* istanbul ignore next */ []));
    /**
     * Icon of the tag to display next to the value.
     * @group Props
     */
    icon = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "icon" }] : /* istanbul ignore next */ []));
    /**
     * Whether the corners of the tag are rounded.
     * @group Props
     */
    rounded = input(false, { ...(ngDevMode ? { debugName: "rounded" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Custom icon template.
     * @group Templates
     */
    iconTemplate;
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    _iconTemplate;
    _componentStyle = inject(TagStyle);
    onAfterContentInit() {
        this.templates()?.forEach((item) => {
            switch (item.getType()) {
                case 'icon':
                    this._iconTemplate = item.template;
                    break;
            }
        });
    }
    get dataP() {
        return this.cn({
            rounded: this.rounded(),
            [this.severity()]: this.severity()
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Tag, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: Tag, isStandalone: true, selector: "p-tag", inputs: { styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, severity: { classPropertyName: "severity", publicName: "severity", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, rounded: { classPropertyName: "rounded", publicName: "rounded", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "cn(cx('root'), styleClass())", "attr.data-p": "dataP" } }, providers: [TagStyle, { provide: TAG_INSTANCE, useExisting: Tag }, { provide: PARENT_INSTANCE, useExisting: Tag }], queries: [{ propertyName: "templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "iconTemplate", first: true, predicate: ["icon"] }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        <ng-content></ng-content>
        @if (!iconTemplate && !_iconTemplate) {
            @if (icon()) {
                <span [class]="cx('icon')" [ngClass]="icon()" [pBind]="ptm('icon')"></span>
            }
        }
        @if (iconTemplate || _iconTemplate) {
            <span [class]="cx('icon')" [pBind]="ptm('icon')">
                <ng-template *ngTemplateOutlet="iconTemplate || _iconTemplate"></ng-template>
            </span>
        }
        <span [class]="cx('label')" [pBind]="ptm('label')">{{ value() }}</span>
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: SharedModule }, { kind: "directive", type: Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Tag, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-tag',
                    standalone: true,
                    imports: [CommonModule, SharedModule, Bind],
                    template: `
        <ng-content></ng-content>
        @if (!iconTemplate && !_iconTemplate) {
            @if (icon()) {
                <span [class]="cx('icon')" [ngClass]="icon()" [pBind]="ptm('icon')"></span>
            }
        }
        @if (iconTemplate || _iconTemplate) {
            <span [class]="cx('icon')" [pBind]="ptm('icon')">
                <ng-template *ngTemplateOutlet="iconTemplate || _iconTemplate"></ng-template>
            </span>
        }
        <span [class]="cx('label')" [pBind]="ptm('label')">{{ value() }}</span>
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [TagStyle, { provide: TAG_INSTANCE, useExisting: Tag }, { provide: PARENT_INSTANCE, useExisting: Tag }],
                    host: {
                        '[class]': "cn(cx('root'), styleClass())",
                        '[attr.data-p]': 'dataP'
                    },
                    hostDirectives: [Bind]
                }]
        }], propDecorators: { styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], severity: [{ type: i0.Input, args: [{ isSignal: true, alias: "severity", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], rounded: [{ type: i0.Input, args: [{ isSignal: true, alias: "rounded", required: false }] }], iconTemplate: [{
                type: ContentChild,
                args: ['icon', { descendants: false }]
            }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class TagModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TagModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: TagModule, imports: [Tag, SharedModule], exports: [Tag, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TagModule, imports: [Tag, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TagModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [Tag, SharedModule],
                    exports: [Tag, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { Tag, TagClasses, TagModule, TagStyle };
//# sourceMappingURL=wawjs-ngx-prime-tag.mjs.map
