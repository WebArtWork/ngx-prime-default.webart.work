/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=wawjs-ngx-prime-types-tabs.mjs.map
