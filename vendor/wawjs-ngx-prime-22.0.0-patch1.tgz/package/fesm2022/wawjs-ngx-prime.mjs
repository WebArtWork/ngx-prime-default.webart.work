var public_api = {};

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=wawjs-ngx-prime.mjs.map
