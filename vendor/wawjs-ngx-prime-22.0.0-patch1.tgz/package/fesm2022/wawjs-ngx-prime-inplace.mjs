export * from '@wawjs/ngx-prime/types/inplace';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, Component, inject, model, input, booleanAttribute, output, contentChild, contentChildren, ViewEncapsulation, ChangeDetectionStrategy, NgModule } from '@angular/core';
import { PrimeTemplate, SharedModule } from '@wawjs/ngx-prime/api';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import * as i2 from '@wawjs/ngx-prime/button';
import { ButtonModule } from '@wawjs/ngx-prime/button';
import { TimesIcon } from '@wawjs/ngx-prime/icons';
import { Ripple } from '@wawjs/ngx-prime/ripple';
import { style } from '@wawjs/css-prime-styles/inplace';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const classes = {
    root: () => ['p-inplace p-component'],
    display: ({ instance }) => ['p-inplace-display', { 'p-disabled': instance.disabled() }],
    content: 'p-inplace-content'
};
class InplaceStyle extends BaseStyle {
    name = 'inplace';
    style = style;
    classes = classes;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InplaceStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InplaceStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InplaceStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * Inplace provides an easy to do editing and display at the same time where clicking the output displays the actual content.
 *
 * [Live Demo](https://www.ngx-prime.org/inplace)
 *
 * @module inplacestyle
 *
 */
var InplaceClasses;
(function (InplaceClasses) {
    /**
     * Class name of the root element
     */
    InplaceClasses["root"] = "p-inplace";
    /**
     * Class name of the display element
     */
    InplaceClasses["display"] = "p-inplace-display";
    /**
     * Class name of the content element
     */
    InplaceClasses["content"] = "p-inplace-content";
})(InplaceClasses || (InplaceClasses = {}));

const INPLACE_INSTANCE = new InjectionToken('INPLACE_INSTANCE');
class InplaceDisplay extends BaseComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InplaceDisplay, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.1.2", type: InplaceDisplay, isStandalone: true, selector: "p-inplacedisplay, p-inplaceDisplay", usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InplaceDisplay, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-inplacedisplay, p-inplaceDisplay',
                    standalone: true,
                    imports: [],
                    template: '<ng-content></ng-content>'
                }]
        }] });
class InplaceContent extends BaseComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InplaceContent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.1.2", type: InplaceContent, isStandalone: true, selector: "p-inplacecontent, p-inplaceContent", usesInheritance: true, ngImport: i0, template: '<ng-content></ng-content>', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InplaceContent, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-inplacecontent, p-inplaceContent',
                    standalone: true,
                    imports: [],
                    template: '<ng-content></ng-content>'
                }]
        }] });
/**
 * Inplace provides an easy to do editing and display at the same time where clicking the output displays the actual content.
 * @group Components
 */
class Inplace extends BaseComponent {
    componentName = 'Inplace';
    $pcInplace = inject(INPLACE_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    /**
     * Whether the content is displayed or not.
     * @group Props
     */
    active = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "active" }] : /* istanbul ignore next */ []));
    /**
     * Displays a button to switch back to display mode.
     * @deprecated since v20.0.0, use `closeCallback` within content template.
     * @group Props
     */
    closable = input(false, { ...(ngDevMode ? { debugName: "closable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * When present, it specifies that the element should be disabled.
     * @group Props
     */
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Allows to prevent clicking.
     * @group Props
     */
    preventClick = input(undefined, { ...(ngDevMode ? { debugName: "preventClick" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Icon to display in the close button.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    closeIcon = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "closeIcon" }] : /* istanbul ignore next */ []));
    /**
     * Establishes a string value that labels the close button.
     * @group Props
     */
    closeAriaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "closeAriaLabel" }] : /* istanbul ignore next */ []));
    /**
     * Callback to invoke when inplace is opened.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onActivate = output();
    /**
     * Callback to invoke when inplace is closed.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onDeactivate = output();
    hover;
    /**
     * Custom display template.
     * @group Templates
     */
    displayTemplate = contentChild('display', { ...(ngDevMode ? { debugName: "displayTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom content template.
     * @group Templates
     */
    contentTemplate = contentChild('content', { ...(ngDevMode ? { debugName: "contentTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom close icon template.
     * @group Templates
     */
    closeIconTemplate = contentChild('closeicon', { ...(ngDevMode ? { debugName: "closeIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    _componentStyle = inject(InplaceStyle);
    onActivateClick(event) {
        if (!this.preventClick())
            this.activate(event);
    }
    onDeactivateClick(event) {
        if (!this.preventClick())
            this.deactivate(event);
    }
    /**
     * Activates the content.
     * @param {Event} event - Browser event.
     * @group Method
     */
    activate(event) {
        if (!this.disabled()) {
            this.active.set(true);
            this.onActivate.emit(event);
            this.cd.markForCheck();
        }
    }
    /**
     * Deactivates the content.
     * @param {Event} event - Browser event.
     * @group Method
     */
    deactivate(event) {
        if (!this.disabled()) {
            this.active.set(false);
            this.hover = false;
            this.onDeactivate.emit(event);
            this.cd.markForCheck();
        }
    }
    onKeydown(event) {
        if (event.code === 'Enter') {
            this.activate(event);
            event.preventDefault();
        }
    }
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    _displayTemplate;
    _closeIconTemplate;
    _contentTemplate;
    onAfterContentInit() {
        this.templates()?.forEach((item) => {
            switch (item.getType()) {
                case 'display':
                    this._displayTemplate = item.template;
                    break;
                case 'closeicon':
                    this._closeIconTemplate = item.template;
                    break;
                case 'content':
                    this._contentTemplate = item.template;
                    break;
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Inplace, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: Inplace, isStandalone: true, selector: "p-inplace", inputs: { active: { classPropertyName: "active", publicName: "active", isSignal: true, isRequired: false, transformFunction: null }, closable: { classPropertyName: "closable", publicName: "closable", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, preventClick: { classPropertyName: "preventClick", publicName: "preventClick", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, closeIcon: { classPropertyName: "closeIcon", publicName: "closeIcon", isSignal: true, isRequired: false, transformFunction: null }, closeAriaLabel: { classPropertyName: "closeAriaLabel", publicName: "closeAriaLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { active: "activeChange", onActivate: "onActivate", onDeactivate: "onDeactivate" }, host: { properties: { "attr.aria-live": "'polite'", "class": "cn(cx('root'), styleClass())" } }, providers: [InplaceStyle, { provide: INPLACE_INSTANCE, useExisting: Inplace }, { provide: PARENT_INSTANCE, useExisting: Inplace }], queries: [{ propertyName: "displayTemplate", first: true, predicate: ["display"], isSignal: true }, { propertyName: "contentTemplate", first: true, predicate: ["content"], isSignal: true }, { propertyName: "closeIconTemplate", first: true, predicate: ["closeicon"], isSignal: true }, { propertyName: "templates", predicate: PrimeTemplate, isSignal: true }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        @if (!active()) {
            <div [class]="cx('display')" [pBind]="ptm('display')" (click)="onActivateClick($event)" tabindex="0" role="button" (keydown)="onKeydown($event)" [attr.data-p-disabled]="disabled()">
                <ng-content select="[pInplaceDisplay]"></ng-content>
                <ng-container *ngTemplateOutlet="displayTemplate() || _displayTemplate"></ng-container>
            </div>
        }
        @if (active()) {
            <div [class]="cx('content')" [pBind]="ptm('content')">
                <ng-content select="[pInplaceContent]"></ng-content>
                <ng-container *ngTemplateOutlet="contentTemplate() || _contentTemplate; context: { closeCallback: onDeactivateClick.bind(this) }"></ng-container>
                @if (closable()) {
                    @if (closeIcon()) {
                        <p-button [pt]="ptm('pcButton')" type="button" [icon]="closeIcon()" pRipple (click)="onDeactivateClick($event)" [attr.aria-label]="closeAriaLabel()"></p-button>
                    }
                    @if (!closeIcon()) {
                        <p-button [pt]="ptm('pcButton')" type="button" pRipple (click)="onDeactivateClick($event)" [attr.aria-label]="closeAriaLabel()">
                            <ng-template #icon>
                                @if (!closeIconTemplate() && !_closeIconTemplate) {
                                    <svg data-p-icon="times" />
                                }
                            </ng-template>
                            <ng-template *ngTemplateOutlet="closeIconTemplate() || _closeIconTemplate"></ng-template>
                        </p-button>
                    }
                }
            </div>
        }
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: ButtonModule }, { kind: "component", type: i2.Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }, { kind: "component", type: TimesIcon, selector: "[data-p-icon=\"times\"]" }, { kind: "ngmodule", type: SharedModule }, { kind: "directive", type: Ripple, selector: "[pRipple]" }, { kind: "directive", type: Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Inplace, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-inplace',
                    standalone: true,
                    imports: [ButtonModule, TimesIcon, SharedModule, Ripple, Bind],
                    template: `
        @if (!active()) {
            <div [class]="cx('display')" [pBind]="ptm('display')" (click)="onActivateClick($event)" tabindex="0" role="button" (keydown)="onKeydown($event)" [attr.data-p-disabled]="disabled()">
                <ng-content select="[pInplaceDisplay]"></ng-content>
                <ng-container *ngTemplateOutlet="displayTemplate() || _displayTemplate"></ng-container>
            </div>
        }
        @if (active()) {
            <div [class]="cx('content')" [pBind]="ptm('content')">
                <ng-content select="[pInplaceContent]"></ng-content>
                <ng-container *ngTemplateOutlet="contentTemplate() || _contentTemplate; context: { closeCallback: onDeactivateClick.bind(this) }"></ng-container>
                @if (closable()) {
                    @if (closeIcon()) {
                        <p-button [pt]="ptm('pcButton')" type="button" [icon]="closeIcon()" pRipple (click)="onDeactivateClick($event)" [attr.aria-label]="closeAriaLabel()"></p-button>
                    }
                    @if (!closeIcon()) {
                        <p-button [pt]="ptm('pcButton')" type="button" pRipple (click)="onDeactivateClick($event)" [attr.aria-label]="closeAriaLabel()">
                            <ng-template #icon>
                                @if (!closeIconTemplate() && !_closeIconTemplate) {
                                    <svg data-p-icon="times" />
                                }
                            </ng-template>
                            <ng-template *ngTemplateOutlet="closeIconTemplate() || _closeIconTemplate"></ng-template>
                        </p-button>
                    }
                }
            </div>
        }
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [InplaceStyle, { provide: INPLACE_INSTANCE, useExisting: Inplace }, { provide: PARENT_INSTANCE, useExisting: Inplace }],
                    host: {
                        '[attr.aria-live]': "'polite'",
                        '[class]': "cn(cx('root'), styleClass())"
                    },
                    hostDirectives: [Bind]
                }]
        }], propDecorators: { active: [{ type: i0.Input, args: [{ isSignal: true, alias: "active", required: false }] }, { type: i0.Output, args: ["activeChange"] }], closable: [{ type: i0.Input, args: [{ isSignal: true, alias: "closable", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], preventClick: [{ type: i0.Input, args: [{ isSignal: true, alias: "preventClick", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], closeIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeIcon", required: false }] }], closeAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "closeAriaLabel", required: false }] }], onActivate: [{ type: i0.Output, args: ["onActivate"] }], onDeactivate: [{ type: i0.Output, args: ["onDeactivate"] }], displayTemplate: [{ type: i0.ContentChild, args: ['display', { ...{ descendants: false }, isSignal: true }] }], contentTemplate: [{ type: i0.ContentChild, args: ['content', { ...{ descendants: false }, isSignal: true }] }], closeIconTemplate: [{ type: i0.ContentChild, args: ['closeicon', { ...{ descendants: false }, isSignal: true }] }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class InplaceModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InplaceModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: InplaceModule, imports: [Inplace, InplaceContent, InplaceDisplay, SharedModule], exports: [Inplace, InplaceContent, InplaceDisplay, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InplaceModule, imports: [Inplace, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InplaceModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [Inplace, InplaceContent, InplaceDisplay, SharedModule],
                    exports: [Inplace, InplaceContent, InplaceDisplay, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { Inplace, InplaceClasses, InplaceContent, InplaceDisplay, InplaceModule, InplaceStyle };
//# sourceMappingURL=wawjs-ngx-prime-inplace.mjs.map
