export * from '@wawjs/ngx-prime/types/orderlist';
import { moveItemInArray, DragDropModule } from '@angular/cdk/drag-drop';
import * as i2 from '@angular/common';
import { isPlatformBrowser, CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, input, numberAttribute, booleanAttribute, model, output, viewChild, contentChild, effect, contentChildren, ContentChild, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import * as i4 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { uuid, findIndexInList, setAttribute } from '@wawjs/css-prime-utils';
import { FilterService, PrimeTemplate, SharedModule } from '@wawjs/ngx-prime/api';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import * as i3 from '@wawjs/ngx-prime/button';
import { ButtonModule } from '@wawjs/ngx-prime/button';
import { AngleDoubleDownIcon, AngleDoubleUpIcon, AngleUpIcon, AngleDownIcon } from '@wawjs/ngx-prime/icons';
import { Listbox } from '@wawjs/ngx-prime/listbox';
import { Ripple } from '@wawjs/ngx-prime/ripple';
import { style } from '@wawjs/css-prime-styles/orderlist';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const theme = /*css*/ `
    ${style}

    /* For ngx-prime */
    .p-orderlist-controls-right .p-orderlist-controls {
        order: 2;
    }
`;
const classes = {
    root: ({ instance }) => ['p-orderlist p-component', { 'p-orderlist-controls-left': instance.controlsPosition() === 'left', 'p-orderlist-controls-right': instance.controlsPosition() === 'right' }],
    controls: 'p-orderlist-controls'
};
class OrderListStyle extends BaseStyle {
    name = 'orderlist';
    style = theme;
    classes = classes;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OrderListStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OrderListStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OrderListStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * OrderList is used to maneged the order of a collection.
 *
 * [Live Demo](https://ngx-prime.org/orderlist)
 *
 * @module orderliststyle
 *
 */
var OrderListClasses;
(function (OrderListClasses) {
    /**
     * Class name of the root element
     */
    OrderListClasses["root"] = "p-orderlist";
    /**
     * Class name of the controls element
     */
    OrderListClasses["controls"] = "p-orderlist-controls";
})(OrderListClasses || (OrderListClasses = {}));

const ORDERLIST_INSTANCE = new InjectionToken('ORDERLIST_INSTANCE');
/**
 * OrderList is used to manage the order of a collection.
 * @group Components
 */
class OrderList extends BaseComponent {
    componentName = 'OrderList';
    bindDirectiveInstance = inject(Bind, { self: true });
    $pcOrderList = inject(ORDERLIST_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    /**
     * Text for the caption.
     * @group Props
     */
    header = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "header" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex = input(undefined, { ...(ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Defines a string that labels the input for accessibility.
     * @group Props
     */
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /**
     * Specifies one or more IDs in the DOM that labels the input field.
     * @group Props
     */
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    /**
     * Inline style of the list element.
     * @group Props
     */
    listStyle = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "listStyle" }] : /* istanbul ignore next */ []));
    /**
     * A boolean value that indicates whether the component should be responsive.
     * @group Props
     */
    responsive = input(undefined, { ...(ngDevMode ? { debugName: "responsive" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * When specified displays an input field to filter the items on keyup and decides which fields to search against.
     * @group Props
     */
    filterBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "filterBy" }] : /* istanbul ignore next */ []));
    /**
     * Placeholder of the filter input.
     * @group Props
     */
    filterPlaceholder = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "filterPlaceholder" }] : /* istanbul ignore next */ []));
    /**
     * Locale to use in filtering. The default locale is the host environment's current locale.
     * @group Props
     */
    filterLocale = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "filterLocale" }] : /* istanbul ignore next */ []));
    /**
     * When true metaKey needs to be pressed to select or unselect an item and when set to false selection of each item can be toggled individually. On touch enabled devices, metaKeySelection is turned off automatically.
     * @group Props
     */
    metaKeySelection = input(false, { ...(ngDevMode ? { debugName: "metaKeySelection" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to enable dragdrop based reordering.
     * @group Props
     */
    dragdrop = input(false, { ...(ngDevMode ? { debugName: "dragdrop" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Defines the location of the buttons with respect to the list.
     * @group Props
     */
    controlsPosition = input('left', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "controlsPosition" }] : /* istanbul ignore next */ []));
    /**
     * Defines a string that labels the filter input.
     * @group Props
     */
    ariaFilterLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaFilterLabel" }] : /* istanbul ignore next */ []));
    /**
     * Defines how the items are filtered.
     * @group Props
     */
    filterMatchMode = input('contains', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterMatchMode" }] : /* istanbul ignore next */ []));
    /**
     * Indicates the width of the screen at which the component should change its behavior.
     * @group Props
     */
    breakpoint = input('960px', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "breakpoint" }] : /* istanbul ignore next */ []));
    /**
     * Whether to displays rows with alternating colors.
     * @group Props
     */
    stripedRows = input(undefined, { ...(ngDevMode ? { debugName: "stripedRows" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * When present, it specifies that the component should be disabled.
     * @group Props
     */
    disabled = input(undefined, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Function to optimize the dom operations by delegating to ngForTrackBy, default algorithm checks for object identity.
     * @group Props
     */
    trackBy = input((index, item) => item, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "trackBy" }] : /* istanbul ignore next */ []));
    /**
     * Height of the viewport, a scrollbar is defined if height of list exceeds this value.
     * @group Props
     */
    scrollHeight = input('14rem', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scrollHeight" }] : /* istanbul ignore next */ []));
    /**
     * Whether to focus on the first visible or selected element.
     * @group Props
     */
    autoOptionFocus = input(true, { ...(ngDevMode ? { debugName: "autoOptionFocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Name of the field that uniquely identifies the record in the data.
     * @group Props
     */
    dataKey = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "dataKey" }] : /* istanbul ignore next */ []));
    /**
     * A list of values that are currently selected.
     * @group Props
     */
    selection = model([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selection" }] : /* istanbul ignore next */ []));
    /**
     * Array of values to be displayed in the component.
     * It represents the data source for the list of items.
     * @group Props
     */
    value = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "value" }] : /* istanbul ignore next */ []));
    /**
     * Used to pass all properties of the ButtonProps to the Button component.
     * @group Props
     */
    buttonProps = input({ severity: 'secondary' }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "buttonProps" }] : /* istanbul ignore next */ []));
    /**
     * Used to pass all properties of the ButtonProps to the move up button inside the component.
     * @group Props
     */
    moveUpButtonProps = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "moveUpButtonProps" }] : /* istanbul ignore next */ []));
    /**
     * Used to pass all properties of the ButtonProps to the move top button inside the component.
     * @group Props
     */
    moveTopButtonProps = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "moveTopButtonProps" }] : /* istanbul ignore next */ []));
    /**
     * Used to pass all properties of the ButtonProps to the move down button inside the component.
     * @group Props
     */
    moveDownButtonProps = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "moveDownButtonProps" }] : /* istanbul ignore next */ []));
    /**
     * Used to pass all properties of the ButtonProps to the move bottom button inside the component.
     * @group Props
     */
    moveBottomButtonProps = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "moveBottomButtonProps" }] : /* istanbul ignore next */ []));
    /**
     * Callback to invoke when list is reordered.
     * @param {*} any - list instance.
     * @group Emits
     */
    onReorder = output();
    /**
     * Callback to invoke when selection changes.
     * @param {OrderListSelectionChangeEvent} event - Custom change event.
     * @group Emits
     */
    onSelectionChange = output();
    /**
     * Callback to invoke when filtering occurs.
     * @param {OrderListFilterEvent} event - Custom filter event.
     * @group Emits
     */
    onFilterEvent = output();
    /**
     * Callback to invoke when the list is focused
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onFocus = output();
    /**
     * Callback to invoke when the list is blurred
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onBlur = output();
    listViewChild = viewChild.required('listelement', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "listViewChild" }] : /* istanbul ignore next */ []));
    filterViewChild = viewChild('filter', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterViewChild" }] : /* istanbul ignore next */ []));
    /**
     * Custom item template.
     * @param {OrderListItemTemplateContext} context - item context.
     * @see {@link OrderListItemTemplateContext}
     * @group Templates
     */
    itemTemplate;
    /**
     * Custom empty template.
     * @group Templates
     */
    emptyMessageTemplate;
    /**
     * Custom empty filter template.
     * @group Templates
     */
    emptyFilterMessageTemplate;
    /**
     * Custom filter template.
     * @param {OrderListFilterTemplateContext} context - filter context.
     * @see {@link OrderListFilterTemplateContext}
     * @group Templates
     */
    filterTemplate;
    /**
     * Custom header template.
     * @group Templates
     */
    headerTemplate;
    /**
     * Custom move up icon template.
     * @group Templates
     */
    moveUpIconTemplate = contentChild('moveupicon', { ...(ngDevMode ? { debugName: "moveUpIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom move top icon template.
     * @group Templates
     */
    moveTopIconTemplate = contentChild('movetopicon', { ...(ngDevMode ? { debugName: "moveTopIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom move down icon template.
     * @group Templates
     */
    moveDownIconTemplate = contentChild('movedownicon', { ...(ngDevMode ? { debugName: "moveDownIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom move bottom icon template.
     * @group Templates
     */
    moveBottomIconTemplate = contentChild('movebottomicon', { ...(ngDevMode ? { debugName: "moveBottomIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom filter icon template.
     * @group Templates
     */
    filterIconTemplate;
    get moveUpAriaLabel() {
        return this.config.translation.aria ? this.config.translation.aria.moveUp : undefined;
    }
    get moveTopAriaLabel() {
        return this.config.translation.aria ? this.config.translation.aria.moveTop : undefined;
    }
    get moveDownAriaLabel() {
        return this.config.translation.aria ? this.config.translation.aria.moveDown : undefined;
    }
    get moveBottomAriaLabel() {
        return this.config.translation.aria ? this.config.translation.aria.moveBottom : undefined;
    }
    _componentStyle = inject(OrderListStyle);
    filterOptions;
    d_selection = [];
    movedUp;
    movedDown;
    itemTouched;
    styleElement;
    id = uuid('pn_id_');
    filterValue;
    visibleOptions;
    filterService = inject(FilterService);
    constructor() {
        super();
        effect(() => {
            this.d_selection = this.selection();
        });
        effect(() => {
            const val = this.value();
            if (this.filterValue) {
                this.filter();
            }
            else if (this.dragdrop()) {
                // Initialize visibleOptions for drag&drop even when no filtering is active
                this.visibleOptions = [...(val || [])];
            }
        });
    }
    getButtonProps(direction) {
        switch (direction) {
            case 'up':
                return { ...this.buttonProps(), ...this.moveUpButtonProps() };
            case 'top':
                return { ...this.buttonProps(), ...this.moveTopButtonProps() };
            case 'down':
                return { ...this.buttonProps(), ...this.moveDownButtonProps() };
            case 'bottom':
                return { ...this.buttonProps(), ...this.moveBottomButtonProps() };
            default:
                return this.buttonProps();
        }
    }
    onInit() {
        if (this.responsive()) {
            this.createStyle();
        }
        if (this.filterBy()) {
            this.filterOptions = {
                filter: (value) => this.onFilterKeyup(value),
                reset: () => this.resetFilter()
            };
        }
        // Initialize visibleOptions for drag&drop if enabled and value exists
        if (this.dragdrop() && this.value() && !this.visibleOptions) {
            this.visibleOptions = [...this.value()];
        }
    }
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    _itemTemplate;
    _emptyMessageTemplate;
    _emptyFilterMessageTemplate;
    _filterTemplate;
    _headerTemplate;
    _moveUpIconTemplate;
    _moveTopIconTemplate;
    _moveDownIconTemplate;
    _moveBottomIconTemplate;
    _filterIconTemplate;
    onAfterContentInit() {
        this.templates().forEach((item) => {
            switch (item.getType()) {
                case 'item':
                    this._itemTemplate = item.template;
                    break;
                case 'empty':
                    this._emptyMessageTemplate = item.template;
                    break;
                case 'emptyfilter':
                    this._emptyFilterMessageTemplate = item.template;
                    break;
                case 'filter':
                    this._filterTemplate = item.template;
                    break;
                case 'header':
                    this._headerTemplate = item.template;
                    break;
                case 'moveupicon':
                    this._moveUpIconTemplate = item.template;
                    break;
                case 'movetopicon':
                    this._moveTopIconTemplate = item.template;
                    break;
                case 'movedownicon':
                    this._moveDownIconTemplate = item.template;
                    break;
                case 'movebottomicon':
                    this._moveBottomIconTemplate = item.template;
                    break;
                case 'filtericon':
                    this._filterIconTemplate = item.template;
                    break;
                default:
                    this._itemTemplate = item.template;
                    break;
            }
        });
    }
    onChangeSelection(e) {
        this.d_selection = e.value;
        //binding
        this.selection.set(e.value);
        //event
        this.onSelectionChange.emit({ originalEvent: e.originalEvent, value: e.value });
    }
    onFilterKeyup(event) {
        this.filterValue = event.target.value.trim().toLocaleLowerCase(this.filterLocale());
        this.filter();
        this.onFilterEvent.emit({
            originalEvent: event,
            value: this.visibleOptions
        });
    }
    filter() {
        let searchFields = this.filterBy().split(',');
        this.visibleOptions = this.filterService.filter(this.value(), searchFields, this.filterValue, this.filterMatchMode(), this.filterLocale());
    }
    /**
     * Callback to invoke on filter reset.
     * @group Method
     */
    resetFilter() {
        this.filterValue = '';
        const filterViewChild = this.filterViewChild();
        filterViewChild && (filterViewChild.nativeElement.value = '');
    }
    isItemVisible(item) {
        if (this.filterValue && this.filterValue.trim().length) {
            for (let i = 0; i < this.visibleOptions.length; i++) {
                if (item == this.visibleOptions[i]) {
                    return true;
                }
            }
        }
        else {
            return true;
        }
    }
    isSelected(item) {
        return findIndexInList(item, this.d_selection) !== -1;
    }
    isEmpty() {
        const value = this.value();
        return this.filterValue ? !this.visibleOptions || this.visibleOptions.length === 0 : !value || value.length === 0;
    }
    moveUp() {
        const value = this.value();
        const selection = this.selection();
        if (selection && value instanceof Array) {
            // Sort selection by their current index to process them from top to bottom
            const sortedSelection = this.sortByIndexInList(selection, value);
            for (let selectedItem of sortedSelection) {
                let selectedItemIndex = findIndexInList(selectedItem, value);
                // Only move if not at top and there's a valid position above
                if (selectedItemIndex > 0) {
                    let movedItem = value[selectedItemIndex];
                    let temp = value[selectedItemIndex - 1];
                    value[selectedItemIndex - 1] = movedItem;
                    value[selectedItemIndex] = temp;
                }
                // Don't break - continue with other items even if one can't move
            }
            if (this.dragdrop()) {
                if (this.filterValue) {
                    this.filter();
                }
                else if (this.visibleOptions) {
                    // Update visibleOptions to match value when no filtering
                    this.visibleOptions = [...value];
                }
            }
            this.movedUp = true;
            this.onReorder.emit(selection);
        }
        this.listViewChild()?.cd?.markForCheck();
    }
    moveTop() {
        const selection = this.selection();
        let value = this.value();
        if (selection) {
            for (let i = selection.length - 1; i >= 0; i--) {
                let selectedItem = selection[i];
                let selectedItemIndex = findIndexInList(selectedItem, value || []);
                if (selectedItemIndex != 0 && value instanceof Array) {
                    let movedItem = value.splice(selectedItemIndex, 1)[0];
                    value.unshift(movedItem);
                }
                else {
                    break;
                }
            }
            if (this.dragdrop()) {
                if (this.filterValue) {
                    this.filter();
                }
                else if (this.visibleOptions) {
                    // Update visibleOptions to match value when no filtering
                    this.visibleOptions = [...(value || [])];
                }
            }
            this.onReorder.emit(selection);
            setTimeout(() => {
                this.listViewChild().scrollInView(0);
            });
        }
        this.listViewChild()?.cd?.markForCheck();
    }
    moveDown() {
        const value = this.value();
        const selection = this.selection();
        if (selection && value instanceof Array) {
            const sortedSelection = this.sortByIndexInList(selection, value).reverse();
            for (let selectedItem of sortedSelection) {
                let selectedItemIndex = findIndexInList(selectedItem, value);
                if (selectedItemIndex < value.length - 1) {
                    let movedItem = value[selectedItemIndex];
                    let temp = value[selectedItemIndex + 1];
                    value[selectedItemIndex + 1] = movedItem;
                    value[selectedItemIndex] = temp;
                }
            }
            if (this.dragdrop()) {
                if (this.filterValue) {
                    this.filter();
                }
                else if (this.visibleOptions) {
                    this.visibleOptions = [...value];
                }
            }
            this.movedDown = true;
            this.onReorder.emit(selection);
        }
        this.listViewChild()?.cd?.markForCheck();
    }
    moveBottom() {
        const selection = this.selection();
        let value = this.value();
        if (selection) {
            for (let i = 0; i < selection.length; i++) {
                let selectedItem = selection[i];
                let selectedItemIndex = findIndexInList(selectedItem, value || []);
                if (value instanceof Array && selectedItemIndex != value.length - 1) {
                    let movedItem = value.splice(selectedItemIndex, 1)[0];
                    value.push(movedItem);
                }
                else {
                    break;
                }
            }
            if (this.dragdrop()) {
                if (this.filterValue) {
                    this.filter();
                }
                else if (this.visibleOptions) {
                    this.visibleOptions = [...(value || [])];
                }
            }
            this.onReorder.emit(selection);
            this.listViewChild()?.scrollInView(value?.length ? value.length - 1 : 0);
        }
        this.listViewChild()?.cd?.markForCheck();
    }
    onDrop(event) {
        let previousIndex = event.previousIndex;
        let currentIndex = event.currentIndex;
        // Store the original state before any modifications
        const originalValue = [...(this.value() || [])];
        const originalVisibleOptions = this.visibleOptions ? [...this.visibleOptions] : null;
        if (previousIndex !== currentIndex) {
            // Determine items to move
            let itemsToMove = [];
            // Check if dragged item is in selected items AND we have multiple selections
            if (this.selection() && this.selection().length > 1 && findIndexInList(event.item.data, this.selection()) !== -1) {
                // Multi-selection: Move all selected items
                itemsToMove = [...this.selection()];
                // For multi-selection, restore original state to undo Listbox's automatic reordering
                const currentValue = this.value();
                if (currentValue) {
                    currentValue.length = 0;
                    currentValue.push(...originalValue);
                }
                if (originalVisibleOptions && this.visibleOptions) {
                    this.visibleOptions.length = 0;
                    this.visibleOptions.push(...originalVisibleOptions);
                }
                // Sort items by their index in the array to maintain relative order
                itemsToMove = this.sortByIndexInList(itemsToMove, this.value() || []);
                // Calculate how many selected items are before the drop position
                let itemsBefore = 0;
                for (const item of itemsToMove) {
                    const itemIndex = findIndexInList(item, this.value() || []);
                    if (itemIndex !== -1 && itemIndex < currentIndex) {
                        itemsBefore++;
                    }
                }
                // Remove all selected items (in reverse order to avoid index shifting)
                for (let i = itemsToMove.length - 1; i >= 0; i--) {
                    const itemIndex = findIndexInList(itemsToMove[i], this.value() || []);
                    if (itemIndex !== -1) {
                        this.value()?.splice(itemIndex, 1);
                    }
                }
                // Calculate the final target index
                // If we're dragging down, we need to subtract the number of items that were before the target
                const targetIndex = Math.max(0, currentIndex - itemsBefore);
                // Insert all selected items at the target position
                for (let i = 0; i < itemsToMove.length; i++) {
                    this.value()?.splice(targetIndex + i, 0, itemsToMove[i]);
                }
                // Update visibleOptions to match value
                if (this.dragdrop()) {
                    if (this.filterValue) {
                        this.filter();
                    }
                    else if (this.visibleOptions) {
                        this.visibleOptions = [...(this.value() || [])];
                    }
                }
                // Ensure change detection runs
                this.cd?.markForCheck();
                this.onReorder.emit(itemsToMove);
            }
            else {
                // Single item: Move only the dragged item (let Listbox handle it)
                itemsToMove = [event.item.data];
                if (this.filterValue) {
                    previousIndex = findIndexInList(event.item.data, this.value() || []);
                    currentIndex = findIndexInList(this.visibleOptions?.[currentIndex], this.value() || []);
                }
                moveItemInArray(this.value(), previousIndex, currentIndex);
                // Sync visibleOptions for non-filtered case
                if (this.dragdrop() && this.visibleOptions && !this.filterValue) {
                    this.visibleOptions = [...(this.value() || [])];
                }
                this.onReorder.emit([event.item.data]);
            }
        }
    }
    // Helper method to sort items by their index in a list
    sortByIndexInList(items, list) {
        return items.sort((a, b) => {
            const indexA = findIndexInList(a, list);
            const indexB = findIndexInList(b, list);
            return indexA - indexB;
        });
    }
    onListFocus(event) {
        this.onFocus.emit(event);
    }
    onListBlur(event) {
        this.onBlur.emit(event);
    }
    getVisibleOptions() {
        const value = this.value();
        return this.visibleOptions && this.visibleOptions.length > 0 ? this.visibleOptions : value && value.length > 0 ? value : null;
    }
    moveDisabled() {
        if (this.disabled() || !this.selection().length) {
            return true;
        }
    }
    createStyle() {
        if (isPlatformBrowser(this.platformId)) {
            if (!this.styleElement) {
                this.renderer.setAttribute(this.el.nativeElement.children[0], this.id, '');
                this.styleElement = this.renderer.createElement('style');
                this.renderer.setAttribute(this.styleElement, 'type', 'text/css');
                setAttribute(this.styleElement, 'nonce', this.config?.csp()?.nonce);
                this.renderer.appendChild(this.document.head, this.styleElement);
                let innerHTML = `
                    @media screen and (max-width: ${this.breakpoint()}) {
                        .p-orderlist[${this.$attrSelector}] {
                            flex-direction: column;
                        }

                        .p-orderlist[${this.$attrSelector}] .p-orderlist-controls {
                            padding: var(--content-padding);
                            flex-direction: row;
                        }

                        .p-orderlist[${this.$attrSelector}] .p-orderlist-controls .p-button {
                            margin-right: var(--inline-spacing);
                            margin-bottom: 0;
                        }

                        .p-orderlist[${this.$attrSelector}] .p-orderlist-controls .p-button:last-child {
                            margin-right: 0;
                        }
                    }
                `;
                this.renderer.setProperty(this.styleElement, 'innerHTML', innerHTML);
                setAttribute(this.styleElement, 'nonce', this.config?.csp()?.nonce);
            }
        }
    }
    destroyStyle() {
        if (isPlatformBrowser(this.platformId)) {
            if (this.styleElement) {
                this.renderer.removeChild(this.document, this.styleElement);
                this.styleElement = null;
            }
        }
    }
    onDestroy() {
        this.destroyStyle();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OrderList, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: OrderList, isStandalone: true, selector: "p-orderList, p-orderlist, p-order-list", inputs: { header: { classPropertyName: "header", publicName: "header", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, listStyle: { classPropertyName: "listStyle", publicName: "listStyle", isSignal: true, isRequired: false, transformFunction: null }, responsive: { classPropertyName: "responsive", publicName: "responsive", isSignal: true, isRequired: false, transformFunction: null }, filterBy: { classPropertyName: "filterBy", publicName: "filterBy", isSignal: true, isRequired: false, transformFunction: null }, filterPlaceholder: { classPropertyName: "filterPlaceholder", publicName: "filterPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, filterLocale: { classPropertyName: "filterLocale", publicName: "filterLocale", isSignal: true, isRequired: false, transformFunction: null }, metaKeySelection: { classPropertyName: "metaKeySelection", publicName: "metaKeySelection", isSignal: true, isRequired: false, transformFunction: null }, dragdrop: { classPropertyName: "dragdrop", publicName: "dragdrop", isSignal: true, isRequired: false, transformFunction: null }, controlsPosition: { classPropertyName: "controlsPosition", publicName: "controlsPosition", isSignal: true, isRequired: false, transformFunction: null }, ariaFilterLabel: { classPropertyName: "ariaFilterLabel", publicName: "ariaFilterLabel", isSignal: true, isRequired: false, transformFunction: null }, filterMatchMode: { classPropertyName: "filterMatchMode", publicName: "filterMatchMode", isSignal: true, isRequired: false, transformFunction: null }, breakpoint: { classPropertyName: "breakpoint", publicName: "breakpoint", isSignal: true, isRequired: false, transformFunction: null }, stripedRows: { classPropertyName: "stripedRows", publicName: "stripedRows", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, trackBy: { classPropertyName: "trackBy", publicName: "trackBy", isSignal: true, isRequired: false, transformFunction: null }, scrollHeight: { classPropertyName: "scrollHeight", publicName: "scrollHeight", isSignal: true, isRequired: false, transformFunction: null }, autoOptionFocus: { classPropertyName: "autoOptionFocus", publicName: "autoOptionFocus", isSignal: true, isRequired: false, transformFunction: null }, dataKey: { classPropertyName: "dataKey", publicName: "dataKey", isSignal: true, isRequired: false, transformFunction: null }, selection: { classPropertyName: "selection", publicName: "selection", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, buttonProps: { classPropertyName: "buttonProps", publicName: "buttonProps", isSignal: true, isRequired: false, transformFunction: null }, moveUpButtonProps: { classPropertyName: "moveUpButtonProps", publicName: "moveUpButtonProps", isSignal: true, isRequired: false, transformFunction: null }, moveTopButtonProps: { classPropertyName: "moveTopButtonProps", publicName: "moveTopButtonProps", isSignal: true, isRequired: false, transformFunction: null }, moveDownButtonProps: { classPropertyName: "moveDownButtonProps", publicName: "moveDownButtonProps", isSignal: true, isRequired: false, transformFunction: null }, moveBottomButtonProps: { classPropertyName: "moveBottomButtonProps", publicName: "moveBottomButtonProps", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selection: "selectionChange", onReorder: "onReorder", onSelectionChange: "onSelectionChange", onFilterEvent: "onFilterEvent", onFocus: "onFocus", onBlur: "onBlur" }, host: { properties: { "class": "cn(cx('root'), styleClass())" } }, providers: [OrderListStyle, { provide: ORDERLIST_INSTANCE, useExisting: OrderList }, { provide: PARENT_INSTANCE, useExisting: OrderList }], queries: [{ propertyName: "moveUpIconTemplate", first: true, predicate: ["moveupicon"], isSignal: true }, { propertyName: "moveTopIconTemplate", first: true, predicate: ["movetopicon"], isSignal: true }, { propertyName: "moveDownIconTemplate", first: true, predicate: ["movedownicon"], isSignal: true }, { propertyName: "moveBottomIconTemplate", first: true, predicate: ["movebottomicon"], isSignal: true }, { propertyName: "templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "itemTemplate", first: true, predicate: ["item"] }, { propertyName: "emptyMessageTemplate", first: true, predicate: ["empty"] }, { propertyName: "emptyFilterMessageTemplate", first: true, predicate: ["emptyfilter"] }, { propertyName: "filterTemplate", first: true, predicate: ["filter"] }, { propertyName: "headerTemplate", first: true, predicate: ["header"] }, { propertyName: "filterIconTemplate", first: true, predicate: ["filtericon"] }], viewQueries: [{ propertyName: "listViewChild", first: true, predicate: ["listelement"], descendants: true, isSignal: true }, { propertyName: "filterViewChild", first: true, predicate: ["filter"], descendants: true, isSignal: true }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        <div [pBind]="ptm('controls')" [class]="cx('controls')">
            <button [pt]="ptm('pcMoveUpButton')" type="button" [disabled]="moveDisabled()" pButton pRipple (click)="moveUp()" [attr.aria-label]="moveUpAriaLabel" [buttonProps]="getButtonProps('up')" hostName="orderlist" [unstyled]="unstyled()">
                @if (!moveUpIconTemplate() && !_moveUpIconTemplate) {
                    <svg data-p-icon="angle-up" pButtonIcon [pt]="ptm('pcMoveUpButton')['icon']" />
                }
                <ng-template *ngTemplateOutlet="moveUpIconTemplate() || _moveUpIconTemplate"></ng-template>
            </button>
            <button [pt]="ptm('pcMoveTopButton')" type="button" [disabled]="moveDisabled()" pButton pRipple (click)="moveTop()" [attr.aria-label]="moveTopAriaLabel" [buttonProps]="getButtonProps('top')" hostName="orderlist" [unstyled]="unstyled()">
                @if (!moveTopIconTemplate() && !_moveTopIconTemplate) {
                    <svg data-p-icon="angle-double-up" pButtonIcon [pt]="ptm('pcMoveTopButton')['icon']" />
                }
                <ng-template *ngTemplateOutlet="moveTopIconTemplate() || _moveTopIconTemplate"></ng-template>
            </button>
            <button
                [pt]="ptm('pcMoveDownButton')"
                type="button"
                [disabled]="moveDisabled()"
                pButton
                pRipple
                (click)="moveDown()"
                [attr.aria-label]="moveDownAriaLabel"
                [buttonProps]="getButtonProps('down')"
                hostName="orderlist"
                [unstyled]="unstyled()"
            >
                @if (!moveDownIconTemplate() && !_moveDownIconTemplate) {
                    <svg data-p-icon="angle-down" pButtonIcon [pt]="ptm('pcMoveDownButton')['icon']" />
                }
                <ng-template *ngTemplateOutlet="moveDownIconTemplate() || _moveDownIconTemplate"></ng-template>
            </button>
            <button
                [pt]="ptm('pcMoveBottomButton')"
                type="button"
                [disabled]="moveDisabled()"
                pButton
                pRipple
                (click)="moveBottom()"
                [attr.aria-label]="moveBottomAriaLabel"
                [buttonProps]="getButtonProps('bottom')"
                hostName="orderlist"
                [unstyled]="unstyled()"
            >
                @if (!moveBottomIconTemplate() && !_moveBottomIconTemplate) {
                    <svg data-p-icon="angle-double-down" pButtonIcon [pt]="ptm('pcMoveBottomButton')['icon']" />
                }
                <ng-template *ngTemplateOutlet="moveBottomIconTemplate() || _moveBottomIconTemplate"></ng-template>
            </button>
        </div>
        <p-listbox
            [pt]="ptm('pcListbox')"
            #listelement
            [multiple]="true"
            [options]="value()"
            [(ngModel)]="d_selection"
            [optionLabel]="dataKey() ?? 'name'"
            [id]="id + '_list'"
            [listStyle]="listStyle()"
            [striped]="stripedRows()"
            [tabindex]="tabindex()"
            (onFocus)="onListFocus($event)"
            (onBlur)="onListBlur($event)"
            (onChange)="onChangeSelection($event)"
            [ariaLabel]="ariaLabel()"
            [disabled]="disabled()"
            [metaKeySelection]="metaKeySelection()"
            [scrollHeight]="scrollHeight()"
            [autoOptionFocus]="autoOptionFocus()"
            [filter]="filterBy()"
            [filterBy]="filterBy()"
            [filterLocale]="filterLocale()"
            [filterPlaceHolder]="filterPlaceholder()"
            [dragdrop]="dragdrop()"
            (onDrop)="onDrop($event)"
            hostName="orderlist"
            [unstyled]="unstyled()"
        >
            @if (headerTemplate || _headerTemplate) {
                <ng-template #header>
                    <ng-template *ngTemplateOutlet="headerTemplate || _headerTemplate"></ng-template>
                </ng-template>
            }
            @if (itemTemplate || _itemTemplate) {
                <ng-template #item let-option let-selected="selected" let-index="index">
                    <ng-template *ngTemplateOutlet="itemTemplate || _itemTemplate; context: { $implicit: option, selected: selected, index: index }"></ng-template>
                </ng-template>
            }
            @if (emptyMessageTemplate || _emptyMessageTemplate) {
                <ng-template #empty>
                    <ng-template *ngTemplateOutlet="emptyMessageTemplate || _emptyMessageTemplate"></ng-template>
                </ng-template>
            }
            @if (emptyFilterMessageTemplate || _emptyFilterMessageTemplate) {
                <ng-template #emptyfilter>
                    <ng-template *ngTemplateOutlet="emptyFilterMessageTemplate || _emptyFilterMessageTemplate"></ng-template>
                </ng-template>
            }
            @if (filterIconTemplate || _filterIconTemplate) {
                <ng-template #filtericon>
                    <ng-template *ngTemplateOutlet="filterIconTemplate || _filterIconTemplate"></ng-template>
                </ng-template>
            }
            @if (filterTemplate || _filterTemplate) {
                <ng-template #filter let-options="options">
                    <ng-template *ngTemplateOutlet="filterTemplate || _filterTemplate; context: { options: options }"></ng-template>
                </ng-template>
            }
        </p-listbox>
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: ButtonModule }, { kind: "directive", type: i3.ButtonDirective, selector: "[pButton]", inputs: ["ptButtonDirective", "pButtonPT", "pButtonUnstyled", "hostName", "text", "plain", "raised", "size", "outlined", "rounded", "iconPos", "loadingIcon", "fluid", "label", "icon", "loading", "buttonProps", "severity"] }, { kind: "directive", type: i3.ButtonIcon, selector: "[pButtonIcon]", inputs: ["ptButtonIcon", "pButtonIconPT", "pButtonUnstyled"] }, { kind: "directive", type: Ripple, selector: "[pRipple]" }, { kind: "ngmodule", type: DragDropModule }, { kind: "component", type: AngleDoubleDownIcon, selector: "[data-p-icon=\"angle-double-down\"]" }, { kind: "component", type: AngleDoubleUpIcon, selector: "[data-p-icon=\"angle-double-up\"]" }, { kind: "component", type: AngleUpIcon, selector: "[data-p-icon=\"angle-up\"]" }, { kind: "component", type: AngleDownIcon, selector: "[data-p-icon=\"angle-down\"]" }, { kind: "component", type: Listbox, selector: "p-listbox, p-listBox, p-list-box", inputs: ["hostName", "id", "searchMessage", "emptySelectionMessage", "selectionMessage", "autoOptionFocus", "ariaLabel", "selectOnFocus", "searchLocale", "focusOnHover", "filterMessage", "filterFields", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "scrollHeight", "tabindex", "multiple", "styleClass", "listStyle", "listStyleClass", "readonly", "checkbox", "filter", "filterBy", "filterMatchMode", "filterLocale", "metaKeySelection", "dataKey", "showToggleAll", "optionLabel", "optionValue", "optionGroupChildren", "optionGroupLabel", "optionDisabled", "ariaFilterLabel", "filterPlaceHolder", "emptyFilterMessage", "emptyMessage", "group", "options", "filterValue", "selectAll", "striped", "highlightOnSelect", "checkmark", "dragdrop", "dropListData", "fluid"], outputs: ["onChange", "onClick", "onDblClick", "onFilter", "onFocus", "onBlur", "onSelectAllChange", "onLazyLoad", "onDrop"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i4.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i4.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: SharedModule }, { kind: "directive", type: Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OrderList, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-orderList, p-orderlist, p-order-list',
                    standalone: true,
                    imports: [CommonModule, ButtonModule, Ripple, DragDropModule, AngleDoubleDownIcon, AngleDoubleUpIcon, AngleUpIcon, AngleDownIcon, Listbox, FormsModule, SharedModule, Bind],
                    template: `
        <div [pBind]="ptm('controls')" [class]="cx('controls')">
            <button [pt]="ptm('pcMoveUpButton')" type="button" [disabled]="moveDisabled()" pButton pRipple (click)="moveUp()" [attr.aria-label]="moveUpAriaLabel" [buttonProps]="getButtonProps('up')" hostName="orderlist" [unstyled]="unstyled()">
                @if (!moveUpIconTemplate() && !_moveUpIconTemplate) {
                    <svg data-p-icon="angle-up" pButtonIcon [pt]="ptm('pcMoveUpButton')['icon']" />
                }
                <ng-template *ngTemplateOutlet="moveUpIconTemplate() || _moveUpIconTemplate"></ng-template>
            </button>
            <button [pt]="ptm('pcMoveTopButton')" type="button" [disabled]="moveDisabled()" pButton pRipple (click)="moveTop()" [attr.aria-label]="moveTopAriaLabel" [buttonProps]="getButtonProps('top')" hostName="orderlist" [unstyled]="unstyled()">
                @if (!moveTopIconTemplate() && !_moveTopIconTemplate) {
                    <svg data-p-icon="angle-double-up" pButtonIcon [pt]="ptm('pcMoveTopButton')['icon']" />
                }
                <ng-template *ngTemplateOutlet="moveTopIconTemplate() || _moveTopIconTemplate"></ng-template>
            </button>
            <button
                [pt]="ptm('pcMoveDownButton')"
                type="button"
                [disabled]="moveDisabled()"
                pButton
                pRipple
                (click)="moveDown()"
                [attr.aria-label]="moveDownAriaLabel"
                [buttonProps]="getButtonProps('down')"
                hostName="orderlist"
                [unstyled]="unstyled()"
            >
                @if (!moveDownIconTemplate() && !_moveDownIconTemplate) {
                    <svg data-p-icon="angle-down" pButtonIcon [pt]="ptm('pcMoveDownButton')['icon']" />
                }
                <ng-template *ngTemplateOutlet="moveDownIconTemplate() || _moveDownIconTemplate"></ng-template>
            </button>
            <button
                [pt]="ptm('pcMoveBottomButton')"
                type="button"
                [disabled]="moveDisabled()"
                pButton
                pRipple
                (click)="moveBottom()"
                [attr.aria-label]="moveBottomAriaLabel"
                [buttonProps]="getButtonProps('bottom')"
                hostName="orderlist"
                [unstyled]="unstyled()"
            >
                @if (!moveBottomIconTemplate() && !_moveBottomIconTemplate) {
                    <svg data-p-icon="angle-double-down" pButtonIcon [pt]="ptm('pcMoveBottomButton')['icon']" />
                }
                <ng-template *ngTemplateOutlet="moveBottomIconTemplate() || _moveBottomIconTemplate"></ng-template>
            </button>
        </div>
        <p-listbox
            [pt]="ptm('pcListbox')"
            #listelement
            [multiple]="true"
            [options]="value()"
            [(ngModel)]="d_selection"
            [optionLabel]="dataKey() ?? 'name'"
            [id]="id + '_list'"
            [listStyle]="listStyle()"
            [striped]="stripedRows()"
            [tabindex]="tabindex()"
            (onFocus)="onListFocus($event)"
            (onBlur)="onListBlur($event)"
            (onChange)="onChangeSelection($event)"
            [ariaLabel]="ariaLabel()"
            [disabled]="disabled()"
            [metaKeySelection]="metaKeySelection()"
            [scrollHeight]="scrollHeight()"
            [autoOptionFocus]="autoOptionFocus()"
            [filter]="filterBy()"
            [filterBy]="filterBy()"
            [filterLocale]="filterLocale()"
            [filterPlaceHolder]="filterPlaceholder()"
            [dragdrop]="dragdrop()"
            (onDrop)="onDrop($event)"
            hostName="orderlist"
            [unstyled]="unstyled()"
        >
            @if (headerTemplate || _headerTemplate) {
                <ng-template #header>
                    <ng-template *ngTemplateOutlet="headerTemplate || _headerTemplate"></ng-template>
                </ng-template>
            }
            @if (itemTemplate || _itemTemplate) {
                <ng-template #item let-option let-selected="selected" let-index="index">
                    <ng-template *ngTemplateOutlet="itemTemplate || _itemTemplate; context: { $implicit: option, selected: selected, index: index }"></ng-template>
                </ng-template>
            }
            @if (emptyMessageTemplate || _emptyMessageTemplate) {
                <ng-template #empty>
                    <ng-template *ngTemplateOutlet="emptyMessageTemplate || _emptyMessageTemplate"></ng-template>
                </ng-template>
            }
            @if (emptyFilterMessageTemplate || _emptyFilterMessageTemplate) {
                <ng-template #emptyfilter>
                    <ng-template *ngTemplateOutlet="emptyFilterMessageTemplate || _emptyFilterMessageTemplate"></ng-template>
                </ng-template>
            }
            @if (filterIconTemplate || _filterIconTemplate) {
                <ng-template #filtericon>
                    <ng-template *ngTemplateOutlet="filterIconTemplate || _filterIconTemplate"></ng-template>
                </ng-template>
            }
            @if (filterTemplate || _filterTemplate) {
                <ng-template #filter let-options="options">
                    <ng-template *ngTemplateOutlet="filterTemplate || _filterTemplate; context: { options: options }"></ng-template>
                </ng-template>
            }
        </p-listbox>
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [OrderListStyle, { provide: ORDERLIST_INSTANCE, useExisting: OrderList }, { provide: PARENT_INSTANCE, useExisting: OrderList }],
                    host: {
                        '[class]': "cn(cx('root'), styleClass())"
                    },
                    hostDirectives: [Bind]
                }]
        }], ctorParameters: () => [], propDecorators: { header: [{ type: i0.Input, args: [{ isSignal: true, alias: "header", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], listStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "listStyle", required: false }] }], responsive: [{ type: i0.Input, args: [{ isSignal: true, alias: "responsive", required: false }] }], filterBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterBy", required: false }] }], filterPlaceholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterPlaceholder", required: false }] }], filterLocale: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterLocale", required: false }] }], metaKeySelection: [{ type: i0.Input, args: [{ isSignal: true, alias: "metaKeySelection", required: false }] }], dragdrop: [{ type: i0.Input, args: [{ isSignal: true, alias: "dragdrop", required: false }] }], controlsPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "controlsPosition", required: false }] }], ariaFilterLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaFilterLabel", required: false }] }], filterMatchMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterMatchMode", required: false }] }], breakpoint: [{ type: i0.Input, args: [{ isSignal: true, alias: "breakpoint", required: false }] }], stripedRows: [{ type: i0.Input, args: [{ isSignal: true, alias: "stripedRows", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], trackBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "trackBy", required: false }] }], scrollHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollHeight", required: false }] }], autoOptionFocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoOptionFocus", required: false }] }], dataKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataKey", required: false }] }], selection: [{ type: i0.Input, args: [{ isSignal: true, alias: "selection", required: false }] }, { type: i0.Output, args: ["selectionChange"] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], buttonProps: [{ type: i0.Input, args: [{ isSignal: true, alias: "buttonProps", required: false }] }], moveUpButtonProps: [{ type: i0.Input, args: [{ isSignal: true, alias: "moveUpButtonProps", required: false }] }], moveTopButtonProps: [{ type: i0.Input, args: [{ isSignal: true, alias: "moveTopButtonProps", required: false }] }], moveDownButtonProps: [{ type: i0.Input, args: [{ isSignal: true, alias: "moveDownButtonProps", required: false }] }], moveBottomButtonProps: [{ type: i0.Input, args: [{ isSignal: true, alias: "moveBottomButtonProps", required: false }] }], onReorder: [{ type: i0.Output, args: ["onReorder"] }], onSelectionChange: [{ type: i0.Output, args: ["onSelectionChange"] }], onFilterEvent: [{ type: i0.Output, args: ["onFilterEvent"] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], listViewChild: [{ type: i0.ViewChild, args: ['listelement', { isSignal: true }] }], filterViewChild: [{ type: i0.ViewChild, args: ['filter', { isSignal: true }] }], itemTemplate: [{
                type: ContentChild,
                args: ['item', { descendants: false }]
            }], emptyMessageTemplate: [{
                type: ContentChild,
                args: ['empty', { descendants: false }]
            }], emptyFilterMessageTemplate: [{
                type: ContentChild,
                args: ['emptyfilter', { descendants: false }]
            }], filterTemplate: [{
                type: ContentChild,
                args: ['filter', { descendants: false }]
            }], headerTemplate: [{
                type: ContentChild,
                args: ['header', { descendants: false }]
            }], moveUpIconTemplate: [{ type: i0.ContentChild, args: ['moveupicon', { ...{ descendants: false }, isSignal: true }] }], moveTopIconTemplate: [{ type: i0.ContentChild, args: ['movetopicon', { ...{ descendants: false }, isSignal: true }] }], moveDownIconTemplate: [{ type: i0.ContentChild, args: ['movedownicon', { ...{ descendants: false }, isSignal: true }] }], moveBottomIconTemplate: [{ type: i0.ContentChild, args: ['movebottomicon', { ...{ descendants: false }, isSignal: true }] }], filterIconTemplate: [{
                type: ContentChild,
                args: ['filtericon', { descendants: false }]
            }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class OrderListModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OrderListModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: OrderListModule, imports: [OrderList, SharedModule], exports: [OrderList, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OrderListModule, imports: [OrderList, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OrderListModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [OrderList, SharedModule],
                    exports: [OrderList, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { OrderList, OrderListClasses, OrderListModule, OrderListStyle };
//# sourceMappingURL=wawjs-ngx-prime-orderlist.mjs.map
