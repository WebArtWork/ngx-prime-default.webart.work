import { isPlatformBrowser } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, ElementRef, NgZone, input, booleanAttribute, output, effect, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import Chart from 'chart.js/auto';
import { SharedModule } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind, BindModule } from '@wawjs/ngx-prime/bind';

const inlineStyles = {
    root: ({ instance }) => ({ display: 'block', position: 'relative', width: instance.width(), height: instance.height() })
};
const classes = {
    root: 'p-chart'
};
class ChartStyle extends BaseStyle {
    name = 'chart';
    classes = classes;
    inlineStyles = inlineStyles;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ChartStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ChartStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ChartStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * Chart groups a collection of contents in tabs.
 *
 * [Live Demo](https://www.ngx-prime.org/chart/)
 *
 * @module chartstyle
 *
 */
var ChartClasses;
(function (ChartClasses) {
    /**
     * Class name of the root element
     */
    ChartClasses["root"] = "p-chart";
})(ChartClasses || (ChartClasses = {}));

const CHART_INSTANCE = new InjectionToken('CHART_INSTANCE');
/**
 * Chart groups a collection of contents in tabs.
 * @group Components
 */
class UIChart extends BaseComponent {
    el = inject(ElementRef);
    zone = inject(NgZone);
    componentName = 'Chart';
    $pcChart = inject(CHART_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    /**
     * Type of the chart.
     * @group Props
     */
    type = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "type" }] : /* istanbul ignore next */ []));
    /**
     * Array of per-chart plugins to customize the chart behaviour.
     * @group Props
     */
    plugins = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "plugins" }] : /* istanbul ignore next */ []));
    /**
     * Width of the chart.
     * @group Props
     */
    width = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "width" }] : /* istanbul ignore next */ []));
    /**
     * Height of the chart.
     * @group Props
     */
    height = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "height" }] : /* istanbul ignore next */ []));
    /**
     * Whether the chart is redrawn on screen size change.
     * @group Props
     */
    responsive = input(true, { ...(ngDevMode ? { debugName: "responsive" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Used to define a string that autocomplete attribute the current element.
     * @group Props
     */
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    /**
     * Data to display.
     * @group Props
     */
    data = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "data" }] : /* istanbul ignore next */ []));
    /**
     * Options to customize the chart.
     * @group Props
     */
    options = input({}, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    /**
     * Callback to execute when an element on chart is clicked.
     * @group Emits
     */
    onDataSelect = output();
    isBrowser = false;
    initialized;
    chart;
    _componentStyle = inject(ChartStyle);
    constructor() {
        super();
        effect(() => {
            this.data();
            this.options();
            this.reinit();
        });
    }
    onAfterViewInit() {
        this.initChart();
        this.initialized = true;
    }
    onCanvasClick(event) {
        if (this.chart) {
            const element = this.chart.getElementsAtEventForMode(event, 'nearest', { intersect: true }, false);
            const dataset = this.chart.getElementsAtEventForMode(event, 'dataset', { intersect: true }, false);
            if (element && element[0] && dataset) {
                this.onDataSelect.emit({ originalEvent: event, element: element[0], dataset: dataset });
            }
        }
    }
    initChart() {
        if (isPlatformBrowser(this.platformId)) {
            let opts = this.options() || {};
            opts.responsive = this.responsive();
            // allows chart to resize in responsive mode
            if (opts.responsive && (this.height() || this.width())) {
                opts.maintainAspectRatio = false;
            }
            this.zone.runOutsideAngular(() => {
                this.chart = new Chart(this.el.nativeElement.children[0], {
                    type: this.type(),
                    data: this.data(),
                    options: this.options(),
                    plugins: this.plugins()
                });
            });
        }
    }
    getCanvas() {
        return this.el.nativeElement.children[0];
    }
    getBase64Image() {
        return this.chart.toBase64Image();
    }
    generateLegend() {
        if (this.chart) {
            return this.chart.generateLegend();
        }
    }
    refresh() {
        if (this.chart) {
            this.chart.update();
        }
    }
    reinit() {
        if (this.chart) {
            this.chart.destroy();
            this.initChart();
        }
    }
    onDestroy() {
        if (this.chart) {
            this.chart.destroy();
            this.initialized = false;
            this.chart = null;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: UIChart, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.2", type: UIChart, isStandalone: true, selector: "p-chart", inputs: { type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, plugins: { classPropertyName: "plugins", publicName: "plugins", isSignal: true, isRequired: false, transformFunction: null }, width: { classPropertyName: "width", publicName: "width", isSignal: true, isRequired: false, transformFunction: null }, height: { classPropertyName: "height", publicName: "height", isSignal: true, isRequired: false, transformFunction: null }, responsive: { classPropertyName: "responsive", publicName: "responsive", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, data: { classPropertyName: "data", publicName: "data", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onDataSelect: "onDataSelect" }, host: { properties: { "class": "cx('root')", "style": "sx('root')" } }, providers: [ChartStyle, { provide: CHART_INSTANCE, useExisting: UIChart }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        <canvas
            role="img"
            [attr.aria-label]="ariaLabel()"
            [attr.aria-labelledby]="ariaLabelledBy()"
            [attr.width]="responsive() && !width() ? null : width()"
            [attr.height]="responsive() && !height() ? null : height()"
            (click)="onCanvasClick($event)"
            [pBind]="ptm('canvas')"
        ></canvas>
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: BindModule }, { kind: "directive", type: i1.Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: UIChart, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-chart',
                    standalone: true,
                    imports: [SharedModule, BindModule],
                    template: `
        <canvas
            role="img"
            [attr.aria-label]="ariaLabel()"
            [attr.aria-labelledby]="ariaLabelledBy()"
            [attr.width]="responsive() && !width() ? null : width()"
            [attr.height]="responsive() && !height() ? null : height()"
            (click)="onCanvasClick($event)"
            [pBind]="ptm('canvas')"
        ></canvas>
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class]': "cx('root')",
                        '[style]': "sx('root')"
                    },
                    providers: [ChartStyle, { provide: CHART_INSTANCE, useExisting: UIChart }],
                    hostDirectives: [Bind]
                }]
        }], ctorParameters: () => [], propDecorators: { type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], plugins: [{ type: i0.Input, args: [{ isSignal: true, alias: "plugins", required: false }] }], width: [{ type: i0.Input, args: [{ isSignal: true, alias: "width", required: false }] }], height: [{ type: i0.Input, args: [{ isSignal: true, alias: "height", required: false }] }], responsive: [{ type: i0.Input, args: [{ isSignal: true, alias: "responsive", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], data: [{ type: i0.Input, args: [{ isSignal: true, alias: "data", required: false }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], onDataSelect: [{ type: i0.Output, args: ["onDataSelect"] }] } });
class ChartModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ChartModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: ChartModule, imports: [UIChart, SharedModule], exports: [UIChart, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ChartModule, imports: [UIChart, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ChartModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [UIChart, SharedModule],
                    exports: [UIChart, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { ChartClasses, ChartModule, ChartStyle, UIChart };
//# sourceMappingURL=wawjs-ngx-prime-chart.mjs.map
