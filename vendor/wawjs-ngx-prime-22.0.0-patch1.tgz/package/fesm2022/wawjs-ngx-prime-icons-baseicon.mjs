import * as i0 from '@angular/core';
import { Injectable, input, booleanAttribute, inject, ViewEncapsulation, ChangeDetectionStrategy, Component } from '@angular/core';
import { cn } from '@wawjs/css-prime-utils';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const css = /*css*/ `
.p-icon {
    display: inline-block;
    vertical-align: baseline;
    flex-shrink: 0;
}

.p-icon-spin {
    -webkit-animation: p-icon-spin 2s infinite linear;
    animation: p-icon-spin 2s infinite linear;
}

@-webkit-keyframes p-icon-spin {
    0% {
        -webkit-transform: rotate(0deg);
        transform: rotate(0deg);
    }
    100% {
        -webkit-transform: rotate(359deg);
        transform: rotate(359deg);
    }
}

@keyframes p-icon-spin {
    0% {
        -webkit-transform: rotate(0deg);
        transform: rotate(0deg);
    }
    100% {
        -webkit-transform: rotate(359deg);
        transform: rotate(359deg);
    }
}
`;
class BaseIconStyle extends BaseStyle {
    name = 'baseicon';
    css = css;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BaseIconStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BaseIconStyle, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BaseIconStyle, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });
/**
 *
 * [Live Demo](https://www.ngx-prime.org/)
 *
 * @module baseiconstyle
 *
 */
var BaseIconClasses;
(function (BaseIconClasses) {
    BaseIconClasses["root"] = "p-icon";
})(BaseIconClasses || (BaseIconClasses = {}));

class BaseIcon extends BaseComponent {
    spin = input(false, { ...(ngDevMode ? { debugName: "spin" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    _componentStyle = inject(BaseIconStyle);
    getClassNames() {
        return cn('p-icon', {
            'p-icon-spin': this.spin()
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BaseIcon, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.2", type: BaseIcon, isStandalone: true, selector: "ng-component", inputs: { spin: { classPropertyName: "spin", publicName: "spin", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "width": "14", "height": "14", "viewBox": "0 0 14 14", "fill": "none", "xmlns": "http://www.w3.org/2000/svg" }, properties: { "class": "getClassNames()" } }, providers: [BaseIconStyle], usesInheritance: true, ngImport: i0, template: ` <ng-content></ng-content> `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BaseIcon, decorators: [{
            type: Component,
            args: [{
                    template: ` <ng-content></ng-content> `,
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [BaseIconStyle],
                    host: {
                        width: '14',
                        height: '14',
                        viewBox: '0 0 14 14',
                        fill: 'none',
                        xmlns: 'http://www.w3.org/2000/svg',
                        '[class]': 'getClassNames()'
                    }
                }]
        }], propDecorators: { spin: [{ type: i0.Input, args: [{ isSignal: true, alias: "spin", required: false }] }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { BaseIcon, BaseIconClasses, BaseIconStyle };
//# sourceMappingURL=wawjs-ngx-prime-icons-baseicon.mjs.map
