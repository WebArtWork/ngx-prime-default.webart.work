export * from '@wawjs/ngx-prime/types/blockui';
import * as i2 from '@angular/common';
import { isPlatformBrowser, CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, input, booleanAttribute, numberAttribute, effect, contentChildren, ContentChild, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { PrimeTemplate, SharedModule } from '@wawjs/ngx-prime/api';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { blockBodyScroll, unblockBodyScroll } from '@wawjs/ngx-prime/dom';
import { ZIndexUtils } from '@wawjs/ngx-prime/utils';
import { style } from '@wawjs/css-prime-styles/blockui';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const classes = {
    root: ({ instance }) => [
        'p-blockui p-blockui-mask',
        {
            'p-blockui-mask-document': !instance.target()
        }
    ]
};
class BlockUiStyle extends BaseStyle {
    name = 'blockui';
    style = style;
    classes = classes;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BlockUiStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BlockUiStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BlockUiStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * BlockUI represents people using icons, labels and images.
 *
 * [Live Demo](https://www.ngx-prime.org/blockui)
 *
 * @module blockuistyle
 *
 */
var BlockUIClasses;
(function (BlockUIClasses) {
    /**
     * Class name of the root element
     */
    BlockUIClasses["root"] = "p-blockui";
})(BlockUIClasses || (BlockUIClasses = {}));

const BLOCKUI_INSTANCE = new InjectionToken('BLOCKUI_INSTANCE');
/**
 * BlockUI can either block other components or the whole page.
 * @group Components
 */
class BlockUI extends BaseComponent {
    componentName = 'BlockUI';
    $pcBlockUI = inject(BLOCKUI_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    /**
     * Name of the local ng-template variable referring to another component.
     * @group Props
     */
    target = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "target" }] : /* istanbul ignore next */ []));
    /**
     * Whether to automatically manage layering.
     * @group Props
     */
    autoZIndex = input(true, { ...(ngDevMode ? { debugName: "autoZIndex" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Base zIndex value to use in layering.
     * @group Props
     */
    baseZIndex = input(0, { ...(ngDevMode ? { debugName: "baseZIndex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Current blocked state as a boolean.
     * @group Props
     */
    blocked = input(false, { ...(ngDevMode ? { debugName: "blocked" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * template of the content
     * @group Templates
     */
    contentTemplate;
    _blocked = false;
    animationEndListener;
    _componentStyle = inject(BlockUiStyle);
    constructor() {
        super();
        effect(() => {
            const val = this.blocked();
            if (this.el && this.el.nativeElement) {
                if (val) {
                    this.block();
                }
                else if (this._blocked) {
                    // Only unblock if currently blocked
                    this.unblock();
                }
            }
            else {
                this._blocked = val;
            }
        });
    }
    onAfterViewInit() {
        if (this._blocked)
            this.block();
        if (this.target() && !this.target().getBlockableElement) {
            throw 'Target of BlockUI must implement BlockableUI interface';
        }
    }
    _contentTemplate;
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    onAfterContentInit() {
        this.templates().forEach((item) => {
            switch (item.getType()) {
                case 'content':
                    this.contentTemplate = item.template;
                    break;
                default:
                    this.contentTemplate = item.template;
                    break;
            }
        });
    }
    block() {
        if (isPlatformBrowser(this.platformId)) {
            this._blocked = true;
            this.el.nativeElement.style.display = 'flex';
            if (this.target()) {
                this.target()
                    .getBlockableElement()
                    .appendChild(this.el.nativeElement);
                this.target().getBlockableElement().style.position = 'relative';
            }
            else {
                this.renderer.appendChild(this.document.body, this.el.nativeElement);
                blockBodyScroll();
            }
            if (this.autoZIndex()) {
                ZIndexUtils.set('modal', this.el.nativeElement, this.baseZIndex() + this.config.zIndex.modal);
            }
            this.renderer.addClass(this.el.nativeElement, 'p-overlay-mask');
            this.renderer.addClass(this.el.nativeElement, 'p-overlay-mask-enter-active');
        }
    }
    unblock() {
        if (isPlatformBrowser(this.platformId) && this.el && this._blocked) {
            this._blocked = false;
            if (!this.animationEndListener) {
                this.animationEndListener = this.renderer.listen(this.el.nativeElement, 'animationend', this.destroyModal.bind(this));
            }
            this.renderer.removeClass(this.el.nativeElement, 'p-overlay-mask-enter-active');
            this.renderer.addClass(this.el.nativeElement, 'p-overlay-mask-leave-active');
        }
    }
    destroyModal() {
        this._blocked = false;
        if (this.el && isPlatformBrowser(this.platformId)) {
            this.el.nativeElement.style.display = 'none';
            this.renderer.removeClass(this.el.nativeElement, 'p-overlay-mask');
            this.renderer.removeClass(this.el.nativeElement, 'p-overlay-mask-leave-active');
            ZIndexUtils.clear(this.el.nativeElement);
            if (!this.target()) {
                this.document.body.removeChild(this.el.nativeElement);
                unblockBodyScroll();
            }
        }
        this.unbindAnimationEndListener();
        this.cd.markForCheck();
    }
    unbindAnimationEndListener() {
        if (this.animationEndListener && this.el) {
            this.animationEndListener();
            this.animationEndListener = null;
        }
    }
    onDestroy() {
        if (this._blocked) {
            // Skip animation on destroy, just cleanup
            this._blocked = false;
            if (this.el && isPlatformBrowser(this.platformId)) {
                ZIndexUtils.clear(this.el.nativeElement);
                if (!this.target()) {
                    unblockBodyScroll();
                }
            }
            this.unbindAnimationEndListener();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BlockUI, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "22.1.2", type: BlockUI, isStandalone: true, selector: "p-blockUI, p-blockui, p-block-ui", inputs: { target: { classPropertyName: "target", publicName: "target", isSignal: true, isRequired: false, transformFunction: null }, autoZIndex: { classPropertyName: "autoZIndex", publicName: "autoZIndex", isSignal: true, isRequired: false, transformFunction: null }, baseZIndex: { classPropertyName: "baseZIndex", publicName: "baseZIndex", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, blocked: { classPropertyName: "blocked", publicName: "blocked", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.aria-busy": "_blocked", "class": "cn(cx('root'), styleClass())" } }, providers: [BlockUiStyle, { provide: BLOCKUI_INSTANCE, useExisting: BlockUI }, { provide: PARENT_INSTANCE, useExisting: BlockUI }], queries: [{ propertyName: "templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "contentTemplate", first: true, predicate: ["content"] }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        <ng-content></ng-content>
        <ng-container *ngTemplateOutlet="contentTemplate || _contentTemplate"></ng-container>
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: SharedModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BlockUI, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-blockUI, p-blockui, p-block-ui',
                    standalone: true,
                    imports: [CommonModule, SharedModule],
                    template: `
        <ng-content></ng-content>
        <ng-container *ngTemplateOutlet="contentTemplate || _contentTemplate"></ng-container>
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [BlockUiStyle, { provide: BLOCKUI_INSTANCE, useExisting: BlockUI }, { provide: PARENT_INSTANCE, useExisting: BlockUI }],
                    host: {
                        '[attr.aria-busy]': '_blocked',
                        '[class]': "cn(cx('root'), styleClass())"
                    },
                    hostDirectives: [Bind]
                }]
        }], ctorParameters: () => [], propDecorators: { target: [{ type: i0.Input, args: [{ isSignal: true, alias: "target", required: false }] }], autoZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoZIndex", required: false }] }], baseZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "baseZIndex", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], blocked: [{ type: i0.Input, args: [{ isSignal: true, alias: "blocked", required: false }] }], contentTemplate: [{
                type: ContentChild,
                args: ['content', { descendants: false }]
            }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class BlockUIModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BlockUIModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: BlockUIModule, imports: [BlockUI, SharedModule], exports: [BlockUI, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BlockUIModule, imports: [BlockUI, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BlockUIModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [BlockUI, SharedModule],
                    exports: [BlockUI, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { BlockUI, BlockUIClasses, BlockUIModule, BlockUiStyle };
//# sourceMappingURL=wawjs-ngx-prime-blockui.mjs.map
