export * from '@wawjs/ngx-prime/types/carousel';
import * as i2 from '@angular/common';
import { isPlatformBrowser, CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, inject, ElementRef, NgZone, input, booleanAttribute, numberAttribute, output, viewChild, contentChild, effect, contentChildren, ContentChild, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { uuid, setAttribute, find, getAttribute, findSingle, removeClass, addClass } from '@wawjs/css-prime-utils';
import { Header, Footer, PrimeTemplate, SharedModule } from '@wawjs/ngx-prime/api';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind, BindModule } from '@wawjs/ngx-prime/bind';
import * as i3 from '@wawjs/ngx-prime/button';
import { ButtonModule } from '@wawjs/ngx-prime/button';
import { ChevronRightIcon, ChevronLeftIcon, ChevronDownIcon, ChevronUpIcon } from '@wawjs/ngx-prime/icons';
import { style } from '@wawjs/css-prime-styles/carousel';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const classes = {
    root: ({ instance }) => [
        'p-carousel p-component',
        {
            'p-carousel-vertical': instance.isVertical(),
            'p-carousel-horizontal': !instance.isVertical()
        }
    ],
    header: 'p-carousel-header',
    contentContainer: 'p-carousel-content-container',
    content: 'p-carousel-content',
    pcPrevButton: ({ instance }) => [
        'p-carousel-prev-button',
        {
            'p-disabled': instance.isBackwardNavDisabled()
        }
    ],
    viewport: 'p-carousel-viewport',
    itemList: 'p-carousel-item-list',
    itemClone: ({ instance, index }) => [
        'p-carousel-item p-carousel-item-clone',
        {
            'p-carousel-item-active': instance.totalShiftedItems * -1 === instance.value()?.length,
            'p-carousel-item-start': 0 === index,
            'p-carousel-item-end': instance.clonedItemsForStarting.length - 1 === index
        }
    ],
    item: ({ instance, index }) => [
        'p-carousel-item',
        {
            'p-carousel-item-active': instance.firstIndex() <= index && instance.lastIndex() >= index,
            'p-carousel-item-start': instance.firstIndex() === index,
            'p-carousel-item-end': instance.lastIndex() === index
        }
    ],
    pcNextButton: ({ instance }) => [
        'p-carousel-next-button',
        {
            'p-disabled': instance.isForwardNavDisabled()
        }
    ],
    indicatorList: ({ instance }) => ['p-carousel-indicator-list', instance.indicatorsContentClass()],
    indicator: ({ instance, index }) => [
        'p-carousel-indicator',
        {
            'p-carousel-indicator-active': instance._page === index
        }
    ],
    indicatorButton: ({ instance }) => ['p-carousel-indicator-button', instance.indicatorStyleClass()],
    footer: 'p-carousel-footer'
};
class CarouselStyle extends BaseStyle {
    name = 'carousel';
    style = style;
    classes = classes;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CarouselStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CarouselStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CarouselStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * Carousel is a content slider featuring various customization options.
 *
 * [Live Demo](https://www.ngx-prime.org/carousel/)
 *
 * @module carouselstyle
 *
 */
var CarouselClasses;
(function (CarouselClasses) {
    /**
     * Class name of the root element
     */
    CarouselClasses["root"] = "p-carousel";
    /**
     * Class name of the header element
     */
    CarouselClasses["header"] = "p-carousel-header";
    /**
     * Class name of the content container element
     */
    CarouselClasses["contentContainer"] = "p-carousel-content-container";
    /**
     * Class name of the content element
     */
    CarouselClasses["content"] = "p-carousel-content";
    /**
     * Class name of the previous button element
     */
    CarouselClasses["pcPrevButton"] = "p-carousel-prev-button";
    /**
     * Class name of the viewport element
     */
    CarouselClasses["viewport"] = "p-carousel-viewport";
    /**
     * Class name of the item list element
     */
    CarouselClasses["itemList"] = "p-carousel-item-list";
    /**
     * Class name of the item clone element
     */
    CarouselClasses["itemClone"] = "p-carousel-item-clone";
    /**
     * Class name of the item element
     */
    CarouselClasses["item"] = "p-carousel-item";
    /**
     * Class name of the next button element
     */
    CarouselClasses["pcNextButton"] = "p-carousel-next-button";
    /**
     * Class name of the indicator list element
     */
    CarouselClasses["indicatorList"] = "p-carousel-indicator-list";
    /**
     * Class name of the indicator element
     */
    CarouselClasses["indicator"] = "p-carousel-indicator";
    /**
     * Class name of the indicator button element
     */
    CarouselClasses["indicatorButton"] = "p-carousel-indicator-button";
    /**
     * Class name of the footer element
     */
    CarouselClasses["footer"] = "p-carousel-footer";
})(CarouselClasses || (CarouselClasses = {}));

/**
 * Carousel is a content slider featuring various customization options.
 * @group Components
 */
class Carousel extends BaseComponent {
    el = inject(ElementRef);
    zone = inject(NgZone);
    componentName = 'Carousel';
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptm('root'));
    }
    /**
     * Index of the first item.
     * @defaultValue 0
     * @group Props
     */
    page = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "page" }] : /* istanbul ignore next */ []));
    /**
     * Number of items per page.
     * @defaultValue 1
     * @group Props
     */
    numVisible = input(1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "numVisible" }] : /* istanbul ignore next */ []));
    /**
     * Number of items to scroll.
     * @defaultValue 1
     * @group Props
     */
    numScroll = input(1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "numScroll" }] : /* istanbul ignore next */ []));
    /**
     * An array of options for responsive design.
     * @see {CarouselResponsiveOptions}
     * @group Props
     */
    responsiveOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "responsiveOptions" }] : /* istanbul ignore next */ []));
    /**
     * Specifies the layout of the component.
     * @group Props
     */
    orientation = input('horizontal', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
    /**
     * Height of the viewport in vertical layout.
     * @group Props
     */
    verticalViewPortHeight = input('300px', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "verticalViewPortHeight" }] : /* istanbul ignore next */ []));
    /**
     * Style class of main content.
     * @group Props
     */
    contentClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "contentClass" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the indicator items.
     * @group Props
     */
    indicatorsContentClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "indicatorsContentClass" }] : /* istanbul ignore next */ []));
    /**
     * Inline style of the indicator items.
     * @group Props
     */
    indicatorsContentStyle = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "indicatorsContentStyle" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the indicators.
     * @group Props
     */
    indicatorStyleClass = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "indicatorStyleClass" }] : /* istanbul ignore next */ []));
    /**
     * Style of the indicators.
     * @group Props
     */
    indicatorStyle = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "indicatorStyle" }] : /* istanbul ignore next */ []));
    /**
     * An array of objects to display.
     * @defaultValue null
     * @group Props
     */
    value = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "value" }] : /* istanbul ignore next */ []));
    /**
     * Defines if scrolling would be infinite.
     * @group Props
     */
    circular = input(false, { ...(ngDevMode ? { debugName: "circular" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to display indicator container.
     * @group Props
     */
    showIndicators = input(true, { ...(ngDevMode ? { debugName: "showIndicators" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to display navigation buttons in container.
     * @group Props
     */
    showNavigators = input(true, { ...(ngDevMode ? { debugName: "showNavigators" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Time in milliseconds to scroll items automatically.
     * @group Props
     */
    autoplayInterval = input(0, { ...(ngDevMode ? { debugName: "autoplayInterval" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Style class of the viewport container.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Used to pass all properties of the ButtonProps to the Button component.
     * @group Props
     */
    prevButtonProps = input({
        severity: 'secondary',
        text: true,
        rounded: true
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "prevButtonProps" }] : /* istanbul ignore next */ []));
    /**
     * Used to pass all properties of the ButtonProps to the Button component.
     * @group Props
     */
    nextButtonProps = input({
        severity: 'secondary',
        text: true,
        rounded: true
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "nextButtonProps" }] : /* istanbul ignore next */ []));
    /**
     * Callback to invoke after scroll.
     * @param {CarouselPageEvent} event - Custom page event.
     * @group Emits
     */
    onPage = output();
    itemsContainer = viewChild('itemsContainer', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "itemsContainer" }] : /* istanbul ignore next */ []));
    indicatorContent = viewChild('indicatorContent', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "indicatorContent" }] : /* istanbul ignore next */ []));
    headerFacet = contentChild(Header, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "headerFacet" }] : /* istanbul ignore next */ []));
    footerFacet = contentChild(Footer, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "footerFacet" }] : /* istanbul ignore next */ []));
    _numVisible = 1;
    _numScroll = 1;
    _oldNumScroll = 0;
    prevState = {
        numScroll: 0,
        numVisible: 0,
        value: []
    };
    defaultNumScroll = 1;
    defaultNumVisible = 1;
    _page = 0;
    carouselStyle;
    id;
    totalShiftedItems;
    isRemainingItemsAdded = false;
    animationTimeout;
    translateTimeout;
    remainingItems = 0;
    _items;
    startPos;
    documentResizeListener;
    clonedItemsForStarting;
    clonedItemsForFinishing;
    allowAutoplay;
    interval;
    isCreated;
    swipeThreshold = 20;
    /**
     * Custom item template.
     * @group Templates
     */
    itemTemplate = contentChild('item', { ...(ngDevMode ? { debugName: "itemTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom header template.
     * @group Templates
     */
    headerTemplate;
    /**
     * Custom footer template.
     * @group Templates
     */
    footerTemplate;
    /**
     * Custom previous icon template.
     * @group Templates
     */
    previousIconTemplate;
    /**
     * Custom next icon template.
     * @group Templates
     */
    nextIconTemplate;
    _itemTemplate;
    _headerTemplate;
    _footerTemplate;
    _previousIconTemplate;
    _nextIconTemplate;
    window;
    _componentStyle = inject(CarouselStyle);
    constructor() {
        super();
        // Preserves a pre-existing bug: the old `numScroll` getter actually returned `_numVisible`.
        this.totalShiftedItems = this._page * this._numVisible * -1;
        this.window = this.document.defaultView;
        effect(() => {
            const val = this.page();
            if (this.isCreated && val !== this._page) {
                if (this.autoplayInterval()) {
                    this.stopAutoplay();
                }
                if (val > this._page && val <= this.totalDots() - 1) {
                    this.step(-1, val);
                }
                else if (val < this._page) {
                    this.step(1, val);
                }
            }
            this._page = val;
        });
        effect(() => {
            this._numVisible = this.numVisible();
            if (isPlatformBrowser(this.platformId) && this.isCreated) {
                if (this.responsiveOptions()) {
                    this.defaultNumVisible = this.numVisible();
                }
                if (this.isCircular()) {
                    this.setCloneItems();
                }
                this.createStyle();
                this.calculatePosition();
            }
        });
        effect(() => {
            this._numScroll = this.numScroll();
            if (isPlatformBrowser(this.platformId) && this.isCreated) {
                if (this.responsiveOptions()) {
                    // Preserves the pre-existing bug above: uses `numVisible()`, not `numScroll()`.
                    this.defaultNumScroll = this.numVisible();
                }
            }
        });
        effect(() => {
            const value = this.value();
            if (isPlatformBrowser(this.platformId) && this.circular() && value) {
                this.setCloneItems();
            }
            this.cd.markForCheck();
        });
    }
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    onAfterContentInit() {
        this.id = uuid('pn_id_');
        if (isPlatformBrowser(this.platformId)) {
            this.allowAutoplay = !!this.autoplayInterval();
            if (this.circular()) {
                this.setCloneItems();
            }
            if (this.responsiveOptions()) {
                this.defaultNumScroll = this._numScroll;
                this.defaultNumVisible = this._numVisible;
            }
            this.createStyle();
            this.calculatePosition();
            if (this.responsiveOptions()) {
                this.bindDocumentListeners();
            }
        }
        this.templates()?.forEach((item) => {
            switch (item.getType()) {
                case 'item':
                    this._itemTemplate = item.template;
                    break;
                case 'header':
                    this._headerTemplate = item.template;
                    break;
                case 'footer':
                    this._footerTemplate = item.template;
                    break;
                case 'previousicon':
                    this._previousIconTemplate = item.template;
                    break;
                case 'nexticon':
                    this._nextIconTemplate = item.template;
                    break;
                default:
                    this._itemTemplate = item.template;
                    break;
            }
        });
        this.cd.detectChanges();
    }
    onAfterContentChecked() {
        if (isPlatformBrowser(this.platformId)) {
            const isCircular = this.isCircular();
            let totalShiftedItems = this.totalShiftedItems;
            const itemsContainer = this.itemsContainer();
            const value = this.value();
            if (value && itemsContainer && (this.prevState.numScroll !== this._numScroll || this.prevState.numVisible !== this._numVisible || this.prevState.value.length !== value.length)) {
                if (this.autoplayInterval()) {
                    this.stopAutoplay(false);
                }
                this.remainingItems = (value.length - this._numVisible) % this._numScroll;
                let page = this._page;
                if (this.totalDots() !== 0 && page >= this.totalDots()) {
                    page = this.totalDots() - 1;
                    this._page = page;
                    this.onPage.emit({
                        page: this._page
                    });
                }
                totalShiftedItems = page * this._numScroll * -1;
                if (isCircular) {
                    totalShiftedItems -= this._numVisible;
                }
                if (page === this.totalDots() - 1 && this.remainingItems > 0) {
                    totalShiftedItems += -1 * this.remainingItems + this._numScroll;
                    this.isRemainingItemsAdded = true;
                }
                else {
                    this.isRemainingItemsAdded = false;
                }
                if (totalShiftedItems !== this.totalShiftedItems) {
                    this.totalShiftedItems = totalShiftedItems;
                }
                this._oldNumScroll = this._numScroll;
                this.prevState.numScroll = this._numScroll;
                this.prevState.numVisible = this._numVisible;
                this.prevState.value = [...value];
                if (this.totalDots() > 0 && itemsContainer.nativeElement) {
                    itemsContainer.nativeElement.style.transform = this.isVertical() ? `translate3d(0, ${totalShiftedItems * (100 / this._numVisible)}%, 0)` : `translate3d(${totalShiftedItems * (100 / this._numVisible)}%, 0, 0)`;
                }
                this.isCreated = true;
                if (this.autoplayInterval() && this.isAutoplay()) {
                    this.startAutoplay();
                }
            }
            if (isCircular) {
                if (this._page === 0) {
                    totalShiftedItems = -1 * this._numVisible;
                }
                else if (totalShiftedItems === 0) {
                    totalShiftedItems = -1 * (value?.length ?? 0);
                    if (this.remainingItems > 0) {
                        this.isRemainingItemsAdded = true;
                    }
                }
                if (totalShiftedItems !== this.totalShiftedItems) {
                    this.totalShiftedItems = totalShiftedItems;
                }
            }
        }
    }
    createStyle() {
        if (!this.carouselStyle) {
            this.carouselStyle = this.renderer.createElement('style');
            this.carouselStyle.type = 'text/css';
            setAttribute(this.carouselStyle, 'nonce', this.config?.csp()?.nonce);
            this.renderer.appendChild(this.document.head, this.carouselStyle);
            setAttribute(this.carouselStyle, 'nonce', this.config?.csp()?.nonce);
        }
        let innerHTML = `
            #${this.id} .p-carousel-item {
				flex: 1 0 ${100 / this.numVisible()}%
			}
        `;
        const responsiveOptions = this.responsiveOptions();
        if (responsiveOptions && !this.$unstyled()) {
            responsiveOptions.sort((data1, data2) => {
                const value1 = data1.breakpoint;
                const value2 = data2.breakpoint;
                let result = null;
                if (value1 == null && value2 != null)
                    result = -1;
                else if (value1 != null && value2 == null)
                    result = 1;
                else if (value1 == null && value2 == null)
                    result = 0;
                else if (typeof value1 === 'string' && typeof value2 === 'string')
                    result = value1.localeCompare(value2, undefined, { numeric: true });
                else
                    result = value1 < value2 ? -1 : value1 > value2 ? 1 : 0;
                return -1 * result;
            });
            for (let i = 0; i < responsiveOptions.length; i++) {
                let res = responsiveOptions[i];
                innerHTML += `
                    @media screen and (max-width: ${res.breakpoint}) {
                        #${this.id} .p-carousel-item {
                            flex: 1 0 ${100 / res.numVisible}%
                        }
                    }
                `;
            }
        }
        this.carouselStyle.innerHTML = innerHTML;
    }
    calculatePosition() {
        const responsiveOptions = this.responsiveOptions();
        if (responsiveOptions) {
            let matchedResponsiveData = {
                numVisible: this.defaultNumVisible,
                numScroll: this.defaultNumScroll
            };
            if (typeof window !== 'undefined') {
                let windowWidth = window.innerWidth;
                for (let i = 0; i < responsiveOptions.length; i++) {
                    let res = responsiveOptions[i];
                    if (parseInt(res.breakpoint, 10) >= windowWidth) {
                        matchedResponsiveData = res;
                    }
                }
            }
            if (this._numScroll !== matchedResponsiveData.numScroll) {
                let page = this._page;
                page = Math.floor((page * this._numScroll) / matchedResponsiveData.numScroll);
                let totalShiftedItems = matchedResponsiveData.numScroll * this._page * -1;
                if (this.isCircular()) {
                    totalShiftedItems -= matchedResponsiveData.numVisible;
                }
                this.totalShiftedItems = totalShiftedItems;
                this._numScroll = matchedResponsiveData.numScroll;
                this._page = page;
                this.onPage.emit({
                    page: this._page
                });
            }
            if (this._numVisible !== matchedResponsiveData.numVisible) {
                this._numVisible = matchedResponsiveData.numVisible;
                this.setCloneItems();
            }
            this.cd.markForCheck();
        }
    }
    setCloneItems() {
        this.clonedItemsForStarting = [];
        this.clonedItemsForFinishing = [];
        const value = this.value();
        if (this.isCircular() && value) {
            this.clonedItemsForStarting.push(...value.slice(-1 * this._numVisible));
            this.clonedItemsForFinishing.push(...value.slice(0, this._numVisible));
        }
    }
    firstIndex() {
        return this.isCircular() ? -1 * (this.totalShiftedItems + this.numVisible()) : this.totalShiftedItems * -1;
    }
    lastIndex() {
        return this.firstIndex() + this.numVisible() - 1;
    }
    totalDots() {
        const value = this.value();
        return value?.length ? Math.ceil((value.length - this._numVisible) / this._numScroll) + 1 : 0;
    }
    totalDotsArray() {
        const totalDots = this.totalDots();
        return totalDots <= 0 ? [] : Array(totalDots).fill(0);
    }
    isVertical() {
        return this.orientation() === 'vertical';
    }
    isCircular() {
        const value = this.value();
        return this.circular() && value && value.length >= this.numVisible();
    }
    isAutoplay() {
        return this.autoplayInterval() && this.allowAutoplay;
    }
    isForwardNavDisabled() {
        return this.isEmpty() || (this._page >= this.totalDots() - 1 && !this.isCircular());
    }
    isBackwardNavDisabled() {
        return this.isEmpty() || (this._page <= 0 && !this.isCircular());
    }
    isEmpty() {
        const value = this.value();
        return !value || value.length === 0;
    }
    navForward(e, index) {
        if (this.isCircular() || this._page < this.totalDots() - 1) {
            this.step(-1, index);
        }
        if (this.autoplayInterval()) {
            this.stopAutoplay();
        }
        if (e && e.cancelable) {
            e.preventDefault();
        }
    }
    navBackward(e, index) {
        if (this.isCircular() || this._page !== 0) {
            this.step(1, index);
        }
        if (this.autoplayInterval()) {
            this.stopAutoplay();
        }
        if (e && e.cancelable) {
            e.preventDefault();
        }
    }
    onDotClick(e, index) {
        let page = this._page;
        if (this.autoplayInterval()) {
            this.stopAutoplay();
        }
        if (index > page) {
            this.navForward(e, index);
        }
        else if (index < page) {
            this.navBackward(e, index);
        }
    }
    onIndicatorKeydown(event) {
        switch (event.code) {
            case 'ArrowRight':
                this.onRightKey();
                break;
            case 'ArrowLeft':
                this.onLeftKey();
                break;
        }
    }
    onRightKey() {
        const indicators = [...find(this.indicatorContent()?.nativeElement, '[data-pc-section="indicator"]')];
        const activeIndex = this.findFocusedIndicatorIndex();
        this.changedFocusedIndicator(activeIndex, activeIndex + 1 === indicators.length ? indicators.length - 1 : activeIndex + 1);
    }
    onLeftKey() {
        const activeIndex = this.findFocusedIndicatorIndex();
        this.changedFocusedIndicator(activeIndex, activeIndex - 1 <= 0 ? 0 : activeIndex - 1);
    }
    onHomeKey() {
        const activeIndex = this.findFocusedIndicatorIndex();
        this.changedFocusedIndicator(activeIndex, 0);
    }
    onEndKey() {
        const indicators = [...find(this.indicatorContent()?.nativeElement, '[data-pc-section="indicator"]')];
        const activeIndex = this.findFocusedIndicatorIndex();
        this.changedFocusedIndicator(activeIndex, indicators.length - 1);
    }
    onTabKey() {
        const indicatorContent = this.indicatorContent();
        const indicators = [...find(indicatorContent?.nativeElement, '[data-pc-section="indicator"]')];
        const highlightedIndex = indicators.findIndex((ind) => getAttribute(ind, 'data-p-highlight') === true);
        const activeIndicator = findSingle(indicatorContent?.nativeElement, '[data-pc-section="indicator"] > button[tabindex="0"]');
        const activeIndex = indicators.findIndex((ind) => ind === activeIndicator.parentElement);
        indicators[activeIndex].children[0].tabIndex = '-1';
        indicators[highlightedIndex].children[0].tabIndex = '0';
    }
    findFocusedIndicatorIndex() {
        const indicatorContent = this.indicatorContent();
        const indicators = [...find(indicatorContent?.nativeElement, '[data-pc-section="indicator"]')];
        const activeIndicator = findSingle(indicatorContent?.nativeElement, '[data-pc-section="indicator"] > button[tabindex="0"]');
        return indicators.findIndex((ind) => ind === activeIndicator?.parentElement);
    }
    changedFocusedIndicator(prevInd, nextInd) {
        const indicators = [...find(this.indicatorContent()?.nativeElement, '[data-pc-section="indicator"]')];
        indicators[prevInd].children[0].tabIndex = '-1';
        indicators[nextInd].children[0].tabIndex = '0';
        indicators[nextInd].children[0].focus();
    }
    step(dir, page) {
        let totalShiftedItems = this.totalShiftedItems;
        const isCircular = this.isCircular();
        if (page != null) {
            totalShiftedItems = this._numScroll * page * -1;
            if (isCircular) {
                totalShiftedItems -= this._numVisible;
            }
            this.isRemainingItemsAdded = false;
        }
        else {
            totalShiftedItems += this._numScroll * dir;
            if (this.isRemainingItemsAdded) {
                totalShiftedItems += this.remainingItems - this._numScroll * dir;
                this.isRemainingItemsAdded = false;
            }
            let originalShiftedItems = isCircular ? totalShiftedItems + this._numVisible : totalShiftedItems;
            page = Math.abs(Math.floor(originalShiftedItems / this._numScroll));
        }
        if (isCircular && this._page === this.totalDots() - 1 && dir === -1) {
            totalShiftedItems = -1 * ((this.value()?.length ?? 0) + this._numVisible);
            page = 0;
        }
        else if (isCircular && this._page === 0 && dir === 1) {
            totalShiftedItems = 0;
            page = this.totalDots() - 1;
        }
        else if (page === this.totalDots() - 1 && this.remainingItems > 0) {
            totalShiftedItems += this.remainingItems * -1 - this._numScroll * dir;
            this.isRemainingItemsAdded = true;
        }
        const itemsContainer = this.itemsContainer();
        if (itemsContainer) {
            !this.$unstyled() && removeClass(itemsContainer.nativeElement, 'p-items-hidden');
            itemsContainer.nativeElement.style.transform = this.isVertical() ? `translate3d(0, ${totalShiftedItems * (100 / this._numVisible)}%, 0)` : `translate3d(${totalShiftedItems * (100 / this._numVisible)}%, 0, 0)`;
            itemsContainer.nativeElement.style.transition = 'transform 500ms ease 0s';
        }
        this.totalShiftedItems = totalShiftedItems;
        this._page = page;
        this.onPage.emit({
            page: this._page
        });
        this.cd.markForCheck();
    }
    startAutoplay() {
        this.interval = setInterval(() => {
            if (this.totalDots() > 0) {
                if (this._page === this.totalDots() - 1) {
                    this.step(-1, 0);
                }
                else {
                    this.step(-1, this._page + 1);
                }
            }
        }, this.autoplayInterval());
        this.allowAutoplay = true;
        this.cd.markForCheck();
    }
    stopAutoplay(changeAllow = true) {
        if (this.interval) {
            clearInterval(this.interval);
            this.interval = undefined;
            if (changeAllow) {
                this.allowAutoplay = false;
            }
        }
        this.cd.markForCheck();
    }
    isPlaying() {
        return !!this.interval;
    }
    onTransitionEnd() {
        const itemsContainer = this.itemsContainer();
        if (itemsContainer) {
            !this.$unstyled() && addClass(itemsContainer.nativeElement, 'p-items-hidden');
            itemsContainer.nativeElement.style.transition = '';
            if ((this._page === 0 || this._page === this.totalDots() - 1) && this.isCircular()) {
                itemsContainer.nativeElement.style.transform = this.isVertical() ? `translate3d(0, ${this.totalShiftedItems * (100 / this._numVisible)}%, 0)` : `translate3d(${this.totalShiftedItems * (100 / this._numVisible)}%, 0, 0)`;
            }
        }
    }
    onTouchStart(e) {
        let touchobj = e.changedTouches[0];
        this.startPos = {
            x: touchobj.pageX,
            y: touchobj.pageY
        };
    }
    onTouchMove(e) {
        if (e.cancelable) {
            e.preventDefault();
        }
    }
    onTouchEnd(e) {
        let touchobj = e.changedTouches[0];
        if (this.isVertical()) {
            this.changePageOnTouch(e, touchobj.pageY - this.startPos.y);
        }
        else {
            this.changePageOnTouch(e, touchobj.pageX - this.startPos.x);
        }
    }
    changePageOnTouch(e, diff) {
        if (Math.abs(diff) > this.swipeThreshold) {
            if (diff < 0) {
                this.navForward(e);
            }
            else {
                this.navBackward(e);
            }
        }
    }
    ariaPrevButtonLabel() {
        return this.config.translation.aria ? this.config.translation.aria?.prevPageLabel : undefined;
    }
    ariaSlideLabel() {
        return this.config.translation.aria ? this.config.translation.aria?.slide : undefined;
    }
    ariaNextButtonLabel() {
        return this.config.translation.aria ? this.config.translation.aria?.nextPageLabel : undefined;
    }
    ariaSlideNumber(value) {
        return this.config.translation.aria ? this.config.translation.aria?.slideNumber?.replace(/{slideNumber}/g, value) : undefined;
    }
    ariaPageLabel(value) {
        return this.config.translation.aria ? this.config.translation.aria?.pageLabel?.replace(/{page}/g, value) : undefined;
    }
    getIndicatorPTOptions(key, index) {
        return this.ptm(key, {
            context: {
                highlighted: index === this._page
            }
        });
    }
    getItemPTOptions(key, index) {
        return this.ptm(key, {
            context: {
                index,
                active: this.firstIndex() <= index && this.lastIndex() >= index,
                start: this.firstIndex() === index,
                end: this.lastIndex() === index
            }
        });
    }
    bindDocumentListeners() {
        if (isPlatformBrowser(this.platformId)) {
            if (!this.documentResizeListener) {
                this.documentResizeListener = this.renderer.listen(this.window, 'resize', () => {
                    this.calculatePosition();
                });
            }
        }
    }
    unbindDocumentListeners() {
        if (isPlatformBrowser(this.platformId)) {
            if (this.documentResizeListener) {
                this.documentResizeListener();
                this.documentResizeListener = null;
            }
        }
    }
    onDestroy() {
        if (this.responsiveOptions()) {
            this.unbindDocumentListeners();
        }
        if (this.autoplayInterval()) {
            this.stopAutoplay();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Carousel, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: Carousel, isStandalone: true, selector: "p-carousel", inputs: { page: { classPropertyName: "page", publicName: "page", isSignal: true, isRequired: false, transformFunction: null }, numVisible: { classPropertyName: "numVisible", publicName: "numVisible", isSignal: true, isRequired: false, transformFunction: null }, numScroll: { classPropertyName: "numScroll", publicName: "numScroll", isSignal: true, isRequired: false, transformFunction: null }, responsiveOptions: { classPropertyName: "responsiveOptions", publicName: "responsiveOptions", isSignal: true, isRequired: false, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, verticalViewPortHeight: { classPropertyName: "verticalViewPortHeight", publicName: "verticalViewPortHeight", isSignal: true, isRequired: false, transformFunction: null }, contentClass: { classPropertyName: "contentClass", publicName: "contentClass", isSignal: true, isRequired: false, transformFunction: null }, indicatorsContentClass: { classPropertyName: "indicatorsContentClass", publicName: "indicatorsContentClass", isSignal: true, isRequired: false, transformFunction: null }, indicatorsContentStyle: { classPropertyName: "indicatorsContentStyle", publicName: "indicatorsContentStyle", isSignal: true, isRequired: false, transformFunction: null }, indicatorStyleClass: { classPropertyName: "indicatorStyleClass", publicName: "indicatorStyleClass", isSignal: true, isRequired: false, transformFunction: null }, indicatorStyle: { classPropertyName: "indicatorStyle", publicName: "indicatorStyle", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, circular: { classPropertyName: "circular", publicName: "circular", isSignal: true, isRequired: false, transformFunction: null }, showIndicators: { classPropertyName: "showIndicators", publicName: "showIndicators", isSignal: true, isRequired: false, transformFunction: null }, showNavigators: { classPropertyName: "showNavigators", publicName: "showNavigators", isSignal: true, isRequired: false, transformFunction: null }, autoplayInterval: { classPropertyName: "autoplayInterval", publicName: "autoplayInterval", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, prevButtonProps: { classPropertyName: "prevButtonProps", publicName: "prevButtonProps", isSignal: true, isRequired: false, transformFunction: null }, nextButtonProps: { classPropertyName: "nextButtonProps", publicName: "nextButtonProps", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onPage: "onPage" }, host: { properties: { "attr.id": "id", "attr.role": "'region'", "class": "cn(cx('root'), styleClass())" } }, providers: [CarouselStyle, { provide: PARENT_INSTANCE, useExisting: Carousel }], queries: [{ propertyName: "headerFacet", first: true, predicate: Header, descendants: true, isSignal: true }, { propertyName: "footerFacet", first: true, predicate: Footer, descendants: true, isSignal: true }, { propertyName: "itemTemplate", first: true, predicate: ["item"], isSignal: true }, { propertyName: "templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "headerTemplate", first: true, predicate: ["header"] }, { propertyName: "footerTemplate", first: true, predicate: ["footer"] }, { propertyName: "previousIconTemplate", first: true, predicate: ["previousicon"] }, { propertyName: "nextIconTemplate", first: true, predicate: ["nexticon"] }], viewQueries: [{ propertyName: "itemsContainer", first: true, predicate: ["itemsContainer"], descendants: true, isSignal: true }, { propertyName: "indicatorContent", first: true, predicate: ["indicatorContent"], descendants: true, isSignal: true }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        @if (headerFacet() || headerTemplate) {
            <div [class]="cx('header')" [pBind]="ptm('header')">
                <ng-content select="p-header"></ng-content>
                <ng-container *ngTemplateOutlet="headerTemplate"></ng-container>
            </div>
        }
        <div [class]="contentClass()" [ngClass]="cx('contentContainer')" [pBind]="ptm('contentContainer')">
            <div [class]="cx('content')" [attr.aria-live]="allowAutoplay ? 'polite' : 'off'" [pBind]="ptm('content')">
                @if (showNavigators()) {
                    <p-button
                        [class]="cx('pcPrevButton')"
                        [attr.aria-label]="ariaPrevButtonLabel()"
                        (click)="navBackward($event)"
                        [text]="true"
                        [buttonProps]="prevButtonProps()"
                        [pt]="ptm('pcPrevButton')"
                        [unstyled]="unstyled()"
                        attr.data-pc-group-section="navigator"
                    >
                        <ng-template #icon>
                            @if (!previousIconTemplate && !_previousIconTemplate && !prevButtonProps()?.icon) {
                                <ng-container>
                                    @if (!isVertical()) {
                                        <svg data-p-icon="chevron-left" />
                                    }
                                    @if (isVertical()) {
                                        <svg data-p-icon="chevron-up" />
                                    }
                                </ng-container>
                            }
                            @if ((previousIconTemplate || _previousIconTemplate) && !prevButtonProps()?.icon) {
                                <ng-container>
                                    <ng-template *ngTemplateOutlet="previousIconTemplate || _previousIconTemplate"></ng-template>
                                </ng-container>
                            }
                        </ng-template>
                    </p-button>
                }
                <div [class]="cx('viewport')" [ngStyle]="{ height: isVertical() ? verticalViewPortHeight() : 'auto' }" (touchend)="onTouchEnd($event)" (touchstart)="onTouchStart($event)" (touchmove)="onTouchMove($event)" [pBind]="ptm('viewport')">
                    <div #itemsContainer [class]="cx('itemList')" (transitionend)="onTransitionEnd()" [pBind]="ptm('itemList')">
                        @for (item of clonedItemsForStarting; track item; let index = $index) {
                            <div
                                [class]="cx('itemClone', { index })"
                                [attr.aria-hidden]="!(totalShiftedItems * -1 === value()!.length)"
                                [attr.aria-label]="ariaSlideNumber(index)"
                                [attr.aria-roledescription]="ariaSlideLabel()"
                                [attr.data-p-carousel-item-active]="totalShiftedItems * -1 === value()!.length + _numVisible"
                                [attr.data-p-carousel-item-start]="index === 0"
                                [attr.data-p-carousel-item-end]="clonedItemsForStarting && clonedItemsForStarting.length - 1 === index"
                                [pBind]="ptm('itemClone')"
                            >
                                <ng-container *ngTemplateOutlet="itemTemplate() || _itemTemplate; context: { $implicit: item }"></ng-container>
                            </div>
                        }
                        @for (item of value(); track item; let index = $index) {
                            <div
                                [class]="cx('item', { index })"
                                role="group"
                                [attr.aria-hidden]="!(firstIndex() <= index && lastIndex() >= index)"
                                [attr.aria-label]="ariaSlideNumber(index)"
                                [attr.aria-roledescription]="ariaSlideLabel()"
                                [attr.data-p-carousel-item-active]="firstIndex() <= index && lastIndex() >= index"
                                [attr.data-p-carousel-item-start]="firstIndex() === index"
                                [attr.data-p-carousel-item-end]="lastIndex() === index"
                                [pBind]="getItemPTOptions('item', index)"
                            >
                                <ng-container *ngTemplateOutlet="itemTemplate() || _itemTemplate; context: { $implicit: item }"></ng-container>
                            </div>
                        }
                        @for (item of clonedItemsForFinishing; track item; let index = $index) {
                            <div [class]="cx('itemClone', { index })" [attr.data-p-carousel-item-active]="false" [attr.data-p-carousel-item-start]="false" [attr.data-p-carousel-item-end]="false" [pBind]="ptm('itemClone')">
                                <ng-container *ngTemplateOutlet="itemTemplate() || _itemTemplate; context: { $implicit: item }"></ng-container>
                            </div>
                        }
                    </div>
                </div>
                @if (showNavigators()) {
                    <p-button
                        type="button"
                        [class]="cx('pcNextButton')"
                        (click)="navForward($event)"
                        [attr.aria-label]="ariaNextButtonLabel()"
                        [buttonProps]="nextButtonProps()"
                        [text]="true"
                        [pt]="ptm('pcNextButton')"
                        [unstyled]="unstyled()"
                        attr.data-pc-group-section="navigator"
                    >
                        <ng-template #icon>
                            @if (!nextIconTemplate && !_nextIconTemplate && !nextButtonProps()?.icon) {
                                <ng-container>
                                    @if (!isVertical()) {
                                        <svg data-p-icon="chevron-right" />
                                    }
                                    @if (isVertical()) {
                                        <svg data-p-icon="chevron-down" />
                                    }
                                </ng-container>
                            }
                            @if (nextIconTemplate || (_nextIconTemplate && !nextButtonProps()?.icon)) {
                                <span>
                                    <ng-template *ngTemplateOutlet="nextIconTemplate || _nextIconTemplate"></ng-template>
                                </span>
                            }
                        </ng-template>
                    </p-button>
                }
            </div>
            @if (showIndicators()) {
                <ul #indicatorContent [class]="cx('indicatorList')" [ngStyle]="indicatorsContentStyle()" (keydown)="onIndicatorKeydown($event)" [pBind]="ptm('indicatorList')">
                    @for (totalDot of totalDotsArray(); track totalDot; let i = $index) {
                        <li [class]="cx('indicator', { index: i })" [attr.data-p-active]="_page === i" [pBind]="getIndicatorPTOptions('indicator', i)">
                            <button
                                type="button"
                                [class]="cx('indicatorButton')"
                                (click)="onDotClick($event, i)"
                                [ngStyle]="indicatorStyle()"
                                [attr.aria-label]="ariaPageLabel(i + 1)"
                                [attr.aria-current]="_page === i ? 'page' : undefined"
                                [tabindex]="_page === i ? 0 : -1"
                                [pBind]="getIndicatorPTOptions('indicatorButton', i)"
                            ></button>
                        </li>
                    }
                </ul>
            }
        </div>
        @if (footerFacet() || footerTemplate || _footerTemplate) {
            <div [class]="cx('footer')" [pBind]="ptm('footer')">
                <ng-content select="p-footer"></ng-content>
                <ng-container *ngTemplateOutlet="footerTemplate || _footerTemplate"></ng-container>
            </div>
        }
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: ChevronRightIcon, selector: "[data-p-icon=\"chevron-right\"]" }, { kind: "ngmodule", type: ButtonModule }, { kind: "component", type: i3.Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }, { kind: "component", type: ChevronLeftIcon, selector: "[data-p-icon=\"chevron-left\"]" }, { kind: "component", type: ChevronDownIcon, selector: "[data-p-icon=\"chevron-down\"]" }, { kind: "component", type: ChevronUpIcon, selector: "[data-p-icon=\"chevron-up\"]" }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: BindModule }, { kind: "directive", type: i1.Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Carousel, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-carousel',
                    standalone: true,
                    imports: [CommonModule, ChevronRightIcon, ButtonModule, ChevronLeftIcon, ChevronDownIcon, ChevronUpIcon, SharedModule, BindModule],
                    template: `
        @if (headerFacet() || headerTemplate) {
            <div [class]="cx('header')" [pBind]="ptm('header')">
                <ng-content select="p-header"></ng-content>
                <ng-container *ngTemplateOutlet="headerTemplate"></ng-container>
            </div>
        }
        <div [class]="contentClass()" [ngClass]="cx('contentContainer')" [pBind]="ptm('contentContainer')">
            <div [class]="cx('content')" [attr.aria-live]="allowAutoplay ? 'polite' : 'off'" [pBind]="ptm('content')">
                @if (showNavigators()) {
                    <p-button
                        [class]="cx('pcPrevButton')"
                        [attr.aria-label]="ariaPrevButtonLabel()"
                        (click)="navBackward($event)"
                        [text]="true"
                        [buttonProps]="prevButtonProps()"
                        [pt]="ptm('pcPrevButton')"
                        [unstyled]="unstyled()"
                        attr.data-pc-group-section="navigator"
                    >
                        <ng-template #icon>
                            @if (!previousIconTemplate && !_previousIconTemplate && !prevButtonProps()?.icon) {
                                <ng-container>
                                    @if (!isVertical()) {
                                        <svg data-p-icon="chevron-left" />
                                    }
                                    @if (isVertical()) {
                                        <svg data-p-icon="chevron-up" />
                                    }
                                </ng-container>
                            }
                            @if ((previousIconTemplate || _previousIconTemplate) && !prevButtonProps()?.icon) {
                                <ng-container>
                                    <ng-template *ngTemplateOutlet="previousIconTemplate || _previousIconTemplate"></ng-template>
                                </ng-container>
                            }
                        </ng-template>
                    </p-button>
                }
                <div [class]="cx('viewport')" [ngStyle]="{ height: isVertical() ? verticalViewPortHeight() : 'auto' }" (touchend)="onTouchEnd($event)" (touchstart)="onTouchStart($event)" (touchmove)="onTouchMove($event)" [pBind]="ptm('viewport')">
                    <div #itemsContainer [class]="cx('itemList')" (transitionend)="onTransitionEnd()" [pBind]="ptm('itemList')">
                        @for (item of clonedItemsForStarting; track item; let index = $index) {
                            <div
                                [class]="cx('itemClone', { index })"
                                [attr.aria-hidden]="!(totalShiftedItems * -1 === value()!.length)"
                                [attr.aria-label]="ariaSlideNumber(index)"
                                [attr.aria-roledescription]="ariaSlideLabel()"
                                [attr.data-p-carousel-item-active]="totalShiftedItems * -1 === value()!.length + _numVisible"
                                [attr.data-p-carousel-item-start]="index === 0"
                                [attr.data-p-carousel-item-end]="clonedItemsForStarting && clonedItemsForStarting.length - 1 === index"
                                [pBind]="ptm('itemClone')"
                            >
                                <ng-container *ngTemplateOutlet="itemTemplate() || _itemTemplate; context: { $implicit: item }"></ng-container>
                            </div>
                        }
                        @for (item of value(); track item; let index = $index) {
                            <div
                                [class]="cx('item', { index })"
                                role="group"
                                [attr.aria-hidden]="!(firstIndex() <= index && lastIndex() >= index)"
                                [attr.aria-label]="ariaSlideNumber(index)"
                                [attr.aria-roledescription]="ariaSlideLabel()"
                                [attr.data-p-carousel-item-active]="firstIndex() <= index && lastIndex() >= index"
                                [attr.data-p-carousel-item-start]="firstIndex() === index"
                                [attr.data-p-carousel-item-end]="lastIndex() === index"
                                [pBind]="getItemPTOptions('item', index)"
                            >
                                <ng-container *ngTemplateOutlet="itemTemplate() || _itemTemplate; context: { $implicit: item }"></ng-container>
                            </div>
                        }
                        @for (item of clonedItemsForFinishing; track item; let index = $index) {
                            <div [class]="cx('itemClone', { index })" [attr.data-p-carousel-item-active]="false" [attr.data-p-carousel-item-start]="false" [attr.data-p-carousel-item-end]="false" [pBind]="ptm('itemClone')">
                                <ng-container *ngTemplateOutlet="itemTemplate() || _itemTemplate; context: { $implicit: item }"></ng-container>
                            </div>
                        }
                    </div>
                </div>
                @if (showNavigators()) {
                    <p-button
                        type="button"
                        [class]="cx('pcNextButton')"
                        (click)="navForward($event)"
                        [attr.aria-label]="ariaNextButtonLabel()"
                        [buttonProps]="nextButtonProps()"
                        [text]="true"
                        [pt]="ptm('pcNextButton')"
                        [unstyled]="unstyled()"
                        attr.data-pc-group-section="navigator"
                    >
                        <ng-template #icon>
                            @if (!nextIconTemplate && !_nextIconTemplate && !nextButtonProps()?.icon) {
                                <ng-container>
                                    @if (!isVertical()) {
                                        <svg data-p-icon="chevron-right" />
                                    }
                                    @if (isVertical()) {
                                        <svg data-p-icon="chevron-down" />
                                    }
                                </ng-container>
                            }
                            @if (nextIconTemplate || (_nextIconTemplate && !nextButtonProps()?.icon)) {
                                <span>
                                    <ng-template *ngTemplateOutlet="nextIconTemplate || _nextIconTemplate"></ng-template>
                                </span>
                            }
                        </ng-template>
                    </p-button>
                }
            </div>
            @if (showIndicators()) {
                <ul #indicatorContent [class]="cx('indicatorList')" [ngStyle]="indicatorsContentStyle()" (keydown)="onIndicatorKeydown($event)" [pBind]="ptm('indicatorList')">
                    @for (totalDot of totalDotsArray(); track totalDot; let i = $index) {
                        <li [class]="cx('indicator', { index: i })" [attr.data-p-active]="_page === i" [pBind]="getIndicatorPTOptions('indicator', i)">
                            <button
                                type="button"
                                [class]="cx('indicatorButton')"
                                (click)="onDotClick($event, i)"
                                [ngStyle]="indicatorStyle()"
                                [attr.aria-label]="ariaPageLabel(i + 1)"
                                [attr.aria-current]="_page === i ? 'page' : undefined"
                                [tabindex]="_page === i ? 0 : -1"
                                [pBind]="getIndicatorPTOptions('indicatorButton', i)"
                            ></button>
                        </li>
                    }
                </ul>
            }
        </div>
        @if (footerFacet() || footerTemplate || _footerTemplate) {
            <div [class]="cx('footer')" [pBind]="ptm('footer')">
                <ng-content select="p-footer"></ng-content>
                <ng-container *ngTemplateOutlet="footerTemplate || _footerTemplate"></ng-container>
            </div>
        }
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [CarouselStyle, { provide: PARENT_INSTANCE, useExisting: Carousel }],
                    hostDirectives: [Bind],
                    host: {
                        '[attr.id]': 'id',
                        '[attr.role]': "'region'",
                        '[class]': "cn(cx('root'), styleClass())"
                    }
                }]
        }], ctorParameters: () => [], propDecorators: { page: [{ type: i0.Input, args: [{ isSignal: true, alias: "page", required: false }] }], numVisible: [{ type: i0.Input, args: [{ isSignal: true, alias: "numVisible", required: false }] }], numScroll: [{ type: i0.Input, args: [{ isSignal: true, alias: "numScroll", required: false }] }], responsiveOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "responsiveOptions", required: false }] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], verticalViewPortHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "verticalViewPortHeight", required: false }] }], contentClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "contentClass", required: false }] }], indicatorsContentClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "indicatorsContentClass", required: false }] }], indicatorsContentStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "indicatorsContentStyle", required: false }] }], indicatorStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "indicatorStyleClass", required: false }] }], indicatorStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "indicatorStyle", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], circular: [{ type: i0.Input, args: [{ isSignal: true, alias: "circular", required: false }] }], showIndicators: [{ type: i0.Input, args: [{ isSignal: true, alias: "showIndicators", required: false }] }], showNavigators: [{ type: i0.Input, args: [{ isSignal: true, alias: "showNavigators", required: false }] }], autoplayInterval: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoplayInterval", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], prevButtonProps: [{ type: i0.Input, args: [{ isSignal: true, alias: "prevButtonProps", required: false }] }], nextButtonProps: [{ type: i0.Input, args: [{ isSignal: true, alias: "nextButtonProps", required: false }] }], onPage: [{ type: i0.Output, args: ["onPage"] }], itemsContainer: [{ type: i0.ViewChild, args: ['itemsContainer', { isSignal: true }] }], indicatorContent: [{ type: i0.ViewChild, args: ['indicatorContent', { isSignal: true }] }], headerFacet: [{ type: i0.ContentChild, args: [i0.forwardRef(() => Header), { isSignal: true }] }], footerFacet: [{ type: i0.ContentChild, args: [i0.forwardRef(() => Footer), { isSignal: true }] }], itemTemplate: [{ type: i0.ContentChild, args: ['item', { ...{ descendants: false }, isSignal: true }] }], headerTemplate: [{
                type: ContentChild,
                args: ['header', { descendants: false }]
            }], footerTemplate: [{
                type: ContentChild,
                args: ['footer', { descendants: false }]
            }], previousIconTemplate: [{
                type: ContentChild,
                args: ['previousicon', { descendants: false }]
            }], nextIconTemplate: [{
                type: ContentChild,
                args: ['nexticon', { descendants: false }]
            }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class CarouselModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CarouselModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: CarouselModule, imports: [Carousel, SharedModule], exports: [Carousel, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CarouselModule, imports: [Carousel, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CarouselModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [Carousel, SharedModule],
                    exports: [Carousel, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { Carousel, CarouselClasses, CarouselModule, CarouselStyle };
//# sourceMappingURL=wawjs-ngx-prime-carousel.mjs.map
