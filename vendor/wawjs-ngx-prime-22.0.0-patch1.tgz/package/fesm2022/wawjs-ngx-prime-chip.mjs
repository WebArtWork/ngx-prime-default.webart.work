export * from '@wawjs/ngx-prime/types/chip';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, input, booleanAttribute, output, computed, contentChildren, ContentChild, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { TranslationKeys, PrimeTemplate, SharedModule } from '@wawjs/ngx-prime/api';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { TimesCircleIcon } from '@wawjs/ngx-prime/icons';
import { style } from '@wawjs/css-prime-styles/chip';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const inlineStyles = {
    root: ({ instance }) => ({
        display: !instance.visible && 'none'
    })
};
const classes = {
    root: ({ instance }) => [
        'p-chip p-component',
        {
            'p-disabled': instance.disabled()
        }
    ],
    image: 'p-chip-image',
    icon: 'p-chip-icon',
    label: 'p-chip-label',
    removeIcon: 'p-chip-remove-icon'
};
class ChipStyle extends BaseStyle {
    name = 'chip';
    style = style;
    classes = classes;
    inlineStyles = inlineStyles;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ChipStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ChipStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ChipStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * Chip represents people using icons, labels and images.
 *
 * [Live Demo](https://www.ngx-prime.org/chip)
 *
 * @module chipstyle
 *
 */
var ChipClasses;
(function (ChipClasses) {
    /**
     * Class name of the root element
     */
    ChipClasses["root"] = "p-chip";
    /**
     * Class name of the image element
     */
    ChipClasses["image"] = "p-chip-image";
    /**
     * Class name of the icon element
     */
    ChipClasses["icon"] = "p-chip-icon";
    /**
     * Class name of the label element
     */
    ChipClasses["label"] = "p-chip-label";
    /**
     * Class name of the remove icon element
     */
    ChipClasses["removeIcon"] = "p-chip-remove-icon";
})(ChipClasses || (ChipClasses = {}));

const CHIP_INSTANCE = new InjectionToken('CHIP_INSTANCE');
/**
 * Chip represents people using icons, labels and images.
 * @group Components
 */
class Chip extends BaseComponent {
    componentName = 'Chip';
    $pcChip = inject(CHIP_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    /**
     * Defines the text to display.
     * @group Props
     */
    label = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "label" }] : /* istanbul ignore next */ []));
    /**
     * Defines the icon to display.
     * @group Props
     */
    icon = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "icon" }] : /* istanbul ignore next */ []));
    /**
     * Defines the image to display.
     * @group Props
     */
    image = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "image" }] : /* istanbul ignore next */ []));
    /**
     * Alt attribute of the image.
     * @group Props
     */
    alt = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "alt" }] : /* istanbul ignore next */ []));
    /**
     * Class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * When present, it specifies that the element should be disabled.
     * @group Props
     */
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to display a remove icon.
     * @group Props
     */
    removable = input(false, { ...(ngDevMode ? { debugName: "removable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Icon of the remove element.
     * @group Props
     */
    removeIcon = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "removeIcon" }] : /* istanbul ignore next */ []));
    /**
     * Callback to invoke when a chip is removed.
     * @param {MouseEvent} event - Mouse event.
     * @group Emits
     */
    onRemove = output();
    /**
     * This event is triggered if an error occurs while loading an image file.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onImageError = output();
    visible = true;
    get removeAriaLabel() {
        return this.config.getTranslation(TranslationKeys.ARIA)['removeLabel'];
    }
    /**
     * Used to pass all properties of the chipProps to the Chip component.
     * @group Props
     */
    chipProps = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "chipProps" }] : /* istanbul ignore next */ []));
    resolvedLabel = computed(() => this.chipProps()?.label ?? this.label(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "resolvedLabel" }] : /* istanbul ignore next */ []));
    resolvedIcon = computed(() => this.chipProps()?.icon ?? this.icon(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "resolvedIcon" }] : /* istanbul ignore next */ []));
    resolvedImage = computed(() => this.chipProps()?.image ?? this.image(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "resolvedImage" }] : /* istanbul ignore next */ []));
    resolvedAlt = computed(() => this.chipProps()?.alt ?? this.alt(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "resolvedAlt" }] : /* istanbul ignore next */ []));
    resolvedStyleClass = computed(() => this.chipProps()?.styleClass ?? this.styleClass(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "resolvedStyleClass" }] : /* istanbul ignore next */ []));
    resolvedRemovable = computed(() => this.chipProps()?.removable ?? this.removable(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "resolvedRemovable" }] : /* istanbul ignore next */ []));
    resolvedRemoveIcon = computed(() => this.chipProps()?.removeIcon ?? this.removeIcon(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "resolvedRemoveIcon" }] : /* istanbul ignore next */ []));
    _componentStyle = inject(ChipStyle);
    /**
     * Custom remove icon template.
     * @group Templates
     */
    removeIconTemplate;
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    _removeIconTemplate;
    onAfterContentInit() {
        this.templates().forEach((item) => {
            switch (item.getType()) {
                case 'removeicon':
                    this._removeIconTemplate = item.template;
                    break;
                default:
                    this._removeIconTemplate = item.template;
                    break;
            }
        });
    }
    close(event) {
        this.visible = false;
        this.onRemove.emit(event);
    }
    onKeydown(event) {
        if (event.key === 'Enter' || event.key === 'Backspace') {
            this.close(event);
        }
    }
    imageError(event) {
        this.onImageError.emit(event);
    }
    get dataP() {
        return this.cn({
            removable: this.resolvedRemovable()
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Chip, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: Chip, isStandalone: true, selector: "p-chip", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, icon: { classPropertyName: "icon", publicName: "icon", isSignal: true, isRequired: false, transformFunction: null }, image: { classPropertyName: "image", publicName: "image", isSignal: true, isRequired: false, transformFunction: null }, alt: { classPropertyName: "alt", publicName: "alt", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, removable: { classPropertyName: "removable", publicName: "removable", isSignal: true, isRequired: false, transformFunction: null }, removeIcon: { classPropertyName: "removeIcon", publicName: "removeIcon", isSignal: true, isRequired: false, transformFunction: null }, chipProps: { classPropertyName: "chipProps", publicName: "chipProps", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onRemove: "onRemove", onImageError: "onImageError" }, host: { properties: { "class": "cn(cx('root'), resolvedStyleClass())", "style": "sx('root')", "attr.aria-label": "resolvedLabel()", "attr.data-p": "dataP" } }, providers: [ChipStyle, { provide: CHIP_INSTANCE, useExisting: Chip }, { provide: PARENT_INSTANCE, useExisting: Chip }], queries: [{ propertyName: "templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "removeIconTemplate", first: true, predicate: ["removeicon"] }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        <ng-content></ng-content>
        @if (resolvedImage()) {
            <img [pBind]="ptm('image')" [class]="cx('image')" [src]="resolvedImage()" (error)="imageError($event)" [alt]="resolvedAlt()" />
        } @else {
            @if (resolvedIcon()) {
                <span [pBind]="ptm('icon')" [class]="resolvedIcon()" [ngClass]="cx('icon')"></span>
            }
        }
        @if (resolvedLabel()) {
            <div [pBind]="ptm('label')" [class]="cx('label')">{{ resolvedLabel() }}</div>
        }
        @if (resolvedRemovable()) {
            @if (!removeIconTemplate && !_removeIconTemplate) {
                @if (resolvedRemoveIcon()) {
                    <span
                        [pBind]="ptm('removeIcon')"
                        [class]="resolvedRemoveIcon()"
                        [ngClass]="cx('removeIcon')"
                        (click)="close($event)"
                        (keydown)="onKeydown($event)"
                        [attr.tabindex]="disabled() ? -1 : 0"
                        [attr.aria-label]="removeAriaLabel"
                        role="button"
                    ></span>
                }
                @if (!resolvedRemoveIcon()) {
                    <svg
                        [pBind]="ptm('removeIcon')"
                        data-p-icon="times-circle"
                        [class]="cx('removeIcon')"
                        (click)="close($event)"
                        (keydown)="onKeydown($event)"
                        [attr.tabindex]="disabled() ? -1 : 0"
                        [attr.aria-label]="removeAriaLabel"
                        role="button"
                    />
                }
            }
            @if (removeIconTemplate || _removeIconTemplate) {
                <span [pBind]="ptm('removeIcon')" [attr.tabindex]="disabled() ? -1 : 0" [class]="cx('removeIcon')" (click)="close($event)" (keydown)="onKeydown($event)" [attr.aria-label]="removeAriaLabel" role="button">
                    <ng-template *ngTemplateOutlet="removeIconTemplate || _removeIconTemplate"></ng-template>
                </span>
            }
        }
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: TimesCircleIcon, selector: "[data-p-icon=\"times-circle\"]" }, { kind: "ngmodule", type: SharedModule }, { kind: "directive", type: Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Chip, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-chip',
                    standalone: true,
                    imports: [CommonModule, TimesCircleIcon, SharedModule, Bind],
                    template: `
        <ng-content></ng-content>
        @if (resolvedImage()) {
            <img [pBind]="ptm('image')" [class]="cx('image')" [src]="resolvedImage()" (error)="imageError($event)" [alt]="resolvedAlt()" />
        } @else {
            @if (resolvedIcon()) {
                <span [pBind]="ptm('icon')" [class]="resolvedIcon()" [ngClass]="cx('icon')"></span>
            }
        }
        @if (resolvedLabel()) {
            <div [pBind]="ptm('label')" [class]="cx('label')">{{ resolvedLabel() }}</div>
        }
        @if (resolvedRemovable()) {
            @if (!removeIconTemplate && !_removeIconTemplate) {
                @if (resolvedRemoveIcon()) {
                    <span
                        [pBind]="ptm('removeIcon')"
                        [class]="resolvedRemoveIcon()"
                        [ngClass]="cx('removeIcon')"
                        (click)="close($event)"
                        (keydown)="onKeydown($event)"
                        [attr.tabindex]="disabled() ? -1 : 0"
                        [attr.aria-label]="removeAriaLabel"
                        role="button"
                    ></span>
                }
                @if (!resolvedRemoveIcon()) {
                    <svg
                        [pBind]="ptm('removeIcon')"
                        data-p-icon="times-circle"
                        [class]="cx('removeIcon')"
                        (click)="close($event)"
                        (keydown)="onKeydown($event)"
                        [attr.tabindex]="disabled() ? -1 : 0"
                        [attr.aria-label]="removeAriaLabel"
                        role="button"
                    />
                }
            }
            @if (removeIconTemplate || _removeIconTemplate) {
                <span [pBind]="ptm('removeIcon')" [attr.tabindex]="disabled() ? -1 : 0" [class]="cx('removeIcon')" (click)="close($event)" (keydown)="onKeydown($event)" [attr.aria-label]="removeAriaLabel" role="button">
                    <ng-template *ngTemplateOutlet="removeIconTemplate || _removeIconTemplate"></ng-template>
                </span>
            }
        }
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [ChipStyle, { provide: CHIP_INSTANCE, useExisting: Chip }, { provide: PARENT_INSTANCE, useExisting: Chip }],
                    host: {
                        '[class]': "cn(cx('root'), resolvedStyleClass())",
                        '[style]': "sx('root')",
                        '[attr.aria-label]': 'resolvedLabel()',
                        '[attr.data-p]': 'dataP'
                    },
                    hostDirectives: [Bind]
                }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], icon: [{ type: i0.Input, args: [{ isSignal: true, alias: "icon", required: false }] }], image: [{ type: i0.Input, args: [{ isSignal: true, alias: "image", required: false }] }], alt: [{ type: i0.Input, args: [{ isSignal: true, alias: "alt", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], removable: [{ type: i0.Input, args: [{ isSignal: true, alias: "removable", required: false }] }], removeIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "removeIcon", required: false }] }], onRemove: [{ type: i0.Output, args: ["onRemove"] }], onImageError: [{ type: i0.Output, args: ["onImageError"] }], chipProps: [{ type: i0.Input, args: [{ isSignal: true, alias: "chipProps", required: false }] }], removeIconTemplate: [{
                type: ContentChild,
                args: ['removeicon', { descendants: false }]
            }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class ChipModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ChipModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: ChipModule, imports: [Chip, SharedModule], exports: [Chip, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ChipModule, imports: [Chip, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ChipModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [Chip, SharedModule],
                    exports: [Chip, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { Chip, ChipClasses, ChipModule, ChipStyle };
//# sourceMappingURL=wawjs-ngx-prime-chip.mjs.map
