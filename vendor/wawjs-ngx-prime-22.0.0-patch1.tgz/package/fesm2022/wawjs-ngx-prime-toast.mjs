export * from '@wawjs/ngx-prime/types/toast';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, NgZone, input, numberAttribute, output, signal, effect, ChangeDetectionStrategy, ViewEncapsulation, Component, booleanAttribute, computed, contentChild, contentChildren, NgModule } from '@angular/core';
import { uuid, isEmpty, setAttribute } from '@wawjs/css-prime-utils';
import { SharedModule, MessageService, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i3 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { CheckIcon, ExclamationTriangleIcon, InfoCircleIcon, TimesIcon, TimesCircleIcon } from '@wawjs/ngx-prime/icons';
import * as i2 from '@wawjs/ngx-prime/motion';
import { MotionModule } from '@wawjs/ngx-prime/motion';
import { ZIndexUtils } from '@wawjs/ngx-prime/utils';
import { style } from '@wawjs/css-prime-styles/toast';
import { BaseStyle } from '@wawjs/ngx-prime/base';

// Position
const inlineStyles = {
    root: ({ instance }) => {
        const _position = instance.position();
        return {
            position: 'fixed',
            top: _position === 'top-right' || _position === 'top-left' || _position === 'top-center' ? '20px' : _position === 'center' ? '50%' : null,
            right: (_position === 'top-right' || _position === 'bottom-right') && '20px',
            bottom: (_position === 'bottom-left' || _position === 'bottom-right' || _position === 'bottom-center') && '20px',
            left: _position === 'top-left' || _position === 'bottom-left' ? '20px' : _position === 'center' || _position === 'top-center' || _position === 'bottom-center' ? '50%' : null
        };
    }
};
const classes = {
    root: ({ instance }) => ['p-toast p-component', `p-toast-${instance.position()}`],
    message: ({ instance }) => ({
        'p-toast-message': true,
        'p-toast-message-info': instance.message()?.severity === 'info' || instance.message()?.severity === undefined,
        'p-toast-message-warn': instance.message()?.severity === 'warn',
        'p-toast-message-error': instance.message()?.severity === 'error',
        'p-toast-message-success': instance.message()?.severity === 'success',
        'p-toast-message-secondary': instance.message()?.severity === 'secondary',
        'p-toast-message-contrast': instance.message()?.severity === 'contrast'
    }),
    messageContent: 'p-toast-message-content',
    messageIcon: ({ instance }) => ({
        'p-toast-message-icon': true,
        [`pi ${instance.message()?.icon}`]: !!instance.message()?.icon
    }),
    messageText: 'p-toast-message-text',
    summary: 'p-toast-summary',
    detail: 'p-toast-detail',
    closeButton: 'p-toast-close-button',
    closeIcon: ({ instance }) => ({
        'p-toast-close-icon': true,
        [`pi ${instance.message()?.closeIcon}`]: !!instance.message()?.closeIcon
    })
};
class ToastStyle extends BaseStyle {
    name = 'toast';
    style = style;
    classes = classes;
    inlineStyles = inlineStyles;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToastStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToastStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToastStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * Toast is used to display messages in an overlay.
 *
 * [Live Demo](https://www.ngx-prime.org/toast/)
 *
 * @module toaststyle
 *
 */
var ToastClasses;
(function (ToastClasses) {
    /**
     * Class name of the root element
     */
    ToastClasses["root"] = "p-toast";
    /**
     * Class name of the message element
     */
    ToastClasses["message"] = "p-toast-message";
    /**
     * Class name of the message content element
     */
    ToastClasses["messageContent"] = "p-toast-message-content";
    /**
     * Class name of the message icon element
     */
    ToastClasses["messageIcon"] = "p-toast-message-icon";
    /**
     * Class name of the message text element
     */
    ToastClasses["messageText"] = "p-toast-message-text";
    /**
     * Class name of the summary element
     */
    ToastClasses["summary"] = "p-toast-summary";
    /**
     * Class name of the detail element
     */
    ToastClasses["detail"] = "p-toast-detail";
    /**
     * Class name of the close button element
     */
    ToastClasses["closeButton"] = "p-toast-close-button";
    /**
     * Class name of the close icon element
     */
    ToastClasses["closeIcon"] = "p-toast-close-icon";
})(ToastClasses || (ToastClasses = {}));

const TOAST_INSTANCE = new InjectionToken('TOAST_INSTANCE');
class ToastItem extends BaseComponent {
    zone = inject(NgZone);
    message = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "message" }] : /* istanbul ignore next */ []));
    index = input(undefined, { ...(ngDevMode ? { debugName: "index" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    life = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "life" }] : /* istanbul ignore next */ []));
    template = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "template" }] : /* istanbul ignore next */ []));
    headlessTemplate = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "headlessTemplate" }] : /* istanbul ignore next */ []));
    showTransformOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "showTransformOptions" }] : /* istanbul ignore next */ []));
    hideTransformOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "hideTransformOptions" }] : /* istanbul ignore next */ []));
    showTransitionOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "showTransitionOptions" }] : /* istanbul ignore next */ []));
    hideTransitionOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "hideTransitionOptions" }] : /* istanbul ignore next */ []));
    motionOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "motionOptions" }] : /* istanbul ignore next */ []));
    clearAll = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "clearAll" }] : /* istanbul ignore next */ []));
    onAnimationStart = output();
    onAnimationEnd = output();
    onBeforeEnter(event) {
        this.onAnimationStart.emit(event.element);
    }
    onAfterLeave(event) {
        if (!this.visible() && !this.isDestroyed) {
            this.onClose.emit({
                index: this.index(),
                message: this.message()
            });
            if (!this.isDestroyed) {
                this.onAnimationEnd.emit(event.element);
            }
        }
    }
    onClose = output();
    _componentStyle = inject(ToastStyle);
    timeout;
    visible = signal(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []));
    isDestroyed = false;
    isClosing = false;
    constructor() {
        super();
        effect(() => {
            if (this.clearAll()) {
                this.visible.set(false);
            }
        });
    }
    onAfterViewInit() {
        this.message()?.sticky && this.visible.set(true);
        this.initTimeout();
    }
    initTimeout() {
        if (!this.message()?.sticky) {
            this.clearTimeout();
            this.zone.runOutsideAngular(() => {
                this.visible.set(true);
                this.timeout = setTimeout(() => {
                    this.visible.set(false);
                }, this.message()?.life || this.life() || 3000);
            });
        }
    }
    clearTimeout() {
        if (this.timeout) {
            clearTimeout(this.timeout);
            this.timeout = null;
        }
    }
    onMouseEnter() {
        this.clearTimeout();
    }
    onMouseLeave() {
        if (!this.isClosing) {
            this.initTimeout();
        }
    }
    onCloseIconClick = (event) => {
        this.isClosing = true;
        this.clearTimeout();
        this.visible.set(false);
        event.preventDefault();
    };
    get closeAriaLabel() {
        return this.config.translation.aria ? this.config.translation.aria.close : undefined;
    }
    onDestroy() {
        this.isDestroyed = true;
        this.clearTimeout();
        this.visible.set(false);
    }
    get dataP() {
        return this.cn({
            [this.message()?.severity]: this.message()?.severity
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToastItem, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: ToastItem, isStandalone: true, selector: "p-toast-item", inputs: { message: { classPropertyName: "message", publicName: "message", isSignal: true, isRequired: false, transformFunction: null }, index: { classPropertyName: "index", publicName: "index", isSignal: true, isRequired: false, transformFunction: null }, life: { classPropertyName: "life", publicName: "life", isSignal: true, isRequired: false, transformFunction: null }, template: { classPropertyName: "template", publicName: "template", isSignal: true, isRequired: false, transformFunction: null }, headlessTemplate: { classPropertyName: "headlessTemplate", publicName: "headlessTemplate", isSignal: true, isRequired: false, transformFunction: null }, showTransformOptions: { classPropertyName: "showTransformOptions", publicName: "showTransformOptions", isSignal: true, isRequired: false, transformFunction: null }, hideTransformOptions: { classPropertyName: "hideTransformOptions", publicName: "hideTransformOptions", isSignal: true, isRequired: false, transformFunction: null }, showTransitionOptions: { classPropertyName: "showTransitionOptions", publicName: "showTransitionOptions", isSignal: true, isRequired: false, transformFunction: null }, hideTransitionOptions: { classPropertyName: "hideTransitionOptions", publicName: "hideTransitionOptions", isSignal: true, isRequired: false, transformFunction: null }, motionOptions: { classPropertyName: "motionOptions", publicName: "motionOptions", isSignal: true, isRequired: false, transformFunction: null }, clearAll: { classPropertyName: "clearAll", publicName: "clearAll", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onAnimationStart: "onAnimationStart", onAnimationEnd: "onAnimationEnd", onClose: "onClose" }, providers: [ToastStyle], usesInheritance: true, ngImport: i0, template: `
        <div
            #container
            [pMotion]="visible()"
            [pMotionAppear]="true"
            [pMotionName]="'p-toast-message'"
            [pMotionOptions]="motionOptions()"
            (pMotionOnBeforeEnter)="onBeforeEnter($event)"
            (pMotionOnAfterLeave)="onAfterLeave($event)"
            [attr.id]="message()?.id"
            [pBind]="ptm('message')"
            [class]="cn(cx('message'), message()?.styleClass)"
            (mouseenter)="onMouseEnter()"
            (mouseleave)="onMouseLeave()"
            role="alert"
            aria-live="assertive"
            aria-atomic="true"
            [attr.data-p]="dataP"
        >
            @if (headlessTemplate()) {
                <ng-container *ngTemplateOutlet="headlessTemplate(); context: { $implicit: message(), closeFn: onCloseIconClick }"></ng-container>
            } @else {
                <div [pBind]="ptm('messageContent')" [class]="cn(cx('messageContent'), message()?.contentStyleClass)">
                    @if (!template()) {
                        @if (message()?.icon) {
                            <span [pBind]="ptm('messageIcon')" [class]="cn(cx('messageIcon'), message()?.icon)"></span>
                        } @else {
                            @switch (message()?.severity) {
                                @case ('success') {
                                    <svg [pBind]="ptm('messageIcon')" data-p-icon="check" [class]="cx('messageIcon')" [attr.aria-hidden]="true" />
                                }
                                @case ('info') {
                                    <svg [pBind]="ptm('messageIcon')" data-p-icon="info-circle" [class]="cx('messageIcon')" [attr.aria-hidden]="true" />
                                }
                                @case ('error') {
                                    <svg [pBind]="ptm('messageIcon')" data-p-icon="times-circle" [class]="cx('messageIcon')" [attr.aria-hidden]="true" />
                                }
                                @case ('warn') {
                                    <svg [pBind]="ptm('messageIcon')" data-p-icon="exclamation-triangle" [class]="cx('messageIcon')" [attr.aria-hidden]="true" />
                                }
                                @default {
                                    <svg [pBind]="ptm('messageIcon')" data-p-icon="info-circle" [class]="cx('messageIcon')" [attr.aria-hidden]="true" />
                                }
                            }
                        }
                        <div [pBind]="ptm('messageText')" [ngClass]="cx('messageText')" [attr.data-p]="dataP">
                            <div [pBind]="ptm('summary')" [ngClass]="cx('summary')" [attr.data-p]="dataP">
                                {{ message()?.summary }}
                            </div>
                            <div [pBind]="ptm('detail')" [ngClass]="cx('detail')" [attr.data-p]="dataP">{{ message()?.detail }}</div>
                        </div>
                    }
                    <ng-container *ngTemplateOutlet="template(); context: { $implicit: message() }"></ng-container>
                    @if (message()?.closable !== false) {
                        <div>
                            <button
                                [pBind]="ptm('closeButton')"
                                type="button"
                                [attr.class]="cx('closeButton')"
                                (click)="onCloseIconClick($event)"
                                (keydown.enter)="onCloseIconClick($event)"
                                [attr.aria-label]="closeAriaLabel"
                                autofocus
                                [attr.data-p]="dataP"
                            >
                                @if (message()?.closeIcon) {
                                    @if (message()?.closeIcon) {
                                        <span [pBind]="ptm('closeIcon')" [class]="cn(cx('closeIcon'), message()?.closeIcon)"></span>
                                    }
                                } @else {
                                    <svg [pBind]="ptm('closeIcon')" data-p-icon="times" [class]="cx('closeIcon')" [attr.aria-hidden]="true" />
                                }
                            </button>
                        </div>
                    }
                </div>
            }
        </div>
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: CheckIcon, selector: "[data-p-icon=\"check\"]" }, { kind: "component", type: ExclamationTriangleIcon, selector: "[data-p-icon=\"exclamation-triangle\"]" }, { kind: "component", type: InfoCircleIcon, selector: "[data-p-icon=\"info-circle\"]" }, { kind: "component", type: TimesIcon, selector: "[data-p-icon=\"times\"]" }, { kind: "component", type: TimesCircleIcon, selector: "[data-p-icon=\"times-circle\"]" }, { kind: "ngmodule", type: SharedModule }, { kind: "directive", type: Bind, selector: "[pBind]", inputs: ["pBind"] }, { kind: "ngmodule", type: MotionModule }, { kind: "directive", type: i2.MotionDirective, selector: "[pMotion]", inputs: ["pMotion", "pMotionName", "pMotionType", "pMotionSafe", "pMotionDisabled", "pMotionAppear", "pMotionEnter", "pMotionLeave", "pMotionDuration", "pMotionHideStrategy", "pMotionEnterFromClass", "pMotionEnterToClass", "pMotionEnterActiveClass", "pMotionLeaveFromClass", "pMotionLeaveToClass", "pMotionLeaveActiveClass", "pMotionOptions"], outputs: ["pMotionOnBeforeEnter", "pMotionOnEnter", "pMotionOnAfterEnter", "pMotionOnEnterCancelled", "pMotionOnBeforeLeave", "pMotionOnLeave", "pMotionOnAfterLeave", "pMotionOnLeaveCancelled"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToastItem, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-toast-item',
                    standalone: true,
                    imports: [CommonModule, CheckIcon, ExclamationTriangleIcon, InfoCircleIcon, TimesIcon, TimesCircleIcon, SharedModule, Bind, MotionModule],
                    template: `
        <div
            #container
            [pMotion]="visible()"
            [pMotionAppear]="true"
            [pMotionName]="'p-toast-message'"
            [pMotionOptions]="motionOptions()"
            (pMotionOnBeforeEnter)="onBeforeEnter($event)"
            (pMotionOnAfterLeave)="onAfterLeave($event)"
            [attr.id]="message()?.id"
            [pBind]="ptm('message')"
            [class]="cn(cx('message'), message()?.styleClass)"
            (mouseenter)="onMouseEnter()"
            (mouseleave)="onMouseLeave()"
            role="alert"
            aria-live="assertive"
            aria-atomic="true"
            [attr.data-p]="dataP"
        >
            @if (headlessTemplate()) {
                <ng-container *ngTemplateOutlet="headlessTemplate(); context: { $implicit: message(), closeFn: onCloseIconClick }"></ng-container>
            } @else {
                <div [pBind]="ptm('messageContent')" [class]="cn(cx('messageContent'), message()?.contentStyleClass)">
                    @if (!template()) {
                        @if (message()?.icon) {
                            <span [pBind]="ptm('messageIcon')" [class]="cn(cx('messageIcon'), message()?.icon)"></span>
                        } @else {
                            @switch (message()?.severity) {
                                @case ('success') {
                                    <svg [pBind]="ptm('messageIcon')" data-p-icon="check" [class]="cx('messageIcon')" [attr.aria-hidden]="true" />
                                }
                                @case ('info') {
                                    <svg [pBind]="ptm('messageIcon')" data-p-icon="info-circle" [class]="cx('messageIcon')" [attr.aria-hidden]="true" />
                                }
                                @case ('error') {
                                    <svg [pBind]="ptm('messageIcon')" data-p-icon="times-circle" [class]="cx('messageIcon')" [attr.aria-hidden]="true" />
                                }
                                @case ('warn') {
                                    <svg [pBind]="ptm('messageIcon')" data-p-icon="exclamation-triangle" [class]="cx('messageIcon')" [attr.aria-hidden]="true" />
                                }
                                @default {
                                    <svg [pBind]="ptm('messageIcon')" data-p-icon="info-circle" [class]="cx('messageIcon')" [attr.aria-hidden]="true" />
                                }
                            }
                        }
                        <div [pBind]="ptm('messageText')" [ngClass]="cx('messageText')" [attr.data-p]="dataP">
                            <div [pBind]="ptm('summary')" [ngClass]="cx('summary')" [attr.data-p]="dataP">
                                {{ message()?.summary }}
                            </div>
                            <div [pBind]="ptm('detail')" [ngClass]="cx('detail')" [attr.data-p]="dataP">{{ message()?.detail }}</div>
                        </div>
                    }
                    <ng-container *ngTemplateOutlet="template(); context: { $implicit: message() }"></ng-container>
                    @if (message()?.closable !== false) {
                        <div>
                            <button
                                [pBind]="ptm('closeButton')"
                                type="button"
                                [attr.class]="cx('closeButton')"
                                (click)="onCloseIconClick($event)"
                                (keydown.enter)="onCloseIconClick($event)"
                                [attr.aria-label]="closeAriaLabel"
                                autofocus
                                [attr.data-p]="dataP"
                            >
                                @if (message()?.closeIcon) {
                                    @if (message()?.closeIcon) {
                                        <span [pBind]="ptm('closeIcon')" [class]="cn(cx('closeIcon'), message()?.closeIcon)"></span>
                                    }
                                } @else {
                                    <svg [pBind]="ptm('closeIcon')" data-p-icon="times" [class]="cx('closeIcon')" [attr.aria-hidden]="true" />
                                }
                            </button>
                        </div>
                    }
                </div>
            }
        </div>
    `,
                    encapsulation: ViewEncapsulation.None,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    providers: [ToastStyle]
                }]
        }], ctorParameters: () => [], propDecorators: { message: [{ type: i0.Input, args: [{ isSignal: true, alias: "message", required: false }] }], index: [{ type: i0.Input, args: [{ isSignal: true, alias: "index", required: false }] }], life: [{ type: i0.Input, args: [{ isSignal: true, alias: "life", required: false }] }], template: [{ type: i0.Input, args: [{ isSignal: true, alias: "template", required: false }] }], headlessTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "headlessTemplate", required: false }] }], showTransformOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "showTransformOptions", required: false }] }], hideTransformOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideTransformOptions", required: false }] }], showTransitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "showTransitionOptions", required: false }] }], hideTransitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideTransitionOptions", required: false }] }], motionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "motionOptions", required: false }] }], clearAll: [{ type: i0.Input, args: [{ isSignal: true, alias: "clearAll", required: false }] }], onAnimationStart: [{ type: i0.Output, args: ["onAnimationStart"] }], onAnimationEnd: [{ type: i0.Output, args: ["onAnimationEnd"] }], onClose: [{ type: i0.Output, args: ["onClose"] }] } });
/**
 * Toast is used to display messages in an overlay.
 * @group Components
 */
class Toast extends BaseComponent {
    componentName = 'Toast';
    $pcToast = inject(TOAST_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    /**
     * Key of the message in case message is targeted to a specific toast component.
     * @group Props
     */
    key = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "key" }] : /* istanbul ignore next */ []));
    /**
     * Whether to automatically manage layering.
     * @group Props
     */
    autoZIndex = input(true, { ...(ngDevMode ? { debugName: "autoZIndex" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Base zIndex value to use in layering.
     * @group Props
     */
    baseZIndex = input(0, { ...(ngDevMode ? { debugName: "baseZIndex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * The default time to display messages for in milliseconds.
     * @group Props
     */
    life = input(3000, { ...(ngDevMode ? { debugName: "life" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Inline class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Position of the toast in viewport.
     * @group Props
     */
    position = input('top-right', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "position" }] : /* istanbul ignore next */ []));
    /**
     * It does not add the new message if there is already a toast displayed with the same content
     * @group Props
     */
    preventOpenDuplicates = input(false, { ...(ngDevMode ? { debugName: "preventOpenDuplicates" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Displays only once a message with the same content.
     * @group Props
     */
    preventDuplicates = input(false, { ...(ngDevMode ? { debugName: "preventDuplicates" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Transform options of the show animation.
     * @group Props
     * @deprecated since v21.0.0. Use `motionOptions` instead.
     */
    showTransformOptions = input('translateY(100%)', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showTransformOptions" }] : /* istanbul ignore next */ []));
    /**
     * Transform options of the hide animation.
     * @group Props
     * @deprecated since v21.0.0. Use `motionOptions` instead.
     */
    hideTransformOptions = input('translateY(-100%)', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hideTransformOptions" }] : /* istanbul ignore next */ []));
    /**
     * Transition options of the show animation.
     * @group Props
     * @deprecated since v21.0.0. Use `motionOptions` instead.
     */
    showTransitionOptions = input('300ms ease-out', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showTransitionOptions" }] : /* istanbul ignore next */ []));
    /**
     * Transition options of the hide animation.
     * @group Props
     * @deprecated since v21.0.0. Use `motionOptions` instead.
     */
    hideTransitionOptions = input('250ms ease-in', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hideTransitionOptions" }] : /* istanbul ignore next */ []));
    /**
     * The motion options.
     * @group Props
     */
    motionOptions = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "motionOptions" }] : /* istanbul ignore next */ []));
    computedMotionOptions = computed(() => ({
        ...this.ptm('motion'),
        ...this.motionOptions()
    }), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "computedMotionOptions" }] : /* istanbul ignore next */ []));
    /**
     * Object literal to define styles per screen size.
     * @group Props
     */
    breakpoints = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "breakpoints" }] : /* istanbul ignore next */ []));
    /**
     * Callback to invoke when a message is closed.
     * @param {ToastCloseEvent} event - custom close event.
     * @group Emits
     */
    onClose = output();
    /**
     * Custom message template.
     * @param {ToastMessageTemplateContext} context - message context.
     * @see {@link ToastMessageTemplateContext}
     * @group Templates
     */
    template = contentChild('message', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "template" }] : /* istanbul ignore next */ []));
    /**
     * Custom headless template.
     * @param {ToastHeadlessTemplateContext} context - headless context.
     * @see {@link ToastHeadlessTemplateContext}
     * @group Templates
     */
    headlessTemplate = contentChild('headless', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "headlessTemplate" }] : /* istanbul ignore next */ []));
    messageSubscription;
    clearSubscription;
    messages;
    messagesArchieve;
    messageService = inject(MessageService);
    _componentStyle = inject(ToastStyle);
    styleElement;
    id = uuid('pn_id_');
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    clearAllTrigger = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "clearAllTrigger" }] : /* istanbul ignore next */ []));
    constructor() {
        super();
    }
    onInit() {
        this.messageSubscription = this.messageService.messageObserver.subscribe((messages) => {
            if (messages) {
                if (Array.isArray(messages)) {
                    const filteredMessages = messages.filter((m) => this.canAdd(m));
                    this.add(filteredMessages);
                }
                else if (this.canAdd(messages)) {
                    this.add([messages]);
                }
            }
        });
        this.clearSubscription = this.messageService.clearObserver.subscribe((key) => {
            if (key) {
                if (this.key() === key) {
                    this.clearAll();
                }
            }
            else {
                this.clearAll();
            }
            this.cd.markForCheck();
        });
    }
    clearAll() {
        // trigger signal to clear all messages
        this.clearAllTrigger.set({});
    }
    _template;
    _headlessTemplate;
    onAfterContentInit() {
        this.templates()?.forEach((item) => {
            switch (item.getType()) {
                case 'message':
                    this._template = item.template;
                    break;
                case 'headless':
                    this._headlessTemplate = item.template;
                    break;
                default:
                    this._template = item.template;
                    break;
            }
        });
    }
    onAfterViewInit() {
        if (this.breakpoints()) {
            this.createStyle();
        }
    }
    add(messages) {
        this.messages = this.messages ? [...this.messages, ...messages] : [...messages];
        if (this.preventDuplicates()) {
            this.messagesArchieve = this.messagesArchieve ? [...this.messagesArchieve, ...messages] : [...messages];
        }
        this.cd.markForCheck();
    }
    canAdd(message) {
        let allow = this.key() === message.key;
        if (allow && this.preventOpenDuplicates()) {
            allow = !this.containsMessage(this.messages, message);
        }
        if (allow && this.preventDuplicates()) {
            allow = !this.containsMessage(this.messagesArchieve, message);
        }
        return allow;
    }
    containsMessage(collection, message) {
        if (!collection) {
            return false;
        }
        return collection.find((m) => m.summary === message.summary && m.detail == message.detail && m.severity === message.severity) != null;
    }
    onMessageClose(event) {
        this.messages?.splice(event.index, 1);
        this.onClose.emit({
            message: event.message
        });
        this.onAnimationEnd();
        this.cd.detectChanges();
    }
    onAnimationStart() {
        this.renderer.setAttribute(this.el?.nativeElement, this.id, '');
        if (this.autoZIndex() && this.el?.nativeElement.style.zIndex === '') {
            ZIndexUtils.set('modal', this.el?.nativeElement, this.baseZIndex() || this.config.zIndex.modal);
        }
    }
    onAnimationEnd() {
        if (this.autoZIndex() && isEmpty(this.messages)) {
            ZIndexUtils.clear(this.el?.nativeElement);
        }
    }
    createStyle() {
        if (!this.styleElement) {
            this.styleElement = this.renderer.createElement('style');
            this.styleElement.type = 'text/css';
            setAttribute(this.styleElement, 'nonce', this.config?.csp()?.nonce);
            this.renderer.appendChild(this.document.head, this.styleElement);
            let innerHTML = '';
            const breakpoints = this.breakpoints();
            for (let breakpoint in breakpoints) {
                let breakpointStyle = '';
                for (let styleProp in breakpoints[breakpoint]) {
                    breakpointStyle += styleProp + ':' + breakpoints[breakpoint][styleProp] + ' !important;';
                }
                innerHTML += `
                    @media screen and (max-width: ${breakpoint}) {
                        .p-toast[${this.id}] {
                           ${breakpointStyle}
                        }
                    }
                `;
            }
            this.renderer.setProperty(this.styleElement, 'innerHTML', innerHTML);
            setAttribute(this.styleElement, 'nonce', this.config?.csp()?.nonce);
        }
    }
    destroyStyle() {
        if (this.styleElement) {
            this.renderer.removeChild(this.document.head, this.styleElement);
            this.styleElement = null;
        }
    }
    onDestroy() {
        if (this.messageSubscription) {
            this.messageSubscription.unsubscribe();
        }
        if (this.el && this.autoZIndex()) {
            ZIndexUtils.clear(this.el.nativeElement);
        }
        if (this.clearSubscription) {
            this.clearSubscription.unsubscribe();
        }
        this.destroyStyle();
    }
    get dataP() {
        const position = this.position();
        return this.cn({
            [position]: position
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Toast, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: Toast, isStandalone: true, selector: "p-toast", inputs: { key: { classPropertyName: "key", publicName: "key", isSignal: true, isRequired: false, transformFunction: null }, autoZIndex: { classPropertyName: "autoZIndex", publicName: "autoZIndex", isSignal: true, isRequired: false, transformFunction: null }, baseZIndex: { classPropertyName: "baseZIndex", publicName: "baseZIndex", isSignal: true, isRequired: false, transformFunction: null }, life: { classPropertyName: "life", publicName: "life", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, position: { classPropertyName: "position", publicName: "position", isSignal: true, isRequired: false, transformFunction: null }, preventOpenDuplicates: { classPropertyName: "preventOpenDuplicates", publicName: "preventOpenDuplicates", isSignal: true, isRequired: false, transformFunction: null }, preventDuplicates: { classPropertyName: "preventDuplicates", publicName: "preventDuplicates", isSignal: true, isRequired: false, transformFunction: null }, showTransformOptions: { classPropertyName: "showTransformOptions", publicName: "showTransformOptions", isSignal: true, isRequired: false, transformFunction: null }, hideTransformOptions: { classPropertyName: "hideTransformOptions", publicName: "hideTransformOptions", isSignal: true, isRequired: false, transformFunction: null }, showTransitionOptions: { classPropertyName: "showTransitionOptions", publicName: "showTransitionOptions", isSignal: true, isRequired: false, transformFunction: null }, hideTransitionOptions: { classPropertyName: "hideTransitionOptions", publicName: "hideTransitionOptions", isSignal: true, isRequired: false, transformFunction: null }, motionOptions: { classPropertyName: "motionOptions", publicName: "motionOptions", isSignal: true, isRequired: false, transformFunction: null }, breakpoints: { classPropertyName: "breakpoints", publicName: "breakpoints", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onClose: "onClose" }, host: { properties: { "class": "cn(cx('root'), styleClass())", "style": "sx('root')", "attr.data-p": "dataP" } }, providers: [ToastStyle, { provide: TOAST_INSTANCE, useExisting: Toast }, { provide: PARENT_INSTANCE, useExisting: Toast }], queries: [{ propertyName: "template", first: true, predicate: ["message"], descendants: true, isSignal: true }, { propertyName: "headlessTemplate", first: true, predicate: ["headless"], descendants: true, isSignal: true }, { propertyName: "templates", predicate: PrimeTemplate, isSignal: true }], usesInheritance: true, hostDirectives: [{ directive: i3.Bind }], ngImport: i0, template: `
        @for (msg of messages; track msg; let i = $index) {
            <p-toast-item
                [message]="msg"
                [index]="i"
                [life]="life()"
                [clearAll]="clearAllTrigger()"
                (onClose)="onMessageClose($event)"
                (onAnimationEnd)="onAnimationEnd()"
                (onAnimationStart)="onAnimationStart()"
                [template]="template() || _template"
                [headlessTemplate]="headlessTemplate() || _headlessTemplate"
                [pt]="pt"
                [unstyled]="unstyled()"
                [motionOptions]="computedMotionOptions()"
            ></p-toast-item>
        }
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: ToastItem, selector: "p-toast-item", inputs: ["message", "index", "life", "template", "headlessTemplate", "showTransformOptions", "hideTransformOptions", "showTransitionOptions", "hideTransitionOptions", "motionOptions", "clearAll"], outputs: ["onAnimationStart", "onAnimationEnd", "onClose"] }, { kind: "ngmodule", type: SharedModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Toast, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-toast',
                    standalone: true,
                    imports: [CommonModule, ToastItem, SharedModule],
                    template: `
        @for (msg of messages; track msg; let i = $index) {
            <p-toast-item
                [message]="msg"
                [index]="i"
                [life]="life()"
                [clearAll]="clearAllTrigger()"
                (onClose)="onMessageClose($event)"
                (onAnimationEnd)="onAnimationEnd()"
                (onAnimationStart)="onAnimationStart()"
                [template]="template() || _template"
                [headlessTemplate]="headlessTemplate() || _headlessTemplate"
                [pt]="pt"
                [unstyled]="unstyled()"
                [motionOptions]="computedMotionOptions()"
            ></p-toast-item>
        }
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [ToastStyle, { provide: TOAST_INSTANCE, useExisting: Toast }, { provide: PARENT_INSTANCE, useExisting: Toast }],
                    host: {
                        '[class]': "cn(cx('root'), styleClass())",
                        '[style]': "sx('root')",
                        '[attr.data-p]': 'dataP'
                    },
                    hostDirectives: [Bind]
                }]
        }], ctorParameters: () => [], propDecorators: { key: [{ type: i0.Input, args: [{ isSignal: true, alias: "key", required: false }] }], autoZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoZIndex", required: false }] }], baseZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "baseZIndex", required: false }] }], life: [{ type: i0.Input, args: [{ isSignal: true, alias: "life", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], position: [{ type: i0.Input, args: [{ isSignal: true, alias: "position", required: false }] }], preventOpenDuplicates: [{ type: i0.Input, args: [{ isSignal: true, alias: "preventOpenDuplicates", required: false }] }], preventDuplicates: [{ type: i0.Input, args: [{ isSignal: true, alias: "preventDuplicates", required: false }] }], showTransformOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "showTransformOptions", required: false }] }], hideTransformOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideTransformOptions", required: false }] }], showTransitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "showTransitionOptions", required: false }] }], hideTransitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideTransitionOptions", required: false }] }], motionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "motionOptions", required: false }] }], breakpoints: [{ type: i0.Input, args: [{ isSignal: true, alias: "breakpoints", required: false }] }], onClose: [{ type: i0.Output, args: ["onClose"] }], template: [{ type: i0.ContentChild, args: ['message', { isSignal: true }] }], headlessTemplate: [{ type: i0.ContentChild, args: ['headless', { isSignal: true }] }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class ToastModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToastModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: ToastModule, imports: [Toast, SharedModule], exports: [Toast, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToastModule, imports: [Toast, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToastModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [Toast, SharedModule],
                    exports: [Toast, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { Toast, ToastClasses, ToastItem, ToastModule, ToastStyle };
//# sourceMappingURL=wawjs-ngx-prime-toast.mjs.map
