export * from '@wawjs/ngx-prime/types/fluid';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const classes = {
    root: 'p-fluid'
};
class FluidStyle extends BaseStyle {
    name = 'fluid';
    classes = classes;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FluidStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FluidStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FluidStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * Fluid is a layout component to make descendant components span full width of their container.
 *
 * [Live Demo](https://www.ngx-prime.org/fluid/)
 *
 * @module fluidstyle
 *
 */
var FluidClasses;
(function (FluidClasses) {
    /**
     * Class name of the root element
     */
    FluidClasses["root"] = "p-fluid";
})(FluidClasses || (FluidClasses = {}));

const FLUID_INSTANCE = new InjectionToken('FLUID_INSTANCE');
/**
 * Fluid is a layout component to make descendant components span full width of their container.
 * @group Components
 */
class Fluid extends BaseComponent {
    componentName = 'Fluid';
    $pcFluid = inject(FLUID_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    _componentStyle = inject(FluidStyle);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Fluid, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.1.2", type: Fluid, isStandalone: true, selector: "p-fluid", host: { properties: { "class": "cx('root')" } }, providers: [FluidStyle, { provide: FLUID_INSTANCE, useExisting: Fluid }, { provide: PARENT_INSTANCE, useExisting: Fluid }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: ` <ng-content></ng-content> `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Fluid, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-fluid',
                    template: ` <ng-content></ng-content> `,
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [FluidStyle, { provide: FLUID_INSTANCE, useExisting: Fluid }, { provide: PARENT_INSTANCE, useExisting: Fluid }],
                    host: {
                        '[class]': "cx('root')"
                    },
                    hostDirectives: [Bind]
                }]
        }] });
class FluidModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FluidModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: FluidModule, imports: [Fluid], exports: [Fluid] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FluidModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FluidModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [Fluid],
                    exports: [Fluid]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { Fluid, FluidClasses, FluidModule, FluidStyle };
//# sourceMappingURL=wawjs-ngx-prime-fluid.mjs.map
