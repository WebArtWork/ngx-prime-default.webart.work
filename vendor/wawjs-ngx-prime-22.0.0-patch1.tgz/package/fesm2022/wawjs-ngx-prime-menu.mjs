export * from '@wawjs/ngx-prime/types/menu';
import * as i1 from '@angular/common';
import { isPlatformBrowser, CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, PLATFORM_ID, Pipe, input, output, ViewEncapsulation, Component, booleanAttribute, numberAttribute, computed, viewChild, signal, contentChild, contentChildren, ContentChild, ChangeDetectionStrategy, NgModule } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import * as i2 from '@angular/router';
import { RouterModule } from '@angular/router';
import { uuid, addStyle, absolutePosition, focus, appendChild, isTouchDevice, find, findSingle } from '@wawjs/css-prime-utils';
import { SharedModule, OverlayService, PrimeTemplate } from '@wawjs/ngx-prime/api';
import * as i4 from '@wawjs/ngx-prime/badge';
import { BadgeModule } from '@wawjs/ngx-prime/badge';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i3 from '@wawjs/ngx-prime/bind';
import { BindModule, Bind } from '@wawjs/ngx-prime/bind';
import { ConnectedOverlayScrollHandler } from '@wawjs/ngx-prime/dom';
import * as i6 from '@wawjs/ngx-prime/motion';
import { MotionModule } from '@wawjs/ngx-prime/motion';
import { Ripple } from '@wawjs/ngx-prime/ripple';
import * as i5 from '@wawjs/ngx-prime/tooltip';
import { TooltipModule } from '@wawjs/ngx-prime/tooltip';
import { ZIndexUtils } from '@wawjs/ngx-prime/utils';
import { style } from '@wawjs/css-prime-styles/menu';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const inlineStyles = {
    root: ({ instance }) => ({ position: instance.popup() ? 'absolute' : 'relative' })
};
const classes = {
    root: ({ instance }) => [
        'p-menu p-component',
        {
            'p-menu-overlay': instance.popup()
        }
    ],
    start: 'p-menu-start',
    list: 'p-menu-list',
    submenuLabel: 'p-menu-submenu-label',
    separator: 'p-menu-separator',
    end: 'p-menu-end',
    item: ({ instance, item, id }) => [
        'p-menu-item',
        {
            'p-focus': instance.focusedOptionId() && id === instance.focusedOptionId(),
            'p-disabled': instance.disabled(item.disabled)
        },
        item.styleClass
    ],
    itemContent: 'p-menu-item-content',
    itemLink: 'p-menu-item-link',
    itemIcon: ({ item }) => ['p-menu-item-icon', item.icon, item.iconClass],
    itemLabel: 'p-menu-item-label'
};
class MenuStyle extends BaseStyle {
    name = 'menu';
    style = style;
    classes = classes;
    inlineStyles = inlineStyles;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MenuStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MenuStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MenuStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * Menu is a navigation / command component that supports dynamic and static positioning.
 *
 * [Live Demo](https://www.ngx-prime.org/menu/)
 *
 * @module menustyle
 *
 */
var MenuClasses;
(function (MenuClasses) {
    /**
     * Class name of the root element
     */
    MenuClasses["root"] = "p-menu";
    /**
     * Class name of the start element
     */
    MenuClasses["start"] = "p-menu-start";
    /**
     * Class name of the list element
     */
    MenuClasses["list"] = "p-menu-list";
    /**
     * Class name of the submenu item element
     */
    MenuClasses["submenuItem"] = "p-menu-submenu-item";
    /**
     * Class name of the separator element
     */
    MenuClasses["separator"] = "p-menu-separator";
    /**
     * Class name of the end element
     */
    MenuClasses["end"] = "p-menu-end";
    /**
     * Class name of the item element
     */
    MenuClasses["item"] = "p-menu-item";
    /**
     * Class name of the item content element
     */
    MenuClasses["itemContent"] = "p-menu-item-content";
    /**
     * Class name of the item link element
     */
    MenuClasses["itemLink"] = "p-menu-item-link";
    /**
     * Class name of the item icon element
     */
    MenuClasses["itemIcon"] = "p-menu-item-icon";
    /**
     * Class name of the item label element
     */
    MenuClasses["itemLabel"] = "p-menu-item-label";
})(MenuClasses || (MenuClasses = {}));

const MENU_INSTANCE = new InjectionToken('MENU_INSTANCE');
class SafeHtmlPipe {
    platformId = inject(PLATFORM_ID);
    sanitizer = inject(DomSanitizer);
    transform(value) {
        if (!value || !isPlatformBrowser(this.platformId)) {
            return value;
        }
        return this.sanitizer.bypassSecurityTrustHtml(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SafeHtmlPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: SafeHtmlPipe, isStandalone: true, name: "safeHtml" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SafeHtmlPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'safeHtml',
                    standalone: true
                }]
        }] });
class MenuItemContent extends BaseComponent {
    item = input(undefined, { ...(ngDevMode ? { debugName: "item" } : /* istanbul ignore next */ {}), alias: 'pMenuItemContent' });
    itemTemplate = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "itemTemplate" }] : /* istanbul ignore next */ []));
    menuitemId = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "menuitemId" }] : /* istanbul ignore next */ []));
    idx = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "idx" }] : /* istanbul ignore next */ []));
    onMenuItemClick = output();
    menu;
    _componentStyle = inject(MenuStyle);
    hostName = 'Menu';
    constructor() {
        const menu = inject(Menu);
        super();
        this.menu = menu;
    }
    onItemClick(event, item) {
        this.onMenuItemClick.emit({ originalEvent: event, item });
    }
    getPTOptions(key) {
        return this.menu.getPTOptions(key, this.item(), this.idx(), this.menuitemId());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MenuItemContent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: MenuItemContent, isStandalone: true, selector: "[pMenuItemContent]", inputs: { item: { classPropertyName: "item", publicName: "pMenuItemContent", isSignal: true, isRequired: false, transformFunction: null }, itemTemplate: { classPropertyName: "itemTemplate", publicName: "itemTemplate", isSignal: true, isRequired: false, transformFunction: null }, menuitemId: { classPropertyName: "menuitemId", publicName: "menuitemId", isSignal: true, isRequired: false, transformFunction: null }, idx: { classPropertyName: "idx", publicName: "idx", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onMenuItemClick: "onMenuItemClick" }, providers: [MenuStyle], usesInheritance: true, ngImport: i0, template: ` <div [class]="cx('itemContent')" (click)="onItemClick($event, item())" [attr.data-pc-section]="'content'" [pBind]="getPTOptions('itemContent')">
        @if (!itemTemplate()) {
            @if (!item()?.routerLink) {
                <a
                    [attr.title]="item()!.title"
                    [attr.href]="item()!.url || null"
                    [attr.data-automationid]="item()!.automationId"
                    [attr.tabindex]="-1"
                    [class]="cn(cx('itemLink'), item()?.linkClass)"
                    [ngStyle]="item()?.linkStyle"
                    [target]="item()!.target"
                    [pBind]="getPTOptions('itemLink')"
                    pRipple
                >
                    <ng-container *ngTemplateOutlet="itemContent; context: { $implicit: item() }"></ng-container>
                </a>
            }
            @if (item()?.routerLink) {
                <a
                    [routerLink]="item()!.routerLink"
                    [attr.data-automationid]="item()!.automationId"
                    [attr.tabindex]="-1"
                    [attr.title]="item()!.title"
                    [queryParams]="item()!.queryParams"
                    routerLinkActive="p-menu-item-link-active"
                    [routerLinkActiveOptions]="item()!.routerLinkActiveOptions || { exact: false }"
                    [class]="cn(cx('itemLink'), item()?.linkClass)"
                    [ngStyle]="item()?.linkStyle"
                    [target]="item()!.target"
                    [fragment]="item()!.fragment"
                    [queryParamsHandling]="item()!.queryParamsHandling"
                    [preserveFragment]="item()!.preserveFragment"
                    [skipLocationChange]="item()!.skipLocationChange"
                    [replaceUrl]="item()!.replaceUrl"
                    [state]="item()!.state"
                    [pBind]="getPTOptions('itemLink')"
                    pRipple
                >
                    <ng-container *ngTemplateOutlet="itemContent; context: { $implicit: item() }"></ng-container>
                </a>
            }
        }

        @if (itemTemplate()) {
            <ng-template *ngTemplateOutlet="itemTemplate(); context: { $implicit: item() }"></ng-template>
        }

        <ng-template #itemContent>
            @if (item()!.icon) {
                <span [class]="cn(cx('itemIcon', { item: item() }), item()!.iconClass)" [pBind]="getPTOptions('itemIcon')" [ngStyle]="item()!.iconStyle" [attr.data-pc-section]="'itemicon'"></span>
            }
            @if (item()!.escape !== false) {
                <span [class]="cn(cx('itemLabel'), item()!.labelClass)" [ngStyle]="item()!.labelStyle" [pBind]="getPTOptions('itemLabel')" [attr.data-pc-section]="'itemlabel'">{{ item()!.label }}</span>
            } @else {
                <span [class]="cn(cx('itemLabel'), item()!.labelClass)" [ngStyle]="item()!.labelStyle" [attr.data-pc-section]="'itemlabel'" [innerHTML]="item()!.label | safeHtml" [pBind]="getPTOptions('itemLabel')"></span>
            }
            @if (item()!.badge) {
                <p-badge [styleClass]="item()!.badgeStyleClass" [value]="item()!.badge" [pt]="getPTOptions('pcBadge')" [unstyled]="unstyled()" />
            }
        </ng-template>
    </div>`, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i2.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "browserUrl", "routerLink"] }, { kind: "directive", type: i2.RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "directive", type: Ripple, selector: "[pRipple]" }, { kind: "ngmodule", type: TooltipModule }, { kind: "directive", type: i3.Bind, selector: "[pBind]", inputs: ["pBind"] }, { kind: "ngmodule", type: BadgeModule }, { kind: "component", type: i4.Badge, selector: "p-badge", inputs: ["styleClass", "badgeSize", "size", "severity", "value", "badgeDisabled"] }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: BindModule }, { kind: "pipe", type: SafeHtmlPipe, name: "safeHtml" }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MenuItemContent, decorators: [{
            type: Component,
            args: [{
                    selector: '[pMenuItemContent]',
                    standalone: true,
                    imports: [CommonModule, RouterModule, Ripple, TooltipModule, BadgeModule, SharedModule, SafeHtmlPipe, BindModule],
                    template: ` <div [class]="cx('itemContent')" (click)="onItemClick($event, item())" [attr.data-pc-section]="'content'" [pBind]="getPTOptions('itemContent')">
        @if (!itemTemplate()) {
            @if (!item()?.routerLink) {
                <a
                    [attr.title]="item()!.title"
                    [attr.href]="item()!.url || null"
                    [attr.data-automationid]="item()!.automationId"
                    [attr.tabindex]="-1"
                    [class]="cn(cx('itemLink'), item()?.linkClass)"
                    [ngStyle]="item()?.linkStyle"
                    [target]="item()!.target"
                    [pBind]="getPTOptions('itemLink')"
                    pRipple
                >
                    <ng-container *ngTemplateOutlet="itemContent; context: { $implicit: item() }"></ng-container>
                </a>
            }
            @if (item()?.routerLink) {
                <a
                    [routerLink]="item()!.routerLink"
                    [attr.data-automationid]="item()!.automationId"
                    [attr.tabindex]="-1"
                    [attr.title]="item()!.title"
                    [queryParams]="item()!.queryParams"
                    routerLinkActive="p-menu-item-link-active"
                    [routerLinkActiveOptions]="item()!.routerLinkActiveOptions || { exact: false }"
                    [class]="cn(cx('itemLink'), item()?.linkClass)"
                    [ngStyle]="item()?.linkStyle"
                    [target]="item()!.target"
                    [fragment]="item()!.fragment"
                    [queryParamsHandling]="item()!.queryParamsHandling"
                    [preserveFragment]="item()!.preserveFragment"
                    [skipLocationChange]="item()!.skipLocationChange"
                    [replaceUrl]="item()!.replaceUrl"
                    [state]="item()!.state"
                    [pBind]="getPTOptions('itemLink')"
                    pRipple
                >
                    <ng-container *ngTemplateOutlet="itemContent; context: { $implicit: item() }"></ng-container>
                </a>
            }
        }

        @if (itemTemplate()) {
            <ng-template *ngTemplateOutlet="itemTemplate(); context: { $implicit: item() }"></ng-template>
        }

        <ng-template #itemContent>
            @if (item()!.icon) {
                <span [class]="cn(cx('itemIcon', { item: item() }), item()!.iconClass)" [pBind]="getPTOptions('itemIcon')" [ngStyle]="item()!.iconStyle" [attr.data-pc-section]="'itemicon'"></span>
            }
            @if (item()!.escape !== false) {
                <span [class]="cn(cx('itemLabel'), item()!.labelClass)" [ngStyle]="item()!.labelStyle" [pBind]="getPTOptions('itemLabel')" [attr.data-pc-section]="'itemlabel'">{{ item()!.label }}</span>
            } @else {
                <span [class]="cn(cx('itemLabel'), item()!.labelClass)" [ngStyle]="item()!.labelStyle" [attr.data-pc-section]="'itemlabel'" [innerHTML]="item()!.label | safeHtml" [pBind]="getPTOptions('itemLabel')"></span>
            }
            @if (item()!.badge) {
                <p-badge [styleClass]="item()!.badgeStyleClass" [value]="item()!.badge" [pt]="getPTOptions('pcBadge')" [unstyled]="unstyled()" />
            }
        </ng-template>
    </div>`,
                    encapsulation: ViewEncapsulation.None,
                    providers: [MenuStyle]
                }]
        }], ctorParameters: () => [], propDecorators: { item: [{ type: i0.Input, args: [{ isSignal: true, alias: "pMenuItemContent", required: false }] }], itemTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemTemplate", required: false }] }], menuitemId: [{ type: i0.Input, args: [{ isSignal: true, alias: "menuitemId", required: false }] }], idx: [{ type: i0.Input, args: [{ isSignal: true, alias: "idx", required: false }] }], onMenuItemClick: [{ type: i0.Output, args: ["onMenuItemClick"] }] } });
/**
 * Menu is a navigation / command component that supports dynamic and static positioning.
 * @group Components
 */
class Menu extends BaseComponent {
    overlayService = inject(OverlayService);
    componentName = 'Menu';
    /**
     * An array of menuitems.
     * @group Props
     */
    model = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "model" }] : /* istanbul ignore next */ []));
    /**
     * Defines if menu would displayed as a popup.
     * @group Props
     */
    popup = input(undefined, { ...(ngDevMode ? { debugName: "popup" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Inline style of the component.
     * @group Props
     */
    style = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "style" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the component.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Whether to automatically manage layering.
     * @group Props
     */
    autoZIndex = input(true, { ...(ngDevMode ? { debugName: "autoZIndex" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Base zIndex value to use in layering.
     * @group Props
     */
    baseZIndex = input(0, { ...(ngDevMode ? { debugName: "baseZIndex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Transition options of the show animation.
     * @deprecated since v21.0.0, use `motionOptions` instead.
     * @group Props
     */
    showTransitionOptions = input('.12s cubic-bezier(0, 0, 0.2, 1)', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showTransitionOptions" }] : /* istanbul ignore next */ []));
    /**
     * Transition options of the hide animation.
     * @deprecated since v21.0.0, use `motionOptions` instead.
     * @group Props
     */
    hideTransitionOptions = input('.1s linear', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hideTransitionOptions" }] : /* istanbul ignore next */ []));
    /**
     * Defines a string value that labels an interactive element.
     * @group Props
     */
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /**
     * Identifier of the underlying input element.
     * @group Props
     */
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    /**
     * Current id state as a string.
     * @group Props
     */
    id = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "id" }] : /* istanbul ignore next */ []));
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex = input(0, { ...(ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'self'
     * @group Props
     */
    appendTo = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "appendTo" }] : /* istanbul ignore next */ []));
    /**
     * The motion options.
     * @group Props
     */
    motionOptions = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "motionOptions" }] : /* istanbul ignore next */ []));
    computedMotionOptions = computed(() => ({
        ...this.ptm('motion'),
        ...this.motionOptions()
    }), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "computedMotionOptions" }] : /* istanbul ignore next */ []));
    /**
     * Callback to invoke when overlay menu is shown.
     * @group Emits
     */
    onShow = output();
    /**
     * Callback to invoke when overlay menu is hidden.
     * @group Emits
     */
    onHide = output();
    /**
     * Callback to invoke when the list loses focus.
     * @param {Event} event - blur event.
     * @group Emits
     */
    onBlur = output();
    /**
     * Callback to invoke when the list receives focus.
     * @param {Event} event - focus event.
     * @group Emits
     */
    onFocus = output();
    listViewChild = viewChild('list', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "listViewChild" }] : /* istanbul ignore next */ []));
    containerViewChild = viewChild('container', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "containerViewChild" }] : /* istanbul ignore next */ []));
    $appendTo = computed(() => this.appendTo() || this.config.overlayAppendTo(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "$appendTo" }] : /* istanbul ignore next */ []));
    container;
    scrollHandler;
    documentClickListener;
    documentResizeListener;
    preventDocumentDefault;
    target;
    visible;
    focusedOptionId = computed(() => (this.focusedOptionIndex() !== -1 ? this.focusedOptionIndex() : null), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusedOptionId" }] : /* istanbul ignore next */ []));
    focusedOptionIndex = signal(-1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusedOptionIndex" }] : /* istanbul ignore next */ []));
    selectedOptionIndex = signal(-1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedOptionIndex" }] : /* istanbul ignore next */ []));
    focused = false;
    overlayVisible = false;
    $pcMenu = inject(MENU_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    _componentStyle = inject(MenuStyle);
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptm('host'));
    }
    _generatedId = uuid('pn_id_');
    get resolvedId() {
        return this.id() || this._generatedId;
    }
    getPTOptions(key, item, index, id) {
        return this.ptm(key, {
            context: {
                item: item,
                index: index,
                focused: this.isItemFocused(id),
                disabled: this.disabled(item.disabled)
            }
        });
    }
    /**
     * Toggles the visibility of the popup menu.
     * @param {Event} event - Browser event.
     * @group Method
     */
    toggle(event) {
        if (this.visible)
            this.hide();
        else
            this.show(event);
        this.preventDocumentDefault = true;
    }
    /**
     * Displays the popup menu.
     * @param {Event} event - Browser event.
     * @group Method
     */
    show(event) {
        // Clear container if exists but overlay is not currently visible (fast toggle case)
        if (this.container && !this.overlayVisible) {
            this.container = undefined;
        }
        this.target = event.currentTarget;
        this.visible = true;
        this.preventDocumentDefault = true;
        this.overlayVisible = true;
        this.cd.markForCheck();
    }
    onInit() {
        if (!this.popup()) {
            this.bindDocumentClickListener();
        }
    }
    /**
     * Defines template option for start.
     * @group Templates
     */
    startTemplate;
    _startTemplate;
    /**
     * Defines template option for end.
     * @group Templates
     */
    endTemplate;
    _endTemplate;
    /**
     * Defines template option for header.
     * @group Templates
     */
    headerTemplate = contentChild('header', { ...(ngDevMode ? { debugName: "headerTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    _headerTemplate;
    /**
     * Custom item template.
     * @param {MenuItemTemplateContext} context - item context.
     * @see {@link MenuItemTemplateContext}
     * @group Templates
     */
    itemTemplate = contentChild('item', { ...(ngDevMode ? { debugName: "itemTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    _itemTemplate;
    /**
     * Custom submenu header template.
     * @param {MenuSubmenuHeaderTemplateContext} context - submenu header context.
     * @see {@link MenuSubmenuHeaderTemplateContext}
     * @group Templates
     */
    submenuHeaderTemplate = contentChild('submenuheader', { ...(ngDevMode ? { debugName: "submenuHeaderTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    _submenuHeaderTemplate;
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    onAfterContentInit() {
        this.templates()?.forEach((item) => {
            switch (item.getType()) {
                case 'start':
                    this._startTemplate = item.template;
                    break;
                case 'end':
                    this._endTemplate = item.template;
                    break;
                case 'item':
                    this._itemTemplate = item.template;
                    break;
                case 'submenuheader':
                    this._submenuHeaderTemplate = item.template;
                    break;
                default:
                    this._itemTemplate = item.template;
                    break;
            }
        });
    }
    getTabIndexValue() {
        return this.tabindex() !== undefined ? this.tabindex().toString() : null;
    }
    onOverlayBeforeEnter(event) {
        this.container = event.element;
        if (this.container) {
            addStyle(this.container, { position: 'absolute', top: '0' });
            this.appendOverlay();
            this.moveOnTop();
            this.$attrSelector && this.container?.setAttribute(this.$attrSelector, '');
            this.bindDocumentClickListener();
            this.bindDocumentResizeListener();
            this.bindScrollListener();
            absolutePosition(this.container, this.target);
            focus(this.listViewChild()?.nativeElement);
            this.onShow.emit({});
        }
    }
    onOverlayAfterLeave() {
        this.restoreOverlayAppend();
        this.onOverlayHide();
        this.overlayVisible = false;
        this.onHide.emit({});
    }
    appendOverlay() {
        if (this.$appendTo() && this.$appendTo() !== 'self') {
            if (this.$appendTo() === 'body') {
                appendChild(this.document.body, this.container);
            }
            else {
                appendChild(this.$appendTo(), this.container);
            }
        }
    }
    restoreOverlayAppend() {
        if (this.container && this.$appendTo() !== 'self') {
            appendChild(this.el.nativeElement, this.container);
        }
    }
    moveOnTop() {
        if (this.autoZIndex()) {
            ZIndexUtils.set('menu', this.container, this.baseZIndex() + this.config.zIndex.menu);
        }
    }
    /**
     * Hides the popup menu.
     * @group Method
     */
    hide() {
        this.visible = false;
        this.cd.markForCheck();
    }
    onWindowResize() {
        if (this.visible && !isTouchDevice()) {
            this.hide();
        }
    }
    menuitemId(item, id, index, childIndex) {
        return item?.id ?? `${id}_${index}${childIndex !== undefined ? '_' + childIndex : ''}`;
    }
    isItemFocused(id) {
        return this.focusedOptionId() === id;
    }
    label(label) {
        return typeof label === 'function' ? label() : label;
    }
    disabled(disabled) {
        return typeof disabled === 'function' ? disabled() : typeof disabled === 'undefined' ? false : disabled;
    }
    activedescendant() {
        return this.focused ? this.focusedOptionId() : undefined;
    }
    onListFocus(event) {
        if (!this.focused) {
            this.focused = true;
            !this.popup() && this.changeFocusedOptionIndex(0);
            this.onFocus.emit(event);
        }
    }
    onListBlur(event) {
        if (this.focused) {
            this.focused = false;
            this.changeFocusedOptionIndex(-1);
            this.selectedOptionIndex.set(-1);
            this.focusedOptionIndex.set(-1);
            this.onBlur.emit(event);
        }
    }
    onListKeyDown(event) {
        switch (event.code) {
            case 'ArrowDown':
                this.onArrowDownKey(event);
                break;
            case 'ArrowUp':
                this.onArrowUpKey(event);
                break;
            case 'Home':
                this.onHomeKey(event);
                break;
            case 'End':
                this.onEndKey(event);
                break;
            case 'Enter':
                this.onEnterKey(event);
                break;
            case 'NumpadEnter':
                this.onEnterKey(event);
                break;
            case 'Space':
                this.onSpaceKey(event);
                break;
            case 'Escape':
            case 'Tab':
                if (this.popup()) {
                    focus(this.target);
                    this.hide();
                }
                this.overlayVisible && this.hide();
                break;
            default:
                break;
        }
    }
    onArrowDownKey(event) {
        const optionIndex = this.findNextOptionIndex(this.focusedOptionIndex());
        this.changeFocusedOptionIndex(optionIndex);
        event.preventDefault();
    }
    onArrowUpKey(event) {
        if (event.altKey && this.popup()) {
            focus(this.target);
            this.hide();
            event.preventDefault();
        }
        else {
            const optionIndex = this.findPrevOptionIndex(this.focusedOptionIndex());
            this.changeFocusedOptionIndex(optionIndex);
            event.preventDefault();
        }
    }
    onHomeKey(event) {
        this.changeFocusedOptionIndex(0);
        event.preventDefault();
    }
    onEndKey(event) {
        this.changeFocusedOptionIndex(find(this.containerViewChild()?.nativeElement, 'li[data-pc-section="item"][data-p-disabled="false"]').length - 1);
        event.preventDefault();
    }
    onEnterKey(event) {
        const element = findSingle(this.containerViewChild()?.nativeElement, `li[id="${`${this.focusedOptionIndex()}`}"]`);
        const anchorElement = element && (findSingle(element, '[data-pc-section="itemlink"]') || findSingle(element, 'a,button'));
        this.popup() && focus(this.target);
        anchorElement ? anchorElement.click() : element && element.click();
        event.preventDefault();
    }
    onSpaceKey(event) {
        this.onEnterKey(event);
    }
    findNextOptionIndex(index) {
        const links = find(this.containerViewChild()?.nativeElement, 'li[data-pc-section="item"][data-p-disabled="false"]');
        const matchedOptionIndex = [...links].findIndex((link) => link.id === index);
        return matchedOptionIndex > -1 ? matchedOptionIndex + 1 : 0;
    }
    findPrevOptionIndex(index) {
        const links = find(this.containerViewChild()?.nativeElement, 'li[data-pc-section="item"][data-p-disabled="false"]');
        const matchedOptionIndex = [...links].findIndex((link) => link.id === index);
        return matchedOptionIndex > -1 ? matchedOptionIndex - 1 : 0;
    }
    changeFocusedOptionIndex(index) {
        const links = find(this.containerViewChild()?.nativeElement, 'li[data-pc-section="item"][data-p-disabled="false"]');
        if (links.length > 0) {
            let order = index >= links.length ? links.length - 1 : index < 0 ? 0 : index;
            order > -1 && this.focusedOptionIndex.set(links[order].getAttribute('id'));
        }
    }
    itemClick(event, id) {
        const { originalEvent, item } = event;
        if (!this.focused) {
            this.focused = true;
            this.onFocus.emit(originalEvent);
        }
        if (item.disabled) {
            originalEvent.preventDefault();
            return;
        }
        if (!item.url && !item.routerLink) {
            originalEvent.preventDefault();
        }
        if (item.command) {
            item.command({
                originalEvent: originalEvent,
                item: item
            });
        }
        if (this.popup()) {
            this.hide();
        }
        if (!this.popup() && this.focusedOptionIndex() !== id) {
            this.focusedOptionIndex.set(id);
        }
    }
    onOverlayClick(event) {
        if (this.popup()) {
            this.overlayService.add({
                originalEvent: event,
                target: this.el.nativeElement
            });
        }
        this.preventDocumentDefault = true;
    }
    bindDocumentClickListener() {
        if (!this.documentClickListener && isPlatformBrowser(this.platformId)) {
            const documentTarget = this.el ? this.el.nativeElement.ownerDocument : 'document';
            this.documentClickListener = this.renderer.listen(documentTarget, 'click', (event) => {
                const isOutsideContainer = this.containerViewChild()?.nativeElement && !this.containerViewChild()?.nativeElement.contains(event.target);
                const isOutsideTarget = !(this.target && (this.target === event.target || this.target.contains(event.target)));
                if (!this.popup() && isOutsideContainer && isOutsideTarget) {
                    this.onListBlur(event);
                }
                if (this.preventDocumentDefault && this.overlayVisible && isOutsideContainer && isOutsideTarget) {
                    this.hide();
                    this.preventDocumentDefault = false;
                }
            });
        }
    }
    unbindDocumentClickListener() {
        if (this.documentClickListener) {
            this.documentClickListener();
            this.documentClickListener = null;
        }
    }
    bindDocumentResizeListener() {
        if (!this.documentResizeListener && isPlatformBrowser(this.platformId)) {
            const window = this.document.defaultView;
            this.documentResizeListener = this.renderer.listen(window, 'resize', this.onWindowResize.bind(this));
        }
    }
    unbindDocumentResizeListener() {
        if (this.documentResizeListener) {
            this.documentResizeListener();
            this.documentResizeListener = null;
        }
    }
    bindScrollListener() {
        if (!this.scrollHandler && isPlatformBrowser(this.platformId)) {
            this.scrollHandler = new ConnectedOverlayScrollHandler(this.target, () => {
                if (this.visible) {
                    this.hide();
                }
            });
        }
        this.scrollHandler?.bindScrollListener();
    }
    unbindScrollListener() {
        if (this.scrollHandler) {
            this.scrollHandler.unbindScrollListener();
            this.scrollHandler = null;
        }
    }
    onOverlayHide() {
        this.unbindDocumentClickListener();
        this.unbindDocumentResizeListener();
        this.unbindScrollListener();
        this.preventDocumentDefault = false;
        if (!this.cd.destroyed) {
            this.target = null;
        }
        if (this.container) {
            if (this.autoZIndex()) {
                ZIndexUtils.clear(this.container);
            }
            this.container = undefined;
        }
    }
    onDestroy() {
        if (this.popup()) {
            if (this.scrollHandler) {
                this.scrollHandler.destroy();
                this.scrollHandler = null;
            }
            if (this.container) {
                if (this.autoZIndex()) {
                    ZIndexUtils.clear(this.container);
                }
                this.container = undefined;
            }
            this.restoreOverlayAppend();
            this.onOverlayHide();
        }
        if (!this.popup()) {
            this.unbindDocumentClickListener();
        }
    }
    hasSubMenu() {
        return this.model()?.some((item) => item.items) ?? false;
    }
    isItemHidden(item) {
        if (item.separator) {
            return item.visible === false || (item.items && item.items.some((subitem) => subitem.visible !== false));
        }
        return item.visible === false;
    }
    get dataP() {
        return this.cn({
            popup: this.popup()
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Menu, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: Menu, isStandalone: true, selector: "p-menu", inputs: { model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: false, transformFunction: null }, popup: { classPropertyName: "popup", publicName: "popup", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, autoZIndex: { classPropertyName: "autoZIndex", publicName: "autoZIndex", isSignal: true, isRequired: false, transformFunction: null }, baseZIndex: { classPropertyName: "baseZIndex", publicName: "baseZIndex", isSignal: true, isRequired: false, transformFunction: null }, showTransitionOptions: { classPropertyName: "showTransitionOptions", publicName: "showTransitionOptions", isSignal: true, isRequired: false, transformFunction: null }, hideTransitionOptions: { classPropertyName: "hideTransitionOptions", publicName: "hideTransitionOptions", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, appendTo: { classPropertyName: "appendTo", publicName: "appendTo", isSignal: true, isRequired: false, transformFunction: null }, motionOptions: { classPropertyName: "motionOptions", publicName: "motionOptions", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onShow: "onShow", onHide: "onHide", onBlur: "onBlur", onFocus: "onFocus" }, providers: [MenuStyle, { provide: MENU_INSTANCE, useExisting: Menu }, { provide: PARENT_INSTANCE, useExisting: Menu }], queries: [{ propertyName: "headerTemplate", first: true, predicate: ["header"], isSignal: true }, { propertyName: "itemTemplate", first: true, predicate: ["item"], isSignal: true }, { propertyName: "submenuHeaderTemplate", first: true, predicate: ["submenuheader"], isSignal: true }, { propertyName: "templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "startTemplate", first: true, predicate: ["start"] }, { propertyName: "endTemplate", first: true, predicate: ["end"] }], viewQueries: [{ propertyName: "listViewChild", first: true, predicate: ["list"], descendants: true, isSignal: true }, { propertyName: "containerViewChild", first: true, predicate: ["container"], descendants: true, isSignal: true }], usesInheritance: true, hostDirectives: [{ directive: i3.Bind }], ngImport: i0, template: `
        @if (!popup() || overlayVisible) {
            <div
                #container
                [class]="cn(cx('root'), styleClass())"
                [style]="sx('root')"
                [ngStyle]="style()"
                (click)="onOverlayClick($event)"
                [attr.id]="resolvedId"
                [pBind]="ptm('root')"
                [attr.data-p]="dataP"
                [pMotion]="visible || !popup()"
                [pMotionName]="'p-anchored-overlay'"
                [pMotionAppear]="!!popup()"
                [pMotionDisabled]="!popup()"
                [pMotionOptions]="computedMotionOptions()"
                (pMotionOnBeforeEnter)="onOverlayBeforeEnter($event)"
                (pMotionOnAfterLeave)="onOverlayAfterLeave()"
            >
                @if (startTemplate ?? _startTemplate) {
                    <div [class]="cx('start')" [pBind]="ptm('start')" [attr.data-pc-section]="'start'">
                        <ng-container *ngTemplateOutlet="startTemplate ?? _startTemplate"></ng-container>
                    </div>
                }
                <ul
                    #list
                    [class]="cx('list')"
                    [pBind]="ptm('list')"
                    role="menu"
                    [attr.id]="resolvedId + '_list'"
                    [attr.tabindex]="getTabIndexValue()"
                    [attr.data-pc-section]="'menu'"
                    [attr.aria-activedescendant]="activedescendant()"
                    [attr.aria-label]="ariaLabel()"
                    [attr.aria-labelledBy]="ariaLabelledBy()"
                    (focus)="onListFocus($event)"
                    (blur)="onListBlur($event)"
                    (keydown)="onListKeyDown($event)"
                >
                    @if (hasSubMenu()) {
                        @for (submenu of model(); track submenu; let i = $index) {
                            @if (submenu.separator && submenu.visible !== false) {
                                <li [class]="cx('separator')" [pBind]="ptm('separator')" role="separator" [attr.data-pc-section]="'separator'"></li>
                            }
                            @if (!submenu.separator) {
                                <li
                                    [class]="cx('submenuLabel')"
                                    [pBind]="ptm('submenuLabel')"
                                    [attr.data-automationid]="submenu.automationId"
                                    pTooltip
                                    [tooltipOptions]="submenu.tooltipOptions"
                                    [pTooltipUnstyled]="unstyled()"
                                    role="none"
                                    [attr.id]="menuitemId(submenu, resolvedId, i)"
                                    [attr.data-pc-section]="'submenulabel'"
                                >
                                    @if (!submenuHeaderTemplate() && !_submenuHeaderTemplate) {
                                        @if (submenu.escape !== false) {
                                            <span>{{ submenu.label }}</span>
                                        } @else {
                                            <span [innerHTML]="submenu.label | safeHtml"></span>
                                        }
                                    }
                                    <ng-container *ngTemplateOutlet="submenuHeaderTemplate() ?? _submenuHeaderTemplate; context: { $implicit: submenu }"></ng-container>
                                </li>
                            }
                            @for (item of submenu.items; track item; let j = $index) {
                                @if (item.separator && (item.visible !== false || submenu.visible !== false)) {
                                    <li [class]="cx('separator')" [pBind]="ptm('separator')" role="separator" [attr.data-pc-section]="'separator'"></li>
                                }
                                @if (!item.separator && item.visible !== false && (item.visible !== undefined || submenu.visible !== false)) {
                                    <li
                                        [class]="cn(cx('item', { item, id: menuitemId(item, resolvedId, i, j) }), item?.styleClass)"
                                        [pBind]="ptm('item')"
                                        [pMenuItemContent]="item"
                                        [itemTemplate]="itemTemplate() ?? _itemTemplate"
                                        [idx]="j"
                                        [menuitemId]="menuitemId(item, resolvedId, i, j)"
                                        [style]="item.style"
                                        (onMenuItemClick)="itemClick($event, menuitemId(item, resolvedId, i, j))"
                                        pTooltip
                                        [tooltipOptions]="item.tooltipOptions"
                                        [pTooltipUnstyled]="unstyled()"
                                        [unstyled]="unstyled()"
                                        role="menuitem"
                                        [attr.aria-label]="label(item.label)"
                                        [attr.data-p-focused]="isItemFocused(menuitemId(item, resolvedId, i, j))"
                                        [attr.data-p-disabled]="disabled(item.disabled)"
                                        [attr.aria-disabled]="disabled(item.disabled)"
                                        [attr.id]="menuitemId(item, resolvedId, i, j)"
                                    ></li>
                                }
                            }
                        }
                    }
                    @if (!hasSubMenu()) {
                        @for (item of model(); track item; let i = $index) {
                            @if (item.separator && item.visible !== false) {
                                <li [class]="cx('separator')" [pBind]="ptm('separator')" role="separator" [attr.data-pc-section]="'separator'"></li>
                            }
                            @if (!item.separator && item.visible !== false) {
                                <li
                                    [class]="cn(cx('item', { item, id: menuitemId(item, resolvedId, i) }), item?.styleClass)"
                                    [pBind]="ptm('item')"
                                    [pMenuItemContent]="item"
                                    [itemTemplate]="itemTemplate() ?? _itemTemplate"
                                    [idx]="i"
                                    [menuitemId]="menuitemId(item, resolvedId, i)"
                                    [ngStyle]="item.style"
                                    (onMenuItemClick)="itemClick($event, menuitemId(item, resolvedId, i))"
                                    pTooltip
                                    [tooltipOptions]="item.tooltipOptions"
                                    [unstyled]="unstyled()"
                                    [pTooltipUnstyled]="unstyled()"
                                    role="menuitem"
                                    [attr.aria-label]="label(item.label)"
                                    [attr.data-p-focused]="isItemFocused(menuitemId(item, resolvedId, i))"
                                    [attr.data-p-disabled]="disabled(item.disabled)"
                                    [attr.aria-disabled]="disabled(item.disabled)"
                                    [attr.id]="menuitemId(item, resolvedId, i)"
                                ></li>
                            }
                        }
                    }
                </ul>
                @if (endTemplate ?? _endTemplate) {
                    <div [class]="cx('end')" [pBind]="ptm('end')" [attr.data-pc-section]="'end'">
                        <ng-container *ngTemplateOutlet="endTemplate ?? _endTemplate"></ng-container>
                    </div>
                }
            </div>
        }
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "ngmodule", type: RouterModule }, { kind: "component", type: MenuItemContent, selector: "[pMenuItemContent]", inputs: ["pMenuItemContent", "itemTemplate", "menuitemId", "idx"], outputs: ["onMenuItemClick"] }, { kind: "ngmodule", type: TooltipModule }, { kind: "directive", type: i5.Tooltip, selector: "[pTooltip]", inputs: ["tooltipPosition", "tooltipEvent", "positionStyle", "tooltipStyleClass", "tooltipZIndex", "escape", "showDelay", "hideDelay", "life", "positionTop", "positionLeft", "autoHide", "fitContent", "hideOnEscape", "showOnEllipsis", "pTooltip", "tooltipDisabled", "tooltipOptions", "appendTo", "ptTooltip", "pTooltipPT", "pTooltipUnstyled"] }, { kind: "directive", type: i3.Bind, selector: "[pBind]", inputs: ["pBind"] }, { kind: "ngmodule", type: BadgeModule }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: BindModule }, { kind: "ngmodule", type: MotionModule }, { kind: "directive", type: i6.MotionDirective, selector: "[pMotion]", inputs: ["pMotion", "pMotionName", "pMotionType", "pMotionSafe", "pMotionDisabled", "pMotionAppear", "pMotionEnter", "pMotionLeave", "pMotionDuration", "pMotionHideStrategy", "pMotionEnterFromClass", "pMotionEnterToClass", "pMotionEnterActiveClass", "pMotionLeaveFromClass", "pMotionLeaveToClass", "pMotionLeaveActiveClass", "pMotionOptions"], outputs: ["pMotionOnBeforeEnter", "pMotionOnEnter", "pMotionOnAfterEnter", "pMotionOnEnterCancelled", "pMotionOnBeforeLeave", "pMotionOnLeave", "pMotionOnAfterLeave", "pMotionOnLeaveCancelled"] }, { kind: "pipe", type: SafeHtmlPipe, name: "safeHtml" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Menu, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-menu',
                    standalone: true,
                    imports: [CommonModule, RouterModule, MenuItemContent, TooltipModule, BadgeModule, SharedModule, SafeHtmlPipe, BindModule, MotionModule],
                    template: `
        @if (!popup() || overlayVisible) {
            <div
                #container
                [class]="cn(cx('root'), styleClass())"
                [style]="sx('root')"
                [ngStyle]="style()"
                (click)="onOverlayClick($event)"
                [attr.id]="resolvedId"
                [pBind]="ptm('root')"
                [attr.data-p]="dataP"
                [pMotion]="visible || !popup()"
                [pMotionName]="'p-anchored-overlay'"
                [pMotionAppear]="!!popup()"
                [pMotionDisabled]="!popup()"
                [pMotionOptions]="computedMotionOptions()"
                (pMotionOnBeforeEnter)="onOverlayBeforeEnter($event)"
                (pMotionOnAfterLeave)="onOverlayAfterLeave()"
            >
                @if (startTemplate ?? _startTemplate) {
                    <div [class]="cx('start')" [pBind]="ptm('start')" [attr.data-pc-section]="'start'">
                        <ng-container *ngTemplateOutlet="startTemplate ?? _startTemplate"></ng-container>
                    </div>
                }
                <ul
                    #list
                    [class]="cx('list')"
                    [pBind]="ptm('list')"
                    role="menu"
                    [attr.id]="resolvedId + '_list'"
                    [attr.tabindex]="getTabIndexValue()"
                    [attr.data-pc-section]="'menu'"
                    [attr.aria-activedescendant]="activedescendant()"
                    [attr.aria-label]="ariaLabel()"
                    [attr.aria-labelledBy]="ariaLabelledBy()"
                    (focus)="onListFocus($event)"
                    (blur)="onListBlur($event)"
                    (keydown)="onListKeyDown($event)"
                >
                    @if (hasSubMenu()) {
                        @for (submenu of model(); track submenu; let i = $index) {
                            @if (submenu.separator && submenu.visible !== false) {
                                <li [class]="cx('separator')" [pBind]="ptm('separator')" role="separator" [attr.data-pc-section]="'separator'"></li>
                            }
                            @if (!submenu.separator) {
                                <li
                                    [class]="cx('submenuLabel')"
                                    [pBind]="ptm('submenuLabel')"
                                    [attr.data-automationid]="submenu.automationId"
                                    pTooltip
                                    [tooltipOptions]="submenu.tooltipOptions"
                                    [pTooltipUnstyled]="unstyled()"
                                    role="none"
                                    [attr.id]="menuitemId(submenu, resolvedId, i)"
                                    [attr.data-pc-section]="'submenulabel'"
                                >
                                    @if (!submenuHeaderTemplate() && !_submenuHeaderTemplate) {
                                        @if (submenu.escape !== false) {
                                            <span>{{ submenu.label }}</span>
                                        } @else {
                                            <span [innerHTML]="submenu.label | safeHtml"></span>
                                        }
                                    }
                                    <ng-container *ngTemplateOutlet="submenuHeaderTemplate() ?? _submenuHeaderTemplate; context: { $implicit: submenu }"></ng-container>
                                </li>
                            }
                            @for (item of submenu.items; track item; let j = $index) {
                                @if (item.separator && (item.visible !== false || submenu.visible !== false)) {
                                    <li [class]="cx('separator')" [pBind]="ptm('separator')" role="separator" [attr.data-pc-section]="'separator'"></li>
                                }
                                @if (!item.separator && item.visible !== false && (item.visible !== undefined || submenu.visible !== false)) {
                                    <li
                                        [class]="cn(cx('item', { item, id: menuitemId(item, resolvedId, i, j) }), item?.styleClass)"
                                        [pBind]="ptm('item')"
                                        [pMenuItemContent]="item"
                                        [itemTemplate]="itemTemplate() ?? _itemTemplate"
                                        [idx]="j"
                                        [menuitemId]="menuitemId(item, resolvedId, i, j)"
                                        [style]="item.style"
                                        (onMenuItemClick)="itemClick($event, menuitemId(item, resolvedId, i, j))"
                                        pTooltip
                                        [tooltipOptions]="item.tooltipOptions"
                                        [pTooltipUnstyled]="unstyled()"
                                        [unstyled]="unstyled()"
                                        role="menuitem"
                                        [attr.aria-label]="label(item.label)"
                                        [attr.data-p-focused]="isItemFocused(menuitemId(item, resolvedId, i, j))"
                                        [attr.data-p-disabled]="disabled(item.disabled)"
                                        [attr.aria-disabled]="disabled(item.disabled)"
                                        [attr.id]="menuitemId(item, resolvedId, i, j)"
                                    ></li>
                                }
                            }
                        }
                    }
                    @if (!hasSubMenu()) {
                        @for (item of model(); track item; let i = $index) {
                            @if (item.separator && item.visible !== false) {
                                <li [class]="cx('separator')" [pBind]="ptm('separator')" role="separator" [attr.data-pc-section]="'separator'"></li>
                            }
                            @if (!item.separator && item.visible !== false) {
                                <li
                                    [class]="cn(cx('item', { item, id: menuitemId(item, resolvedId, i) }), item?.styleClass)"
                                    [pBind]="ptm('item')"
                                    [pMenuItemContent]="item"
                                    [itemTemplate]="itemTemplate() ?? _itemTemplate"
                                    [idx]="i"
                                    [menuitemId]="menuitemId(item, resolvedId, i)"
                                    [ngStyle]="item.style"
                                    (onMenuItemClick)="itemClick($event, menuitemId(item, resolvedId, i))"
                                    pTooltip
                                    [tooltipOptions]="item.tooltipOptions"
                                    [unstyled]="unstyled()"
                                    [pTooltipUnstyled]="unstyled()"
                                    role="menuitem"
                                    [attr.aria-label]="label(item.label)"
                                    [attr.data-p-focused]="isItemFocused(menuitemId(item, resolvedId, i))"
                                    [attr.data-p-disabled]="disabled(item.disabled)"
                                    [attr.aria-disabled]="disabled(item.disabled)"
                                    [attr.id]="menuitemId(item, resolvedId, i)"
                                ></li>
                            }
                        }
                    }
                </ul>
                @if (endTemplate ?? _endTemplate) {
                    <div [class]="cx('end')" [pBind]="ptm('end')" [attr.data-pc-section]="'end'">
                        <ng-container *ngTemplateOutlet="endTemplate ?? _endTemplate"></ng-container>
                    </div>
                }
            </div>
        }
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [MenuStyle, { provide: MENU_INSTANCE, useExisting: Menu }, { provide: PARENT_INSTANCE, useExisting: Menu }],
                    hostDirectives: [Bind]
                }]
        }], propDecorators: { model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: false }] }], popup: [{ type: i0.Input, args: [{ isSignal: true, alias: "popup", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], autoZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoZIndex", required: false }] }], baseZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "baseZIndex", required: false }] }], showTransitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "showTransitionOptions", required: false }] }], hideTransitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideTransitionOptions", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], appendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "appendTo", required: false }] }], motionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "motionOptions", required: false }] }], onShow: [{ type: i0.Output, args: ["onShow"] }], onHide: [{ type: i0.Output, args: ["onHide"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], listViewChild: [{ type: i0.ViewChild, args: ['list', { isSignal: true }] }], containerViewChild: [{ type: i0.ViewChild, args: ['container', { isSignal: true }] }], startTemplate: [{
                type: ContentChild,
                args: ['start', { descendants: false }]
            }], endTemplate: [{
                type: ContentChild,
                args: ['end', { descendants: false }]
            }], headerTemplate: [{ type: i0.ContentChild, args: ['header', { ...{ descendants: false }, isSignal: true }] }], itemTemplate: [{ type: i0.ContentChild, args: ['item', { ...{ descendants: false }, isSignal: true }] }], submenuHeaderTemplate: [{ type: i0.ContentChild, args: ['submenuheader', { ...{ descendants: false }, isSignal: true }] }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class MenuModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MenuModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: MenuModule, imports: [Menu, SharedModule, SafeHtmlPipe], exports: [Menu, SharedModule, SafeHtmlPipe] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MenuModule, imports: [Menu, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MenuModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [Menu, SharedModule, SafeHtmlPipe],
                    exports: [Menu, SharedModule, SafeHtmlPipe]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { Menu, MenuClasses, MenuItemContent, MenuModule, MenuStyle, SafeHtmlPipe };
//# sourceMappingURL=wawjs-ngx-prime-menu.mjs.map
