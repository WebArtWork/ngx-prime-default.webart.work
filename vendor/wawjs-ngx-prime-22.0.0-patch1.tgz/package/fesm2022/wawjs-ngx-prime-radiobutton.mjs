export * from '@wawjs/ngx-prime/types/radiobutton';
import * as i0 from '@angular/core';
import { Injectable, inject, ElementRef, input, booleanAttribute, numberAttribute, computed, output, effect, forwardRef, Directive, InjectionToken, viewChild, Injector, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { NG_VALUE_ACCESSOR, NgControl } from '@angular/forms';
import { SharedModule } from '@wawjs/ngx-prime/api';
import { AutoFocus } from '@wawjs/ngx-prime/autofocus';
import { PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind, BindModule } from '@wawjs/ngx-prime/bind';
import { style as style$1 } from '@wawjs/css-prime-styles/radiobutton';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import { equals } from '@wawjs/css-prime-utils';

const style = /*css*/ `
    ${style$1}

    /* Native radio directive: preserve browser grouping and accessibility while using the active theme color. */
    input.p-radiobutton.p-component {
        accent-color: dt('radiobutton.checked.background');
        cursor: pointer;
    }

    input.p-radiobutton.p-component.p-disabled {
        cursor: default;
    }

    /* For ngx-prime */
    p-radioButton.ng-invalid.ng-dirty .p-radiobutton-box,
    p-radio-button.ng-invalid.ng-dirty .p-radiobutton-box,
    p-radiobutton.ng-invalid.ng-dirty .p-radiobutton-box {
        border-color: dt('radiobutton.invalid.border.color');
    }
`;
const classes = {
    root: ({ instance }) => [
        'p-radiobutton p-component',
        {
            'p-radiobutton-checked': instance.checked,
            'p-disabled': instance.$disabled(),
            'p-invalid': instance.invalid(),
            'p-variant-filled': instance.$variant() === 'filled',
            'p-radiobutton-sm p-inputfield-sm': instance.size() === 'small',
            'p-radiobutton-lg p-inputfield-lg': instance.size() === 'large'
        }
    ],
    box: 'p-radiobutton-box',
    input: 'p-radiobutton-input',
    icon: 'p-radiobutton-icon'
};
class RadioButtonStyle extends BaseStyle {
    name = 'radiobutton';
    style = style;
    classes = classes;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RadioButtonStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RadioButtonStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RadioButtonStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * RadioButton is an extension to standard radio button element with theming.
 *
 * [Live Demo](https://www.ngx-prime.org/radiobutton/)
 *
 * @module radiobuttonstyle
 *
 */
var RadioButtonClasses;
(function (RadioButtonClasses) {
    /**
     * Class name of the root element
     */
    RadioButtonClasses["root"] = "p-radiobutton";
    /**
     * Class name of the box element
     */
    RadioButtonClasses["box"] = "p-radiobutton-box";
    /**
     * Class name of the input element
     */
    RadioButtonClasses["input"] = "p-radiobutton-input";
    /**
     * Class name of the icon element
     */
    RadioButtonClasses["icon"] = "p-radiobutton-icon";
})(RadioButtonClasses || (RadioButtonClasses = {}));

/**
 * Adds Prime styling and accessibility attributes to a native radio input.
 * Native radios retain Angular's built-in radio value accessor and grouping.
 *
 * @group Components
 */
class RadioButtonDirective extends BaseEditableHolder {
    componentName = 'RadioButton';
    element = inject(ElementRef);
    _componentStyle = inject(RadioButtonStyle);
    bindDirectiveInstance = inject(Bind, { self: true });
    /** @deprecated Use the native `class` attribute instead. */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /** Compatibility input for the directive pass-through configuration. */
    ptRadioButton = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ptRadioButton" }] : /* istanbul ignore next */ []));
    /** Pass-through configuration for the native radio button. */
    pRadioButtonPT = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "pRadioButtonPT" }] : /* istanbul ignore next */ []));
    /** Enables unstyled mode for this native radio button. */
    pRadioButtonUnstyled = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "pRadioButtonUnstyled" }] : /* istanbul ignore next */ []));
    value = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "value" }] : /* istanbul ignore next */ []));
    binary = input(false, { ...(ngDevMode ? { debugName: "binary" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    tabindex = input(undefined, { ...(ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    inputId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "inputId" }] : /* istanbul ignore next */ []));
    autofocus = input(false, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    variant = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "variant" }] : /* istanbul ignore next */ []));
    size = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "size" }] : /* istanbul ignore next */ []));
    $variant = computed(() => this.variant() || this.config.inputStyle() || this.config.inputVariant(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "$variant" }] : /* istanbul ignore next */ []));
    /** Emits when this native radio input is selected. */
    onClick = output();
    onFocus = output();
    onBlur = output();
    touch = output();
    onInputChange(event) {
        const input = event.target;
        if (input.checked && !this.$disabled()) {
            const value = this.binary() ? true : this.value();
            this.writeModelValue(value);
            this.onModelChange(value);
            this.onClick.emit({ originalEvent: event, value });
        }
    }
    onInputFocus(event) {
        this.onFocus.emit(event);
    }
    onInputBlur(event) {
        this.onModelTouched();
        this.touch.emit();
        this.onBlur.emit(event);
    }
    get checked() {
        return this.binary() ? !!this.modelValue() : equals(this.modelValue(), this.value());
    }
    get dataP() {
        return this.cn({
            invalid: this.invalid(),
            checked: this.checked,
            disabled: this.$disabled(),
            filled: this.$variant() === 'filled',
            [this.size()]: this.size()
        });
    }
    constructor() {
        super();
        effect(() => {
            const pt = this.ptRadioButton() || this.pRadioButtonPT();
            if (pt) {
                this.directivePT.set(pt);
            }
        });
        effect(() => {
            if (this.pRadioButtonUnstyled()) {
                this.directiveUnstyled.set(true);
            }
        });
    }
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptm('root'));
    }
    focus(options) {
        this.element.nativeElement.focus(options);
    }
    writeControlValue(value, setModelValue) {
        setModelValue(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RadioButtonDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: RadioButtonDirective, isStandalone: true, selector: "input[type='radio'][pRadioButton]", inputs: { styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, ptRadioButton: { classPropertyName: "ptRadioButton", publicName: "ptRadioButton", isSignal: true, isRequired: false, transformFunction: null }, pRadioButtonPT: { classPropertyName: "pRadioButtonPT", publicName: "pRadioButtonPT", isSignal: true, isRequired: false, transformFunction: null }, pRadioButtonUnstyled: { classPropertyName: "pRadioButtonUnstyled", publicName: "pRadioButtonUnstyled", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, binary: { classPropertyName: "binary", publicName: "binary", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onClick: "onClick", onFocus: "onFocus", onBlur: "onBlur", touch: "touch" }, host: { listeners: { "change": "onInputChange($event)", "focus": "onInputFocus($event)", "blur": "onInputBlur($event)" }, properties: { "class": "cn(cx('root'), styleClass())", "attr.data-pc-name": "'radiobutton'", "attr.data-pc-section": "'input'", "attr.data-p": "dataP", "attr.data-p-invalid": "invalid() || null", "attr.aria-label": "ariaLabel() || null", "attr.aria-labelledby": "ariaLabelledBy() || null", "attr.aria-required": "required() || null", "attr.tabindex": "tabindex() ?? null", "attr.id": "inputId() || null", "autofocus": "autofocus()", "disabled": "$disabled()", "required": "required()", "attr.name": "name() || null", "value": "value() ?? \"\"", "checked": "checked", "attr.aria-checked": "checked" } }, providers: [RadioButtonStyle, { provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => RadioButtonDirective), multi: true }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RadioButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: "input[type='radio'][pRadioButton]",
                    standalone: true,
                    host: {
                        '[class]': "cn(cx('root'), styleClass())",
                        '[attr.data-pc-name]': "'radiobutton'",
                        '[attr.data-pc-section]': "'input'",
                        '[attr.data-p]': 'dataP',
                        '[attr.data-p-invalid]': 'invalid() || null',
                        '[attr.aria-label]': 'ariaLabel() || null',
                        '[attr.aria-labelledby]': 'ariaLabelledBy() || null',
                        '[attr.aria-required]': 'required() || null',
                        '[attr.tabindex]': 'tabindex() ?? null',
                        '[attr.id]': 'inputId() || null',
                        '[autofocus]': 'autofocus()',
                        '[disabled]': '$disabled()',
                        '[required]': 'required()',
                        '[attr.name]': 'name() || null',
                        '[value]': 'value() ?? ""',
                        '[checked]': 'checked',
                        '[attr.aria-checked]': 'checked',
                        '(change)': 'onInputChange($event)',
                        '(focus)': 'onInputFocus($event)',
                        '(blur)': 'onInputBlur($event)'
                    },
                    providers: [RadioButtonStyle, { provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => RadioButtonDirective), multi: true }],
                    hostDirectives: [Bind]
                }]
        }], ctorParameters: () => [], propDecorators: { styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], ptRadioButton: [{ type: i0.Input, args: [{ isSignal: true, alias: "ptRadioButton", required: false }] }], pRadioButtonPT: [{ type: i0.Input, args: [{ isSignal: true, alias: "pRadioButtonPT", required: false }] }], pRadioButtonUnstyled: [{ type: i0.Input, args: [{ isSignal: true, alias: "pRadioButtonUnstyled", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], binary: [{ type: i0.Input, args: [{ isSignal: true, alias: "binary", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], onClick: [{ type: i0.Output, args: ["onClick"] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], touch: [{ type: i0.Output, args: ["touch"] }] } });

const RADIOBUTTON_INSTANCE = new InjectionToken('RADIOBUTTON_INSTANCE');
const RADIO_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => RadioButton),
    multi: true
};
class RadioControlRegistry {
    accessors = [];
    add(control, accessor) {
        this.accessors.push([control, accessor]);
    }
    remove(accessor) {
        this.accessors = this.accessors.filter((c) => c[1] !== accessor);
    }
    select(accessor) {
        this.accessors.forEach((c) => {
            if (this.isSameGroup(c, accessor) && c[1] !== accessor) {
                c[1].writeValue(accessor.value());
            }
        });
    }
    isSameGroup(controlPair, accessor) {
        if (!controlPair[0].control) {
            return false;
        }
        return controlPair[0].control.root === accessor.control.control.root && controlPair[1].name() === accessor.name();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RadioControlRegistry, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RadioControlRegistry, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RadioControlRegistry, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }] });
/**
 * RadioButton is an extension to standard radio button element with theming.
 *
 * @deprecated Use a native `<input type="radio" pRadioButton>` instead. This
 * component remains available for compatibility and is planned for removal in v23.
 * @group Components
 */
class RadioButton extends BaseEditableHolder {
    componentName = 'RadioButton';
    $pcRadioButton = inject(RADIOBUTTON_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    /**
     * Value of the radiobutton.
     * @group Props
     */
    value = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "value" }] : /* istanbul ignore next */ []));
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex = input(undefined, { ...(ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Identifier of the focus input to match a label defined for the component.
     * @group Props
     */
    inputId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "inputId" }] : /* istanbul ignore next */ []));
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    /**
     * Used to define a string that labels the input element.
     * @group Props
     */
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus = input(undefined, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Allows to select a boolean value.
     * @group Props
     */
    binary = input(undefined, { ...(ngDevMode ? { debugName: "binary" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Specifies the input variant of the component.
     * @defaultValue undefined
     * @group Props
     */
    variant = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "variant" }] : /* istanbul ignore next */ []));
    /**
     * Specifies the size of the component.
     * @defaultValue undefined
     * @group Props
     */
    size = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "size" }] : /* istanbul ignore next */ []));
    /**
     * Callback to invoke on radio button click.
     * @param {RadioButtonClickEvent} event - Custom click event.
     * @group Emits
     */
    onClick = output();
    /**
     * Callback to invoke when the receives focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onFocus = output();
    /**
     * Callback to invoke when the loses focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onBlur = output();
    inputViewChild = viewChild.required('input', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputViewChild" }] : /* istanbul ignore next */ []));
    $variant = computed(() => this.variant() || this.config.inputStyle() || this.config.inputVariant(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "$variant" }] : /* istanbul ignore next */ []));
    checked;
    focused;
    control;
    _componentStyle = inject(RadioButtonStyle);
    injector = inject(Injector);
    registry = inject(RadioControlRegistry);
    onInit() {
        this.control = this.injector.get(NgControl);
        this.registry.add(this.control, this);
    }
    onChange(event) {
        if (!this.$disabled()) {
            this.select(event);
        }
    }
    select(event) {
        if (!this.$disabled()) {
            this.checked = true;
            this.writeModelValue(this.checked);
            this.onModelChange(this.value());
            this.registry.select(this);
            this.onClick.emit({ originalEvent: event, value: this.value() });
        }
    }
    onInputFocus(event) {
        this.focused = true;
        this.onFocus.emit(event);
    }
    onInputBlur(event) {
        this.focused = false;
        this.onModelTouched();
        this.onBlur.emit(event);
    }
    /**
     * Applies focus to input field.
     * @group Method
     */
    focus() {
        this.inputViewChild().nativeElement.focus();
    }
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value, setModelValue) {
        this.checked = !this.binary() ? value == this.value() : !!value;
        setModelValue(this.checked);
        this.cd.markForCheck();
    }
    onDestroy() {
        this.registry.remove(this);
    }
    get dataP() {
        return this.cn({
            invalid: this.invalid(),
            checked: this.checked,
            disabled: this.$disabled(),
            filled: this.$variant() === 'filled',
            [this.size()]: this.size()
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RadioButton, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "22.1.2", type: RadioButton, isStandalone: true, selector: "p-radioButton, p-radiobutton, p-radio-button", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null }, binary: { classPropertyName: "binary", publicName: "binary", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onClick: "onClick", onFocus: "onFocus", onBlur: "onBlur" }, host: { properties: { "class": "cx('root')", "attr.data-p-disabled": "$disabled()", "attr.data-p-checked": "checked", "attr.data-p": "dataP" } }, providers: [RADIO_VALUE_ACCESSOR, RadioButtonStyle, { provide: RADIOBUTTON_INSTANCE, useExisting: RadioButton }, { provide: PARENT_INSTANCE, useExisting: RadioButton }], viewQueries: [{ propertyName: "inputViewChild", first: true, predicate: ["input"], descendants: true, isSignal: true }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        <input
            #input
            [attr.id]="inputId()"
            type="radio"
            [class]="cx('input')"
            [attr.name]="name()"
            [attr.required]="required() ? '' : undefined"
            [attr.disabled]="$disabled() ? '' : undefined"
            [checked]="checked"
            [attr.value]="modelValue()"
            [attr.aria-labelledby]="ariaLabelledBy()"
            [attr.aria-label]="ariaLabel()"
            [attr.aria-checked]="checked"
            [attr.tabindex]="tabindex()"
            (focus)="onInputFocus($event)"
            (blur)="onInputBlur($event)"
            (change)="onChange($event)"
            [pAutoFocus]="autofocus()"
            [pBind]="ptm('input')"
        />
        <div [class]="cx('box')" [pBind]="ptm('box')">
            <div [class]="cx('icon')" [pBind]="ptm('icon')"></div>
        </div>
    `, isInline: true, dependencies: [{ kind: "directive", type: AutoFocus, selector: "[pAutoFocus]", inputs: ["pAutoFocus"] }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: BindModule }, { kind: "directive", type: i1.Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RadioButton, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-radioButton, p-radiobutton, p-radio-button',
                    standalone: true,
                    imports: [AutoFocus, SharedModule, BindModule],
                    template: `
        <input
            #input
            [attr.id]="inputId()"
            type="radio"
            [class]="cx('input')"
            [attr.name]="name()"
            [attr.required]="required() ? '' : undefined"
            [attr.disabled]="$disabled() ? '' : undefined"
            [checked]="checked"
            [attr.value]="modelValue()"
            [attr.aria-labelledby]="ariaLabelledBy()"
            [attr.aria-label]="ariaLabel()"
            [attr.aria-checked]="checked"
            [attr.tabindex]="tabindex()"
            (focus)="onInputFocus($event)"
            (blur)="onInputBlur($event)"
            (change)="onChange($event)"
            [pAutoFocus]="autofocus()"
            [pBind]="ptm('input')"
        />
        <div [class]="cx('box')" [pBind]="ptm('box')">
            <div [class]="cx('icon')" [pBind]="ptm('icon')"></div>
        </div>
    `,
                    providers: [RADIO_VALUE_ACCESSOR, RadioButtonStyle, { provide: RADIOBUTTON_INSTANCE, useExisting: RadioButton }, { provide: PARENT_INSTANCE, useExisting: RadioButton }],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: {
                        '[class]': "cx('root')",
                        '[attr.data-p-disabled]': '$disabled()',
                        '[attr.data-p-checked]': 'checked',
                        '[attr.data-p]': 'dataP'
                    },
                    hostDirectives: [Bind]
                }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], binary: [{ type: i0.Input, args: [{ isSignal: true, alias: "binary", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], onClick: [{ type: i0.Output, args: ["onClick"] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], inputViewChild: [{ type: i0.ViewChild, args: ['input', { isSignal: true }] }] } });
class RadioButtonModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RadioButtonModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: RadioButtonModule, imports: [RadioButton, RadioButtonDirective, SharedModule], exports: [RadioButton, RadioButtonDirective, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RadioButtonModule, imports: [RadioButton, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RadioButtonModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [RadioButton, RadioButtonDirective, SharedModule],
                    exports: [RadioButton, RadioButtonDirective, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { RADIO_VALUE_ACCESSOR, RadioButton, RadioButtonClasses, RadioButtonDirective, RadioButtonModule, RadioButtonStyle, RadioControlRegistry };
//# sourceMappingURL=wawjs-ngx-prime-radiobutton.mjs.map
