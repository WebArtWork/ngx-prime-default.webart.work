export * from '@wawjs/ngx-prime/types/treetable';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, input, booleanAttribute, numberAttribute, output, viewChild, contentChild, contentChildren, NgZone, effect, ContentChild, ViewEncapsulation, Component, forwardRef, Directive, ChangeDetectorRef, ChangeDetectionStrategy, ElementRef, NgModule } from '@angular/core';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import { NgTemplateOutlet, NgClass, NgStyle, isPlatformBrowser, CommonModule } from '@angular/common';
import * as i2 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { resolveFieldData, isEmpty, getOffset, addStyle, findSingle, getIndex, calculateScrollbarWidth, getHiddenElementOuterWidth, getHiddenElementOuterHeight, reorderArray, isClickable, equals, find, removeClass, addClass, calculateScrollbarHeight, clearSelection, invokeElementMethod, focus, isNotEmpty, getAttribute } from '@wawjs/css-prime-utils';
import { PrimeTemplate, FilterService, SharedModule } from '@wawjs/ngx-prime/api';
import { Badge, BadgeModule } from '@wawjs/ngx-prime/badge';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind, BindModule } from '@wawjs/ngx-prime/bind';
import { Checkbox } from '@wawjs/ngx-prime/checkbox';
import { DomHandler } from '@wawjs/ngx-prime/dom';
import { SpinnerIcon, ArrowDownIcon, ArrowUpIcon, SortAltIcon, SortAmountUpAltIcon, SortAmountDownIcon, ChevronDownIcon, ChevronRightIcon, CheckIcon } from '@wawjs/ngx-prime/icons';
import { Paginator, PaginatorModule } from '@wawjs/ngx-prime/paginator';
import { Ripple } from '@wawjs/ngx-prime/ripple';
import { Scroller } from '@wawjs/ngx-prime/scroller';
import { Subject } from 'rxjs';

const style = /*css*/ `
/* For ngx-prime */
.p-treetable {
    position: relative;
}

.p-treetable table {
    border-collapse: collapse;
    width: 100%;
    table-layout: fixed;
}

.p-treetable .p-sortable-column {
    cursor: pointer;
    user-select: none;
}

.p-treetable .p-sortable-column .p-column-title,
.p-treetable .p-sortable-column .p-sortable-column-icon,
.p-treetable .p-sortable-column .p-sortable-column-badge {
    vertical-align: middle;
}

.p-treetable-sort-icon {
    color: dt('treetable.sort.icon.color');
    font-size: dt('treetable.sort.icon.size');
    width: dt('treetable.sort.icon.size');
    height: dt('treetable.sort.icon.size');
    transition: color dt('treetable.transition.duration');
}

.p-treetable .p-sortable-column .p-sortable-column-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.p-treetable-auto-layout>.p-treetable-wrapper {
    overflow-x: auto;
}

.p-treetable-auto-layout>.p-treetable-wrapper>table {
    table-layout: auto;
}

.p-treetable-hoverable-rows .p-treetable-tbody>tr {
    cursor: pointer;
}

.p-treetable-toggler {
    cursor: pointer;
    user-select: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    vertical-align: middle;
    overflow: hidden;
    position: relative;
}


/* Scrollable */
.p-treetable-scrollable-wrapper {
    position: relative;
}

.p-treetable-scrollable-header,
.p-treetable-scrollable-footer {
    overflow: hidden;
    flex-shrink: 0;
}

.p-treetable-scrollable-body {
    overflow: auto;
    position: relative;
}

.p-treetable-virtual-table {
    position: absolute;
}

/* Frozen Columns */
.p-treetable-frozen-view .p-treetable-scrollable-body {
    overflow: hidden;
}

.p-treetable-frozen-view>.p-treetable-scrollable-body>table>.p-treetable-tbody>tr>td:last-child {
    border-right: 0 none;
}

.p-treetable-unfrozen-view {
    position: absolute;
    top: 0;
}

/* Flex Scrollable */
.p-treetable-flex-scrollable {
    display: flex;
    flex-direction: column;
    flex: 1;
    height: 100%;
}

.p-treetable-flex-scrollable .p-treetable-scrollable-wrapper,
.p-treetable-flex-scrollable .p-treetable-scrollable-view {
    display: flex;
    flex-direction: column;
    flex: 1;
    height: 100%;
}

.p-treetable-flex-scrollable .p-treetable-virtual-scrollable-body {
    flex: 1;
}

/* Resizable */
.p-treetable-resizable>.p-treetable-wrapper {
    overflow-x: auto;
}

.p-treetable-resizable .p-treetable-thead>tr>th,
.p-treetable-resizable .p-treetable-tfoot>tr>td,
.p-treetable-resizable .p-treetable-tbody>tr>td {
    overflow: hidden;
}

.p-treetable-resizable .p-resizable-column {
    background-clip: padding-box;
    position: relative;
}

.p-treetable-resizable-fit .p-resizable-column:last-child .p-column-resizer {
    display: none;
}

.p-treetable .p-column-resizer {
    display: block;
    position: absolute;
    top: 0;
    right: 0;
    margin: 0;
    width: dt('treetable.column.resizer.width');
    height: 100%;
    padding: 0px;
    cursor: col-resize;
    border: 1px solid transparent;
}

.p-treetable .p-column-resizer-helper {
    width: dt('treetable.resize.indicator.width');
    position: absolute;
    z-index: 10;
    display: none;
    background: dt('treetable.resize.indicator.color');
}

.p-treetable .p-row-editor-init,
.p-treetable .p-row-editor-save,
.p-treetable .p-row-editor-cancel {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    position: relative;
}


/* Reorder */
.p-treetable-reorder-indicator-up,
.p-treetable-reorder-indicator-down {
    position: absolute;
    display: none;
}

[ttReorderableColumn] {
    cursor: move;
}

/* Loader */
.p-treetable-mask {
    position: absolute !important;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 2;
}

.p-treetable-loading-icon {
    font-size: dt('treetable.loading.icon.size');
    width: dt('treetable.loading.icon.size');
    height: dt('treetable.loading.icon.size');
}

/* Virtual Scroll */
.p-treetable .p-scroller-loading {
    transform: none !important;
    min-height: 0;
    position: sticky;
    top: 0;
    left: 0;
}

.p-treetable .p-paginator-top {
    border-color: dt('treetable.paginator.top.border.color');
    border-style: solid;
    border-width: dt('treetable.paginator.top.border.width');
}

.p-treetable .p-paginator-bottom {
    border-color: dt('treetable.paginator.bottom.border.color');
    border-style: solid;
    border-width: dt('treetable.paginator.bottom.border.width');
}

.p-treetable .p-treetable-header {
    background: dt('treetable.header.background');
    color: dt('treetable.header.color');
    border-color: dt('treetable.header.border.color');
    border-style: solid;
    border-width: dt('treetable.header.border.width');
    padding: dt('treetable.header.padding');
    font-weight: dt('treetable.column.title.font.weight');
}

.p-treetable .p-treetable-footer {
    background: dt('treetable.footer.background');
    color: dt('treetable.footer.color');
    border-color: dt('treetable.footer.border.color');
    border-style: solid;
    border-width: dt('treetable.footer.border.width');
    padding: dt('treetable.footer.padding');
    font-weight: dt('treetable.column.footer.font.weight');
}

.p-treetable .p-treetable-thead>tr>th {
    padding: dt('treetable.header.cell.padding');
    background: dt('treetable.header.cell.background');
    border-color: dt('treetable.header.cell.border.color');
    border-style: solid;
    border-width: 0 0 1px 0;
    color: dt('treetable.header.cell.color');
    font-weight: dt('treetable.column.title.font.weight');
    text-align: start;
    transition: background dt('treetable.transition.duration'), color dt('treetable.transition.duration'), border-color dt('treetable.transition.duration'),
            outline-color dt('treetable.transition.duration'), box-shadow dt('treetable.transition.duration');
}

.p-treetable .p-treetable-tfoot>tr>td {
    text-align: start;
    padding: dt('treetable.footer.cell.padding');
    border-color: dt('treetable.footer.cell.border.color');
    border-style: solid;
    border-width: 0 0 1px 0;
    color: dt('treetable.footer.cell.color');
    background: dt('treetable.footer.cell.background');
    font-weight: dt('treetable.column.footer.font.weight');
}

.p-treetable .p-sortable-column {
    cursor: pointer;
    user-select: none;
    outline-color: transparent;
    vertical-align: middle;
}

.p-treetable .p-sortable-column .p-sortable-column-icon {
    color: dt('treetable.sort.icon.color');
    transition: color dt('treetable.transition.duration');
}


.p-treetable .p-sortable-column:not(.p-treetable-column-sorted):hover {
    background: dt('treetable.header.cell.hover.background');
    color: dt('treetable.header.cell.hover.color');
}

.p-treetable .p-sortable-column:not(.p-treetable-column-sorted):hover .p-treetable-sort-icon {
    color: dt('treetable.sort.icon.hover.color');
}

.p-treetable .p-sortable-column.p-treetable-column-sorted {
    background: dt('treetable.header.cell.selected.background');
    color: dt('treetable.header.cell.selected.color');
}

.p-treetable .p-sortable-column.p-treetable-column-sorted .p-treetable-sort-icon {
    color: dt('treetable.header.cell.selected.color');
}

.p-treetable .p-sortable-column:focus-visible {
    box-shadow: dt('treetable.header.cell.focus.ring.shadow');
    outline: dt('treetable.header.cell.focus.ring.width') dt('treetable.header.cell.focus.ring.style') dt('treetable.header.cell.focus.ring.color');
    outline-offset: dt('treetable.header.cell.focus.ring.offset');
}

.p-treetable-hoverable .p-treetable-selectable-row {
    cursor: pointer;
}

.p-treetable .p-treetable-tbody > tr {
    outline-color: transparent;
    background: dt('treetable.row.background');
    color: dt('treetable.row.color');
}

.p-treetable .p-treetable-tbody>tr>td {
    text-align: start;
    border-color: dt('treetable.body.cell.border.color');
    border-style: solid;
    border-width: 0 0 1px 0;
    padding: dt('treetable.body.cell.padding');
}

.p-treetable .p-treetable-tbody>tr>td .p-treetable-toggler {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    position: relative;
    width: dt('treetable.node.toggle.button.size');
    height: dt('treetable.node.toggle.button.size');
    color: dt('treetable.node.toggle.button.color');
    border: 0 none;
    background: transparent;
    cursor: pointer;
    border-radius: dt('treetable.node.toggle.button.border.radius');
    transition: background dt('treetable.transition.duration'), color dt('treetable.transition.duration'), border-color dt('treetable.transition.duration'),
            outline-color dt('treetable.transition.duration'), box-shadow dt('treetable.transition.duration');
    outline-color: transparent;
    user-select: none;
}

.p-treetable .p-treetable-tbody>tr>td .p-treetable-toggler:enabled:hover {
    color: dt('treetable.node.toggle.button.hover.color');
    background: dt('treetable.node.toggle.button.hover.background');
}

.p-treetable .p-treetable-tbody>tr>tr.treetable-row-selected .p-treetable-toggler:hover {
    background: dt('treetable.node.toggle.button.selected.hover.background');
    color: dt('treetable.node.toggle.button.selected.hover.color');
}

.p-treetable .p-treetable-tbody>tr>td .p-treetable-toggler:focus-visible {
    box-shadow: dt('treetable.node.toggle.button.focus.ring.shadow');
    outline: dt('treetable.node.toggle.button.focus.ring.width') dt('treetable.node.toggle.button.focus.ring.style') dt('treetable.node.toggle.button.focus.ring.color');
    outline-offset: dt('treetable.node.toggle.button.focus.ring.offset');
}


.p-treetable .p-treetable-tbody>tr.p-treetable-row-selected {
    background: dt('treetable.row.selected.background');
    color: dt('treetable.row.selected.color');
}

.p-treetable-tbody > tr:focus-visible,
.p-treetable-tbody > tr.p-treetable-contextmenu-row-selected {
    box-shadow: dt('treetable.row.focus.ring.shadow');
    outline: dt('treetable.row.focus.ring.width') dt('treetable.row.focus.ring.style') dt('treetable.row.focus.ring.color');
    outline-offset: dt('treetable.row.focus.ring.offset');
}

.p-treetable .p-treetable-tbody>tr.p-treetable-row-selected .p-treetable-toggler {
    color: inherit;
}

.p-treetable .p-treetable-tbody>tr.p-treetable-row-selected .p-treetable-toggler:hover {
    background: dt('treetable.node.toggle.button.selected.hover.background');
    color: dt('treetable.node.toggle.button.selected.hover.color');
}

.p-treetable.p-treetable-hoverable-rows .p-treetable-tbody>tr:not(.p-treetable-row-selected):hover {
    background: dt('treetable.row.hover.background');
    color: dt('treetable.row.hover.color');
}

.p-treetable-gridlines .p-treetable-header {
    border-width: 1px 1px 0 1px;
}

.p-treetable-gridlines .p-treetable-footer {
    border-width: 0 1px 1px 1px;
}

.p-treetable-gridlines .p-treetable-paginator-top {
    border-width: 1px 1px 0 1px;
}

.p-treetable-gridlines .p-treetable-paginator-bottom {
    border-width: 0 1px 1px 1px;
}

.p-treetable-gridlines .p-treetable-thead > tr > th {
    border-width: 1px 0 1px 1px;
}

.p-treetable-gridlines .p-treetable-thead > tr > th:last-child {
    border-width: 1px;
}

.p-treetable-gridlines .p-treetable-tbody > tr > td {
    border-width: 1px 0 0 1px;
}

.p-treetable-gridlines .p-treetable-tbody > tr > td:last-child {
    border-width: 1px 1px 0 1px;
}

.p-treetable-gridlines .p-treetable-tbody > tr:last-child > td {
    border-width: 1px 0 1px 1px;
}

.p-treetable-gridlines .p-treetable-tbody > tr:last-child > td:last-child {
    border-width: 1px;
}

.p-treetable-gridlines .p-treetable-tfoot > tr > td {
    border-width: 1px 0 1px 1px;
}

.p-treetable-gridlines .p-treetable-tfoot > tr > td:last-child {
    border-width: 1px 1px 1px 1px;
}

.p-treetable.p-treetable-gridlines .p-treetable-thead + .p-treetable-tfoot > tr > td {
    border-width: 0 0 1px 1px;
}

.p-treetable.p-treetable-gridlines .p-treetable-thead + .p-treetable-tfoot > tr > td:last-child {
    border-width: 0 1px 1px 1px;
}

.p-treetable.p-treetable-gridlines:has(.p-treetable-thead):has(.p-treetable-tbody) .p-treetable-tbody > tr > td {
    border-width: 0 0 1px 1px;
}

.p-treetable.p-treetable-gridlines:has(.p-treetable-thead):has(.p-treetable-tbody) .p-treetable-tbody > tr > td:last-child {
    border-width: 0 1px 1px 1px;
}

.p-treetable.p-treetable-gridlines:has(.p-treetable-tbody):has(.p-treetable-tfoot) .p-treetable-tbody > tr:last-child > td {
    border-width: 0 0 0 1px;
}

.p-treetable.p-treetable-gridlines:has(.p-treetable-tbody):has(.p-treetable-tfoot) .p-treetable-tbody > tr:last-child > td:last-child {
    border-width: 0 1px 0 1px;
}

.p-treetable.p-treetable-sm .p-treetable-header {
    padding: 0.65625rem 0.875rem;
}

.p-treetable.p-treetable-sm .p-treetable-thead>tr>th {
    padding: 0.375rem 0.5rem;
}

.p-treetable.p-treetable-sm .p-treetable-tbody>tr>td {
    padding: 0.375rem 0.5rem;
}

.p-treetable.p-treetable-sm .p-treetable-tfoot>tr>td {
    padding: 0.375rem 0.5rem;
}

.p-treetable.p-treetable-sm .p-treetable-footer {
    padding: 0.375rem 0.5rem;
}

.p-treetable.p-treetable-lg .p-treetable-header {
    padding: 0.9375rem 1.25rem;
}

.p-treetable.p-treetable-lg .p-treetable-thead>tr>th {
    padding: 0.9375rem 1.25rem;
}

.p-treetable.p-treetable-lg .p-treetable-tbody>tr>td {
    padding: 0.9375rem 1.25rem;
}

.p-treetable.p-treetable-lg .p-treetable-tfoot>tr>td {
    padding: 0.9375rem 1.25rem;
}

.p-treetable.p-treetable-lg .p-treetable-footer {
    padding: 0.9375rem 1.25rem;
}

p-treetabletoggler + p-treetablecheckbox .p-checkbox,
p-treetable-toggler + p-treetable-checkbox .p-checkbox,
p-tree-table-toggler + p-tree-table-checkbox .p-checkbox {
    vertical-align: middle;
}

p-treetabletoggler + p-treetablecheckbox + span,
p-treetable-toggler + p-treetable-checkbox + span,
p-tree-table-toggler + p-tree-table-checkbox + span {
    vertical-align: middle;
}

p-treetable-sort-icon {
    display: inline-flex;
    align-items: center;
    gap: dt('treetable.header.cell.gap');
}
`;
const classes = {
    root: ({ instance }) => [
        'p-treetable p-component',
        {
            'p-treetable-gridlines': instance.showGridlines(),
            'p-treetable-hoverable-rows': instance.rowHover() || instance.selectionMode() === 'single' || instance.selectionMode() === 'multiple',
            'p-treetable-auto-layout': instance.autoLayout(),
            'p-treetable-resizable': instance.resizableColumns(),
            'p-treetable-resizable-fit': instance.resizableColumns() && instance.columnResizeMode() === 'fit',
            'p-treetable-flex-scrollable': instance.scrollable() && instance.scrollHeight() === 'flex'
        }
    ],
    loading: 'p-treetable-loading',
    mask: 'p-treetable-mask p-overlay-mask',
    loadingIcon: 'p-treetable-loading-icon',
    header: 'p-treetable-header',
    pcPaginator: ({ instance }) => ['p-treetable-paginator-' + instance.paginatorPosition(), instance.paginatorStyleClass()],
    tableContainer: 'p-treetable-table-container',
    table: ({ instance }) => ({
        'p-treetable-table': true,
        'p-treetable-scrollable-table': instance.scrollable(),
        'p-treetable-resizable-table': instance.resizableColumns(),
        'p-treetable-resizable-table-fit': instance.resizableColumns() && instance.columnResizeMode() === 'fit'
    }),
    thead: 'p-treetable-thead',
    sortableColumn: ({ instance }) => ({
        'p-sortable-column': instance.isEnabled(),
        'p-treetable-column-sorted': instance.sorted
    }),
    sortableColumnIcon: 'p-treetable-sort-icon',
    sortableColumnBadge: 'p-sortable-column-badge',
    columnResizer: 'p-treetable-column-resizer',
    columnHeaderContent: 'p-treetable-column-header-content',
    columnTitle: 'p-treetable-column-title',
    sortIcon: 'p-treetable-sort-icon',
    pcSortBadge: 'p-treetable-sort-badge',
    tbody: 'p-treetable-tbody',
    row: ({ instance }) => ({
        'p-treetable-row-selected': instance.selected
    }),
    contextMenuRow: ({ instance }) => ({
        'p-treetable-contextmenu-row-selected': instance.selected
    }),
    toggler: 'p-treetable-toggler',
    nodeToggleButton: 'p-treetable-node-toggle-button',
    nodeToggleIcon: 'p-treetable-node-toggle-icon',
    pcNodeCheckbox: 'p-treetable-node-checkbox',
    tfoot: 'p-treetable-tfoot',
    footerCell: ({ instance }) => ({
        'p-treetable-frozen-column': instance.columnProp('frozen')
    }),
    footer: 'p-treetable-footer',
    columnResizeIndicator: 'p-treetable-column-resize-indicator',
    wrapper: 'p-treetable-wrapper',
    scrollableWrapper: 'p-treetable-scrollable-wrapper',
    scrollableView: 'p-treetable-scrollable-view',
    frozenView: 'p-treetable-frozen-view',
    columnResizerHelper: 'p-column-resizer-helper',
    reorderIndicatorUp: 'p-treetable-reorder-indicator-up',
    reorderIndicatorDown: 'p-treetable-reorder-indicator-down',
    scrollableHeader: 'p-treetable-scrollable-header',
    scrollableHeaderBox: 'p-treetable-scrollable-header-box',
    scrollableHeaderTable: 'p-treetable-scrollable-header-table',
    scrollableBody: 'p-treetable-scrollable-body',
    scrollableFooter: 'p-treetable-scrollable-footer',
    scrollableFooterBox: 'p-treetable-scrollable-footer-box',
    scrollableFooterTable: 'p-treetable-scrollable-footer-table'
};
class TreeTableStyle extends BaseStyle {
    name = 'treetable';
    style = style;
    classes = classes;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeTableStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeTableStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeTableStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * TreeTable is used to display hierarchical data in tabular format.
 *
 * [Live Demo](https://www.ngx-prime.org/treetable/)
 *
 * @module treetablestyle
 *
 */
var TreeTableClasses;
(function (TreeTableClasses) {
    /**
     * Class name of the root element
     */
    TreeTableClasses["root"] = "p-treetable";
    /**
     * Class name of the loading element
     */
    TreeTableClasses["loading"] = "p-treetable-loading";
    /**
     * Class name of the mask element
     */
    TreeTableClasses["mask"] = "p-treetable-mask";
    /**
     * Class name of the loading icon element
     */
    TreeTableClasses["loadingIcon"] = "p-treetable-loading-icon";
    /**
     * Class name of the header element
     */
    TreeTableClasses["header"] = "p-treetable-header";
    /**
     * Class name of the paginator element
     */
    TreeTableClasses["pcPaginator"] = "p-treetable-paginator-[position]";
    /**
     * Class name of the table container element
     */
    TreeTableClasses["tableContainer"] = "p-treetable-table-container";
    /**
     * Class name of the table element
     */
    TreeTableClasses["table"] = "p-treetable-table";
    /**
     * Class name of the thead element
     */
    TreeTableClasses["thead"] = "p-treetable-thead";
    /**
     * Class name of the column resizer element
     */
    TreeTableClasses["columnResizer"] = "p-treetable-column-resizer";
    /**
     * Class name of the column title element
     */
    TreeTableClasses["columnTitle"] = "p-treetable-column-title";
    /**
     * Class name of the sort icon element
     */
    TreeTableClasses["sortIcon"] = "p-treetable-sort-icon";
    /**
     * Class name of the sort badge element
     */
    TreeTableClasses["pcSortBadge"] = "p-treetable-sort-badge";
    /**
     * Class name of the tbody element
     */
    TreeTableClasses["tbody"] = "p-treetable-tbody";
    /**
     * Class name of the node toggle button element
     */
    TreeTableClasses["nodeToggleButton"] = "p-treetable-node-toggle-button";
    /**
     * Class name of the node toggle icon element
     */
    TreeTableClasses["nodeToggleIcon"] = "p-treetable-node-toggle-icon";
    /**
     * Class name of the node checkbox element
     */
    TreeTableClasses["pcNodeCheckbox"] = "p-treetable-node-checkbox";
    /**
     * Class name of the empty message element
     */
    TreeTableClasses["emptyMessage"] = "p-treetable-empty-message";
    /**
     * Class name of the tfoot element
     */
    TreeTableClasses["tfoot"] = "p-treetable-tfoot";
    /**
     * Class name of the footer element
     */
    TreeTableClasses["footer"] = "p-treetable-footer";
    /**
     * Class name of the column resize indicator element
     */
    TreeTableClasses["columnResizeIndicator"] = "p-treetable-column-resize-indicator";
    /**
     * Class name of the wrapper element
     */
    TreeTableClasses["wrapper"] = "p-treetable-wrapper";
    /**
     * Class name of the scrollable wrapper element
     */
    TreeTableClasses["scrollableWrapper"] = "p-treetable-scrollable-wrapper";
    /**
     * Class name of the scrollable view element
     */
    TreeTableClasses["scrollableView"] = "p-treetable-scrollable-view";
    /**
     * Class name of the frozen view element
     */
    TreeTableClasses["frozenView"] = "p-treetable-frozen-view";
    /**
     * Class name of the column resizer helper element
     */
    TreeTableClasses["columnResizerHelper"] = "p-treetable-column-resizer-helper";
    /**
     * Class name of the reorder indicator up element
     */
    TreeTableClasses["reorderIndicatorUp"] = "p-treetable-reorder-indicator-up";
    /**
     * Class name of the reorder indicator down element
     */
    TreeTableClasses["reorderIndicatorDown"] = "p-treetable-reorder-indicator-down";
    /**
     * Class name of the scrollable header element
     */
    TreeTableClasses["scrollableHeader"] = "p-treetable-scrollable-header";
    /**
     * Class name of the scrollable header box element
     */
    TreeTableClasses["scrollableHeaderBox"] = "p-treetable-scrollable-header-box";
    /**
     * Class name of the scrollable header table element
     */
    TreeTableClasses["scrollableHeaderTable"] = "p-treetable-scrollable-header-table";
    /**
     * Class name of the scrollable body element
     */
    TreeTableClasses["scrollableBody"] = "p-treetable-scrollable-body";
    /**
     * Class name of the scrollable footer element
     */
    TreeTableClasses["scrollableFooter"] = "p-treetable-scrollable-footer";
    /**
     * Class name of the scrollable footer box element
     */
    TreeTableClasses["scrollableFooterBox"] = "p-treetable-scrollable-footer-box";
    /**
     * Class name of the scrollable footer table element
     */
    TreeTableClasses["scrollableFooterTable"] = "p-treetable-scrollable-footer-table";
    /**
     * Class name of the sortable column icon element
     */
    TreeTableClasses["sortableColumnIcon"] = "p-sortable-column-icon";
})(TreeTableClasses || (TreeTableClasses = {}));

const TREETABLE_INSTANCE = new InjectionToken('TREETABLE_INSTANCE');
class TreeTableService {
    sortSource = new Subject();
    selectionSource = new Subject();
    contextMenuSource = new Subject();
    uiUpdateSource = new Subject();
    totalRecordsSource = new Subject();
    sortSource$ = this.sortSource.asObservable();
    selectionSource$ = this.selectionSource.asObservable();
    contextMenuSource$ = this.contextMenuSource.asObservable();
    uiUpdateSource$ = this.uiUpdateSource.asObservable();
    totalRecordsSource$ = this.totalRecordsSource.asObservable();
    onSort(sortMeta) {
        this.sortSource.next(sortMeta);
    }
    onSelectionChange() {
        this.selectionSource.next(null);
    }
    onContextMenu(node) {
        this.contextMenuSource.next(node);
    }
    onUIUpdate(value) {
        this.uiUpdateSource.next(value);
    }
    onTotalRecordsChange(value) {
        this.totalRecordsSource.next(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeTableService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeTableService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeTableService, decorators: [{
            type: Injectable
        }] });
/**
 * TreeTable is used to display hierarchical data in tabular format.
 * @group Components
 */
class TreeTable extends BaseComponent {
    componentName = 'TreeTable';
    _componentStyle = inject(TreeTableStyle);
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    /**
     * An array of objects to represent dynamic columns.
     * @group Props
     */
    columns = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "columns" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Inline style of the table.
     * @group Props
     */
    tableStyle = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "tableStyle" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the table.
     * @group Props
     */
    tableStyleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "tableStyleClass" }] : /* istanbul ignore next */ []));
    /**
     * Whether the cell widths scale according to their content or not.
     * @group Props
     */
    autoLayout = input(undefined, { ...(ngDevMode ? { debugName: "autoLayout" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Defines if data is loaded and interacted with in lazy manner.
     * @group Props
     */
    lazy = input(false, { ...(ngDevMode ? { debugName: "lazy" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to call lazy loading on initialization.
     * @group Props
     */
    lazyLoadOnInit = input(true, { ...(ngDevMode ? { debugName: "lazyLoadOnInit" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * When specified as true, enables the pagination.
     * @group Props
     */
    paginator = input(undefined, { ...(ngDevMode ? { debugName: "paginator" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Number of rows to display per page.
     * @group Props
     */
    rows = input(undefined, { ...(ngDevMode ? { debugName: "rows" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Index of the first row to be displayed.
     * @group Props
     */
    first = input(0, { ...(ngDevMode ? { debugName: "first" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Number of page links to display in paginator.
     * @group Props
     */
    pageLinks = input(5, { ...(ngDevMode ? { debugName: "pageLinks" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Array of integer/object values to display inside rows per page dropdown of paginator
     * @group Props
     */
    rowsPerPageOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "rowsPerPageOptions" }] : /* istanbul ignore next */ []));
    /**
     * Whether to show it even there is only one page.
     * @group Props
     */
    alwaysShowPaginator = input(true, { ...(ngDevMode ? { debugName: "alwaysShowPaginator" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Position of the paginator.
     * @group Props
     */
    paginatorPosition = input('bottom', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "paginatorPosition" }] : /* istanbul ignore next */ []));
    /**
     * Custom style class for paginator
     * @group Props
     */
    paginatorStyleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "paginatorStyleClass" }] : /* istanbul ignore next */ []));
    /**
     * Target element to attach the paginator dropdown overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @group Props
     */
    paginatorDropdownAppendTo = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "paginatorDropdownAppendTo" }] : /* istanbul ignore next */ []));
    /**
     * Template of the current page report element. Available placeholders are {currentPage},{totalPages},{rows},{first},{last} and {totalRecords}
     * @group Props
     */
    currentPageReportTemplate = input('{currentPage} of {totalPages}', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentPageReportTemplate" }] : /* istanbul ignore next */ []));
    /**
     * Whether to display current page report.
     * @group Props
     */
    showCurrentPageReport = input(undefined, { ...(ngDevMode ? { debugName: "showCurrentPageReport" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to display a dropdown to navigate to any page.
     * @group Props
     */
    showJumpToPageDropdown = input(undefined, { ...(ngDevMode ? { debugName: "showJumpToPageDropdown" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * When enabled, icons are displayed on paginator to go first and last page.
     * @group Props
     */
    showFirstLastIcon = input(true, { ...(ngDevMode ? { debugName: "showFirstLastIcon" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to show page links.
     * @group Props
     */
    showPageLinks = input(true, { ...(ngDevMode ? { debugName: "showPageLinks" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Sort order to use when an unsorted column gets sorted by user interaction.
     * @group Props
     */
    defaultSortOrder = input(1, { ...(ngDevMode ? { debugName: "defaultSortOrder" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Defines whether sorting works on single column or on multiple columns.
     * @group Props
     */
    sortMode = input('single', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sortMode" }] : /* istanbul ignore next */ []));
    /**
     * When true, resets paginator to first page after sorting.
     * @group Props
     */
    resetPageOnSort = input(true, { ...(ngDevMode ? { debugName: "resetPageOnSort" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to use the default sorting or a custom one using sortFunction.
     * @group Props
     */
    customSort = input(undefined, { ...(ngDevMode ? { debugName: "customSort" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Specifies the selection mode, valid values are "single" and "multiple".
     * @group Props
     */
    selectionMode = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "selectionMode" }] : /* istanbul ignore next */ []));
    /**
     * Selected row with a context menu.
     * @group Props
     */
    contextMenuSelection = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "contextMenuSelection" }] : /* istanbul ignore next */ []));
    /**
     * Mode of the contet menu selection.
     * @group Props
     */
    contextMenuSelectionMode = input('separate', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "contextMenuSelectionMode" }] : /* istanbul ignore next */ []));
    /**
     * A property to uniquely identify a record in data.
     * @group Props
     */
    dataKey = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "dataKey" }] : /* istanbul ignore next */ []));
    /**
     * Defines whether metaKey is should be considered for the selection. On touch enabled devices, metaKeySelection is turned off automatically.
     * @group Props
     */
    metaKeySelection = input(false, { ...(ngDevMode ? { debugName: "metaKeySelection" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Algorithm to define if a row is selected, valid values are "equals" that compares by reference and "deepEquals" that compares all fields.
     * @group Props
     */
    compareSelectionBy = input('deepEquals', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "compareSelectionBy" }] : /* istanbul ignore next */ []));
    /**
     * Adds hover effect to rows without the need for selectionMode.
     * @group Props
     */
    rowHover = input(undefined, { ...(ngDevMode ? { debugName: "rowHover" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Displays a loader to indicate data load is in progress.
     * @group Props
     */
    loading = input(undefined, { ...(ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * The icon to show while indicating data load is in progress.
     * @group Props
     */
    loadingIcon = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "loadingIcon" }] : /* istanbul ignore next */ []));
    /**
     * Whether to show the loading mask when loading property is true.
     * @group Props
     */
    showLoader = input(true, { ...(ngDevMode ? { debugName: "showLoader" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * When specified, enables horizontal and/or vertical scrolling.
     * @group Props
     */
    scrollable = input(undefined, { ...(ngDevMode ? { debugName: "scrollable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Height of the scroll viewport in fixed pixels or the "flex" keyword for a dynamic size.
     * @group Props
     */
    scrollHeight = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "scrollHeight" }] : /* istanbul ignore next */ []));
    /**
     * Whether the data should be loaded on demand during scroll.
     * @group Props
     */
    virtualScroll = input(undefined, { ...(ngDevMode ? { debugName: "virtualScroll" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Height of a row to use in calculations of virtual scrolling.
     * @group Props
     */
    virtualScrollItemSize = input(undefined, { ...(ngDevMode ? { debugName: "virtualScrollItemSize" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Whether to use the scroller feature. The properties of scroller component can be used like an object in it.
     * @group Props
     */
    virtualScrollOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "virtualScrollOptions" }] : /* istanbul ignore next */ []));
    /**
     * The delay (in milliseconds) before triggering the virtual scroll. This determines the time gap between the user's scroll action and the actual rendering of the next set of items in the virtual scroll.
     * @group Props
     */
    virtualScrollDelay = input(150, { ...(ngDevMode ? { debugName: "virtualScrollDelay" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Width of the frozen columns container.
     * @group Props
     */
    frozenWidth = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "frozenWidth" }] : /* istanbul ignore next */ []));
    /**
     * An array of objects to represent dynamic columns that are frozen.
     * @group Props
     */
    frozenColumns = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "frozenColumns" }] : /* istanbul ignore next */ []));
    /**
     * When enabled, columns can be resized using drag and drop.
     * @group Props
     */
    resizableColumns = input(undefined, { ...(ngDevMode ? { debugName: "resizableColumns" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Defines whether the overall table width should change on column resize, valid values are "fit" and "expand".
     * @group Props
     */
    columnResizeMode = input('fit', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "columnResizeMode" }] : /* istanbul ignore next */ []));
    /**
     * When enabled, columns can be reordered using drag and drop.
     * @group Props
     */
    reorderableColumns = input(undefined, { ...(ngDevMode ? { debugName: "reorderableColumns" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Local ng-template varilable of a ContextMenu.
     * @group Props
     */
    contextMenu = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "contextMenu" }] : /* istanbul ignore next */ []));
    /**
     * Function to optimize the dom operations by delegating to ngForTrackBy, default algorithm checks for object identity.
     * @group Props
     */
    rowTrackBy = input((index, item) => item, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rowTrackBy" }] : /* istanbul ignore next */ []));
    /**
     * An array of FilterMetadata objects to provide external filters.
     * @group Props
     */
    filters = input({}, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filters" }] : /* istanbul ignore next */ []));
    /**
     * An array of fields as string to use in global filtering.
     * @group Props
     */
    globalFilterFields = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "globalFilterFields" }] : /* istanbul ignore next */ []));
    /**
     * Delay in milliseconds before filtering the data.
     * @group Props
     */
    filterDelay = input(300, { ...(ngDevMode ? { debugName: "filterDelay" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Mode for filtering valid values are "lenient" and "strict". Default is lenient.
     * @group Props
     */
    filterMode = input('lenient', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterMode" }] : /* istanbul ignore next */ []));
    /**
     * Locale to use in filtering. The default locale is the host environment's current locale.
     * @group Props
     */
    filterLocale = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "filterLocale" }] : /* istanbul ignore next */ []));
    /**
     * Locale to be used in paginator formatting.
     * @group Props
     */
    paginatorLocale = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "paginatorLocale" }] : /* istanbul ignore next */ []));
    /**
     * Number of total records, defaults to length of value when not defined.
     * @group Props
     */
    totalRecords = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "totalRecords" }] : /* istanbul ignore next */ []));
    /**
     * Name of the field to sort data by default.
     * @group Props
     */
    sortField = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "sortField" }] : /* istanbul ignore next */ []));
    /**
     * Order to sort when default sorting is enabled.
     * @defaultValue 1
     * @group Props
     */
    sortOrder = input(1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sortOrder" }] : /* istanbul ignore next */ []));
    /**
     * An array of SortMeta objects to sort the data by default in multiple sort mode.
     * @defaultValue null
     * @group Props
     */
    multiSortMeta = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "multiSortMeta" }] : /* istanbul ignore next */ []));
    /**
     * Selected row in single mode or an array of values in multiple mode.
     * @defaultValue null
     * @group Props
     */
    selection = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "selection" }] : /* istanbul ignore next */ []));
    /**
     * An array of objects to display.
     * @defaultValue null
     * @group Props
     */
    value = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    /**
     * Indicates the height of rows to be scrolled.
     * @defaultValue 28
     * @group Props
     * @deprecated use virtualScrollItemSize property instead.
     */
    virtualRowHeight = input(28, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "virtualRowHeight" }] : /* istanbul ignore next */ []));
    /**
     * A map of keys to control the selection state.
     * @group Props
     */
    selectionKeys = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "selectionKeys" }] : /* istanbul ignore next */ []));
    /**
     * Whether to show grid lines between cells.
     * @defaultValue false
     * @group Props
     */
    showGridlines = input(false, { ...(ngDevMode ? { debugName: "showGridlines" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Callback to invoke on selected node change.
     * @param {TreeTableNode} object - Node instance.
     * @group Emits
     */
    selectionChange = output();
    /**
     * Callback to invoke on context menu selection change.
     * @param {TreeTableNode} object - Node instance.
     * @group Emits
     */
    contextMenuSelectionChange = output();
    /**
     * Callback to invoke when data is filtered.
     * @param {TreeTableFilterEvent} event - Custom filter event.
     * @group Emits
     */
    onFilter = output();
    /**
     * Callback to invoke when a node is expanded.
     * @param {TreeTableNodeExpandEvent} event - Node expand event.
     * @group Emits
     */
    onNodeExpand = output();
    /**
     * Callback to invoke when a node is collapsed.
     * @param {TreeTableNodeCollapseEvent} event - Node collapse event.
     * @group Emits
     */
    onNodeCollapse = output();
    /**
     * Callback to invoke when pagination occurs.
     * @param {TreeTablePaginatorState} object - Paginator state.
     * @group Emits
     */
    onPage = output();
    /**
     * Callback to invoke when a column gets sorted.
     * @param {Object} Object - Sort data.
     * @group Emits
     */
    onSort = output();
    /**
     * Callback to invoke when paging, sorting or filtering happens in lazy mode.
     * @param {TreeTableLazyLoadEvent} event - Custom lazy load event.
     * @group Emits
     */
    onLazyLoad = output();
    /**
     * An event emitter to invoke on custom sorting, refer to sorting section for details.
     * @param {TreeTableSortEvent} event - Custom sort event.
     * @group Emits
     */
    sortFunction = output();
    /**
     * Callback to invoke when a column is resized.
     * @param {TreeTableColResizeEvent} event - Custom column resize event.
     * @group Emits
     */
    onColResize = output();
    /**
     * Callback to invoke when a column is reordered.
     * @param {TreeTableColumnReorderEvent} event - Custom column reorder.
     * @group Emits
     */
    onColReorder = output();
    /**
     * Callback to invoke when a node is selected.
     * @param {TreeTableNode} object - Node instance.
     * @group Emits
     */
    onNodeSelect = output();
    /**
     * Callback to invoke when a node is unselected.
     * @param {TreeTableNodeUnSelectEvent} event - Custom node unselect event.
     * @group Emits
     */
    onNodeUnselect = output();
    /**
     * Callback to invoke when a node is selected with right click.
     * @param {TreeTableContextMenuSelectEvent} event - Custom context menu select event.
     * @group Emits
     */
    onContextMenuSelect = output();
    /**
     * Callback to invoke when state of header checkbox changes.
     * @param {TreeTableHeaderCheckboxToggleEvent} event - Custom checkbox toggle event.
     * @group Emits
     */
    onHeaderCheckboxToggle = output();
    /**
     * Callback to invoke when a cell switches to edit mode.
     * @param {TreeTableEditEvent} event - Custom edit event.
     * @group Emits
     */
    onEditInit = output();
    /**
     * Callback to invoke when cell edit is completed.
     * @param {TreeTableEditEvent} event - Custom edit event.
     * @group Emits
     */
    onEditComplete = output();
    /**
     * Callback to invoke when cell edit is cancelled with escape key.
     * @param {TreeTableEditEvent} event - Custom edit event.
     * @group Emits
     */
    onEditCancel = output();
    /**
     * Callback to invoke when selectionKeys are changed.
     * @param {Object} object - updated value of the selectionKeys.
     * @group Emits
     */
    selectionKeysChange = output();
    resizeHelperViewChild = viewChild('resizeHelper', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "resizeHelperViewChild" }] : /* istanbul ignore next */ []));
    reorderIndicatorUpViewChild = viewChild('reorderIndicatorUp', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "reorderIndicatorUpViewChild" }] : /* istanbul ignore next */ []));
    reorderIndicatorDownViewChild = viewChild('reorderIndicatorDown', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "reorderIndicatorDownViewChild" }] : /* istanbul ignore next */ []));
    tableViewChild = viewChild('table', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tableViewChild" }] : /* istanbul ignore next */ []));
    scrollableViewChild = viewChild('scrollableView', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scrollableViewChild" }] : /* istanbul ignore next */ []));
    scrollableFrozenViewChild = viewChild('scrollableFrozenView', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scrollableFrozenViewChild" }] : /* istanbul ignore next */ []));
    _value = [];
    _virtualRowHeight = 28;
    _selectionKeys;
    serializedValue;
    _totalRecords = 0;
    _multiSortMeta;
    _sortField;
    _sortOrder = 1;
    _first = 0;
    _rows;
    _filters = {};
    _contextMenuSelection;
    filteredNodes;
    filterTimeout;
    _colGroupTemplate = contentChild('colgroup', { ...(ngDevMode ? { debugName: "_colGroupTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    colGroupTemplate;
    _captionTemplate;
    captionTemplate;
    _headerTemplate = contentChild('header', { ...(ngDevMode ? { debugName: "_headerTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    headerTemplate;
    _bodyTemplate = contentChild('body', { ...(ngDevMode ? { debugName: "_bodyTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    bodyTemplate;
    _footerTemplate;
    footerTemplate;
    _summaryTemplate;
    summaryTemplate;
    _emptyMessageTemplate = contentChild('emptymessage', { ...(ngDevMode ? { debugName: "_emptyMessageTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    emptyMessageTemplate;
    _paginatorLeftTemplate = contentChild('paginatorleft', { ...(ngDevMode ? { debugName: "_paginatorLeftTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    paginatorLeftTemplate;
    _paginatorRightTemplate = contentChild('paginatorright', { ...(ngDevMode ? { debugName: "_paginatorRightTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    paginatorRightTemplate;
    _paginatorDropdownItemTemplate = contentChild('paginatordropdownitem', { ...(ngDevMode ? { debugName: "_paginatorDropdownItemTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    paginatorDropdownItemTemplate;
    _frozenHeaderTemplate = contentChild('frozenheader', { ...(ngDevMode ? { debugName: "_frozenHeaderTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    frozenHeaderTemplate;
    _frozenBodyTemplate = contentChild('frozenbody', { ...(ngDevMode ? { debugName: "_frozenBodyTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    frozenBodyTemplate;
    _frozenFooterTemplate = contentChild('frozenfooter', { ...(ngDevMode ? { debugName: "_frozenFooterTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    frozenFooterTemplate;
    _frozenColGroupTemplate = contentChild('frozencolgroup', { ...(ngDevMode ? { debugName: "_frozenColGroupTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    frozenColGroupTemplate;
    _loadingIconTemplate;
    loadingIconTemplate;
    _reorderIndicatorUpIconTemplate = contentChild('reorderindicatorupicon', { ...(ngDevMode ? { debugName: "_reorderIndicatorUpIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    reorderIndicatorUpIconTemplate;
    _reorderIndicatorDownIconTemplate = contentChild('reorderindicatordownicon', { ...(ngDevMode ? { debugName: "_reorderIndicatorDownIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    reorderIndicatorDownIconTemplate;
    _sortIconTemplate;
    sortIconTemplate;
    _checkboxIconTemplate;
    checkboxIconTemplate;
    _headerCheckboxIconTemplate;
    headerCheckboxIconTemplate;
    _togglerIconTemplate = contentChild('togglericon', { ...(ngDevMode ? { debugName: "_togglerIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    togglerIconTemplate;
    _paginatorFirstPageLinkIconTemplate;
    paginatorFirstPageLinkIconTemplate;
    _paginatorLastPageLinkIconTemplate;
    paginatorLastPageLinkIconTemplate;
    _paginatorPreviousPageLinkIconTemplate;
    paginatorPreviousPageLinkIconTemplate;
    _paginatorNextPageLinkIconTemplate;
    paginatorNextPageLinkIconTemplate;
    _loaderTemplate;
    loaderTemplate;
    lastResizerHelperX;
    reorderIconWidth;
    reorderIconHeight;
    draggedColumn;
    dropPosition;
    preventSelectionSetterPropagation;
    _selection;
    selectedKeys = {};
    rowTouched;
    editingCell;
    editingCellData;
    editingCellField;
    editingCellClick;
    documentEditListener;
    initialized;
    toggleRowIndex;
    onInit() {
        if (this.lazy() && this.lazyLoadOnInit() && !this.virtualScroll()) {
            this.onLazyLoad.emit(this.createLazyLoadMetadata());
        }
        this.initialized = true;
    }
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    onAfterContentInit() {
        this.templates().forEach((item) => {
            switch (item.getType()) {
                case 'caption':
                    this.captionTemplate = item.template;
                    break;
                case 'header':
                    this.headerTemplate = item.template;
                    break;
                case 'body':
                    this.bodyTemplate = item.template;
                    break;
                case 'footer':
                    this.footerTemplate = item.template;
                    break;
                case 'summary':
                    this.summaryTemplate = item.template;
                    break;
                case 'colgroup':
                    this.colGroupTemplate = item.template;
                    break;
                case 'emptymessage':
                    this.emptyMessageTemplate = item.template;
                    break;
                case 'paginatorleft':
                    this.paginatorLeftTemplate = item.template;
                    break;
                case 'paginatorright':
                    this.paginatorRightTemplate = item.template;
                    break;
                case 'paginatordropdownitem':
                    this.paginatorDropdownItemTemplate = item.template;
                    break;
                case 'frozenheader':
                    this.frozenHeaderTemplate = item.template;
                    break;
                case 'frozenbody':
                    this.frozenBodyTemplate = item.template;
                    break;
                case 'frozenfooter':
                    this.frozenFooterTemplate = item.template;
                    break;
                case 'frozencolgroup':
                    this.frozenColGroupTemplate = item.template;
                    break;
                case 'loadingicon':
                    this.loadingIconTemplate = item.template;
                    break;
                case 'reorderindicatorupicon':
                    this.reorderIndicatorUpIconTemplate = item.template;
                    break;
                case 'reorderindicatordownicon':
                    this.reorderIndicatorDownIconTemplate = item.template;
                    break;
                case 'sorticon':
                    this.sortIconTemplate = item.template;
                    break;
                case 'checkboxicon':
                    this.checkboxIconTemplate = item.template;
                    break;
                case 'headercheckboxicon':
                    this.headerCheckboxIconTemplate = item.template;
                    break;
                case 'togglericon':
                    this.togglerIconTemplate = item.template;
                    break;
                case 'paginatorfirstpagelinkicon':
                    this.paginatorFirstPageLinkIconTemplate = item.template;
                    break;
                case 'paginatorlastpagelinkicon':
                    this.paginatorLastPageLinkIconTemplate = item.template;
                    break;
                case 'paginatorpreviouspagelinkicon':
                    this.paginatorPreviousPageLinkIconTemplate = item.template;
                    break;
                case 'paginatornextpagelinkicon':
                    this.paginatorNextPageLinkIconTemplate = item.template;
                    break;
                case 'loader':
                    this.loaderTemplate = item.template;
                    break;
            }
        });
    }
    filterService = inject(FilterService);
    tableService = inject(TreeTableService);
    zone = inject(NgZone);
    _prevValue;
    _prevSortField;
    _prevSortOrder;
    _prevMultiSortMeta;
    _prevSelection;
    constructor() {
        super();
        effect(() => {
            this._totalRecords = this.totalRecords();
            this.tableService.onTotalRecordsChange(this._totalRecords);
        });
        effect(() => {
            this._virtualRowHeight = this.virtualRowHeight();
            console.log('The virtualRowHeight property is deprecated, use virtualScrollItemSize property instead.');
        });
        effect(() => {
            this._selectionKeys = this.selectionKeys();
            this.selectionKeysChange.emit(this._selectionKeys);
        });
        effect(() => {
            this._first = this.first();
        });
        effect(() => {
            this._rows = this.rows();
        });
        effect(() => {
            this._filters = this.filters();
        });
        effect(() => {
            this._contextMenuSelection = this.contextMenuSelection();
        });
        effect(() => {
            const value = this.value();
            const sortField = this.sortField();
            const sortOrder = this.sortOrder();
            const multiSortMeta = this.multiSortMeta();
            const selection = this.selection();
            const valueChanged = this._prevValue !== value;
            const sortFieldChanged = this._prevSortField !== sortField;
            const sortOrderChanged = this._prevSortOrder !== sortOrder;
            const multiSortMetaChanged = this._prevMultiSortMeta !== multiSortMeta;
            const selectionChanged = this._prevSelection !== selection;
            if (valueChanged) {
                this._value = value;
                if (!this.lazy()) {
                    this._totalRecords = this._value ? this._value.length : 0;
                    this.tableService.onTotalRecordsChange(this._totalRecords);
                    const sortMode = this.sortMode();
                    if (sortMode == 'single' && this._sortField)
                        this.sortSingle();
                    else if (sortMode == 'multiple' && this._multiSortMeta)
                        this.sortMultiple();
                    else if (this.hasFilter())
                        //sort already filters
                        this._filter();
                }
                this.updateSerializedValue();
                this.tableService.onUIUpdate(this._value);
            }
            const lazy = this.lazy();
            const sortMode = this.sortMode();
            if (sortFieldChanged) {
                this._sortField = sortField;
                //avoid triggering lazy load prior to lazy initialization at onInit
                if (!lazy || this.initialized) {
                    if (sortMode === 'single') {
                        this.sortSingle();
                    }
                }
            }
            if (sortOrderChanged) {
                this._sortOrder = sortOrder;
                //avoid triggering lazy load prior to lazy initialization at onInit
                if (!lazy || this.initialized) {
                    if (sortMode === 'single') {
                        this.sortSingle();
                    }
                }
            }
            if (multiSortMetaChanged) {
                this._multiSortMeta = multiSortMeta;
                if (sortMode === 'multiple') {
                    this.sortMultiple();
                }
            }
            if (selectionChanged) {
                this._selection = selection;
                if (!this.preventSelectionSetterPropagation) {
                    this.updateselectedKeys();
                    this.tableService.onSelectionChange();
                }
                this.preventSelectionSetterPropagation = false;
            }
            this._prevValue = value;
            this._prevSortField = sortField;
            this._prevSortOrder = sortOrder;
            this._prevMultiSortMeta = multiSortMeta;
            this._prevSelection = selection;
        });
    }
    updateSerializedValue() {
        this.serializedValue = [];
        if (this.paginator())
            this.serializePageNodes();
        else
            this.serializeNodes(null, this.filteredNodes || this._value, 0, true);
    }
    serializeNodes(parent, nodes, level, visible) {
        if (nodes && nodes.length) {
            for (let node of nodes) {
                node.parent = parent;
                const rowNode = {
                    node: node,
                    parent: parent,
                    level: level,
                    visible: visible && (parent ? parent.expanded : true)
                };
                this.serializedValue.push(rowNode);
                if (rowNode.visible && node.expanded) {
                    this.serializeNodes(node, node.children, level + 1, rowNode.visible);
                }
            }
        }
    }
    serializePageNodes() {
        let data = this.filteredNodes || this._value;
        this.serializedValue = [];
        if (data && data.length) {
            const first = this.lazy() ? 0 : this._first;
            for (let i = first; i < first + this._rows; i++) {
                let node = data[i];
                if (node) {
                    this.serializedValue.push({
                        node: node,
                        parent: null,
                        level: 0,
                        visible: true
                    });
                    this.serializeNodes(node, node.children, 1, true);
                }
            }
        }
    }
    updateselectedKeys() {
        const dataKey = this.dataKey();
        if (dataKey && this._selection) {
            this.selectedKeys = {};
            if (Array.isArray(this._selection)) {
                for (let node of this._selection) {
                    this.selectedKeys[String(resolveFieldData(node.data, dataKey))] = 1;
                }
            }
            else {
                this.selectedKeys[String(resolveFieldData(this._selection.data, dataKey))] = 1;
            }
        }
    }
    onPageChange(event) {
        this._first = event.first;
        this._rows = event.rows;
        if (this.lazy())
            this.onLazyLoad.emit(this.createLazyLoadMetadata());
        else
            this.serializePageNodes();
        this.onPage.emit({
            first: this._first,
            rows: this._rows
        });
        this.tableService.onUIUpdate(this._value);
        if (this.scrollable()) {
            this.resetScrollTop();
        }
    }
    sort(event) {
        let originalEvent = event.originalEvent;
        const sortMode = this.sortMode();
        const scrollable = this.scrollable();
        const resetPageOnSort = this.resetPageOnSort();
        if (sortMode === 'single') {
            this._sortOrder = this._sortField === event.field ? this._sortOrder * -1 : this.defaultSortOrder();
            this._sortField = event.field;
            this.sortSingle();
            if (resetPageOnSort && scrollable) {
                this.resetScrollTop();
            }
        }
        if (sortMode === 'multiple') {
            let metaKey = originalEvent.metaKey || originalEvent.ctrlKey;
            let sortMeta = this.getSortMeta(event.field);
            if (sortMeta) {
                if (!metaKey) {
                    this._multiSortMeta = [{ field: event.field, order: sortMeta.order * -1 }];
                    if (resetPageOnSort && scrollable) {
                        this.resetScrollTop();
                    }
                }
                else {
                    sortMeta.order = sortMeta.order * -1;
                }
            }
            else {
                if (!metaKey || !this._multiSortMeta) {
                    this._multiSortMeta = [];
                    if (resetPageOnSort && scrollable) {
                        this.resetScrollTop();
                    }
                }
                this._multiSortMeta.push({ field: event.field, order: this.defaultSortOrder() });
            }
            this.sortMultiple();
        }
    }
    sortSingle() {
        if (this._sortField && this._sortOrder) {
            if (this.lazy()) {
                this.onLazyLoad.emit(this.createLazyLoadMetadata());
            }
            else if (this._value) {
                this.sortNodes(this._value);
                if (this.hasFilter()) {
                    this._filter();
                }
            }
            let sortMeta = {
                field: this._sortField,
                order: this._sortOrder
            };
            this.onSort.emit(sortMeta);
            this.tableService.onSort(sortMeta);
            this.updateSerializedValue();
        }
    }
    sortNodes(nodes) {
        if (!nodes || nodes.length === 0) {
            return;
        }
        if (this.customSort()) {
            this.sortFunction.emit({
                data: nodes,
                mode: this.sortMode(),
                field: this._sortField,
                order: this._sortOrder
            });
        }
        else {
            nodes.sort((node1, node2) => {
                let value1 = resolveFieldData(node1.data, this._sortField);
                let value2 = resolveFieldData(node2.data, this._sortField);
                let result = 0;
                if (value1 == null && value2 != null)
                    result = -1;
                else if (value1 != null && value2 == null)
                    result = 1;
                else if (value1 == null && value2 == null)
                    result = 0;
                else if (typeof value1 === 'string' && typeof value2 === 'string')
                    result = value1.localeCompare(value2, undefined, { numeric: true });
                else
                    result = value1 < value2 ? -1 : value1 > value2 ? 1 : 0;
                return this._sortOrder * result;
            });
        }
        for (let node of nodes) {
            this.sortNodes(node.children);
        }
    }
    sortMultiple() {
        if (this._multiSortMeta) {
            if (this.lazy()) {
                this.onLazyLoad.emit(this.createLazyLoadMetadata());
            }
            else if (this._value) {
                this.sortMultipleNodes(this._value);
                if (this.hasFilter()) {
                    this._filter();
                }
            }
            this.onSort.emit({
                multisortmeta: this._multiSortMeta
            });
            this.updateSerializedValue();
            this.tableService.onSort(this._multiSortMeta);
        }
    }
    sortMultipleNodes(nodes) {
        if (!nodes || nodes.length === 0) {
            return;
        }
        if (this.customSort()) {
            this.sortFunction.emit({
                data: this._value,
                mode: this.sortMode(),
                multiSortMeta: this._multiSortMeta
            });
        }
        else {
            nodes.sort((node1, node2) => this.multisortField(node1, node2, this._multiSortMeta, 0));
        }
        for (let node of nodes) {
            this.sortMultipleNodes(node.children);
        }
    }
    multisortField(node1, node2, multiSortMeta, index) {
        if (isEmpty(this._multiSortMeta) || isEmpty(multiSortMeta[index])) {
            return 0;
        }
        let value1 = resolveFieldData(node1.data, multiSortMeta[index].field);
        let value2 = resolveFieldData(node2.data, multiSortMeta[index].field);
        let result = 0;
        if (value1 == null && value2 != null)
            result = -1;
        else if (value1 != null && value2 == null)
            result = 1;
        else if (value1 == null && value2 == null)
            result = 0;
        if (typeof value1 == 'string' || value1 instanceof String) {
            if (value1.localeCompare && value1 != value2) {
                return multiSortMeta[index].order * value1.localeCompare(value2, undefined, { numeric: true });
            }
        }
        else {
            result = value1 < value2 ? -1 : 1;
        }
        if (value1 == value2) {
            return multiSortMeta.length - 1 > index ? this.multisortField(node1, node2, multiSortMeta, index + 1) : 0;
        }
        return multiSortMeta[index].order * result;
    }
    getSortMeta(field) {
        if (this._multiSortMeta && this._multiSortMeta.length) {
            for (let i = 0; i < this._multiSortMeta.length; i++) {
                if (this._multiSortMeta[i].field === field) {
                    return this._multiSortMeta[i];
                }
            }
        }
        return null;
    }
    isSorted(field) {
        const sortMode = this.sortMode();
        if (sortMode === 'single') {
            return this._sortField && this._sortField === field;
        }
        else if (sortMode === 'multiple') {
            let sorted = false;
            if (this._multiSortMeta) {
                for (let i = 0; i < this._multiSortMeta.length; i++) {
                    if (this._multiSortMeta[i].field == field) {
                        sorted = true;
                        break;
                    }
                }
            }
            return sorted;
        }
    }
    createLazyLoadMetadata() {
        const filters = this._filters;
        return {
            first: this._first,
            rows: this._rows,
            sortField: this._sortField,
            sortOrder: this._sortOrder,
            filters: this._filters,
            globalFilter: filters && filters['global'] ? filters['global'].value : null,
            multiSortMeta: this._multiSortMeta,
            forceUpdate: () => this.cd.detectChanges()
        };
    }
    onLazyItemLoad(event) {
        this.onLazyLoad.emit({
            ...this.createLazyLoadMetadata(),
            ...event,
            rows: event.last - event.first
        });
    }
    /**
     * Resets scroll to top.
     * @group Method
     */
    resetScrollTop() {
        if (this.virtualScroll())
            this.scrollToVirtualIndex(0);
        else
            this.scrollTo({ top: 0 });
    }
    /**
     * Scrolls to given index when using virtual scroll.
     * @param {number} index - index of the element.
     * @group Method
     */
    scrollToVirtualIndex(index) {
        const scrollableViewChild = this.scrollableViewChild();
        if (scrollableViewChild) {
            scrollableViewChild.scrollToVirtualIndex(index);
        }
        if (this.scrollableFrozenViewChild()) {
            scrollableViewChild.scrollToVirtualIndex(index);
        }
    }
    /**
     * Scrolls to given index.
     * @param {ScrollToOptions} options - Scroll options.
     * @group Method
     */
    scrollTo(options) {
        const scrollableViewChild = this.scrollableViewChild();
        if (scrollableViewChild) {
            scrollableViewChild.scrollTo(options);
        }
        if (this.scrollableFrozenViewChild()) {
            scrollableViewChild.scrollTo(options);
        }
    }
    isEmpty() {
        let data = this.filteredNodes || this._value;
        return data == null || data.length == 0;
    }
    getBlockableElement() {
        return this.el.nativeElement.children[0];
    }
    onColumnResizeBegin(event) {
        let containerLeft = getOffset(this.el?.nativeElement).left;
        this.lastResizerHelperX = event.pageX - containerLeft + this.el?.nativeElement.scrollLeft;
        event.preventDefault();
    }
    onColumnResize(event) {
        let containerLeft = getOffset(this.el?.nativeElement).left;
        this.el?.nativeElement.setAttribute('data-p-unselectable-text', 'true');
        !this.$unstyled() && addStyle(this.el.nativeElement, { 'user-select': 'none' });
        this.resizeHelperViewChild().nativeElement.style.height = this.el?.nativeElement.offsetHeight + 'px';
        this.resizeHelperViewChild().nativeElement.style.top = 0 + 'px';
        this.resizeHelperViewChild().nativeElement.style.left = event.pageX - containerLeft + this.el?.nativeElement.scrollLeft + 'px';
        this.resizeHelperViewChild().nativeElement.style.display = 'block';
    }
    onColumnResizeEnd(event, column) {
        let delta = this.resizeHelperViewChild().nativeElement.offsetLeft - this.lastResizerHelperX;
        let columnWidth = column.offsetWidth;
        let newColumnWidth = columnWidth + delta;
        let minWidth = column.style.minWidth || 15;
        if (columnWidth + delta > parseInt(minWidth)) {
            const columnResizeMode = this.columnResizeMode();
            if (columnResizeMode === 'fit') {
                let nextColumn = column.nextElementSibling;
                while (!nextColumn.offsetParent) {
                    nextColumn = nextColumn.nextElementSibling;
                }
                if (nextColumn) {
                    let nextColumnWidth = nextColumn.offsetWidth - delta;
                    let nextColumnMinWidth = nextColumn.style.minWidth || 15;
                    if (newColumnWidth > 15 && nextColumnWidth > parseInt(nextColumnMinWidth)) {
                        if (this.scrollable()) {
                            let scrollableView = this.findParentScrollableView(column);
                            let scrollableBodyTable = findSingle(scrollableView, '[data-pc-section="scrollablebody"] table') || findSingle(scrollableView, '[data-pc-name="virtualscroller"] table');
                            let scrollableHeaderTable = findSingle(scrollableView, '[data-pc-section="scrollableheadertable"]');
                            let scrollableFooterTable = findSingle(scrollableView, '[data-pc-section="scrollablefootertable"]');
                            let resizeColumnIndex = getIndex(column);
                            this.resizeColGroup(scrollableHeaderTable, resizeColumnIndex, newColumnWidth, nextColumnWidth);
                            this.resizeColGroup(scrollableBodyTable, resizeColumnIndex, newColumnWidth, nextColumnWidth);
                            this.resizeColGroup(scrollableFooterTable, resizeColumnIndex, newColumnWidth, nextColumnWidth);
                        }
                        else {
                            column.style.width = newColumnWidth + 'px';
                            if (nextColumn) {
                                nextColumn.style.width = nextColumnWidth + 'px';
                            }
                        }
                    }
                }
            }
            else if (columnResizeMode === 'expand') {
                if (this.scrollable()) {
                    let scrollableView = this.findParentScrollableView(column);
                    let scrollableBody = findSingle(scrollableView, '[data-pc-section="scrollablebody"]') || findSingle(scrollableView, '[data-pc-name="virtualscroller"]');
                    let scrollableHeader = findSingle(scrollableView, '[data-pc-section="scrollableheader"]');
                    let scrollableFooter = findSingle(scrollableView, '[data-pc-section="scrollablefooter"]');
                    let scrollableBodyTable = findSingle(scrollableView, '[data-pc-section="scrollablebody"] table') || findSingle(scrollableView, '[data-pc-name="virtualscroller"] table');
                    let scrollableHeaderTable = findSingle(scrollableView, '[data-pc-section="scrollableheadertable"]');
                    let scrollableFooterTable = findSingle(scrollableView, '[data-pc-section="scrollablefootertable"]');
                    scrollableBodyTable.style.width = scrollableBodyTable.offsetWidth + delta + 'px';
                    scrollableHeaderTable.style.width = scrollableHeaderTable.offsetWidth + delta + 'px';
                    if (scrollableFooterTable) {
                        scrollableFooterTable.style.width = scrollableFooterTable.offsetWidth + delta + 'px';
                    }
                    let resizeColumnIndex = getIndex(column);
                    const scrollableBodyTableWidth = column ? scrollableBodyTable.offsetWidth + delta : newColumnWidth;
                    const scrollableHeaderTableWidth = column ? scrollableHeaderTable.offsetWidth + delta : newColumnWidth;
                    const isContainerInViewport = this.el?.nativeElement.offsetWidth >= scrollableBodyTableWidth;
                    let setWidth = (container, table, width, isContainerInViewport) => {
                        if (container && table) {
                            container.style.width = isContainerInViewport ? width + calculateScrollbarWidth(scrollableBody) + 'px' : 'auto';
                            table.style.width = width + 'px';
                        }
                    };
                    setWidth(scrollableBody, scrollableBodyTable, scrollableBodyTableWidth, isContainerInViewport);
                    setWidth(scrollableHeader, scrollableHeaderTable, scrollableHeaderTableWidth, isContainerInViewport);
                    setWidth(scrollableFooter, scrollableFooterTable, scrollableHeaderTableWidth, isContainerInViewport);
                    this.resizeColGroup(scrollableHeaderTable, resizeColumnIndex, newColumnWidth, null);
                    this.resizeColGroup(scrollableBodyTable, resizeColumnIndex, newColumnWidth, null);
                    this.resizeColGroup(scrollableFooterTable, resizeColumnIndex, newColumnWidth, null);
                }
                else {
                    const tableViewChild = this.tableViewChild();
                    this.tableViewChild().nativeElement.style.width = tableViewChild?.nativeElement.offsetWidth + delta + 'px';
                    column.style.width = newColumnWidth + 'px';
                    let containerWidth = tableViewChild?.nativeElement.style.width;
                    this.el.nativeElement.style.width = containerWidth + 'px';
                }
            }
            this.onColResize.emit({
                element: column,
                delta: delta
            });
        }
        this.resizeHelperViewChild().nativeElement.style.display = 'none';
        this.el.nativeElement.removeAttribute('data-p-unselectable-text');
        !this.$unstyled() && (this.el.nativeElement.style['user-select'] = '');
    }
    findParentScrollableView(column) {
        if (column) {
            let parent = column.parentElement;
            while (parent && !findSingle(parent, '[data-pc-section="scrollableview"]')) {
                parent = parent.parentElement;
            }
            return parent;
        }
        else {
            return null;
        }
    }
    resizeColGroup(table, resizeColumnIndex, newColumnWidth, nextColumnWidth) {
        if (table) {
            let colGroup = table.children[0].nodeName === 'COLGROUP' ? table.children[0] : null;
            if (colGroup) {
                let col = colGroup.children[resizeColumnIndex];
                let nextCol = col.nextElementSibling;
                col.style.width = newColumnWidth + 'px';
                if (nextCol && nextColumnWidth) {
                    nextCol.style.width = nextColumnWidth + 'px';
                }
            }
            else {
                throw 'Scrollable tables require a colgroup to support resizable columns';
            }
        }
    }
    onColumnDragStart(event, columnElement) {
        this.reorderIconWidth = getHiddenElementOuterWidth(this.reorderIndicatorUpViewChild()?.nativeElement);
        this.reorderIconHeight = getHiddenElementOuterHeight(this.reorderIndicatorDownViewChild()?.nativeElement);
        this.draggedColumn = columnElement;
        event.dataTransfer.setData('text', 'b'); // For firefox
    }
    onColumnDragEnter(event, dropHeader) {
        if (this.reorderableColumns() && this.draggedColumn && dropHeader) {
            event.preventDefault();
            let containerOffset = getOffset(this.el?.nativeElement);
            let dropHeaderOffset = getOffset(dropHeader);
            if (this.draggedColumn != dropHeader) {
                let targetLeft = dropHeaderOffset.left - containerOffset.left;
                let columnCenter = dropHeaderOffset.left + dropHeader.offsetWidth / 2;
                this.reorderIndicatorUpViewChild().nativeElement.style.top = dropHeaderOffset.top - containerOffset.top - (this.reorderIconHeight - 1) + 'px';
                this.reorderIndicatorDownViewChild().nativeElement.style.top = dropHeaderOffset.top - containerOffset.top + dropHeader.offsetHeight + 'px';
                if (event.pageX > columnCenter) {
                    this.reorderIndicatorUpViewChild().nativeElement.style.left = targetLeft + dropHeader.offsetWidth - Math.ceil(this.reorderIconWidth / 2) + 'px';
                    this.reorderIndicatorDownViewChild().nativeElement.style.left = targetLeft + dropHeader.offsetWidth - Math.ceil(this.reorderIconWidth / 2) + 'px';
                    this.dropPosition = 1;
                }
                else {
                    this.reorderIndicatorUpViewChild().nativeElement.style.left = targetLeft - Math.ceil(this.reorderIconWidth / 2) + 'px';
                    this.reorderIndicatorDownViewChild().nativeElement.style.left = targetLeft - Math.ceil(this.reorderIconWidth / 2) + 'px';
                    this.dropPosition = -1;
                }
                this.reorderIndicatorUpViewChild().nativeElement.style.display = 'block';
                this.reorderIndicatorDownViewChild().nativeElement.style.display = 'block';
            }
            else {
                event.dataTransfer.dropEffect = 'none';
            }
        }
    }
    onColumnDragLeave(event) {
        if (this.reorderableColumns() && this.draggedColumn) {
            event.preventDefault();
            this.reorderIndicatorUpViewChild().nativeElement.style.display = 'none';
            this.reorderIndicatorDownViewChild().nativeElement.style.display = 'none';
        }
    }
    onColumnDrop(event, dropColumn) {
        event.preventDefault();
        if (this.draggedColumn) {
            let dragIndex = DomHandler.indexWithinGroup(this.draggedColumn, 'ttreorderablecolumn');
            let dropIndex = DomHandler.indexWithinGroup(dropColumn, 'ttreorderablecolumn');
            let allowDrop = dragIndex != dropIndex;
            if (allowDrop && ((dropIndex - dragIndex == 1 && this.dropPosition === -1) || (dragIndex - dropIndex == 1 && this.dropPosition === 1))) {
                allowDrop = false;
            }
            if (allowDrop && dropIndex < dragIndex && this.dropPosition === 1) {
                dropIndex = dropIndex + 1;
            }
            if (allowDrop && dropIndex > dragIndex && this.dropPosition === -1) {
                dropIndex = dropIndex - 1;
            }
            if (allowDrop) {
                const columns = this.columns();
                reorderArray(columns, dragIndex, dropIndex);
                this.onColReorder.emit({
                    dragIndex: dragIndex,
                    dropIndex: dropIndex,
                    columns: columns
                });
            }
            this.reorderIndicatorUpViewChild().nativeElement.style.display = 'none';
            this.reorderIndicatorDownViewChild().nativeElement.style.display = 'none';
            this.draggedColumn.draggable = false;
            this.draggedColumn = null;
            this.dropPosition = null;
        }
    }
    handleRowClick(event) {
        let targetNode = event.originalEvent.target.nodeName;
        if (targetNode == 'INPUT' || targetNode == 'BUTTON' || targetNode == 'A' || isClickable(event.originalEvent.target)) {
            return;
        }
        const selectionMode = this.selectionMode();
        if (selectionMode) {
            this.preventSelectionSetterPropagation = true;
            let rowNode = event.rowNode;
            let selected = this.isSelected(rowNode.node);
            let metaSelection = this.rowTouched ? false : this.metaKeySelection();
            const dataKey = this.dataKey();
            let dataKeyValue = dataKey ? String(resolveFieldData(rowNode.node.data, dataKey)) : null;
            if (metaSelection) {
                let keyboardEvent = event.originalEvent;
                let metaKey = keyboardEvent.metaKey || keyboardEvent.ctrlKey;
                if (selected && metaKey) {
                    if (this.isSingleSelectionMode()) {
                        this._selection = null;
                        this.selectedKeys = {};
                        this.selectionChange.emit(null);
                    }
                    else {
                        let selectionIndex = this.findIndexInSelection(rowNode.node);
                        this._selection = this._selection.filter((val, i) => i != selectionIndex);
                        this.selectionChange.emit(this._selection);
                        if (dataKeyValue) {
                            delete this.selectedKeys[dataKeyValue];
                        }
                    }
                    this.onNodeUnselect.emit({
                        originalEvent: event.originalEvent,
                        node: rowNode.node,
                        type: 'row'
                    });
                }
                else {
                    if (this.isSingleSelectionMode()) {
                        this._selection = rowNode.node;
                        this.selectionChange.emit(rowNode.node);
                        if (dataKeyValue) {
                            this.selectedKeys = {};
                            this.selectedKeys[dataKeyValue] = 1;
                        }
                    }
                    else if (this.isMultipleSelectionMode()) {
                        if (metaKey) {
                            this._selection = this._selection || [];
                        }
                        else {
                            this._selection = [];
                            this.selectedKeys = {};
                        }
                        this._selection = [...this._selection, rowNode.node];
                        this.selectionChange.emit(this._selection);
                        if (dataKeyValue) {
                            this.selectedKeys[dataKeyValue] = 1;
                        }
                    }
                    this.onNodeSelect.emit({
                        originalEvent: event.originalEvent,
                        node: rowNode.node,
                        type: 'row',
                        index: event.rowIndex
                    });
                }
            }
            else {
                if (selectionMode === 'single') {
                    if (selected) {
                        this._selection = null;
                        this.selectedKeys = {};
                        this.selectionChange.emit(this._selection);
                        this.onNodeUnselect.emit({
                            originalEvent: event.originalEvent,
                            node: rowNode.node,
                            type: 'row'
                        });
                    }
                    else {
                        this._selection = rowNode.node;
                        this.selectionChange.emit(this._selection);
                        this.onNodeSelect.emit({
                            originalEvent: event.originalEvent,
                            node: rowNode.node,
                            type: 'row',
                            index: event.rowIndex
                        });
                        if (dataKeyValue) {
                            this.selectedKeys = {};
                            this.selectedKeys[dataKeyValue] = 1;
                        }
                    }
                }
                else if (selectionMode === 'multiple') {
                    if (selected) {
                        let selectionIndex = this.findIndexInSelection(rowNode.node);
                        this._selection = this._selection.filter((val, i) => i != selectionIndex);
                        this.selectionChange.emit(this._selection);
                        this.onNodeUnselect.emit({
                            originalEvent: event.originalEvent,
                            node: rowNode.node,
                            type: 'row'
                        });
                        if (dataKeyValue) {
                            delete this.selectedKeys[dataKeyValue];
                        }
                    }
                    else {
                        this._selection = this._selection ? [...this._selection, rowNode.node] : [rowNode.node];
                        this.selectionChange.emit(this._selection);
                        this.onNodeSelect.emit({
                            originalEvent: event.originalEvent,
                            node: rowNode.node,
                            type: 'row',
                            index: event.rowIndex
                        });
                        if (dataKeyValue) {
                            this.selectedKeys[dataKeyValue] = 1;
                        }
                    }
                }
            }
            this.tableService.onSelectionChange();
        }
        this.rowTouched = false;
    }
    handleRowTouchEnd() {
        this.rowTouched = true;
    }
    handleRowRightClick(event) {
        if (this.contextMenu()) {
            const node = event.rowNode.node;
            const showContextMenu = () => {
                this.contextMenu().show(event.originalEvent);
                this.contextMenu().hideCallback = () => {
                    this._contextMenuSelection = null;
                    this.contextMenuSelectionChange.emit(null);
                    this.tableService.onContextMenu(null);
                };
            };
            const contextMenuSelectionMode = this.contextMenuSelectionMode();
            if (contextMenuSelectionMode === 'separate') {
                this._contextMenuSelection = node;
                this.contextMenuSelectionChange.emit(node);
                this.tableService.onContextMenu(node);
                showContextMenu();
                this.onContextMenuSelect.emit({ originalEvent: event.originalEvent, node: node });
            }
            else if (contextMenuSelectionMode === 'joint') {
                this.preventSelectionSetterPropagation = true;
                let selected = this.isSelected(node);
                const dataKey = this.dataKey();
                let dataKeyValue = dataKey ? String(resolveFieldData(node.data, dataKey)) : null;
                if (!selected) {
                    if (this.isSingleSelectionMode()) {
                        this._selection = node;
                        this.selectionChange.emit(node);
                    }
                    else if (this.isMultipleSelectionMode()) {
                        this._selection = [node];
                        this.selectionChange.emit(this._selection);
                    }
                    if (dataKeyValue) {
                        this.selectedKeys[dataKeyValue] = 1;
                    }
                }
                this._contextMenuSelection = node;
                this.contextMenuSelectionChange.emit(node);
                this.tableService.onContextMenu(node);
                showContextMenu();
                this.onContextMenuSelect.emit({ originalEvent: event.originalEvent, node: node });
            }
        }
    }
    toggleNodeWithCheckbox(event) {
        // legacy selection support, will be removed in v18
        this._selection = this._selection || [];
        this.preventSelectionSetterPropagation = true;
        let node = event.rowNode.node;
        let selected = this.isSelected(node);
        if (selected) {
            this.propagateSelectionDown(node, false);
            if (event.rowNode.parent) {
                this.propagateSelectionUp(node.parent, false);
            }
            this.selectionChange.emit(this._selection);
            this.onNodeUnselect.emit({ originalEvent: event, node: node });
        }
        else {
            this.propagateSelectionDown(node, true);
            if (event.rowNode.parent) {
                this.propagateSelectionUp(node.parent, true);
            }
            this.selectionChange.emit(this._selection);
            this.onNodeSelect.emit({ originalEvent: event, node: node });
        }
        this.tableService.onSelectionChange();
    }
    toggleNodesWithCheckbox(event, check) {
        // legacy selection support, will be removed in v18
        let data = this.filteredNodes || this._value;
        this._selection = check && data ? data.slice() : [];
        this.toggleAll(check);
        if (!check) {
            this._selection = [];
            this.selectedKeys = {};
        }
        this.preventSelectionSetterPropagation = true;
        this.selectionChange.emit(this._selection);
        this.tableService.onSelectionChange();
        this.onHeaderCheckboxToggle.emit({ originalEvent: event, checked: check });
    }
    toggleAll(checked) {
        let data = this.filteredNodes || this._value;
        if (!this._selectionKeys) {
            if (data && data.length) {
                for (let node of data) {
                    this.propagateSelectionDown(node, checked);
                }
            }
        }
        else {
            // legacy selection support, will be removed in v18
            if (data && data.length) {
                for (let node of data) {
                    this.propagateDown(node, checked);
                }
                this.selectionKeysChange.emit(this._selectionKeys);
            }
        }
    }
    propagateSelectionUp(node, select) {
        // legacy selection support, will be removed in v18
        if (node.children && node.children.length) {
            let selectedChildCount = 0;
            let childPartialSelected = false;
            const dataKey = this.dataKey();
            let dataKeyValue = dataKey ? String(resolveFieldData(node.data, dataKey)) : null;
            for (let child of node.children) {
                if (this.isSelected(child))
                    selectedChildCount++;
                else if (child.partialSelected)
                    childPartialSelected = true;
            }
            if (select && selectedChildCount == node.children.length) {
                this._selection = [...(this._selection || []), node];
                node.partialSelected = false;
                if (dataKeyValue) {
                    this.selectedKeys[dataKeyValue] = 1;
                }
            }
            else {
                if (!select) {
                    let index = this.findIndexInSelection(node);
                    if (index >= 0) {
                        this._selection = this._selection.filter((val, i) => i != index);
                        if (dataKeyValue) {
                            delete this.selectedKeys[dataKeyValue];
                        }
                    }
                }
                if (childPartialSelected || (selectedChildCount > 0 && selectedChildCount != node.children.length))
                    node.partialSelected = true;
                else
                    node.partialSelected = false;
            }
        }
        let parent = node.parent;
        node.checked = select;
        if (parent) {
            this.propagateSelectionUp(parent, select);
        }
    }
    propagateSelectionDown(node, select) {
        // legacy selection support, will be removed in v18
        let index = this.findIndexInSelection(node);
        const dataKey = this.dataKey();
        let dataKeyValue = dataKey ? String(resolveFieldData(node.data, dataKey)) : null;
        if (select && index == -1) {
            this._selection = [...(this._selection || []), node];
            if (dataKeyValue) {
                this.selectedKeys[dataKeyValue] = 1;
            }
        }
        else if (!select && index > -1) {
            this._selection = this._selection.filter((val, i) => i != index);
            if (dataKeyValue) {
                delete this.selectedKeys[dataKeyValue];
            }
        }
        node.partialSelected = false;
        node.checked = select;
        if (node.children && node.children.length) {
            for (let child of node.children) {
                this.propagateSelectionDown(child, select);
            }
        }
    }
    isSelected(node) {
        // legacy selection support, will be removed in v18
        if (node && this._selection) {
            const dataKey = this.dataKey();
            if (dataKey) {
                if (Object.prototype.hasOwnProperty.call(node, 'checked')) {
                    return node['checked'];
                }
                else {
                    return this.selectedKeys[resolveFieldData(node.data, dataKey)] !== undefined;
                }
            }
            else {
                if (Array.isArray(this._selection))
                    return this.findIndexInSelection(node) > -1;
                else
                    return this.equals(node, this._selection);
            }
        }
        return false;
    }
    isNodeSelected(node) {
        return this.selectionMode() && this._selectionKeys ? this._selectionKeys[this.nodeKey(node)]?.checked === true : false;
    }
    isNodePartialSelected(node) {
        return this.selectionMode() && this._selectionKeys ? this._selectionKeys[this.nodeKey(node)]?.partialChecked === true : false;
    }
    nodeKey(node) {
        const dataKey = this.dataKey();
        return resolveFieldData(node, dataKey) || resolveFieldData(node?.data, dataKey);
    }
    toggleCheckbox(event) {
        let { rowNode, check, originalEvent } = event;
        let node = rowNode.node;
        if (this._selectionKeys) {
            this.propagateDown(node, check);
            if (node.parent) {
                this.propagateUp(node.parent, check);
            }
            this.selectionKeysChange.emit(this._selectionKeys);
        }
        else {
            this.toggleNodeWithCheckbox({ originalEvent, rowNode });
        }
        this.tableService.onSelectionChange();
    }
    propagateDown(node, check) {
        if (check) {
            this._selectionKeys[this.nodeKey(node)] = { checked: true, partialChecked: false };
        }
        else {
            delete this._selectionKeys[this.nodeKey(node)];
        }
        if (node.children && node.children.length) {
            for (let child of node.children) {
                this.propagateDown(child, check);
            }
        }
    }
    propagateUp(node, check) {
        let checkedChildCount = 0;
        let childPartialSelected = false;
        for (let child of node.children) {
            if (this._selectionKeys[this.nodeKey(child)] && this._selectionKeys[this.nodeKey(child)].checked)
                checkedChildCount++;
            else if (this._selectionKeys[this.nodeKey(child)] && this._selectionKeys[this.nodeKey(child)].partialChecked)
                childPartialSelected = true;
        }
        if (check && checkedChildCount === node.children.length) {
            this._selectionKeys[this.nodeKey(node)] = { checked: true, partialChecked: false };
        }
        else {
            if (!check) {
                delete this._selectionKeys[this.nodeKey(node)];
            }
            if (childPartialSelected || (checkedChildCount > 0 && checkedChildCount !== node.children.length))
                this._selectionKeys[this.nodeKey(node)] = { checked: false, partialChecked: true };
            else
                this._selectionKeys[this.nodeKey(node)] = { checked: false, partialChecked: false };
        }
        let parent = node.parent;
        if (parent) {
            this.propagateUp(parent, check);
        }
    }
    findIndexInSelection(node) {
        let index = -1;
        if (this._selection && this._selection.length) {
            for (let i = 0; i < this._selection.length; i++) {
                if (this.equals(node, this._selection[i])) {
                    index = i;
                    break;
                }
            }
        }
        return index;
    }
    isSingleSelectionMode() {
        return this.selectionMode() === 'single';
    }
    isMultipleSelectionMode() {
        return this.selectionMode() === 'multiple';
    }
    equals(node1, node2) {
        return this.compareSelectionBy() === 'equals' ? equals(node1, node2) : equals(node1.data, node2.data, this.dataKey());
    }
    filter(value, field, matchMode) {
        if (this.filterTimeout) {
            clearTimeout(this.filterTimeout);
        }
        const filters = this._filters;
        if (!this.isFilterBlank(value)) {
            this._filters[field] = { value: value, matchMode: matchMode };
        }
        else if (filters[field]) {
            delete filters[field];
        }
        this.filterTimeout = setTimeout(() => {
            this._filter();
            this.filterTimeout = null;
        }, this.filterDelay());
    }
    filterGlobal(value, matchMode) {
        this.filter(value, 'global', matchMode);
    }
    isFilterBlank(filter) {
        if (filter !== null && filter !== undefined) {
            if ((typeof filter === 'string' && filter.trim().length == 0) || (Array.isArray(filter) && filter.length == 0))
                return true;
            else
                return false;
        }
        return true;
    }
    _filter() {
        if (this.lazy()) {
            this.onLazyLoad.emit(this.createLazyLoadMetadata());
        }
        else {
            if (!this._value) {
                return;
            }
            if (!this.hasFilter()) {
                this.filteredNodes = null;
                if (this.paginator()) {
                    this._totalRecords = this._value ? this._value.length : 0;
                }
            }
            else {
                let globalFilterFieldsArray;
                const filters = this._filters;
                if (filters['global']) {
                    const columns = this.columns();
                    const globalFilterFields = this.globalFilterFields();
                    if (!columns && !globalFilterFields)
                        throw new Error('Global filtering requires dynamic columns or globalFilterFields to be defined.');
                    else
                        globalFilterFieldsArray = globalFilterFields || columns;
                }
                this.filteredNodes = [];
                const isStrictMode = this.filterMode() === 'strict';
                let isValueChanged = false;
                for (let node of this._value) {
                    let copyNode = { ...node };
                    let localMatch = true;
                    let globalMatch = false;
                    let paramsWithoutNode;
                    for (let prop in filters) {
                        if (Object.prototype.hasOwnProperty.call(filters, prop) && prop !== 'global') {
                            let filterMeta = filters[prop];
                            let filterField = prop;
                            let filterValue = filterMeta.value;
                            let filterMatchMode = filterMeta.matchMode || 'startsWith';
                            let filterConstraint = this.filterService.filters[filterMatchMode];
                            paramsWithoutNode = { filterField, filterValue, filterConstraint, isStrictMode };
                            if ((isStrictMode && !(this.findFilteredNodes(copyNode, paramsWithoutNode) || this.isFilterMatched(copyNode, paramsWithoutNode))) ||
                                (!isStrictMode && !(this.isFilterMatched(copyNode, paramsWithoutNode) || this.findFilteredNodes(copyNode, paramsWithoutNode)))) {
                                localMatch = false;
                            }
                            if (!localMatch) {
                                break;
                            }
                        }
                    }
                    if (filters['global'] && !globalMatch && globalFilterFieldsArray) {
                        let copyNodeForGlobal = { ...copyNode };
                        let filterField = undefined;
                        let filterValue = filters['global'].value;
                        let filterConstraint = this.filterService.filters[filters['global'].matchMode];
                        paramsWithoutNode = {
                            filterField,
                            filterValue,
                            filterConstraint,
                            isStrictMode,
                            globalFilterFieldsArray
                        };
                        if ((isStrictMode && (this.findFilteredNodes(copyNodeForGlobal, paramsWithoutNode) || this.isFilterMatched(copyNodeForGlobal, paramsWithoutNode))) ||
                            (!isStrictMode && (this.isFilterMatched(copyNodeForGlobal, paramsWithoutNode) || this.findFilteredNodes(copyNodeForGlobal, paramsWithoutNode)))) {
                            globalMatch = true;
                            copyNode = copyNodeForGlobal;
                        }
                    }
                    let matches = localMatch;
                    if (filters['global']) {
                        matches = localMatch && globalMatch;
                    }
                    if (matches) {
                        this.filteredNodes.push(copyNode);
                    }
                    isValueChanged = isValueChanged || !localMatch || globalMatch || (localMatch && this.filteredNodes.length > 0) || (!globalMatch && this.filteredNodes.length === 0);
                }
                if (!isValueChanged) {
                    this.filteredNodes = null;
                }
                if (this.paginator()) {
                    this._totalRecords = this.filteredNodes ? this.filteredNodes.length : this._value ? this._value.length : 0;
                }
            }
            this.cd.markForCheck();
        }
        this._first = 0;
        const filteredValue = this.filteredNodes || this._value;
        this.onFilter.emit({
            filters: this._filters,
            filteredValue: filteredValue
        });
        this.tableService.onUIUpdate(filteredValue);
        this.updateSerializedValue();
        if (this.scrollable()) {
            this.resetScrollTop();
        }
    }
    findFilteredNodes(node, paramsWithoutNode) {
        if (node) {
            let matched = false;
            if (node.children) {
                let childNodes = [...node.children];
                node.children = [];
                for (let childNode of childNodes) {
                    let copyChildNode = { ...childNode };
                    if (this.isFilterMatched(copyChildNode, paramsWithoutNode)) {
                        matched = true;
                        node.children.push(copyChildNode);
                    }
                }
            }
            if (matched) {
                return true;
            }
        }
    }
    isFilterMatched(node, filterOptions) {
        let { filterField, filterValue, filterConstraint, isStrictMode, globalFilterFieldsArray } = filterOptions;
        let matched = false;
        const isMatched = (field) => filterConstraint(resolveFieldData(node.data, field), filterValue, this.filterLocale());
        matched = globalFilterFieldsArray?.length ? globalFilterFieldsArray.some((globalFilterField) => isMatched(globalFilterField.field || globalFilterField)) : isMatched(filterField);
        if (!matched || (isStrictMode && !this.isNodeLeaf(node))) {
            matched =
                this.findFilteredNodes(node, {
                    filterField,
                    filterValue,
                    filterConstraint,
                    isStrictMode,
                    globalFilterFieldsArray
                }) || matched;
        }
        return matched;
    }
    isNodeLeaf(node) {
        return node.leaf === false ? false : !(node.children && node.children.length);
    }
    hasFilter() {
        let empty = true;
        for (let prop in this._filters) {
            if (Object.prototype.hasOwnProperty.call(this._filters, prop)) {
                empty = false;
                break;
            }
        }
        return !empty;
    }
    /**
     * Clears the sort and paginator state.
     * @group Method
     */
    reset() {
        this._sortField = null;
        this._sortOrder = 1;
        this._multiSortMeta = null;
        this.tableService.onSort(null);
        this.filteredNodes = null;
        this._filters = {};
        this._first = 0;
        if (this.lazy()) {
            this.onLazyLoad.emit(this.createLazyLoadMetadata());
        }
        else {
            this._totalRecords = this._value ? this._value.length : 0;
        }
    }
    updateEditingCell(cell, data, field) {
        this.editingCell = cell;
        this.editingCellData = data;
        this.editingCellField = field;
        this.bindDocumentEditListener();
    }
    isEditingCellValid() {
        return this.editingCell && find(this.editingCell, '.ng-invalid.ng-dirty').length === 0;
    }
    bindDocumentEditListener() {
        if (!this.documentEditListener) {
            this.documentEditListener = this.renderer.listen(this.document, 'click', () => {
                if (this.editingCell && !this.editingCellClick && this.isEditingCellValid()) {
                    !this.$unstyled() && removeClass(this.editingCell, 'p-cell-editing');
                    this.editingCell = null;
                    this.onEditComplete.emit({ field: this.editingCellField, data: this.editingCellData });
                    this.editingCellField = null;
                    this.editingCellData = null;
                    this.unbindDocumentEditListener();
                }
                this.editingCellClick = false;
            });
        }
    }
    unbindDocumentEditListener() {
        if (this.documentEditListener) {
            this.documentEditListener();
            this.documentEditListener = null;
        }
    }
    onDestroy() {
        this.unbindDocumentEditListener();
        this.editingCell = null;
        this.editingCellField = null;
        this.editingCellData = null;
        this.initialized = null;
    }
    get dataP() {
        return this.cn({
            scrollable: this.scrollable(),
            'flex-scrollable': this.scrollable() && this.scrollHeight() === 'flex',
            loading: this.loading(),
            empty: this.isEmpty()
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeTable, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: TreeTable, isStandalone: true, selector: "p-treeTable, p-treetable, p-tree-table", inputs: { columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, tableStyle: { classPropertyName: "tableStyle", publicName: "tableStyle", isSignal: true, isRequired: false, transformFunction: null }, tableStyleClass: { classPropertyName: "tableStyleClass", publicName: "tableStyleClass", isSignal: true, isRequired: false, transformFunction: null }, autoLayout: { classPropertyName: "autoLayout", publicName: "autoLayout", isSignal: true, isRequired: false, transformFunction: null }, lazy: { classPropertyName: "lazy", publicName: "lazy", isSignal: true, isRequired: false, transformFunction: null }, lazyLoadOnInit: { classPropertyName: "lazyLoadOnInit", publicName: "lazyLoadOnInit", isSignal: true, isRequired: false, transformFunction: null }, paginator: { classPropertyName: "paginator", publicName: "paginator", isSignal: true, isRequired: false, transformFunction: null }, rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: false, transformFunction: null }, first: { classPropertyName: "first", publicName: "first", isSignal: true, isRequired: false, transformFunction: null }, pageLinks: { classPropertyName: "pageLinks", publicName: "pageLinks", isSignal: true, isRequired: false, transformFunction: null }, rowsPerPageOptions: { classPropertyName: "rowsPerPageOptions", publicName: "rowsPerPageOptions", isSignal: true, isRequired: false, transformFunction: null }, alwaysShowPaginator: { classPropertyName: "alwaysShowPaginator", publicName: "alwaysShowPaginator", isSignal: true, isRequired: false, transformFunction: null }, paginatorPosition: { classPropertyName: "paginatorPosition", publicName: "paginatorPosition", isSignal: true, isRequired: false, transformFunction: null }, paginatorStyleClass: { classPropertyName: "paginatorStyleClass", publicName: "paginatorStyleClass", isSignal: true, isRequired: false, transformFunction: null }, paginatorDropdownAppendTo: { classPropertyName: "paginatorDropdownAppendTo", publicName: "paginatorDropdownAppendTo", isSignal: true, isRequired: false, transformFunction: null }, currentPageReportTemplate: { classPropertyName: "currentPageReportTemplate", publicName: "currentPageReportTemplate", isSignal: true, isRequired: false, transformFunction: null }, showCurrentPageReport: { classPropertyName: "showCurrentPageReport", publicName: "showCurrentPageReport", isSignal: true, isRequired: false, transformFunction: null }, showJumpToPageDropdown: { classPropertyName: "showJumpToPageDropdown", publicName: "showJumpToPageDropdown", isSignal: true, isRequired: false, transformFunction: null }, showFirstLastIcon: { classPropertyName: "showFirstLastIcon", publicName: "showFirstLastIcon", isSignal: true, isRequired: false, transformFunction: null }, showPageLinks: { classPropertyName: "showPageLinks", publicName: "showPageLinks", isSignal: true, isRequired: false, transformFunction: null }, defaultSortOrder: { classPropertyName: "defaultSortOrder", publicName: "defaultSortOrder", isSignal: true, isRequired: false, transformFunction: null }, sortMode: { classPropertyName: "sortMode", publicName: "sortMode", isSignal: true, isRequired: false, transformFunction: null }, resetPageOnSort: { classPropertyName: "resetPageOnSort", publicName: "resetPageOnSort", isSignal: true, isRequired: false, transformFunction: null }, customSort: { classPropertyName: "customSort", publicName: "customSort", isSignal: true, isRequired: false, transformFunction: null }, selectionMode: { classPropertyName: "selectionMode", publicName: "selectionMode", isSignal: true, isRequired: false, transformFunction: null }, contextMenuSelection: { classPropertyName: "contextMenuSelection", publicName: "contextMenuSelection", isSignal: true, isRequired: false, transformFunction: null }, contextMenuSelectionMode: { classPropertyName: "contextMenuSelectionMode", publicName: "contextMenuSelectionMode", isSignal: true, isRequired: false, transformFunction: null }, dataKey: { classPropertyName: "dataKey", publicName: "dataKey", isSignal: true, isRequired: false, transformFunction: null }, metaKeySelection: { classPropertyName: "metaKeySelection", publicName: "metaKeySelection", isSignal: true, isRequired: false, transformFunction: null }, compareSelectionBy: { classPropertyName: "compareSelectionBy", publicName: "compareSelectionBy", isSignal: true, isRequired: false, transformFunction: null }, rowHover: { classPropertyName: "rowHover", publicName: "rowHover", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, loadingIcon: { classPropertyName: "loadingIcon", publicName: "loadingIcon", isSignal: true, isRequired: false, transformFunction: null }, showLoader: { classPropertyName: "showLoader", publicName: "showLoader", isSignal: true, isRequired: false, transformFunction: null }, scrollable: { classPropertyName: "scrollable", publicName: "scrollable", isSignal: true, isRequired: false, transformFunction: null }, scrollHeight: { classPropertyName: "scrollHeight", publicName: "scrollHeight", isSignal: true, isRequired: false, transformFunction: null }, virtualScroll: { classPropertyName: "virtualScroll", publicName: "virtualScroll", isSignal: true, isRequired: false, transformFunction: null }, virtualScrollItemSize: { classPropertyName: "virtualScrollItemSize", publicName: "virtualScrollItemSize", isSignal: true, isRequired: false, transformFunction: null }, virtualScrollOptions: { classPropertyName: "virtualScrollOptions", publicName: "virtualScrollOptions", isSignal: true, isRequired: false, transformFunction: null }, virtualScrollDelay: { classPropertyName: "virtualScrollDelay", publicName: "virtualScrollDelay", isSignal: true, isRequired: false, transformFunction: null }, frozenWidth: { classPropertyName: "frozenWidth", publicName: "frozenWidth", isSignal: true, isRequired: false, transformFunction: null }, frozenColumns: { classPropertyName: "frozenColumns", publicName: "frozenColumns", isSignal: true, isRequired: false, transformFunction: null }, resizableColumns: { classPropertyName: "resizableColumns", publicName: "resizableColumns", isSignal: true, isRequired: false, transformFunction: null }, columnResizeMode: { classPropertyName: "columnResizeMode", publicName: "columnResizeMode", isSignal: true, isRequired: false, transformFunction: null }, reorderableColumns: { classPropertyName: "reorderableColumns", publicName: "reorderableColumns", isSignal: true, isRequired: false, transformFunction: null }, contextMenu: { classPropertyName: "contextMenu", publicName: "contextMenu", isSignal: true, isRequired: false, transformFunction: null }, rowTrackBy: { classPropertyName: "rowTrackBy", publicName: "rowTrackBy", isSignal: true, isRequired: false, transformFunction: null }, filters: { classPropertyName: "filters", publicName: "filters", isSignal: true, isRequired: false, transformFunction: null }, globalFilterFields: { classPropertyName: "globalFilterFields", publicName: "globalFilterFields", isSignal: true, isRequired: false, transformFunction: null }, filterDelay: { classPropertyName: "filterDelay", publicName: "filterDelay", isSignal: true, isRequired: false, transformFunction: null }, filterMode: { classPropertyName: "filterMode", publicName: "filterMode", isSignal: true, isRequired: false, transformFunction: null }, filterLocale: { classPropertyName: "filterLocale", publicName: "filterLocale", isSignal: true, isRequired: false, transformFunction: null }, paginatorLocale: { classPropertyName: "paginatorLocale", publicName: "paginatorLocale", isSignal: true, isRequired: false, transformFunction: null }, totalRecords: { classPropertyName: "totalRecords", publicName: "totalRecords", isSignal: true, isRequired: false, transformFunction: null }, sortField: { classPropertyName: "sortField", publicName: "sortField", isSignal: true, isRequired: false, transformFunction: null }, sortOrder: { classPropertyName: "sortOrder", publicName: "sortOrder", isSignal: true, isRequired: false, transformFunction: null }, multiSortMeta: { classPropertyName: "multiSortMeta", publicName: "multiSortMeta", isSignal: true, isRequired: false, transformFunction: null }, selection: { classPropertyName: "selection", publicName: "selection", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, virtualRowHeight: { classPropertyName: "virtualRowHeight", publicName: "virtualRowHeight", isSignal: true, isRequired: false, transformFunction: null }, selectionKeys: { classPropertyName: "selectionKeys", publicName: "selectionKeys", isSignal: true, isRequired: false, transformFunction: null }, showGridlines: { classPropertyName: "showGridlines", publicName: "showGridlines", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectionChange: "selectionChange", contextMenuSelectionChange: "contextMenuSelectionChange", onFilter: "onFilter", onNodeExpand: "onNodeExpand", onNodeCollapse: "onNodeCollapse", onPage: "onPage", onSort: "onSort", onLazyLoad: "onLazyLoad", sortFunction: "sortFunction", onColResize: "onColResize", onColReorder: "onColReorder", onNodeSelect: "onNodeSelect", onNodeUnselect: "onNodeUnselect", onContextMenuSelect: "onContextMenuSelect", onHeaderCheckboxToggle: "onHeaderCheckboxToggle", onEditInit: "onEditInit", onEditComplete: "onEditComplete", onEditCancel: "onEditCancel", selectionKeysChange: "selectionKeysChange" }, host: { properties: { "class": "cn(cx('root'), styleClass())", "attr.data-p": "dataP", "attr.data-scrollselectors": "'.p-treetable-scrollable-body'" } }, providers: [TreeTableService, TreeTableStyle, { provide: TREETABLE_INSTANCE, useExisting: TreeTable }, { provide: PARENT_INSTANCE, useExisting: TreeTable }], queries: [{ propertyName: "_colGroupTemplate", first: true, predicate: ["colgroup"], isSignal: true }, { propertyName: "_headerTemplate", first: true, predicate: ["header"], isSignal: true }, { propertyName: "_bodyTemplate", first: true, predicate: ["body"], isSignal: true }, { propertyName: "_emptyMessageTemplate", first: true, predicate: ["emptymessage"], isSignal: true }, { propertyName: "_paginatorLeftTemplate", first: true, predicate: ["paginatorleft"], isSignal: true }, { propertyName: "_paginatorRightTemplate", first: true, predicate: ["paginatorright"], isSignal: true }, { propertyName: "_paginatorDropdownItemTemplate", first: true, predicate: ["paginatordropdownitem"], isSignal: true }, { propertyName: "_frozenHeaderTemplate", first: true, predicate: ["frozenheader"], isSignal: true }, { propertyName: "_frozenBodyTemplate", first: true, predicate: ["frozenbody"], isSignal: true }, { propertyName: "_frozenFooterTemplate", first: true, predicate: ["frozenfooter"], isSignal: true }, { propertyName: "_frozenColGroupTemplate", first: true, predicate: ["frozencolgroup"], isSignal: true }, { propertyName: "_reorderIndicatorUpIconTemplate", first: true, predicate: ["reorderindicatorupicon"], isSignal: true }, { propertyName: "_reorderIndicatorDownIconTemplate", first: true, predicate: ["reorderindicatordownicon"], isSignal: true }, { propertyName: "_togglerIconTemplate", first: true, predicate: ["togglericon"], isSignal: true }, { propertyName: "templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "_captionTemplate", first: true, predicate: ["caption"] }, { propertyName: "_footerTemplate", first: true, predicate: ["footer"] }, { propertyName: "_summaryTemplate", first: true, predicate: ["summary"] }, { propertyName: "_loadingIconTemplate", first: true, predicate: ["loadingicon"] }, { propertyName: "_sortIconTemplate", first: true, predicate: ["sorticon"] }, { propertyName: "_checkboxIconTemplate", first: true, predicate: ["checkboxicon"] }, { propertyName: "_headerCheckboxIconTemplate", first: true, predicate: ["headercheckboxicon"] }, { propertyName: "_paginatorFirstPageLinkIconTemplate", first: true, predicate: ["paginatorfirstpagelinkicon"] }, { propertyName: "_paginatorLastPageLinkIconTemplate", first: true, predicate: ["paginatorlastpagelinkicon"] }, { propertyName: "_paginatorPreviousPageLinkIconTemplate", first: true, predicate: ["paginatorpreviouspagelinkicon"] }, { propertyName: "_paginatorNextPageLinkIconTemplate", first: true, predicate: ["paginatornextpagelinkicon"] }, { propertyName: "_loaderTemplate", first: true, predicate: ["loader"] }], viewQueries: [{ propertyName: "resizeHelperViewChild", first: true, predicate: ["resizeHelper"], descendants: true, isSignal: true }, { propertyName: "reorderIndicatorUpViewChild", first: true, predicate: ["reorderIndicatorUp"], descendants: true, isSignal: true }, { propertyName: "reorderIndicatorDownViewChild", first: true, predicate: ["reorderIndicatorDown"], descendants: true, isSignal: true }, { propertyName: "tableViewChild", first: true, predicate: ["table"], descendants: true, isSignal: true }, { propertyName: "scrollableViewChild", first: true, predicate: ["scrollableView"], descendants: true, isSignal: true }, { propertyName: "scrollableFrozenViewChild", first: true, predicate: ["scrollableFrozenView"], descendants: true, isSignal: true }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        @if (loading() && showLoader()) {
            <div [pBind]="ptm('mask')" [class]="cx('mask')" animate.enter="p-overlay-mask-enter-active" animate.leave="p-overlay-mask-leave-active">
                @if (loadingIcon()) {
                    <i [class]="cn(cx('loadingIcon'), 'pi-spin' + loadingIcon())"></i>
                }
                @if (!loadingIcon()) {
                    @if (!loadingIconTemplate && !_loadingIconTemplate) {
                        <svg data-p-icon="spinner" [spin]="true" [class]="cx('loadingIcon')" />
                    }
                    @if (loadingIconTemplate || _loadingIconTemplate) {
                        <span [class]="cx('loadingIcon')">
                            <ng-template *ngTemplateOutlet="loadingIconTemplate || _loadingIconTemplate"></ng-template>
                        </span>
                    }
                }
            </div>
        }
        @if (captionTemplate || _captionTemplate) {
            <div [pBind]="ptm('header')" [class]="cx('header')">
                <ng-container *ngTemplateOutlet="captionTemplate || _captionTemplate"></ng-container>
            </div>
        }
        @if (paginator() && (paginatorPosition() === 'top' || paginatorPosition() === 'both')) {
            <p-paginator
                [pt]="ptm('pcPaginator')"
                [rows]="rows()"
                [first]="first()"
                [totalRecords]="_totalRecords"
                [pageLinkSize]="pageLinks()"
                [styleClass]="cx('pcPaginator')"
                [alwaysShow]="alwaysShowPaginator()"
                (onPageChange)="onPageChange($event)"
                [rowsPerPageOptions]="rowsPerPageOptions()"
                [templateLeft]="paginatorLeftTemplate ?? _paginatorLeftTemplate()"
                [templateRight]="paginatorRightTemplate ?? _paginatorRightTemplate()"
                [appendTo]="paginatorDropdownAppendTo()"
                [currentPageReportTemplate]="currentPageReportTemplate()"
                [showFirstLastIcon]="showFirstLastIcon()"
                [dropdownItemTemplate]="paginatorDropdownItemTemplate ?? _paginatorDropdownItemTemplate()"
                [showCurrentPageReport]="showCurrentPageReport()"
                [showJumpToPageDropdown]="showJumpToPageDropdown()"
                [showPageLinks]="showPageLinks()"
                [locale]="paginatorLocale()"
                [unstyled]="unstyled()"
            >
                @if (paginatorFirstPageLinkIconTemplate || _paginatorFirstPageLinkIconTemplate) {
                    <ng-template pTemplate="firstpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorFirstPageLinkIconTemplate || _paginatorFirstPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorPreviousPageLinkIconTemplate || _paginatorPreviousPageLinkIconTemplate) {
                    <ng-template pTemplate="previouspagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorPreviousPageLinkIconTemplate || _paginatorPreviousPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorLastPageLinkIconTemplate || _paginatorLastPageLinkIconTemplate) {
                    <ng-template pTemplate="lastpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorLastPageLinkIconTemplate || _paginatorLastPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorNextPageLinkIconTemplate || _paginatorNextPageLinkIconTemplate) {
                    <ng-template pTemplate="nextpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorNextPageLinkIconTemplate || _paginatorNextPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
            </p-paginator>
        }

        @if (!scrollable()) {
            <div [pBind]="ptm('wrapper')" [class]="cx('wrapper')">
                <table role="treegrid" [pBind]="ptm('table')" #table [ngClass]="tableStyleClass()" [ngStyle]="tableStyle()">
                    <ng-container *ngTemplateOutlet="colGroupTemplate || _colGroupTemplate(); context: { $implicit: columns() }"></ng-container>
                    <thead role="rowgroup" [class]="cx('thead')" [pBind]="ptm('thead')">
                        <ng-container *ngTemplateOutlet="headerTemplate || _headerTemplate(); context: { $implicit: columns() }"></ng-container>
                    </thead>
                    <tbody [class]="cx('tbody')" [pBind]="ptm('tbody')" role="rowgroup" [unstyled]="unstyled()" [pTreeTableBody]="columns()" [pTreeTableBodyTemplate]="bodyTemplate ?? _bodyTemplate()"></tbody>
                    <tfoot [class]="cx('tfoot')" [pBind]="ptm('tfoot')" role="rowgroup">
                        <ng-container *ngTemplateOutlet="footerTemplate || _footerTemplate; context: { $implicit: columns() }"></ng-container>
                    </tfoot>
                </table>
            </div>
        }

        @if (scrollable()) {
            <div [pBind]="ptm('scrollableWrapper')" [class]="cx('scrollableWrapper')">
                @if (frozenColumns() || frozenBodyTemplate || _frozenBodyTemplate()) {
                    <div
                        [ngClass]="[cx('scrollableView'), cx('frozenView')]"
                        #scrollableFrozenView
                        [ttScrollableView]="frozenColumns()"
                        [unstyled]="unstyled()"
                        [frozen]="true"
                        [ngStyle]="{ width: frozenWidth() }"
                        [scrollHeight]="scrollHeight()"
                        [pBind]="ptm('scrollableView')"
                    ></div>
                }
                <div
                    [class]="cx('scrollableView')"
                    [pBind]="ptm('scrollableView')"
                    #scrollableView
                    [ttScrollableView]="columns()"
                    [unstyled]="unstyled()"
                    [frozen]="false"
                    [scrollHeight]="scrollHeight()"
                    [ngStyle]="{ left: frozenWidth(), width: 'calc(100% - ' + frozenWidth() + ')' }"
                ></div>
            </div>
        }

        @if (paginator() && (paginatorPosition() === 'bottom' || paginatorPosition() === 'both')) {
            <p-paginator
                [pt]="ptm('pcPaginator')"
                [rows]="rows()"
                [first]="first()"
                [totalRecords]="_totalRecords"
                [pageLinkSize]="pageLinks()"
                [styleClass]="cx('pcPaginator')"
                [alwaysShow]="alwaysShowPaginator()"
                (onPageChange)="onPageChange($event)"
                [rowsPerPageOptions]="rowsPerPageOptions()"
                [templateLeft]="paginatorLeftTemplate ?? _paginatorLeftTemplate()"
                [templateRight]="paginatorRightTemplate ?? _paginatorRightTemplate()"
                [appendTo]="paginatorDropdownAppendTo()"
                [currentPageReportTemplate]="currentPageReportTemplate()"
                [showFirstLastIcon]="showFirstLastIcon()"
                [dropdownItemTemplate]="paginatorDropdownItemTemplate ?? _paginatorDropdownItemTemplate()"
                [showCurrentPageReport]="showCurrentPageReport()"
                [showJumpToPageDropdown]="showJumpToPageDropdown()"
                [showPageLinks]="showPageLinks()"
                [locale]="paginatorLocale()"
                [unstyled]="unstyled()"
            >
                @if (paginatorFirstPageLinkIconTemplate || _paginatorFirstPageLinkIconTemplate) {
                    <ng-template pTemplate="firstpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorFirstPageLinkIconTemplate || _paginatorFirstPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorPreviousPageLinkIconTemplate || _paginatorPreviousPageLinkIconTemplate) {
                    <ng-template pTemplate="previouspagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorPreviousPageLinkIconTemplate || _paginatorPreviousPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorLastPageLinkIconTemplate || _paginatorLastPageLinkIconTemplate) {
                    <ng-template pTemplate="lastpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorLastPageLinkIconTemplate || _paginatorLastPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorNextPageLinkIconTemplate || _paginatorNextPageLinkIconTemplate) {
                    <ng-template pTemplate="nextpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorNextPageLinkIconTemplate || _paginatorNextPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
            </p-paginator>
        }
        @if (summaryTemplate || _summaryTemplate) {
            <div [pBind]="ptm('footer')" [class]="cx('footer')">
                <ng-container *ngTemplateOutlet="summaryTemplate || _summaryTemplate"></ng-container>
            </div>
        }

        @if (resizableColumns()) {
            <div [pBind]="ptm('columnResizerHelper')" #resizeHelper [class]="cx('columnResizerHelper')" [style.display]="'none'"></div>
        }
        @if (reorderableColumns()) {
            <span [pBind]="ptm('reorderIndicatorUp')" #reorderIndicatorUp [class]="cx('reorderIndicatorUp')" [style.display]="'none'">
                @if (!reorderIndicatorUpIconTemplate && !_reorderIndicatorUpIconTemplate()) {
                    <svg data-p-icon="arrow-down" />
                }
                <ng-template *ngTemplateOutlet="reorderIndicatorUpIconTemplate || _reorderIndicatorUpIconTemplate()"></ng-template>
            </span>
        }
        @if (reorderableColumns()) {
            <span [pBind]="ptm('reorderIndicatorDown')" #reorderIndicatorDown [class]="cx('reorderIndicatorDown')" [style.display]="'none'">
                @if (!reorderIndicatorDownIconTemplate && !_reorderIndicatorDownIconTemplate()) {
                    <svg data-p-icon="arrow-up" />
                }
                <ng-template *ngTemplateOutlet="reorderIndicatorDownIconTemplate || _reorderIndicatorDownIconTemplate()"></ng-template>
            </span>
        }
    `, isInline: true, dependencies: [{ kind: "directive", type: i0.forwardRef(() => Bind), selector: "[pBind]", inputs: ["pBind"] }, { kind: "component", type: i0.forwardRef(() => SpinnerIcon), selector: "[data-p-icon=\"spinner\"]" }, { kind: "directive", type: i0.forwardRef(() => NgTemplateOutlet), selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: i0.forwardRef(() => Paginator), selector: "p-paginator", inputs: ["pageLinkSize", "styleClass", "alwaysShow", "dropdownAppendTo", "templateLeft", "templateRight", "dropdownScrollHeight", "currentPageReportTemplate", "showCurrentPageReport", "showFirstLastIcon", "totalRecords", "rows", "rowsPerPageOptions", "showJumpToPageDropdown", "showJumpToPageInput", "jumpToPageItemTemplate", "showPageLinks", "locale", "dropdownItemTemplate", "first", "appendTo"], outputs: ["rowsChange", "onPageChange"] }, { kind: "directive", type: i0.forwardRef(() => PrimeTemplate), selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "directive", type: i0.forwardRef(() => NgClass), selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i0.forwardRef(() => NgStyle), selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: i0.forwardRef(() => TTBody), selector: "[pTreeTableBody]", inputs: ["pTreeTableBody", "pTreeTableBodyTemplate", "frozen", "serializedNodes", "scrollerOptions"] }, { kind: "component", type: i0.forwardRef(() => TTScrollableView), selector: "[ttScrollableView]", inputs: ["ttScrollableView", "frozen", "scrollHeight"] }, { kind: "component", type: i0.forwardRef(() => ArrowDownIcon), selector: "[data-p-icon=\"arrow-down\"]" }, { kind: "component", type: i0.forwardRef(() => ArrowUpIcon), selector: "[data-p-icon=\"arrow-up\"]" }, { kind: "ngmodule", type: i0.forwardRef(() => TreeTableModule) }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeTable, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-treeTable, p-treetable, p-tree-table',
                    template: `
        @if (loading() && showLoader()) {
            <div [pBind]="ptm('mask')" [class]="cx('mask')" animate.enter="p-overlay-mask-enter-active" animate.leave="p-overlay-mask-leave-active">
                @if (loadingIcon()) {
                    <i [class]="cn(cx('loadingIcon'), 'pi-spin' + loadingIcon())"></i>
                }
                @if (!loadingIcon()) {
                    @if (!loadingIconTemplate && !_loadingIconTemplate) {
                        <svg data-p-icon="spinner" [spin]="true" [class]="cx('loadingIcon')" />
                    }
                    @if (loadingIconTemplate || _loadingIconTemplate) {
                        <span [class]="cx('loadingIcon')">
                            <ng-template *ngTemplateOutlet="loadingIconTemplate || _loadingIconTemplate"></ng-template>
                        </span>
                    }
                }
            </div>
        }
        @if (captionTemplate || _captionTemplate) {
            <div [pBind]="ptm('header')" [class]="cx('header')">
                <ng-container *ngTemplateOutlet="captionTemplate || _captionTemplate"></ng-container>
            </div>
        }
        @if (paginator() && (paginatorPosition() === 'top' || paginatorPosition() === 'both')) {
            <p-paginator
                [pt]="ptm('pcPaginator')"
                [rows]="rows()"
                [first]="first()"
                [totalRecords]="_totalRecords"
                [pageLinkSize]="pageLinks()"
                [styleClass]="cx('pcPaginator')"
                [alwaysShow]="alwaysShowPaginator()"
                (onPageChange)="onPageChange($event)"
                [rowsPerPageOptions]="rowsPerPageOptions()"
                [templateLeft]="paginatorLeftTemplate ?? _paginatorLeftTemplate()"
                [templateRight]="paginatorRightTemplate ?? _paginatorRightTemplate()"
                [appendTo]="paginatorDropdownAppendTo()"
                [currentPageReportTemplate]="currentPageReportTemplate()"
                [showFirstLastIcon]="showFirstLastIcon()"
                [dropdownItemTemplate]="paginatorDropdownItemTemplate ?? _paginatorDropdownItemTemplate()"
                [showCurrentPageReport]="showCurrentPageReport()"
                [showJumpToPageDropdown]="showJumpToPageDropdown()"
                [showPageLinks]="showPageLinks()"
                [locale]="paginatorLocale()"
                [unstyled]="unstyled()"
            >
                @if (paginatorFirstPageLinkIconTemplate || _paginatorFirstPageLinkIconTemplate) {
                    <ng-template pTemplate="firstpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorFirstPageLinkIconTemplate || _paginatorFirstPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorPreviousPageLinkIconTemplate || _paginatorPreviousPageLinkIconTemplate) {
                    <ng-template pTemplate="previouspagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorPreviousPageLinkIconTemplate || _paginatorPreviousPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorLastPageLinkIconTemplate || _paginatorLastPageLinkIconTemplate) {
                    <ng-template pTemplate="lastpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorLastPageLinkIconTemplate || _paginatorLastPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorNextPageLinkIconTemplate || _paginatorNextPageLinkIconTemplate) {
                    <ng-template pTemplate="nextpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorNextPageLinkIconTemplate || _paginatorNextPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
            </p-paginator>
        }

        @if (!scrollable()) {
            <div [pBind]="ptm('wrapper')" [class]="cx('wrapper')">
                <table role="treegrid" [pBind]="ptm('table')" #table [ngClass]="tableStyleClass()" [ngStyle]="tableStyle()">
                    <ng-container *ngTemplateOutlet="colGroupTemplate || _colGroupTemplate(); context: { $implicit: columns() }"></ng-container>
                    <thead role="rowgroup" [class]="cx('thead')" [pBind]="ptm('thead')">
                        <ng-container *ngTemplateOutlet="headerTemplate || _headerTemplate(); context: { $implicit: columns() }"></ng-container>
                    </thead>
                    <tbody [class]="cx('tbody')" [pBind]="ptm('tbody')" role="rowgroup" [unstyled]="unstyled()" [pTreeTableBody]="columns()" [pTreeTableBodyTemplate]="bodyTemplate ?? _bodyTemplate()"></tbody>
                    <tfoot [class]="cx('tfoot')" [pBind]="ptm('tfoot')" role="rowgroup">
                        <ng-container *ngTemplateOutlet="footerTemplate || _footerTemplate; context: { $implicit: columns() }"></ng-container>
                    </tfoot>
                </table>
            </div>
        }

        @if (scrollable()) {
            <div [pBind]="ptm('scrollableWrapper')" [class]="cx('scrollableWrapper')">
                @if (frozenColumns() || frozenBodyTemplate || _frozenBodyTemplate()) {
                    <div
                        [ngClass]="[cx('scrollableView'), cx('frozenView')]"
                        #scrollableFrozenView
                        [ttScrollableView]="frozenColumns()"
                        [unstyled]="unstyled()"
                        [frozen]="true"
                        [ngStyle]="{ width: frozenWidth() }"
                        [scrollHeight]="scrollHeight()"
                        [pBind]="ptm('scrollableView')"
                    ></div>
                }
                <div
                    [class]="cx('scrollableView')"
                    [pBind]="ptm('scrollableView')"
                    #scrollableView
                    [ttScrollableView]="columns()"
                    [unstyled]="unstyled()"
                    [frozen]="false"
                    [scrollHeight]="scrollHeight()"
                    [ngStyle]="{ left: frozenWidth(), width: 'calc(100% - ' + frozenWidth() + ')' }"
                ></div>
            </div>
        }

        @if (paginator() && (paginatorPosition() === 'bottom' || paginatorPosition() === 'both')) {
            <p-paginator
                [pt]="ptm('pcPaginator')"
                [rows]="rows()"
                [first]="first()"
                [totalRecords]="_totalRecords"
                [pageLinkSize]="pageLinks()"
                [styleClass]="cx('pcPaginator')"
                [alwaysShow]="alwaysShowPaginator()"
                (onPageChange)="onPageChange($event)"
                [rowsPerPageOptions]="rowsPerPageOptions()"
                [templateLeft]="paginatorLeftTemplate ?? _paginatorLeftTemplate()"
                [templateRight]="paginatorRightTemplate ?? _paginatorRightTemplate()"
                [appendTo]="paginatorDropdownAppendTo()"
                [currentPageReportTemplate]="currentPageReportTemplate()"
                [showFirstLastIcon]="showFirstLastIcon()"
                [dropdownItemTemplate]="paginatorDropdownItemTemplate ?? _paginatorDropdownItemTemplate()"
                [showCurrentPageReport]="showCurrentPageReport()"
                [showJumpToPageDropdown]="showJumpToPageDropdown()"
                [showPageLinks]="showPageLinks()"
                [locale]="paginatorLocale()"
                [unstyled]="unstyled()"
            >
                @if (paginatorFirstPageLinkIconTemplate || _paginatorFirstPageLinkIconTemplate) {
                    <ng-template pTemplate="firstpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorFirstPageLinkIconTemplate || _paginatorFirstPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorPreviousPageLinkIconTemplate || _paginatorPreviousPageLinkIconTemplate) {
                    <ng-template pTemplate="previouspagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorPreviousPageLinkIconTemplate || _paginatorPreviousPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorLastPageLinkIconTemplate || _paginatorLastPageLinkIconTemplate) {
                    <ng-template pTemplate="lastpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorLastPageLinkIconTemplate || _paginatorLastPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorNextPageLinkIconTemplate || _paginatorNextPageLinkIconTemplate) {
                    <ng-template pTemplate="nextpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorNextPageLinkIconTemplate || _paginatorNextPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
            </p-paginator>
        }
        @if (summaryTemplate || _summaryTemplate) {
            <div [pBind]="ptm('footer')" [class]="cx('footer')">
                <ng-container *ngTemplateOutlet="summaryTemplate || _summaryTemplate"></ng-container>
            </div>
        }

        @if (resizableColumns()) {
            <div [pBind]="ptm('columnResizerHelper')" #resizeHelper [class]="cx('columnResizerHelper')" [style.display]="'none'"></div>
        }
        @if (reorderableColumns()) {
            <span [pBind]="ptm('reorderIndicatorUp')" #reorderIndicatorUp [class]="cx('reorderIndicatorUp')" [style.display]="'none'">
                @if (!reorderIndicatorUpIconTemplate && !_reorderIndicatorUpIconTemplate()) {
                    <svg data-p-icon="arrow-down" />
                }
                <ng-template *ngTemplateOutlet="reorderIndicatorUpIconTemplate || _reorderIndicatorUpIconTemplate()"></ng-template>
            </span>
        }
        @if (reorderableColumns()) {
            <span [pBind]="ptm('reorderIndicatorDown')" #reorderIndicatorDown [class]="cx('reorderIndicatorDown')" [style.display]="'none'">
                @if (!reorderIndicatorDownIconTemplate && !_reorderIndicatorDownIconTemplate()) {
                    <svg data-p-icon="arrow-up" />
                }
                <ng-template *ngTemplateOutlet="reorderIndicatorDownIconTemplate || _reorderIndicatorDownIconTemplate()"></ng-template>
            </span>
        }
    `,
                    providers: [TreeTableService, TreeTableStyle, { provide: TREETABLE_INSTANCE, useExisting: TreeTable }, { provide: PARENT_INSTANCE, useExisting: TreeTable }],
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class]': "cn(cx('root'), styleClass())",
                        '[attr.data-p]': 'dataP',
                        '[attr.data-scrollselectors]': "'.p-treetable-scrollable-body'"
                    },
                    hostDirectives: [Bind],
                    imports: [Bind, SpinnerIcon, NgTemplateOutlet, Paginator, PrimeTemplate, NgClass, NgStyle, forwardRef(() => TTBody), forwardRef(() => TTScrollableView), ArrowDownIcon, ArrowUpIcon, forwardRef(() => TreeTableModule)]
                }]
        }], ctorParameters: () => [], propDecorators: { columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], tableStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "tableStyle", required: false }] }], tableStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "tableStyleClass", required: false }] }], autoLayout: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoLayout", required: false }] }], lazy: [{ type: i0.Input, args: [{ isSignal: true, alias: "lazy", required: false }] }], lazyLoadOnInit: [{ type: i0.Input, args: [{ isSignal: true, alias: "lazyLoadOnInit", required: false }] }], paginator: [{ type: i0.Input, args: [{ isSignal: true, alias: "paginator", required: false }] }], rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: false }] }], first: [{ type: i0.Input, args: [{ isSignal: true, alias: "first", required: false }] }], pageLinks: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageLinks", required: false }] }], rowsPerPageOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowsPerPageOptions", required: false }] }], alwaysShowPaginator: [{ type: i0.Input, args: [{ isSignal: true, alias: "alwaysShowPaginator", required: false }] }], paginatorPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "paginatorPosition", required: false }] }], paginatorStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "paginatorStyleClass", required: false }] }], paginatorDropdownAppendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "paginatorDropdownAppendTo", required: false }] }], currentPageReportTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentPageReportTemplate", required: false }] }], showCurrentPageReport: [{ type: i0.Input, args: [{ isSignal: true, alias: "showCurrentPageReport", required: false }] }], showJumpToPageDropdown: [{ type: i0.Input, args: [{ isSignal: true, alias: "showJumpToPageDropdown", required: false }] }], showFirstLastIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "showFirstLastIcon", required: false }] }], showPageLinks: [{ type: i0.Input, args: [{ isSignal: true, alias: "showPageLinks", required: false }] }], defaultSortOrder: [{ type: i0.Input, args: [{ isSignal: true, alias: "defaultSortOrder", required: false }] }], sortMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "sortMode", required: false }] }], resetPageOnSort: [{ type: i0.Input, args: [{ isSignal: true, alias: "resetPageOnSort", required: false }] }], customSort: [{ type: i0.Input, args: [{ isSignal: true, alias: "customSort", required: false }] }], selectionMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectionMode", required: false }] }], contextMenuSelection: [{ type: i0.Input, args: [{ isSignal: true, alias: "contextMenuSelection", required: false }] }], contextMenuSelectionMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "contextMenuSelectionMode", required: false }] }], dataKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataKey", required: false }] }], metaKeySelection: [{ type: i0.Input, args: [{ isSignal: true, alias: "metaKeySelection", required: false }] }], compareSelectionBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "compareSelectionBy", required: false }] }], rowHover: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowHover", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], loadingIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "loadingIcon", required: false }] }], showLoader: [{ type: i0.Input, args: [{ isSignal: true, alias: "showLoader", required: false }] }], scrollable: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollable", required: false }] }], scrollHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollHeight", required: false }] }], virtualScroll: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScroll", required: false }] }], virtualScrollItemSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScrollItemSize", required: false }] }], virtualScrollOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScrollOptions", required: false }] }], virtualScrollDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScrollDelay", required: false }] }], frozenWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "frozenWidth", required: false }] }], frozenColumns: [{ type: i0.Input, args: [{ isSignal: true, alias: "frozenColumns", required: false }] }], resizableColumns: [{ type: i0.Input, args: [{ isSignal: true, alias: "resizableColumns", required: false }] }], columnResizeMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnResizeMode", required: false }] }], reorderableColumns: [{ type: i0.Input, args: [{ isSignal: true, alias: "reorderableColumns", required: false }] }], contextMenu: [{ type: i0.Input, args: [{ isSignal: true, alias: "contextMenu", required: false }] }], rowTrackBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowTrackBy", required: false }] }], filters: [{ type: i0.Input, args: [{ isSignal: true, alias: "filters", required: false }] }], globalFilterFields: [{ type: i0.Input, args: [{ isSignal: true, alias: "globalFilterFields", required: false }] }], filterDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterDelay", required: false }] }], filterMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterMode", required: false }] }], filterLocale: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterLocale", required: false }] }], paginatorLocale: [{ type: i0.Input, args: [{ isSignal: true, alias: "paginatorLocale", required: false }] }], totalRecords: [{ type: i0.Input, args: [{ isSignal: true, alias: "totalRecords", required: false }] }], sortField: [{ type: i0.Input, args: [{ isSignal: true, alias: "sortField", required: false }] }], sortOrder: [{ type: i0.Input, args: [{ isSignal: true, alias: "sortOrder", required: false }] }], multiSortMeta: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiSortMeta", required: false }] }], selection: [{ type: i0.Input, args: [{ isSignal: true, alias: "selection", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], virtualRowHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualRowHeight", required: false }] }], selectionKeys: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectionKeys", required: false }] }], showGridlines: [{ type: i0.Input, args: [{ isSignal: true, alias: "showGridlines", required: false }] }], selectionChange: [{ type: i0.Output, args: ["selectionChange"] }], contextMenuSelectionChange: [{ type: i0.Output, args: ["contextMenuSelectionChange"] }], onFilter: [{ type: i0.Output, args: ["onFilter"] }], onNodeExpand: [{ type: i0.Output, args: ["onNodeExpand"] }], onNodeCollapse: [{ type: i0.Output, args: ["onNodeCollapse"] }], onPage: [{ type: i0.Output, args: ["onPage"] }], onSort: [{ type: i0.Output, args: ["onSort"] }], onLazyLoad: [{ type: i0.Output, args: ["onLazyLoad"] }], sortFunction: [{ type: i0.Output, args: ["sortFunction"] }], onColResize: [{ type: i0.Output, args: ["onColResize"] }], onColReorder: [{ type: i0.Output, args: ["onColReorder"] }], onNodeSelect: [{ type: i0.Output, args: ["onNodeSelect"] }], onNodeUnselect: [{ type: i0.Output, args: ["onNodeUnselect"] }], onContextMenuSelect: [{ type: i0.Output, args: ["onContextMenuSelect"] }], onHeaderCheckboxToggle: [{ type: i0.Output, args: ["onHeaderCheckboxToggle"] }], onEditInit: [{ type: i0.Output, args: ["onEditInit"] }], onEditComplete: [{ type: i0.Output, args: ["onEditComplete"] }], onEditCancel: [{ type: i0.Output, args: ["onEditCancel"] }], selectionKeysChange: [{ type: i0.Output, args: ["selectionKeysChange"] }], resizeHelperViewChild: [{ type: i0.ViewChild, args: ['resizeHelper', { isSignal: true }] }], reorderIndicatorUpViewChild: [{ type: i0.ViewChild, args: ['reorderIndicatorUp', { isSignal: true }] }], reorderIndicatorDownViewChild: [{ type: i0.ViewChild, args: ['reorderIndicatorDown', { isSignal: true }] }], tableViewChild: [{ type: i0.ViewChild, args: ['table', { isSignal: true }] }], scrollableViewChild: [{ type: i0.ViewChild, args: ['scrollableView', { isSignal: true }] }], scrollableFrozenViewChild: [{ type: i0.ViewChild, args: ['scrollableFrozenView', { isSignal: true }] }], _colGroupTemplate: [{ type: i0.ContentChild, args: ['colgroup', { ...{ descendants: false }, isSignal: true }] }], _captionTemplate: [{
                type: ContentChild,
                args: ['caption', { descendants: false }]
            }], _headerTemplate: [{ type: i0.ContentChild, args: ['header', { ...{ descendants: false }, isSignal: true }] }], _bodyTemplate: [{ type: i0.ContentChild, args: ['body', { ...{ descendants: false }, isSignal: true }] }], _footerTemplate: [{
                type: ContentChild,
                args: ['footer', { descendants: false }]
            }], _summaryTemplate: [{
                type: ContentChild,
                args: ['summary', { descendants: false }]
            }], _emptyMessageTemplate: [{ type: i0.ContentChild, args: ['emptymessage', { ...{ descendants: false }, isSignal: true }] }], _paginatorLeftTemplate: [{ type: i0.ContentChild, args: ['paginatorleft', { ...{ descendants: false }, isSignal: true }] }], _paginatorRightTemplate: [{ type: i0.ContentChild, args: ['paginatorright', { ...{ descendants: false }, isSignal: true }] }], _paginatorDropdownItemTemplate: [{ type: i0.ContentChild, args: ['paginatordropdownitem', { ...{ descendants: false }, isSignal: true }] }], _frozenHeaderTemplate: [{ type: i0.ContentChild, args: ['frozenheader', { ...{ descendants: false }, isSignal: true }] }], _frozenBodyTemplate: [{ type: i0.ContentChild, args: ['frozenbody', { ...{ descendants: false }, isSignal: true }] }], _frozenFooterTemplate: [{ type: i0.ContentChild, args: ['frozenfooter', { ...{ descendants: false }, isSignal: true }] }], _frozenColGroupTemplate: [{ type: i0.ContentChild, args: ['frozencolgroup', { ...{ descendants: false }, isSignal: true }] }], _loadingIconTemplate: [{
                type: ContentChild,
                args: ['loadingicon', { descendants: false }]
            }], _reorderIndicatorUpIconTemplate: [{ type: i0.ContentChild, args: ['reorderindicatorupicon', { ...{ descendants: false }, isSignal: true }] }], _reorderIndicatorDownIconTemplate: [{ type: i0.ContentChild, args: ['reorderindicatordownicon', { ...{ descendants: false }, isSignal: true }] }], _sortIconTemplate: [{
                type: ContentChild,
                args: ['sorticon', { descendants: false }]
            }], _checkboxIconTemplate: [{
                type: ContentChild,
                args: ['checkboxicon', { descendants: false }]
            }], _headerCheckboxIconTemplate: [{
                type: ContentChild,
                args: ['headercheckboxicon', { descendants: false }]
            }], _togglerIconTemplate: [{ type: i0.ContentChild, args: ['togglericon', { ...{ descendants: false }, isSignal: true }] }], _paginatorFirstPageLinkIconTemplate: [{
                type: ContentChild,
                args: ['paginatorfirstpagelinkicon', { descendants: false }]
            }], _paginatorLastPageLinkIconTemplate: [{
                type: ContentChild,
                args: ['paginatorlastpagelinkicon', { descendants: false }]
            }], _paginatorPreviousPageLinkIconTemplate: [{
                type: ContentChild,
                args: ['paginatorpreviouspagelinkicon', { descendants: false }]
            }], _paginatorNextPageLinkIconTemplate: [{
                type: ContentChild,
                args: ['paginatornextpagelinkicon', { descendants: false }]
            }], _loaderTemplate: [{
                type: ContentChild,
                args: ['loader', { descendants: false }]
            }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class TTBody extends BaseComponent {
    tt = inject(TreeTable);
    treeTableService = inject(TreeTableService);
    columns = input(undefined, { ...(ngDevMode ? { debugName: "columns" } : /* istanbul ignore next */ {}), alias: 'pTreeTableBody' });
    template = input(undefined, { ...(ngDevMode ? { debugName: "template" } : /* istanbul ignore next */ {}), alias: 'pTreeTableBodyTemplate' });
    frozen = input(undefined, { ...(ngDevMode ? { debugName: "frozen" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    serializedNodes = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "serializedNodes" }] : /* istanbul ignore next */ []));
    scrollerOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "scrollerOptions" }] : /* istanbul ignore next */ []));
    subscription;
    constructor() {
        super();
        this.subscription = this.tt.tableService.uiUpdateSource$.subscribe(() => {
            if (this.tt.virtualScroll()) {
                this.cd.detectChanges();
            }
        });
    }
    getScrollerOption(option, options) {
        if (this.tt.virtualScroll()) {
            options = options || this.scrollerOptions();
            return options ? options[option] : null;
        }
        return null;
    }
    getRowIndex(rowIndex) {
        const getItemOptions = this.getScrollerOption('getItemOptions');
        return getItemOptions ? getItemOptions(rowIndex).index : rowIndex;
    }
    onDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    get dataP() {
        return this.cn({
            hoverable: this.tt.rowHover() || this.tt.selectionMode(),
            frozen: this.frozen()
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTBody, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: TTBody, isStandalone: true, selector: "[pTreeTableBody]", inputs: { columns: { classPropertyName: "columns", publicName: "pTreeTableBody", isSignal: true, isRequired: false, transformFunction: null }, template: { classPropertyName: "template", publicName: "pTreeTableBodyTemplate", isSignal: true, isRequired: false, transformFunction: null }, frozen: { classPropertyName: "frozen", publicName: "frozen", isSignal: true, isRequired: false, transformFunction: null }, serializedNodes: { classPropertyName: "serializedNodes", publicName: "serializedNodes", isSignal: true, isRequired: false, transformFunction: null }, scrollerOptions: { classPropertyName: "scrollerOptions", publicName: "scrollerOptions", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.data-p": "dataP" } }, usesInheritance: true, ngImport: i0, template: `
        @for (serializedNode of serializedNodes() || tt.serializedValue; track tt.rowTrackBy()(rowIndex, serializedNode); let rowIndex = $index) {
            @if (serializedNode.visible) {
                <ng-container
                    *ngTemplateOutlet="
                        template();
                        context: {
                            $implicit: serializedNode,
                            node: serializedNode.node,
                            rowData: serializedNode.node.data,
                            columns: columns()
                        }
                    "
                ></ng-container>
            }
        }
        @if (tt.isEmpty()) {
            <ng-container *ngTemplateOutlet="tt.emptyMessageTemplate || tt._emptyMessageTemplate(); context: { $implicit: columns(), frozen: frozen() }"></ng-container>
        }
    `, isInline: true, dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTBody, decorators: [{
            type: Component,
            args: [{
                    selector: '[pTreeTableBody]',
                    template: `
        @for (serializedNode of serializedNodes() || tt.serializedValue; track tt.rowTrackBy()(rowIndex, serializedNode); let rowIndex = $index) {
            @if (serializedNode.visible) {
                <ng-container
                    *ngTemplateOutlet="
                        template();
                        context: {
                            $implicit: serializedNode,
                            node: serializedNode.node,
                            rowData: serializedNode.node.data,
                            columns: columns()
                        }
                    "
                ></ng-container>
            }
        }
        @if (tt.isEmpty()) {
            <ng-container *ngTemplateOutlet="tt.emptyMessageTemplate || tt._emptyMessageTemplate(); context: { $implicit: columns(), frozen: frozen() }"></ng-container>
        }
    `,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[attr.data-p]': 'dataP'
                    },
                    imports: [NgTemplateOutlet]
                }]
        }], ctorParameters: () => [], propDecorators: { columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "pTreeTableBody", required: false }] }], template: [{ type: i0.Input, args: [{ isSignal: true, alias: "pTreeTableBodyTemplate", required: false }] }], frozen: [{ type: i0.Input, args: [{ isSignal: true, alias: "frozen", required: false }] }], serializedNodes: [{ type: i0.Input, args: [{ isSignal: true, alias: "serializedNodes", required: false }] }], scrollerOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollerOptions", required: false }] }] } });
class TTScrollableView extends BaseComponent {
    tt = inject(TreeTable);
    zone = inject(NgZone);
    hostName = 'TreeTable';
    columns = input(undefined, { ...(ngDevMode ? { debugName: "columns" } : /* istanbul ignore next */ {}), alias: 'ttScrollableView' });
    frozen = input(undefined, { ...(ngDevMode ? { debugName: "frozen" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    scrollHeaderViewChild = viewChild('scrollHeader', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scrollHeaderViewChild" }] : /* istanbul ignore next */ []));
    scrollHeaderBoxViewChild = viewChild('scrollHeaderBox', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scrollHeaderBoxViewChild" }] : /* istanbul ignore next */ []));
    scrollBodyViewChild = viewChild('scrollBody', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scrollBodyViewChild" }] : /* istanbul ignore next */ []));
    scrollTableViewChild = viewChild('scrollTable', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scrollTableViewChild" }] : /* istanbul ignore next */ []));
    scrollLoadingTableViewChild = viewChild('loadingTable', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scrollLoadingTableViewChild" }] : /* istanbul ignore next */ []));
    scrollFooterViewChild = viewChild('scrollFooter', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scrollFooterViewChild" }] : /* istanbul ignore next */ []));
    scrollFooterBoxViewChild = viewChild('scrollFooterBox', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scrollFooterBoxViewChild" }] : /* istanbul ignore next */ []));
    scrollableAlignerViewChild = viewChild('scrollableAligner', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scrollableAlignerViewChild" }] : /* istanbul ignore next */ []));
    scroller = viewChild('scroller', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scroller" }] : /* istanbul ignore next */ []));
    headerScrollListener;
    bodyScrollListener;
    footerScrollListener;
    frozenSiblingBody;
    totalRecordsSubscription;
    _scrollHeight;
    preventBodyScrollPropagation;
    _componentStyle = inject(TreeTableStyle);
    scrollHeight = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "scrollHeight" }] : /* istanbul ignore next */ []));
    constructor() {
        super();
        effect(() => {
            const val = this.scrollHeight();
            this._scrollHeight = val;
            if (val != null && (val.includes('%') || val.includes('calc'))) {
                console.log('Percentage scroll height calculation is removed in favor of the more performant CSS based flex mode, use scrollHeight="flex" instead.');
            }
        });
    }
    onAfterViewInit() {
        if (isPlatformBrowser(this.platformId)) {
            if (!this.frozen()) {
                if (this.tt.frozenColumns() || this.tt.frozenBodyTemplate || this.tt._frozenBodyTemplate()) {
                    addClass(this.el.nativeElement, 'p-treetable-unfrozen-view');
                }
                let frozenView = this.el.nativeElement.previousElementSibling;
                if (frozenView) {
                    if (this.tt.virtualScroll())
                        this.frozenSiblingBody = findSingle(frozenView, '[data-pc-name="virtualscroller"]');
                    else
                        this.frozenSiblingBody = findSingle(frozenView, '[data-pc-section="scrollablebody"]');
                }
                if (this._scrollHeight) {
                    let scrollBarWidth = calculateScrollbarWidth();
                    const scrollHeaderBoxViewChild = this.scrollHeaderBoxViewChild();
                    if (scrollHeaderBoxViewChild?.nativeElement) {
                        scrollHeaderBoxViewChild.nativeElement.style.paddingRight = scrollBarWidth + 'px';
                    }
                    const scrollFooterBoxViewChild = this.scrollFooterBoxViewChild();
                    if (scrollFooterBoxViewChild && scrollFooterBoxViewChild.nativeElement) {
                        scrollFooterBoxViewChild.nativeElement.style.paddingRight = scrollBarWidth + 'px';
                    }
                }
            }
            else {
                const scrollableAlignerViewChild = this.scrollableAlignerViewChild();
                if (scrollableAlignerViewChild && scrollableAlignerViewChild.nativeElement) {
                    scrollableAlignerViewChild.nativeElement.style.height = calculateScrollbarHeight() + 'px';
                }
            }
            this.bindEvents();
        }
    }
    bindEvents() {
        if (isPlatformBrowser(this.platformId)) {
            this.zone.runOutsideAngular(() => {
                const scrollHeaderViewChild = this.scrollHeaderViewChild();
                if (scrollHeaderViewChild && scrollHeaderViewChild.nativeElement) {
                    this.headerScrollListener = this.renderer.listen(this.scrollHeaderBoxViewChild()?.nativeElement, 'scroll', this.onHeaderScroll.bind(this));
                }
                const scrollFooterViewChild = this.scrollFooterViewChild();
                if (scrollFooterViewChild && scrollFooterViewChild.nativeElement) {
                    this.footerScrollListener = this.renderer.listen(scrollFooterViewChild.nativeElement, 'scroll', this.onFooterScroll.bind(this));
                }
                if (!this.frozen()) {
                    if (this.tt.virtualScroll()) {
                        this.bodyScrollListener = this.renderer.listen((this.scroller()?.getElementRef()).nativeElement, 'scroll', this.onBodyScroll.bind(this));
                    }
                    else {
                        this.bodyScrollListener = this.renderer.listen(this.scrollBodyViewChild()?.nativeElement, 'scroll', this.onBodyScroll.bind(this));
                    }
                }
            });
        }
    }
    unbindEvents() {
        if (isPlatformBrowser(this.platformId)) {
            const scrollHeaderViewChild = this.scrollHeaderViewChild();
            if (scrollHeaderViewChild && scrollHeaderViewChild.nativeElement) {
                if (this.headerScrollListener) {
                    this.headerScrollListener();
                    this.headerScrollListener = null;
                }
            }
            const scrollFooterViewChild = this.scrollFooterViewChild();
            if (scrollFooterViewChild && scrollFooterViewChild.nativeElement) {
                if (this.footerScrollListener) {
                    this.footerScrollListener();
                    this.footerScrollListener = null;
                }
            }
            const scrollBodyViewChild = this.scrollBodyViewChild();
            if (scrollBodyViewChild && scrollBodyViewChild.nativeElement) {
                if (this.bodyScrollListener) {
                    this.bodyScrollListener();
                    this.bodyScrollListener = null;
                }
            }
            const scroller = this.scroller();
            if (scroller && scroller.getElementRef()) {
                if (this.bodyScrollListener) {
                    this.bodyScrollListener();
                    this.bodyScrollListener = null;
                }
            }
        }
    }
    onHeaderScroll() {
        const scrollLeft = this.scrollHeaderViewChild()?.nativeElement.scrollLeft;
        this.scrollBodyViewChild().nativeElement.scrollLeft = scrollLeft;
        const scrollFooterViewChild = this.scrollFooterViewChild();
        if (scrollFooterViewChild && scrollFooterViewChild.nativeElement) {
            scrollFooterViewChild.nativeElement.scrollLeft = scrollLeft;
        }
        this.preventBodyScrollPropagation = true;
    }
    onFooterScroll() {
        const scrollLeft = this.scrollFooterViewChild()?.nativeElement.scrollLeft;
        this.scrollBodyViewChild().nativeElement.scrollLeft = scrollLeft;
        const scrollHeaderViewChild = this.scrollHeaderViewChild();
        if (scrollHeaderViewChild && scrollHeaderViewChild.nativeElement) {
            scrollHeaderViewChild.nativeElement.scrollLeft = scrollLeft;
        }
        this.preventBodyScrollPropagation = true;
    }
    onBodyScroll(event) {
        if (this.preventBodyScrollPropagation) {
            this.preventBodyScrollPropagation = false;
            return;
        }
        const scrollHeaderViewChild = this.scrollHeaderViewChild();
        if (scrollHeaderViewChild && scrollHeaderViewChild.nativeElement) {
            this.scrollHeaderBoxViewChild().nativeElement.style.marginLeft = -1 * event.target.scrollLeft + 'px';
        }
        const scrollFooterViewChild = this.scrollFooterViewChild();
        if (scrollFooterViewChild && scrollFooterViewChild.nativeElement) {
            this.scrollFooterBoxViewChild().nativeElement.style.marginLeft = -1 * event.target.scrollLeft + 'px';
        }
        if (this.frozenSiblingBody) {
            this.frozenSiblingBody.scrollTop = event.target.scrollTop;
        }
    }
    scrollToVirtualIndex(index) {
        const scroller = this.scroller();
        if (scroller) {
            scroller.scrollToIndex(index);
        }
    }
    scrollTo(options) {
        const scroller = this.scroller();
        if (scroller) {
            scroller.scrollTo(options);
        }
        else {
            const scrollBodyViewChild = this.scrollBodyViewChild();
            if (scrollBodyViewChild?.nativeElement.scrollTo) {
                scrollBodyViewChild.nativeElement.scrollTo(options);
            }
            else {
                scrollBodyViewChild.nativeElement.scrollLeft = options.left;
                scrollBodyViewChild.nativeElement.scrollTop = options.top;
            }
        }
    }
    onDestroy() {
        this.unbindEvents();
        this.frozenSiblingBody = null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTScrollableView, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: TTScrollableView, isStandalone: true, selector: "[ttScrollableView]", inputs: { columns: { classPropertyName: "columns", publicName: "ttScrollableView", isSignal: true, isRequired: false, transformFunction: null }, frozen: { classPropertyName: "frozen", publicName: "frozen", isSignal: true, isRequired: false, transformFunction: null }, scrollHeight: { classPropertyName: "scrollHeight", publicName: "scrollHeight", isSignal: true, isRequired: false, transformFunction: null } }, providers: [TreeTableStyle], viewQueries: [{ propertyName: "scrollHeaderViewChild", first: true, predicate: ["scrollHeader"], descendants: true, isSignal: true }, { propertyName: "scrollHeaderBoxViewChild", first: true, predicate: ["scrollHeaderBox"], descendants: true, isSignal: true }, { propertyName: "scrollBodyViewChild", first: true, predicate: ["scrollBody"], descendants: true, isSignal: true }, { propertyName: "scrollTableViewChild", first: true, predicate: ["scrollTable"], descendants: true, isSignal: true }, { propertyName: "scrollLoadingTableViewChild", first: true, predicate: ["loadingTable"], descendants: true, isSignal: true }, { propertyName: "scrollFooterViewChild", first: true, predicate: ["scrollFooter"], descendants: true, isSignal: true }, { propertyName: "scrollFooterBoxViewChild", first: true, predicate: ["scrollFooterBox"], descendants: true, isSignal: true }, { propertyName: "scrollableAlignerViewChild", first: true, predicate: ["scrollableAligner"], descendants: true, isSignal: true }, { propertyName: "scroller", first: true, predicate: ["scroller"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: `
        <div #scrollHeader [class]="cx('scrollableHeader')" [pBind]="ptm('scrollableHeader')">
            <div #scrollHeaderBox [class]="cx('scrollableHeaderBox')" [pBind]="ptm('scrollableHeaderBox')">
                <table [class]="cn(cx('scrollableHeaderTable'), tt.tableStyleClass())" [pBind]="ptm('scrollableHeaderTable')" [ngStyle]="tt.tableStyle()">
                    <ng-container
                        *ngTemplateOutlet="frozen() ? tt.frozenColGroupTemplate || tt._frozenColGroupTemplate() || tt.colGroupTemplate || tt._colGroupTemplate() : tt.colGroupTemplate || tt._colGroupTemplate(); context: { $implicit: columns() }"
                    ></ng-container>
                    <thead role="rowgroup" [class]="cx('thead')" [pBind]="ptm('thead')">
                        <ng-container
                            *ngTemplateOutlet="frozen() ? tt.frozenHeaderTemplate || tt._frozenHeaderTemplate() || tt.headerTemplate || tt._headerTemplate() : tt.headerTemplate || tt._headerTemplate(); context: { $implicit: columns() }"
                        ></ng-container>
                    </thead>
                </table>
            </div>
        </div>

        @if (tt.virtualScroll()) {
            <p-scroller
                #scroller
                [items]="tt.serializedValue"
                [styleClass]="cx('scrollableBody')"
                [style]="{ height: tt.scrollHeight() !== 'flex' ? tt.scrollHeight() : undefined }"
                [scrollHeight]="_scrollHeight !== 'flex' ? undefined : '100%'"
                [itemSize]="tt.virtualScrollItemSize() || tt._virtualRowHeight"
                [lazy]="tt.lazy()"
                (onLazyLoad)="tt.onLazyItemLoad($event)"
                [options]="tt.virtualScrollOptions()"
                [pt]="ptm('virtualScroller')"
            >
                <ng-template #content let-items let-scrollerOptions="options">
                    <ng-container *ngTemplateOutlet="buildInItems; context: { $implicit: items, options: scrollerOptions }"></ng-container>
                </ng-template>
                @if (tt.loaderTemplate || tt._loaderTemplate) {
                    <ng-template #loader let-scrollerOptions="options">
                        <ng-container *ngTemplateOutlet="tt.loaderTemplate || tt._loaderTemplate; context: { options: scrollerOptions }"></ng-container>
                    </ng-template>
                }
            </p-scroller>
        }
        @if (!tt.virtualScroll()) {
            <div
                #scrollBody
                [class]="cx('scrollableBody')"
                [pBind]="ptm('scrollableBody')"
                [ngStyle]="{
                    'max-height': tt.scrollHeight() !== 'flex' ? _scrollHeight : undefined,
                    'overflow-y': !frozen() && tt.scrollHeight() ? 'scroll' : undefined
                }"
            >
                <ng-container *ngTemplateOutlet="buildInItems; context: { $implicit: serializedValue, options: {} }"></ng-container>
            </div>
        }

        <ng-template #buildInItems let-items let-scrollerOptions="options">
            <table role="treegrid" #scrollTable [pBind]="ptm('table')" [class]="tt.tableStyleClass()" [ngClass]="scrollerOptions.contentStyleClass" [ngStyle]="tt.tableStyle()" [style]="scrollerOptions.contentStyle">
                <ng-container
                    *ngTemplateOutlet="frozen() ? tt.frozenColGroupTemplate || tt._frozenColGroupTemplate() || tt.colGroupTemplate || tt._colGroupTemplate() : tt.colGroupTemplate || tt._colGroupTemplate(); context: { $implicit: columns() }"
                ></ng-container>
                <tbody
                    [pBind]="ptm('tbody')"
                    role="rowgroup"
                    [class]="cx('tbody')"
                    [pBind]="ptm('tbody')"
                    [pTreeTableBody]="columns()"
                    [unstyled]="unstyled()"
                    [pTreeTableBodyTemplate]="frozen() ? tt.frozenBodyTemplate || tt._frozenBodyTemplate() || tt.bodyTemplate || tt._bodyTemplate() : tt.bodyTemplate || tt._bodyTemplate()"
                    [serializedNodes]="items"
                    [frozen]="frozen()"
                ></tbody>
            </table>
            @if (frozen()) {
                <div #scrollableAligner [style.background-color]="'transparent'"></div>
            }
        </ng-template>

        @if (tt.footerTemplate || tt._footerTemplate) {
            <div #scrollFooter [class]="cx('scrollableFooter')" [pBind]="ptm('scrollableFooter')">
                <div #scrollFooterBox [class]="cx('scrollableFooterBox')" [pBind]="ptm('scrollableFooterBox')">
                    <table [class]="cx('scrollableFooterTable')" [ngClass]="tt.tableStyleClass()" [ngStyle]="tt.tableStyle()" [pBind]="ptm('scrollableFooterTable')">
                        <ng-container
                            *ngTemplateOutlet="frozen() ? tt.frozenColGroupTemplate || tt._frozenColGroupTemplate() || tt.colGroupTemplate || tt._colGroupTemplate() : tt.colGroupTemplate || tt._colGroupTemplate(); context: { $implicit: columns() }"
                        ></ng-container>
                        <tfoot role="rowgroup" [class]="cx('tfoot')" [pBind]="ptm('tfoot')">
                            <ng-container
                                *ngTemplateOutlet="frozen() ? tt.frozenFooterTemplate || tt._frozenFooterTemplate() || tt.footerTemplate || tt._footerTemplate : tt.footerTemplate || tt._footerTemplate; context: { $implicit: columns() }"
                            ></ng-container>
                        </tfoot>
                    </table>
                </div>
            </div>
        }
    `, isInline: true, dependencies: [{ kind: "directive", type: Bind, selector: "[pBind]", inputs: ["pBind"] }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: Scroller, selector: "p-scroller, p-virtualscroller, p-virtual-scroller, p-virtualScroller", inputs: ["hostName", "id", "style", "styleClass", "tabindex", "items", "itemSize", "scrollHeight", "scrollWidth", "orientation", "step", "delay", "resizeDelay", "appendOnly", "inline", "lazy", "disabled", "loaderDisabled", "columns", "showSpacer", "showLoader", "numToleratedItems", "loading", "autoSize", "trackBy", "options"], outputs: ["onLazyLoad", "onScroll", "onScrollIndexChange"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: TTBody, selector: "[pTreeTableBody]", inputs: ["pTreeTableBody", "pTreeTableBodyTemplate", "frozen", "serializedNodes", "scrollerOptions"] }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTScrollableView, decorators: [{
            type: Component,
            args: [{
                    selector: '[ttScrollableView]',
                    template: `
        <div #scrollHeader [class]="cx('scrollableHeader')" [pBind]="ptm('scrollableHeader')">
            <div #scrollHeaderBox [class]="cx('scrollableHeaderBox')" [pBind]="ptm('scrollableHeaderBox')">
                <table [class]="cn(cx('scrollableHeaderTable'), tt.tableStyleClass())" [pBind]="ptm('scrollableHeaderTable')" [ngStyle]="tt.tableStyle()">
                    <ng-container
                        *ngTemplateOutlet="frozen() ? tt.frozenColGroupTemplate || tt._frozenColGroupTemplate() || tt.colGroupTemplate || tt._colGroupTemplate() : tt.colGroupTemplate || tt._colGroupTemplate(); context: { $implicit: columns() }"
                    ></ng-container>
                    <thead role="rowgroup" [class]="cx('thead')" [pBind]="ptm('thead')">
                        <ng-container
                            *ngTemplateOutlet="frozen() ? tt.frozenHeaderTemplate || tt._frozenHeaderTemplate() || tt.headerTemplate || tt._headerTemplate() : tt.headerTemplate || tt._headerTemplate(); context: { $implicit: columns() }"
                        ></ng-container>
                    </thead>
                </table>
            </div>
        </div>

        @if (tt.virtualScroll()) {
            <p-scroller
                #scroller
                [items]="tt.serializedValue"
                [styleClass]="cx('scrollableBody')"
                [style]="{ height: tt.scrollHeight() !== 'flex' ? tt.scrollHeight() : undefined }"
                [scrollHeight]="_scrollHeight !== 'flex' ? undefined : '100%'"
                [itemSize]="tt.virtualScrollItemSize() || tt._virtualRowHeight"
                [lazy]="tt.lazy()"
                (onLazyLoad)="tt.onLazyItemLoad($event)"
                [options]="tt.virtualScrollOptions()"
                [pt]="ptm('virtualScroller')"
            >
                <ng-template #content let-items let-scrollerOptions="options">
                    <ng-container *ngTemplateOutlet="buildInItems; context: { $implicit: items, options: scrollerOptions }"></ng-container>
                </ng-template>
                @if (tt.loaderTemplate || tt._loaderTemplate) {
                    <ng-template #loader let-scrollerOptions="options">
                        <ng-container *ngTemplateOutlet="tt.loaderTemplate || tt._loaderTemplate; context: { options: scrollerOptions }"></ng-container>
                    </ng-template>
                }
            </p-scroller>
        }
        @if (!tt.virtualScroll()) {
            <div
                #scrollBody
                [class]="cx('scrollableBody')"
                [pBind]="ptm('scrollableBody')"
                [ngStyle]="{
                    'max-height': tt.scrollHeight() !== 'flex' ? _scrollHeight : undefined,
                    'overflow-y': !frozen() && tt.scrollHeight() ? 'scroll' : undefined
                }"
            >
                <ng-container *ngTemplateOutlet="buildInItems; context: { $implicit: serializedValue, options: {} }"></ng-container>
            </div>
        }

        <ng-template #buildInItems let-items let-scrollerOptions="options">
            <table role="treegrid" #scrollTable [pBind]="ptm('table')" [class]="tt.tableStyleClass()" [ngClass]="scrollerOptions.contentStyleClass" [ngStyle]="tt.tableStyle()" [style]="scrollerOptions.contentStyle">
                <ng-container
                    *ngTemplateOutlet="frozen() ? tt.frozenColGroupTemplate || tt._frozenColGroupTemplate() || tt.colGroupTemplate || tt._colGroupTemplate() : tt.colGroupTemplate || tt._colGroupTemplate(); context: { $implicit: columns() }"
                ></ng-container>
                <tbody
                    [pBind]="ptm('tbody')"
                    role="rowgroup"
                    [class]="cx('tbody')"
                    [pBind]="ptm('tbody')"
                    [pTreeTableBody]="columns()"
                    [unstyled]="unstyled()"
                    [pTreeTableBodyTemplate]="frozen() ? tt.frozenBodyTemplate || tt._frozenBodyTemplate() || tt.bodyTemplate || tt._bodyTemplate() : tt.bodyTemplate || tt._bodyTemplate()"
                    [serializedNodes]="items"
                    [frozen]="frozen()"
                ></tbody>
            </table>
            @if (frozen()) {
                <div #scrollableAligner [style.background-color]="'transparent'"></div>
            }
        </ng-template>

        @if (tt.footerTemplate || tt._footerTemplate) {
            <div #scrollFooter [class]="cx('scrollableFooter')" [pBind]="ptm('scrollableFooter')">
                <div #scrollFooterBox [class]="cx('scrollableFooterBox')" [pBind]="ptm('scrollableFooterBox')">
                    <table [class]="cx('scrollableFooterTable')" [ngClass]="tt.tableStyleClass()" [ngStyle]="tt.tableStyle()" [pBind]="ptm('scrollableFooterTable')">
                        <ng-container
                            *ngTemplateOutlet="frozen() ? tt.frozenColGroupTemplate || tt._frozenColGroupTemplate() || tt.colGroupTemplate || tt._colGroupTemplate() : tt.colGroupTemplate || tt._colGroupTemplate(); context: { $implicit: columns() }"
                        ></ng-container>
                        <tfoot role="rowgroup" [class]="cx('tfoot')" [pBind]="ptm('tfoot')">
                            <ng-container
                                *ngTemplateOutlet="frozen() ? tt.frozenFooterTemplate || tt._frozenFooterTemplate() || tt.footerTemplate || tt._footerTemplate : tt.footerTemplate || tt._footerTemplate; context: { $implicit: columns() }"
                            ></ng-container>
                        </tfoot>
                    </table>
                </div>
            </div>
        }
    `,
                    encapsulation: ViewEncapsulation.None,
                    providers: [TreeTableStyle],
                    imports: [Bind, NgStyle, NgTemplateOutlet, Scroller, NgClass, TTBody]
                }]
        }], ctorParameters: () => [], propDecorators: { columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "ttScrollableView", required: false }] }], frozen: [{ type: i0.Input, args: [{ isSignal: true, alias: "frozen", required: false }] }], scrollHeaderViewChild: [{ type: i0.ViewChild, args: ['scrollHeader', { isSignal: true }] }], scrollHeaderBoxViewChild: [{ type: i0.ViewChild, args: ['scrollHeaderBox', { isSignal: true }] }], scrollBodyViewChild: [{ type: i0.ViewChild, args: ['scrollBody', { isSignal: true }] }], scrollTableViewChild: [{ type: i0.ViewChild, args: ['scrollTable', { isSignal: true }] }], scrollLoadingTableViewChild: [{ type: i0.ViewChild, args: ['loadingTable', { isSignal: true }] }], scrollFooterViewChild: [{ type: i0.ViewChild, args: ['scrollFooter', { isSignal: true }] }], scrollFooterBoxViewChild: [{ type: i0.ViewChild, args: ['scrollFooterBox', { isSignal: true }] }], scrollableAlignerViewChild: [{ type: i0.ViewChild, args: ['scrollableAligner', { isSignal: true }] }], scroller: [{ type: i0.ViewChild, args: ['scroller', { isSignal: true }] }], scrollHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollHeight", required: false }] }] } });
class TTSortableColumn extends BaseComponent {
    tt = inject(TreeTable);
    hostName = 'TreeTable ';
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptm('sortableColumn', { context: { sorted: this.sorted } }));
    }
    field = input(undefined, { ...(ngDevMode ? { debugName: "field" } : /* istanbul ignore next */ {}), alias: 'ttSortableColumn' });
    ttSortableColumnDisabled = input(undefined, { ...(ngDevMode ? { debugName: "ttSortableColumnDisabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    sorted;
    subscription;
    _componentStyle = inject(TreeTableStyle);
    get ariaSorted() {
        if (this.sorted && this.tt.sortOrder() < 0)
            return 'descending';
        else if (this.sorted && this.tt.sortOrder() > 0)
            return 'ascending';
        else
            return 'none';
    }
    constructor() {
        super();
        if (this.isEnabled()) {
            this.subscription = this.tt.tableService.sortSource$.subscribe(() => {
                this.updateSortState();
            });
        }
    }
    onInit() {
        if (this.isEnabled()) {
            this.updateSortState();
        }
    }
    updateSortState() {
        this.sorted = this.tt.isSorted(this.field());
    }
    onClick(event) {
        if (this.isEnabled()) {
            this.updateSortState();
            this.tt.sort({
                originalEvent: event,
                field: this.field()
            });
            clearSelection();
        }
    }
    onEnterKey(event) {
        this.onClick(event);
    }
    isEnabled() {
        return this.ttSortableColumnDisabled() !== true;
    }
    onDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTSortableColumn, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: TTSortableColumn, isStandalone: true, selector: "[ttSortableColumn]", inputs: { field: { classPropertyName: "field", publicName: "ttSortableColumn", isSignal: true, isRequired: false, transformFunction: null }, ttSortableColumnDisabled: { classPropertyName: "ttSortableColumnDisabled", publicName: "ttSortableColumnDisabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "columnheader" }, listeners: { "click": "onClick($event)", "keydown.enter": "onEnterKey($event)" }, properties: { "class": "cx(\"sortableColumn\")", "tabindex": "isEnabled() ? \"0\" : null", "attr.aria-sort": "ariaSorted" } }, providers: [TreeTableStyle], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTSortableColumn, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ttSortableColumn]',
                    host: {
                        '[class]': 'cx("sortableColumn")',
                        '[tabindex]': 'isEnabled() ? "0" : null',
                        role: 'columnheader',
                        '[attr.aria-sort]': 'ariaSorted',
                        '(click)': 'onClick($event)',
                        '(keydown.enter)': 'onEnterKey($event)'
                    },
                    providers: [TreeTableStyle],
                    hostDirectives: [Bind]
                }]
        }], ctorParameters: () => [], propDecorators: { field: [{ type: i0.Input, args: [{ isSignal: true, alias: "ttSortableColumn", required: false }] }], ttSortableColumnDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "ttSortableColumnDisabled", required: false }] }] } });
class TTSortIcon extends BaseComponent {
    tt = inject(TreeTable);
    cd = inject(ChangeDetectorRef);
    hostName = 'TreeTable';
    field = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "field" }] : /* istanbul ignore next */ []));
    ariaLabelDesc = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelDesc" }] : /* istanbul ignore next */ []));
    ariaLabelAsc = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelAsc" }] : /* istanbul ignore next */ []));
    subscription;
    sortOrder;
    _componentStyle = inject(TreeTableStyle);
    constructor() {
        super();
        this.subscription = this.tt.tableService.sortSource$.subscribe(() => {
            this.updateSortState();
            this.cd.markForCheck();
        });
    }
    onInit() {
        this.updateSortState();
    }
    onClick(event) {
        event.preventDefault();
    }
    getMultiSortMetaIndex() {
        let multiSortMeta = this.tt._multiSortMeta;
        let index = -1;
        if (multiSortMeta && this.tt.sortMode() === 'multiple' && multiSortMeta.length > 1) {
            for (let i = 0; i < multiSortMeta.length; i++) {
                let meta = multiSortMeta[i];
                const field = this.field();
                if (meta.field === field || meta.field === field) {
                    index = i;
                    break;
                }
            }
        }
        return index;
    }
    updateSortState() {
        const sortMode = this.tt.sortMode();
        if (sortMode === 'single') {
            this.sortOrder = this.tt.isSorted(this.field()) ? this.tt.sortOrder() : 0;
        }
        else if (sortMode === 'multiple') {
            let sortMeta = this.tt.getSortMeta(this.field());
            this.sortOrder = sortMeta ? sortMeta.order : 0;
        }
    }
    getBadgeValue() {
        return this.getMultiSortMetaIndex() + 1;
    }
    isMultiSorted() {
        return this.tt.sortMode() === 'multiple' && this.getMultiSortMetaIndex() > -1;
    }
    onDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTSortIcon, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: TTSortIcon, isStandalone: true, selector: "p-treeTableSortIcon, p-treetable-sort-icon, p-tree-table-sort-icon", inputs: { field: { classPropertyName: "field", publicName: "field", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelDesc: { classPropertyName: "ariaLabelDesc", publicName: "ariaLabelDesc", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelAsc: { classPropertyName: "ariaLabelAsc", publicName: "ariaLabelAsc", isSignal: true, isRequired: false, transformFunction: null } }, providers: [TreeTableStyle], usesInheritance: true, ngImport: i0, template: `
        @if (!tt.sortIconTemplate && !tt._sortIconTemplate) {
            @if (sortOrder === 0) {
                <svg data-p-icon="sort-alt" [class]="cx('sortableColumnIcon')" [pBind]="ptm('sortableColumnIcon')" />
            }
            @if (sortOrder === 1) {
                <svg data-p-icon="sort-amount-up-alt" [class]="cx('sortableColumnIcon')" [pBind]="ptm('sortableColumnIcon')" />
            }
            @if (sortOrder === -1) {
                <svg data-p-icon="sort-amount-down" [class]="cx('sortableColumnIcon')" [pBind]="ptm('sortableColumnIcon')" />
            }
        }
        @if (tt.sortIconTemplate || tt._sortIconTemplate) {
            <span [class]="cx('sortableColumnIcon')" [pBind]="ptm('sortableColumnIcon')">
                <ng-template *ngTemplateOutlet="tt.sortIconTemplate || tt._sortIconTemplate; context: { $implicit: sortOrder }"></ng-template>
            </span>
        }
        @if (isMultiSorted()) {
            <p-badge [class]="cx('sortableColumnBadge')" [value]="getBadgeValue()" size="small" [pt]="ptm('pcSortableColumnBadge')" [unstyled]="unstyled()"></p-badge>
        }
    `, isInline: true, dependencies: [{ kind: "component", type: SortAltIcon, selector: "[data-p-icon=\"sort-alt\"]" }, { kind: "directive", type: Bind, selector: "[pBind]", inputs: ["pBind"] }, { kind: "component", type: SortAmountUpAltIcon, selector: "[data-p-icon=\"sort-amount-up-alt\"]" }, { kind: "component", type: SortAmountDownIcon, selector: "[data-p-icon=\"sort-amount-down\"]" }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: Badge, selector: "p-badge", inputs: ["styleClass", "badgeSize", "size", "severity", "value", "badgeDisabled"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTSortIcon, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-treeTableSortIcon, p-treetable-sort-icon, p-tree-table-sort-icon',
                    template: `
        @if (!tt.sortIconTemplate && !tt._sortIconTemplate) {
            @if (sortOrder === 0) {
                <svg data-p-icon="sort-alt" [class]="cx('sortableColumnIcon')" [pBind]="ptm('sortableColumnIcon')" />
            }
            @if (sortOrder === 1) {
                <svg data-p-icon="sort-amount-up-alt" [class]="cx('sortableColumnIcon')" [pBind]="ptm('sortableColumnIcon')" />
            }
            @if (sortOrder === -1) {
                <svg data-p-icon="sort-amount-down" [class]="cx('sortableColumnIcon')" [pBind]="ptm('sortableColumnIcon')" />
            }
        }
        @if (tt.sortIconTemplate || tt._sortIconTemplate) {
            <span [class]="cx('sortableColumnIcon')" [pBind]="ptm('sortableColumnIcon')">
                <ng-template *ngTemplateOutlet="tt.sortIconTemplate || tt._sortIconTemplate; context: { $implicit: sortOrder }"></ng-template>
            </span>
        }
        @if (isMultiSorted()) {
            <p-badge [class]="cx('sortableColumnBadge')" [value]="getBadgeValue()" size="small" [pt]="ptm('pcSortableColumnBadge')" [unstyled]="unstyled()"></p-badge>
        }
    `,
                    encapsulation: ViewEncapsulation.None,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    providers: [TreeTableStyle],
                    imports: [SortAltIcon, Bind, SortAmountUpAltIcon, SortAmountDownIcon, NgTemplateOutlet, Badge]
                }]
        }], ctorParameters: () => [], propDecorators: { field: [{ type: i0.Input, args: [{ isSignal: true, alias: "field", required: false }] }], ariaLabelDesc: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelDesc", required: false }] }], ariaLabelAsc: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelAsc", required: false }] }] } });
class TTResizableColumn extends BaseComponent {
    tt = inject(TreeTable);
    zone = inject(NgZone);
    hostName = 'TreeTable';
    ttResizableColumnDisabled = input(undefined, { ...(ngDevMode ? { debugName: "ttResizableColumnDisabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    resizer;
    resizerMouseDownListener;
    documentMouseMoveListener;
    documentMouseUpListener;
    onAfterViewInit() {
        if (isPlatformBrowser(this.platformId)) {
            if (this.isEnabled()) {
                addClass(this.el.nativeElement, 'p-resizable-column');
                this.resizer = this.renderer.createElement('span');
                !this.$unstyled() && this.renderer.addClass(this.resizer, 'p-column-resizer');
                this.resizer.setAttribute('data-pc-section', 'columnresizer');
                this.renderer.appendChild(this.el.nativeElement, this.resizer);
                this.zone.runOutsideAngular(() => {
                    this.resizerMouseDownListener = this.renderer.listen(this.resizer, 'mousedown', this.onMouseDown.bind(this));
                });
            }
        }
    }
    bindDocumentEvents() {
        this.zone.runOutsideAngular(() => {
            this.documentMouseMoveListener = this.renderer.listen(this.document, 'mousemove', this.onDocumentMouseMove.bind(this));
            this.documentMouseUpListener = this.renderer.listen(this.document, 'mouseup', this.onDocumentMouseUp.bind(this));
        });
    }
    unbindDocumentEvents() {
        if (this.documentMouseMoveListener) {
            this.documentMouseMoveListener();
            this.documentMouseMoveListener = null;
        }
        if (this.documentMouseUpListener) {
            this.documentMouseUpListener();
            this.documentMouseUpListener = null;
        }
    }
    onMouseDown(event) {
        this.tt.onColumnResizeBegin(event);
        this.bindDocumentEvents();
    }
    onDocumentMouseMove(event) {
        this.tt.onColumnResize(event);
    }
    onDocumentMouseUp(event) {
        this.tt.onColumnResizeEnd(event, this.el.nativeElement);
        this.unbindDocumentEvents();
    }
    isEnabled() {
        return this.ttResizableColumnDisabled() !== true;
    }
    onDestroy() {
        if (this.resizerMouseDownListener) {
            this.resizerMouseDownListener();
            this.resizerMouseDownListener = null;
        }
        this.unbindDocumentEvents();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTResizableColumn, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: TTResizableColumn, isStandalone: true, selector: "[ttResizableColumn]", inputs: { ttResizableColumnDisabled: { classPropertyName: "ttResizableColumnDisabled", publicName: "ttResizableColumnDisabled", isSignal: true, isRequired: false, transformFunction: null } }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTResizableColumn, decorators: [{
            type: Directive,
            args: [{ selector: '[ttResizableColumn]' }]
        }], propDecorators: { ttResizableColumnDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "ttResizableColumnDisabled", required: false }] }] } });
class TTReorderableColumn extends BaseComponent {
    tt = inject(TreeTable);
    zone = inject(NgZone);
    hostName = 'TreeTable';
    ttReorderableColumnDisabled = input(undefined, { ...(ngDevMode ? { debugName: "ttReorderableColumnDisabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    dragStartListener;
    dragOverListener;
    dragEnterListener;
    dragLeaveListener;
    mouseDownListener;
    onAfterViewInit() {
        if (this.isEnabled()) {
            this.bindEvents();
        }
    }
    bindEvents() {
        if (isPlatformBrowser(this.platformId)) {
            this.zone.runOutsideAngular(() => {
                this.mouseDownListener = this.renderer.listen(this.el.nativeElement, 'mousedown', this.onMouseDown.bind(this));
                this.dragStartListener = this.renderer.listen(this.el.nativeElement, 'dragstart', this.onDragStart.bind(this));
                this.dragOverListener = this.renderer.listen(this.el.nativeElement, 'dragover', this.onDragEnter.bind(this));
                this.dragEnterListener = this.renderer.listen(this.el.nativeElement, 'dragenter', this.onDragEnter.bind(this));
                this.dragLeaveListener = this.renderer.listen(this.el.nativeElement, 'dragleave', this.onDragLeave.bind(this));
            });
        }
    }
    unbindEvents() {
        if (isPlatformBrowser(this.platformId)) {
            if (this.mouseDownListener) {
                this.mouseDownListener();
                this.mouseDownListener = null;
            }
            if (this.dragOverListener) {
                this.dragOverListener();
                this.dragOverListener = null;
            }
            if (this.dragEnterListener) {
                this.dragEnterListener();
                this.dragEnterListener = null;
            }
            if (this.dragLeaveListener) {
                this.dragLeaveListener();
                this.dragLeaveListener = null;
            }
        }
    }
    onMouseDown(event) {
        if (event.target.nodeName === 'INPUT' || event.target.nodeName === 'TEXTAREA' || findSingle(event.target, '[data-pc-section="columnresizer"]'))
            this.el.nativeElement.draggable = false;
        else
            this.el.nativeElement.draggable = true;
    }
    onDragStart(event) {
        this.tt.onColumnDragStart(event, this.el.nativeElement);
    }
    onDragOver(event) {
        event.preventDefault();
    }
    onDragEnter(event) {
        this.tt.onColumnDragEnter(event, this.el.nativeElement);
    }
    onDragLeave(event) {
        this.tt.onColumnDragLeave(event);
    }
    onDrop(event) {
        if (this.isEnabled()) {
            this.tt.onColumnDrop(event, this.el.nativeElement);
        }
    }
    isEnabled() {
        return this.ttReorderableColumnDisabled() !== true;
    }
    onDestroy() {
        this.unbindEvents();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTReorderableColumn, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: TTReorderableColumn, isStandalone: true, selector: "[ttReorderableColumn]", inputs: { ttReorderableColumnDisabled: { classPropertyName: "ttReorderableColumnDisabled", publicName: "ttReorderableColumnDisabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "drop": "onDrop($event)" } }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTReorderableColumn, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ttReorderableColumn]',
                    host: {
                        '(drop)': 'onDrop($event)'
                    }
                }]
        }], propDecorators: { ttReorderableColumnDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "ttReorderableColumnDisabled", required: false }] }] } });
class TTSelectableRow extends BaseComponent {
    tt = inject(TreeTable);
    tableService = inject(TreeTableService);
    rowNode = input(undefined, { ...(ngDevMode ? { debugName: "rowNode" } : /* istanbul ignore next */ {}), alias: 'ttSelectableRow' });
    ttSelectableRowDisabled = input(undefined, { ...(ngDevMode ? { debugName: "ttSelectableRowDisabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    selected;
    subscription;
    _componentStyle = inject(TreeTableStyle);
    constructor() {
        super();
        if (this.isEnabled()) {
            this.subscription = this.tt.tableService.selectionSource$.subscribe(() => {
                this.selected = this.tt.isSelected(this.rowNode().node);
            });
        }
    }
    onInit() {
        if (this.isEnabled()) {
            this.selected = this.tt.isSelected(this.rowNode().node);
        }
    }
    onClick(event) {
        if (this.isEnabled()) {
            this.tt.handleRowClick({
                originalEvent: event,
                rowNode: this.rowNode()
            });
        }
    }
    onKeyDown(event) {
        switch (event.code) {
            case 'Enter':
            case 'Space':
                this.onEnterKey(event);
                break;
            default:
                break;
        }
    }
    onTouchEnd() {
        if (this.isEnabled()) {
            this.tt.handleRowTouchEnd();
        }
    }
    onEnterKey(event) {
        if (this.tt.selectionMode() === 'checkbox') {
            this.tt.toggleNodeWithCheckbox({
                originalEvent: event,
                rowNode: this.rowNode()
            });
        }
        else {
            this.onClick(event);
        }
        event.preventDefault();
    }
    isEnabled() {
        return this.ttSelectableRowDisabled() !== true;
    }
    onDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTSelectableRow, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: TTSelectableRow, isStandalone: true, selector: "[ttSelectableRow]", inputs: { rowNode: { classPropertyName: "rowNode", publicName: "ttSelectableRow", isSignal: true, isRequired: false, transformFunction: null }, ttSelectableRowDisabled: { classPropertyName: "ttSelectableRowDisabled", publicName: "ttSelectableRowDisabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "onClick($event)", "keydown": "onKeyDown($event)", "touchend": "onTouchEnd()" }, properties: { "class": "cx(\"row\")", "attr.aria-selected": "selected" } }, providers: [TreeTableStyle], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTSelectableRow, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ttSelectableRow]',
                    host: {
                        '[class]': 'cx("row")',
                        '[attr.aria-selected]': 'selected',
                        '(click)': 'onClick($event)',
                        '(keydown)': 'onKeyDown($event)',
                        '(touchend)': 'onTouchEnd()'
                    },
                    providers: [TreeTableStyle]
                }]
        }], ctorParameters: () => [], propDecorators: { rowNode: [{ type: i0.Input, args: [{ isSignal: true, alias: "ttSelectableRow", required: false }] }], ttSelectableRowDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "ttSelectableRowDisabled", required: false }] }] } });
class TTSelectableRowDblClick extends BaseComponent {
    tt = inject(TreeTable);
    tableService = inject(TreeTableService);
    rowNode = input(undefined, { ...(ngDevMode ? { debugName: "rowNode" } : /* istanbul ignore next */ {}), alias: 'ttSelectableRowDblClick' });
    ttSelectableRowDisabled = input(undefined, { ...(ngDevMode ? { debugName: "ttSelectableRowDisabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    selected;
    subscription;
    _componentStyle = inject(TreeTableStyle);
    constructor() {
        super();
        if (this.isEnabled()) {
            this.subscription = this.tt.tableService.selectionSource$.subscribe(() => {
                this.selected = this.tt.isSelected(this.rowNode().node);
            });
        }
    }
    onInit() {
        if (this.isEnabled()) {
            this.selected = this.tt.isSelected(this.rowNode().node);
        }
    }
    onClick(event) {
        if (this.isEnabled()) {
            this.tt.handleRowClick({
                originalEvent: event,
                rowNode: this.rowNode()
            });
        }
    }
    isEnabled() {
        return this.ttSelectableRowDisabled() !== true;
    }
    onDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTSelectableRowDblClick, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: TTSelectableRowDblClick, isStandalone: true, selector: "[ttSelectableRowDblClick]", inputs: { rowNode: { classPropertyName: "rowNode", publicName: "ttSelectableRowDblClick", isSignal: true, isRequired: false, transformFunction: null }, ttSelectableRowDisabled: { classPropertyName: "ttSelectableRowDisabled", publicName: "ttSelectableRowDisabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "dblclick": "onClick($event)" }, properties: { "class": "cx(\"row\")" } }, providers: [TreeTableStyle], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTSelectableRowDblClick, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ttSelectableRowDblClick]',
                    host: {
                        '[class]': 'cx("row")',
                        '(dblclick)': 'onClick($event)'
                    },
                    providers: [TreeTableStyle]
                }]
        }], ctorParameters: () => [], propDecorators: { rowNode: [{ type: i0.Input, args: [{ isSignal: true, alias: "ttSelectableRowDblClick", required: false }] }], ttSelectableRowDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "ttSelectableRowDisabled", required: false }] }] } });
class TTContextMenuRow extends BaseComponent {
    tt = inject(TreeTable);
    tableService = inject(TreeTableService);
    rowNode = input(undefined, { ...(ngDevMode ? { debugName: "rowNode" } : /* istanbul ignore next */ {}), alias: 'ttContextMenuRow' });
    ttContextMenuRowDisabled = input(undefined, { ...(ngDevMode ? { debugName: "ttContextMenuRowDisabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    selected;
    subscription;
    _componentStyle = inject(TreeTableStyle);
    constructor() {
        super();
        if (this.isEnabled()) {
            this.subscription = this.tt.tableService.contextMenuSource$.subscribe((node) => {
                this.selected = node ? this.tt.equals(this.rowNode().node, node) : false;
            });
        }
    }
    onContextMenu(event) {
        if (this.isEnabled()) {
            this.tt.handleRowRightClick({
                originalEvent: event,
                rowNode: this.rowNode()
            });
            this.el.nativeElement.focus();
            event.preventDefault();
        }
    }
    isEnabled() {
        return this.ttContextMenuRowDisabled() !== true;
    }
    onDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTContextMenuRow, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: TTContextMenuRow, isStandalone: true, selector: "[ttContextMenuRow]", inputs: { rowNode: { classPropertyName: "rowNode", publicName: "ttContextMenuRow", isSignal: true, isRequired: false, transformFunction: null }, ttContextMenuRowDisabled: { classPropertyName: "ttContextMenuRowDisabled", publicName: "ttContextMenuRowDisabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "contextmenu": "onContextMenu($event)" }, properties: { "class": "cx(\"contextMenuRow\")", "tabindex": "isEnabled() ? 0 : undefined" } }, providers: [TreeTableStyle], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTContextMenuRow, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ttContextMenuRow]',
                    host: {
                        '[class]': 'cx("contextMenuRow")',
                        '[tabindex]': 'isEnabled() ? 0 : undefined',
                        '(contextmenu)': 'onContextMenu($event)'
                    },
                    providers: [TreeTableStyle]
                }]
        }], ctorParameters: () => [], propDecorators: { rowNode: [{ type: i0.Input, args: [{ isSignal: true, alias: "ttContextMenuRow", required: false }] }], ttContextMenuRowDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "ttContextMenuRowDisabled", required: false }] }] } });
class TTCheckbox extends BaseComponent {
    tt = inject(TreeTable);
    tableService = inject(TreeTableService);
    cd = inject(ChangeDetectorRef);
    hostName = 'TreeTable';
    disabled = input(undefined, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    // eslint-disable-next-line @angular-eslint/no-input-rename -- `value` is published public API; renaming would break consumers.
    rowNode = input(undefined, { ...(ngDevMode ? { debugName: "rowNode" } : /* istanbul ignore next */ {}), alias: 'value' });
    checked;
    partialChecked;
    focused;
    subscription;
    _componentStyle = inject(TreeTableStyle);
    constructor() {
        super();
        this.subscription = this.tt.tableService.selectionSource$.subscribe(() => {
            if (this.tt.selectionKeys()) {
                this.checked = this.tt.isNodeSelected(this.rowNode().node);
                this.partialChecked = this.tt.isNodePartialSelected(this.rowNode().node);
            }
            else {
                this.checked = this.tt.isSelected(this.rowNode().node);
                this.partialChecked = this.rowNode().node.partialSelected;
            }
            this.cd.markForCheck();
        });
    }
    onInit() {
        if (this.tt.selectionKeys()) {
            this.checked = this.tt.isNodeSelected(this.rowNode().node);
            this.partialChecked = this.tt.isNodePartialSelected(this.rowNode().node);
        }
        else {
            // for backward compatibility
            this.checked = this.tt.isSelected(this.rowNode().node);
            this.partialChecked = this.rowNode().node.partialSelected;
        }
    }
    onClick(event) {
        if (!this.disabled()) {
            if (this.tt.selectionKeys()) {
                const _check = !this.checked;
                this.tt.toggleCheckbox({
                    originalEvent: event,
                    check: _check,
                    rowNode: this.rowNode()
                });
            }
            else {
                this.tt.toggleNodeWithCheckbox({
                    originalEvent: event,
                    rowNode: this.rowNode()
                });
            }
        }
        clearSelection();
    }
    onFocus() {
        this.focused = true;
    }
    onBlur() {
        this.focused = false;
    }
    onDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTCheckbox, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: TTCheckbox, isStandalone: true, selector: "p-treeTableCheckbox, p-treetable-checkbox, p-tree-table-checkbox", inputs: { disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, rowNode: { classPropertyName: "rowNode", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, providers: [TreeTableStyle], usesInheritance: true, ngImport: i0, template: `
        <p-checkbox [ngModel]="checked" [pt]="ptm('pcRowCheckbox')" (onChange)="onClick($event)" [binary]="true" [disabled]="disabled()" [indeterminate]="partialChecked" [styleClass]="cx('pcNodeCheckbox')" [tabIndex]="-1" [unstyled]="unstyled()">
            @if (tt.checkboxIconTemplate || tt._checkboxIconTemplate) {
                <ng-template pTemplate="icon">
                    <ng-template *ngTemplateOutlet="tt.checkboxIconTemplate || tt._checkboxIconTemplate; context: { $implicit: checked, partialSelected: partialChecked }"></ng-template>
                </ng-template>
            }
        </p-checkbox>
    `, isInline: true, dependencies: [{ kind: "component", type: Checkbox, selector: "p-checkbox, p-checkBox, p-check-box", inputs: ["hostName", "value", "binary", "ariaLabelledBy", "ariaLabel", "tabindex", "inputId", "inputStyle", "styleClass", "inputClass", "indeterminate", "formControl", "checkboxIcon", "readonly", "autofocus", "trueValue", "falseValue", "variant", "size"], outputs: ["onChange", "onFocus", "onBlur"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTCheckbox, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-treeTableCheckbox, p-treetable-checkbox, p-tree-table-checkbox',
                    template: `
        <p-checkbox [ngModel]="checked" [pt]="ptm('pcRowCheckbox')" (onChange)="onClick($event)" [binary]="true" [disabled]="disabled()" [indeterminate]="partialChecked" [styleClass]="cx('pcNodeCheckbox')" [tabIndex]="-1" [unstyled]="unstyled()">
            @if (tt.checkboxIconTemplate || tt._checkboxIconTemplate) {
                <ng-template pTemplate="icon">
                    <ng-template *ngTemplateOutlet="tt.checkboxIconTemplate || tt._checkboxIconTemplate; context: { $implicit: checked, partialSelected: partialChecked }"></ng-template>
                </ng-template>
            }
        </p-checkbox>
    `,
                    encapsulation: ViewEncapsulation.None,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    providers: [TreeTableStyle],
                    imports: [Bind, Checkbox, FormsModule, PrimeTemplate, NgTemplateOutlet]
                }]
        }], ctorParameters: () => [], propDecorators: { disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], rowNode: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }] } });
class TTHeaderCheckbox extends BaseComponent {
    tt = inject(TreeTable);
    tableService = inject(TreeTableService);
    checked;
    disabled;
    selectionChangeSubscription;
    valueChangeSubscription;
    constructor() {
        super();
        this.valueChangeSubscription = this.tt.tableService.uiUpdateSource$.subscribe(() => {
            this.checked = this.updateCheckedState();
        });
        this.selectionChangeSubscription = this.tt.tableService.selectionSource$.subscribe(() => {
            this.checked = this.updateCheckedState();
        });
    }
    onInit() {
        this.checked = this.updateCheckedState();
    }
    onClick(event) {
        const ttValue = this.tt?.value();
        if ((ttValue || this.tt?.filteredNodes) && ((ttValue && ttValue.length > 0) || (this.tt?.filteredNodes && this.tt.filteredNodes.length > 0))) {
            this.tt?.toggleNodesWithCheckbox(event, !this.checked);
        }
        clearSelection();
    }
    onDestroy() {
        if (this.selectionChangeSubscription) {
            this.selectionChangeSubscription.unsubscribe();
        }
        if (this.valueChangeSubscription) {
            this.valueChangeSubscription.unsubscribe();
        }
    }
    updateCheckedState() {
        this.cd.markForCheck();
        let checked;
        const data = this.tt.filteredNodes || this.tt.value();
        if (data) {
            if (this.tt.selectionKeys()) {
                for (let node of data) {
                    if (this.tt.isNodeSelected(node)) {
                        checked = true;
                    }
                    else {
                        checked = false;
                        break;
                    }
                }
            }
            if (!this.tt.selectionKeys()) {
                // legacy selection support, will be removed in v18
                for (let node of data) {
                    if (this.tt.isSelected(node)) {
                        checked = true;
                    }
                    else {
                        checked = false;
                        break;
                    }
                }
            }
        }
        else {
            checked = false;
        }
        return checked;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTHeaderCheckbox, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: TTHeaderCheckbox, isStandalone: true, selector: "p-treeTableHeaderCheckbox, p-tree-table-header-checkbox, p-treetableheadercheckbox", usesInheritance: true, ngImport: i0, template: `
        <p-checkbox [ngModel]="checked" [pt]="ptm('pcHeaderCheckbox')" (onChange)="onClick($event)" [binary]="true" [disabled]="!tt.value() || tt.value()!.length === 0" [unstyled]="unstyled()">
            @if (tt.headerCheckboxIconTemplate || tt._headerCheckboxIconTemplate) {
                <ng-template pTemplate="icon">
                    <ng-template *ngTemplateOutlet="tt.headerCheckboxIconTemplate || tt._headerCheckboxIconTemplate; context: { $implicit: checked }"></ng-template>
                </ng-template>
            }
        </p-checkbox>
    `, isInline: true, dependencies: [{ kind: "component", type: Checkbox, selector: "p-checkbox, p-checkBox, p-check-box", inputs: ["hostName", "value", "binary", "ariaLabelledBy", "ariaLabel", "tabindex", "inputId", "inputStyle", "styleClass", "inputClass", "indeterminate", "formControl", "checkboxIcon", "readonly", "autofocus", "trueValue", "falseValue", "variant", "size"], outputs: ["onChange", "onFocus", "onBlur"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTHeaderCheckbox, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-treeTableHeaderCheckbox, p-tree-table-header-checkbox, p-treetableheadercheckbox',
                    template: `
        <p-checkbox [ngModel]="checked" [pt]="ptm('pcHeaderCheckbox')" (onChange)="onClick($event)" [binary]="true" [disabled]="!tt.value() || tt.value()!.length === 0" [unstyled]="unstyled()">
            @if (tt.headerCheckboxIconTemplate || tt._headerCheckboxIconTemplate) {
                <ng-template pTemplate="icon">
                    <ng-template *ngTemplateOutlet="tt.headerCheckboxIconTemplate || tt._headerCheckboxIconTemplate; context: { $implicit: checked }"></ng-template>
                </ng-template>
            }
        </p-checkbox>
    `,
                    encapsulation: ViewEncapsulation.None,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    imports: [Bind, Checkbox, FormsModule, PrimeTemplate, NgTemplateOutlet]
                }]
        }], ctorParameters: () => [] });
class TTEditableColumn extends BaseComponent {
    tt = inject(TreeTable);
    zone = inject(NgZone);
    data = input(undefined, { ...(ngDevMode ? { debugName: "data" } : /* istanbul ignore next */ {}), alias: 'ttEditableColumn' });
    field = input(undefined, { ...(ngDevMode ? { debugName: "field" } : /* istanbul ignore next */ {}), alias: 'ttEditableColumnField' });
    ttEditableColumnDisabled = input(undefined, { ...(ngDevMode ? { debugName: "ttEditableColumnDisabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    onAfterViewInit() {
        if (this.isEnabled()) {
            !this.$unstyled() && addClass(this.el.nativeElement, 'p-editable-column');
            this.el?.nativeElement.setAttribute('data-p-editable-column', 'true');
        }
    }
    onClick() {
        if (this.isEnabled()) {
            this.tt.editingCellClick = true;
            if (this.tt.editingCell) {
                if (this.tt.editingCell !== this.el.nativeElement) {
                    if (!this.tt.isEditingCellValid()) {
                        return;
                    }
                    if (this.tt.editingCell)
                        !this.$unstyled() && removeClass(this.tt.editingCell, 'p-cell-editing');
                    this.openCell();
                }
            }
            else {
                this.openCell();
            }
        }
    }
    openCell() {
        const data = this.data();
        const field = this.field();
        this.tt.updateEditingCell(this.el.nativeElement, data, field);
        !this.$unstyled() && addClass(this.el.nativeElement, 'p-cell-editing');
        this.el?.nativeElement.setAttribute('data-p-cell-editing', 'true');
        this.tt.onEditInit.emit({ field: field, data: data });
        this.tt.editingCellClick = true;
        this.zone.runOutsideAngular(() => {
            setTimeout(() => {
                let focusable = findSingle(this.el.nativeElement, 'input, textarea');
                if (focusable) {
                    focusable.focus();
                }
            }, 50);
        });
    }
    closeEditingCell() {
        if (this.tt.editingCell)
            !this.$unstyled() && removeClass(this.tt.editingCell, 'p-checkbox-icon');
        this.tt.editingCell = null;
        this.tt.unbindDocumentEditListener();
    }
    onKeyDown(event) {
        if (this.isEnabled()) {
            //enter
            if (event.keyCode == 13 && !event.shiftKey) {
                if (this.tt.isEditingCellValid()) {
                    if (this.tt.editingCell) {
                        !this.$unstyled() && removeClass(this.tt.editingCell, 'p-cell-editing');
                        this.el?.nativeElement.setAttribute('data-p-cell-editing', 'false');
                    }
                    this.closeEditingCell();
                    this.tt.onEditComplete.emit({ field: this.field(), data: this.data() });
                }
                event.preventDefault();
            }
            //escape
            else if (event.keyCode == 27) {
                if (this.tt.isEditingCellValid()) {
                    if (this.tt.editingCell) {
                        !this.$unstyled() && removeClass(this.tt.editingCell, 'p-cell-editing');
                        this.el?.nativeElement.setAttribute('data-p-cell-editing', 'false');
                    }
                    this.closeEditingCell();
                    this.tt.onEditCancel.emit({ field: this.field(), data: this.data() });
                }
                event.preventDefault();
            }
            //tab
            else if (event.keyCode == 9) {
                this.tt.onEditComplete.emit({ field: this.field(), data: this.data() });
                if (event.shiftKey)
                    this.moveToPreviousCell(event);
                else
                    this.moveToNextCell(event);
            }
        }
    }
    findCell(element) {
        if (element) {
            let cell = element;
            while (cell && !findSingle(cell, '[data-p-cell-editing="true"]')) {
                cell = cell.parentElement;
            }
            return cell;
        }
        else {
            return null;
        }
    }
    moveToPreviousCell(event) {
        let currentCell = this.findCell(event.target);
        let targetCell = this.findPreviousEditableColumn(currentCell);
        if (targetCell) {
            // @ts-expect-error invokeElementMethod's methodName is typed as keyof Element, but 'click' is an HTMLElement method.
            invokeElementMethod(targetCell, 'click', undefined);
            event.preventDefault();
        }
    }
    moveToNextCell(event) {
        let currentCell = this.findCell(event.target);
        let targetCell = this.findNextEditableColumn(currentCell);
        if (targetCell) {
            // @ts-expect-error invokeElementMethod's methodName is typed as keyof Element, but 'click' is an HTMLElement method.
            invokeElementMethod(targetCell, 'click', undefined);
            event.preventDefault();
        }
    }
    findPreviousEditableColumn(cell) {
        let prevCell = cell.previousElementSibling;
        if (!prevCell) {
            let previousRow = cell.parentElement ? cell.parentElement.previousElementSibling : null;
            if (previousRow) {
                prevCell = previousRow.lastElementChild;
            }
        }
        if (prevCell) {
            if (findSingle(prevCell, '[data-p-editable-column="true"]'))
                return prevCell;
            else
                return this.findPreviousEditableColumn(prevCell);
        }
        else {
            return null;
        }
    }
    findNextEditableColumn(cell) {
        let nextCell = cell.nextElementSibling;
        if (!nextCell) {
            let nextRow = cell.parentElement ? cell.parentElement.nextElementSibling : null;
            if (nextRow) {
                nextCell = nextRow.firstElementChild;
            }
        }
        if (nextCell) {
            if (findSingle(nextCell, '[data-p-editable-column="true"]'))
                return nextCell;
            else
                return this.findNextEditableColumn(nextCell);
        }
        else {
            return null;
        }
    }
    isEnabled() {
        return this.ttEditableColumnDisabled() !== true;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTEditableColumn, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: TTEditableColumn, isStandalone: true, selector: "[ttEditableColumn]", inputs: { data: { classPropertyName: "data", publicName: "ttEditableColumn", isSignal: true, isRequired: false, transformFunction: null }, field: { classPropertyName: "field", publicName: "ttEditableColumnField", isSignal: true, isRequired: false, transformFunction: null }, ttEditableColumnDisabled: { classPropertyName: "ttEditableColumnDisabled", publicName: "ttEditableColumnDisabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "onClick()", "keydown": "onKeyDown($event)" } }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTEditableColumn, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ttEditableColumn]',
                    host: {
                        '(click)': 'onClick()',
                        '(keydown)': 'onKeyDown($event)'
                    }
                }]
        }], propDecorators: { data: [{ type: i0.Input, args: [{ isSignal: true, alias: "ttEditableColumn", required: false }] }], field: [{ type: i0.Input, args: [{ isSignal: true, alias: "ttEditableColumnField", required: false }] }], ttEditableColumnDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "ttEditableColumnDisabled", required: false }] }] } });
class TreeTableCellEditor extends BaseComponent {
    tt = inject(TreeTable);
    editableColumn = inject(TTEditableColumn);
    hostName = 'TreeTable';
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptm('cellEditor'));
    }
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    inputTemplate;
    outputTemplate;
    onAfterContentInit() {
        this.templates().forEach((item) => {
            switch (item.getType()) {
                case 'input':
                    this.inputTemplate = item.template;
                    break;
                case 'output':
                    this.outputTemplate = item.template;
                    break;
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeTableCellEditor, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: TreeTableCellEditor, isStandalone: true, selector: "p-treeTableCellEditor, p-treetablecelleditor, p-treetable-cell-editor", queries: [{ propertyName: "templates", predicate: PrimeTemplate, isSignal: true }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        @if (tt.editingCell === editableColumn.el.nativeElement) {
            <ng-container *ngTemplateOutlet="inputTemplate"></ng-container>
        }
        @if (!tt.editingCell || tt.editingCell !== editableColumn.el.nativeElement) {
            <ng-container *ngTemplateOutlet="outputTemplate"></ng-container>
        }
    `, isInline: true, dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeTableCellEditor, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-treeTableCellEditor, p-treetablecelleditor, p-treetable-cell-editor',
                    template: `
        @if (tt.editingCell === editableColumn.el.nativeElement) {
            <ng-container *ngTemplateOutlet="inputTemplate"></ng-container>
        }
        @if (!tt.editingCell || tt.editingCell !== editableColumn.el.nativeElement) {
            <ng-container *ngTemplateOutlet="outputTemplate"></ng-container>
        }
    `,
                    encapsulation: ViewEncapsulation.None,
                    hostDirectives: [Bind],
                    imports: [NgTemplateOutlet]
                }]
        }], propDecorators: { templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class TTRow extends BaseComponent {
    tt = inject(TreeTable);
    el = inject(ElementRef);
    zone = inject(NgZone);
    hostName = 'TreeTable';
    bindDirectiveInstance = inject(Bind, { self: true });
    treeTable = inject(TreeTable);
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptm('row', this.ptmOptions()));
    }
    get level() {
        return this.rowNode()?.['level'] + 1;
    }
    get styleClass() {
        return this.rowNode()?.node['styleClass'] || '';
    }
    get expanded() {
        return this.rowNode()?.node['expanded'];
    }
    rowNode = input(undefined, { ...(ngDevMode ? { debugName: "rowNode" } : /* istanbul ignore next */ {}), alias: 'ttRow' });
    _componentStyle = inject(TreeTableStyle);
    onKeyDown(event) {
        switch (event.code) {
            case 'ArrowDown':
                this.onArrowDownKey(event);
                break;
            case 'ArrowUp':
                this.onArrowUpKey(event);
                break;
            case 'ArrowRight':
                this.onArrowRightKey(event);
                break;
            case 'ArrowLeft':
                this.onArrowLeftKey(event);
                break;
            case 'Tab':
                this.onTabKey();
                break;
            case 'Home':
                this.onHomeKey(event);
                break;
            case 'End':
                this.onEndKey(event);
                break;
            default:
                break;
        }
    }
    onArrowDownKey(event) {
        let nextRow = this.el?.nativeElement?.nextElementSibling;
        if (nextRow) {
            this.focusRowChange(event.currentTarget, nextRow);
        }
        event.preventDefault();
    }
    onArrowUpKey(event) {
        let prevRow = this.el?.nativeElement?.previousElementSibling;
        if (prevRow) {
            this.focusRowChange(event.currentTarget, prevRow);
        }
        event.preventDefault();
    }
    onArrowRightKey(event) {
        const currentTarget = event.currentTarget;
        const isHiddenIcon = findSingle(currentTarget, 'button').style.visibility === 'hidden';
        if (!isHiddenIcon && !this.expanded && this.rowNode().node['children']) {
            this.expand(event);
            currentTarget.tabIndex = -1;
        }
        event.preventDefault();
    }
    onArrowLeftKey(event) {
        const container = this.tt.el?.nativeElement;
        const expandedRows = find(container, '[aria-expanded="true"]');
        const lastExpandedRow = expandedRows[expandedRows.length - 1];
        if (this.expanded) {
            this.collapse(event);
        }
        if (lastExpandedRow) {
            this.tt.toggleRowIndex = getIndex(lastExpandedRow);
        }
        this.restoreFocus();
        event.preventDefault();
    }
    onHomeKey(event) {
        const firstElement = findSingle(this.tt.el?.nativeElement, `tr[aria-level="${this.level}"]`);
        firstElement && focus(firstElement);
        event.preventDefault();
    }
    onEndKey(event) {
        const nodes = find(this.tt.el?.nativeElement, `tr[aria-level="${this.level}"]`);
        const lastElement = nodes[nodes.length - 1];
        focus(lastElement);
        event.preventDefault();
    }
    onTabKey() {
        const rows = this.el.nativeElement ? [...find(this.el.nativeElement.parentNode, 'tr')] : undefined;
        if (rows && isNotEmpty(rows)) {
            const hasSelectedRow = rows.some((row) => getAttribute(row, 'data-p-highlight') || row.getAttribute('aria-selected') === 'true');
            rows.forEach((row) => {
                row.tabIndex = -1;
            });
            if (hasSelectedRow) {
                const selectedNodes = rows.filter((node) => getAttribute(node, 'data-p-highlight') || node.getAttribute('aria-selected') === 'true');
                selectedNodes[0].tabIndex = 0;
                return;
            }
            rows[0].tabIndex = 0;
        }
    }
    expand(event) {
        this.tt.toggleRowIndex = getIndex(this.el.nativeElement);
        this.rowNode().node['expanded'] = true;
        this.tt.updateSerializedValue();
        this.tt.tableService.onUIUpdate(this.tt.value());
        this.rowNode().node['children'] ? this.restoreFocus(this.tt.toggleRowIndex + 1) : this.restoreFocus();
        this.tt.onNodeExpand.emit({
            originalEvent: event,
            node: this.rowNode().node
        });
    }
    collapse(event) {
        this.rowNode().node['expanded'] = false;
        this.tt.updateSerializedValue();
        this.tt.tableService.onUIUpdate(this.tt.value());
        this.tt.onNodeCollapse.emit({ originalEvent: event, node: this.rowNode().node });
    }
    focusRowChange(firstFocusableRow, currentFocusedRow) {
        firstFocusableRow.tabIndex = '-1';
        currentFocusedRow.tabIndex = '0';
        focus(currentFocusedRow);
    }
    restoreFocus(index) {
        this.zone.runOutsideAngular(() => {
            setTimeout(() => {
                const container = this.tt.el?.nativeElement;
                const tbody = findSingle(container, '[data-pc-section="tbody"]');
                const row = tbody?.children?.[index || this.tt.toggleRowIndex || 0];
                const rows = [...find(container, 'tr')];
                rows &&
                    rows.forEach((r) => {
                        if (row && !row.isSameNode(r)) {
                            r.tabIndex = -1;
                        }
                    });
                if (row) {
                    row.tabIndex = 0;
                    row.focus();
                }
            }, 25);
        });
    }
    ptmOptions() {
        return {
            context: {
                selectable: this.treeTable?.rowHover() || this.treeTable.selectionMode() === 'row',
                selected: this.treeTable.isSelected(this.rowNode()?.node),
                scrollable: this.treeTable?.scrollable(),
                rowNode: this.rowNode()
            }
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTRow, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: TTRow, isStandalone: true, selector: "[ttRow]", inputs: { rowNode: { classPropertyName: "rowNode", publicName: "ttRow", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "row" }, listeners: { "keydown": "onKeyDown($event)" }, properties: { "class": "'p-element ' + styleClass", "tabindex": "'0'", "attr.aria-expanded": "expanded", "attr.aria-level": "level" } }, providers: [TreeTableStyle], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TTRow, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ttRow]',
                    host: {
                        '[class]': `'p-element ' + styleClass`,
                        '[tabindex]': "'0'",
                        '[attr.aria-expanded]': 'expanded',
                        '[attr.aria-level]': 'level',
                        role: 'row',
                        '(keydown)': 'onKeyDown($event)'
                    },
                    providers: [TreeTableStyle],
                    hostDirectives: [Bind]
                }]
        }], propDecorators: { rowNode: [{ type: i0.Input, args: [{ isSignal: true, alias: "ttRow", required: false }] }] } });
class TreeTableToggler extends BaseComponent {
    tt = inject(TreeTable);
    hostName = 'TreeTable';
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptm('toggler'));
    }
    rowNode = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "rowNode" }] : /* istanbul ignore next */ []));
    _componentStyle = inject(TreeTableStyle);
    get toggleButtonAriaLabel() {
        return this.config.translation ? (this.rowNode().expanded ? this.config.translation?.aria?.collapseRow : this.config.translation?.aria?.expandRow) : undefined;
    }
    onClick(event) {
        this.rowNode().node.expanded = !this.rowNode().node.expanded;
        if (this.rowNode().node.expanded) {
            this.tt.onNodeExpand.emit({
                originalEvent: event,
                node: this.rowNode().node
            });
        }
        else {
            this.tt.onNodeCollapse.emit({
                originalEvent: event,
                node: this.rowNode().node
            });
        }
        this.tt.updateSerializedValue();
        this.tt.tableService.onUIUpdate(this.tt.value());
        event.preventDefault();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeTableToggler, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: TreeTableToggler, isStandalone: true, selector: "p-treeTableToggler, p-treetabletoggler, p-treetable-toggler", inputs: { rowNode: { classPropertyName: "rowNode", publicName: "rowNode", isSignal: true, isRequired: false, transformFunction: null } }, providers: [TreeTableStyle], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        <button
            type="button"
            [class]="cx('toggler')"
            [pBind]="ptm('rowToggleButton')"
            (click)="onClick($event)"
            tabindex="-1"
            pRipple
            [style.visibility]="rowNode().node.leaf === false || (rowNode().node.children && rowNode().node.children.length) ? 'visible' : 'hidden'"
            [style.marginInlineStart]="rowNode().level * 16 + 'px'"
            [attr.data-pc-group-section]="'rowactionbutton'"
            [attr.aria-label]="toggleButtonAriaLabel"
        >
            @if (!tt.togglerIconTemplate && !tt._togglerIconTemplate()) {
                @if (rowNode().node.expanded) {
                    <svg data-p-icon="chevron-down" [pBind]="ptm('nodetoggleicon')" [attr.aria-hidden]="true" />
                }
                @if (!rowNode().node.expanded) {
                    <svg data-p-icon="chevron-right" [pBind]="ptm('nodetoggleicon')" [attr.aria-hidden]="true" />
                }
            }
            <ng-template *ngTemplateOutlet="tt.togglerIconTemplate || tt._togglerIconTemplate(); context: { $implicit: rowNode().node.expanded }"></ng-template>
        </button>
    `, isInline: true, dependencies: [{ kind: "directive", type: Ripple, selector: "[pRipple]" }, { kind: "directive", type: Bind, selector: "[pBind]", inputs: ["pBind"] }, { kind: "component", type: ChevronDownIcon, selector: "[data-p-icon=\"chevron-down\"]" }, { kind: "component", type: ChevronRightIcon, selector: "[data-p-icon=\"chevron-right\"]" }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeTableToggler, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-treeTableToggler, p-treetabletoggler, p-treetable-toggler',
                    template: `
        <button
            type="button"
            [class]="cx('toggler')"
            [pBind]="ptm('rowToggleButton')"
            (click)="onClick($event)"
            tabindex="-1"
            pRipple
            [style.visibility]="rowNode().node.leaf === false || (rowNode().node.children && rowNode().node.children.length) ? 'visible' : 'hidden'"
            [style.marginInlineStart]="rowNode().level * 16 + 'px'"
            [attr.data-pc-group-section]="'rowactionbutton'"
            [attr.aria-label]="toggleButtonAriaLabel"
        >
            @if (!tt.togglerIconTemplate && !tt._togglerIconTemplate()) {
                @if (rowNode().node.expanded) {
                    <svg data-p-icon="chevron-down" [pBind]="ptm('nodetoggleicon')" [attr.aria-hidden]="true" />
                }
                @if (!rowNode().node.expanded) {
                    <svg data-p-icon="chevron-right" [pBind]="ptm('nodetoggleicon')" [attr.aria-hidden]="true" />
                }
            }
            <ng-template *ngTemplateOutlet="tt.togglerIconTemplate || tt._togglerIconTemplate(); context: { $implicit: rowNode().node.expanded }"></ng-template>
        </button>
    `,
                    encapsulation: ViewEncapsulation.None,
                    providers: [TreeTableStyle],
                    hostDirectives: [Bind],
                    imports: [Ripple, Bind, ChevronDownIcon, ChevronRightIcon, NgTemplateOutlet]
                }]
        }], propDecorators: { rowNode: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowNode", required: false }] }] } });
class TreeTableModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeTableModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: TreeTableModule, imports: [CommonModule,
            PaginatorModule,
            Ripple,
            Scroller,
            SpinnerIcon,
            ArrowDownIcon,
            ArrowUpIcon,
            SortAltIcon,
            SortAmountUpAltIcon,
            SortAmountDownIcon,
            BadgeModule,
            CheckIcon,
            ChevronDownIcon,
            ChevronRightIcon,
            Checkbox,
            SharedModule,
            FormsModule,
            BindModule, TreeTable, TreeTableToggler, TTScrollableView, TTBody, TTSortableColumn, TTSortIcon, TTResizableColumn, TTRow, TTReorderableColumn, TTSelectableRow, TTSelectableRowDblClick, TTContextMenuRow, TTCheckbox, TTHeaderCheckbox, TTEditableColumn, TreeTableCellEditor], exports: [TreeTable, SharedModule, TreeTableToggler, TTSortableColumn, TTSortIcon, TTResizableColumn, TTRow, TTReorderableColumn, TTSelectableRow, TTSelectableRowDblClick, TTContextMenuRow, TTCheckbox, TTHeaderCheckbox, TTEditableColumn, TreeTableCellEditor, Scroller] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeTableModule, imports: [CommonModule,
            PaginatorModule,
            Scroller,
            SpinnerIcon,
            ArrowDownIcon,
            ArrowUpIcon,
            SortAltIcon,
            SortAmountUpAltIcon,
            SortAmountDownIcon,
            BadgeModule,
            CheckIcon,
            ChevronDownIcon,
            ChevronRightIcon,
            Checkbox,
            SharedModule,
            FormsModule,
            BindModule,
            TreeTable,
            TreeTableToggler,
            TTScrollableView,
            TTSortIcon,
            TTCheckbox,
            TTHeaderCheckbox, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeTableModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        PaginatorModule,
                        Ripple,
                        Scroller,
                        SpinnerIcon,
                        ArrowDownIcon,
                        ArrowUpIcon,
                        SortAltIcon,
                        SortAmountUpAltIcon,
                        SortAmountDownIcon,
                        BadgeModule,
                        CheckIcon,
                        ChevronDownIcon,
                        ChevronRightIcon,
                        Checkbox,
                        SharedModule,
                        FormsModule,
                        BindModule,
                        TreeTable,
                        TreeTableToggler,
                        TTScrollableView,
                        TTBody,
                        TTSortableColumn,
                        TTSortIcon,
                        TTResizableColumn,
                        TTRow,
                        TTReorderableColumn,
                        TTSelectableRow,
                        TTSelectableRowDblClick,
                        TTContextMenuRow,
                        TTCheckbox,
                        TTHeaderCheckbox,
                        TTEditableColumn,
                        TreeTableCellEditor
                    ],
                    exports: [
                        TreeTable,
                        SharedModule,
                        TreeTableToggler,
                        TTSortableColumn,
                        TTSortIcon,
                        TTResizableColumn,
                        TTRow,
                        TTReorderableColumn,
                        TTSelectableRow,
                        TTSelectableRowDblClick,
                        TTContextMenuRow,
                        TTCheckbox,
                        TTHeaderCheckbox,
                        TTEditableColumn,
                        TreeTableCellEditor,
                        Scroller
                    ]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { TTBody, TTCheckbox, TTContextMenuRow, TTEditableColumn, TTHeaderCheckbox, TTReorderableColumn, TTResizableColumn, TTRow, TTScrollableView, TTSelectableRow, TTSelectableRowDblClick, TTSortIcon, TTSortableColumn, TreeTable, TreeTableCellEditor, TreeTableClasses, TreeTableModule, TreeTableService, TreeTableStyle, TreeTableToggler };
//# sourceMappingURL=wawjs-ngx-prime-treetable.mjs.map
