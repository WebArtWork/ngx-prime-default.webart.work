import * as i0 from '@angular/core';
import { inject, Service } from '@angular/core';
import { css as css$1, dt, Theme } from '@wawjs/css-prime-styled';
import { style } from '@wawjs/css-prime-styles/base';
import { resolve, minifyCSS } from '@wawjs/css-prime-utils';
import { UseStyle } from '@wawjs/ngx-prime/usestyle';

var base = {
    _loadedStyleNames: new Set(),
    getLoadedStyleNames() {
        return this._loadedStyleNames;
    },
    isStyleNameLoaded(name) {
        return this._loadedStyleNames.has(name);
    },
    setLoadedStyleName(name) {
        this._loadedStyleNames.add(name);
    },
    deleteLoadedStyleName(name) {
        this._loadedStyleNames.delete(name);
    },
    clearLoadedStyleNames() {
        this._loadedStyleNames.clear();
    }
};

const css = /*css*/ `
.p-hidden-accessible {
    border: 0;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
}

.p-hidden-accessible input,
.p-hidden-accessible select {
    transform: scale(0);
}

.p-overflow-hidden {
    overflow: hidden;
    padding-right: dt('scrollbar.width');
}
`;
class BaseStyle {
    name = 'base';
    useStyle = inject(UseStyle);
    css = undefined;
    style = undefined;
    classes = {};
    inlineStyles = {};
    load = (style, options = {}, transform = (cs) => cs) => {
        const computedStyle = transform(css$1 `${resolve(style, { dt })}`);
        return computedStyle ? this.useStyle.use(minifyCSS(computedStyle), { name: this.name, ...options }) : {};
    };
    loadCSS = (options = {}) => this.load(this.css, options);
    loadStyle = (options = {}, style = '') => this.load(this.style, options, (computedStyle = '') => Theme.transformCSS(options.name || this.name, `${computedStyle}${css$1 `${style}`}`));
    loadBaseCSS = (options = {}) => this.load(css, options);
    loadBaseStyle = (options = {}, style$1 = '') => this.load(style, options, (computedStyle = '') => Theme.transformCSS(options.name || this.name, `${computedStyle}${css$1 `${style$1}`}`));
    getCommonTheme = (params) => Theme.getCommon(this.name, params);
    getComponentTheme = (params) => Theme.getComponent(this.name, params);
    getPresetTheme = (preset, selector, params) => Theme.getCustomPreset(this.name, preset, selector, params);
    getLayerOrderThemeCSS = () => Theme.getLayerOrderCSS(this.name);
    getStyleSheet = (extendedCSS = '', props = {}) => {
        if (this.css) {
            const _css = resolve(this.css, { dt });
            const _style = minifyCSS(css$1 `${_css}${extendedCSS}`);
            const _props = Object.entries(props)
                .reduce((acc, [k, v]) => acc.push(`${k}="${v}"`) && acc, [])
                .join(' ');
            return `<style type="text/css" data-ngx-prime-style-id="${this.name}" ${_props}>${_style}</style>`;
        }
        return '';
    };
    getCommonThemeStyleSheet = (params, props = {}) => Theme.getCommonStyleSheet(this.name, params, props);
    getThemeStyleSheet = (params, props = {}) => {
        let css = [Theme.getStyleSheet(this.name, params, props)];
        if (this.style) {
            const name = this.name === 'base' ? 'global-style' : `${this.name}-style`;
            const _css = css$1 `${resolve(this.style, { dt })}`;
            const _style = minifyCSS(Theme.transformCSS(name, _css));
            const _props = Object.entries(props)
                .reduce((acc, [k, v]) => acc.push(`${k}="${v}"`) && acc, [])
                .join(' ');
            css.push(`<style type="text/css" data-ngx-prime-style-id="${name}" ${_props}>${_style}</style>`);
        }
        return css.join('');
    };
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BaseStyle, deps: [], target: i0.ɵɵFactoryTarget.Service });
    static ɵprov = i0.ɵɵngDeclareService({ minVersion: "22.0.0", version: "22.1.2", ngImport: i0, type: BaseStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: BaseStyle, decorators: [{
            type: Service
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { base as Base, BaseStyle };
//# sourceMappingURL=wawjs-ngx-prime-base.mjs.map
