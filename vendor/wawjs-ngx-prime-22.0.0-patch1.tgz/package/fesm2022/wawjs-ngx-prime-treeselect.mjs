import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, forwardRef, InjectionToken, inject, input, booleanAttribute, output, computed, viewChild, contentChild, contentChildren, effect, ContentChild, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { uuid, isNotEmpty, getFocusableElements, getFirstFocusableElement, focus, getLastFocusableElement } from '@wawjs/css-prime-utils';
import { PrimeTemplate, SharedModule } from '@wawjs/ngx-prime/api';
import { AutoFocus } from '@wawjs/ngx-prime/autofocus';
import { PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Chip } from '@wawjs/ngx-prime/chip';
import { Fluid } from '@wawjs/ngx-prime/fluid';
import { TimesIcon, ChevronDownIcon } from '@wawjs/ngx-prime/icons';
import { Overlay } from '@wawjs/ngx-prime/overlay';
import { Tree } from '@wawjs/ngx-prime/tree';
import { style as style$1 } from '@wawjs/css-prime-styles/treeselect';
import { BaseStyle } from '@wawjs/ngx-prime/base';
export * from '@wawjs/ngx-prime/types/treeselect';

const style = /*css*/ `
    ${style$1}

    /* For ngx-prime */

    .p-treeselect.ng-invalid.ng-dirty {
        border-color: dt('treeselect.invalid.border.color');
    }

    p-treeselect.ng-invalid.ng-dirty.p-focus {
        border-color: dt('treeselect.focus.border.color');
    }

    p-treeselect.ng-invalid.ng-dirty .p-treeselect-label.p-placeholder {
        color: dt('treeselect.invalid.placeholder.color');
    }

    .p-treeselect-clear-icon.p-icon {
        flex-shrink: 0;
    }
`;
const inlineStyles = {
    root: ({ instance }) => ({ position: instance.$appendTo() === 'self' ? 'relative' : undefined, ...instance.containerStyle() })
};
const classes = {
    root: ({ instance }) => [
        'p-treeselect p-component p-inputwrapper',
        {
            'p-treeselect-display-chip': instance.display() === 'chip',
            'p-disabled': instance.$disabled(),
            'p-invalid': instance.invalid(),
            'p-focus': instance.focused,
            'p-variant-filled': instance.$variant() === 'filled',
            'p-inputwrapper-filled': !instance.emptyValue,
            'p-inputwrapper-focus': instance.focused || instance.overlayVisible,
            'p-treeselect-open': instance.overlayVisible,
            'p-treeselect-clearable': instance.showClear(),
            'p-treeselect-fluid': instance.hasFluid,
            'p-treeselect-sm p-inputfield-sm': instance.size() === 'small',
            'p-treeselect-lg p-inputfield-lg': instance.size() === 'large'
        }
    ],
    labelContainer: 'p-treeselect-label-container',
    label: ({ instance }) => [
        'p-treeselect-label',
        {
            'p-placeholder': instance.label === instance.placeholder(),
            'p-treeselect-label-empty': !instance.placeholder() && instance.emptyValue
        }
    ],
    clearIcon: 'p-treeselect-clear-icon',
    chip: 'p-treeselect-chip-item',
    pcChip: 'p-treeselect-chip',
    dropdown: 'p-treeselect-dropdown',
    dropdownIcon: 'p-treeselect-dropdown-icon',
    panel: 'p-treeselect-overlay p-component-overlay p-component',
    treeContainer: 'p-treeselect-tree-container',
    emptyMessage: 'p-treeselect-empty-message'
};
class TreeSelectStyle extends BaseStyle {
    name = 'treeselect';
    style = style;
    classes = classes;
    inlineStyles = inlineStyles;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeSelectStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeSelectStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeSelectStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * TreeSelect is a form component to choose from hierarchical data.
 *
 * [Live Demo](https://www.ngx-prime.org/treeselect/)
 *
 * @module treeselectstyle
 *
 */
var TreeSelectClasses;
(function (TreeSelectClasses) {
    /**
     * Class name of the root element
     */
    TreeSelectClasses["root"] = "p-treeselect";
    /**
     * Class name of the label container element
     */
    TreeSelectClasses["labelContainer"] = "p-treeselect-label-container";
    /**
     * Class name of the label element
     */
    TreeSelectClasses["label"] = "p-treeselect-label";
    /**
     * Class name of the chip item element
     */
    TreeSelectClasses["chipItem"] = "p-treeselect-chip-item";
    /**
     * Class name of the clear icon element
     */
    TreeSelectClasses["clearIcon"] = "p-treeselect-clear-icon";
    /**
     * Class name of the chip element
     */
    TreeSelectClasses["pcChip"] = "p-treeselect-chip";
    /**
     * Class name of the dropdown element
     */
    TreeSelectClasses["dropdown"] = "p-treeselect-dropdown";
    /**
     * Class name of the dropdown icon element
     */
    TreeSelectClasses["dropdownIcon"] = "p-treeselect-dropdown-icon";
    /**
     * Class name of the panel element
     */
    TreeSelectClasses["panel"] = "p-treeselect-overlay";
    /**
     * Class name of the tree container element
     */
    TreeSelectClasses["treeContainer"] = "p-treeselect-tree-container";
    /**
     * Class name of the empty message element
     */
    TreeSelectClasses["emptyMessage"] = "p-treeselect-empty-message";
})(TreeSelectClasses || (TreeSelectClasses = {}));

const TREESELECT_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => TreeSelect),
    multi: true
};
const TREESELECT_INSTANCE = new InjectionToken('TREESELECT_INSTANCE');
/**
 * TreeSelect is a form component to choose from hierarchical data.
 * @group Components
 */
class TreeSelect extends BaseEditableHolder {
    componentName = 'TreeSelect';
    $pcTreeSelect = inject(TREESELECT_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    bindDirectiveInstance = inject(Bind, { self: true });
    _componentStyle = inject(TreeSelectStyle);
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    /**
     * Identifier of the underlying input element.
     * @group Props
     */
    inputId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "inputId" }] : /* istanbul ignore next */ []));
    /**
     * Height of the viewport, a scrollbar is defined if height of list exceeds this value.
     * @group Props
     */
    scrollHeight = input('400px', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scrollHeight" }] : /* istanbul ignore next */ []));
    /**
     * Defines how multiple items can be selected, when true metaKey needs to be pressed to select or unselect an item and when set to false selection of each item can be toggled individually. On touch enabled devices, metaKeySelection is turned off automatically.
     * @group Props
     */
    metaKeySelection = input(false, { ...(ngDevMode ? { debugName: "metaKeySelection" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Defines how the selected items are displayed.
     * @group Props
     */
    display = input('comma', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "display" }] : /* istanbul ignore next */ []));
    /**
     * Defines the selection mode.
     * @group Props
     */
    selectionMode = input('single', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectionMode" }] : /* istanbul ignore next */ []));
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex = input('0', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tabindex" }] : /* istanbul ignore next */ []));
    /**
     * Defines a string that labels the input for accessibility.
     * @group Props
     */
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    /**
     * Label to display when there are no selections.
     * @group Props
     */
    placeholder = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "placeholder" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the overlay panel.
     * @group Props
     */
    panelClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "panelClass" }] : /* istanbul ignore next */ []));
    /**
     * Inline style of the panel element.
     * @group Props
     */
    panelStyle = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "panelStyle" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the panel element.
     * @group Props
     */
    panelStyleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "panelStyleClass" }] : /* istanbul ignore next */ []));
    /**
     * Inline style of the container element.
     * @deprecated since v20.0.0, use `style` instead.
     * @group Props
     */
    containerStyle = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "containerStyle" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the container element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    containerStyleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "containerStyleClass" }] : /* istanbul ignore next */ []));
    /**
     * Inline style of the label element.
     * @group Props
     */
    labelStyle = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "labelStyle" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the label element.
     * @group Props
     */
    labelStyleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "labelStyleClass" }] : /* istanbul ignore next */ []));
    /**
     * Specifies the options for the overlay.
     * @group Props
     */
    overlayOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "overlayOptions" }] : /* istanbul ignore next */ []));
    /**
     * Text to display when there are no options available. Defaults to value from ngx-prime locale configuration.
     * @group Props
     */
    emptyMessage = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []));
    /**
     * When specified, displays an input field to filter the items.
     * @group Props
     */
    filter = input(false, { ...(ngDevMode ? { debugName: "filter" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * When filtering is enabled, filterBy decides which field or fields (comma separated) to search against.
     * @group Props
     */
    filterBy = input('label', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterBy" }] : /* istanbul ignore next */ []));
    /**
     * Mode for filtering valid values are "lenient" and "strict". Default is lenient.
     * @group Props
     */
    filterMode = input('lenient', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterMode" }] : /* istanbul ignore next */ []));
    /**
     * Placeholder text to show when filter input is empty.
     * @group Props
     */
    filterPlaceholder = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "filterPlaceholder" }] : /* istanbul ignore next */ []));
    /**
     * Locale to use in filtering. The default locale is the host environment's current locale.
     * @group Props
     */
    filterLocale = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "filterLocale" }] : /* istanbul ignore next */ []));
    /**
     * Determines whether the filter input should be automatically focused when the component is rendered.
     * @group Props
     */
    filterInputAutoFocus = input(true, { ...(ngDevMode ? { debugName: "filterInputAutoFocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether checkbox selections propagate to descendant nodes.
     * @group Props
     */
    propagateSelectionDown = input(true, { ...(ngDevMode ? { debugName: "propagateSelectionDown" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether checkbox selections propagate to ancestor nodes.
     * @group Props
     */
    propagateSelectionUp = input(true, { ...(ngDevMode ? { debugName: "propagateSelectionUp" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * When enabled, a clear icon is displayed to clear the value.
     * @group Props
     */
    showClear = input(false, { ...(ngDevMode ? { debugName: "showClear" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Clears the filter value when hiding the dropdown.
     * @group Props
     */
    resetFilterOnHide = input(true, { ...(ngDevMode ? { debugName: "resetFilterOnHide" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether the data should be loaded on demand during scroll.
     * @group Props
     */
    virtualScroll = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "virtualScroll" }] : /* istanbul ignore next */ []));
    /**
     * Height of an item in the list for VirtualScrolling.
     * @group Props
     */
    virtualScrollItemSize = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "virtualScrollItemSize" }] : /* istanbul ignore next */ []));
    /**
     * Whether to use the scroller feature. The properties of scroller component can be used like an object in it.
     * @group Props
     */
    virtualScrollOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "virtualScrollOptions" }] : /* istanbul ignore next */ []));
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus = input(undefined, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * An array of treenodes.
     * @defaultValue undefined
     * @group Props
     */
    options = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "options" }] : /* istanbul ignore next */ []));
    /**
     * Displays a loader to indicate data load is in progress.
     * @group Props
     */
    loading = input(undefined, { ...(ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Loading mode display.
     * @group Props
     */
    loadingMode = input('mask', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "loadingMode" }] : /* istanbul ignore next */ []));
    /**
     * Specifies the size of the component.
     * @defaultValue undefined
     * @group Props
     */
    size = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "size" }] : /* istanbul ignore next */ []));
    /**
     * Specifies the input variant of the component.
     * @defaultValue undefined
     * @group Props
     */
    variant = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "variant" }] : /* istanbul ignore next */ []));
    /**
     * Spans 100% width of the container when enabled.
     * @defaultValue undefined
     * @group Props
     */
    fluid = input(undefined, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'self'
     * @group Props
     */
    appendTo = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "appendTo" }] : /* istanbul ignore next */ []));
    /**
     * The motion options.
     * @group Props
     */
    motionOptions = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "motionOptions" }] : /* istanbul ignore next */ []));
    /**
     * Callback to invoke when a node is expanded.
     * @param {TreeSelectNodeExpandEvent} event - Custom node expand event.
     * @group Emits
     */
    onNodeExpand = output();
    /**
     * Callback to invoke when a node is collapsed.
     * @param {TreeSelectNodeCollapseEvent} event - Custom node collapse event.
     * @group Emits
     */
    onNodeCollapse = output();
    /**
     * Callback to invoke when the overlay is shown.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onShow = output();
    /**
     * Callback to invoke when the overlay is hidden.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onHide = output();
    /**
     * Callback to invoke when input field is cleared.
     * @group Emits
     */
    onClear = output();
    /**
     * Callback to invoke when data is filtered.
     * @group Emits
     */
    onFilter = output();
    /**
     * Callback to invoke when treeselect gets focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onFocus = output();
    /**
     * Callback to invoke when treeselect loses focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onBlur = output();
    /**
     * Callback to invoke when a node is unselected.
     * @param {TreeNodeUnSelectEvent} event - node unselect event.
     * @group Emits
     */
    onNodeUnselect = output();
    /**
     * Callback to invoke when a node is selected.
     * @param {TreeNodeSelectEvent} event - node select event.
     * @group Emits
     */
    onNodeSelect = output();
    $appendTo = computed(() => this.appendTo() || this.config.overlayAppendTo(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "$appendTo" }] : /* istanbul ignore next */ []));
    focusInput = viewChild('focusInput', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusInput" }] : /* istanbul ignore next */ []));
    filterViewChild = viewChild('filter', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterViewChild" }] : /* istanbul ignore next */ []));
    treeViewChild = viewChild('tree', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "treeViewChild" }] : /* istanbul ignore next */ []));
    panelEl = viewChild('panel', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelEl" }] : /* istanbul ignore next */ []));
    overlayViewChild = viewChild('overlay', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "overlayViewChild" }] : /* istanbul ignore next */ []));
    firstHiddenFocusableElementOnOverlay = viewChild('firstHiddenFocusableEl', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "firstHiddenFocusableElementOnOverlay" }] : /* istanbul ignore next */ []));
    lastHiddenFocusableElementOnOverlay = viewChild('lastHiddenFocusableEl', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "lastHiddenFocusableElementOnOverlay" }] : /* istanbul ignore next */ []));
    $variant = computed(() => this.variant() || this.config.inputStyle() || this.config.inputVariant(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "$variant" }] : /* istanbul ignore next */ []));
    pcFluid = inject(Fluid, { optional: true, host: true, skipSelf: true });
    get hasFluid() {
        return this.fluid() ?? !!this.pcFluid;
    }
    filteredNodes;
    filterValue = null;
    serializedValue;
    /**
     * Custom value template.
     * @param {TreeSelectValueTemplateContext} context - value context.
     * @see {@link TreeSelectValueTemplateContext}
     * @group Templates
     */
    valueTemplate;
    /**
     * Custom header template.
     * @param {TreeSelectHeaderTemplateContext} context - header context.
     * @see {@link TreeSelectHeaderTemplateContext}
     * @group Templates
     */
    headerTemplate = contentChild('header', { ...(ngDevMode ? { debugName: "headerTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom empty message template.
     * @group Templates
     */
    emptyTemplate;
    /**
     * Custom footer template.
     * @param {TreeSelectHeaderTemplateContext} context - footer context.
     * @see {@link TreeSelectHeaderTemplateContext}
     * @group Templates
     */
    footerTemplate = contentChild('footer', { ...(ngDevMode ? { debugName: "footerTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom clear icon template.
     * @group Templates
     */
    clearIconTemplate;
    /**
     * Custom trigger icon template.
     * @group Templates
     */
    triggerIconTemplate;
    /**
     * Custom dropdown icon template.
     * @group Templates
     */
    dropdownIconTemplate;
    /**
     * Custom filter icon template.
     * @group Templates
     */
    filterIconTemplate;
    /**
     * Custom close icon template.
     * @group Templates
     */
    closeIconTemplate = contentChild('closeicon', { ...(ngDevMode ? { debugName: "closeIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom item toggler icon template.
     * @param {TreeSelectItemTogglerIconTemplateContext} context - toggler icon context.
     * @see {@link TreeSelectItemTogglerIconTemplateContext}
     * @group Templates
     */
    itemTogglerIconTemplate;
    /**
     * Custom item checkbox icon template.
     * @param {TreeSelectItemCheckboxIconTemplateContext} context - checkbox icon context.
     * @see {@link TreeSelectItemCheckboxIconTemplateContext}
     * @group Templates
     */
    itemCheckboxIconTemplate;
    /**
     * Custom item loading icon template.
     * @group Templates
     */
    itemLoadingIconTemplate;
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    _valueTemplate;
    _headerTemplate;
    _emptyTemplate;
    _footerTemplate;
    _clearIconTemplate;
    _triggerIconTemplate;
    _filterIconTemplate;
    _closeIconTemplate;
    _itemTogglerIconTemplate;
    _itemCheckboxIconTemplate;
    _itemLoadingIconTemplate;
    _dropdownIconTemplate;
    focused;
    overlayVisible;
    value;
    expandedNodes = [];
    templateMap;
    listId = '';
    constructor() {
        super();
        effect(() => {
            this.options();
            this.updateTreeState();
        });
    }
    onHostClick(event) {
        this.onClick(event);
    }
    onInit() {
        this.listId = uuid('pn_id_') + '_list';
        this.updateTreeState();
    }
    onAfterContentInit() {
        if (this.templates().length) {
            this.templateMap = {};
        }
        this.templates().forEach((item) => {
            switch (item.getType()) {
                case 'value':
                    this._valueTemplate = item.template;
                    break;
                case 'header':
                    this._headerTemplate = item.template;
                    break;
                case 'empty':
                    this._emptyTemplate = item.template;
                    break;
                case 'footer':
                    this._footerTemplate = item.template;
                    break;
                case 'clearicon':
                    this._clearIconTemplate = item.template;
                    break;
                case 'triggericon':
                    this._triggerIconTemplate = item.template;
                    break;
                case 'filtericon':
                    this._filterIconTemplate = item.template;
                    break;
                case 'closeicon':
                    this._closeIconTemplate = item.template;
                    break;
                case 'itemtogglericon':
                    this._itemTogglerIconTemplate = item.template;
                    break;
                case 'itemcheckboxicon':
                    this._itemCheckboxIconTemplate = item.template;
                    break;
                case 'dropdownicon':
                    this._dropdownIconTemplate = item.template;
                    break;
                case 'itemloadingicon':
                    this._itemLoadingIconTemplate = item.template;
                    break;
                default: {
                    //TODO: @deprecated Use "value" template instead
                    const itemName = item.name();
                    if (itemName)
                        this.templateMap[itemName] = item.template;
                    else
                        this.valueTemplate = item.template;
                    break;
                }
            }
        });
    }
    onOverlayBeforeEnter() {
        if (this.filter()) {
            isNotEmpty(this.filterValue) && this.treeViewChild()?._filter(this.filterValue);
            this.filterInputAutoFocus() && this.filterViewChild()?.nativeElement.focus();
        }
        else {
            let panelNativeElement = this.panelEl()?.nativeElement;
            let focusableElements = getFocusableElements(panelNativeElement);
            if (focusableElements && focusableElements.length > 0) {
                focusableElements[0].focus();
            }
        }
    }
    onOverlayBeforeHide() {
        let focusableElements = getFocusableElements(this.el.nativeElement);
        if (focusableElements && focusableElements.length > 0) {
            focusableElements[0].focus();
        }
    }
    onSelectionChange(event) {
        this.value = event;
        this.onModelChange(this.value);
        this.cd.markForCheck();
    }
    onClick(event) {
        if (this.$disabled()) {
            return;
        }
        const section = event.target?.getAttribute?.('data-pc-section');
        if (!this.overlayViewChild()?.el?.nativeElement?.contains(event.target) && section !== 'box' && section !== 'icon') {
            if (this.overlayVisible) {
                this.hide();
            }
            else {
                this.show();
            }
            this.focusInput()?.nativeElement.focus();
        }
    }
    onKeyDown(event) {
        switch (event.code) {
            //down
            case 'ArrowDown':
                if (!this.overlayVisible) {
                    this.show();
                    event.preventDefault();
                }
                this.onArrowDown(event);
                event.preventDefault();
                break;
            //space
            case 'Space':
            case 'Enter':
                if (!this.overlayVisible) {
                    this.show();
                    event.preventDefault();
                }
                break;
            //escape
            case 'Escape':
                if (this.overlayVisible) {
                    this.hide();
                    this.focusInput()?.nativeElement.focus();
                    event.preventDefault();
                }
                break;
            //tab
            case 'Tab':
                this.onTabKey(event);
                break;
            default:
                break;
        }
    }
    onFilterInput(event) {
        this.filterValue = event.target.value;
        const treeViewChild = this.treeViewChild();
        treeViewChild?._filter(this.filterValue);
        this.onFilter.emit({
            filter: this.filterValue,
            filteredValue: treeViewChild?._filteredNodesBacking
        });
        setTimeout(() => {
            this.overlayViewChild()?.alignOverlay();
        });
    }
    onArrowDown(event) {
        const panelEl = this.panelEl();
        if (this.overlayVisible && panelEl?.nativeElement) {
            let focusableElements = getFocusableElements(panelEl.nativeElement, '[data-pc-section="node"]');
            if (focusableElements && focusableElements.length > 0) {
                focusableElements[0].focus();
            }
            event.preventDefault();
        }
    }
    onFirstHiddenFocus(event) {
        const focusInput = this.focusInput();
        const focusableEl = event.relatedTarget === focusInput?.nativeElement ? getFirstFocusableElement(this.overlayViewChild()?.overlayViewChild()?.nativeElement, ':not([data-p-hidden-focusable="true"])') : focusInput?.nativeElement;
        focus(focusableEl);
    }
    onLastHiddenFocus(event) {
        const focusInput = this.focusInput();
        const focusableEl = event.relatedTarget === focusInput?.nativeElement ? getLastFocusableElement(this.overlayViewChild()?.overlayViewChild()?.nativeElement, ':not([data-p-hidden-focusable="true"])') : focusInput?.nativeElement;
        focus(focusableEl);
    }
    show() {
        this.overlayVisible = true;
    }
    hide(event) {
        this.overlayVisible = false;
        this.resetFilter();
        this.onHide.emit(event);
        this.cd.markForCheck();
    }
    clear(event) {
        this.value = null;
        this.resetExpandedNodes();
        this.resetPartialSelected();
        this.onModelChange(this.value);
        this.onClear.emit(undefined);
        event.stopPropagation();
    }
    checkValue() {
        return this.value !== null && isNotEmpty(this.value);
    }
    onTabKey(event, pressedInInputText = false) {
        if (!pressedInInputText) {
            if (this.overlayVisible && this.hasFocusableElements()) {
                focus(event.shiftKey ? this.lastHiddenFocusableElementOnOverlay()?.nativeElement : this.firstHiddenFocusableElementOnOverlay()?.nativeElement);
                event.preventDefault();
            }
            else {
                this.overlayVisible && this.hide(this.filter());
            }
        }
    }
    hasFocusableElements() {
        return getFocusableElements(this.overlayViewChild()?.overlayViewChild()?.nativeElement, ':not([data-p-hidden-focusable="true"])').length > 0;
    }
    resetFilter() {
        if (this.filter() && !this.resetFilterOnHide()) {
            const treeViewChild = this.treeViewChild();
            this.filteredNodes = treeViewChild?._filteredNodesBacking;
            treeViewChild?.resetFilter();
        }
        else {
            this.filterValue = null;
        }
    }
    updateTreeState() {
        if (this.value) {
            let selectedNodes = this.selectionMode() === 'single' ? [this.value] : [...this.value];
            this.resetExpandedNodes();
            this.resetPartialSelected();
            if (selectedNodes && this.options()) {
                this.updateTreeBranchState(null, null, selectedNodes);
            }
        }
    }
    updateTreeBranchState(node, path, selectedNodes) {
        if (node) {
            if (this.isSelected(node)) {
                this.expandPath(path);
                selectedNodes.splice(selectedNodes.indexOf(node), 1);
            }
            if (selectedNodes.length > 0 && node.children) {
                for (let childNode of node.children) {
                    this.updateTreeBranchState(childNode, [...path, node], selectedNodes);
                }
            }
        }
        else {
            for (let childNode of this.options()) {
                this.updateTreeBranchState(childNode, [], selectedNodes);
            }
        }
    }
    expandPath(expandedNodes) {
        for (let node of expandedNodes) {
            node.expanded = true;
        }
        this.expandedNodes = [...expandedNodes];
    }
    nodeExpand(event) {
        this.onNodeExpand.emit(event);
        this.expandedNodes.push(event.node);
        setTimeout(() => {
            this.overlayViewChild()?.alignOverlay();
        });
    }
    nodeCollapse(event) {
        this.onNodeCollapse.emit(event);
        this.expandedNodes.splice(this.expandedNodes.indexOf(event.node), 1);
        setTimeout(() => {
            this.overlayViewChild()?.alignOverlay();
        });
    }
    resetExpandedNodes() {
        for (let node of this.expandedNodes) {
            node.expanded = false;
        }
        this.expandedNodes = [];
    }
    resetPartialSelected(nodes = this.options()) {
        if (!nodes) {
            return;
        }
        for (let node of nodes) {
            node.partialSelected = false;
            if (node.children && node.children?.length > 0) {
                this.resetPartialSelected(node.children);
            }
        }
    }
    findSelectedNodes(node, keys, selectedNodes) {
        if (node) {
            if (this.isSelected(node)) {
                selectedNodes.push(node);
                delete keys[node.key];
            }
            if (Object.keys(keys).length && node.children) {
                for (let childNode of node.children) {
                    this.findSelectedNodes(childNode, keys, selectedNodes);
                }
            }
        }
        else {
            for (let childNode of this.options()) {
                this.findSelectedNodes(childNode, keys, selectedNodes);
            }
        }
    }
    isSelected(node) {
        return this.findIndexInSelection(node) != -1;
    }
    findIndexInSelection(node) {
        let index = -1;
        if (this.value) {
            if (this.selectionMode() === 'single') {
                let areNodesEqual = (this.value.key && this.value.key === node.key) || this.value == node;
                index = areNodesEqual ? 0 : -1;
            }
            else {
                for (let i = 0; i < this.value.length; i++) {
                    let selectedNode = this.value[i];
                    let areNodesEqual = (selectedNode.key && selectedNode.key === node.key) || selectedNode == node;
                    if (areNodesEqual) {
                        index = i;
                        break;
                    }
                }
            }
        }
        return index;
    }
    onSelect(event) {
        this.onNodeSelect.emit(event);
        if (this.selectionMode() === 'single') {
            this.hide();
            this.focusInput()?.nativeElement.focus();
        }
    }
    onUnselect(event) {
        this.onNodeUnselect.emit(event);
    }
    onInputFocus(event) {
        if (this.$disabled()) {
            // For ScreenReaders
            return;
        }
        this.focused = true;
        this.onFocus.emit(event);
    }
    onInputBlur(event) {
        this.focused = false;
        this.onBlur.emit(event);
        this.onModelTouched();
    }
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value) {
        this.value = value;
        this.updateTreeState();
        this.cd.markForCheck();
    }
    get emptyValue() {
        return !this.value || Object.keys(this.value).length === 0;
    }
    get emptyOptions() {
        return !this.options() || this.options().length === 0;
    }
    get label() {
        let value = this.value || [];
        return value.length ? value.map((node) => node.label).join(', ') : this.selectionMode() === 'single' && this.value ? value.label : this.placeholder();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeSelect, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: TreeSelect, isStandalone: true, selector: "p-treeSelect, p-treeselect, p-tree-select", inputs: { inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, scrollHeight: { classPropertyName: "scrollHeight", publicName: "scrollHeight", isSignal: true, isRequired: false, transformFunction: null }, metaKeySelection: { classPropertyName: "metaKeySelection", publicName: "metaKeySelection", isSignal: true, isRequired: false, transformFunction: null }, display: { classPropertyName: "display", publicName: "display", isSignal: true, isRequired: false, transformFunction: null }, selectionMode: { classPropertyName: "selectionMode", publicName: "selectionMode", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, panelClass: { classPropertyName: "panelClass", publicName: "panelClass", isSignal: true, isRequired: false, transformFunction: null }, panelStyle: { classPropertyName: "panelStyle", publicName: "panelStyle", isSignal: true, isRequired: false, transformFunction: null }, panelStyleClass: { classPropertyName: "panelStyleClass", publicName: "panelStyleClass", isSignal: true, isRequired: false, transformFunction: null }, containerStyle: { classPropertyName: "containerStyle", publicName: "containerStyle", isSignal: true, isRequired: false, transformFunction: null }, containerStyleClass: { classPropertyName: "containerStyleClass", publicName: "containerStyleClass", isSignal: true, isRequired: false, transformFunction: null }, labelStyle: { classPropertyName: "labelStyle", publicName: "labelStyle", isSignal: true, isRequired: false, transformFunction: null }, labelStyleClass: { classPropertyName: "labelStyleClass", publicName: "labelStyleClass", isSignal: true, isRequired: false, transformFunction: null }, overlayOptions: { classPropertyName: "overlayOptions", publicName: "overlayOptions", isSignal: true, isRequired: false, transformFunction: null }, emptyMessage: { classPropertyName: "emptyMessage", publicName: "emptyMessage", isSignal: true, isRequired: false, transformFunction: null }, filter: { classPropertyName: "filter", publicName: "filter", isSignal: true, isRequired: false, transformFunction: null }, filterBy: { classPropertyName: "filterBy", publicName: "filterBy", isSignal: true, isRequired: false, transformFunction: null }, filterMode: { classPropertyName: "filterMode", publicName: "filterMode", isSignal: true, isRequired: false, transformFunction: null }, filterPlaceholder: { classPropertyName: "filterPlaceholder", publicName: "filterPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, filterLocale: { classPropertyName: "filterLocale", publicName: "filterLocale", isSignal: true, isRequired: false, transformFunction: null }, filterInputAutoFocus: { classPropertyName: "filterInputAutoFocus", publicName: "filterInputAutoFocus", isSignal: true, isRequired: false, transformFunction: null }, propagateSelectionDown: { classPropertyName: "propagateSelectionDown", publicName: "propagateSelectionDown", isSignal: true, isRequired: false, transformFunction: null }, propagateSelectionUp: { classPropertyName: "propagateSelectionUp", publicName: "propagateSelectionUp", isSignal: true, isRequired: false, transformFunction: null }, showClear: { classPropertyName: "showClear", publicName: "showClear", isSignal: true, isRequired: false, transformFunction: null }, resetFilterOnHide: { classPropertyName: "resetFilterOnHide", publicName: "resetFilterOnHide", isSignal: true, isRequired: false, transformFunction: null }, virtualScroll: { classPropertyName: "virtualScroll", publicName: "virtualScroll", isSignal: true, isRequired: false, transformFunction: null }, virtualScrollItemSize: { classPropertyName: "virtualScrollItemSize", publicName: "virtualScrollItemSize", isSignal: true, isRequired: false, transformFunction: null }, virtualScrollOptions: { classPropertyName: "virtualScrollOptions", publicName: "virtualScrollOptions", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, loadingMode: { classPropertyName: "loadingMode", publicName: "loadingMode", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null }, appendTo: { classPropertyName: "appendTo", publicName: "appendTo", isSignal: true, isRequired: false, transformFunction: null }, motionOptions: { classPropertyName: "motionOptions", publicName: "motionOptions", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onNodeExpand: "onNodeExpand", onNodeCollapse: "onNodeCollapse", onShow: "onShow", onHide: "onHide", onClear: "onClear", onFilter: "onFilter", onFocus: "onFocus", onBlur: "onBlur", onNodeUnselect: "onNodeUnselect", onNodeSelect: "onNodeSelect" }, host: { listeners: { "mousedown": "onHostClick($event)" }, properties: { "class": "cn(cx('root'), containerStyleClass())", "style": "sx('root')" } }, providers: [
            TREESELECT_VALUE_ACCESSOR,
            TreeSelectStyle,
            {
                provide: TREESELECT_INSTANCE,
                useExisting: TreeSelect
            },
            {
                provide: PARENT_INSTANCE,
                useExisting: TreeSelect
            }
        ], queries: [{ propertyName: "headerTemplate", first: true, predicate: ["header"], isSignal: true }, { propertyName: "footerTemplate", first: true, predicate: ["footer"], isSignal: true }, { propertyName: "closeIconTemplate", first: true, predicate: ["closeicon"], isSignal: true }, { propertyName: "templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "valueTemplate", first: true, predicate: ["value"] }, { propertyName: "emptyTemplate", first: true, predicate: ["empty"] }, { propertyName: "clearIconTemplate", first: true, predicate: ["clearicon"] }, { propertyName: "triggerIconTemplate", first: true, predicate: ["triggericon"] }, { propertyName: "dropdownIconTemplate", first: true, predicate: ["dropdownicon"] }, { propertyName: "filterIconTemplate", first: true, predicate: ["filtericon"] }, { propertyName: "itemTogglerIconTemplate", first: true, predicate: ["itemtogglericon"] }, { propertyName: "itemCheckboxIconTemplate", first: true, predicate: ["itemcheckboxicon"] }, { propertyName: "itemLoadingIconTemplate", first: true, predicate: ["itemloadingicon"] }], viewQueries: [{ propertyName: "focusInput", first: true, predicate: ["focusInput"], descendants: true, isSignal: true }, { propertyName: "filterViewChild", first: true, predicate: ["filter"], descendants: true, isSignal: true }, { propertyName: "treeViewChild", first: true, predicate: ["tree"], descendants: true, isSignal: true }, { propertyName: "panelEl", first: true, predicate: ["panel"], descendants: true, isSignal: true }, { propertyName: "overlayViewChild", first: true, predicate: ["overlay"], descendants: true, isSignal: true }, { propertyName: "firstHiddenFocusableElementOnOverlay", first: true, predicate: ["firstHiddenFocusableEl"], descendants: true, isSignal: true }, { propertyName: "lastHiddenFocusableElementOnOverlay", first: true, predicate: ["lastHiddenFocusableEl"], descendants: true, isSignal: true }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        <div class="p-hidden-accessible" [pBind]="ptm('hiddenInputContainer')" [attr.data-p-hidden-accessible]="true">
            <input
                #focusInput
                type="text"
                role="combobox"
                [attr.id]="inputId()"
                readonly
                [attr.disabled]="$disabled() ? '' : undefined"
                (focus)="onInputFocus($event)"
                (blur)="onInputBlur($event)"
                (keydown)="onKeyDown($event)"
                [attr.tabindex]="!$disabled() ? tabindex() : -1"
                [attr.aria-controls]="overlayVisible ? listId : null"
                [attr.aria-haspopup]="'tree'"
                [attr.aria-expanded]="overlayVisible ?? false"
                [attr.aria-labelledby]="ariaLabelledBy()"
                [attr.aria-label]="ariaLabel() || (label === 'p-emptylabel' ? undefined : label)"
                [pAutoFocus]="autofocus()"
                [pBind]="ptm('hiddenInput')"
            />
        </div>
        <div [class]="cx('labelContainer')" [pBind]="ptm('labelContainer')">
            <div [class]="cn(cx('label'), labelStyleClass())" [ngStyle]="labelStyle()" [pBind]="ptm('label')">
                @if (valueTemplate || _valueTemplate) {
                    <ng-container *ngTemplateOutlet="valueTemplate || _valueTemplate; context: { $implicit: value, placeholder: placeholder() }"></ng-container>
                } @else {
                    @if (display() === 'comma') {
                        {{ label || 'empty' }}
                    } @else {
                        @for (node of value; track node) {
                            <div [class]="cx('chipItem')" [pBind]="ptm('chipItem')">
                                <p-chip [unstyled]="unstyled()" [label]="node.label" [class]="cx('pcChip')" [pt]="ptm('pcChip')" />
                            </div>
                        }
                        @if (emptyValue) {
                            {{ placeholder() || 'empty' }}
                        }
                    }
                }
            </div>
        </div>
        @if (checkValue() && !$disabled() && showClear()) {
            @if (!clearIconTemplate && !_clearIconTemplate) {
                <svg data-p-icon="times" [class]="cx('clearIcon')" (click)="clear($event)" [pBind]="ptm('clearIcon')" />
            }
            @if (clearIconTemplate || clearIconTemplate) {
                <span [class]="cx('clearIcon')" (click)="clear($event)" [pBind]="ptm('clearIcon')">
                    <ng-template *ngTemplateOutlet="clearIconTemplate || _clearIconTemplate"></ng-template>
                </span>
            }
        }
        <div [class]="cx('dropdown')" role="button" aria-haspopup="tree" [attr.aria-expanded]="overlayVisible ?? false" [attr.aria-label]="'treeselect trigger'" [pBind]="ptm('dropdown')">
            @if (!triggerIconTemplate && !_triggerIconTemplate && !dropdownIconTemplate && !_dropdownIconTemplate) {
                <svg data-p-icon="chevron-down" [class]="cx('dropdownIcon')" [pBind]="ptm('dropdownIcon')" />
            }
            @if (triggerIconTemplate || _triggerIconTemplate || dropdownIconTemplate || _dropdownIconTemplate) {
                <span [class]="cx('dropdownIcon')" [pBind]="ptm('dropdownIcon')">
                    <ng-template *ngTemplateOutlet="triggerIconTemplate || _triggerIconTemplate || dropdownIconTemplate || _dropdownIconTemplate"></ng-template>
                </span>
            }
        </div>
        <p-overlay
            #overlay
            [hostAttrSelector]="$attrSelector"
            [(visible)]="overlayVisible"
            [options]="overlayOptions()"
            [target]="'@parent'"
            [appendTo]="$appendTo()"
            [unstyled]="unstyled()"
            [pt]="ptm('pcOverlay')"
            [motionOptions]="motionOptions()"
            (onBeforeEnter)="onOverlayBeforeEnter()"
            (onBeforeHide)="onOverlayBeforeHide()"
            (onShow)="onShow.emit($event)"
            (onHide)="hide($event)"
        >
            <ng-template #content>
                <div #panel [attr.id]="listId" [class]="cn(cx('panel'), panelStyleClass(), panelClass())" [ngStyle]="panelStyle()" [pBind]="ptm('panel')">
                    <span
                        #firstHiddenFocusableEl
                        role="presentation"
                        class="p-hidden-accessible p-hidden-focusable"
                        [attr.tabindex]="0"
                        (focus)="onFirstHiddenFocus($event)"
                        [attr.data-p-hidden-accessible]="true"
                        [attr.data-p-hidden-focusable]="true"
                        [pBind]="ptm('hiddenFirstFocusableEl')"
                    >
                    </span>
                    <ng-container *ngTemplateOutlet="headerTemplate() || _headerTemplate; context: { $implicit: value, options: options() }"></ng-container>
                    <div [class]="cx('treeContainer')" [ngStyle]="{ 'max-height': scrollHeight() }" [pBind]="ptm('treeContainer')">
                        <p-tree
                            #tree
                            [value]="options()"
                            [propagateSelectionDown]="propagateSelectionDown()"
                            [propagateSelectionUp]="propagateSelectionUp()"
                            [selectionMode]="selectionMode()"
                            (selectionChange)="onSelectionChange($event)"
                            [selection]="value"
                            [metaKeySelection]="metaKeySelection()"
                            (onNodeExpand)="nodeExpand($event)"
                            (onNodeCollapse)="nodeCollapse($event)"
                            (onNodeSelect)="onSelect($event)"
                            [emptyMessage]="emptyMessage()"
                            (onNodeUnselect)="onUnselect($event)"
                            [filter]="filter()"
                            [filterBy]="filterBy()"
                            [filterMode]="filterMode()"
                            [filterPlaceholder]="filterPlaceholder()"
                            [filterLocale]="filterLocale()"
                            [filteredNodes]="filteredNodes"
                            [virtualScroll]="virtualScroll()"
                            [virtualScrollItemSize]="virtualScrollItemSize()"
                            [virtualScrollOptions]="virtualScrollOptions()"
                            [_templateMap]="templateMap"
                            [loading]="loading()"
                            [filterInputAutoFocus]="filterInputAutoFocus()"
                            [loadingMode]="loadingMode()"
                            [pt]="ptm('pcTree')"
                            [unstyled]="unstyled()"
                        >
                            @if (emptyTemplate || _emptyTemplate) {
                                <ng-template #empty>
                                    <ng-container *ngTemplateOutlet="emptyTemplate || _emptyTemplate"></ng-container>
                                </ng-template>
                            }
                            @if (itemTogglerIconTemplate || _itemTogglerIconTemplate; as expanded) {
                                <ng-template #togglericon let-expanded>
                                    <ng-container *ngTemplateOutlet="itemTogglerIconTemplate || _itemTogglerIconTemplate; context: { $implicit: expanded }"></ng-container>
                                </ng-template>
                            }
                            @if (itemCheckboxIconTemplate || _itemCheckboxIconTemplate) {
                                <ng-template #checkboxicon let-selected let-partialSelected="partialSelected">
                                    <ng-container *ngTemplateOutlet="itemCheckboxIconTemplate || _itemCheckboxIconTemplate; context: { $implicit: selected, partialSelected: partialSelected }"></ng-container>
                                </ng-template>
                            }
                            @if (itemLoadingIconTemplate || _itemLoadingIconTemplate) {
                                <ng-template #loadingicon>
                                    <ng-container *ngTemplateOutlet="itemLoadingIconTemplate || _itemLoadingIconTemplate"></ng-container>
                                </ng-template>
                            }
                            @if (filterIconTemplate || _filterIconTemplate) {
                                <ng-template #filtericon>
                                    <ng-container *ngTemplateOutlet="filterIconTemplate || _filterIconTemplate"></ng-container>
                                </ng-template>
                            }
                        </p-tree>
                    </div>
                    <ng-container *ngTemplateOutlet="footerTemplate(); context: { $implicit: value, options: options() }"></ng-container>
                    <span
                        #lastHiddenFocusableEl
                        role="presentation"
                        class="p-hidden-accessible p-hidden-focusable"
                        [attr.tabindex]="0"
                        (focus)="onLastHiddenFocus($event)"
                        [attr.data-p-hidden-accessible]="true"
                        [attr.data-p-hidden-focusable]="true"
                        [pBind]="ptm('hiddenLastFocusableEl')"
                    ></span>
                </div>
            </ng-template>
        </p-overlay>
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: Overlay, selector: "p-overlay", inputs: ["hostName", "visible", "mode", "style", "styleClass", "contentStyle", "contentStyleClass", "target", "autoZIndex", "baseZIndex", "showTransitionOptions", "hideTransitionOptions", "listener", "responsive", "options", "appendTo", "inline", "motionOptions", "hostAttrSelector"], outputs: ["visibleChange", "onBeforeShow", "onShow", "onBeforeHide", "onHide", "onAnimationStart", "onAnimationDone", "onBeforeEnter", "onEnter", "onAfterEnter", "onBeforeLeave", "onLeave", "onAfterLeave"] }, { kind: "ngmodule", type: SharedModule }, { kind: "component", type: Tree, selector: "p-tree", inputs: ["value", "selectionMode", "loadingMode", "selection", "styleClass", "contextMenu", "contextMenuSelectionMode", "contextMenuSelection", "draggableScope", "droppableScope", "draggableNodes", "droppableNodes", "metaKeySelection", "propagateSelectionUp", "propagateSelectionDown", "loading", "loadingIcon", "emptyMessage", "ariaLabel", "togglerAriaLabel", "ariaLabelledBy", "validateDrop", "filter", "filterInputAutoFocus", "filterBy", "filterMode", "filterOptions", "filterPlaceholder", "filteredNodes", "filterLocale", "scrollHeight", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "indentation", "_templateMap", "trackBy", "highlightOnSelect"], outputs: ["selectionChange", "contextMenuSelectionChange", "onNodeSelect", "onNodeUnselect", "onNodeExpand", "onNodeCollapse", "onNodeContextMenuSelect", "onNodeDoubleClick", "onNodeDrop", "onLazyLoad", "onScroll", "onScrollIndexChange", "onFilter"] }, { kind: "directive", type: AutoFocus, selector: "[pAutoFocus]", inputs: ["pAutoFocus"] }, { kind: "component", type: TimesIcon, selector: "[data-p-icon=\"times\"]" }, { kind: "component", type: ChevronDownIcon, selector: "[data-p-icon=\"chevron-down\"]" }, { kind: "component", type: Chip, selector: "p-chip", inputs: ["label", "icon", "image", "alt", "styleClass", "disabled", "removable", "removeIcon", "chipProps"], outputs: ["onRemove", "onImageError"] }, { kind: "directive", type: Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeSelect, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-treeSelect, p-treeselect, p-tree-select',
                    standalone: true,
                    imports: [CommonModule, Overlay, SharedModule, Tree, AutoFocus, TimesIcon, ChevronDownIcon, Chip, Bind],
                    hostDirectives: [Bind],
                    template: `
        <div class="p-hidden-accessible" [pBind]="ptm('hiddenInputContainer')" [attr.data-p-hidden-accessible]="true">
            <input
                #focusInput
                type="text"
                role="combobox"
                [attr.id]="inputId()"
                readonly
                [attr.disabled]="$disabled() ? '' : undefined"
                (focus)="onInputFocus($event)"
                (blur)="onInputBlur($event)"
                (keydown)="onKeyDown($event)"
                [attr.tabindex]="!$disabled() ? tabindex() : -1"
                [attr.aria-controls]="overlayVisible ? listId : null"
                [attr.aria-haspopup]="'tree'"
                [attr.aria-expanded]="overlayVisible ?? false"
                [attr.aria-labelledby]="ariaLabelledBy()"
                [attr.aria-label]="ariaLabel() || (label === 'p-emptylabel' ? undefined : label)"
                [pAutoFocus]="autofocus()"
                [pBind]="ptm('hiddenInput')"
            />
        </div>
        <div [class]="cx('labelContainer')" [pBind]="ptm('labelContainer')">
            <div [class]="cn(cx('label'), labelStyleClass())" [ngStyle]="labelStyle()" [pBind]="ptm('label')">
                @if (valueTemplate || _valueTemplate) {
                    <ng-container *ngTemplateOutlet="valueTemplate || _valueTemplate; context: { $implicit: value, placeholder: placeholder() }"></ng-container>
                } @else {
                    @if (display() === 'comma') {
                        {{ label || 'empty' }}
                    } @else {
                        @for (node of value; track node) {
                            <div [class]="cx('chipItem')" [pBind]="ptm('chipItem')">
                                <p-chip [unstyled]="unstyled()" [label]="node.label" [class]="cx('pcChip')" [pt]="ptm('pcChip')" />
                            </div>
                        }
                        @if (emptyValue) {
                            {{ placeholder() || 'empty' }}
                        }
                    }
                }
            </div>
        </div>
        @if (checkValue() && !$disabled() && showClear()) {
            @if (!clearIconTemplate && !_clearIconTemplate) {
                <svg data-p-icon="times" [class]="cx('clearIcon')" (click)="clear($event)" [pBind]="ptm('clearIcon')" />
            }
            @if (clearIconTemplate || clearIconTemplate) {
                <span [class]="cx('clearIcon')" (click)="clear($event)" [pBind]="ptm('clearIcon')">
                    <ng-template *ngTemplateOutlet="clearIconTemplate || _clearIconTemplate"></ng-template>
                </span>
            }
        }
        <div [class]="cx('dropdown')" role="button" aria-haspopup="tree" [attr.aria-expanded]="overlayVisible ?? false" [attr.aria-label]="'treeselect trigger'" [pBind]="ptm('dropdown')">
            @if (!triggerIconTemplate && !_triggerIconTemplate && !dropdownIconTemplate && !_dropdownIconTemplate) {
                <svg data-p-icon="chevron-down" [class]="cx('dropdownIcon')" [pBind]="ptm('dropdownIcon')" />
            }
            @if (triggerIconTemplate || _triggerIconTemplate || dropdownIconTemplate || _dropdownIconTemplate) {
                <span [class]="cx('dropdownIcon')" [pBind]="ptm('dropdownIcon')">
                    <ng-template *ngTemplateOutlet="triggerIconTemplate || _triggerIconTemplate || dropdownIconTemplate || _dropdownIconTemplate"></ng-template>
                </span>
            }
        </div>
        <p-overlay
            #overlay
            [hostAttrSelector]="$attrSelector"
            [(visible)]="overlayVisible"
            [options]="overlayOptions()"
            [target]="'@parent'"
            [appendTo]="$appendTo()"
            [unstyled]="unstyled()"
            [pt]="ptm('pcOverlay')"
            [motionOptions]="motionOptions()"
            (onBeforeEnter)="onOverlayBeforeEnter()"
            (onBeforeHide)="onOverlayBeforeHide()"
            (onShow)="onShow.emit($event)"
            (onHide)="hide($event)"
        >
            <ng-template #content>
                <div #panel [attr.id]="listId" [class]="cn(cx('panel'), panelStyleClass(), panelClass())" [ngStyle]="panelStyle()" [pBind]="ptm('panel')">
                    <span
                        #firstHiddenFocusableEl
                        role="presentation"
                        class="p-hidden-accessible p-hidden-focusable"
                        [attr.tabindex]="0"
                        (focus)="onFirstHiddenFocus($event)"
                        [attr.data-p-hidden-accessible]="true"
                        [attr.data-p-hidden-focusable]="true"
                        [pBind]="ptm('hiddenFirstFocusableEl')"
                    >
                    </span>
                    <ng-container *ngTemplateOutlet="headerTemplate() || _headerTemplate; context: { $implicit: value, options: options() }"></ng-container>
                    <div [class]="cx('treeContainer')" [ngStyle]="{ 'max-height': scrollHeight() }" [pBind]="ptm('treeContainer')">
                        <p-tree
                            #tree
                            [value]="options()"
                            [propagateSelectionDown]="propagateSelectionDown()"
                            [propagateSelectionUp]="propagateSelectionUp()"
                            [selectionMode]="selectionMode()"
                            (selectionChange)="onSelectionChange($event)"
                            [selection]="value"
                            [metaKeySelection]="metaKeySelection()"
                            (onNodeExpand)="nodeExpand($event)"
                            (onNodeCollapse)="nodeCollapse($event)"
                            (onNodeSelect)="onSelect($event)"
                            [emptyMessage]="emptyMessage()"
                            (onNodeUnselect)="onUnselect($event)"
                            [filter]="filter()"
                            [filterBy]="filterBy()"
                            [filterMode]="filterMode()"
                            [filterPlaceholder]="filterPlaceholder()"
                            [filterLocale]="filterLocale()"
                            [filteredNodes]="filteredNodes"
                            [virtualScroll]="virtualScroll()"
                            [virtualScrollItemSize]="virtualScrollItemSize()"
                            [virtualScrollOptions]="virtualScrollOptions()"
                            [_templateMap]="templateMap"
                            [loading]="loading()"
                            [filterInputAutoFocus]="filterInputAutoFocus()"
                            [loadingMode]="loadingMode()"
                            [pt]="ptm('pcTree')"
                            [unstyled]="unstyled()"
                        >
                            @if (emptyTemplate || _emptyTemplate) {
                                <ng-template #empty>
                                    <ng-container *ngTemplateOutlet="emptyTemplate || _emptyTemplate"></ng-container>
                                </ng-template>
                            }
                            @if (itemTogglerIconTemplate || _itemTogglerIconTemplate; as expanded) {
                                <ng-template #togglericon let-expanded>
                                    <ng-container *ngTemplateOutlet="itemTogglerIconTemplate || _itemTogglerIconTemplate; context: { $implicit: expanded }"></ng-container>
                                </ng-template>
                            }
                            @if (itemCheckboxIconTemplate || _itemCheckboxIconTemplate) {
                                <ng-template #checkboxicon let-selected let-partialSelected="partialSelected">
                                    <ng-container *ngTemplateOutlet="itemCheckboxIconTemplate || _itemCheckboxIconTemplate; context: { $implicit: selected, partialSelected: partialSelected }"></ng-container>
                                </ng-template>
                            }
                            @if (itemLoadingIconTemplate || _itemLoadingIconTemplate) {
                                <ng-template #loadingicon>
                                    <ng-container *ngTemplateOutlet="itemLoadingIconTemplate || _itemLoadingIconTemplate"></ng-container>
                                </ng-template>
                            }
                            @if (filterIconTemplate || _filterIconTemplate) {
                                <ng-template #filtericon>
                                    <ng-container *ngTemplateOutlet="filterIconTemplate || _filterIconTemplate"></ng-container>
                                </ng-template>
                            }
                        </p-tree>
                    </div>
                    <ng-container *ngTemplateOutlet="footerTemplate(); context: { $implicit: value, options: options() }"></ng-container>
                    <span
                        #lastHiddenFocusableEl
                        role="presentation"
                        class="p-hidden-accessible p-hidden-focusable"
                        [attr.tabindex]="0"
                        (focus)="onLastHiddenFocus($event)"
                        [attr.data-p-hidden-accessible]="true"
                        [attr.data-p-hidden-focusable]="true"
                        [pBind]="ptm('hiddenLastFocusableEl')"
                    ></span>
                </div>
            </ng-template>
        </p-overlay>
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    providers: [
                        TREESELECT_VALUE_ACCESSOR,
                        TreeSelectStyle,
                        {
                            provide: TREESELECT_INSTANCE,
                            useExisting: TreeSelect
                        },
                        {
                            provide: PARENT_INSTANCE,
                            useExisting: TreeSelect
                        }
                    ],
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class]': "cn(cx('root'), containerStyleClass())",
                        '[style]': "sx('root')",
                        '(mousedown)': 'onHostClick($event)'
                    }
                }]
        }], ctorParameters: () => [], propDecorators: { inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], scrollHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollHeight", required: false }] }], metaKeySelection: [{ type: i0.Input, args: [{ isSignal: true, alias: "metaKeySelection", required: false }] }], display: [{ type: i0.Input, args: [{ isSignal: true, alias: "display", required: false }] }], selectionMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectionMode", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], panelClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelClass", required: false }] }], panelStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelStyle", required: false }] }], panelStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelStyleClass", required: false }] }], containerStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "containerStyle", required: false }] }], containerStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "containerStyleClass", required: false }] }], labelStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelStyle", required: false }] }], labelStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelStyleClass", required: false }] }], overlayOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "overlayOptions", required: false }] }], emptyMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyMessage", required: false }] }], filter: [{ type: i0.Input, args: [{ isSignal: true, alias: "filter", required: false }] }], filterBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterBy", required: false }] }], filterMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterMode", required: false }] }], filterPlaceholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterPlaceholder", required: false }] }], filterLocale: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterLocale", required: false }] }], filterInputAutoFocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterInputAutoFocus", required: false }] }], propagateSelectionDown: [{ type: i0.Input, args: [{ isSignal: true, alias: "propagateSelectionDown", required: false }] }], propagateSelectionUp: [{ type: i0.Input, args: [{ isSignal: true, alias: "propagateSelectionUp", required: false }] }], showClear: [{ type: i0.Input, args: [{ isSignal: true, alias: "showClear", required: false }] }], resetFilterOnHide: [{ type: i0.Input, args: [{ isSignal: true, alias: "resetFilterOnHide", required: false }] }], virtualScroll: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScroll", required: false }] }], virtualScrollItemSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScrollItemSize", required: false }] }], virtualScrollOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScrollOptions", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], loadingMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "loadingMode", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], appendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "appendTo", required: false }] }], motionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "motionOptions", required: false }] }], onNodeExpand: [{ type: i0.Output, args: ["onNodeExpand"] }], onNodeCollapse: [{ type: i0.Output, args: ["onNodeCollapse"] }], onShow: [{ type: i0.Output, args: ["onShow"] }], onHide: [{ type: i0.Output, args: ["onHide"] }], onClear: [{ type: i0.Output, args: ["onClear"] }], onFilter: [{ type: i0.Output, args: ["onFilter"] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], onNodeUnselect: [{ type: i0.Output, args: ["onNodeUnselect"] }], onNodeSelect: [{ type: i0.Output, args: ["onNodeSelect"] }], focusInput: [{ type: i0.ViewChild, args: ['focusInput', { isSignal: true }] }], filterViewChild: [{ type: i0.ViewChild, args: ['filter', { isSignal: true }] }], treeViewChild: [{ type: i0.ViewChild, args: ['tree', { isSignal: true }] }], panelEl: [{ type: i0.ViewChild, args: ['panel', { isSignal: true }] }], overlayViewChild: [{ type: i0.ViewChild, args: ['overlay', { isSignal: true }] }], firstHiddenFocusableElementOnOverlay: [{ type: i0.ViewChild, args: ['firstHiddenFocusableEl', { isSignal: true }] }], lastHiddenFocusableElementOnOverlay: [{ type: i0.ViewChild, args: ['lastHiddenFocusableEl', { isSignal: true }] }], valueTemplate: [{
                type: ContentChild,
                args: ['value', { descendants: false }]
            }], headerTemplate: [{ type: i0.ContentChild, args: ['header', { ...{ descendants: false }, isSignal: true }] }], emptyTemplate: [{
                type: ContentChild,
                args: ['empty', { descendants: false }]
            }], footerTemplate: [{ type: i0.ContentChild, args: ['footer', { ...{ descendants: false }, isSignal: true }] }], clearIconTemplate: [{
                type: ContentChild,
                args: ['clearicon', { descendants: false }]
            }], triggerIconTemplate: [{
                type: ContentChild,
                args: ['triggericon', { descendants: false }]
            }], dropdownIconTemplate: [{
                type: ContentChild,
                args: ['dropdownicon', { descendants: false }]
            }], filterIconTemplate: [{
                type: ContentChild,
                args: ['filtericon', { descendants: false }]
            }], closeIconTemplate: [{ type: i0.ContentChild, args: ['closeicon', { ...{ descendants: false }, isSignal: true }] }], itemTogglerIconTemplate: [{
                type: ContentChild,
                args: ['itemtogglericon', { descendants: false }]
            }], itemCheckboxIconTemplate: [{
                type: ContentChild,
                args: ['itemcheckboxicon', { descendants: false }]
            }], itemLoadingIconTemplate: [{
                type: ContentChild,
                args: ['itemloadingicon', { descendants: false }]
            }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class TreeSelectModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeSelectModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: TreeSelectModule, imports: [TreeSelect, SharedModule], exports: [TreeSelect, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeSelectModule, imports: [TreeSelect, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TreeSelectModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [TreeSelect, SharedModule],
                    exports: [TreeSelect, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { TREESELECT_VALUE_ACCESSOR, TreeSelect, TreeSelectClasses, TreeSelectModule, TreeSelectStyle };
//# sourceMappingURL=wawjs-ngx-prime-treeselect.mjs.map
