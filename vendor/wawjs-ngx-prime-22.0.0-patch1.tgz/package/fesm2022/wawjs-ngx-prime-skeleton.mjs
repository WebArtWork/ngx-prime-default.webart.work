import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, input, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { SharedModule } from '@wawjs/ngx-prime/api';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { style } from '@wawjs/css-prime-styles/skeleton';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const inlineStyles = {
    root: { position: 'relative' }
};
const classes = {
    root: ({ instance }) => [
        'p-skeleton p-component',
        {
            'p-skeleton-circle': instance.shape() === 'circle',
            'p-skeleton-animation-none': instance.animation() === 'none'
        }
    ]
};
class SkeletonStyle extends BaseStyle {
    name = 'skeleton';
    style = style;
    classes = classes;
    inlineStyles = inlineStyles;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SkeletonStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SkeletonStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SkeletonStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * Skeleton is a placeholder to display instead of the actual content.
 *
 * [Live Demo](https://www.ngx-prime.org/skeleton/)
 *
 * @module skeletonstyle
 *
 */
var SkeletonClasses;
(function (SkeletonClasses) {
    /**
     * Class name of the root element
     */
    SkeletonClasses["root"] = "p-skeleton";
})(SkeletonClasses || (SkeletonClasses = {}));

const SKELETON_INSTANCE = new InjectionToken('SKELETON_INSTANCE');
/**
 * Skeleton is a placeholder to display instead of the actual content.
 * @group Components
 */
class Skeleton extends BaseComponent {
    componentName = 'Skeleton';
    $pcSkeleton = inject(SKELETON_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    /**
     * Class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Shape of the element.
     * @group Props
     */
    shape = input('rectangle', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "shape" }] : /* istanbul ignore next */ []));
    /**
     * Type of the animation.
     * @gruop Props
     */
    animation = input('wave', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "animation" }] : /* istanbul ignore next */ []));
    /**
     * Border radius of the element, defaults to value from theme.
     * @group Props
     */
    borderRadius = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "borderRadius" }] : /* istanbul ignore next */ []));
    /**
     * Size of the skeleton.
     * @group Props
     */
    size = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "size" }] : /* istanbul ignore next */ []));
    /**
     * Width of the element.
     * @group Props
     */
    width = input('100%', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "width" }] : /* istanbul ignore next */ []));
    /**
     * Height of the element.
     * @group Props
     */
    height = input('1rem', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "height" }] : /* istanbul ignore next */ []));
    _componentStyle = inject(SkeletonStyle);
    get containerStyle() {
        const inlineStyles = this._componentStyle?.inlineStyles['root'];
        let style;
        if (!this.$unstyled()) {
            if (this.size())
                style = { ...inlineStyles, width: this.size(), height: this.size(), borderRadius: this.borderRadius() };
            else
                style = { ...inlineStyles, width: this.width(), height: this.height(), borderRadius: this.borderRadius() };
        }
        return style;
    }
    get dataP() {
        return this.cn({
            [this.shape()]: this.shape()
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Skeleton, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.2", type: Skeleton, isStandalone: true, selector: "p-skeleton", inputs: { styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, shape: { classPropertyName: "shape", publicName: "shape", isSignal: true, isRequired: false, transformFunction: null }, animation: { classPropertyName: "animation", publicName: "animation", isSignal: true, isRequired: false, transformFunction: null }, borderRadius: { classPropertyName: "borderRadius", publicName: "borderRadius", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, width: { classPropertyName: "width", publicName: "width", isSignal: true, isRequired: false, transformFunction: null }, height: { classPropertyName: "height", publicName: "height", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.aria-hidden": "true", "class": "cn(cx('root'), styleClass())", "style": "containerStyle", "attr.data-p": "dataP" } }, providers: [SkeletonStyle, { provide: SKELETON_INSTANCE, useExisting: Skeleton }, { provide: PARENT_INSTANCE, useExisting: Skeleton }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: ``, isInline: true, dependencies: [{ kind: "ngmodule", type: SharedModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Skeleton, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-skeleton',
                    standalone: true,
                    imports: [SharedModule],
                    template: ``,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [SkeletonStyle, { provide: SKELETON_INSTANCE, useExisting: Skeleton }, { provide: PARENT_INSTANCE, useExisting: Skeleton }],
                    host: {
                        '[attr.aria-hidden]': 'true',
                        '[class]': "cn(cx('root'), styleClass())",
                        '[style]': 'containerStyle',
                        '[attr.data-p]': 'dataP'
                    },
                    hostDirectives: [Bind]
                }]
        }], propDecorators: { styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], shape: [{ type: i0.Input, args: [{ isSignal: true, alias: "shape", required: false }] }], animation: [{ type: i0.Input, args: [{ isSignal: true, alias: "animation", required: false }] }], borderRadius: [{ type: i0.Input, args: [{ isSignal: true, alias: "borderRadius", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], width: [{ type: i0.Input, args: [{ isSignal: true, alias: "width", required: false }] }], height: [{ type: i0.Input, args: [{ isSignal: true, alias: "height", required: false }] }] } });
class SkeletonModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SkeletonModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: SkeletonModule, imports: [Skeleton, SharedModule], exports: [Skeleton, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SkeletonModule, imports: [Skeleton, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SkeletonModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [Skeleton, SharedModule],
                    exports: [Skeleton, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { Skeleton, SkeletonClasses, SkeletonModule, SkeletonStyle };
//# sourceMappingURL=wawjs-ngx-prime-skeleton.mjs.map
