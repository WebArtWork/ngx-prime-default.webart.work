import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, forwardRef, inject, input, numberAttribute, booleanAttribute, output, ChangeDetectionStrategy, ViewEncapsulation, Component, viewChild, contentChild, signal, computed, contentChildren, effect, ContentChild, NgModule } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { resolveFieldData, isNotEmpty, equals, getOffset, getViewport, getHiddenElementOuterWidth, getOuterWidth, calculateScrollbarWidth, uuid, isPrintableCharacter, isEmpty, findSingle, findLastIndex, focus } from '@wawjs/css-prime-utils';
import { SharedModule, OverlayService, TranslationKeys, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { AutoFocus } from '@wawjs/ngx-prime/autofocus';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i2 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { Fluid } from '@wawjs/ngx-prime/fluid';
import { AngleRightIcon, ChevronDownIcon, TimesIcon } from '@wawjs/ngx-prime/icons';
import { Overlay } from '@wawjs/ngx-prime/overlay';
import { Ripple } from '@wawjs/ngx-prime/ripple';
import { style as style$1 } from '@wawjs/css-prime-styles/cascadeselect';
import { BaseStyle } from '@wawjs/ngx-prime/base';
export * from '@wawjs/ngx-prime/types/cascadeselect';

const style = /*css*/ `
    ${style$1}

    /* For ngx-prime */
    .p-cascadeselect.ng-invalid.ng-dirty:not(.ng-untouched):not(.ng-pristine) {
        border-color: dt('cascadeselect.invalid.border.color');
    }

    .p-cascadeselect.ng-invalid.ng-dirty:not(.ng-untouched):not(.ng-pristine) .p-cascadeselect-label.p-placeholder {
        color: dt('cascadeselect.invalid.placeholder.color');
    }
`;
const inlineStyles = {
    root: ({ instance }) => ({ position: instance.$appendTo() === 'self' ? 'relative' : undefined })
};
const classes = {
    root: ({ instance }) => [
        'p-cascadeselect p-component p-inputwrapper',
        {
            'p-cascadeselect p-component p-inputwrapper': true,
            'p-cascadeselect-clearable': instance.showClear() && !instance.$disabled(),
            'p-cascadeselect-mobile': instance.queryMatches(),
            'p-disabled': instance.$disabled(),
            'p-invalid': instance.invalid(),
            'p-focus': instance.focused,
            'p-inputwrapper-filled': instance.modelValue(),
            'p-variant-filled': instance.$variant() === 'filled',
            'p-inputwrapper-focus': instance.focused || instance.overlayVisible,
            'p-cascadeselect-open': instance.overlayVisible,
            'p-cascadeselect-fluid': instance.hasFluid,
            'p-cascadeselect-sm p-inputfield-sm': instance.size() === 'small',
            'p-cascadeselect-lg p-inputfield-lg': instance.size() === 'large'
        }
    ],
    label: ({ instance }) => [
        'p-cascadeselect-label',
        {
            'p-placeholder': instance.label() === instance.placeholder(),
            'p-cascadeselect-label-empty': !instance.modelValue() && (instance.label() === 'p-emptylabel' || instance.label().length === 0)
        }
    ],
    clearIcon: 'p-cascadeselect-clear-icon',
    dropdown: 'p-cascadeselect-dropdown',
    loadingIcon: 'p-cascadeselect-loading-icon',
    dropdownIcon: 'p-cascadeselect-dropdown-icon',
    overlay: ({ instance }) => [
        'p-cascadeselect-overlay p-component-overlay p-component',
        {
            'p-cascadeselect-mobile-active': instance.queryMatches()
        }
    ],
    listContainer: 'p-cascadeselect-list-container',
    list: 'p-cascadeselect-list',
    option: ({ instance, processedOption }) => [
        'p-cascadeselect-option',
        {
            'p-cascadeselect-option-group': instance.isOptionGroup(processedOption),
            'p-cascadeselect-option-active': instance.isOptionActive(processedOption),
            'p-cascadeselect-option-selected': instance.isOptionSelected(processedOption),
            'p-focus': instance.isOptionFocused(processedOption),
            'p-disabled': instance.isOptionDisabled(processedOption)
        }
    ],
    optionContent: 'p-cascadeselect-option-content',
    optionText: 'p-cascadeselect-option-text',
    groupIcon: 'p-cascadeselect-group-icon',
    optionList: 'p-cascadeselect-list p-cascadeselect-overlay p-cascadeselect-option-list'
};
class CascadeSelectStyle extends BaseStyle {
    name = 'cascadeselect';
    style = style;
    classes = classes;
    inlineStyles = inlineStyles;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CascadeSelectStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CascadeSelectStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CascadeSelectStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * CascadeSelect is a form component to select a value from a nested structure of options.
 *
 * [Live Demo](https://www.ngx-prime.org/cascadeselect/)
 *
 * @module cascadeselectstyle
 *
 */
var CascadeSelectClasses;
(function (CascadeSelectClasses) {
    /**
     * Class name of the root element
     */
    CascadeSelectClasses["root"] = "p-cascadeselect";
    /**
     * Class name of the label element
     */
    CascadeSelectClasses["label"] = "p-cascadeselect-label";
    /**
     * Class name of the dropdown element
     */
    CascadeSelectClasses["dropdown"] = "p-cascadeselect-dropdown";
    /**
     * Class name of the loading icon element
     */
    CascadeSelectClasses["loadingIcon"] = "p-cascadeselect-loading-icon";
    /**
     * Class name of the dropdown icon element
     */
    CascadeSelectClasses["clearIcon"] = "p-cascadeselect-clear-icon";
    /**
     * Class name of the dropdown icon element
     */
    CascadeSelectClasses["dropdownIcon"] = "p-cascadeselect-dropdown-icon";
    /**
     * Class name of the overlay element
     */
    CascadeSelectClasses["overlay"] = "p-cascadeselect-overlay";
    /**
     * Class name of the list container element
     */
    CascadeSelectClasses["listContainer"] = "p-cascadeselect-list-container";
    /**
     * Class name of the list element
     */
    CascadeSelectClasses["list"] = "p-cascadeselect-list";
    /**
     * Class name of the item element
     */
    CascadeSelectClasses["item"] = "p-cascadeselect-item";
    /**
     * Class name of the item content element
     */
    CascadeSelectClasses["itemContent"] = "p-cascadeselect-item-content";
    /**
     * Class name of the item text element
     */
    CascadeSelectClasses["itemText"] = "p-cascadeselect-item-text";
    /**
     * Class name of the group icon element
     */
    CascadeSelectClasses["groupIcon"] = "p-cascadeselect-group-icon";
    /**
     * Class name of the item list element
     */
    CascadeSelectClasses["itemList"] = "p-cascadeselect-item-list";
})(CascadeSelectClasses || (CascadeSelectClasses = {}));

const CASCADESELECT_INSTANCE = new InjectionToken('CASCADESELECT_INSTANCE');
const CASCADESELECT_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => CascadeSelect),
    multi: true
};
class CascadeSelectSub extends BaseComponent {
    cascadeselect = inject(CascadeSelect);
    selectId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "selectId" }] : /* istanbul ignore next */ []));
    activeOptionPath = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeOptionPath" }] : /* istanbul ignore next */ []));
    optionDisabled = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "optionDisabled" }] : /* istanbul ignore next */ []));
    focusedOptionId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "focusedOptionId" }] : /* istanbul ignore next */ []));
    options = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "options" }] : /* istanbul ignore next */ []));
    optionGroupChildren = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "optionGroupChildren" }] : /* istanbul ignore next */ []));
    optionTemplate = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "optionTemplate" }] : /* istanbul ignore next */ []));
    groupicon = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "groupicon" }] : /* istanbul ignore next */ []));
    level = input(0, { ...(ngDevMode ? { debugName: "level" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    optionLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "optionLabel" }] : /* istanbul ignore next */ []));
    optionValue = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "optionValue" }] : /* istanbul ignore next */ []));
    optionGroupLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "optionGroupLabel" }] : /* istanbul ignore next */ []));
    dirty = input(undefined, { ...(ngDevMode ? { debugName: "dirty" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    root = input(undefined, { ...(ngDevMode ? { debugName: "root" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    onChange = output();
    onFocusChange = output();
    onFocusEnterChange = output();
    _componentStyle = inject(CascadeSelectStyle);
    getPTOptions(processedOption, index, key) {
        return this.ptm(key, {
            context: {
                option: processedOption,
                index,
                level: this.level(),
                optionGroup: this.isOptionGroup(processedOption),
                active: this.isOptionActive(processedOption),
                focused: this.isOptionFocused(processedOption),
                disabled: this.isOptionDisabled(processedOption)
            }
        });
    }
    onInit() {
        if (!this.root()) {
            this.position();
        }
    }
    onOptionClick(event, processedOption) {
        this.onChange.emit({
            originalEvent: event,
            processedOption,
            isFocus: true
        });
    }
    onOptionMouseEnter(event, processedOption) {
        this.onFocusEnterChange.emit({ originalEvent: event, processedOption });
    }
    onOptionMouseMove(event, processedOption) {
        this.onFocusChange.emit({ originalEvent: event, processedOption });
    }
    getOptionId(processedOption) {
        return `${this.selectId()}_${processedOption.key}`;
    }
    getOptionLabel(processedOption) {
        const optionLabel = this.optionLabel();
        return optionLabel ? resolveFieldData(processedOption.option, optionLabel) : processedOption.option;
    }
    getOptionValue(processedOption) {
        const optionValue = this.optionValue();
        return optionValue ? resolveFieldData(processedOption.option, optionValue) : processedOption.option;
    }
    getOptionLabelToRender(processedOption) {
        return this.isOptionGroup(processedOption) ? this.getOptionGroupLabel(processedOption) : this.getOptionLabel(processedOption);
    }
    isOptionDisabled(processedOption) {
        const optionDisabled = this.optionDisabled();
        return optionDisabled ? resolveFieldData(processedOption.option, optionDisabled) : false;
    }
    getOptionGroupLabel(processedOption) {
        const optionGroupLabel = this.optionGroupLabel();
        return optionGroupLabel ? resolveFieldData(processedOption.option, optionGroupLabel) : null;
    }
    getOptionGroupChildren(processedOption) {
        return processedOption.children;
    }
    isOptionGroup(processedOption) {
        return isNotEmpty(processedOption.children);
    }
    isOptionSelected(processedOption) {
        return equals(this.cascadeselect?.modelValue(), processedOption?.option);
    }
    isOptionActive(processedOption) {
        return this.activeOptionPath().some((path) => path.key === processedOption.key);
    }
    isOptionFocused(processedOption) {
        return this.focusedOptionId() === this.getOptionId(processedOption);
    }
    position() {
        const parentItem = this.el.nativeElement.parentElement;
        const containerOffset = getOffset(parentItem);
        const viewport = getViewport();
        const sublistWidth = this.el.nativeElement.childNodes[0].offsetParent ? this.el.nativeElement.children[0].offsetWidth : getHiddenElementOuterWidth(this.el.nativeElement.children[0]);
        const itemOuterWidth = getOuterWidth(parentItem.children[0]);
        if (parseInt(containerOffset.left, 10) + itemOuterWidth + sublistWidth > viewport.width - calculateScrollbarWidth()) {
            this.el.nativeElement.children[0].style.left = '-200%';
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CascadeSelectSub, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: CascadeSelectSub, isStandalone: true, selector: "ul[pCascadeSelectSub]", inputs: { selectId: { classPropertyName: "selectId", publicName: "selectId", isSignal: true, isRequired: false, transformFunction: null }, activeOptionPath: { classPropertyName: "activeOptionPath", publicName: "activeOptionPath", isSignal: true, isRequired: false, transformFunction: null }, optionDisabled: { classPropertyName: "optionDisabled", publicName: "optionDisabled", isSignal: true, isRequired: false, transformFunction: null }, focusedOptionId: { classPropertyName: "focusedOptionId", publicName: "focusedOptionId", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, optionGroupChildren: { classPropertyName: "optionGroupChildren", publicName: "optionGroupChildren", isSignal: true, isRequired: false, transformFunction: null }, optionTemplate: { classPropertyName: "optionTemplate", publicName: "optionTemplate", isSignal: true, isRequired: false, transformFunction: null }, groupicon: { classPropertyName: "groupicon", publicName: "groupicon", isSignal: true, isRequired: false, transformFunction: null }, level: { classPropertyName: "level", publicName: "level", isSignal: true, isRequired: false, transformFunction: null }, optionLabel: { classPropertyName: "optionLabel", publicName: "optionLabel", isSignal: true, isRequired: false, transformFunction: null }, optionValue: { classPropertyName: "optionValue", publicName: "optionValue", isSignal: true, isRequired: false, transformFunction: null }, optionGroupLabel: { classPropertyName: "optionGroupLabel", publicName: "optionGroupLabel", isSignal: true, isRequired: false, transformFunction: null }, dirty: { classPropertyName: "dirty", publicName: "dirty", isSignal: true, isRequired: false, transformFunction: null }, root: { classPropertyName: "root", publicName: "root", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onChange: "onChange", onFocusChange: "onFocusChange", onFocusEnterChange: "onFocusEnterChange" }, providers: [CascadeSelectStyle, { provide: PARENT_INSTANCE, useExisting: CascadeSelectSub }], usesInheritance: true, ngImport: i0, template: `
        @for (processedOption of options(); track processedOption; let i = $index) {
            <li
                [class]="cx('option', { processedOption })"
                role="treeitem"
                [attr.aria-level]="level() + 1"
                [attr.aria-setsize]="options().length"
                [pBind]="getPTOptions(processedOption, i, 'option')"
                [id]="getOptionId(processedOption)"
                [attr.aria-label]="getOptionLabelToRender(processedOption)"
                [attr.aria-selected]="isOptionGroup(processedOption) ? undefined : isOptionSelected(processedOption)"
                [attr.aria-posinset]="i + 1"
            >
                <div
                    [class]="cx('optionContent')"
                    (click)="onOptionClick($event, processedOption)"
                    (mouseenter)="onOptionMouseEnter($event, processedOption)"
                    (mousemove)="onOptionMouseMove($event, processedOption)"
                    pRipple
                    [pBind]="getPTOptions(processedOption, i, 'optionContent')"
                >
                    @if (optionTemplate()) {
                        <ng-container *ngTemplateOutlet="optionTemplate(); context: { $implicit: processedOption?.option, level: level() }"></ng-container>
                    } @else {
                        <span [class]="cx('optionText')" [pBind]="getPTOptions(processedOption, i, 'optionText')">{{ getOptionLabelToRender(processedOption) }}</span>
                    }
                    @if (isOptionGroup(processedOption)) {
                        <span [class]="cx('groupIcon')" [pBind]="getPTOptions(processedOption, i, 'groupIcon')">
                            @if (!groupicon()) {
                                <svg data-p-icon="angle-right" [pBind]="getPTOptions(processedOption, index, 'groupIcon')" />
                            }
                            <ng-template *ngTemplateOutlet="groupicon()"></ng-template>
                        </span>
                    }
                </div>
                @if (isOptionGroup(processedOption) && isOptionActive(processedOption)) {
                    <ul
                        pCascadeSelectSub
                        [attrrole]="'group'"
                        [class]="cx('optionList')"
                        [selectId]="selectId()"
                        [focusedOptionId]="focusedOptionId()"
                        [activeOptionPath]="activeOptionPath()"
                        [options]="getOptionGroupChildren(processedOption)"
                        [optionLabel]="optionLabel()"
                        [optionValue]="optionValue()"
                        [level]="level() + 1"
                        (onChange)="onChange.emit($event)"
                        (onFocusChange)="onFocusChange.emit($event)"
                        (onFocusEnterChange)="onFocusEnterChange.emit($event)"
                        [optionGroupLabel]="optionGroupLabel()"
                        [optionGroupChildren]="optionGroupChildren()"
                        [dirty]="dirty()"
                        [optionTemplate]="optionTemplate()"
                        [pBind]="ptm('optionList')"
                        [pt]="pt"
                        [unstyled]="unstyled()"
                    ></ul>
                }
            </li>
        }
    `, isInline: true, dependencies: [{ kind: "component", type: CascadeSelectSub, selector: "ul[pCascadeSelectSub]", inputs: ["selectId", "activeOptionPath", "optionDisabled", "focusedOptionId", "options", "optionGroupChildren", "optionTemplate", "groupicon", "level", "optionLabel", "optionValue", "optionGroupLabel", "dirty", "root"], outputs: ["onChange", "onFocusChange", "onFocusEnterChange"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: Ripple, selector: "[pRipple]" }, { kind: "component", type: AngleRightIcon, selector: "[data-p-icon=\"angle-right\"]" }, { kind: "ngmodule", type: SharedModule }, { kind: "directive", type: Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CascadeSelectSub, decorators: [{
            type: Component,
            args: [{
                    selector: 'ul[pCascadeSelectSub]',
                    standalone: true,
                    imports: [CommonModule, Ripple, AngleRightIcon, SharedModule, Bind],
                    template: `
        @for (processedOption of options(); track processedOption; let i = $index) {
            <li
                [class]="cx('option', { processedOption })"
                role="treeitem"
                [attr.aria-level]="level() + 1"
                [attr.aria-setsize]="options().length"
                [pBind]="getPTOptions(processedOption, i, 'option')"
                [id]="getOptionId(processedOption)"
                [attr.aria-label]="getOptionLabelToRender(processedOption)"
                [attr.aria-selected]="isOptionGroup(processedOption) ? undefined : isOptionSelected(processedOption)"
                [attr.aria-posinset]="i + 1"
            >
                <div
                    [class]="cx('optionContent')"
                    (click)="onOptionClick($event, processedOption)"
                    (mouseenter)="onOptionMouseEnter($event, processedOption)"
                    (mousemove)="onOptionMouseMove($event, processedOption)"
                    pRipple
                    [pBind]="getPTOptions(processedOption, i, 'optionContent')"
                >
                    @if (optionTemplate()) {
                        <ng-container *ngTemplateOutlet="optionTemplate(); context: { $implicit: processedOption?.option, level: level() }"></ng-container>
                    } @else {
                        <span [class]="cx('optionText')" [pBind]="getPTOptions(processedOption, i, 'optionText')">{{ getOptionLabelToRender(processedOption) }}</span>
                    }
                    @if (isOptionGroup(processedOption)) {
                        <span [class]="cx('groupIcon')" [pBind]="getPTOptions(processedOption, i, 'groupIcon')">
                            @if (!groupicon()) {
                                <svg data-p-icon="angle-right" [pBind]="getPTOptions(processedOption, index, 'groupIcon')" />
                            }
                            <ng-template *ngTemplateOutlet="groupicon()"></ng-template>
                        </span>
                    }
                </div>
                @if (isOptionGroup(processedOption) && isOptionActive(processedOption)) {
                    <ul
                        pCascadeSelectSub
                        [attrrole]="'group'"
                        [class]="cx('optionList')"
                        [selectId]="selectId()"
                        [focusedOptionId]="focusedOptionId()"
                        [activeOptionPath]="activeOptionPath()"
                        [options]="getOptionGroupChildren(processedOption)"
                        [optionLabel]="optionLabel()"
                        [optionValue]="optionValue()"
                        [level]="level() + 1"
                        (onChange)="onChange.emit($event)"
                        (onFocusChange)="onFocusChange.emit($event)"
                        (onFocusEnterChange)="onFocusEnterChange.emit($event)"
                        [optionGroupLabel]="optionGroupLabel()"
                        [optionGroupChildren]="optionGroupChildren()"
                        [dirty]="dirty()"
                        [optionTemplate]="optionTemplate()"
                        [pBind]="ptm('optionList')"
                        [pt]="pt"
                        [unstyled]="unstyled()"
                    ></ul>
                }
            </li>
        }
    `,
                    encapsulation: ViewEncapsulation.None,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    providers: [CascadeSelectStyle, { provide: PARENT_INSTANCE, useExisting: CascadeSelectSub }]
                }]
        }], propDecorators: { selectId: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectId", required: false }] }], activeOptionPath: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeOptionPath", required: false }] }], optionDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionDisabled", required: false }] }], focusedOptionId: [{ type: i0.Input, args: [{ isSignal: true, alias: "focusedOptionId", required: false }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], optionGroupChildren: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionGroupChildren", required: false }] }], optionTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionTemplate", required: false }] }], groupicon: [{ type: i0.Input, args: [{ isSignal: true, alias: "groupicon", required: false }] }], level: [{ type: i0.Input, args: [{ isSignal: true, alias: "level", required: false }] }], optionLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionLabel", required: false }] }], optionValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionValue", required: false }] }], optionGroupLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionGroupLabel", required: false }] }], dirty: [{ type: i0.Input, args: [{ isSignal: true, alias: "dirty", required: false }] }], root: [{ type: i0.Input, args: [{ isSignal: true, alias: "root", required: false }] }], onChange: [{ type: i0.Output, args: ["onChange"] }], onFocusChange: [{ type: i0.Output, args: ["onFocusChange"] }], onFocusEnterChange: [{ type: i0.Output, args: ["onFocusEnterChange"] }] } });
/**
 * CascadeSelect is a form component to select a value from a nested structure of options.
 * @group Components
 */
class CascadeSelect extends BaseEditableHolder {
    overlayService = inject(OverlayService);
    componentName = 'CascadeSelect';
    $pcCascadeSelect = inject(CASCADESELECT_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    /**
     * Unique identifier of the component
     * @group Props
     */
    id = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "id" }] : /* istanbul ignore next */ []));
    _generatedId;
    get resolvedId() {
        return this.id() || (this._generatedId ??= uuid('pn_id_'));
    }
    /**
     * Text to display when the search is active. Defaults to global value in i18n translation configuration.
     * @group Props
     * @defaultValue '{0} results are available'
     */
    searchMessage = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "searchMessage" }] : /* istanbul ignore next */ []));
    /**
     * Text to display when there is no data. Defaults to global value in i18n translation configuration.
     * @group Props
     */
    emptyMessage = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "emptyMessage" }] : /* istanbul ignore next */ []));
    /**
     * Text to be displayed in hidden accessible field when options are selected. Defaults to global value in i18n translation configuration.
     * @group Props
     * @defaultValue '{0} items selected'
     */
    selectionMessage = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "selectionMessage" }] : /* istanbul ignore next */ []));
    /**
     * Text to display when filtering does not return any results. Defaults to value from ngx-prime locale configuration.
     * @group Props
     * @defaultValue 'No available options'
     */
    emptySearchMessage = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "emptySearchMessage" }] : /* istanbul ignore next */ []));
    /**
     * Text to display when filtering does not return any results. Defaults to global value in i18n translation configuration.
     * @group Props
     * @defaultValue 'No selected item'
     */
    emptySelectionMessage = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "emptySelectionMessage" }] : /* istanbul ignore next */ []));
    /**
     * Locale to use in searching. The default locale is the host environment's current locale.
     * @group Props
     */
    searchLocale = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "searchLocale" }] : /* istanbul ignore next */ []));
    /**
     * Name of the disabled field of an option.
     * @group Props
     */
    optionDisabled = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "optionDisabled" }] : /* istanbul ignore next */ []));
    /**
     * Fields used when filtering the options, defaults to optionLabel.
     * @group Props
     */
    focusOnHover = input(true, { ...(ngDevMode ? { debugName: "focusOnHover" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Determines if the option will be selected on focus.
     * @group Props
     */
    selectOnFocus = input(false, { ...(ngDevMode ? { debugName: "selectOnFocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to focus on the first visible or selected element when the overlay panel is shown.
     * @group Props
     */
    autoOptionFocus = input(false, { ...(ngDevMode ? { debugName: "autoOptionFocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * An array of selectitems to display as the available options.
     * @group Props
     */
    options = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "options" }] : /* istanbul ignore next */ []));
    /**
     * Property name or getter function to use as the label of an option.
     * @group Props
     */
    optionLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "optionLabel" }] : /* istanbul ignore next */ []));
    /**
     * Property name or getter function to use as the value of an option, defaults to the option itself when not defined.
     * @group Props
     */
    optionValue = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "optionValue" }] : /* istanbul ignore next */ []));
    /**
     * Property name or getter function to use as the label of an option group.
     * @group Props
     */
    optionGroupLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "optionGroupLabel" }] : /* istanbul ignore next */ []));
    /**
     * Property name or getter function to retrieve the items of a group.
     * @group Props
     */
    optionGroupChildren = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "optionGroupChildren" }] : /* istanbul ignore next */ []));
    /**
     * Default text to display when no option is selected.
     * @group Props
     */
    placeholder = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "placeholder" }] : /* istanbul ignore next */ []));
    /**
     * Selected value of the component.
     * @group Props
     */
    value = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "value" }] : /* istanbul ignore next */ []));
    /**
     * A property to uniquely identify an option.
     * @group Props
     */
    dataKey = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "dataKey" }] : /* istanbul ignore next */ []));
    /**
     * Identifier of the underlying input element.
     * @group Props
     */
    inputId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "inputId" }] : /* istanbul ignore next */ []));
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex = input(0, { ...(ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    /**
     * Label of the input for accessibility.
     * @group Props
     */
    inputLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "inputLabel" }] : /* istanbul ignore next */ []));
    /**
     * Defines a string that labels the input for accessibility.
     * @group Props
     */
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /**
     * When enabled, a clear icon is displayed to clear the value.
     * @group Props
     */
    showClear = input(false, { ...(ngDevMode ? { debugName: "showClear" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Style class of the overlay panel.
     * @group Props
     */
    panelStyleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "panelStyleClass" }] : /* istanbul ignore next */ []));
    /**
     * Inline style of the overlay panel.
     * @group Props
     */
    panelStyle = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "panelStyle" }] : /* istanbul ignore next */ []));
    /**
     * Whether to use overlay API feature. The properties of overlay API can be used like an object in it.
     * @group Props
     */
    overlayOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "overlayOptions" }] : /* istanbul ignore next */ []));
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus = input(undefined, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether the dropdown is in loading state.
     * @group Props
     */
    loading = input(false, { ...(ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Icon to display in loading state.
     * @group Props
     */
    loadingIcon = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "loadingIcon" }] : /* istanbul ignore next */ []));
    /**
     * The breakpoint to define the maximum width boundary.
     * @group Props
     */
    breakpoint = input('960px', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "breakpoint" }] : /* istanbul ignore next */ []));
    /**
     * Specifies the size of the component.
     * @defaultValue undefined
     * @group Props
     */
    size = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "size" }] : /* istanbul ignore next */ []));
    /**
     * Specifies the input variant of the component.
     * @defaultValue undefined
     * @group Props
     */
    variant = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "variant" }] : /* istanbul ignore next */ []));
    /**
     * Spans 100% width of the container when enabled.
     * @defaultValue undefined
     * @group Props
     */
    fluid = input(undefined, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'self'
     * @group Props
     */
    appendTo = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "appendTo" }] : /* istanbul ignore next */ []));
    /**
     * The motion options.
     * @group Props
     */
    motionOptions = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "motionOptions" }] : /* istanbul ignore next */ []));
    /**
     * Callback to invoke on value change.
     * @param {CascadeSelectChangeEvent} event - Custom change event.
     * @group Emits
     */
    onChange = output();
    /**
     * Callback to invoke when a group changes.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onGroupChange = output();
    /**
     * Callback to invoke when the overlay is shown.
     * @param {CascadeSelectShowEvent} event - Custom overlay show event.
     * @group Emits
     */
    onShow = output();
    /**
     * Callback to invoke when the overlay is hidden.
     * @param {CascadeSelectHideEvent} event - Custom overlay hide event.
     * @group Emits
     */
    onHide = output();
    /**
     * Callback to invoke when the clear token is clicked.
     * @group Emits
     */
    onClear = output();
    /**
     * Callback to invoke before overlay is shown.
     * @param {CascadeSelectBeforeShowEvent} event - Custom overlay show event.
     * @group Emits
     */
    onBeforeShow = output();
    /**
     * Callback to invoke before overlay is hidden.
     * @param {CascadeSelectBeforeHideEvent} event - Custom overlay hide event.
     * @group Emits
     */
    onBeforeHide = output();
    /**
     * Callback to invoke when input receives focus.
     * @param {FocusEvent} event - Focus event.
     * @group Emits
     */
    onFocus = output();
    /**
     * Callback to invoke when input loses focus.
     * @param {FocusEvent} event - Focus event.
     * @group Emits
     */
    onBlur = output();
    focusInputViewChild = viewChild('focusInput', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusInputViewChild" }] : /* istanbul ignore next */ []));
    panelViewChild = viewChild('panel', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelViewChild" }] : /* istanbul ignore next */ []));
    overlayViewChild = viewChild('overlay', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "overlayViewChild" }] : /* istanbul ignore next */ []));
    /**
     * Custom value template.
     * @group Templates
     */
    valueTemplate;
    /**
     * Custom option template.
     * @group Templates
     */
    optionTemplate = contentChild('option', { ...(ngDevMode ? { debugName: "optionTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom header template.
     * @group Templates
     */
    headerTemplate = contentChild('header', { ...(ngDevMode ? { debugName: "headerTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom footer template.
     * @group Templates
     */
    footerTemplate = contentChild('footer', { ...(ngDevMode ? { debugName: "footerTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom trigger icon template.
     * @group Templates
     */
    triggerIconTemplate;
    /**
     * Custom loading icon template.
     * @group Templates
     */
    loadingIconTemplate;
    /**
     * Custom option group icon template.
     * @group Templates
     */
    groupIconTemplate = contentChild('optiongroupicon', { ...(ngDevMode ? { debugName: "groupIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom clear icon template.
     * @group Templates
     */
    clearIconTemplate;
    _valueTemplate;
    _optionTemplate;
    _headerTemplate;
    _footerTemplate;
    _triggerIconTemplate;
    _loadingIconTemplate;
    _groupIconTemplate;
    _clearIconTemplate;
    selectionPath = null;
    focused = false;
    overlayVisible = false;
    clicked = false;
    dirty = false;
    searchValue;
    searchTimeout;
    focusedOptionInfo = signal({ index: -1, level: 0, parentKey: '' }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusedOptionInfo" }] : /* istanbul ignore next */ []));
    activeOptionPath = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeOptionPath" }] : /* istanbul ignore next */ []));
    processedOptions = [];
    _componentStyle = inject(CascadeSelectStyle);
    initialized = false;
    $variant = computed(() => this.variant() || this.config.inputStyle() || this.config.inputVariant(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "$variant" }] : /* istanbul ignore next */ []));
    $appendTo = computed(() => this.appendTo() || this.config.overlayAppendTo(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "$appendTo" }] : /* istanbul ignore next */ []));
    pcFluid = inject(Fluid, { optional: true, host: true, skipSelf: true });
    get hasFluid() {
        return this.fluid() ?? !!this.pcFluid;
    }
    onHostClick(event) {
        this.onContainerClick(event);
    }
    get listLabel() {
        return this.config.getTranslation(TranslationKeys.ARIA)['listLabel'];
    }
    get focusedOptionId() {
        return this.focusedOptionInfo().index !== -1 ? `${this.resolvedId}${isNotEmpty(this.focusedOptionInfo().parentKey) ? '_' + this.focusedOptionInfo().parentKey : ''}_${this.focusedOptionInfo().index}` : null;
    }
    get searchResultMessageText() {
        return isNotEmpty(this.visibleOptions()) ? this.searchMessageText.replaceAll('{0}', this.visibleOptions().length) : this.emptySearchMessageText;
    }
    get searchMessageText() {
        return this.searchMessage() || this.config.translation.searchMessage || '';
    }
    get emptySearchMessageText() {
        return this.emptySearchMessage() || this.config.translation.emptySearchMessage || '';
    }
    get emptyMessageText() {
        return this.emptyMessage() || this.config.translation.emptyMessage || '';
    }
    get selectionMessageText() {
        return this.selectionMessage() || this.config.translation.selectionMessage || '';
    }
    get emptySelectionMessageText() {
        return this.emptySelectionMessage() || this.config.translation.emptySelectionMessage || '';
    }
    get selectedMessageText() {
        return this.hasSelectedOption() ? this.selectionMessageText.replaceAll('{0}', '1') : this.emptySelectionMessageText;
    }
    visibleOptions = computed(() => {
        const processedOption = this.activeOptionPath().find((p) => p.key === this.focusedOptionInfo().parentKey);
        return processedOption ? processedOption.children : this.processedOptions;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visibleOptions" }] : /* istanbul ignore next */ []));
    label = computed(() => {
        const label = this.placeholder() || 'p-emptylabel';
        if (this.hasSelectedOption()) {
            const activeOptionPath = this.findOptionPathByValue(this.modelValue(), null);
            const processedOption = isNotEmpty(activeOptionPath) ? activeOptionPath[activeOptionPath.length - 1] : null;
            return processedOption ? this.getOptionLabel(processedOption.option) : label;
        }
        return label;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    get _label() {
        const label = this.placeholder() || 'p-emptylabel';
        if (this.hasSelectedOption()) {
            const activeOptionPath = this.findOptionPathByValue(this.modelValue(), null);
            const processedOption = isNotEmpty(activeOptionPath) ? activeOptionPath[activeOptionPath.length - 1] : null;
            return processedOption ? this.getOptionLabel(processedOption.option) : label;
        }
        return label;
    }
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    onAfterContentInit() {
        this.templates().forEach((item) => {
            switch (item.getType()) {
                case 'value':
                    this._valueTemplate = item.template;
                    break;
                case 'option':
                    this._optionTemplate = item.template;
                    break;
                case 'header':
                    this._headerTemplate = item.template;
                    break;
                case 'footer':
                    this._footerTemplate = item.template;
                    break;
                case 'triggericon':
                    this._triggerIconTemplate = item.template;
                    break;
                case 'loadingicon':
                    this._loadingIconTemplate = item.template;
                    break;
                case 'clearicon':
                    this._clearIconTemplate = item.template;
                    break;
                case 'optiongroupicon':
                    this._groupIconTemplate = item.template;
                    break;
            }
        });
    }
    hasSelectedOption() {
        return isNotEmpty(this.modelValue());
    }
    createProcessedOptions(options, level = 0, parent = {}, parentKey = '') {
        const processedOptions = [];
        options &&
            options.forEach((option, index) => {
                const key = (parentKey !== '' ? parentKey + '_' : '') + index;
                const newOption = {
                    option,
                    index,
                    level,
                    key,
                    parent,
                    parentKey
                };
                newOption['children'] = this.createProcessedOptions(this.getOptionGroupChildren(option, level), level + 1, newOption, key);
                processedOptions.push(newOption);
            });
        return processedOptions;
    }
    onInputFocus(event) {
        if (this.$disabled()) {
            // For screenreaders
            return;
        }
        this.focused = true;
        this.onFocus.emit(event);
    }
    onInputBlur(event) {
        this.focused = false;
        this.focusedOptionInfo.set({ indeX: -1, level: 0, parentKey: '' });
        this.searchValue = '';
        this.onModelTouched();
        this.onBlur.emit(event);
    }
    onInputKeyDown(event) {
        if (this.$disabled() || this.loading()) {
            event.preventDefault();
            return;
        }
        const metaKey = event.metaKey || event.ctrlKey;
        switch (event.code) {
            case 'ArrowDown':
                this.onArrowDownKey(event);
                break;
            case 'ArrowUp':
                this.onArrowUpKey(event);
                break;
            case 'ArrowLeft':
                this.onArrowLeftKey(event);
                break;
            case 'ArrowRight':
                this.onArrowRightKey(event);
                break;
            case 'Home':
                this.onHomeKey(event);
                break;
            case 'End':
                this.onEndKey(event);
                break;
            case 'Space':
                this.onSpaceKey(event);
                break;
            case 'Enter':
            case 'NumpadEnter':
                this.onEnterKey(event);
                break;
            case 'Escape':
                this.onEscapeKey(event);
                break;
            case 'Tab':
                this.onTabKey(event);
                break;
            case 'Backspace':
                this.onBackspaceKey(event);
                break;
            case 'PageDown':
            case 'PageUp':
            case 'ShiftLeft':
            case 'ShiftRight':
                //NOOP
                break;
            default:
                if (!metaKey && isPrintableCharacter(event.key)) {
                    !this.overlayVisible && this.show();
                    this.searchOptions(event, event.key);
                }
                break;
        }
        this.clicked = false;
    }
    onArrowDownKey(event) {
        if (!this.overlayVisible) {
            this.show();
        }
        else {
            const optionIndex = this.focusedOptionInfo().index !== -1 ? this.findNextOptionIndex(this.focusedOptionInfo().index) : this.clicked ? this.findFirstOptionIndex() : this.findFirstFocusedOptionIndex();
            this.changeFocusedOptionIndex(event, optionIndex, true);
        }
        event.preventDefault();
    }
    onArrowUpKey(event) {
        if (event.altKey) {
            if (this.focusedOptionInfo().index !== -1) {
                const processedOption = this.visibleOptions[this.focusedOptionInfo().index];
                const grouped = this.isProccessedOptionGroup(processedOption);
                !grouped && this.onOptionChange({ originalEvent: event, processedOption });
            }
            this.overlayVisible && this.hide();
            event.preventDefault();
        }
        else {
            const optionIndex = this.focusedOptionInfo().index !== -1 ? this.findPrevOptionIndex(this.focusedOptionInfo().index) : this.clicked ? this.findLastOptionIndex() : this.findLastFocusedOptionIndex();
            this.changeFocusedOptionIndex(event, optionIndex, true);
            !this.overlayVisible && this.show();
            event.preventDefault();
        }
    }
    onArrowLeftKey(event) {
        if (this.overlayVisible) {
            const processedOption = this.visibleOptions()[this.focusedOptionInfo().index];
            const parentOption = this.activeOptionPath().find((p) => p.key === processedOption.parentKey);
            const matched = this.focusedOptionInfo().parentKey === '' || (parentOption && parentOption.key === this.focusedOptionInfo().parentKey);
            const root = isEmpty(processedOption.parent);
            if (matched) {
                const activeOptionPath = this.activeOptionPath().filter((p) => p.parentKey !== this.focusedOptionInfo().parentKey);
                this.activeOptionPath.set(activeOptionPath);
            }
            if (!root) {
                this.focusedOptionInfo.set({ index: -1, parentKey: parentOption ? parentOption.parentKey : '' });
                this.searchValue = '';
                this.onArrowDownKey(event);
            }
            event.preventDefault();
        }
    }
    onArrowRightKey(event) {
        if (this.overlayVisible) {
            const processedOption = this.visibleOptions()[this.focusedOptionInfo().index];
            const grouped = this.isProccessedOptionGroup(processedOption);
            if (grouped) {
                const matched = this.activeOptionPath().some((p) => processedOption.key === p.key);
                if (matched) {
                    this.focusedOptionInfo.set({ index: -1, parentKey: processedOption.key });
                    this.searchValue = '';
                    this.onArrowDownKey(event);
                }
                else {
                    this.onOptionChange({ originalEvent: event, processedOption });
                }
            }
            event.preventDefault();
        }
    }
    onHomeKey(event) {
        this.changeFocusedOptionIndex(event, this.findFirstOptionIndex());
        !this.overlayVisible && this.show();
        event.preventDefault();
    }
    onEndKey(event) {
        this.changeFocusedOptionIndex(event, this.findLastOptionIndex());
        !this.overlayVisible && this.show();
        event.preventDefault();
    }
    onEnterKey(event) {
        if (!this.overlayVisible) {
            this.focusedOptionInfo.set({ ...this.focusedOptionInfo(), index: -1 }); // reset
            this.onArrowDownKey(event);
        }
        else {
            if (this.focusedOptionInfo().index !== -1) {
                const processedOption = this.visibleOptions()[this.focusedOptionInfo().index];
                const grouped = this.isProccessedOptionGroup(processedOption);
                this.onOptionClick({ originalEvent: event, processedOption });
                !grouped && this.hide();
            }
        }
        event.preventDefault();
    }
    onSpaceKey(event) {
        this.onEnterKey(event);
    }
    onEscapeKey(event) {
        this.overlayVisible && this.hide(event, true);
        event.preventDefault();
    }
    onTabKey(event) {
        if (this.focusedOptionInfo().index !== -1) {
            const processedOption = this.visibleOptions()[this.focusedOptionInfo().index];
            const grouped = this.isProccessedOptionGroup(processedOption);
            !grouped && this.onOptionChange({ originalEvent: event, processedOption });
        }
        this.overlayVisible && this.hide();
    }
    onBackspaceKey(event) {
        if (isNotEmpty(this.modelValue()) && this.showClear()) {
            this.clear();
        }
        event.stopPropagation();
    }
    equalityKey() {
        return this.optionValue() ? undefined : this.dataKey();
    }
    updateModel(value, event) {
        this.onModelChange(value);
        this.writeModelValue(value);
        if (this.initialized) {
            this.onChange.emit({
                originalEvent: event,
                value: value
            });
        }
    }
    autoUpdateModel() {
        if (this.selectOnFocus() && this.autoOptionFocus() && !this.hasSelectedOption()) {
            this.focusedOptionInfo().index = this.findFirstFocusedOptionIndex();
            this.onOptionChange({
                originalEvent: null,
                processedOption: this.visibleOptions()[this.focusedOptionInfo().index],
                isHide: false
            });
            !this.overlayVisible && this.focusedOptionInfo.set({ index: -1, level: 0, parentKey: '' });
        }
    }
    scrollInView(index = -1) {
        const id = index !== -1 ? `${this.resolvedId}_${index}` : this.focusedOptionId;
        const element = findSingle(this.panelViewChild()?.nativeElement, `li[id="${id}"]`);
        if (element) {
            element.scrollIntoView && element.scrollIntoView({ block: 'nearest', inline: 'start' });
        }
    }
    changeFocusedOptionIndex(event, index, preventSelection) {
        const focusedOptionInfo = this.focusedOptionInfo();
        if (focusedOptionInfo.index !== index) {
            this.focusedOptionInfo.set({ ...focusedOptionInfo, index });
            this.scrollInView();
            if (this.focusOnHover()) {
                this.onOptionClick({ originalEvent: event, processedOption: this.visibleOptions()[index], isHide: false, preventSelection });
            }
            if (this.selectOnFocus()) {
                this.onOptionChange({ originalEvent: event, processedOption: this.visibleOptions()[index], isHide: false });
            }
        }
    }
    matchMediaListener;
    onOptionSelect(event) {
        const { originalEvent, value, isHide } = event;
        const newValue = this.getOptionValue(value);
        const activeOptionPath = this.activeOptionPath();
        activeOptionPath.forEach((p) => (p.selected = true));
        this.activeOptionPath.set(activeOptionPath);
        this.updateModel(newValue, originalEvent);
        isHide && this.hide(event, true);
    }
    onOptionGroupSelect(event) {
        this.dirty = true;
        this.onGroupChange.emit(event);
    }
    onContainerClick(event) {
        if (this.$disabled() || this.loading()) {
            return;
        }
        if (!this.overlayViewChild()?.el?.nativeElement?.contains(event.target)) {
            if (this.overlayVisible) {
                this.hide();
            }
            else {
                this.show();
            }
            this.focusInputViewChild()?.nativeElement.focus();
        }
        this.clicked = true;
    }
    isOptionMatched(processedOption) {
        return this.isValidOption(processedOption) && this.getProccessedOptionLabel(processedOption).toLocaleLowerCase(this.searchLocale()).startsWith(this.searchValue?.toLocaleLowerCase(this.searchLocale()));
    }
    isOptionDisabled(option) {
        const optionDisabled = this.optionDisabled();
        return optionDisabled ? resolveFieldData(option, optionDisabled) : false;
    }
    isValidOption(processedOption) {
        return !!processedOption && !this.isOptionDisabled(processedOption.option);
    }
    isValidSelectedOption(processedOption) {
        return this.isValidOption(processedOption) && this.isSelected(processedOption);
    }
    isSelected(processedOption) {
        return this.activeOptionPath().some((p) => p.key === processedOption.key);
    }
    findOptionPathByValue(value, processedOptions, level = 0) {
        processedOptions = processedOptions || (level === 0 && this.processedOptions);
        if (!processedOptions)
            return null;
        if (isEmpty(value))
            return [];
        for (let i = 0; i < processedOptions.length; i++) {
            const processedOption = processedOptions[i];
            if (equals(value, this.getOptionValue(processedOption.option), this.equalityKey())) {
                return [processedOption];
            }
            const matchedOptions = this.findOptionPathByValue(value, processedOption.children, level + 1);
            if (matchedOptions) {
                matchedOptions.unshift(processedOption);
                return matchedOptions;
            }
        }
    }
    findFirstOptionIndex() {
        return this.visibleOptions().findIndex((processedOption) => this.isValidOption(processedOption));
    }
    findLastOptionIndex() {
        return findLastIndex(this.visibleOptions(), (processedOption) => this.isValidOption(processedOption));
    }
    findNextOptionIndex(index) {
        const matchedOptionIndex = index < this.visibleOptions().length - 1
            ? this.visibleOptions()
                .slice(index + 1)
                .findIndex((processedOption) => this.isValidOption(processedOption))
            : -1;
        return matchedOptionIndex > -1 ? matchedOptionIndex + index + 1 : index;
    }
    findPrevOptionIndex(index) {
        const matchedOptionIndex = index > 0 ? findLastIndex(this.visibleOptions().slice(0, index), (processedOption) => this.isValidOption(processedOption)) : -1;
        return matchedOptionIndex > -1 ? matchedOptionIndex : index;
    }
    findSelectedOptionIndex() {
        return this.visibleOptions().findIndex((processedOption) => this.isValidSelectedOption(processedOption));
    }
    findFirstFocusedOptionIndex() {
        const selectedIndex = this.findSelectedOptionIndex();
        return selectedIndex < 0 ? this.findFirstOptionIndex() : selectedIndex;
    }
    findLastFocusedOptionIndex() {
        const selectedIndex = this.findSelectedOptionIndex();
        return selectedIndex < 0 ? this.findLastOptionIndex() : selectedIndex;
    }
    searchOptions(event, char) {
        this.searchValue = (this.searchValue || '') + char;
        let optionIndex = -1;
        let matched = false;
        const focusedOptionInfo = this.focusedOptionInfo();
        if (focusedOptionInfo.index !== -1) {
            optionIndex = this.visibleOptions()
                .slice(focusedOptionInfo.index)
                .findIndex((processedOption) => this.isOptionMatched(processedOption));
            optionIndex =
                optionIndex === -1
                    ? this.visibleOptions()
                        .slice(0, focusedOptionInfo.index)
                        .findIndex((processedOption) => this.isOptionMatched(processedOption))
                    : optionIndex + focusedOptionInfo.index;
        }
        else {
            optionIndex = this.visibleOptions().findIndex((processedOption) => this.isOptionMatched(processedOption));
        }
        if (optionIndex !== -1) {
            matched = true;
        }
        if (optionIndex === -1 && focusedOptionInfo.index === -1) {
            optionIndex = this.findFirstFocusedOptionIndex();
        }
        if (optionIndex !== -1) {
            this.changeFocusedOptionIndex(event, optionIndex);
        }
        if (this.searchTimeout) {
            clearTimeout(this.searchTimeout);
        }
        this.searchTimeout = setTimeout(() => {
            this.searchValue = '';
            this.searchTimeout = null;
        }, 500);
        return matched;
    }
    hide(event, isFocus = false) {
        const _hide = () => {
            this.overlayVisible = false;
            this.clicked = false;
            this.activeOptionPath.set([]);
            this.focusedOptionInfo.set({ index: -1, level: 0, parentKey: '' });
            isFocus && focus(this.focusInputViewChild()?.nativeElement);
            this.onHide.emit(event);
            this.cd.markForCheck();
        };
        setTimeout(() => {
            _hide();
        }, 0); // For ScreenReaders
    }
    show(event, isFocus = false) {
        this.onShow.emit(event);
        this.overlayVisible = true;
        const activeOptionPath = this.hasSelectedOption() ? this.findOptionPathByValue(this.modelValue()) : this.activeOptionPath();
        this.activeOptionPath.set(activeOptionPath);
        let focusedOptionInfo;
        if (this.hasSelectedOption() && isNotEmpty(this.activeOptionPath())) {
            const processedOption = this.activeOptionPath()[this.activeOptionPath().length - 1];
            focusedOptionInfo = {
                index: processedOption.index,
                level: processedOption.level,
                parentKey: processedOption.parentKey
            };
        }
        else {
            focusedOptionInfo = { index: this.autoOptionFocus() ? this.findFirstFocusedOptionIndex() : this.findSelectedOptionIndex(), level: 0, parentKey: '' };
        }
        this.focusedOptionInfo.set(focusedOptionInfo);
        isFocus && focus(this.focusInputViewChild()?.nativeElement);
    }
    clear(event) {
        if (isNotEmpty(this.modelValue()) && this.showClear()) {
            this.updateModel(null);
            this.focusedOptionInfo.set({ index: -1, level: 0, parentKey: '' });
            this.activeOptionPath.set([]);
            this.onClear.emit(event);
        }
        event && event.stopPropagation();
    }
    getOptionLabel(option) {
        const optionLabel = this.optionLabel();
        return optionLabel ? resolveFieldData(option, optionLabel) : option;
    }
    getOptionValue(option) {
        const optionValue = this.optionValue();
        return optionValue ? resolveFieldData(option, optionValue) : option;
    }
    getOptionGroupLabel(optionGroup) {
        const optionGroupLabel = this.optionGroupLabel();
        return optionGroupLabel ? resolveFieldData(optionGroup, optionGroupLabel) : null;
    }
    getOptionGroupChildren(optionGroup, level) {
        return resolveFieldData(optionGroup, this.optionGroupChildren()?.[level]);
    }
    isOptionGroup(option, level) {
        return Object.prototype.hasOwnProperty.call(option, this.optionGroupChildren()?.[level]);
    }
    isProccessedOptionGroup(processedOption) {
        return isNotEmpty(processedOption?.children);
    }
    getProccessedOptionLabel(processedOption) {
        const grouped = this.isProccessedOptionGroup(processedOption);
        return grouped ? this.getOptionGroupLabel(processedOption.option) : this.getOptionLabel(processedOption.option);
    }
    constructor() {
        super();
        effect(() => {
            const activeOptionPath = this.activeOptionPath();
            if (isNotEmpty(activeOptionPath)) {
                this.overlayViewChild()?.alignOverlay();
            }
        });
        effect(() => {
            const options = this.options();
            this.processedOptions = this.createProcessedOptions(options || []);
            this.updateModel(null);
        });
    }
    query;
    queryMatches = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "queryMatches" }] : /* istanbul ignore next */ []));
    mobileActive = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "mobileActive" }] : /* istanbul ignore next */ []));
    onOptionChange(event) {
        const { processedOption, type } = event;
        if (isEmpty(processedOption))
            return;
        const { index, key, level, parentKey, children } = processedOption;
        const grouped = isNotEmpty(children);
        const activeOptionPath = this.activeOptionPath().filter((p) => p.parentKey !== parentKey && p.parentKey !== key);
        this.focusedOptionInfo.set({ index, level, parentKey });
        if (type == 'hover' && this.queryMatches()) {
            return;
        }
        if (grouped) {
            activeOptionPath.push(processedOption);
        }
        this.activeOptionPath.set([...activeOptionPath]);
    }
    onOptionClick(event) {
        const { originalEvent, processedOption, isFocus, preventSelection } = event;
        const { index, key, level, parentKey } = processedOption;
        const grouped = this.isProccessedOptionGroup(processedOption);
        const selected = this.isSelected(processedOption);
        if (selected) {
            const activeOptionPath = this.activeOptionPath().filter((p) => key !== p.key && key.startsWith(p.key));
            this.activeOptionPath.set([...activeOptionPath]);
            this.focusedOptionInfo.set({ index, level, parentKey });
        }
        else {
            if (grouped) {
                this.onOptionChange(event);
                this.onOptionGroupSelect({ originalEvent, value: processedOption.option, isFocus: false });
            }
            else {
                const activeOptionPath = this.activeOptionPath().filter((p) => p.parentKey !== parentKey);
                activeOptionPath.push(processedOption);
                this.focusedOptionInfo.set({ index, level, parentKey });
                if (!preventSelection || processedOption?.children.length !== 0) {
                    this.activeOptionPath.set([...activeOptionPath]);
                    this.onOptionSelect({ originalEvent, value: processedOption.option, isHide: isFocus });
                }
            }
        }
        isFocus && focus(this.focusInputViewChild()?.nativeElement);
    }
    onOptionMouseEnter(event) {
        if (this.focusOnHover()) {
            if (this.dirty || (!this.dirty && isNotEmpty(this.modelValue()))) {
                this.onOptionChange({ ...event, type: 'hover' });
            }
            else if (!this.dirty && event.processedOption.level === 0) {
                this.onOptionClick({ ...event, type: 'hover' });
            }
        }
    }
    onOptionMouseMove(event) {
        if (this.focused && this.focusOnHover()) {
            this.changeFocusedOptionIndex(event, event.processedOption.index);
        }
    }
    onInit() {
        this.autoUpdateModel();
        this.bindMatchMediaListener();
    }
    onAfterViewInit() {
        this.initialized = true;
    }
    bindMatchMediaListener() {
        if (!this.matchMediaListener) {
            const window = this.document.defaultView;
            if (window && window.matchMedia) {
                const query = window.matchMedia(`(max-width: ${this.breakpoint()})`);
                this.query = query;
                this.queryMatches.set(query?.matches);
                this.matchMediaListener = () => {
                    this.queryMatches.set(query?.matches);
                    this.mobileActive.set(false);
                };
                this.query.addEventListener('change', this.matchMediaListener);
            }
        }
    }
    unbindMatchMediaListener() {
        if (this.matchMediaListener) {
            this.query.removeEventListener('change', this.matchMediaListener);
            this.matchMediaListener = null;
        }
    }
    onOverlayAfterLeave() {
        this.dirty = false;
    }
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value, setModelValue) {
        setModelValue(value);
        this.cd.markForCheck();
    }
    onDestroy() {
        if (this.matchMediaListener) {
            this.unbindMatchMediaListener();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CascadeSelect, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: CascadeSelect, isStandalone: true, selector: "p-cascadeSelect, p-cascadeselect, p-cascade-select", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, searchMessage: { classPropertyName: "searchMessage", publicName: "searchMessage", isSignal: true, isRequired: false, transformFunction: null }, emptyMessage: { classPropertyName: "emptyMessage", publicName: "emptyMessage", isSignal: true, isRequired: false, transformFunction: null }, selectionMessage: { classPropertyName: "selectionMessage", publicName: "selectionMessage", isSignal: true, isRequired: false, transformFunction: null }, emptySearchMessage: { classPropertyName: "emptySearchMessage", publicName: "emptySearchMessage", isSignal: true, isRequired: false, transformFunction: null }, emptySelectionMessage: { classPropertyName: "emptySelectionMessage", publicName: "emptySelectionMessage", isSignal: true, isRequired: false, transformFunction: null }, searchLocale: { classPropertyName: "searchLocale", publicName: "searchLocale", isSignal: true, isRequired: false, transformFunction: null }, optionDisabled: { classPropertyName: "optionDisabled", publicName: "optionDisabled", isSignal: true, isRequired: false, transformFunction: null }, focusOnHover: { classPropertyName: "focusOnHover", publicName: "focusOnHover", isSignal: true, isRequired: false, transformFunction: null }, selectOnFocus: { classPropertyName: "selectOnFocus", publicName: "selectOnFocus", isSignal: true, isRequired: false, transformFunction: null }, autoOptionFocus: { classPropertyName: "autoOptionFocus", publicName: "autoOptionFocus", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, optionLabel: { classPropertyName: "optionLabel", publicName: "optionLabel", isSignal: true, isRequired: false, transformFunction: null }, optionValue: { classPropertyName: "optionValue", publicName: "optionValue", isSignal: true, isRequired: false, transformFunction: null }, optionGroupLabel: { classPropertyName: "optionGroupLabel", publicName: "optionGroupLabel", isSignal: true, isRequired: false, transformFunction: null }, optionGroupChildren: { classPropertyName: "optionGroupChildren", publicName: "optionGroupChildren", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, dataKey: { classPropertyName: "dataKey", publicName: "dataKey", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, inputLabel: { classPropertyName: "inputLabel", publicName: "inputLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, showClear: { classPropertyName: "showClear", publicName: "showClear", isSignal: true, isRequired: false, transformFunction: null }, panelStyleClass: { classPropertyName: "panelStyleClass", publicName: "panelStyleClass", isSignal: true, isRequired: false, transformFunction: null }, panelStyle: { classPropertyName: "panelStyle", publicName: "panelStyle", isSignal: true, isRequired: false, transformFunction: null }, overlayOptions: { classPropertyName: "overlayOptions", publicName: "overlayOptions", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, loadingIcon: { classPropertyName: "loadingIcon", publicName: "loadingIcon", isSignal: true, isRequired: false, transformFunction: null }, breakpoint: { classPropertyName: "breakpoint", publicName: "breakpoint", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null }, appendTo: { classPropertyName: "appendTo", publicName: "appendTo", isSignal: true, isRequired: false, transformFunction: null }, motionOptions: { classPropertyName: "motionOptions", publicName: "motionOptions", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onChange: "onChange", onGroupChange: "onGroupChange", onShow: "onShow", onHide: "onHide", onClear: "onClear", onBeforeShow: "onBeforeShow", onBeforeHide: "onBeforeHide", onFocus: "onFocus", onBlur: "onBlur" }, host: { listeners: { "mousedown": "onHostClick($event)" }, properties: { "class": "cn(cx('root'), styleClass())", "style": "sx('root')" } }, providers: [CASCADESELECT_VALUE_ACCESSOR, CascadeSelectStyle, { provide: PARENT_INSTANCE, useExisting: CascadeSelect }, { provide: CASCADESELECT_INSTANCE, useExisting: CascadeSelect }], queries: [{ propertyName: "optionTemplate", first: true, predicate: ["option"], isSignal: true }, { propertyName: "headerTemplate", first: true, predicate: ["header"], isSignal: true }, { propertyName: "footerTemplate", first: true, predicate: ["footer"], isSignal: true }, { propertyName: "groupIconTemplate", first: true, predicate: ["optiongroupicon"], isSignal: true }, { propertyName: "templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "valueTemplate", first: true, predicate: ["value"] }, { propertyName: "triggerIconTemplate", first: true, predicate: ["triggericon"] }, { propertyName: "loadingIconTemplate", first: true, predicate: ["loadingicon"] }, { propertyName: "clearIconTemplate", first: true, predicate: ["clearicon"] }], viewQueries: [{ propertyName: "focusInputViewChild", first: true, predicate: ["focusInput"], descendants: true, isSignal: true }, { propertyName: "panelViewChild", first: true, predicate: ["panel"], descendants: true, isSignal: true }, { propertyName: "overlayViewChild", first: true, predicate: ["overlay"], descendants: true, isSignal: true }], usesInheritance: true, hostDirectives: [{ directive: i2.Bind }], ngImport: i0, template: `
        <div class="p-hidden-accessible" [pBind]="ptm('hiddenInputWrapper')">
            <input
                #focusInput
                readonly
                type="text"
                role="combobox"
                [attr.name]="name()"
                [attr.required]="required() ? '' : undefined"
                [attr.disabled]="$disabled() ? '' : undefined"
                [attr.placeholder]="placeholder()"
                [attr.tabindex]="!$disabled() ? tabindex() : -1"
                [attr.id]="inputId()"
                [attr.aria-label]="ariaLabel()"
                [attr.aria-labelledby]="ariaLabelledBy()"
                [attr.aria-haspopup]="'tree'"
                [attr.aria-expanded]="overlayVisible ?? false"
                [attr.aria-controls]="overlayVisible ? id() + '_tree' : null"
                [attr.aria-activedescendant]="focused ? focusedOptionId : undefined"
                (focus)="onInputFocus($event)"
                (blur)="onInputBlur($event)"
                (keydown)="onInputKeyDown($event)"
                [pAutoFocus]="autofocus()"
                [pBind]="ptm('hiddenInput')"
            />
        </div>
        <span [class]="cx('label')" [pBind]="ptm('label')">
            @if (valueTemplate || _valueTemplate) {
                <ng-container *ngTemplateOutlet="valueTemplate || _valueTemplate; context: { $implicit: value(), placeholder: placeholder() }"></ng-container>
            } @else {
                {{ label() }}
            }
        </span>

        @if ($filled() && !$disabled() && showClear()) {
            @if (!clearIconTemplate && !_clearIconTemplate) {
                <svg data-p-icon="times" [class]="cx('clearIcon')" (click)="clear($event)" [pBind]="ptm('clearIcon')" [attr.aria-hidden]="true" />
            }
            @if (clearIconTemplate || _clearIconTemplate) {
                <span [class]="cx('clearIcon')" (click)="clear($event)" [pBind]="ptm('clearIcon')" [attr.aria-hidden]="true">
                    <ng-template *ngTemplateOutlet="clearIconTemplate || _clearIconTemplate"></ng-template>
                </span>
            }
        }

        <div [class]="cx('dropdown')" role="button" aria-haspopup="listbox" [attr.aria-expanded]="overlayVisible ?? false" [pBind]="ptm('dropdown')" [attr.aria-hidden]="true">
            @if (loading()) {
                @if (loadingIconTemplate || _loadingIconTemplate) {
                    <ng-container *ngTemplateOutlet="loadingIconTemplate || _loadingIconTemplate"></ng-container>
                }
                @if (!loadingIconTemplate && !_loadingIconTemplate) {
                    @if (loadingIcon()) {
                        <span [class]="cn(cx('loadingIcon'), loadingIcon() + 'pi-spin')" aria-hidden="true" [pBind]="ptm('loadingIcon')"></span>
                    }
                    @if (!loadingIcon()) {
                        <span [class]="cn(cx('loadingIcon'), loadingIcon() + ' pi pi-spinner pi-spin')" aria-hidden="true" [pBind]="ptm('loadingIcon')"></span>
                    }
                }
            } @else {
                @if (!triggerIconTemplate && !_triggerIconTemplate) {
                    <svg data-p-icon="chevron-down" [class]="cx('dropdownIcon')" [pBind]="ptm('dropdownIcon')" />
                }
                @if (triggerIconTemplate || _triggerIconTemplate) {
                    <span [class]="cx('dropdownIcon')" [pBind]="ptm('dropdownIcon')">
                        <ng-template *ngTemplateOutlet="triggerIconTemplate || _triggerIconTemplate"></ng-template>
                    </span>
                }
            }
        </div>
        <span role="status" aria-live="polite" class="p-hidden-accessible" [pBind]="ptm('hiddenSearchResult')">
            {{ searchResultMessageText }}
        </span>
        <p-overlay
            #overlay
            [hostAttrSelector]="$attrSelector"
            [(visible)]="overlayVisible"
            [options]="overlayOptions()"
            [target]="'@parent'"
            [appendTo]="$appendTo()"
            [unstyled]="unstyled()"
            [pt]="ptm('pcOverlay')"
            [motionOptions]="motionOptions()"
            (onAfterLeave)="onOverlayAfterLeave()"
            (onBeforeShow)="onBeforeShow.emit($event)"
            (onShow)="show($event)"
            (onBeforeHide)="onBeforeHide.emit($event)"
            (onHide)="hide($event)"
        >
            <ng-template #content>
                <div #panel [class]="cn(cx('overlay'), panelStyleClass())" [ngStyle]="panelStyle()" [pBind]="ptm('overlay')">
                    <ng-template *ngTemplateOutlet="headerTemplate() || _headerTemplate"></ng-template>
                    <div [class]="cx('listContainer')" [pBind]="ptm('listContainer')">
                        <ul
                            pCascadeSelectSub
                            [class]="cx('list')"
                            [options]="processedOptions"
                            [selectId]="resolvedId"
                            [focusedOptionId]="focused ? focusedOptionId : undefined"
                            [activeOptionPath]="activeOptionPath()"
                            [optionLabel]="optionLabel()"
                            [optionValue]="optionValue()"
                            [level]="0"
                            [optionTemplate]="optionTemplate() || _optionTemplate"
                            [groupicon]="groupIconTemplate() || groupIconTemplate()"
                            [optionGroupLabel]="optionGroupLabel()"
                            [optionGroupChildren]="optionGroupChildren()"
                            [optionDisabled]="optionDisabled()"
                            [root]="true"
                            (onChange)="onOptionClick($event)"
                            (onFocusChange)="onOptionMouseMove($event)"
                            (onFocusEnterChange)="onOptionMouseEnter($event)"
                            [dirty]="dirty"
                            [attr.role]="'tree'"
                            [attr.aria-orientation]="'horizontal'"
                            [pBind]="ptm('list')"
                            [attr.aria-label]="listlabel"
                            [pt]="pt"
                            [unstyled]="unstyled()"
                        ></ul>
                    </div>
                    <span role="status" aria-live="polite" class="p-hidden-accessible" [pBind]="ptm('selectedMessageText')">
                        {{ selectedMessageText }}
                    </span>
                    <ng-template *ngTemplateOutlet="footerTemplate() || _footerTemplate"></ng-template>
                </div>
            </ng-template>
        </p-overlay>
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: Overlay, selector: "p-overlay", inputs: ["hostName", "visible", "mode", "style", "styleClass", "contentStyle", "contentStyleClass", "target", "autoZIndex", "baseZIndex", "showTransitionOptions", "hideTransitionOptions", "listener", "responsive", "options", "appendTo", "inline", "motionOptions", "hostAttrSelector"], outputs: ["visibleChange", "onBeforeShow", "onShow", "onBeforeHide", "onHide", "onAnimationStart", "onAnimationDone", "onBeforeEnter", "onEnter", "onAfterEnter", "onBeforeLeave", "onLeave", "onAfterLeave"] }, { kind: "directive", type: AutoFocus, selector: "[pAutoFocus]", inputs: ["pAutoFocus"] }, { kind: "component", type: CascadeSelectSub, selector: "ul[pCascadeSelectSub]", inputs: ["selectId", "activeOptionPath", "optionDisabled", "focusedOptionId", "options", "optionGroupChildren", "optionTemplate", "groupicon", "level", "optionLabel", "optionValue", "optionGroupLabel", "dirty", "root"], outputs: ["onChange", "onFocusChange", "onFocusEnterChange"] }, { kind: "component", type: ChevronDownIcon, selector: "[data-p-icon=\"chevron-down\"]" }, { kind: "component", type: TimesIcon, selector: "[data-p-icon=\"times\"]" }, { kind: "ngmodule", type: SharedModule }, { kind: "directive", type: Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CascadeSelect, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-cascadeSelect, p-cascadeselect, p-cascade-select',
                    standalone: true,
                    imports: [CommonModule, Overlay, AutoFocus, CascadeSelectSub, ChevronDownIcon, TimesIcon, SharedModule, Bind],
                    template: `
        <div class="p-hidden-accessible" [pBind]="ptm('hiddenInputWrapper')">
            <input
                #focusInput
                readonly
                type="text"
                role="combobox"
                [attr.name]="name()"
                [attr.required]="required() ? '' : undefined"
                [attr.disabled]="$disabled() ? '' : undefined"
                [attr.placeholder]="placeholder()"
                [attr.tabindex]="!$disabled() ? tabindex() : -1"
                [attr.id]="inputId()"
                [attr.aria-label]="ariaLabel()"
                [attr.aria-labelledby]="ariaLabelledBy()"
                [attr.aria-haspopup]="'tree'"
                [attr.aria-expanded]="overlayVisible ?? false"
                [attr.aria-controls]="overlayVisible ? id() + '_tree' : null"
                [attr.aria-activedescendant]="focused ? focusedOptionId : undefined"
                (focus)="onInputFocus($event)"
                (blur)="onInputBlur($event)"
                (keydown)="onInputKeyDown($event)"
                [pAutoFocus]="autofocus()"
                [pBind]="ptm('hiddenInput')"
            />
        </div>
        <span [class]="cx('label')" [pBind]="ptm('label')">
            @if (valueTemplate || _valueTemplate) {
                <ng-container *ngTemplateOutlet="valueTemplate || _valueTemplate; context: { $implicit: value(), placeholder: placeholder() }"></ng-container>
            } @else {
                {{ label() }}
            }
        </span>

        @if ($filled() && !$disabled() && showClear()) {
            @if (!clearIconTemplate && !_clearIconTemplate) {
                <svg data-p-icon="times" [class]="cx('clearIcon')" (click)="clear($event)" [pBind]="ptm('clearIcon')" [attr.aria-hidden]="true" />
            }
            @if (clearIconTemplate || _clearIconTemplate) {
                <span [class]="cx('clearIcon')" (click)="clear($event)" [pBind]="ptm('clearIcon')" [attr.aria-hidden]="true">
                    <ng-template *ngTemplateOutlet="clearIconTemplate || _clearIconTemplate"></ng-template>
                </span>
            }
        }

        <div [class]="cx('dropdown')" role="button" aria-haspopup="listbox" [attr.aria-expanded]="overlayVisible ?? false" [pBind]="ptm('dropdown')" [attr.aria-hidden]="true">
            @if (loading()) {
                @if (loadingIconTemplate || _loadingIconTemplate) {
                    <ng-container *ngTemplateOutlet="loadingIconTemplate || _loadingIconTemplate"></ng-container>
                }
                @if (!loadingIconTemplate && !_loadingIconTemplate) {
                    @if (loadingIcon()) {
                        <span [class]="cn(cx('loadingIcon'), loadingIcon() + 'pi-spin')" aria-hidden="true" [pBind]="ptm('loadingIcon')"></span>
                    }
                    @if (!loadingIcon()) {
                        <span [class]="cn(cx('loadingIcon'), loadingIcon() + ' pi pi-spinner pi-spin')" aria-hidden="true" [pBind]="ptm('loadingIcon')"></span>
                    }
                }
            } @else {
                @if (!triggerIconTemplate && !_triggerIconTemplate) {
                    <svg data-p-icon="chevron-down" [class]="cx('dropdownIcon')" [pBind]="ptm('dropdownIcon')" />
                }
                @if (triggerIconTemplate || _triggerIconTemplate) {
                    <span [class]="cx('dropdownIcon')" [pBind]="ptm('dropdownIcon')">
                        <ng-template *ngTemplateOutlet="triggerIconTemplate || _triggerIconTemplate"></ng-template>
                    </span>
                }
            }
        </div>
        <span role="status" aria-live="polite" class="p-hidden-accessible" [pBind]="ptm('hiddenSearchResult')">
            {{ searchResultMessageText }}
        </span>
        <p-overlay
            #overlay
            [hostAttrSelector]="$attrSelector"
            [(visible)]="overlayVisible"
            [options]="overlayOptions()"
            [target]="'@parent'"
            [appendTo]="$appendTo()"
            [unstyled]="unstyled()"
            [pt]="ptm('pcOverlay')"
            [motionOptions]="motionOptions()"
            (onAfterLeave)="onOverlayAfterLeave()"
            (onBeforeShow)="onBeforeShow.emit($event)"
            (onShow)="show($event)"
            (onBeforeHide)="onBeforeHide.emit($event)"
            (onHide)="hide($event)"
        >
            <ng-template #content>
                <div #panel [class]="cn(cx('overlay'), panelStyleClass())" [ngStyle]="panelStyle()" [pBind]="ptm('overlay')">
                    <ng-template *ngTemplateOutlet="headerTemplate() || _headerTemplate"></ng-template>
                    <div [class]="cx('listContainer')" [pBind]="ptm('listContainer')">
                        <ul
                            pCascadeSelectSub
                            [class]="cx('list')"
                            [options]="processedOptions"
                            [selectId]="resolvedId"
                            [focusedOptionId]="focused ? focusedOptionId : undefined"
                            [activeOptionPath]="activeOptionPath()"
                            [optionLabel]="optionLabel()"
                            [optionValue]="optionValue()"
                            [level]="0"
                            [optionTemplate]="optionTemplate() || _optionTemplate"
                            [groupicon]="groupIconTemplate() || groupIconTemplate()"
                            [optionGroupLabel]="optionGroupLabel()"
                            [optionGroupChildren]="optionGroupChildren()"
                            [optionDisabled]="optionDisabled()"
                            [root]="true"
                            (onChange)="onOptionClick($event)"
                            (onFocusChange)="onOptionMouseMove($event)"
                            (onFocusEnterChange)="onOptionMouseEnter($event)"
                            [dirty]="dirty"
                            [attr.role]="'tree'"
                            [attr.aria-orientation]="'horizontal'"
                            [pBind]="ptm('list')"
                            [attr.aria-label]="listlabel"
                            [pt]="pt"
                            [unstyled]="unstyled()"
                        ></ul>
                    </div>
                    <span role="status" aria-live="polite" class="p-hidden-accessible" [pBind]="ptm('selectedMessageText')">
                        {{ selectedMessageText }}
                    </span>
                    <ng-template *ngTemplateOutlet="footerTemplate() || _footerTemplate"></ng-template>
                </div>
            </ng-template>
        </p-overlay>
    `,
                    providers: [CASCADESELECT_VALUE_ACCESSOR, CascadeSelectStyle, { provide: PARENT_INSTANCE, useExisting: CascadeSelect }, { provide: CASCADESELECT_INSTANCE, useExisting: CascadeSelect }],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class]': "cn(cx('root'), styleClass())",
                        '[style]': "sx('root')",
                        '(mousedown)': 'onHostClick($event)'
                    },
                    hostDirectives: [Bind]
                }]
        }], ctorParameters: () => [], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], searchMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "searchMessage", required: false }] }], emptyMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyMessage", required: false }] }], selectionMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectionMessage", required: false }] }], emptySearchMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptySearchMessage", required: false }] }], emptySelectionMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptySelectionMessage", required: false }] }], searchLocale: [{ type: i0.Input, args: [{ isSignal: true, alias: "searchLocale", required: false }] }], optionDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionDisabled", required: false }] }], focusOnHover: [{ type: i0.Input, args: [{ isSignal: true, alias: "focusOnHover", required: false }] }], selectOnFocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectOnFocus", required: false }] }], autoOptionFocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoOptionFocus", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], optionLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionLabel", required: false }] }], optionValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionValue", required: false }] }], optionGroupLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionGroupLabel", required: false }] }], optionGroupChildren: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionGroupChildren", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], dataKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataKey", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], inputLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputLabel", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], showClear: [{ type: i0.Input, args: [{ isSignal: true, alias: "showClear", required: false }] }], panelStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelStyleClass", required: false }] }], panelStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelStyle", required: false }] }], overlayOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "overlayOptions", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], loadingIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "loadingIcon", required: false }] }], breakpoint: [{ type: i0.Input, args: [{ isSignal: true, alias: "breakpoint", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], appendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "appendTo", required: false }] }], motionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "motionOptions", required: false }] }], onChange: [{ type: i0.Output, args: ["onChange"] }], onGroupChange: [{ type: i0.Output, args: ["onGroupChange"] }], onShow: [{ type: i0.Output, args: ["onShow"] }], onHide: [{ type: i0.Output, args: ["onHide"] }], onClear: [{ type: i0.Output, args: ["onClear"] }], onBeforeShow: [{ type: i0.Output, args: ["onBeforeShow"] }], onBeforeHide: [{ type: i0.Output, args: ["onBeforeHide"] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], focusInputViewChild: [{ type: i0.ViewChild, args: ['focusInput', { isSignal: true }] }], panelViewChild: [{ type: i0.ViewChild, args: ['panel', { isSignal: true }] }], overlayViewChild: [{ type: i0.ViewChild, args: ['overlay', { isSignal: true }] }], valueTemplate: [{
                type: ContentChild,
                args: ['value', { descendants: false }]
            }], optionTemplate: [{ type: i0.ContentChild, args: ['option', { ...{ descendants: false }, isSignal: true }] }], headerTemplate: [{ type: i0.ContentChild, args: ['header', { ...{ descendants: false }, isSignal: true }] }], footerTemplate: [{ type: i0.ContentChild, args: ['footer', { ...{ descendants: false }, isSignal: true }] }], triggerIconTemplate: [{
                type: ContentChild,
                args: ['triggericon', { descendants: false }]
            }], loadingIconTemplate: [{
                type: ContentChild,
                args: ['loadingicon', { descendants: false }]
            }], groupIconTemplate: [{ type: i0.ContentChild, args: ['optiongroupicon', { ...{ descendants: false }, isSignal: true }] }], clearIconTemplate: [{
                type: ContentChild,
                args: ['clearicon', { descendants: false }]
            }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class CascadeSelectModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CascadeSelectModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: CascadeSelectModule, imports: [CascadeSelect, SharedModule], exports: [CascadeSelect, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CascadeSelectModule, imports: [CascadeSelect, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CascadeSelectModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CascadeSelect, SharedModule],
                    exports: [CascadeSelect, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { CASCADESELECT_VALUE_ACCESSOR, CascadeSelect, CascadeSelectClasses, CascadeSelectModule, CascadeSelectStyle, CascadeSelectSub };
//# sourceMappingURL=wawjs-ngx-prime-cascadeselect.mjs.map
