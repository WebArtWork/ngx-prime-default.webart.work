export * from '@wawjs/ngx-prime/types/toggleswitch';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, inject, ElementRef, input, booleanAttribute, numberAttribute, output, effect, forwardRef, Directive, InjectionToken, contentChildren, ContentChild, ViewChild, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { PrimeTemplate, SharedModule } from '@wawjs/ngx-prime/api';
import { AutoFocus } from '@wawjs/ngx-prime/autofocus';
import { PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind, BindModule } from '@wawjs/ngx-prime/bind';
import { style as style$1 } from '@wawjs/css-prime-styles/toggleswitch';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import { equals } from '@wawjs/css-prime-utils';

const style = /*css*/ `
    ${style$1}

    /* Native toggle-switch directive: preserve the checkbox while applying the active theme color. */
    input.p-toggleswitch.p-component {
        accent-color: dt('toggleswitch.checked.background');
        cursor: pointer;
    }

    input.p-toggleswitch.p-component.p-disabled,
    input.p-toggleswitch.p-component[readonly] {
        cursor: default;
    }

    p-toggleswitch.ng-invalid.ng-dirty > .p-toggleswitch-slider {
        border-color: dt('toggleswitch.invalid.border.color');
    }
`;
const inlineStyles = {
    root: { position: 'relative' }
};
const classes = {
    root: ({ instance }) => [
        'p-toggleswitch p-component',
        {
            'p-toggleswitch p-component': true,
            'p-toggleswitch-checked': instance.checked(),
            'p-disabled': instance.$disabled(),
            'p-invalid': instance.invalid()
        }
    ],
    input: 'p-toggleswitch-input',
    slider: 'p-toggleswitch-slider',
    handle: 'p-toggleswitch-handle'
};
class ToggleSwitchStyle extends BaseStyle {
    name = 'toggleswitch';
    style = style;
    classes = classes;
    inlineStyles = inlineStyles;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToggleSwitchStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToggleSwitchStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToggleSwitchStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * ToggleSwitch is used to select a boolean value.
 *
 * [Live Demo](https://www.ngx-prime.org/toggleswitch/)
 *
 * @module toggleswitchstyle
 *
 */
var ToggleSwitchClasses;
(function (ToggleSwitchClasses) {
    /**
     * Class name of the root element
     */
    ToggleSwitchClasses["root"] = "p-toggleswitch";
    /**
     * Class name of the input element
     */
    ToggleSwitchClasses["input"] = "p-toggleswitch-input";
    /**
     * Class name of the slider element
     */
    ToggleSwitchClasses["slider"] = "p-toggleswitch-slider";
})(ToggleSwitchClasses || (ToggleSwitchClasses = {}));

/** Adds switch semantics and Prime state attributes to a native checkbox. */
class ToggleSwitchDirective extends BaseEditableHolder {
    componentName = 'ToggleSwitch';
    element = inject(ElementRef);
    _componentStyle = inject(ToggleSwitchStyle);
    bindDirectiveInstance = inject(Bind, { self: true });
    /** @deprecated Use the native `class` attribute instead. */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /** Compatibility input for the directive pass-through configuration. */
    ptToggleSwitch = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ptToggleSwitch" }] : /* istanbul ignore next */ []));
    /** Pass-through configuration for the native toggle switch. */
    pToggleSwitchPT = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "pToggleSwitchPT" }] : /* istanbul ignore next */ []));
    /** Enables unstyled mode for this native toggle switch. */
    pToggleSwitchUnstyled = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "pToggleSwitchUnstyled" }] : /* istanbul ignore next */ []));
    readonly = input(false, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    tabindex = input(undefined, { ...(ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    inputId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "inputId" }] : /* istanbul ignore next */ []));
    autofocus = input(false, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    trueValue = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "trueValue" }] : /* istanbul ignore next */ []));
    falseValue = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "falseValue" }] : /* istanbul ignore next */ []));
    size = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "size" }] : /* istanbul ignore next */ []));
    onChange = output();
    onFocus = output();
    onBlur = output();
    touch = output();
    onInputClick(event) {
        if (this.readonly() || this.$disabled()) {
            event.preventDefault();
        }
    }
    onInputChange(event) {
        const input = event.target;
        if (this.readonly()) {
            input.checked = this.checked();
            return;
        }
        const checked = input.checked ? this.trueValue() : this.falseValue();
        this.writeModelValue(checked);
        this.onModelChange(checked);
        this.onChange.emit({ originalEvent: event, checked: input.checked });
    }
    onInputFocus(event) {
        this.onFocus.emit(event);
    }
    onInputBlur(event) {
        this.onModelTouched();
        this.touch.emit();
        this.onBlur.emit(event);
    }
    checked() {
        return equals(this.modelValue(), this.trueValue());
    }
    constructor() {
        super();
        effect(() => {
            const pt = this.ptToggleSwitch() || this.pToggleSwitchPT();
            if (pt) {
                this.directivePT.set(pt);
            }
        });
        effect(() => {
            if (this.pToggleSwitchUnstyled()) {
                this.directiveUnstyled.set(true);
            }
        });
    }
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptm('root'));
    }
    focus(options) {
        this.element.nativeElement.focus(options);
    }
    writeControlValue(value, setModelValue) {
        setModelValue(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToggleSwitchDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: ToggleSwitchDirective, isStandalone: true, selector: "input[type='checkbox'][pToggleSwitch]", inputs: { styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, ptToggleSwitch: { classPropertyName: "ptToggleSwitch", publicName: "ptToggleSwitch", isSignal: true, isRequired: false, transformFunction: null }, pToggleSwitchPT: { classPropertyName: "pToggleSwitchPT", publicName: "pToggleSwitchPT", isSignal: true, isRequired: false, transformFunction: null }, pToggleSwitchUnstyled: { classPropertyName: "pToggleSwitchUnstyled", publicName: "pToggleSwitchUnstyled", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null }, trueValue: { classPropertyName: "trueValue", publicName: "trueValue", isSignal: true, isRequired: false, transformFunction: null }, falseValue: { classPropertyName: "falseValue", publicName: "falseValue", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onChange: "onChange", onFocus: "onFocus", onBlur: "onBlur", touch: "touch" }, host: { attributes: { "role": "switch" }, listeners: { "click": "onInputClick($event)", "change": "onInputChange($event)", "focus": "onInputFocus($event)", "blur": "onInputBlur($event)" }, properties: { "class": "cn(cx('root'), styleClass())", "attr.data-pc-name": "'toggleswitch'", "attr.data-pc-section": "'input'", "attr.data-p-invalid": "invalid() || null", "attr.aria-label": "ariaLabel() || null", "attr.aria-labelledby": "ariaLabelledBy() || null", "attr.tabindex": "tabindex() ?? null", "attr.id": "inputId() || null", "autofocus": "autofocus()", "disabled": "$disabled()", "required": "required()", "attr.name": "name() || null", "checked": "checked()", "attr.aria-checked": "checked()" } }, providers: [ToggleSwitchStyle, { provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => ToggleSwitchDirective), multi: true }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToggleSwitchDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: "input[type='checkbox'][pToggleSwitch]",
                    standalone: true,
                    host: {
                        '[class]': "cn(cx('root'), styleClass())",
                        role: 'switch',
                        '[attr.data-pc-name]': "'toggleswitch'",
                        '[attr.data-pc-section]': "'input'",
                        '[attr.data-p-invalid]': 'invalid() || null',
                        '[attr.aria-label]': 'ariaLabel() || null',
                        '[attr.aria-labelledby]': 'ariaLabelledBy() || null',
                        '[attr.tabindex]': 'tabindex() ?? null',
                        '[attr.id]': 'inputId() || null',
                        '[autofocus]': 'autofocus()',
                        '[disabled]': '$disabled()',
                        '[required]': 'required()',
                        '[attr.name]': 'name() || null',
                        '[checked]': 'checked()',
                        '[attr.aria-checked]': 'checked()',
                        '(click)': 'onInputClick($event)',
                        '(change)': 'onInputChange($event)',
                        '(focus)': 'onInputFocus($event)',
                        '(blur)': 'onInputBlur($event)'
                    },
                    providers: [ToggleSwitchStyle, { provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => ToggleSwitchDirective), multi: true }],
                    hostDirectives: [Bind]
                }]
        }], ctorParameters: () => [], propDecorators: { styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], ptToggleSwitch: [{ type: i0.Input, args: [{ isSignal: true, alias: "ptToggleSwitch", required: false }] }], pToggleSwitchPT: [{ type: i0.Input, args: [{ isSignal: true, alias: "pToggleSwitchPT", required: false }] }], pToggleSwitchUnstyled: [{ type: i0.Input, args: [{ isSignal: true, alias: "pToggleSwitchUnstyled", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], trueValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "trueValue", required: false }] }], falseValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "falseValue", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], onChange: [{ type: i0.Output, args: ["onChange"] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], touch: [{ type: i0.Output, args: ["touch"] }] } });

const TOGGLESWITCH_INSTANCE = new InjectionToken('TOGGLESWITCH_INSTANCE');
const TOGGLESWITCH_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => ToggleSwitch),
    multi: true
};
/**
 * ToggleSwitch is used to select a boolean value.
 *
 * @deprecated Use a native `<input type="checkbox" pToggleSwitch>` instead.
 * The native control uses the browser indicator; custom handle templates are
 * not available. This component remains available for compatibility and is
 * planned for removal in v23.
 * @group Components
 */
class ToggleSwitch extends BaseEditableHolder {
    componentName = 'ToggleSwitch';
    $pcToggleSwitch = inject(TOGGLESWITCH_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex = input(undefined, { ...(ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Identifier of the input element.
     * @group Props
     */
    inputId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "inputId" }] : /* istanbul ignore next */ []));
    /**
     * When present, it specifies that the component cannot be edited.
     * @group Props
     */
    readonly = input(undefined, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Value in checked state.
     * @group Props
     */
    trueValue = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "trueValue" }] : /* istanbul ignore next */ []));
    /**
     * Value in unchecked state.
     * @group Props
     */
    falseValue = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "falseValue" }] : /* istanbul ignore next */ []));
    /**
     * Used to define a string that autocomplete attribute the current element.
     * @group Props
     */
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /**
     * Specifies the size of the component.
     * @defaultValue undefined
     * @group Props
     */
    size = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "size" }] : /* istanbul ignore next */ []));
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus = input(undefined, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Callback to invoke when the on value change.
     * @param {ToggleSwitchChangeEvent} event - Custom change event.
     * @group Emits
     */
    onChange = output();
    input;
    /**
     * Custom handle template.
     * @param {ToggleSwitchHandleTemplateContext} context - handle context.
     * @see {@link ToggleSwitchHandleTemplateContext}
     * @group Templates
     */
    handleTemplate;
    _handleTemplate;
    focused = false;
    _componentStyle = inject(ToggleSwitchStyle);
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    onHostClick(event) {
        this.onClick(event);
    }
    onAfterContentInit() {
        this.templates().forEach((item) => {
            switch (item.getType()) {
                case 'handle':
                    this._handleTemplate = item.template;
                    break;
                default:
                    this._handleTemplate = item.template;
                    break;
            }
        });
    }
    onClick(event) {
        if (!this.$disabled() && !this.readonly()) {
            this.writeModelValue(this.checked() ? this.falseValue() : this.trueValue());
            this.onModelChange(this.modelValue());
            this.onChange.emit({
                originalEvent: event,
                checked: this.modelValue()
            });
            this.input.nativeElement.focus();
        }
    }
    onFocus() {
        this.focused = true;
    }
    onBlur() {
        this.focused = false;
        this.onModelTouched();
    }
    checked() {
        return this.modelValue() === this.trueValue();
    }
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value, setModelValue) {
        setModelValue(value);
        this.cd.markForCheck();
    }
    get dataP() {
        return this.cn({
            checked: this.checked(),
            disabled: this.$disabled(),
            invalid: this.invalid()
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToggleSwitch, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: ToggleSwitch, isStandalone: true, selector: "p-toggleswitch, p-toggleSwitch, p-toggle-switch", inputs: { styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, trueValue: { classPropertyName: "trueValue", publicName: "trueValue", isSignal: true, isRequired: false, transformFunction: null }, falseValue: { classPropertyName: "falseValue", publicName: "falseValue", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onChange: "onChange" }, host: { listeners: { "click": "onHostClick($event)" }, properties: { "class": "cn(cx('root'), styleClass())", "style": "sx('root')", "attr.data-p-checked": "checked()", "attr.data-p-disabled": "$disabled()", "attr.data-p": "dataP" } }, providers: [TOGGLESWITCH_VALUE_ACCESSOR, ToggleSwitchStyle, { provide: TOGGLESWITCH_INSTANCE, useExisting: ToggleSwitch }, { provide: PARENT_INSTANCE, useExisting: ToggleSwitch }], queries: [{ propertyName: "templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "handleTemplate", first: true, predicate: ["handle"] }], viewQueries: [{ propertyName: "input", first: true, predicate: ["input"], descendants: true }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        <input
            #input
            [attr.id]="inputId()"
            type="checkbox"
            role="switch"
            [class]="cx('input')"
            [checked]="checked()"
            [attr.required]="required() ? '' : undefined"
            [attr.disabled]="$disabled() ? '' : undefined"
            [attr.aria-checked]="checked()"
            [attr.aria-labelledby]="ariaLabelledBy()"
            [attr.aria-label]="ariaLabel()"
            [attr.name]="name()"
            [attr.tabindex]="tabindex()"
            (focus)="onFocus()"
            (blur)="onBlur()"
            [pAutoFocus]="autofocus()"
            [pBind]="ptm('input')"
        />
        <div [class]="cx('slider')" [pBind]="ptm('slider')" [attr.data-p]="dataP">
            <div [class]="cx('handle')" [pBind]="ptm('handle')" [attr.data-p]="dataP">
                @if (handleTemplate || _handleTemplate) {
                    <ng-container *ngTemplateOutlet="handleTemplate || _handleTemplate; context: { checked: checked() }" />
                }
            </div>
        </div>
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: AutoFocus, selector: "[pAutoFocus]", inputs: ["pAutoFocus"] }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: BindModule }, { kind: "directive", type: i1.Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToggleSwitch, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-toggleswitch, p-toggleSwitch, p-toggle-switch',
                    standalone: true,
                    imports: [CommonModule, AutoFocus, SharedModule, BindModule],
                    template: `
        <input
            #input
            [attr.id]="inputId()"
            type="checkbox"
            role="switch"
            [class]="cx('input')"
            [checked]="checked()"
            [attr.required]="required() ? '' : undefined"
            [attr.disabled]="$disabled() ? '' : undefined"
            [attr.aria-checked]="checked()"
            [attr.aria-labelledby]="ariaLabelledBy()"
            [attr.aria-label]="ariaLabel()"
            [attr.name]="name()"
            [attr.tabindex]="tabindex()"
            (focus)="onFocus()"
            (blur)="onBlur()"
            [pAutoFocus]="autofocus()"
            [pBind]="ptm('input')"
        />
        <div [class]="cx('slider')" [pBind]="ptm('slider')" [attr.data-p]="dataP">
            <div [class]="cx('handle')" [pBind]="ptm('handle')" [attr.data-p]="dataP">
                @if (handleTemplate || _handleTemplate) {
                    <ng-container *ngTemplateOutlet="handleTemplate || _handleTemplate; context: { checked: checked() }" />
                }
            </div>
        </div>
    `,
                    providers: [TOGGLESWITCH_VALUE_ACCESSOR, ToggleSwitchStyle, { provide: TOGGLESWITCH_INSTANCE, useExisting: ToggleSwitch }, { provide: PARENT_INSTANCE, useExisting: ToggleSwitch }],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class]': "cn(cx('root'), styleClass())",
                        '[style]': "sx('root')",
                        '[attr.data-p-checked]': 'checked()',
                        '[attr.data-p-disabled]': '$disabled()',
                        '[attr.data-p]': 'dataP',
                        '(click)': 'onHostClick($event)'
                    },
                    hostDirectives: [Bind]
                }]
        }], propDecorators: { styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], trueValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "trueValue", required: false }] }], falseValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "falseValue", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], onChange: [{ type: i0.Output, args: ["onChange"] }], input: [{
                type: ViewChild,
                args: ['input']
            }], handleTemplate: [{
                type: ContentChild,
                args: ['handle', { descendants: false }]
            }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class ToggleSwitchModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToggleSwitchModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: ToggleSwitchModule, imports: [ToggleSwitch, ToggleSwitchDirective, SharedModule], exports: [ToggleSwitch, ToggleSwitchDirective, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToggleSwitchModule, imports: [ToggleSwitch, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToggleSwitchModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [ToggleSwitch, ToggleSwitchDirective, SharedModule],
                    exports: [ToggleSwitch, ToggleSwitchDirective, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { TOGGLESWITCH_VALUE_ACCESSOR, ToggleSwitch, ToggleSwitchClasses, ToggleSwitchDirective, ToggleSwitchModule, ToggleSwitchStyle };
//# sourceMappingURL=wawjs-ngx-prime-toggleswitch.mjs.map
