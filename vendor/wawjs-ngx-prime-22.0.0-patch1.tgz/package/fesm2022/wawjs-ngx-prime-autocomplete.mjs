export * from '@wawjs/ngx-prime/types/autocomplete';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, forwardRef, inject, NgZone, input, numberAttribute, booleanAttribute, output, viewChild, contentChild, signal, computed, effect, contentChildren, ContentChild, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { uuid, equals, isNotEmpty, findLastIndex, resolveFieldData, focus, isEmpty, findSingle } from '@wawjs/css-prime-utils';
import { OverlayService, TranslationKeys, PrimeTemplate, SharedModule } from '@wawjs/ngx-prime/api';
import { AutoFocus } from '@wawjs/ngx-prime/autofocus';
import { PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import { BaseInput } from '@wawjs/ngx-prime/baseinput';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind, BindModule } from '@wawjs/ngx-prime/bind';
import { Chip } from '@wawjs/ngx-prime/chip';
import { TimesCircleIcon, SpinnerIcon, ChevronDownIcon, TimesIcon } from '@wawjs/ngx-prime/icons';
import { InputText } from '@wawjs/ngx-prime/inputtext';
import { Overlay } from '@wawjs/ngx-prime/overlay';
import { Ripple } from '@wawjs/ngx-prime/ripple';
import { Scroller } from '@wawjs/ngx-prime/scroller';
import { style as style$1 } from '@wawjs/css-prime-styles/autocomplete';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const style = /*css*/ `
${style$1}

/* For ngx-prime */
p-autoComplete.ng-invalid.ng-dirty .p-autocomplete-input,
p-autoComplete.ng-invalid.ng-dirty .p-autocomplete-input-multiple,
p-auto-complete.ng-invalid.ng-dirty .p-autocomplete-input,
p-auto-complete.ng-invalid.ng-dirty .p-autocomplete-input-multiple p-autocomplete.ng-invalid.ng-dirty .p-autocomplete-input,
p-autocomplete.ng-invalid.ng-dirty .p-autocomplete-input-multiple {
    border-color: dt('autocomplete.invalid.border.color');
}

p-autoComplete.ng-invalid.ng-dirty .p-autocomplete-input:enabled:focus,
p-autoComplete.ng-invalid.ng-dirty:not(.p-disabled).p-focus .p-autocomplete-input-multiple,
p-auto-complete.ng-invalid.ng-dirty .p-autocomplete-input:enabled:focus,
p-auto-complete.ng-invalid.ng-dirty:not(.p-disabled).p-focus .p-autocomplete-input-multiple,
p-autocomplete.ng-invalid.ng-dirty .p-autocomplete-input:enabled:focus,
p-autocomplete.ng-invalid.ng-dirty:not(.p-disabled).p-focus .p-autocomplete-input-multiple {
    border-color: dt('autocomplete.focus.border.color');
}

p-autoComplete.ng-invalid.ng-dirty .p-autocomplete-input-chip input::placeholder,
p-auto-complete.ng-invalid.ng-dirty .p-autocomplete-input-chip input::placeholder,
p-autocomplete.ng-invalid.ng-dirty .p-autocomplete-input-chip input::placeholder {
    color: dt('autocomplete.invalid.placeholder.color');
}

p-autoComplete.ng-invalid.ng-dirty .p-autocomplete-input::placeholder,
p-auto-complete.ng-invalid.ng-dirty .p-autocomplete-input::placeholder,
p-autocomplete.ng-invalid.ng-dirty .p-autocomplete-input::placeholder {
    color: dt('autocomplete.invalid.placeholder.color');
}
`;
const inlineStyles = {
    root: { position: 'relative' }
};
const classes = {
    root: ({ instance }) => [
        'p-autocomplete p-component p-inputwrapper',
        {
            'p-invalid': instance.invalid(),
            'p-focus': instance.focused,
            'p-inputwrapper-filled': instance.$filled(),
            'p-inputwrapper-focus': (instance.focused && !instance.$disabled()) || instance.autofocus || instance.overlayVisible,
            'p-autocomplete-open': instance.overlayVisible,
            'p-autocomplete-clearable': instance.showClear && !instance.$disabled(),
            'p-autocomplete-fluid': instance.hasFluid
        }
    ],
    pcInputText: 'p-autocomplete-input',
    inputMultiple: ({ instance }) => [
        'p-autocomplete-input-multiple',
        {
            'p-disabled': instance.$disabled(),
            'p-variant-filled': instance.$variant() === 'filled'
        }
    ],
    chipItem: ({ instance, i }) => [
        'p-autocomplete-chip-item',
        {
            'p-focus': instance.focusedMultipleOptionIndex() === i
        }
    ],
    pcChip: 'p-autocomplete-chip',
    chipIcon: 'p-autocomplete-chip-icon',
    inputChip: 'p-autocomplete-input-chip',
    loader: 'p-autocomplete-loader',
    dropdown: 'p-autocomplete-dropdown',
    overlay: ({ instance }) => ['p-autocomplete-overlay p-component-overlay p-component', { 'p-input-filled': instance.$variant() === 'filled', 'p-ripple-disabled': instance.config.ripple() === false }],
    listContainer: 'p-autocomplete-list-container',
    list: 'p-autocomplete-list',
    optionGroup: 'p-autocomplete-option-group',
    option: ({ instance, option, i, scrollerOptions }) => ({
        'p-autocomplete-option': true,
        'p-autocomplete-option-selected': instance.isSelected(option),
        'p-focus': instance.focusedOptionIndex() === instance.getOptionIndex(i, scrollerOptions),
        'p-disabled': instance.isOptionDisabled(option)
    }),
    emptyMessage: 'p-autocomplete-empty-message',
    clearIcon: 'p-autocomplete-clear-icon'
};
class AutoCompleteStyle extends BaseStyle {
    name = 'autocomplete';
    style = style;
    classes = classes;
    inlineStyles = inlineStyles;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AutoCompleteStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AutoCompleteStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AutoCompleteStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * AutoComplete is an input component that provides real-time suggestions while being typed.
 *
 * [Live Demo](https://www.ngx-prime.org/autocomplete/)
 *
 * @module autocompletestyle
 *
 */
var AutoCompleteClasses;
(function (AutoCompleteClasses) {
    /**
     * Class name of the root element
     */
    AutoCompleteClasses["root"] = "p-autocomplete";
    /**
     * Class name of the input element
     */
    AutoCompleteClasses["pcInputText"] = "p-autocomplete-input";
    /**
     * Class name of the input multiple element
     */
    AutoCompleteClasses["inputMultiple"] = "p-autocomplete-input-multiple";
    /**
     * Class name of the chip item element
     */
    AutoCompleteClasses["chipItem"] = "p-autocomplete-chip-item";
    /**
     * Class name of the chip element
     */
    AutoCompleteClasses["pcChip"] = "p-autocomplete-chip";
    /**
     * Class name of the chip icon element
     */
    AutoCompleteClasses["chipIcon"] = "p-autocomplete-chip-icon";
    /**
     * Class name of the input chip element
     */
    AutoCompleteClasses["inputChip"] = "p-autocomplete-input-chip";
    /**
     * Class name of the loader element
     */
    AutoCompleteClasses["loader"] = "p-autocomplete-loader";
    /**
     * Class name of the dropdown element
     */
    AutoCompleteClasses["dropdown"] = "p-autocomplete-dropdown";
    /**
     * Class name of the panel element
     */
    AutoCompleteClasses["panel"] = "p-autocomplete-overlay";
    /**
     * Class name of the list element
     */
    AutoCompleteClasses["list"] = "p-autocomplete-list";
    /**
     * Class name of the option group element
     */
    AutoCompleteClasses["optionGroup"] = "p-autocomplete-option-group";
    /**
     * Class name of the option element
     */
    AutoCompleteClasses["option"] = "p-autocomplete-option";
    /**
     * Class name of the empty message element
     */
    AutoCompleteClasses["emptyMessage"] = "p-autocomplete-empty-message";
    /**
     * Class name of the clear icon
     */
    AutoCompleteClasses["clearIcon"] = "p-autocomplete-clear-icon";
})(AutoCompleteClasses || (AutoCompleteClasses = {}));

const AUTOCOMPLETE_INSTANCE = new InjectionToken('AUTOCOMPLETE_INSTANCE');
const AUTOCOMPLETE_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => AutoComplete),
    multi: true
};
/**
 * AutoComplete is an input component that provides real-time suggestions when being typed.
 * @group Components
 */
class AutoComplete extends BaseInput {
    overlayService = inject(OverlayService);
    zone = inject(NgZone);
    componentName = 'AutoComplete';
    $pcAutoComplete = inject(AUTOCOMPLETE_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    bindDirectiveInstance = inject(Bind, { self: true });
    /**
     * Minimum number of characters to initiate a search.
     * @deprecated since v20.0.0, use `minQueryLength` instead.
     * @group Props
     */
    minLength = input(1, { ...(ngDevMode ? { debugName: "minLength" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Minimum number of characters to initiate a search.
     * @group Props
     */
    minQueryLength = input(undefined, { ...(ngDevMode ? { debugName: "minQueryLength" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Delay between keystrokes to wait before sending a query.
     * @group Props
     */
    delay = input(300, { ...(ngDevMode ? { debugName: "delay" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Inline style of the overlay panel element.
     * @group Props
     */
    panelStyle = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "panelStyle" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the overlay panel element.
     * @group Props
     */
    panelStyleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "panelStyleClass" }] : /* istanbul ignore next */ []));
    /**
     * Inline style of the input field.
     * @group Props
     */
    inputStyle = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "inputStyle" }] : /* istanbul ignore next */ []));
    /**
     * Identifier of the focus input to match a label defined for the component.
     * @group Props
     */
    inputId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "inputId" }] : /* istanbul ignore next */ []));
    /**
     * Inline style of the input field.
     * @group Props
     */
    inputStyleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "inputStyleClass" }] : /* istanbul ignore next */ []));
    /**
     * Hint text for the input field.
     * @group Props
     */
    placeholder = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "placeholder" }] : /* istanbul ignore next */ []));
    /**
     * When present, it specifies that the input cannot be typed.
     * @group Props
     */
    readonly = input(undefined, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Maximum height of the suggestions panel.
     * @group Props
     */
    scrollHeight = input('200px', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scrollHeight" }] : /* istanbul ignore next */ []));
    /**
     * Defines if data is loaded and interacted with in lazy manner.
     * @group Props
     */
    lazy = input(false, { ...(ngDevMode ? { debugName: "lazy" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether the data should be loaded on demand during scroll.
     * @group Props
     */
    virtualScroll = input(undefined, { ...(ngDevMode ? { debugName: "virtualScroll" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Height of an item in the list for VirtualScrolling.
     * @group Props
     */
    virtualScrollItemSize = input(undefined, { ...(ngDevMode ? { debugName: "virtualScrollItemSize" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Whether to use the scroller feature. The properties of scroller component can be used like an object in it.
     * @group Props
     */
    virtualScrollOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "virtualScrollOptions" }] : /* istanbul ignore next */ []));
    /**
     * When enabled, highlights the first item in the list by default.
     * @group Props
     */
    autoHighlight = input(undefined, { ...(ngDevMode ? { debugName: "autoHighlight" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * When present, autocomplete clears the manual input if it does not match of the suggestions to force only accepting values from the suggestions.
     * @group Props
     */
    forceSelection = input(undefined, { ...(ngDevMode ? { debugName: "forceSelection" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Type of the input, defaults to "text".
     * @group Props
     */
    type = input('text', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    /**
     * Whether to automatically manage layering.
     * @group Props
     */
    autoZIndex = input(true, { ...(ngDevMode ? { debugName: "autoZIndex" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Base zIndex value to use in layering.
     * @group Props
     */
    baseZIndex = input(0, { ...(ngDevMode ? { debugName: "baseZIndex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Defines a string that labels the input for accessibility.
     * @group Props
     */
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /**
     * Defines a string that labels the dropdown button for accessibility.
     * @group Props
     */
    dropdownAriaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "dropdownAriaLabel" }] : /* istanbul ignore next */ []));
    /**
     * Specifies one or more IDs in the DOM that labels the input field.
     * @group Props
     */
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    /**
     * Icon class of the dropdown icon.
     * @group Props
     */
    dropdownIcon = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "dropdownIcon" }] : /* istanbul ignore next */ []));
    /**
     * Ensures uniqueness of selected items on multiple mode.
     * @group Props
     */
    unique = input(true, { ...(ngDevMode ? { debugName: "unique" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to display options as grouped when nested options are provided.
     * @group Props
     */
    group = input(undefined, { ...(ngDevMode ? { debugName: "group" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to run a query when input receives focus.
     * @group Props
     */
    completeOnFocus = input(false, { ...(ngDevMode ? { debugName: "completeOnFocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * When enabled, a clear icon is displayed to clear the value.
     * @group Props
     */
    showClear = input(false, { ...(ngDevMode ? { debugName: "showClear" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Displays a button next to the input field when enabled.
     * @group Props
     */
    dropdown = input(undefined, { ...(ngDevMode ? { debugName: "dropdown" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to show the empty message or not.
     * @group Props
     */
    showEmptyMessage = input(true, { ...(ngDevMode ? { debugName: "showEmptyMessage" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Specifies the behavior dropdown button. Default "blank" mode sends an empty string and "current" mode sends the input value.
     * @group Props
     */
    dropdownMode = input('blank', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dropdownMode" }] : /* istanbul ignore next */ []));
    /**
     * Specifies if multiple values can be selected.
     * @group Props
     */
    multiple = input(undefined, { ...(ngDevMode ? { debugName: "multiple" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * When enabled, the input value is added to the selected items on tab key press when multiple is true and typeahead is false.
     * @group Props
     */
    addOnTab = input(false, { ...(ngDevMode ? { debugName: "addOnTab" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex = input(undefined, { ...(ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * A property to uniquely identify a value in options.
     * @group Props
     */
    dataKey = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "dataKey" }] : /* istanbul ignore next */ []));
    /**
     * Text to display when there is no data. Defaults to global value in i18n translation configuration.
     * @group Props
     */
    emptyMessage = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "emptyMessage" }] : /* istanbul ignore next */ []));
    /**
     * Transition options of the show animation.
     * @group Props
     * @deprecated since v21.0.0, use `motionOptions` instead.
     */
    showTransitionOptions = input('.12s cubic-bezier(0, 0, 0.2, 1)', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showTransitionOptions" }] : /* istanbul ignore next */ []));
    /**
     * Transition options of the hide animation.
     * @group Props
     * @deprecated since v21.0.0, use `motionOptions` instead.
     */
    hideTransitionOptions = input('.1s linear', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hideTransitionOptions" }] : /* istanbul ignore next */ []));
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus = input(undefined, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Used to define a string that autocomplete attribute the current element.
     * @group Props
     */
    autocomplete = input('off', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "autocomplete" }] : /* istanbul ignore next */ []));
    /**
     * Name of the options field of an option group.
     * @group Props
     */
    optionGroupChildren = input('items', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "optionGroupChildren" }] : /* istanbul ignore next */ []));
    /**
     * Name of the label field of an option group.
     * @group Props
     */
    optionGroupLabel = input('label', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "optionGroupLabel" }] : /* istanbul ignore next */ []));
    /**
     * Options for the overlay element.
     * @group Props
     */
    overlayOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "overlayOptions" }] : /* istanbul ignore next */ []));
    /**
     * An array of suggestions to display.
     * @group Props
     */
    suggestions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "suggestions" }] : /* istanbul ignore next */ []));
    /**
     * Property name or getter function to use as the label of an option.
     * @group Props
     */
    optionLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "optionLabel" }] : /* istanbul ignore next */ []));
    /**
     * Property name or getter function to use as the value of an option.
     * @group Props
     */
    optionValue = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "optionValue" }] : /* istanbul ignore next */ []));
    /**
     * Unique identifier of the component.
     * @group Props
     */
    id = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "id" }] : /* istanbul ignore next */ []));
    _generatedId;
    get resolvedId() {
        return this.id() || (this._generatedId ??= uuid('pn_id_'));
    }
    /**
     * Text to display when the search is active. Defaults to global value in i18n translation configuration.
     * @group Props
     * @defaultValue '{0} results are available'
     */
    searchMessage = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "searchMessage" }] : /* istanbul ignore next */ []));
    /**
     * Text to display when filtering does not return any results. Defaults to global value in i18n translation configuration.
     * @group Props
     * @defaultValue 'No selected item'
     */
    emptySelectionMessage = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "emptySelectionMessage" }] : /* istanbul ignore next */ []));
    /**
     * Text to be displayed in hidden accessible field when options are selected. Defaults to global value in i18n translation configuration.
     * @group Props
     * @defaultValue '{0} items selected'
     */
    selectionMessage = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "selectionMessage" }] : /* istanbul ignore next */ []));
    /**
     * Whether to focus on the first visible or selected element when the overlay panel is shown.
     * @group Props
     */
    autoOptionFocus = input(false, { ...(ngDevMode ? { debugName: "autoOptionFocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * When enabled, the focused option is selected.
     * @group Props
     */
    selectOnFocus = input(undefined, { ...(ngDevMode ? { debugName: "selectOnFocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Locale to use in searching. The default locale is the host environment's current locale.
     * @group Props
     */
    searchLocale = input(undefined, { ...(ngDevMode ? { debugName: "searchLocale" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Property name or getter function to use as the disabled flag of an option, defaults to false when not defined.
     * @group Props
     */
    optionDisabled = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "optionDisabled" }] : /* istanbul ignore next */ []));
    /**
     * When enabled, the hovered option will be focused.
     * @group Props
     */
    focusOnHover = input(true, { ...(ngDevMode ? { debugName: "focusOnHover" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether typeahead is active or not.
     * @defaultValue true
     * @group Props
     */
    typeahead = input(true, { ...(ngDevMode ? { debugName: "typeahead" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to add an item on blur event if the input has value and typeahead is false with multiple mode.
     * @defaultValue false
     * @group Props
     */
    addOnBlur = input(false, { ...(ngDevMode ? { debugName: "addOnBlur" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Separator char to add item when typeahead is false and multiple mode is enabled.
     * @group Props
     */
    separator = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "separator" }] : /* istanbul ignore next */ []));
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'self'
     * @group Props
     */
    appendTo = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "appendTo" }] : /* istanbul ignore next */ []));
    /**
     * The motion options.
     * @group Props
     */
    motionOptions = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "motionOptions" }] : /* istanbul ignore next */ []));
    /**
     * Callback to invoke to search for suggestions.
     * @param {AutoCompleteCompleteEvent} event - Custom complete event.
     * @group Emits
     */
    completeMethod = output();
    /**
     * Callback to invoke when a suggestion is selected.
     * @param {AutoCompleteSelectEvent} event - custom select event.
     * @group Emits
     */
    onSelect = output();
    /**
     * Callback to invoke when a selected value is removed.
     * @param {AutoCompleteUnselectEvent} event - custom unselect event.
     * @group Emits
     */
    onUnselect = output();
    /**
     * Callback to invoke when an item is added via addOnBlur or separator features.
     * @param {AutoCompleteAddEvent} event - Custom add event.
     * @group Emits
     */
    onAdd = output();
    /**
     * Callback to invoke when the component receives focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onFocus = output();
    /**
     * Callback to invoke when the component loses focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onBlur = output();
    /**
     * Callback to invoke to when dropdown button is clicked.
     * @param {AutoCompleteDropdownClickEvent} event - custom dropdown click event.
     * @group Emits
     */
    onDropdownClick = output();
    /**
     * Callback to invoke when clear button is clicked.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onClear = output();
    /**
     * Callback to invoke on input key down.
     * @param {KeyboardEvent} event - Keyboard event.
     * @group Emits
     */
    onInputKeydown = output();
    /**
     * Callback to invoke on input key up.
     * @param {KeyboardEvent} event - Keyboard event.
     * @group Emits
     */
    onKeyUp = output();
    /**
     * Callback to invoke on overlay is shown.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onShow = output();
    /**
     * Callback to invoke on overlay is hidden.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onHide = output();
    /**
     * Callback to invoke on lazy load data.
     * @param {AutoCompleteLazyLoadEvent} event - Lazy load event.
     * @group Emits
     */
    onLazyLoad = output();
    inputEL = viewChild('focusInput', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputEL" }] : /* istanbul ignore next */ []));
    multiInputEl = viewChild('multiIn', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "multiInputEl" }] : /* istanbul ignore next */ []));
    multiContainerEL = viewChild('multiContainer', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "multiContainerEL" }] : /* istanbul ignore next */ []));
    dropdownButton = viewChild('ddBtn', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dropdownButton" }] : /* istanbul ignore next */ []));
    itemsViewChild = viewChild('items', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "itemsViewChild" }] : /* istanbul ignore next */ []));
    scroller = viewChild('scroller', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scroller" }] : /* istanbul ignore next */ []));
    overlayViewChild = viewChild.required('overlay', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "overlayViewChild" }] : /* istanbul ignore next */ []));
    itemsWrapper;
    /**
     * Custom item template.
     * @group Templates
     */
    itemTemplate = contentChild('item', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "itemTemplate" }] : /* istanbul ignore next */ []));
    /**
     * Custom empty message template.
     * @group Templates
     */
    emptyTemplate = contentChild('empty', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyTemplate" }] : /* istanbul ignore next */ []));
    /**
     * Custom header template.
     * @group Templates
     */
    headerTemplate = contentChild('header', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "headerTemplate" }] : /* istanbul ignore next */ []));
    /**
     * Custom footer template.
     * @group Templates
     */
    footerTemplate = contentChild('footer', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "footerTemplate" }] : /* istanbul ignore next */ []));
    /**
     * Custom selected item template.
     * @group Templates
     */
    selectedItemTemplate = contentChild('selecteditem', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectedItemTemplate" }] : /* istanbul ignore next */ []));
    /**
     * Custom group template.
     * @group Templates
     */
    groupTemplate = contentChild('group', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "groupTemplate" }] : /* istanbul ignore next */ []));
    /**
     * Custom loader template.
     * @group Templates
     */
    loaderTemplate;
    /**
     * Custom remove icon template.
     * @group Templates
     */
    removeIconTemplate;
    /**
     * Custom loading icon template.
     * @group Templates
     */
    loadingIconTemplate;
    /**
     * Custom clear icon template.
     * @group Templates
     */
    clearIconTemplate;
    /**
     * Custom dropdown icon template.
     * @group Templates
     */
    dropdownIconTemplate = contentChild('dropdownicon', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "dropdownIconTemplate" }] : /* istanbul ignore next */ []));
    onHostClick(event) {
        this.onContainerClick(event);
    }
    value;
    _suggestions = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_suggestions" }] : /* istanbul ignore next */ []));
    timeout;
    overlayVisible;
    suggestionsUpdated;
    highlightOption;
    highlightOptionChanged;
    focused = false;
    loading;
    scrollHandler;
    listId;
    searchTimeout;
    dirty = false;
    _itemTemplate;
    _groupTemplate;
    _selectedItemTemplate;
    _headerTemplate;
    _emptyTemplate;
    _footerTemplate;
    _loaderTemplate;
    _removeIconTemplate;
    _loadingIconTemplate;
    _clearIconTemplate;
    _dropdownIconTemplate;
    focusedMultipleOptionIndex = signal(-1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusedMultipleOptionIndex" }] : /* istanbul ignore next */ []));
    focusedOptionIndex = signal(-1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusedOptionIndex" }] : /* istanbul ignore next */ []));
    _componentStyle = inject(AutoCompleteStyle);
    $appendTo = computed(() => this.appendTo() || this.config.overlayAppendTo(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "$appendTo" }] : /* istanbul ignore next */ []));
    visibleOptions = computed(() => (this.group() ? this.flatOptions(this._suggestions()) : this._suggestions() || []), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visibleOptions" }] : /* istanbul ignore next */ []));
    inputValue = computed(() => {
        const modelValue = this.modelValue();
        const selectedOption = this.optionValueSelected ? (this._suggestions() || []).find((option) => equals(option, modelValue, this.equalityKey())) : modelValue;
        if (isNotEmpty(modelValue)) {
            if (typeof modelValue === 'object' || this.optionValueSelected) {
                const label = this.getOptionLabel(selectedOption);
                return label != null ? label : modelValue;
            }
            else {
                return modelValue;
            }
        }
        else {
            return '';
        }
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputValue" }] : /* istanbul ignore next */ []));
    get focusedMultipleOptionId() {
        return this.focusedMultipleOptionIndex() !== -1 ? `${this.resolvedId}_multiple_option_${this.focusedMultipleOptionIndex()}` : null;
    }
    get focusedOptionId() {
        return this.focusedOptionIndex() !== -1 ? `${this.resolvedId}_${this.focusedOptionIndex()}` : null;
    }
    get searchResultMessageText() {
        return isNotEmpty(this.visibleOptions()) && this.overlayVisible ? this.searchMessageText.replaceAll('{0}', this.visibleOptions().length) : this.emptySearchMessageText;
    }
    get searchMessageText() {
        return this.searchMessage() || this.config.translation.searchMessage || '';
    }
    get emptySearchMessageText() {
        return this.emptyMessage() || this.config.translation.emptySearchMessage || '';
    }
    get selectionMessageText() {
        return this.selectionMessage() || this.config.translation.selectionMessage || '';
    }
    get emptySelectionMessageText() {
        return this.emptySelectionMessage() || this.config.translation.emptySelectionMessage || '';
    }
    get selectedMessageText() {
        return this.hasSelectedOption() ? this.selectionMessageText.replaceAll('{0}', this.multiple() ? this.modelValue()?.length : '1') : this.emptySelectionMessageText;
    }
    get ariaSetSize() {
        return this.visibleOptions().filter((option) => !this.isOptionGroup(option)).length;
    }
    get listLabel() {
        return this.config.getTranslation(TranslationKeys.ARIA)['listLabel'];
    }
    get virtualScrollerDisabled() {
        return !this.virtualScroll();
    }
    get optionValueSelected() {
        return typeof this.modelValue() === 'string' && this.optionValue();
    }
    chipItemClass(index) {
        return this._componentStyle.classes.chipItem({ instance: this, i: index });
    }
    constructor() {
        super();
        effect(() => {
            this._suggestions.set(this.suggestions());
            this.handleSuggestionsChange();
        });
    }
    onInit() {
        this.cd.detectChanges();
    }
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    onAfterContentInit() {
        this.templates().forEach((item) => {
            switch (item.getType()) {
                case 'item':
                    this._itemTemplate = item.template;
                    break;
                case 'group':
                    this._groupTemplate = item.template;
                    break;
                case 'selecteditem':
                    this._selectedItemTemplate = item.template;
                    break;
                case 'selectedItem':
                    this._selectedItemTemplate = item.template;
                    break;
                case 'header':
                    this._headerTemplate = item.template;
                    break;
                case 'empty':
                    this._emptyTemplate = item.template;
                    break;
                case 'footer':
                    this._footerTemplate = item.template;
                    break;
                case 'loader':
                    this._loaderTemplate = item.template;
                    break;
                case 'removetokenicon':
                    this._removeIconTemplate = item.template;
                    break;
                case 'loadingicon':
                    this._loadingIconTemplate = item.template;
                    break;
                case 'clearicon':
                    this._clearIconTemplate = item.template;
                    break;
                case 'dropdownicon':
                    this._dropdownIconTemplate = item.template;
                    break;
                default:
                    this._itemTemplate = item.template;
                    break;
            }
        });
    }
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
        //Use timeouts as since Angular 4.2, AfterViewChecked is broken and not called after panel is updated
        if (this.suggestionsUpdated && this.overlayViewChild()) {
            this.zone.runOutsideAngular(() => {
                setTimeout(() => {
                    const overlayViewChild = this.overlayViewChild();
                    if (overlayViewChild) {
                        overlayViewChild.alignOverlay();
                    }
                }, 1);
                this.suggestionsUpdated = false;
            });
        }
    }
    handleSuggestionsChange() {
        if (this.loading) {
            this._suggestions()?.length > 0 || this.showEmptyMessage() || !!this.emptyTemplate() ? this.show() : this.hide();
            const focusedOptionIndex = this.overlayVisible && this.autoOptionFocus() ? this.findFirstFocusedOptionIndex() : -1;
            this.focusedOptionIndex.set(focusedOptionIndex);
            this.suggestionsUpdated = true;
            this.loading = false;
            this.cd.markForCheck();
        }
    }
    flatOptions(options) {
        return (options || []).reduce((result, option, index) => {
            result.push({ optionGroup: option, group: true, index });
            const optionGroupChildren = this.getOptionGroupChildren(option);
            optionGroupChildren && optionGroupChildren.forEach((o) => result.push(o));
            return result;
        }, []);
    }
    isOptionGroup(option) {
        return this.optionGroupLabel() && option.optionGroup && option.group;
    }
    findFirstOptionIndex() {
        return this.visibleOptions().findIndex((option) => this.isValidOption(option));
    }
    findLastOptionIndex() {
        return findLastIndex(this.visibleOptions(), (option) => this.isValidOption(option));
    }
    findFirstFocusedOptionIndex() {
        const selectedIndex = this.findSelectedOptionIndex();
        return selectedIndex < 0 ? this.findFirstOptionIndex() : selectedIndex;
    }
    findLastFocusedOptionIndex() {
        const selectedIndex = this.findSelectedOptionIndex();
        return selectedIndex < 0 ? this.findLastOptionIndex() : selectedIndex;
    }
    findSelectedOptionIndex() {
        return this.hasSelectedOption() ? this.visibleOptions().findIndex((option) => this.isValidSelectedOption(option)) : -1;
    }
    findNextOptionIndex(index) {
        const matchedOptionIndex = index < this.visibleOptions().length - 1
            ? this.visibleOptions()
                .slice(index + 1)
                .findIndex((option) => this.isValidOption(option))
            : -1;
        return matchedOptionIndex > -1 ? matchedOptionIndex + index + 1 : index;
    }
    findPrevOptionIndex(index) {
        const matchedOptionIndex = index > 0 ? findLastIndex(this.visibleOptions().slice(0, index), (option) => this.isValidOption(option)) : -1;
        return matchedOptionIndex > -1 ? matchedOptionIndex : index;
    }
    isValidSelectedOption(option) {
        return this.isValidOption(option) && this.isSelected(option);
    }
    isValidOption(option) {
        return option && !(this.isOptionDisabled(option) || this.isOptionGroup(option));
    }
    isOptionDisabled(option) {
        const optionDisabled = this.optionDisabled();
        return optionDisabled ? resolveFieldData(option, optionDisabled) : false;
    }
    isSelected(option) {
        if (this.multiple()) {
            return this.unique() ? this.modelValue()?.some((model) => equals(model, option, this.equalityKey())) : false;
        }
        return equals(this.modelValue(), option, this.equalityKey());
    }
    isOptionMatched(option, value) {
        return this.isValidOption(option) && this.getOptionLabel(option).toLocaleLowerCase(this.searchLocale()) === value.toLocaleLowerCase(this.searchLocale());
    }
    isInputClicked(event) {
        return event.target === this.inputEL()?.nativeElement;
    }
    isDropdownClicked(event) {
        const dropdownButton = this.dropdownButton();
        return dropdownButton?.nativeElement ? event.target === dropdownButton.nativeElement || dropdownButton.nativeElement.contains(event.target) : false;
    }
    equalityKey() {
        return this.optionValue() ? undefined : this.dataKey();
    }
    onContainerClick(event) {
        if (this.$disabled() || this.loading || this.isInputClicked(event) || this.isDropdownClicked(event)) {
            return;
        }
        const overlayViewChild = this.overlayViewChild();
        if (!overlayViewChild || !overlayViewChild.overlayViewChild()?.nativeElement.contains(event.target)) {
            focus(this.inputEL()?.nativeElement);
        }
    }
    handleDropdownClick(event) {
        let query = undefined;
        if (this.overlayVisible) {
            this.hide(true);
        }
        else {
            const inputEL = this.inputEL();
            focus(inputEL?.nativeElement);
            query = inputEL?.nativeElement?.value;
            const dropdownMode = this.dropdownMode();
            if (dropdownMode === 'blank')
                this.search(event, '', 'dropdown');
            else if (dropdownMode === 'current')
                this.search(event, query, 'dropdown');
        }
        this.onDropdownClick.emit({ originalEvent: event, query });
    }
    onInput(event) {
        if (this.typeahead()) {
            const _minLength = this.minQueryLength() || this.minLength();
            if (this.searchTimeout) {
                clearTimeout(this.searchTimeout);
            }
            let query = event.target.value;
            if (this.maxlength() !== null) {
                query = query.split('').slice(0, this.maxlength()).join('');
            }
            const multiple = this.multiple();
            if (!multiple && !this.forceSelection()) {
                this.updateModel(query);
            }
            if (query.length === 0 && !multiple) {
                this.onClear.emit(undefined);
                setTimeout(() => {
                    this.hide();
                }, this.delay() / 2);
            }
            else {
                if (query.length >= _minLength) {
                    this.focusedOptionIndex.set(-1);
                    this.searchTimeout = setTimeout(() => {
                        this.search(event, query, 'input');
                    }, this.delay());
                }
                else {
                    this.hide();
                }
            }
        }
    }
    onInputChange(event) {
        this.updateInputWithForceSelection(event);
    }
    onInputFocus(event) {
        if (this.$disabled()) {
            // For ScreenReaders
            return;
        }
        if (!this.dirty && this.completeOnFocus()) {
            this.search(event, event.target.value, 'focus');
        }
        this.dirty = true;
        this.focused = true;
        const focusedOptionIndex = this.focusedOptionIndex() !== -1 ? this.focusedOptionIndex() : this.overlayVisible && this.autoOptionFocus() ? this.findFirstFocusedOptionIndex() : -1;
        this.focusedOptionIndex.set(focusedOptionIndex);
        this.overlayVisible && this.scrollInView(this.focusedOptionIndex());
        this.onFocus.emit(event);
    }
    onMultipleContainerFocus() {
        if (this.$disabled()) {
            // For ScreenReaders
            return;
        }
        this.focused = true;
    }
    onMultipleContainerBlur() {
        this.focusedMultipleOptionIndex.set(-1);
        this.focused = false;
    }
    onMultipleContainerKeyDown(event) {
        if (this.$disabled()) {
            event.preventDefault();
            return;
        }
        switch (event.code) {
            case 'ArrowLeft':
                this.onArrowLeftKeyOnMultiple();
                break;
            case 'ArrowRight':
                this.onArrowRightKeyOnMultiple();
                break;
            case 'Backspace':
                this.onBackspaceKeyOnMultiple(event);
                break;
            default:
                break;
        }
    }
    onInputBlur(event) {
        this.dirty = false;
        this.focused = false;
        this.focusedOptionIndex.set(-1);
        if (this.addOnBlur() && this.multiple() && !this.typeahead()) {
            const inputValue = (this.multiInputEl()?.nativeElement?.value || event.target.value || '').trim();
            if (inputValue && !this.isSelected(inputValue)) {
                this.updateModel([...(this.modelValue() || []), inputValue]);
                this.onAdd.emit({ originalEvent: event, value: inputValue });
                const multiInputEl = this.multiInputEl();
                if (multiInputEl?.nativeElement) {
                    multiInputEl.nativeElement.value = '';
                }
                else {
                    event.target.value = '';
                }
            }
        }
        this.onModelTouched();
        this.onBlur.emit(event);
    }
    onInputPaste(event) {
        const separator = this.separator();
        if (separator && this.multiple() && !this.typeahead()) {
            const pastedData = (event.clipboardData || window['clipboardData'])?.getData('Text');
            if (pastedData) {
                const values = pastedData.split(separator);
                const newValues = [...(this.modelValue() || [])];
                values.forEach((value) => {
                    const trimmedValue = value.trim();
                    if (trimmedValue && !this.isSelected(trimmedValue)) {
                        newValues.push(trimmedValue);
                    }
                });
                if (newValues.length > (this.modelValue() || []).length) {
                    const addedValues = newValues.slice((this.modelValue() || []).length);
                    this.updateModel(newValues);
                    addedValues.forEach((addedValue) => {
                        this.onAdd.emit({ originalEvent: event, value: addedValue });
                    });
                    const multiInputEl = this.multiInputEl();
                    if (multiInputEl?.nativeElement) {
                        multiInputEl.nativeElement.value = '';
                    }
                    else {
                        event.target.value = '';
                    }
                    event.preventDefault();
                }
            }
        }
        else {
            this.onKeyDown(event);
        }
    }
    onInputKeyUp(event) {
        this.onKeyUp.emit(event);
    }
    onKeyDown(event) {
        if (this.$disabled()) {
            event.preventDefault();
            return;
        }
        // Emit keydown event for external handling
        this.onInputKeydown.emit(event);
        switch (event.code) {
            case 'ArrowDown':
                this.onArrowDownKey(event);
                break;
            case 'ArrowUp':
                this.onArrowUpKey(event);
                break;
            case 'ArrowLeft':
                this.onArrowLeftKey(event);
                break;
            case 'ArrowRight':
                this.onArrowRightKey(event);
                break;
            case 'Home':
                this.onHomeKey(event);
                break;
            case 'End':
                this.onEndKey(event);
                break;
            case 'PageDown':
                this.onPageDownKey(event);
                break;
            case 'PageUp':
                this.onPageUpKey(event);
                break;
            case 'Enter':
            case 'NumpadEnter':
                this.onEnterKey(event);
                break;
            case 'Escape':
                this.onEscapeKey(event);
                break;
            case 'Tab':
                this.onTabKey(event);
                break;
            case 'Backspace':
                this.onBackspaceKey(event);
                break;
            case 'ShiftLeft':
            case 'ShiftRight':
                //NOOP
                break;
            default:
                this.handleSeparatorKey(event);
                break;
        }
    }
    handleSeparatorKey(event) {
        const separator = this.separator();
        if (separator && this.multiple() && !this.typeahead()) {
            if (separator === event.key || (typeof separator === 'string' && event.key === separator) || (separator instanceof RegExp && event.key.match(separator))) {
                const inputValue = (this.multiInputEl()?.nativeElement?.value || event.target.value || '').trim();
                if (inputValue && !this.isSelected(inputValue)) {
                    this.updateModel([...(this.modelValue() || []), inputValue]);
                    this.onAdd.emit({ originalEvent: event, value: inputValue });
                    const multiInputEl = this.multiInputEl();
                    if (multiInputEl?.nativeElement) {
                        multiInputEl.nativeElement.value = '';
                    }
                    else {
                        event.target.value = '';
                    }
                    event.preventDefault();
                }
            }
        }
    }
    onArrowDownKey(event) {
        if (!this.overlayVisible) {
            return;
        }
        const optionIndex = this.focusedOptionIndex() !== -1 ? this.findNextOptionIndex(this.focusedOptionIndex()) : this.findFirstFocusedOptionIndex();
        this.changeFocusedOptionIndex(event, optionIndex);
        event.preventDefault();
        event.stopPropagation();
    }
    onArrowUpKey(event) {
        if (!this.overlayVisible) {
            return;
        }
        if (event.altKey) {
            if (this.focusedOptionIndex() !== -1) {
                this.onOptionSelect(event, this.visibleOptions()[this.focusedOptionIndex()]);
            }
            this.overlayVisible && this.hide();
            event.preventDefault();
        }
        else {
            const optionIndex = this.focusedOptionIndex() !== -1 ? this.findPrevOptionIndex(this.focusedOptionIndex()) : this.findLastFocusedOptionIndex();
            this.changeFocusedOptionIndex(event, optionIndex);
            event.preventDefault();
            event.stopPropagation();
        }
    }
    onArrowLeftKey(event) {
        const target = event.currentTarget;
        this.focusedOptionIndex.set(-1);
        if (this.multiple()) {
            if (isEmpty(target.value) && this.hasSelectedOption()) {
                focus(this.multiContainerEL()?.nativeElement);
                this.focusedMultipleOptionIndex.set(this.modelValue().length);
            }
            else {
                event.stopPropagation(); // To prevent onArrowLeftKeyOnMultiple method
            }
        }
    }
    onArrowRightKey(event) {
        this.focusedOptionIndex.set(-1);
        this.multiple() && event.stopPropagation(); // To prevent onArrowRightKeyOnMultiple method
    }
    onHomeKey(event) {
        const { currentTarget } = event;
        const len = currentTarget.value.length;
        currentTarget.setSelectionRange(0, event.shiftKey ? len : 0);
        this.focusedOptionIndex.set(-1);
        event.preventDefault();
    }
    onEndKey(event) {
        const { currentTarget } = event;
        const len = currentTarget.value.length;
        currentTarget.setSelectionRange(event.shiftKey ? 0 : len, len);
        this.focusedOptionIndex.set(-1);
        event.preventDefault();
    }
    onPageDownKey(event) {
        this.scrollInView(this.visibleOptions().length - 1);
        event.preventDefault();
    }
    onPageUpKey(event) {
        this.scrollInView(0);
        event.preventDefault();
    }
    onEnterKey(event) {
        if (!this.typeahead() && !this.forceSelection()) {
            if (this.multiple()) {
                const inputValue = event.target.value?.trim();
                if (inputValue && !this.isSelected(inputValue)) {
                    this.updateModel([...(this.modelValue() || []), inputValue]);
                    this.onAdd.emit({ originalEvent: event, value: inputValue });
                    const inputEL = this.inputEL();
                    inputEL?.nativeElement && (inputEL.nativeElement.value = '');
                }
            }
        }
        if (!this.overlayVisible) {
            return;
        }
        else {
            if (this.focusedOptionIndex() !== -1) {
                this.onOptionSelect(event, this.visibleOptions()[this.focusedOptionIndex()]);
            }
            this.hide();
        }
        event.preventDefault();
    }
    onEscapeKey(event) {
        this.overlayVisible && this.hide(true);
        event.preventDefault();
    }
    onTabKey(event) {
        // If there's a focused option in the dropdown, select it
        if (this.focusedOptionIndex() !== -1) {
            this.onOptionSelect(event, this.visibleOptions()[this.focusedOptionIndex()]);
            return;
        }
        // Handle tab key behavior for multiple mode without typeahead
        if (this.multiple() && !this.typeahead()) {
            const inputValue = (this.multiInputEl()?.nativeElement?.value || this.inputEL()?.nativeElement?.value || '').trim();
            if (this.addOnTab()) {
                if (inputValue && !this.isSelected(inputValue)) {
                    // Add the value and keep focus
                    this.updateModel([...(this.modelValue() || []), inputValue]);
                    this.onAdd.emit({ originalEvent: event, value: inputValue });
                    const inputEL = this.inputEL();
                    const multiInputEl = this.multiInputEl();
                    if (multiInputEl?.nativeElement) {
                        multiInputEl.nativeElement.value = '';
                    }
                    else if (inputEL?.nativeElement) {
                        inputEL.nativeElement.value = '';
                    }
                    this.updateInputValue();
                    event.preventDefault(); // Keep focus on the component
                    this.overlayVisible && this.hide();
                    return;
                }
                // If no value or already selected, allow normal tab behavior (blur)
            }
            // If addOnTab is false or no value to add, allow normal tab behavior
            // which will trigger blur and potentially addOnBlur
        }
        this.overlayVisible && this.hide();
    }
    onBackspaceKey(event) {
        if (this.multiple()) {
            if (isNotEmpty(this.modelValue()) && !this.inputEL()?.nativeElement?.value) {
                const removedValue = this.modelValue()[this.modelValue().length - 1];
                const newValue = this.modelValue().slice(0, -1);
                this.updateModel(newValue);
                this.onUnselect.emit({ originalEvent: event, value: removedValue });
            }
            event.stopPropagation(); // To prevent onBackspaceKeyOnMultiple method
        }
    }
    onArrowLeftKeyOnMultiple() {
        const optionIndex = this.focusedMultipleOptionIndex() < 1 ? 0 : this.focusedMultipleOptionIndex() - 1;
        this.focusedMultipleOptionIndex.set(optionIndex);
    }
    onArrowRightKeyOnMultiple() {
        let optionIndex = this.focusedMultipleOptionIndex();
        optionIndex++;
        this.focusedMultipleOptionIndex.set(optionIndex);
        if (optionIndex > this.modelValue().length - 1) {
            this.focusedMultipleOptionIndex.set(-1);
            focus(this.inputEL()?.nativeElement);
        }
    }
    onBackspaceKeyOnMultiple(event) {
        if (this.focusedMultipleOptionIndex() !== -1) {
            this.removeOption(event, this.focusedMultipleOptionIndex());
        }
    }
    onOptionSelect(event, option, isHide = true) {
        if (this.multiple()) {
            const inputEL = this.inputEL();
            inputEL?.nativeElement && (inputEL.nativeElement.value = '');
            if (!this.isSelected(option)) {
                this.updateModel([...(this.modelValue() || []), option]);
            }
        }
        else {
            this.updateModel(option);
        }
        this.onSelect.emit({ originalEvent: event, value: option });
        isHide && this.hide(true);
    }
    onOptionMouseEnter(event, index) {
        if (this.focusOnHover()) {
            this.changeFocusedOptionIndex(event, index);
        }
    }
    search(event, query, source) {
        //allow empty string but not undefined or null
        if (query === undefined || query === null) {
            return;
        }
        //do not search blank values on input change
        if (source === 'input' && query.trim().length === 0) {
            return;
        }
        this.loading = true;
        this.completeMethod.emit({ originalEvent: event, query });
    }
    removeOption(event, index) {
        event.stopPropagation();
        const removedOption = this.modelValue()[index];
        const value = this.modelValue().filter((_, i) => i !== index);
        this.updateModel(value);
        this.onUnselect.emit({ originalEvent: event, value: removedOption });
        focus(this.inputEL()?.nativeElement);
    }
    updateModel(options) {
        let value = null;
        if (options) {
            value = this.multiple() ? options.map((option) => this.getOptionValue(option)) : this.getOptionValue(options);
        }
        this.value = value;
        this.writeModelValue(options);
        this.onModelChange(value);
        this.updateInputValue();
        this.cd.markForCheck();
    }
    updateInputValue() {
        const inputEL = this.inputEL();
        if (inputEL && inputEL.nativeElement) {
            if (!this.multiple()) {
                inputEL.nativeElement.value = this.inputValue();
            }
            else {
                inputEL.nativeElement.value = '';
            }
        }
    }
    updateInputWithForceSelection(event) {
        const input = this.inputEL()?.nativeElement;
        const inputCleared = !input?.value && isNotEmpty(this.modelValue());
        if (!this.forceSelection() || this.overlayVisible || (!input?.value && !inputCleared)) {
            return;
        }
        const _minLength = this.minQueryLength() ?? this.minLength();
        if (!inputCleared && input.value.length < _minLength) {
            return;
        }
        const matchedOption = this.visibleOptions()?.find((option) => this.isOptionMatched(option, input.value));
        if (!matchedOption) {
            input.value = '';
            if (!this.multiple()) {
                this.clear();
            }
            return;
        }
        if (matchedOption && !this.isSelected(matchedOption)) {
            this.onOptionSelect(event, matchedOption);
        }
    }
    autoUpdateModel() {
        if ((this.selectOnFocus() || this.autoHighlight()) && this.autoOptionFocus() && !this.hasSelectedOption()) {
            const focusedOptionIndex = this.findFirstFocusedOptionIndex();
            this.focusedOptionIndex.set(focusedOptionIndex);
            this.onOptionSelect(null, this.visibleOptions()[this.focusedOptionIndex()], false);
        }
    }
    scrollInView(index = -1) {
        const id = index !== -1 ? `${this.resolvedId}_${index}` : this.focusedOptionId;
        const itemsViewChild = this.itemsViewChild();
        if (itemsViewChild && itemsViewChild.nativeElement) {
            const element = findSingle(itemsViewChild.nativeElement, `li[id="${id}"]`);
            if (element) {
                element.scrollIntoView && element.scrollIntoView({ block: 'nearest', inline: 'nearest' });
            }
            else if (!this.virtualScrollerDisabled) {
                setTimeout(() => {
                    this.virtualScroll() && this.scroller()?.scrollToIndex(index !== -1 ? index : this.focusedOptionIndex());
                }, 0);
            }
        }
    }
    changeFocusedOptionIndex(event, index) {
        if (this.focusedOptionIndex() !== index) {
            this.focusedOptionIndex.set(index);
            this.scrollInView();
            if (this.selectOnFocus()) {
                this.onOptionSelect(event, this.visibleOptions()[index], false);
            }
        }
    }
    show(isFocus = false) {
        this.dirty = true;
        this.overlayVisible = true;
        const focusedOptionIndex = this.focusedOptionIndex() !== -1 ? this.focusedOptionIndex() : this.autoOptionFocus() ? this.findFirstFocusedOptionIndex() : -1;
        this.focusedOptionIndex.set(focusedOptionIndex);
        isFocus && focus(this.inputEL()?.nativeElement);
        if (isFocus) {
            focus(this.inputEL()?.nativeElement);
        }
        this.onShow.emit(undefined);
        this.cd.markForCheck();
    }
    hide(isFocus = false) {
        const _hide = () => {
            this.dirty = isFocus;
            this.overlayVisible = false;
            this.focusedOptionIndex.set(-1);
            isFocus && focus(this.inputEL()?.nativeElement);
            this.onHide.emit(undefined);
            this.updateInputWithForceSelection(null);
            this.cd.markForCheck();
        };
        setTimeout(() => {
            _hide();
        }, 0); // For ScreenReaders
    }
    clear() {
        this.updateModel(null);
        const inputEL = this.inputEL();
        inputEL?.nativeElement && (inputEL.nativeElement.value = '');
        this.onClear.emit(undefined);
    }
    hasSelectedOption() {
        return isNotEmpty(this.modelValue());
    }
    getAriaPosInset(index) {
        return ((this.optionGroupLabel()
            ? index -
                this.visibleOptions()
                    .slice(0, index)
                    .filter((option) => this.isOptionGroup(option)).length
            : index) + 1);
    }
    getOptionLabel(option) {
        const optionLabel = this.optionLabel();
        return optionLabel ? resolveFieldData(option, optionLabel) : option && option.label != undefined ? option.label : option;
    }
    getOptionValue(option) {
        const optionValue = this.optionValue();
        return optionValue ? resolveFieldData(option, optionValue) : option && option.value != undefined ? option.value : option;
    }
    getOptionIndex(index, scrollerOptions) {
        return this.virtualScrollerDisabled ? index : scrollerOptions && scrollerOptions.getItemOptions(index)['index'];
    }
    getOptionGroupLabel(optionGroup) {
        const optionGroupLabel = this.optionGroupLabel();
        return optionGroupLabel ? resolveFieldData(optionGroup, optionGroupLabel) : optionGroup && optionGroup.label != undefined ? optionGroup.label : optionGroup;
    }
    getOptionGroupChildren(optionGroup) {
        const optionGroupChildren = this.optionGroupChildren();
        return optionGroupChildren ? resolveFieldData(optionGroup, optionGroupChildren) : optionGroup.items;
    }
    getPTOptions(option, scrollerOptions, index, key) {
        return this.ptm(key, {
            context: {
                option,
                index: this.getOptionIndex(index, scrollerOptions),
                selected: this.isSelected(option),
                focused: this.focusedOptionIndex() === this.getOptionIndex(index, scrollerOptions),
                disabled: this.isOptionDisabled(option)
            }
        });
    }
    onOverlayBeforeEnter() {
        this.itemsWrapper = findSingle(this.overlayViewChild().overlayViewChild()?.nativeElement, this.virtualScroll() ? '[data-pc-name="virtualscroller"]' : '[data-pc-name="pcoverlay"]');
        const scroller = this.scroller();
        const virtualScroll = this.virtualScroll();
        if (virtualScroll) {
            scroller?.setContentEl(this.itemsViewChild()?.nativeElement);
            scroller?.viewInit();
        }
        if (this.visibleOptions() && this.visibleOptions().length) {
            if (virtualScroll) {
                const selectedIndex = this.modelValue() ? this.focusedOptionIndex() : -1;
                if (selectedIndex !== -1) {
                    scroller?.scrollToIndex(selectedIndex);
                }
            }
            else {
                let selectedListItem = findSingle(this.itemsWrapper, '[data-pc-section="option"][data-p-selected="true"]');
                if (selectedListItem) {
                    selectedListItem.scrollIntoView({ block: 'nearest', inline: 'center' });
                }
            }
        }
    }
    get containerDataP() {
        return this.cn({
            fluid: this.hasFluid
        });
    }
    get overlayDataP() {
        return this.cn({
            [`overlay-${this.$appendTo()}`]: true
        });
    }
    get inputMultipleDataP() {
        return this.cn({
            invalid: this.invalid(),
            disabled: this.$disabled(),
            focus: this.focused,
            fluid: this.hasFluid,
            filled: this.$variant() === 'filled',
            empty: !this.$filled(),
            [this.size()]: this.size()
        });
    }
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value, setModelValue) {
        if (this.multiple()) {
            const resolved = (value || []).map((val) => {
                const match = this.visibleOptions().find((option) => equals(val, option, this.equalityKey()));
                return match ?? val;
            });
            setModelValue(isEmpty(value) ? value : resolved);
        }
        else {
            const option = this.visibleOptions().find((option) => equals(value, option, this.equalityKey()));
            setModelValue(isEmpty(option) ? value : option);
        }
        this.value = value;
        this.updateInputValue();
        this.cd.markForCheck();
    }
    onDestroy() {
        if (this.scrollHandler) {
            this.scrollHandler.destroy();
            this.scrollHandler = null;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AutoComplete, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: AutoComplete, isStandalone: true, selector: "p-autoComplete, p-autocomplete, p-auto-complete", inputs: { minLength: { classPropertyName: "minLength", publicName: "minLength", isSignal: true, isRequired: false, transformFunction: null }, minQueryLength: { classPropertyName: "minQueryLength", publicName: "minQueryLength", isSignal: true, isRequired: false, transformFunction: null }, delay: { classPropertyName: "delay", publicName: "delay", isSignal: true, isRequired: false, transformFunction: null }, panelStyle: { classPropertyName: "panelStyle", publicName: "panelStyle", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, panelStyleClass: { classPropertyName: "panelStyleClass", publicName: "panelStyleClass", isSignal: true, isRequired: false, transformFunction: null }, inputStyle: { classPropertyName: "inputStyle", publicName: "inputStyle", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, inputStyleClass: { classPropertyName: "inputStyleClass", publicName: "inputStyleClass", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, scrollHeight: { classPropertyName: "scrollHeight", publicName: "scrollHeight", isSignal: true, isRequired: false, transformFunction: null }, lazy: { classPropertyName: "lazy", publicName: "lazy", isSignal: true, isRequired: false, transformFunction: null }, virtualScroll: { classPropertyName: "virtualScroll", publicName: "virtualScroll", isSignal: true, isRequired: false, transformFunction: null }, virtualScrollItemSize: { classPropertyName: "virtualScrollItemSize", publicName: "virtualScrollItemSize", isSignal: true, isRequired: false, transformFunction: null }, virtualScrollOptions: { classPropertyName: "virtualScrollOptions", publicName: "virtualScrollOptions", isSignal: true, isRequired: false, transformFunction: null }, autoHighlight: { classPropertyName: "autoHighlight", publicName: "autoHighlight", isSignal: true, isRequired: false, transformFunction: null }, forceSelection: { classPropertyName: "forceSelection", publicName: "forceSelection", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, autoZIndex: { classPropertyName: "autoZIndex", publicName: "autoZIndex", isSignal: true, isRequired: false, transformFunction: null }, baseZIndex: { classPropertyName: "baseZIndex", publicName: "baseZIndex", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, dropdownAriaLabel: { classPropertyName: "dropdownAriaLabel", publicName: "dropdownAriaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, dropdownIcon: { classPropertyName: "dropdownIcon", publicName: "dropdownIcon", isSignal: true, isRequired: false, transformFunction: null }, unique: { classPropertyName: "unique", publicName: "unique", isSignal: true, isRequired: false, transformFunction: null }, group: { classPropertyName: "group", publicName: "group", isSignal: true, isRequired: false, transformFunction: null }, completeOnFocus: { classPropertyName: "completeOnFocus", publicName: "completeOnFocus", isSignal: true, isRequired: false, transformFunction: null }, showClear: { classPropertyName: "showClear", publicName: "showClear", isSignal: true, isRequired: false, transformFunction: null }, dropdown: { classPropertyName: "dropdown", publicName: "dropdown", isSignal: true, isRequired: false, transformFunction: null }, showEmptyMessage: { classPropertyName: "showEmptyMessage", publicName: "showEmptyMessage", isSignal: true, isRequired: false, transformFunction: null }, dropdownMode: { classPropertyName: "dropdownMode", publicName: "dropdownMode", isSignal: true, isRequired: false, transformFunction: null }, multiple: { classPropertyName: "multiple", publicName: "multiple", isSignal: true, isRequired: false, transformFunction: null }, addOnTab: { classPropertyName: "addOnTab", publicName: "addOnTab", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, dataKey: { classPropertyName: "dataKey", publicName: "dataKey", isSignal: true, isRequired: false, transformFunction: null }, emptyMessage: { classPropertyName: "emptyMessage", publicName: "emptyMessage", isSignal: true, isRequired: false, transformFunction: null }, showTransitionOptions: { classPropertyName: "showTransitionOptions", publicName: "showTransitionOptions", isSignal: true, isRequired: false, transformFunction: null }, hideTransitionOptions: { classPropertyName: "hideTransitionOptions", publicName: "hideTransitionOptions", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null }, autocomplete: { classPropertyName: "autocomplete", publicName: "autocomplete", isSignal: true, isRequired: false, transformFunction: null }, optionGroupChildren: { classPropertyName: "optionGroupChildren", publicName: "optionGroupChildren", isSignal: true, isRequired: false, transformFunction: null }, optionGroupLabel: { classPropertyName: "optionGroupLabel", publicName: "optionGroupLabel", isSignal: true, isRequired: false, transformFunction: null }, overlayOptions: { classPropertyName: "overlayOptions", publicName: "overlayOptions", isSignal: true, isRequired: false, transformFunction: null }, suggestions: { classPropertyName: "suggestions", publicName: "suggestions", isSignal: true, isRequired: false, transformFunction: null }, optionLabel: { classPropertyName: "optionLabel", publicName: "optionLabel", isSignal: true, isRequired: false, transformFunction: null }, optionValue: { classPropertyName: "optionValue", publicName: "optionValue", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, searchMessage: { classPropertyName: "searchMessage", publicName: "searchMessage", isSignal: true, isRequired: false, transformFunction: null }, emptySelectionMessage: { classPropertyName: "emptySelectionMessage", publicName: "emptySelectionMessage", isSignal: true, isRequired: false, transformFunction: null }, selectionMessage: { classPropertyName: "selectionMessage", publicName: "selectionMessage", isSignal: true, isRequired: false, transformFunction: null }, autoOptionFocus: { classPropertyName: "autoOptionFocus", publicName: "autoOptionFocus", isSignal: true, isRequired: false, transformFunction: null }, selectOnFocus: { classPropertyName: "selectOnFocus", publicName: "selectOnFocus", isSignal: true, isRequired: false, transformFunction: null }, searchLocale: { classPropertyName: "searchLocale", publicName: "searchLocale", isSignal: true, isRequired: false, transformFunction: null }, optionDisabled: { classPropertyName: "optionDisabled", publicName: "optionDisabled", isSignal: true, isRequired: false, transformFunction: null }, focusOnHover: { classPropertyName: "focusOnHover", publicName: "focusOnHover", isSignal: true, isRequired: false, transformFunction: null }, typeahead: { classPropertyName: "typeahead", publicName: "typeahead", isSignal: true, isRequired: false, transformFunction: null }, addOnBlur: { classPropertyName: "addOnBlur", publicName: "addOnBlur", isSignal: true, isRequired: false, transformFunction: null }, separator: { classPropertyName: "separator", publicName: "separator", isSignal: true, isRequired: false, transformFunction: null }, appendTo: { classPropertyName: "appendTo", publicName: "appendTo", isSignal: true, isRequired: false, transformFunction: null }, motionOptions: { classPropertyName: "motionOptions", publicName: "motionOptions", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { completeMethod: "completeMethod", onSelect: "onSelect", onUnselect: "onUnselect", onAdd: "onAdd", onFocus: "onFocus", onBlur: "onBlur", onDropdownClick: "onDropdownClick", onClear: "onClear", onInputKeydown: "onInputKeydown", onKeyUp: "onKeyUp", onShow: "onShow", onHide: "onHide", onLazyLoad: "onLazyLoad" }, host: { listeners: { "click": "onHostClick($event)" }, properties: { "class": "cn(cx('root'), styleClass())", "style": "sx('root')", "attr.data-p": "containerDataP" } }, providers: [AUTOCOMPLETE_VALUE_ACCESSOR, AutoCompleteStyle, { provide: AUTOCOMPLETE_INSTANCE, useExisting: AutoComplete }, { provide: PARENT_INSTANCE, useExisting: AutoComplete }], queries: [{ propertyName: "itemTemplate", first: true, predicate: ["item"], descendants: true, isSignal: true }, { propertyName: "emptyTemplate", first: true, predicate: ["empty"], descendants: true, isSignal: true }, { propertyName: "headerTemplate", first: true, predicate: ["header"], descendants: true, isSignal: true }, { propertyName: "footerTemplate", first: true, predicate: ["footer"], descendants: true, isSignal: true }, { propertyName: "selectedItemTemplate", first: true, predicate: ["selecteditem"], descendants: true, isSignal: true }, { propertyName: "groupTemplate", first: true, predicate: ["group"], descendants: true, isSignal: true }, { propertyName: "dropdownIconTemplate", first: true, predicate: ["dropdownicon"], descendants: true, isSignal: true }, { propertyName: "templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "loaderTemplate", first: true, predicate: ["loader"], descendants: true }, { propertyName: "removeIconTemplate", first: true, predicate: ["removeicon"], descendants: true }, { propertyName: "loadingIconTemplate", first: true, predicate: ["loadingicon"], descendants: true }, { propertyName: "clearIconTemplate", first: true, predicate: ["clearicon"], descendants: true }], viewQueries: [{ propertyName: "inputEL", first: true, predicate: ["focusInput"], descendants: true, isSignal: true }, { propertyName: "multiInputEl", first: true, predicate: ["multiIn"], descendants: true, isSignal: true }, { propertyName: "multiContainerEL", first: true, predicate: ["multiContainer"], descendants: true, isSignal: true }, { propertyName: "dropdownButton", first: true, predicate: ["ddBtn"], descendants: true, isSignal: true }, { propertyName: "itemsViewChild", first: true, predicate: ["items"], descendants: true, isSignal: true }, { propertyName: "scroller", first: true, predicate: ["scroller"], descendants: true, isSignal: true }, { propertyName: "overlayViewChild", first: true, predicate: ["overlay"], descendants: true, isSignal: true }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        @if (!multiple()) {
            <input
                #focusInput
                [pAutoFocus]="autofocus()"
                pInputText
                [pt]="ptm('pcInputText')"
                [class]="cn(cx('pcInputText'), inputStyleClass())"
                [ngStyle]="inputStyle()"
                [attr.type]="type()"
                [attr.value]="inputValue()"
                [variant]="$variant()"
                [invalid]="invalid()"
                [attr.id]="inputId()"
                [attr.autocomplete]="autocomplete()"
                aria-autocomplete="list"
                role="combobox"
                [attr.placeholder]="placeholder()"
                [attr.name]="name()"
                [attr.minlength]="minlength()"
                [pSize]="size()"
                [attr.min]="min()"
                [attr.max]="max()"
                [attr.pattern]="pattern()"
                [attr.size]="inputSize()"
                [attr.maxlength]="maxlength()"
                [attr.tabindex]="!$disabled() ? tabindex() : -1"
                [attr.required]="required() ? '' : undefined"
                [attr.readonly]="readonly() ? '' : undefined"
                [attr.disabled]="$disabled() ? '' : undefined"
                [attr.aria-label]="ariaLabel()"
                [attr.aria-labelledby]="ariaLabelledBy()"
                [attr.aria-required]="required()"
                [attr.aria-expanded]="overlayVisible ?? false"
                [attr.aria-controls]="overlayVisible ? id() + '_list' : null"
                [attr.aria-activedescendant]="focused ? focusedOptionId : undefined"
                (input)="onInput($event)"
                (keydown)="onKeyDown($event)"
                (change)="onInputChange($event)"
                (focus)="onInputFocus($event)"
                (blur)="onInputBlur($event)"
                (paste)="onInputPaste($event)"
                (keyup)="onInputKeyUp($event)"
                [fluid]="hasFluid"
                [pInputTextUnstyled]="unstyled()"
            />
        }
        @if ($filled() && !$disabled() && showClear() && !loading) {
            <ng-container>
                @if (!clearIconTemplate && !_clearIconTemplate) {
                    <svg data-p-icon="times" [pBind]="ptm('clearIcon')" [class]="cx('clearIcon')" (click)="clear()" [attr.aria-hidden]="true" />
                }
                @if (clearIconTemplate || _clearIconTemplate) {
                    <span [pBind]="ptm('clearIcon')" [class]="cx('clearIcon')" (click)="clear()" [attr.aria-hidden]="true">
                        <ng-template *ngTemplateOutlet="clearIconTemplate || _clearIconTemplate"></ng-template>
                    </span>
                }
            </ng-container>
        }

        @if (multiple()) {
            <ul
                #multiContainer
                [pBind]="ptm('inputMultiple')"
                [class]="cx('inputMultiple')"
                [attr.data-p]="inputMultipleDataP"
                [tabindex]="-1"
                role="listbox"
                [attr.aria-orientation]="'horizontal'"
                [attr.aria-activedescendant]="focused ? focusedMultipleOptionId : undefined"
                (focus)="onMultipleContainerFocus($event)"
                (blur)="onMultipleContainerBlur($event)"
                (keydown)="onMultipleContainerKeyDown($event)"
            >
                @for (option of modelValue(); track option; let i = $index) {
                    <li
                        #token
                        [pBind]="ptm('chipItem')"
                        [class]="cx('chipItem', { i })"
                        [attr.id]="id() + '_multiple_option_' + i"
                        role="option"
                        [attr.aria-label]="getOptionLabel(option)"
                        [attr.aria-setsize]="modelValue().length"
                        [attr.aria-posinset]="i + 1"
                        [attr.aria-selected]="true"
                    >
                        <p-chip
                            [pt]="ptm('pcChip')"
                            [class]="cx('pcChip')"
                            [label]="!selectedItemTemplate() && !_selectedItemTemplate && getOptionLabel(option)"
                            [disabled]="$disabled()"
                            [removable]="true"
                            (onRemove)="!readonly() ? removeOption($event, i) : ''"
                            [unstyled]="unstyled()"
                        >
                            <ng-container *ngTemplateOutlet="selectedItemTemplate() || _selectedItemTemplate; context: { $implicit: option }"></ng-container>
                            <ng-template #removeicon>
                                @if (!removeIconTemplate && !_removeIconTemplate) {
                                    <span [pBind]="ptm('chipIcon')" [class]="cx('chipIcon')" (click)="!readonly() && !$disabled() ? removeOption($event, i) : ''">
                                        <svg data-p-icon="times-circle" [class]="cx('chipIcon')" [attr.aria-hidden]="true" />
                                    </span>
                                }
                                @if (removeIconTemplate || _removeIconTemplate) {
                                    <span [pBind]="ptm('chipIcon')" [attr.aria-hidden]="true">
                                        <ng-template *ngTemplateOutlet="removeIconTemplate || _removeIconTemplate; context: { removeCallback: removeOption.bind(this), index: i, class: cx('chipIcon') }"></ng-template>
                                    </span>
                                }
                            </ng-template>
                        </p-chip>
                    </li>
                }
                <li [pBind]="ptm('inputChip')" [class]="cx('inputChip')" role="option">
                    <input
                        #focusInput
                        #multiIn
                        [pAutoFocus]="autofocus()"
                        [pBind]="ptm('input')"
                        [class]="cx('pcInputText')"
                        [ngStyle]="inputStyle()"
                        [attr.type]="type()"
                        [attr.id]="inputId()"
                        [attr.autocomplete]="autocomplete()"
                        [attr.name]="name()"
                        [attr.minlength]="minlength()"
                        [attr.maxlength]="maxlength()"
                        [attr.size]="size()"
                        [attr.min]="min()"
                        [attr.max]="max()"
                        [attr.pattern]="pattern()"
                        role="combobox"
                        [attr.placeholder]="!$filled() ? placeholder() : null"
                        aria-autocomplete="list"
                        [attr.tabindex]="!$disabled() ? tabindex() : -1"
                        [attr.required]="required() ? '' : undefined"
                        [attr.readonly]="readonly() ? '' : undefined"
                        [attr.disabled]="$disabled() ? '' : undefined"
                        [attr.aria-label]="ariaLabel()"
                        [attr.aria-labelledby]="ariaLabelledBy()"
                        [attr.aria-required]="required()"
                        [attr.aria-expanded]="overlayVisible ?? false"
                        [attr.aria-controls]="overlayVisible ? id() + '_list' : null"
                        [attr.aria-activedescendant]="focused ? focusedOptionId : undefined"
                        (input)="onInput($event)"
                        (keydown)="onKeyDown($event)"
                        (change)="onInputChange($event)"
                        (focus)="onInputFocus($event)"
                        (blur)="onInputBlur($event)"
                        (paste)="onInputPaste($event)"
                        (keyup)="onInputKeyUp($event)"
                    />
                </li>
            </ul>
        }
        @if (loading) {
            <ng-container>
                @if (!loadingIconTemplate && !_loadingIconTemplate) {
                    <svg data-p-icon="spinner" [pBind]="ptm('loader')" [class]="cx('loader')" [spin]="true" [attr.aria-hidden]="true" />
                }
                @if (loadingIconTemplate || _loadingIconTemplate) {
                    <span [pBind]="ptm('loader')" [class]="cx('loader')" [attr.aria-hidden]="true">
                        <ng-template *ngTemplateOutlet="loadingIconTemplate || _loadingIconTemplate"></ng-template>
                    </span>
                }
            </ng-container>
        }
        @if (dropdown()) {
            <button #ddBtn type="button" [pBind]="ptm('dropdown')" [attr.aria-label]="dropdownAriaLabel()" [class]="cx('dropdown')" [disabled]="$disabled()" pRipple (click)="handleDropdownClick($event)" [attr.tabindex]="tabindex()">
                @if (dropdownIcon()) {
                    <span [ngClass]="dropdownIcon()" [attr.aria-hidden]="true"></span>
                }
                @if (!dropdownIcon()) {
                    <ng-container>
                        @if (!dropdownIconTemplate() && !_dropdownIconTemplate) {
                            <svg data-p-icon="chevron-down" [pBind]="ptm('dropdown')" />
                        }
                        <ng-template *ngTemplateOutlet="dropdownIconTemplate() || _dropdownIconTemplate"></ng-template>
                    </ng-container>
                }
            </button>
        }
        <p-overlay
            #overlay
            [hostAttrSelector]="$attrSelector"
            [(visible)]="overlayVisible"
            [options]="overlayOptions()"
            [target]="'@parent'"
            [appendTo]="$appendTo()"
            [unstyled]="unstyled()"
            [pt]="ptm('pcOverlay')"
            [motionOptions]="motionOptions()"
            (onBeforeEnter)="onOverlayBeforeEnter()"
            (onHide)="hide()"
            [attr.data-p]="overlayDataP"
        >
            <ng-template #content>
                <div [pBind]="ptm('overlay')" [class]="cn(cx('overlay'), panelStyleClass())" [ngStyle]="panelStyle()">
                    <ng-container *ngTemplateOutlet="headerTemplate() || _headerTemplate"></ng-container>
                    <div [pBind]="ptm('listContainer')" [class]="cx('listContainer')" [style.max-height]="virtualScroll() ? 'auto' : scrollHeight()" [tabindex]="-1">
                        @if (virtualScroll()) {
                            <p-scroller
                                #scroller
                                [tabindex]="-1"
                                [pt]="ptm('virtualScroller')"
                                [items]="visibleOptions()"
                                [style]="{ height: scrollHeight() }"
                                [itemSize]="virtualScrollItemSize()"
                                [autoSize]="true"
                                [lazy]="lazy()"
                                (onLazyLoad)="onLazyLoad.emit($event)"
                                [options]="virtualScrollOptions()"
                            >
                                <ng-template #content let-items let-scrollerOptions="options">
                                    <ng-container *ngTemplateOutlet="buildInItems; context: { $implicit: items, options: scrollerOptions }"></ng-container>
                                </ng-template>
                                @if (loaderTemplate || _loaderTemplate) {
                                    <ng-template #loader let-scrollerOptions="options">
                                        <ng-container *ngTemplateOutlet="loaderTemplate || _loaderTemplate; context: { options: scrollerOptions }"></ng-container>
                                    </ng-template>
                                }
                            </p-scroller>
                        }
                        @if (!virtualScroll()) {
                            <ng-container *ngTemplateOutlet="buildInItems; context: { $implicit: visibleOptions(), options: {} }"></ng-container>
                        }
                    </div>

                    <ng-template #buildInItems let-items let-scrollerOptions="options">
                        <ul #items [pBind]="ptm('list')" [class]="cn(cx('list'), scrollerOptions.contentStyleClass)" [style]="scrollerOptions.contentStyle" role="listbox" [attr.id]="id() + '_list'" [attr.aria-label]="listLabel">
                            @for (option of items; track option; let i = $index) {
                                @if (isOptionGroup(option)) {
                                    <li [pBind]="ptm('optionGroup')" [attr.id]="id() + '_' + getOptionIndex(i, scrollerOptions)" [class]="cx('optionGroup')" [ngStyle]="{ height: scrollerOptions.itemSize + 'px' }" role="option">
                                        @if (!groupTemplate()) {
                                            <span>{{ getOptionGroupLabel(option.optionGroup) }}</span>
                                        }
                                        <ng-container *ngTemplateOutlet="groupTemplate(); context: { $implicit: option.optionGroup }"></ng-container>
                                    </li>
                                }
                                @if (!isOptionGroup(option)) {
                                    <li
                                        pRipple
                                        [pBind]="getPTOptions(option, scrollerOptions, i, 'option')"
                                        [ngStyle]="{ height: scrollerOptions.itemSize + 'px' }"
                                        [class]="cx('option', { option, i, scrollerOptions })"
                                        [attr.id]="id() + '_' + getOptionIndex(i, scrollerOptions)"
                                        role="option"
                                        [attr.aria-label]="getOptionLabel(option)"
                                        [attr.aria-selected]="isSelected(option)"
                                        [attr.data-p-selected]="isSelected(option)"
                                        [attr.aria-disabled]="isOptionDisabled(option)"
                                        [attr.data-p-focused]="focusedOptionIndex() === getOptionIndex(i, scrollerOptions)"
                                        [attr.aria-setsize]="ariaSetSize"
                                        [attr.aria-posinset]="getAriaPosInset(getOptionIndex(i, scrollerOptions))"
                                        (click)="onOptionSelect($event, option)"
                                        (mouseenter)="onOptionMouseEnter($event, getOptionIndex(i, scrollerOptions))"
                                    >
                                        @if (!itemTemplate() && !_itemTemplate) {
                                            <span>{{ getOptionLabel(option) }}</span>
                                        }
                                        <ng-container
                                            *ngTemplateOutlet="
                                                itemTemplate() || _itemTemplate;
                                                context: {
                                                    $implicit: option,
                                                    index: scrollerOptions.getOptions ? scrollerOptions.getOptions(i) : i
                                                }
                                            "
                                        ></ng-container>
                                    </li>
                                }
                            }
                            @if (!items || (items && items.length === 0 && showEmptyMessage())) {
                                <li [pBind]="ptm('emptyMessage')" [class]="cx('emptyMessage')" [ngStyle]="{ height: scrollerOptions.itemSize + 'px' }" role="option">
                                    @if (!emptyTemplate() && !_emptyTemplate) {
                                        {{ searchResultMessageText }}
                                    } @else {
                                        <ng-container *ngTemplateOutlet="emptyTemplate() || _emptyTemplate"></ng-container>
                                    }
                                </li>
                            }
                        </ul>
                    </ng-template>
                    <ng-container *ngTemplateOutlet="footerTemplate() || _footerTemplate"></ng-container>
                </div>
                <span role="status" aria-live="polite" class="p-hidden-accessible">
                    {{ selectedMessageText }}
                </span>
            </ng-template>
        </p-overlay>
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: Overlay, selector: "p-overlay", inputs: ["hostName", "visible", "mode", "style", "styleClass", "contentStyle", "contentStyleClass", "target", "autoZIndex", "baseZIndex", "showTransitionOptions", "hideTransitionOptions", "listener", "responsive", "options", "appendTo", "inline", "motionOptions", "hostAttrSelector"], outputs: ["visibleChange", "onBeforeShow", "onShow", "onBeforeHide", "onHide", "onAnimationStart", "onAnimationDone", "onBeforeEnter", "onEnter", "onAfterEnter", "onBeforeLeave", "onLeave", "onAfterLeave"] }, { kind: "directive", type: InputText, selector: "[pInputText]", inputs: ["hostName", "ptInputText", "pInputTextPT", "pInputTextUnstyled", "pSize", "variant", "fluid", "invalid"] }, { kind: "directive", type: Ripple, selector: "[pRipple]" }, { kind: "component", type: Scroller, selector: "p-scroller, p-virtualscroller, p-virtual-scroller, p-virtualScroller", inputs: ["hostName", "id", "style", "styleClass", "tabindex", "items", "itemSize", "scrollHeight", "scrollWidth", "orientation", "step", "delay", "resizeDelay", "appendOnly", "inline", "lazy", "disabled", "loaderDisabled", "columns", "showSpacer", "showLoader", "numToleratedItems", "loading", "autoSize", "trackBy", "options"], outputs: ["onLazyLoad", "onScroll", "onScrollIndexChange"] }, { kind: "directive", type: AutoFocus, selector: "[pAutoFocus]", inputs: ["pAutoFocus"] }, { kind: "component", type: TimesCircleIcon, selector: "[data-p-icon=\"times-circle\"]" }, { kind: "component", type: SpinnerIcon, selector: "[data-p-icon=\"spinner\"]" }, { kind: "component", type: ChevronDownIcon, selector: "[data-p-icon=\"chevron-down\"]" }, { kind: "component", type: Chip, selector: "p-chip", inputs: ["label", "icon", "image", "alt", "styleClass", "disabled", "removable", "removeIcon", "chipProps"], outputs: ["onRemove", "onImageError"] }, { kind: "ngmodule", type: SharedModule }, { kind: "component", type: TimesIcon, selector: "[data-p-icon=\"times\"]" }, { kind: "ngmodule", type: BindModule }, { kind: "directive", type: i1.Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AutoComplete, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-autoComplete, p-autocomplete, p-auto-complete',
                    standalone: true,
                    imports: [CommonModule, Overlay, InputText, Ripple, Scroller, AutoFocus, TimesCircleIcon, SpinnerIcon, ChevronDownIcon, Chip, SharedModule, TimesIcon, BindModule],
                    template: `
        @if (!multiple()) {
            <input
                #focusInput
                [pAutoFocus]="autofocus()"
                pInputText
                [pt]="ptm('pcInputText')"
                [class]="cn(cx('pcInputText'), inputStyleClass())"
                [ngStyle]="inputStyle()"
                [attr.type]="type()"
                [attr.value]="inputValue()"
                [variant]="$variant()"
                [invalid]="invalid()"
                [attr.id]="inputId()"
                [attr.autocomplete]="autocomplete()"
                aria-autocomplete="list"
                role="combobox"
                [attr.placeholder]="placeholder()"
                [attr.name]="name()"
                [attr.minlength]="minlength()"
                [pSize]="size()"
                [attr.min]="min()"
                [attr.max]="max()"
                [attr.pattern]="pattern()"
                [attr.size]="inputSize()"
                [attr.maxlength]="maxlength()"
                [attr.tabindex]="!$disabled() ? tabindex() : -1"
                [attr.required]="required() ? '' : undefined"
                [attr.readonly]="readonly() ? '' : undefined"
                [attr.disabled]="$disabled() ? '' : undefined"
                [attr.aria-label]="ariaLabel()"
                [attr.aria-labelledby]="ariaLabelledBy()"
                [attr.aria-required]="required()"
                [attr.aria-expanded]="overlayVisible ?? false"
                [attr.aria-controls]="overlayVisible ? id() + '_list' : null"
                [attr.aria-activedescendant]="focused ? focusedOptionId : undefined"
                (input)="onInput($event)"
                (keydown)="onKeyDown($event)"
                (change)="onInputChange($event)"
                (focus)="onInputFocus($event)"
                (blur)="onInputBlur($event)"
                (paste)="onInputPaste($event)"
                (keyup)="onInputKeyUp($event)"
                [fluid]="hasFluid"
                [pInputTextUnstyled]="unstyled()"
            />
        }
        @if ($filled() && !$disabled() && showClear() && !loading) {
            <ng-container>
                @if (!clearIconTemplate && !_clearIconTemplate) {
                    <svg data-p-icon="times" [pBind]="ptm('clearIcon')" [class]="cx('clearIcon')" (click)="clear()" [attr.aria-hidden]="true" />
                }
                @if (clearIconTemplate || _clearIconTemplate) {
                    <span [pBind]="ptm('clearIcon')" [class]="cx('clearIcon')" (click)="clear()" [attr.aria-hidden]="true">
                        <ng-template *ngTemplateOutlet="clearIconTemplate || _clearIconTemplate"></ng-template>
                    </span>
                }
            </ng-container>
        }

        @if (multiple()) {
            <ul
                #multiContainer
                [pBind]="ptm('inputMultiple')"
                [class]="cx('inputMultiple')"
                [attr.data-p]="inputMultipleDataP"
                [tabindex]="-1"
                role="listbox"
                [attr.aria-orientation]="'horizontal'"
                [attr.aria-activedescendant]="focused ? focusedMultipleOptionId : undefined"
                (focus)="onMultipleContainerFocus($event)"
                (blur)="onMultipleContainerBlur($event)"
                (keydown)="onMultipleContainerKeyDown($event)"
            >
                @for (option of modelValue(); track option; let i = $index) {
                    <li
                        #token
                        [pBind]="ptm('chipItem')"
                        [class]="cx('chipItem', { i })"
                        [attr.id]="id() + '_multiple_option_' + i"
                        role="option"
                        [attr.aria-label]="getOptionLabel(option)"
                        [attr.aria-setsize]="modelValue().length"
                        [attr.aria-posinset]="i + 1"
                        [attr.aria-selected]="true"
                    >
                        <p-chip
                            [pt]="ptm('pcChip')"
                            [class]="cx('pcChip')"
                            [label]="!selectedItemTemplate() && !_selectedItemTemplate && getOptionLabel(option)"
                            [disabled]="$disabled()"
                            [removable]="true"
                            (onRemove)="!readonly() ? removeOption($event, i) : ''"
                            [unstyled]="unstyled()"
                        >
                            <ng-container *ngTemplateOutlet="selectedItemTemplate() || _selectedItemTemplate; context: { $implicit: option }"></ng-container>
                            <ng-template #removeicon>
                                @if (!removeIconTemplate && !_removeIconTemplate) {
                                    <span [pBind]="ptm('chipIcon')" [class]="cx('chipIcon')" (click)="!readonly() && !$disabled() ? removeOption($event, i) : ''">
                                        <svg data-p-icon="times-circle" [class]="cx('chipIcon')" [attr.aria-hidden]="true" />
                                    </span>
                                }
                                @if (removeIconTemplate || _removeIconTemplate) {
                                    <span [pBind]="ptm('chipIcon')" [attr.aria-hidden]="true">
                                        <ng-template *ngTemplateOutlet="removeIconTemplate || _removeIconTemplate; context: { removeCallback: removeOption.bind(this), index: i, class: cx('chipIcon') }"></ng-template>
                                    </span>
                                }
                            </ng-template>
                        </p-chip>
                    </li>
                }
                <li [pBind]="ptm('inputChip')" [class]="cx('inputChip')" role="option">
                    <input
                        #focusInput
                        #multiIn
                        [pAutoFocus]="autofocus()"
                        [pBind]="ptm('input')"
                        [class]="cx('pcInputText')"
                        [ngStyle]="inputStyle()"
                        [attr.type]="type()"
                        [attr.id]="inputId()"
                        [attr.autocomplete]="autocomplete()"
                        [attr.name]="name()"
                        [attr.minlength]="minlength()"
                        [attr.maxlength]="maxlength()"
                        [attr.size]="size()"
                        [attr.min]="min()"
                        [attr.max]="max()"
                        [attr.pattern]="pattern()"
                        role="combobox"
                        [attr.placeholder]="!$filled() ? placeholder() : null"
                        aria-autocomplete="list"
                        [attr.tabindex]="!$disabled() ? tabindex() : -1"
                        [attr.required]="required() ? '' : undefined"
                        [attr.readonly]="readonly() ? '' : undefined"
                        [attr.disabled]="$disabled() ? '' : undefined"
                        [attr.aria-label]="ariaLabel()"
                        [attr.aria-labelledby]="ariaLabelledBy()"
                        [attr.aria-required]="required()"
                        [attr.aria-expanded]="overlayVisible ?? false"
                        [attr.aria-controls]="overlayVisible ? id() + '_list' : null"
                        [attr.aria-activedescendant]="focused ? focusedOptionId : undefined"
                        (input)="onInput($event)"
                        (keydown)="onKeyDown($event)"
                        (change)="onInputChange($event)"
                        (focus)="onInputFocus($event)"
                        (blur)="onInputBlur($event)"
                        (paste)="onInputPaste($event)"
                        (keyup)="onInputKeyUp($event)"
                    />
                </li>
            </ul>
        }
        @if (loading) {
            <ng-container>
                @if (!loadingIconTemplate && !_loadingIconTemplate) {
                    <svg data-p-icon="spinner" [pBind]="ptm('loader')" [class]="cx('loader')" [spin]="true" [attr.aria-hidden]="true" />
                }
                @if (loadingIconTemplate || _loadingIconTemplate) {
                    <span [pBind]="ptm('loader')" [class]="cx('loader')" [attr.aria-hidden]="true">
                        <ng-template *ngTemplateOutlet="loadingIconTemplate || _loadingIconTemplate"></ng-template>
                    </span>
                }
            </ng-container>
        }
        @if (dropdown()) {
            <button #ddBtn type="button" [pBind]="ptm('dropdown')" [attr.aria-label]="dropdownAriaLabel()" [class]="cx('dropdown')" [disabled]="$disabled()" pRipple (click)="handleDropdownClick($event)" [attr.tabindex]="tabindex()">
                @if (dropdownIcon()) {
                    <span [ngClass]="dropdownIcon()" [attr.aria-hidden]="true"></span>
                }
                @if (!dropdownIcon()) {
                    <ng-container>
                        @if (!dropdownIconTemplate() && !_dropdownIconTemplate) {
                            <svg data-p-icon="chevron-down" [pBind]="ptm('dropdown')" />
                        }
                        <ng-template *ngTemplateOutlet="dropdownIconTemplate() || _dropdownIconTemplate"></ng-template>
                    </ng-container>
                }
            </button>
        }
        <p-overlay
            #overlay
            [hostAttrSelector]="$attrSelector"
            [(visible)]="overlayVisible"
            [options]="overlayOptions()"
            [target]="'@parent'"
            [appendTo]="$appendTo()"
            [unstyled]="unstyled()"
            [pt]="ptm('pcOverlay')"
            [motionOptions]="motionOptions()"
            (onBeforeEnter)="onOverlayBeforeEnter()"
            (onHide)="hide()"
            [attr.data-p]="overlayDataP"
        >
            <ng-template #content>
                <div [pBind]="ptm('overlay')" [class]="cn(cx('overlay'), panelStyleClass())" [ngStyle]="panelStyle()">
                    <ng-container *ngTemplateOutlet="headerTemplate() || _headerTemplate"></ng-container>
                    <div [pBind]="ptm('listContainer')" [class]="cx('listContainer')" [style.max-height]="virtualScroll() ? 'auto' : scrollHeight()" [tabindex]="-1">
                        @if (virtualScroll()) {
                            <p-scroller
                                #scroller
                                [tabindex]="-1"
                                [pt]="ptm('virtualScroller')"
                                [items]="visibleOptions()"
                                [style]="{ height: scrollHeight() }"
                                [itemSize]="virtualScrollItemSize()"
                                [autoSize]="true"
                                [lazy]="lazy()"
                                (onLazyLoad)="onLazyLoad.emit($event)"
                                [options]="virtualScrollOptions()"
                            >
                                <ng-template #content let-items let-scrollerOptions="options">
                                    <ng-container *ngTemplateOutlet="buildInItems; context: { $implicit: items, options: scrollerOptions }"></ng-container>
                                </ng-template>
                                @if (loaderTemplate || _loaderTemplate) {
                                    <ng-template #loader let-scrollerOptions="options">
                                        <ng-container *ngTemplateOutlet="loaderTemplate || _loaderTemplate; context: { options: scrollerOptions }"></ng-container>
                                    </ng-template>
                                }
                            </p-scroller>
                        }
                        @if (!virtualScroll()) {
                            <ng-container *ngTemplateOutlet="buildInItems; context: { $implicit: visibleOptions(), options: {} }"></ng-container>
                        }
                    </div>

                    <ng-template #buildInItems let-items let-scrollerOptions="options">
                        <ul #items [pBind]="ptm('list')" [class]="cn(cx('list'), scrollerOptions.contentStyleClass)" [style]="scrollerOptions.contentStyle" role="listbox" [attr.id]="id() + '_list'" [attr.aria-label]="listLabel">
                            @for (option of items; track option; let i = $index) {
                                @if (isOptionGroup(option)) {
                                    <li [pBind]="ptm('optionGroup')" [attr.id]="id() + '_' + getOptionIndex(i, scrollerOptions)" [class]="cx('optionGroup')" [ngStyle]="{ height: scrollerOptions.itemSize + 'px' }" role="option">
                                        @if (!groupTemplate()) {
                                            <span>{{ getOptionGroupLabel(option.optionGroup) }}</span>
                                        }
                                        <ng-container *ngTemplateOutlet="groupTemplate(); context: { $implicit: option.optionGroup }"></ng-container>
                                    </li>
                                }
                                @if (!isOptionGroup(option)) {
                                    <li
                                        pRipple
                                        [pBind]="getPTOptions(option, scrollerOptions, i, 'option')"
                                        [ngStyle]="{ height: scrollerOptions.itemSize + 'px' }"
                                        [class]="cx('option', { option, i, scrollerOptions })"
                                        [attr.id]="id() + '_' + getOptionIndex(i, scrollerOptions)"
                                        role="option"
                                        [attr.aria-label]="getOptionLabel(option)"
                                        [attr.aria-selected]="isSelected(option)"
                                        [attr.data-p-selected]="isSelected(option)"
                                        [attr.aria-disabled]="isOptionDisabled(option)"
                                        [attr.data-p-focused]="focusedOptionIndex() === getOptionIndex(i, scrollerOptions)"
                                        [attr.aria-setsize]="ariaSetSize"
                                        [attr.aria-posinset]="getAriaPosInset(getOptionIndex(i, scrollerOptions))"
                                        (click)="onOptionSelect($event, option)"
                                        (mouseenter)="onOptionMouseEnter($event, getOptionIndex(i, scrollerOptions))"
                                    >
                                        @if (!itemTemplate() && !_itemTemplate) {
                                            <span>{{ getOptionLabel(option) }}</span>
                                        }
                                        <ng-container
                                            *ngTemplateOutlet="
                                                itemTemplate() || _itemTemplate;
                                                context: {
                                                    $implicit: option,
                                                    index: scrollerOptions.getOptions ? scrollerOptions.getOptions(i) : i
                                                }
                                            "
                                        ></ng-container>
                                    </li>
                                }
                            }
                            @if (!items || (items && items.length === 0 && showEmptyMessage())) {
                                <li [pBind]="ptm('emptyMessage')" [class]="cx('emptyMessage')" [ngStyle]="{ height: scrollerOptions.itemSize + 'px' }" role="option">
                                    @if (!emptyTemplate() && !_emptyTemplate) {
                                        {{ searchResultMessageText }}
                                    } @else {
                                        <ng-container *ngTemplateOutlet="emptyTemplate() || _emptyTemplate"></ng-container>
                                    }
                                </li>
                            }
                        </ul>
                    </ng-template>
                    <ng-container *ngTemplateOutlet="footerTemplate() || _footerTemplate"></ng-container>
                </div>
                <span role="status" aria-live="polite" class="p-hidden-accessible">
                    {{ selectedMessageText }}
                </span>
            </ng-template>
        </p-overlay>
    `,
                    providers: [AUTOCOMPLETE_VALUE_ACCESSOR, AutoCompleteStyle, { provide: AUTOCOMPLETE_INSTANCE, useExisting: AutoComplete }, { provide: PARENT_INSTANCE, useExisting: AutoComplete }],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class]': "cn(cx('root'), styleClass())",
                        '[style]': "sx('root')",
                        '[attr.data-p]': 'containerDataP',
                        '(click)': 'onHostClick($event)'
                    },
                    hostDirectives: [Bind]
                }]
        }], ctorParameters: () => [], propDecorators: { minLength: [{ type: i0.Input, args: [{ isSignal: true, alias: "minLength", required: false }] }], minQueryLength: [{ type: i0.Input, args: [{ isSignal: true, alias: "minQueryLength", required: false }] }], delay: [{ type: i0.Input, args: [{ isSignal: true, alias: "delay", required: false }] }], panelStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelStyle", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], panelStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelStyleClass", required: false }] }], inputStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputStyle", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], inputStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputStyleClass", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], scrollHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollHeight", required: false }] }], lazy: [{ type: i0.Input, args: [{ isSignal: true, alias: "lazy", required: false }] }], virtualScroll: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScroll", required: false }] }], virtualScrollItemSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScrollItemSize", required: false }] }], virtualScrollOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScrollOptions", required: false }] }], autoHighlight: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoHighlight", required: false }] }], forceSelection: [{ type: i0.Input, args: [{ isSignal: true, alias: "forceSelection", required: false }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], autoZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoZIndex", required: false }] }], baseZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "baseZIndex", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], dropdownAriaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "dropdownAriaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], dropdownIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "dropdownIcon", required: false }] }], unique: [{ type: i0.Input, args: [{ isSignal: true, alias: "unique", required: false }] }], group: [{ type: i0.Input, args: [{ isSignal: true, alias: "group", required: false }] }], completeOnFocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "completeOnFocus", required: false }] }], showClear: [{ type: i0.Input, args: [{ isSignal: true, alias: "showClear", required: false }] }], dropdown: [{ type: i0.Input, args: [{ isSignal: true, alias: "dropdown", required: false }] }], showEmptyMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "showEmptyMessage", required: false }] }], dropdownMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "dropdownMode", required: false }] }], multiple: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiple", required: false }] }], addOnTab: [{ type: i0.Input, args: [{ isSignal: true, alias: "addOnTab", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], dataKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataKey", required: false }] }], emptyMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyMessage", required: false }] }], showTransitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "showTransitionOptions", required: false }] }], hideTransitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideTransitionOptions", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], autocomplete: [{ type: i0.Input, args: [{ isSignal: true, alias: "autocomplete", required: false }] }], optionGroupChildren: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionGroupChildren", required: false }] }], optionGroupLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionGroupLabel", required: false }] }], overlayOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "overlayOptions", required: false }] }], suggestions: [{ type: i0.Input, args: [{ isSignal: true, alias: "suggestions", required: false }] }], optionLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionLabel", required: false }] }], optionValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionValue", required: false }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], searchMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "searchMessage", required: false }] }], emptySelectionMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptySelectionMessage", required: false }] }], selectionMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectionMessage", required: false }] }], autoOptionFocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoOptionFocus", required: false }] }], selectOnFocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectOnFocus", required: false }] }], searchLocale: [{ type: i0.Input, args: [{ isSignal: true, alias: "searchLocale", required: false }] }], optionDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionDisabled", required: false }] }], focusOnHover: [{ type: i0.Input, args: [{ isSignal: true, alias: "focusOnHover", required: false }] }], typeahead: [{ type: i0.Input, args: [{ isSignal: true, alias: "typeahead", required: false }] }], addOnBlur: [{ type: i0.Input, args: [{ isSignal: true, alias: "addOnBlur", required: false }] }], separator: [{ type: i0.Input, args: [{ isSignal: true, alias: "separator", required: false }] }], appendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "appendTo", required: false }] }], motionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "motionOptions", required: false }] }], completeMethod: [{ type: i0.Output, args: ["completeMethod"] }], onSelect: [{ type: i0.Output, args: ["onSelect"] }], onUnselect: [{ type: i0.Output, args: ["onUnselect"] }], onAdd: [{ type: i0.Output, args: ["onAdd"] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], onDropdownClick: [{ type: i0.Output, args: ["onDropdownClick"] }], onClear: [{ type: i0.Output, args: ["onClear"] }], onInputKeydown: [{ type: i0.Output, args: ["onInputKeydown"] }], onKeyUp: [{ type: i0.Output, args: ["onKeyUp"] }], onShow: [{ type: i0.Output, args: ["onShow"] }], onHide: [{ type: i0.Output, args: ["onHide"] }], onLazyLoad: [{ type: i0.Output, args: ["onLazyLoad"] }], inputEL: [{ type: i0.ViewChild, args: ['focusInput', { isSignal: true }] }], multiInputEl: [{ type: i0.ViewChild, args: ['multiIn', { isSignal: true }] }], multiContainerEL: [{ type: i0.ViewChild, args: ['multiContainer', { isSignal: true }] }], dropdownButton: [{ type: i0.ViewChild, args: ['ddBtn', { isSignal: true }] }], itemsViewChild: [{ type: i0.ViewChild, args: ['items', { isSignal: true }] }], scroller: [{ type: i0.ViewChild, args: ['scroller', { isSignal: true }] }], overlayViewChild: [{ type: i0.ViewChild, args: ['overlay', { isSignal: true }] }], itemTemplate: [{ type: i0.ContentChild, args: ['item', { isSignal: true }] }], emptyTemplate: [{ type: i0.ContentChild, args: ['empty', { isSignal: true }] }], headerTemplate: [{ type: i0.ContentChild, args: ['header', { isSignal: true }] }], footerTemplate: [{ type: i0.ContentChild, args: ['footer', { isSignal: true }] }], selectedItemTemplate: [{ type: i0.ContentChild, args: ['selecteditem', { isSignal: true }] }], groupTemplate: [{ type: i0.ContentChild, args: ['group', { isSignal: true }] }], loaderTemplate: [{
                type: ContentChild,
                args: ['loader']
            }], removeIconTemplate: [{
                type: ContentChild,
                args: ['removeicon']
            }], loadingIconTemplate: [{
                type: ContentChild,
                args: ['loadingicon']
            }], clearIconTemplate: [{
                type: ContentChild,
                args: ['clearicon']
            }], dropdownIconTemplate: [{ type: i0.ContentChild, args: ['dropdownicon', { isSignal: true }] }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class AutoCompleteModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AutoCompleteModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: AutoCompleteModule, imports: [AutoComplete, SharedModule], exports: [AutoComplete, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AutoCompleteModule, imports: [AutoComplete, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AutoCompleteModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [AutoComplete, SharedModule],
                    exports: [AutoComplete, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { AUTOCOMPLETE_VALUE_ACCESSOR, AutoComplete, AutoCompleteClasses, AutoCompleteModule, AutoCompleteStyle };
//# sourceMappingURL=wawjs-ngx-prime-autocomplete.mjs.map
