export * from '@wawjs/ngx-prime/types/togglebutton';
import * as i0 from '@angular/core';
import { Injectable, inject, ElementRef, model, input, booleanAttribute, numberAttribute, output, forwardRef, Directive, InjectionToken, contentChild, contentChildren, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { style as style$1 } from '@wawjs/css-prime-styles/togglebutton';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import * as i3 from '@angular/common';
import { CommonModule } from '@angular/common';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { PrimeTemplate, SharedModule } from '@wawjs/ngx-prime/api';
import { PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i2 from '@wawjs/ngx-prime/bind';
import { Bind, BindModule } from '@wawjs/ngx-prime/bind';
import * as i1 from '@wawjs/ngx-prime/ripple';
import { Ripple } from '@wawjs/ngx-prime/ripple';

const style = /*css*/ `
    ${style$1}

    /* For ngx-prime (iconPos) */
    .p-togglebutton-icon-right {
        order: 1;
    }

    .p-togglebutton.ng-invalid.ng-dirty {
        border-color: dt('togglebutton.invalid.border.color');
    }
`;
const isChecked = (instance) => (typeof instance.checked === 'function' ? instance.checked() : instance.checked);
const classes = {
    root: ({ instance }) => [
        'p-togglebutton p-component',
        {
            'p-togglebutton-checked': isChecked(instance),
            'p-invalid': instance.invalid(),
            'p-disabled': instance.$disabled(),
            'p-togglebutton-sm p-inputfield-sm': instance.size() === 'small',
            'p-togglebutton-lg p-inputfield-lg': instance.size() === 'large',
            'p-togglebutton-fluid': instance.fluid()
        }
    ],
    content: 'p-togglebutton-content',
    icon: 'p-togglebutton-icon',
    iconLeft: 'p-togglebutton-icon-left',
    iconRight: 'p-togglebutton-icon-right',
    label: 'p-togglebutton-label'
};
class ToggleButtonStyle extends BaseStyle {
    name = 'togglebutton';
    style = style;
    classes = classes;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToggleButtonStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToggleButtonStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToggleButtonStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * ToggleButton is used to select a boolean value using a button.
 *
 * [Live Demo](https://www.ngx-prime.org/togglebutton/)
 *
 * @module togglebuttonstyle
 *
 */
var ToggleButtonClasses;
(function (ToggleButtonClasses) {
    /**
     * Class name of the root element
     */
    ToggleButtonClasses["root"] = "p-togglebutton";
    /**
     * Class name of the icon element
     */
    ToggleButtonClasses["icon"] = "p-togglebutton-icon";
    /**
     * Class name of the left icon
     */
    ToggleButtonClasses["iconLeft"] = "p-togglebutton-icon-left";
    /**
     * Class name of the right icon
     */
    ToggleButtonClasses["iconRight"] = "p-togglebutton-icon-right";
    /**
     * Class name of the label element
     */
    ToggleButtonClasses["label"] = "p-togglebutton-label";
})(ToggleButtonClasses || (ToggleButtonClasses = {}));

/** Adds toggle semantics to a native button. */
class ToggleButtonDirective extends BaseEditableHolder {
    componentName = 'ToggleButton';
    _componentStyle = inject(ToggleButtonStyle);
    element = inject(ElementRef);
    bindDirectiveInstance = inject(Bind, { self: true });
    /** Signal Forms checkbox contract; binds publicly as `[(pressed)]`. */
    checked = model(false, { ...(ngDevMode ? { debugName: "checked" } : /* istanbul ignore next */ {}), alias: 'pressed' });
    allowEmpty = input(true, { ...(ngDevMode ? { debugName: "allowEmpty" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    type = input('button', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    tabindex = input(undefined, { ...(ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    autofocus = input(false, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    size = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "size" }] : /* istanbul ignore next */ []));
    fluid = input(false, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    inputId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "inputId" }] : /* istanbul ignore next */ []));
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    ariaDescribedBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaDescribedBy" }] : /* istanbul ignore next */ []));
    onChange = output();
    onFocus = output();
    onBlur = output();
    touch = output();
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['button', 'root']));
    }
    toggle(event) {
        if (this.$disabled() || (this.allowEmpty() === false && this.checked())) {
            return;
        }
        const checked = !this.checked();
        this.checked.set(checked);
        this.writeModelValue(checked);
        this.onModelChange(checked);
        this.onModelTouched();
        this.onChange.emit({ originalEvent: event, checked });
    }
    handleBlur(event) {
        this.onModelTouched();
        this.touch.emit();
        this.onBlur.emit(event);
    }
    focus(options) {
        this.element.nativeElement.focus(options);
    }
    writeControlValue(value, setModelValue) {
        const checked = !!value;
        setModelValue(checked);
        this.checked.set(checked);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToggleButtonDirective, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: ToggleButtonDirective, isStandalone: true, selector: "button[pToggleButton]", inputs: { checked: { classPropertyName: "checked", publicName: "pressed", isSignal: true, isRequired: false, transformFunction: null }, allowEmpty: { classPropertyName: "allowEmpty", publicName: "allowEmpty", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, ariaDescribedBy: { classPropertyName: "ariaDescribedBy", publicName: "ariaDescribedBy", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { checked: "pressedChange", onChange: "onChange", onFocus: "onFocus", onBlur: "onBlur", touch: "touch" }, host: { listeners: { "click": "toggle($event)", "focus": "onFocus.emit($event)", "blur": "handleBlur($event)" }, properties: { "class": "cx('root')", "attr.data-pc-name": "'togglebutton'", "attr.data-pc-section": "'root'", "attr.data-p-checked": "checked() || null", "attr.data-p-disabled": "$disabled() || null", "attr.data-p-invalid": "invalid() || null", "attr.type": "type()", "attr.aria-pressed": "checked()", "attr.aria-label": "ariaLabel() || null", "attr.aria-labelledby": "ariaLabelledBy() || null", "attr.aria-describedby": "ariaDescribedBy() || null", "attr.aria-disabled": "$disabled() || null", "attr.id": "inputId() || null", "attr.name": "name() || null", "disabled": "$disabled()", "attr.tabindex": "tabindex() ?? null", "autofocus": "autofocus()" } }, providers: [ToggleButtonStyle, { provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => ToggleButtonDirective), multi: true }], usesInheritance: true, hostDirectives: [{ directive: i2.Bind }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToggleButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[pToggleButton]',
                    standalone: true,
                    host: {
                        '[class]': "cx('root')",
                        '[attr.data-pc-name]': "'togglebutton'",
                        '[attr.data-pc-section]': "'root'",
                        '[attr.data-p-checked]': 'checked() || null',
                        '[attr.data-p-disabled]': '$disabled() || null',
                        '[attr.data-p-invalid]': 'invalid() || null',
                        '[attr.type]': 'type()',
                        '[attr.aria-pressed]': 'checked()',
                        '[attr.aria-label]': 'ariaLabel() || null',
                        '[attr.aria-labelledby]': 'ariaLabelledBy() || null',
                        '[attr.aria-describedby]': 'ariaDescribedBy() || null',
                        '[attr.aria-disabled]': '$disabled() || null',
                        '[attr.id]': 'inputId() || null',
                        '[attr.name]': 'name() || null',
                        '[disabled]': '$disabled()',
                        '[attr.tabindex]': 'tabindex() ?? null',
                        '[autofocus]': 'autofocus()',
                        '(click)': 'toggle($event)',
                        '(focus)': 'onFocus.emit($event)',
                        '(blur)': 'handleBlur($event)'
                    },
                    providers: [ToggleButtonStyle, { provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => ToggleButtonDirective), multi: true }],
                    hostDirectives: [Bind]
                }]
        }], propDecorators: { checked: [{ type: i0.Input, args: [{ isSignal: true, alias: "pressed", required: false }] }, { type: i0.Output, args: ["pressedChange"] }], allowEmpty: [{ type: i0.Input, args: [{ isSignal: true, alias: "allowEmpty", required: false }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], ariaDescribedBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaDescribedBy", required: false }] }], onChange: [{ type: i0.Output, args: ["onChange"] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], touch: [{ type: i0.Output, args: ["touch"] }] } });

const TOGGLEBUTTON_INSTANCE = new InjectionToken('TOGGLEBUTTON_INSTANCE');
const TOGGLEBUTTON_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => ToggleButton),
    multi: true
};
/**
 * Legacy ToggleButton component.
 * @deprecated since v22, use `<button pToggleButton>` for native toggle buttons. The legacy component selectors will be removed in v23.
 * @group Components
 */
class ToggleButton extends BaseEditableHolder {
    componentName = 'ToggleButton';
    nbsp = String.fromCharCode(160);
    $pcToggleButton = inject(TOGGLEBUTTON_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    onKeyDown(event) {
        switch (event.code) {
            case 'Enter':
                this.toggle(event);
                event.preventDefault();
                break;
            case 'Space':
                this.toggle(event);
                event.preventDefault();
                break;
        }
    }
    toggle(event) {
        if (!this.$disabled() && !(this.allowEmpty() === false && this.checked)) {
            this.checked = !this.checked;
            this.writeModelValue(this.checked);
            this.onModelChange(this.checked);
            this.onModelTouched();
            this.onChange.emit({
                originalEvent: event,
                checked: this.checked
            });
            this.cd.markForCheck();
        }
    }
    /**
     * Label for the on state.
     * @group Props
     */
    onLabel = input('Yes', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "onLabel" }] : /* istanbul ignore next */ []));
    /**
     * Label for the off state.
     * @group Props
     */
    offLabel = input('No', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "offLabel" }] : /* istanbul ignore next */ []));
    /**
     * Icon for the on state.
     * @group Props
     */
    onIcon = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "onIcon" }] : /* istanbul ignore next */ []));
    /**
     * Icon for the off state.
     * @group Props
     */
    offIcon = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "offIcon" }] : /* istanbul ignore next */ []));
    /**
     * Defines a string that labels the input for accessibility.
     * @group Props
     */
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Identifier of the focus input to match a label defined for the component.
     * @group Props
     */
    inputId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "inputId" }] : /* istanbul ignore next */ []));
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex = input(0, { ...(ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Position of the icon.
     * @group Props
     */
    iconPos = input('left', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "iconPos" }] : /* istanbul ignore next */ []));
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus = input(undefined, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Defines the size of the component.
     * @group Props
     */
    size = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "size" }] : /* istanbul ignore next */ []));
    /**
     * Whether selection can not be cleared.
     * @group Props
     */
    allowEmpty = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "allowEmpty" }] : /* istanbul ignore next */ []));
    /**
     * Spans 100% width of the container when enabled.
     * @defaultValue undefined
     * @group Props
     */
    fluid = input(undefined, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Callback to invoke on value change.
     * @param {ToggleButtonChangeEvent} event - Custom change event.
     * @group Emits
     */
    onChange = output();
    /**
     * Custom icon template.
     * @param {ToggleButtonIconTemplateContext} context - icon context.
     * @see {@link ToggleButtonIconTemplateContext}
     * @group Templates
     */
    iconTemplate = contentChild('icon', { ...(ngDevMode ? { debugName: "iconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom content template.
     * @param {ToggleButtonContentTemplateContext} context - content context.
     * @see {@link ToggleButtonContentTemplateContext}
     * @group Templates
     */
    contentTemplate = contentChild('content', { ...(ngDevMode ? { debugName: "contentTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    checked = false;
    onInit() {
        if (this.checked === null || this.checked === undefined) {
            this.checked = false;
        }
    }
    _componentStyle = inject(ToggleButtonStyle);
    onBlur() {
        this.onModelTouched();
    }
    get hasOnLabel() {
        return (this.onLabel() && this.onLabel().length > 0);
    }
    get hasOffLabel() {
        return (this.offLabel() && this.offLabel().length > 0);
    }
    get active() {
        return this.checked === true;
    }
    _iconTemplate;
    _contentTemplate;
    onAfterContentInit() {
        this.templates().forEach((item) => {
            switch (item.getType()) {
                case 'icon':
                    this._iconTemplate = item.template;
                    break;
                case 'content':
                    this._contentTemplate = item.template;
                    break;
                default:
                    this._contentTemplate = item.template;
                    break;
            }
        });
    }
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value, setModelValue) {
        this.checked = value;
        setModelValue(value);
        this.cd.markForCheck();
    }
    get dataP() {
        return this.cn({
            checked: this.active,
            invalid: this.invalid(),
            [this.size()]: this.size()
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToggleButton, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: ToggleButton, isStandalone: true, selector: "p-toggleButton, p-togglebutton, p-toggle-button", inputs: { onLabel: { classPropertyName: "onLabel", publicName: "onLabel", isSignal: true, isRequired: false, transformFunction: null }, offLabel: { classPropertyName: "offLabel", publicName: "offLabel", isSignal: true, isRequired: false, transformFunction: null }, onIcon: { classPropertyName: "onIcon", publicName: "onIcon", isSignal: true, isRequired: false, transformFunction: null }, offIcon: { classPropertyName: "offIcon", publicName: "offIcon", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, iconPos: { classPropertyName: "iconPos", publicName: "iconPos", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, allowEmpty: { classPropertyName: "allowEmpty", publicName: "allowEmpty", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onChange: "onChange" }, host: { listeners: { "keydown": "onKeyDown($event)", "click": "toggle($event)" }, properties: { "class": "cn(cx('root'), styleClass())", "attr.aria-labelledby": "ariaLabelledBy()", "attr.aria-label": "ariaLabel()", "attr.aria-pressed": "checked ? \"true\" : \"false\"", "attr.role": "\"button\"", "attr.tabindex": "tabindex() !== undefined ? tabindex() : (!$disabled() ? 0 : -1)", "attr.data-pc-name": "'togglebutton'", "attr.data-p-checked": "active", "attr.data-p-disabled": "$disabled()", "attr.data-p": "dataP" } }, providers: [TOGGLEBUTTON_VALUE_ACCESSOR, ToggleButtonStyle, { provide: TOGGLEBUTTON_INSTANCE, useExisting: ToggleButton }, { provide: PARENT_INSTANCE, useExisting: ToggleButton }], queries: [{ propertyName: "iconTemplate", first: true, predicate: ["icon"], isSignal: true }, { propertyName: "contentTemplate", first: true, predicate: ["content"], isSignal: true }, { propertyName: "templates", predicate: PrimeTemplate, isSignal: true }], usesInheritance: true, hostDirectives: [{ directive: i1.Ripple }, { directive: i2.Bind }], ngImport: i0, template: `<span [class]="cx('content')" [pBind]="ptm('content')" [attr.data-p]="dataP">
        <ng-container *ngTemplateOutlet="contentTemplate() || _contentTemplate; context: { $implicit: checked }"></ng-container>
        @if (!contentTemplate()) {
            @if (!iconTemplate()) {
                @if (onIcon() || offIcon()) {
                    <span [class]="cn(cx('icon'), checked ? this.onIcon() : this.offIcon(), iconPos() === 'left' ? cx('iconLeft') : cx('iconRight'))" [pBind]="ptm('icon')"></span>
                }
            } @else {
                <ng-container *ngTemplateOutlet="iconTemplate() || _iconTemplate; context: { $implicit: checked }"></ng-container>
            }
            <span [class]="cx('label')" [pBind]="ptm('label')">{{ checked ? (hasOnLabel ? onLabel() : nbsp) : hasOffLabel ? offLabel() : nbsp }}</span>
        }
    </span>`, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i3.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: BindModule }, { kind: "directive", type: i2.Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToggleButton, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-toggleButton, p-togglebutton, p-toggle-button',
                    standalone: true,
                    imports: [CommonModule, SharedModule, BindModule],
                    hostDirectives: [{ directive: Ripple }, Bind],
                    host: {
                        '[class]': "cn(cx('root'), styleClass())",
                        '[attr.aria-labelledby]': 'ariaLabelledBy()',
                        '[attr.aria-label]': 'ariaLabel()',
                        '[attr.aria-pressed]': 'checked ? "true" : "false"',
                        '[attr.role]': '"button"',
                        '[attr.tabindex]': 'tabindex() !== undefined ? tabindex() : (!$disabled() ? 0 : -1)',
                        '[attr.data-pc-name]': "'togglebutton'",
                        '[attr.data-p-checked]': 'active',
                        '[attr.data-p-disabled]': '$disabled()',
                        '[attr.data-p]': 'dataP',
                        '(keydown)': 'onKeyDown($event)',
                        '(click)': 'toggle($event)'
                    },
                    template: `<span [class]="cx('content')" [pBind]="ptm('content')" [attr.data-p]="dataP">
        <ng-container *ngTemplateOutlet="contentTemplate() || _contentTemplate; context: { $implicit: checked }"></ng-container>
        @if (!contentTemplate()) {
            @if (!iconTemplate()) {
                @if (onIcon() || offIcon()) {
                    <span [class]="cn(cx('icon'), checked ? this.onIcon() : this.offIcon(), iconPos() === 'left' ? cx('iconLeft') : cx('iconRight'))" [pBind]="ptm('icon')"></span>
                }
            } @else {
                <ng-container *ngTemplateOutlet="iconTemplate() || _iconTemplate; context: { $implicit: checked }"></ng-container>
            }
            <span [class]="cx('label')" [pBind]="ptm('label')">{{ checked ? (hasOnLabel ? onLabel() : nbsp) : hasOffLabel ? offLabel() : nbsp }}</span>
        }
    </span>`,
                    providers: [TOGGLEBUTTON_VALUE_ACCESSOR, ToggleButtonStyle, { provide: TOGGLEBUTTON_INSTANCE, useExisting: ToggleButton }, { provide: PARENT_INSTANCE, useExisting: ToggleButton }],
                    changeDetection: ChangeDetectionStrategy.OnPush
                }]
        }], propDecorators: { onLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "onLabel", required: false }] }], offLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "offLabel", required: false }] }], onIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "onIcon", required: false }] }], offIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "offIcon", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], iconPos: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconPos", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], allowEmpty: [{ type: i0.Input, args: [{ isSignal: true, alias: "allowEmpty", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], onChange: [{ type: i0.Output, args: ["onChange"] }], iconTemplate: [{ type: i0.ContentChild, args: ['icon', { ...{ descendants: false }, isSignal: true }] }], contentTemplate: [{ type: i0.ContentChild, args: ['content', { ...{ descendants: false }, isSignal: true }] }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class ToggleButtonModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToggleButtonModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: ToggleButtonModule, imports: [ToggleButton, ToggleButtonDirective, SharedModule], exports: [ToggleButton, ToggleButtonDirective, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToggleButtonModule, imports: [ToggleButton, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ToggleButtonModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [ToggleButton, ToggleButtonDirective, SharedModule],
                    exports: [ToggleButton, ToggleButtonDirective, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { TOGGLEBUTTON_VALUE_ACCESSOR, ToggleButton, ToggleButtonClasses, ToggleButtonDirective, ToggleButtonModule, ToggleButtonStyle };
//# sourceMappingURL=wawjs-ngx-prime-togglebutton.mjs.map
