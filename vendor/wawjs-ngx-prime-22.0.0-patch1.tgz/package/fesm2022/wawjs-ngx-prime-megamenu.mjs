export * from '@wawjs/ngx-prime/types/megamenu';
import * as i2 from '@angular/common';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, input, numberAttribute, booleanAttribute, output, forwardRef, ViewEncapsulation, Component, contentChild, contentChildren, viewChild, signal, effect, ContentChild, ChangeDetectionStrategy, NgModule } from '@angular/core';
import * as i3 from '@angular/router';
import { RouterModule } from '@angular/router';
import { resolve, isNotEmpty, uuid, isEmpty, focus, findSingle, isPrintableCharacter, findLastIndex, isTouchDevice } from '@wawjs/css-prime-utils';
import { SharedModule, PrimeTemplate } from '@wawjs/ngx-prime/api';
import * as i5 from '@wawjs/ngx-prime/badge';
import { BadgeModule } from '@wawjs/ngx-prime/badge';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind } from '@wawjs/ngx-prime/bind';
import { AngleDownIcon, AngleRightIcon, BarsIcon } from '@wawjs/ngx-prime/icons';
import { Ripple } from '@wawjs/ngx-prime/ripple';
import * as i4 from '@wawjs/ngx-prime/tooltip';
import { TooltipModule } from '@wawjs/ngx-prime/tooltip';
import { ZIndexUtils } from '@wawjs/ngx-prime/utils';
import { style } from '@wawjs/css-prime-styles/megamenu';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const inlineStyles = {
    rootList: ({ instance }) => ({ 'max-height': instance.scrollHeight(), overflow: 'auto' })
};
const classes = {
    root: ({ instance }) => [
        'p-megamenu p-component',
        {
            'p-megamenu-mobile': instance.queryMatches(),
            'p-megamenu-mobile-active': instance.mobileActive,
            'p-megamenu-horizontal': instance.orientation() === 'horizontal',
            'p-megamenu-vertical': instance.orientation() === 'vertical'
        }
    ],
    start: 'p-megamenu-start',
    button: 'p-megamenu-button',
    rootList: 'p-megamenu-root-list',
    submenuLabel: ({ instance, processedItem }) => [
        'p-megamenu-submenu-label',
        {
            'p-disabled': instance.isItemDisabled(processedItem)
        }
    ],
    item: ({ instance, processedItem }) => [
        'p-megamenu-item',
        instance.getItemProp(processedItem, 'styleClass'),
        instance.getItemProp(processedItem, 'class'),
        {
            'p-megamenu-item-active': instance.isItemActive(processedItem),
            'p-focus': instance.isItemFocused(processedItem),
            'p-disabled': instance.isItemDisabled(processedItem)
        }
    ],
    itemContent: 'p-megamenu-item-content',
    itemLink: 'p-megamenu-item-link',
    itemIcon: 'p-megamenu-item-icon',
    itemLabel: 'p-megamenu-item-label',
    submenuIcon: 'p-megamenu-submenu-icon',
    overlay: 'p-megamenu-overlay',
    grid: 'p-megamenu-grid',
    column: ({ instance, processedItem }) => {
        let length = instance.isItemGroup(processedItem) ? processedItem.items.length : 0;
        let columnClass;
        if (instance.megaMenu.queryMatches())
            columnClass = 'p-megamenu-col-12';
        else {
            switch (length) {
                case 2:
                    columnClass = 'p-megamenu-col-6';
                    break;
                case 3:
                    columnClass = 'p-megamenu-col-4';
                    break;
                case 4:
                    columnClass = 'p-megamenu-col-3';
                    break;
                case 6:
                    columnClass = 'p-megamenu-col-2';
                    break;
                default:
                    columnClass = 'p-megamenu-col-12';
                    break;
            }
        }
        return columnClass;
    },
    submenu: 'p-megamenu-submenu',
    separator: 'p-megamenu-separator',
    end: 'p-megamenu-end'
};
class MegaMenuStyle extends BaseStyle {
    name = 'megamenu';
    style = style;
    classes = classes;
    inlineStyles = inlineStyles;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MegaMenuStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MegaMenuStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MegaMenuStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * MegaMenu is navigation component that displays submenus together.
 *
 * [Live Demo](https://www.ngx-prime.org/megamenu/)
 *
 * @module megamenustyle
 *
 */
var MegaMenuClasses;
(function (MegaMenuClasses) {
    /**
     * Class name of the root element
     */
    MegaMenuClasses["root"] = "p-megamenu";
    /**
     * Class name of the start element
     */
    MegaMenuClasses["start"] = "p-megamenu-start";
    /**
     * Class name of the button element
     */
    MegaMenuClasses["button"] = "p-megamenu-button";
    /**
     * Class name of the root list element
     */
    MegaMenuClasses["rootList"] = "p-megamenu-root-list";
    /**
     * Class name of the submenu item element
     */
    MegaMenuClasses["submenuItem"] = "p-megamenu-submenu-item";
    /**
     * Class name of the item element
     */
    MegaMenuClasses["item"] = "p-megamenu-item";
    /**
     * Class name of the item content element
     */
    MegaMenuClasses["itemContent"] = "p-megamenu-item-content";
    /**
     * Class name of the item link element
     */
    MegaMenuClasses["itemLink"] = "p-megamenu-item-link";
    /**
     * Class name of the item icon element
     */
    MegaMenuClasses["itemIcon"] = "p-megamenu-item-icon";
    /**
     * Class name of the item label element
     */
    MegaMenuClasses["itemLabel"] = "p-megamenu-item-label";
    /**
     * Class name of the submenu icon element
     */
    MegaMenuClasses["submenuIcon"] = "p-megamenu-submenu-icon";
    /**
     * Class name of the panel element
     */
    MegaMenuClasses["panel"] = "p-megamenu-panel";
    /**
     * Class name of the grid element
     */
    MegaMenuClasses["grid"] = "p-megamenu-grid";
    /**
     * Class name of the submenu element
     */
    MegaMenuClasses["submenu"] = "p-megamenu-submenu";
    /**
     * Class name of the submenu item label element
     */
    MegaMenuClasses["submenuItemLabel"] = "p-megamenu-submenu-item-label";
    /**
     * Class name of the separator element
     */
    MegaMenuClasses["separator"] = "p-megamenu-separator";
    /**
     * Class name of the end element
     */
    MegaMenuClasses["end"] = "p-megamenu-end";
})(MegaMenuClasses || (MegaMenuClasses = {}));

const MEGAMENU_INSTANCE = new InjectionToken('MEGAMENU_INSTANCE');
const MEGAMENU_SUB_INSTANCE = new InjectionToken('MEGAMENU_SUB_INSTANCE');
class MegaMenuSub extends BaseComponent {
    bindDirectiveInstance = inject(Bind, { self: true });
    $pcMegaMenu = inject(MEGAMENU_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    $pcMegaMenuSub = inject(MEGAMENU_SUB_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    id = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "id" }] : /* istanbul ignore next */ []));
    items = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "items" }] : /* istanbul ignore next */ []));
    itemTemplate = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "itemTemplate" }] : /* istanbul ignore next */ []));
    menuId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "menuId" }] : /* istanbul ignore next */ []));
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    level = input(0, { ...(ngDevMode ? { debugName: "level" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    focusedItemId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "focusedItemId" }] : /* istanbul ignore next */ []));
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    orientation = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "orientation" }] : /* istanbul ignore next */ []));
    activeItem = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "activeItem" }] : /* istanbul ignore next */ []));
    submenu = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "submenu" }] : /* istanbul ignore next */ []));
    queryMatches = input(false, { ...(ngDevMode ? { debugName: "queryMatches" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    mobileActive = input(false, { ...(ngDevMode ? { debugName: "mobileActive" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    scrollHeight = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "scrollHeight" }] : /* istanbul ignore next */ []));
    tabindex = input(0, { ...(ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    root = input(false, { ...(ngDevMode ? { debugName: "root" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    itemClick = output();
    itemMouseEnter = output();
    menuFocus = output();
    menuBlur = output();
    menuKeydown = output();
    menuMouseDown = output();
    megaMenu = inject(forwardRef(() => MegaMenu));
    _componentStyle = inject(MegaMenuStyle);
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptm(this.root() ? 'rootList' : 'submenu'));
    }
    onItemClick(event, processedItem) {
        this.getItemProp(processedItem, 'command', { originalEvent: event, item: processedItem.item });
        this.itemClick.emit({ originalEvent: event, processedItem, isFocus: true });
    }
    getItemProp(processedItem, name, params = null) {
        return processedItem && processedItem.item ? resolve(processedItem.item[name], params) : undefined;
    }
    getItemId(processedItem) {
        return processedItem.item && processedItem.item?.id ? processedItem.item.id : `${this.menuId()}_${processedItem.key}`;
    }
    getSubListId(processedItem) {
        return `${this.getItemId(processedItem)}_list`;
    }
    getItemLabel(processedItem) {
        return this.getItemProp(processedItem, 'label');
    }
    isSubmenuVisible(submenu) {
        if (this.submenu() && !this.root()) {
            return this.isItemVisible(submenu);
        }
        else {
            return true;
        }
    }
    isItemVisible(processedItem) {
        return this.getItemProp(processedItem, 'visible') !== false;
    }
    isItemActive(processedItem) {
        const activeItem = this.activeItem();
        return isNotEmpty(activeItem) ? activeItem.key === processedItem.key : false;
    }
    isItemDisabled(processedItem) {
        return this.getItemProp(processedItem, 'disabled');
    }
    isItemFocused(processedItem) {
        return this.focusedItemId() === this.getItemId(processedItem);
    }
    isItemGroup(processedItem) {
        return isNotEmpty(processedItem.items);
    }
    getAriaSetSize() {
        return this.items()?.filter((processedItem) => this.isItemVisible(processedItem) && !this.getItemProp(processedItem, 'separator')).length;
    }
    getAriaPosInset(index) {
        return (index -
            (this.items()
                ?.slice(0, index)
                .filter((processedItem) => this.isItemVisible(processedItem) && this.getItemProp(processedItem, 'separator')).length || 0) +
            1);
    }
    onItemMouseEnter(param) {
        const { event, processedItem } = param;
        this.itemMouseEnter.emit({ originalEvent: event, processedItem });
    }
    getPTOptions(processedItem, index, key) {
        const ptContext = {
            context: {
                item: processedItem.item,
                index,
                active: this.isItemActive(processedItem),
                focused: this.isItemFocused(processedItem),
                disabled: this.isItemDisabled(processedItem)
            }
        };
        return this.ptm(key, ptContext);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MegaMenuSub, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: MegaMenuSub, isStandalone: true, selector: "p-megaMenuSub, p-megamenu-sub, ul[pMegaMenuSub]", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, itemTemplate: { classPropertyName: "itemTemplate", publicName: "itemTemplate", isSignal: true, isRequired: false, transformFunction: null }, menuId: { classPropertyName: "menuId", publicName: "menuId", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, level: { classPropertyName: "level", publicName: "level", isSignal: true, isRequired: false, transformFunction: null }, focusedItemId: { classPropertyName: "focusedItemId", publicName: "focusedItemId", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, activeItem: { classPropertyName: "activeItem", publicName: "activeItem", isSignal: true, isRequired: false, transformFunction: null }, submenu: { classPropertyName: "submenu", publicName: "submenu", isSignal: true, isRequired: false, transformFunction: null }, queryMatches: { classPropertyName: "queryMatches", publicName: "queryMatches", isSignal: true, isRequired: false, transformFunction: null }, mobileActive: { classPropertyName: "mobileActive", publicName: "mobileActive", isSignal: true, isRequired: false, transformFunction: null }, scrollHeight: { classPropertyName: "scrollHeight", publicName: "scrollHeight", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, root: { classPropertyName: "root", publicName: "root", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { itemClick: "itemClick", itemMouseEnter: "itemMouseEnter", menuFocus: "menuFocus", menuBlur: "menuBlur", menuKeydown: "menuKeydown", menuMouseDown: "menuMouseDown" }, host: { listeners: { "keydown": "menuKeydown.emit($event)", "focus": "menuFocus.emit($event)", "blur": "menuBlur.emit($event)", "mousedown": "menuMouseDown.emit($event)" }, properties: { "class": "root() ? cx(\"rootList\") : cx(\"submenu\")", "style": "sx(\"rootList\")", "style.display": "isSubmenuVisible(submenu()) ? null : \"none\"", "attr.role": "root() ? \"menubar\" : \"menu\"", "attr.id": "id()", "attr.aria-orientation": "orientation()", "tabindex": "tabindex()", "attr.aria-activedescendant": "focusedItemId()", "attr.data-pc-section": "root() ? \"rootlist\" : \"submenu\"" } }, providers: [
            { provide: MEGAMENU_SUB_INSTANCE, useExisting: MegaMenuSub },
            { provide: PARENT_INSTANCE, useExisting: MegaMenuSub }
        ], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        @if (submenu()) {
            <li [class]="cn(cx('submenuLabel'), getItemProp(submenu(), 'class'))" [style]="getItemProp(submenu(), 'style')" role="presentation" [pBind]="ptm('submenuLabel')">
                {{ getItemLabel(submenu()) }}
            </li>
        }
        @for (processedItem of items(); track processedItem; let index = $index) {
            @if (isItemVisible(processedItem) && getItemProp(processedItem, 'separator')) {
                <li [attr.id]="getItemId(processedItem)" [style]="getItemProp(processedItem, 'style')" [class]="cn(cx('separator'), this.getItemProp(processedItem, 'class'))" role="separator" [pBind]="ptm('separator')"></li>
            }
            @if (isItemVisible(processedItem) && !getItemProp(processedItem, 'separator')) {
                <li
                    #listItem
                    role="menuitem"
                    [attr.id]="getItemId(processedItem)"
                    [attr.data-p-active]="isItemActive(processedItem)"
                    [attr.data-p-focused]="isItemFocused(processedItem)"
                    [attr.data-p-disabled]="isItemDisabled(processedItem)"
                    [attr.aria-label]="getItemLabel(processedItem)"
                    [attr.aria-disabled]="isItemDisabled(processedItem) || undefined"
                    [attr.aria-haspopup]="isItemGroup(processedItem) && !getItemProp(processedItem, 'to') ? 'menu' : undefined"
                    [attr.aria-expanded]="isItemGroup(processedItem) ? isItemActive(processedItem) : undefined"
                    [attr.aria-level]="level() + 1"
                    [attr.aria-setsize]="getAriaSetSize()"
                    [attr.aria-posinset]="getAriaPosInset(index)"
                    [ngStyle]="getItemProp(processedItem, 'style')"
                    [class]="cn(cx('item', { processedItem }), getItemProp(processedItem, 'styleClass'))"
                    pTooltip
                    [tooltipOptions]="getItemProp(processedItem, 'tooltipOptions')"
                    [pBind]="getPTOptions(processedItem, index, 'item')"
                    [pTooltipUnstyled]="unstyled()"
                >
                    <div [class]="cx('itemContent')" [pBind]="getPTOptions(processedItem, index, 'itemContent')" (click)="onItemClick($event, processedItem)" (mouseenter)="onItemMouseEnter({ $event, processedItem })">
                        @if (!itemTemplate()) {
                            @if (!getItemProp(processedItem, 'routerLink')) {
                                <a
                                    [attr.href]="getItemProp(processedItem, 'url')"
                                    [attr.data-automationid]="getItemProp(processedItem, 'automationId')"
                                    [attr.title]="getItemProp(processedItem, 'title')"
                                    [target]="getItemProp(processedItem, 'target')"
                                    [class]="cn(cx('itemLink'), getItemProp(processedItem, 'linkClass'))"
                                    [ngStyle]="getItemProp(processedItem, 'linkStyle')"
                                    [attr.tabindex]="-1"
                                    [pBind]="getPTOptions(processedItem, index, 'itemLink')"
                                    pRipple
                                >
                                    @if (getItemProp(processedItem, 'icon')) {
                                        <span
                                            [class]="cn(cx('itemIcon'), getItemProp(processedItem, 'icon'), getItemProp(processedItem, 'iconClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                            [attr.tabindex]="-1"
                                            [pBind]="getPTOptions(processedItem, index, 'itemIcon')"
                                        >
                                        </span>
                                    }
                                    @if (getItemProp(processedItem, 'escape')) {
                                        <span [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))" [ngStyle]="getItemProp(processedItem, 'labelStyle')" [pBind]="getPTOptions(processedItem, index, 'itemLabel')">
                                            {{ getItemLabel(processedItem) }}
                                        </span>
                                    } @else {
                                        <span
                                            [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'labelStyle')"
                                            [innerHTML]="getItemLabel(processedItem)"
                                            [pBind]="getPTOptions(processedItem, index, 'itemLabel')"
                                        ></span>
                                    }
                                    @if (getItemProp(processedItem, 'badge')) {
                                        <p-badge [class]="getItemProp(processedItem, 'badgeStyleClass')" [value]="getItemProp(processedItem, 'badge')" [unstyled]="unstyled()" />
                                    }
                                    @if (isItemGroup(processedItem)) {
                                        @if (!megaMenu.submenuIconTemplate() && !megaMenu._submenuIconTemplate) {
                                            @if (orientation() === 'horizontal' || mobileActive()) {
                                                <svg data-p-icon="angle-down" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" [attr.aria-hidden]="true" />
                                            } @else {
                                                @if (orientation() === 'vertical') {
                                                    <svg data-p-icon="angle-right" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" [attr.aria-hidden]="true" />
                                                }
                                            }
                                        }
                                        <ng-template *ngTemplateOutlet="megaMenu.submenuIconTemplate() || megaMenu._submenuIconTemplate" [attr.aria-hidden]="true"></ng-template>
                                    }
                                </a>
                            }
                            @if (getItemProp(processedItem, 'routerLink')) {
                                <a
                                    [routerLink]="getItemProp(processedItem, 'routerLink')"
                                    [attr.data-automationid]="getItemProp(processedItem, 'automationId')"
                                    [attr.title]="getItemProp(processedItem, 'title')"
                                    [attr.tabindex]="-1"
                                    [queryParams]="getItemProp(processedItem, 'queryParams')"
                                    [routerLinkActive]="'p-megamenu-item-link-active'"
                                    [routerLinkActiveOptions]="getItemProp(processedItem, 'routerLinkActiveOptions') || { exact: false }"
                                    [target]="getItemProp(processedItem, 'target')"
                                    [class]="cn(cx('itemLink'), getItemProp(processedItem, 'linkClass'))"
                                    [ngStyle]="getItemProp(processedItem, 'linkStyle')"
                                    [fragment]="getItemProp(processedItem, 'fragment')"
                                    [queryParamsHandling]="getItemProp(processedItem, 'queryParamsHandling')"
                                    [preserveFragment]="getItemProp(processedItem, 'preserveFragment')"
                                    [skipLocationChange]="getItemProp(processedItem, 'skipLocationChange')"
                                    [replaceUrl]="getItemProp(processedItem, 'replaceUrl')"
                                    [state]="getItemProp(processedItem, 'state')"
                                    [pBind]="getPTOptions(processedItem, index, 'itemLink')"
                                    pRipple
                                >
                                    @if (getItemProp(processedItem, 'icon')) {
                                        <span
                                            [class]="cn(cx('itemIcon'), getItemProp(processedItem, 'icon'), getItemProp(processedItem, 'iconClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                            [attr.tabindex]="-1"
                                            [pBind]="getPTOptions(processedItem, index, 'itemIcon')"
                                        ></span>
                                    }
                                    @if (getItemProp(processedItem, 'escape')) {
                                        <span [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))" [ngStyle]="getItemProp(processedItem, 'labelStyle')" [pBind]="getPTOptions(processedItem, index, 'itemLabel')">{{
                                            getItemLabel(processedItem)
                                        }}</span>
                                    } @else {
                                        <span
                                            [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'labelStyle')"
                                            [innerHTML]="getItemLabel(processedItem)"
                                            [pBind]="getPTOptions(processedItem, index, 'itemLabel')"
                                        ></span>
                                    }
                                    @if (getItemProp(processedItem, 'badge')) {
                                        <p-badge [styleClass]="getItemProp(processedItem, 'badgeStyleClass')" [value]="getItemProp(processedItem, 'badge')" [unstyled]="unstyled()" />
                                    }
                                    @if (isItemGroup(processedItem)) {
                                        @if (!megaMenu.submenuIconTemplate() && !megaMenu._submenuIconTemplate) {
                                            @if (orientation() === 'horizontal') {
                                                <svg data-p-icon="angle-down" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" [attr.aria-hidden]="true" />
                                            }
                                            @if (orientation() === 'vertical') {
                                                <svg data-p-icon="angle-right" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" [attr.aria-hidden]="true" />
                                            }
                                        }
                                        <ng-template *ngTemplateOutlet="megaMenu.submenuIconTemplate() || megaMenu._submenuIconTemplate" [attr.aria-hidden]="true"></ng-template>
                                    }
                                </a>
                            }
                        }
                        @if (itemTemplate()) {
                            <ng-template *ngTemplateOutlet="itemTemplate(); context: { $implicit: processedItem.item }"></ng-template>
                        }
                    </div>
                    @if (isItemVisible(processedItem) && isItemGroup(processedItem)) {
                        <div [class]="cx('overlay')" [pBind]="ptm('overlay')">
                            <div [class]="cx('grid')" [pBind]="ptm('grid')">
                                @for (col of processedItem.items; track col) {
                                    <div [class]="cx('column', { processedItem })" [pBind]="ptm('column')">
                                        @for (submenu of col; track submenu) {
                                            <ul
                                                pMegaMenuSub
                                                [id]="getSubListId(submenu)"
                                                [submenu]="submenu"
                                                [items]="submenu.items"
                                                [itemTemplate]="itemTemplate()"
                                                [mobileActive]="mobileActive()"
                                                [menuId]="menuId()"
                                                [focusedItemId]="focusedItemId()"
                                                [level]="level() + 1"
                                                [root]="false"
                                                (itemClick)="itemClick.emit($event)"
                                                (itemMouseEnter)="onItemMouseEnter($event)"
                                                [pt]="pt()"
                                                [unstyled]="unstyled()"
                                            ></ul>
                                        }
                                    </div>
                                }
                            </div>
                        </div>
                    }
                </li>
            }
        }
    `, isInline: true, dependencies: [{ kind: "component", type: MegaMenuSub, selector: "p-megaMenuSub, p-megamenu-sub, ul[pMegaMenuSub]", inputs: ["id", "items", "itemTemplate", "menuId", "ariaLabel", "ariaLabelledBy", "level", "focusedItemId", "disabled", "orientation", "activeItem", "submenu", "queryMatches", "mobileActive", "scrollHeight", "tabindex", "root"], outputs: ["itemClick", "itemMouseEnter", "menuFocus", "menuBlur", "menuKeydown", "menuMouseDown"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i3.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "browserUrl", "routerLink"] }, { kind: "directive", type: i3.RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "directive", type: Ripple, selector: "[pRipple]" }, { kind: "ngmodule", type: TooltipModule }, { kind: "directive", type: i4.Tooltip, selector: "[pTooltip]", inputs: ["tooltipPosition", "tooltipEvent", "positionStyle", "tooltipStyleClass", "tooltipZIndex", "escape", "showDelay", "hideDelay", "life", "positionTop", "positionLeft", "autoHide", "fitContent", "hideOnEscape", "showOnEllipsis", "pTooltip", "tooltipDisabled", "tooltipOptions", "appendTo", "ptTooltip", "pTooltipPT", "pTooltipUnstyled"] }, { kind: "directive", type: i1.Bind, selector: "[pBind]", inputs: ["pBind"] }, { kind: "component", type: AngleDownIcon, selector: "[data-p-icon=\"angle-down\"]" }, { kind: "component", type: AngleRightIcon, selector: "[data-p-icon=\"angle-right\"]" }, { kind: "ngmodule", type: BadgeModule }, { kind: "component", type: i5.Badge, selector: "p-badge", inputs: ["styleClass", "badgeSize", "size", "severity", "value", "badgeDisabled"] }, { kind: "ngmodule", type: SharedModule }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MegaMenuSub, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-megaMenuSub, p-megamenu-sub, ul[pMegaMenuSub]',
                    standalone: true,
                    imports: [CommonModule, RouterModule, Ripple, TooltipModule, AngleDownIcon, AngleRightIcon, BadgeModule, SharedModule, Bind],
                    template: `
        @if (submenu()) {
            <li [class]="cn(cx('submenuLabel'), getItemProp(submenu(), 'class'))" [style]="getItemProp(submenu(), 'style')" role="presentation" [pBind]="ptm('submenuLabel')">
                {{ getItemLabel(submenu()) }}
            </li>
        }
        @for (processedItem of items(); track processedItem; let index = $index) {
            @if (isItemVisible(processedItem) && getItemProp(processedItem, 'separator')) {
                <li [attr.id]="getItemId(processedItem)" [style]="getItemProp(processedItem, 'style')" [class]="cn(cx('separator'), this.getItemProp(processedItem, 'class'))" role="separator" [pBind]="ptm('separator')"></li>
            }
            @if (isItemVisible(processedItem) && !getItemProp(processedItem, 'separator')) {
                <li
                    #listItem
                    role="menuitem"
                    [attr.id]="getItemId(processedItem)"
                    [attr.data-p-active]="isItemActive(processedItem)"
                    [attr.data-p-focused]="isItemFocused(processedItem)"
                    [attr.data-p-disabled]="isItemDisabled(processedItem)"
                    [attr.aria-label]="getItemLabel(processedItem)"
                    [attr.aria-disabled]="isItemDisabled(processedItem) || undefined"
                    [attr.aria-haspopup]="isItemGroup(processedItem) && !getItemProp(processedItem, 'to') ? 'menu' : undefined"
                    [attr.aria-expanded]="isItemGroup(processedItem) ? isItemActive(processedItem) : undefined"
                    [attr.aria-level]="level() + 1"
                    [attr.aria-setsize]="getAriaSetSize()"
                    [attr.aria-posinset]="getAriaPosInset(index)"
                    [ngStyle]="getItemProp(processedItem, 'style')"
                    [class]="cn(cx('item', { processedItem }), getItemProp(processedItem, 'styleClass'))"
                    pTooltip
                    [tooltipOptions]="getItemProp(processedItem, 'tooltipOptions')"
                    [pBind]="getPTOptions(processedItem, index, 'item')"
                    [pTooltipUnstyled]="unstyled()"
                >
                    <div [class]="cx('itemContent')" [pBind]="getPTOptions(processedItem, index, 'itemContent')" (click)="onItemClick($event, processedItem)" (mouseenter)="onItemMouseEnter({ $event, processedItem })">
                        @if (!itemTemplate()) {
                            @if (!getItemProp(processedItem, 'routerLink')) {
                                <a
                                    [attr.href]="getItemProp(processedItem, 'url')"
                                    [attr.data-automationid]="getItemProp(processedItem, 'automationId')"
                                    [attr.title]="getItemProp(processedItem, 'title')"
                                    [target]="getItemProp(processedItem, 'target')"
                                    [class]="cn(cx('itemLink'), getItemProp(processedItem, 'linkClass'))"
                                    [ngStyle]="getItemProp(processedItem, 'linkStyle')"
                                    [attr.tabindex]="-1"
                                    [pBind]="getPTOptions(processedItem, index, 'itemLink')"
                                    pRipple
                                >
                                    @if (getItemProp(processedItem, 'icon')) {
                                        <span
                                            [class]="cn(cx('itemIcon'), getItemProp(processedItem, 'icon'), getItemProp(processedItem, 'iconClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                            [attr.tabindex]="-1"
                                            [pBind]="getPTOptions(processedItem, index, 'itemIcon')"
                                        >
                                        </span>
                                    }
                                    @if (getItemProp(processedItem, 'escape')) {
                                        <span [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))" [ngStyle]="getItemProp(processedItem, 'labelStyle')" [pBind]="getPTOptions(processedItem, index, 'itemLabel')">
                                            {{ getItemLabel(processedItem) }}
                                        </span>
                                    } @else {
                                        <span
                                            [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'labelStyle')"
                                            [innerHTML]="getItemLabel(processedItem)"
                                            [pBind]="getPTOptions(processedItem, index, 'itemLabel')"
                                        ></span>
                                    }
                                    @if (getItemProp(processedItem, 'badge')) {
                                        <p-badge [class]="getItemProp(processedItem, 'badgeStyleClass')" [value]="getItemProp(processedItem, 'badge')" [unstyled]="unstyled()" />
                                    }
                                    @if (isItemGroup(processedItem)) {
                                        @if (!megaMenu.submenuIconTemplate() && !megaMenu._submenuIconTemplate) {
                                            @if (orientation() === 'horizontal' || mobileActive()) {
                                                <svg data-p-icon="angle-down" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" [attr.aria-hidden]="true" />
                                            } @else {
                                                @if (orientation() === 'vertical') {
                                                    <svg data-p-icon="angle-right" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" [attr.aria-hidden]="true" />
                                                }
                                            }
                                        }
                                        <ng-template *ngTemplateOutlet="megaMenu.submenuIconTemplate() || megaMenu._submenuIconTemplate" [attr.aria-hidden]="true"></ng-template>
                                    }
                                </a>
                            }
                            @if (getItemProp(processedItem, 'routerLink')) {
                                <a
                                    [routerLink]="getItemProp(processedItem, 'routerLink')"
                                    [attr.data-automationid]="getItemProp(processedItem, 'automationId')"
                                    [attr.title]="getItemProp(processedItem, 'title')"
                                    [attr.tabindex]="-1"
                                    [queryParams]="getItemProp(processedItem, 'queryParams')"
                                    [routerLinkActive]="'p-megamenu-item-link-active'"
                                    [routerLinkActiveOptions]="getItemProp(processedItem, 'routerLinkActiveOptions') || { exact: false }"
                                    [target]="getItemProp(processedItem, 'target')"
                                    [class]="cn(cx('itemLink'), getItemProp(processedItem, 'linkClass'))"
                                    [ngStyle]="getItemProp(processedItem, 'linkStyle')"
                                    [fragment]="getItemProp(processedItem, 'fragment')"
                                    [queryParamsHandling]="getItemProp(processedItem, 'queryParamsHandling')"
                                    [preserveFragment]="getItemProp(processedItem, 'preserveFragment')"
                                    [skipLocationChange]="getItemProp(processedItem, 'skipLocationChange')"
                                    [replaceUrl]="getItemProp(processedItem, 'replaceUrl')"
                                    [state]="getItemProp(processedItem, 'state')"
                                    [pBind]="getPTOptions(processedItem, index, 'itemLink')"
                                    pRipple
                                >
                                    @if (getItemProp(processedItem, 'icon')) {
                                        <span
                                            [class]="cn(cx('itemIcon'), getItemProp(processedItem, 'icon'), getItemProp(processedItem, 'iconClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                            [attr.tabindex]="-1"
                                            [pBind]="getPTOptions(processedItem, index, 'itemIcon')"
                                        ></span>
                                    }
                                    @if (getItemProp(processedItem, 'escape')) {
                                        <span [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))" [ngStyle]="getItemProp(processedItem, 'labelStyle')" [pBind]="getPTOptions(processedItem, index, 'itemLabel')">{{
                                            getItemLabel(processedItem)
                                        }}</span>
                                    } @else {
                                        <span
                                            [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'labelStyle')"
                                            [innerHTML]="getItemLabel(processedItem)"
                                            [pBind]="getPTOptions(processedItem, index, 'itemLabel')"
                                        ></span>
                                    }
                                    @if (getItemProp(processedItem, 'badge')) {
                                        <p-badge [styleClass]="getItemProp(processedItem, 'badgeStyleClass')" [value]="getItemProp(processedItem, 'badge')" [unstyled]="unstyled()" />
                                    }
                                    @if (isItemGroup(processedItem)) {
                                        @if (!megaMenu.submenuIconTemplate() && !megaMenu._submenuIconTemplate) {
                                            @if (orientation() === 'horizontal') {
                                                <svg data-p-icon="angle-down" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" [attr.aria-hidden]="true" />
                                            }
                                            @if (orientation() === 'vertical') {
                                                <svg data-p-icon="angle-right" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" [attr.aria-hidden]="true" />
                                            }
                                        }
                                        <ng-template *ngTemplateOutlet="megaMenu.submenuIconTemplate() || megaMenu._submenuIconTemplate" [attr.aria-hidden]="true"></ng-template>
                                    }
                                </a>
                            }
                        }
                        @if (itemTemplate()) {
                            <ng-template *ngTemplateOutlet="itemTemplate(); context: { $implicit: processedItem.item }"></ng-template>
                        }
                    </div>
                    @if (isItemVisible(processedItem) && isItemGroup(processedItem)) {
                        <div [class]="cx('overlay')" [pBind]="ptm('overlay')">
                            <div [class]="cx('grid')" [pBind]="ptm('grid')">
                                @for (col of processedItem.items; track col) {
                                    <div [class]="cx('column', { processedItem })" [pBind]="ptm('column')">
                                        @for (submenu of col; track submenu) {
                                            <ul
                                                pMegaMenuSub
                                                [id]="getSubListId(submenu)"
                                                [submenu]="submenu"
                                                [items]="submenu.items"
                                                [itemTemplate]="itemTemplate()"
                                                [mobileActive]="mobileActive()"
                                                [menuId]="menuId()"
                                                [focusedItemId]="focusedItemId()"
                                                [level]="level() + 1"
                                                [root]="false"
                                                (itemClick)="itemClick.emit($event)"
                                                (itemMouseEnter)="onItemMouseEnter($event)"
                                                [pt]="pt()"
                                                [unstyled]="unstyled()"
                                            ></ul>
                                        }
                                    </div>
                                }
                            </div>
                        </div>
                    }
                </li>
            }
        }
    `,
                    encapsulation: ViewEncapsulation.None,
                    providers: [
                        { provide: MEGAMENU_SUB_INSTANCE, useExisting: MegaMenuSub },
                        { provide: PARENT_INSTANCE, useExisting: MegaMenuSub }
                    ],
                    host: {
                        '[class]': 'root() ? cx("rootList") : cx("submenu")',
                        '[style]': 'sx("rootList")',
                        '[style.display]': 'isSubmenuVisible(submenu()) ? null : "none"',
                        '[attr.role]': 'root() ? "menubar" : "menu"',
                        '[attr.id]': 'id()',
                        '[attr.aria-orientation]': 'orientation()',
                        '[tabindex]': 'tabindex()',
                        '[attr.aria-activedescendant]': 'focusedItemId()',
                        '[attr.data-pc-section]': 'root() ? "rootlist" : "submenu"',
                        '(keydown)': 'menuKeydown.emit($event)',
                        '(focus)': 'menuFocus.emit($event)',
                        '(blur)': 'menuBlur.emit($event)',
                        '(mousedown)': 'menuMouseDown.emit($event)'
                    },
                    hostDirectives: [Bind]
                }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }], itemTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemTemplate", required: false }] }], menuId: [{ type: i0.Input, args: [{ isSignal: true, alias: "menuId", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], level: [{ type: i0.Input, args: [{ isSignal: true, alias: "level", required: false }] }], focusedItemId: [{ type: i0.Input, args: [{ isSignal: true, alias: "focusedItemId", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], activeItem: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeItem", required: false }] }], submenu: [{ type: i0.Input, args: [{ isSignal: true, alias: "submenu", required: false }] }], queryMatches: [{ type: i0.Input, args: [{ isSignal: true, alias: "queryMatches", required: false }] }], mobileActive: [{ type: i0.Input, args: [{ isSignal: true, alias: "mobileActive", required: false }] }], scrollHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollHeight", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], root: [{ type: i0.Input, args: [{ isSignal: true, alias: "root", required: false }] }], itemClick: [{ type: i0.Output, args: ["itemClick"] }], itemMouseEnter: [{ type: i0.Output, args: ["itemMouseEnter"] }], menuFocus: [{ type: i0.Output, args: ["menuFocus"] }], menuBlur: [{ type: i0.Output, args: ["menuBlur"] }], menuKeydown: [{ type: i0.Output, args: ["menuKeydown"] }], menuMouseDown: [{ type: i0.Output, args: ["menuMouseDown"] }] } });
/**
 * MegaMenu is navigation component that displays submenus together.
 * @group Components
 */
class MegaMenu extends BaseComponent {
    componentName = 'MegaMenu';
    bindDirectiveInstance = inject(Bind, { self: true });
    /**
     * An array of menuitems.
     * @group Props
     */
    model = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "model" }] : /* istanbul ignore next */ []));
    /**
     * Class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Defines the orientation.
     * @group Props
     */
    orientation = input('horizontal', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
    /**
     * Current id state as a string.
     * @group Props
     */
    id = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "id" }] : /* istanbul ignore next */ []));
    /**
     * Defines a string value that labels an interactive element.
     * @group Props
     */
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /**
     * Identifier of the underlying input element.
     * @group Props
     */
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    /**
     * The breakpoint to define the maximum width boundary.
     * @group Props
     */
    breakpoint = input('960px', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "breakpoint" }] : /* istanbul ignore next */ []));
    /**
     * Height of the viewport, a scrollbar is defined if height of list exceeds this value.
     * @group Props
     */
    scrollHeight = input('20rem', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scrollHeight" }] : /* istanbul ignore next */ []));
    /**
     * When present, it specifies that the component should be disabled.
     * @group Props
     */
    disabled = input(false, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex = input(0, { ...(ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Defines template option for start.
     * @group Templates
     */
    startTemplate;
    /**
     * Defines template option for end.
     * @group Templates
     */
    endTemplate;
    /**
     * Defines template option for menu icon.
     * @group Templates
     */
    menuIconTemplate = contentChild('menuicon', { ...(ngDevMode ? { debugName: "menuIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Defines template option for submenu icon.
     * @group Templates
     */
    submenuIconTemplate = contentChild('submenuicon', { ...(ngDevMode ? { debugName: "submenuIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom item template.
     * @param {MegaMenuItemTemplateContext} context - item context.
     * @see {@link MegaMenuItemTemplateContext}
     * @group Templates
     */
    itemTemplate = contentChild('item', { ...(ngDevMode ? { debugName: "itemTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom menu button template on responsive mode.
     * @group Templates
     */
    buttonTemplate = contentChild('button', { ...(ngDevMode ? { debugName: "buttonTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom menu button icon template on responsive mode.
     * @group Templates
     */
    buttonIconTemplate = contentChild('buttonicon', { ...(ngDevMode ? { debugName: "buttonIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    menubuttonViewChild = viewChild('menubutton', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "menubuttonViewChild" }] : /* istanbul ignore next */ []));
    rootmenu = viewChild('rootmenu', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rootmenu" }] : /* istanbul ignore next */ []));
    _startTemplate;
    _endTemplate;
    _menuIconTemplate;
    _submenuIconTemplate;
    _itemTemplate;
    _buttonTemplate;
    _buttonIconTemplate;
    outsideClickListener;
    resizeListener;
    dirty = false;
    focused = false;
    activeItem = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeItem" }] : /* istanbul ignore next */ []));
    focusedItemInfo = signal({ index: -1, level: 0, parentKey: '', item: null }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusedItemInfo" }] : /* istanbul ignore next */ []));
    searchValue = '';
    searchTimeout;
    _processedItems;
    _componentStyle = inject(MegaMenuStyle);
    matchMediaListener;
    query;
    queryMatches = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "queryMatches" }] : /* istanbul ignore next */ []));
    mobileActive = false;
    _generatedId;
    get resolvedId() {
        return this.id() || (this._generatedId ??= uuid('pn_id_'));
    }
    get visibleItems() {
        const processedItem = isNotEmpty(this.activeItem()) ? this.activeItem() : null;
        return processedItem
            ? processedItem.items.reduce((items, col) => {
                col.forEach((submenu) => {
                    submenu.items.forEach((a) => {
                        items.push(a);
                    });
                });
                return items;
            }, [])
            : this.processedItems;
    }
    get processedItems() {
        if (!this._processedItems || !this._processedItems.length) {
            this._processedItems = this.createProcessedItems(this.model() || []);
        }
        return this._processedItems;
    }
    get focusedItemId() {
        const focusedItem = this.focusedItemInfo();
        return focusedItem?.item && focusedItem.item?.id ? focusedItem.item.id : isNotEmpty(focusedItem.key) ? `${this.resolvedId}_${focusedItem.key}` : null;
    }
    constructor() {
        super();
        effect(() => {
            const activeItem = this.activeItem();
            if (isNotEmpty(activeItem)) {
                this.bindOutsideClickListener();
                this.bindResizeListener();
            }
            else {
                this.unbindOutsideClickListener();
                this.unbindResizeListener();
            }
        });
        effect(() => {
            this._processedItems = this.createProcessedItems(this.model() || []);
        });
    }
    onInit() {
        this.bindMatchMediaListener();
    }
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    onAfterContentInit() {
        this.templates()?.forEach((item) => {
            switch (item.getType()) {
                case 'start':
                    this._startTemplate = item.template;
                    break;
                case 'end':
                    this._endTemplate = item.template;
                    break;
                case 'menuicon':
                    this._menuIconTemplate = item.template;
                    break;
                case 'submenuicon':
                    this._submenuIconTemplate = item.template;
                    break;
                case 'item':
                    this._itemTemplate = item.template;
                    break;
                case 'button':
                    this._buttonTemplate = item.template;
                    break;
                case 'buttonicon':
                    this._buttonIconTemplate = item.template;
                    break;
                default:
                    this._itemTemplate = item.template;
                    break;
            }
        });
    }
    bindMatchMediaListener() {
        if (isPlatformBrowser(this.platformId)) {
            if (!this.matchMediaListener) {
                const query = window.matchMedia(`(max-width: ${this.breakpoint()})`);
                this.query = query;
                this.queryMatches.set(query.matches);
                this.matchMediaListener = () => {
                    this.queryMatches.set(query.matches);
                    this.mobileActive = false;
                    this.cd.markForCheck();
                };
                query.addEventListener('change', this.matchMediaListener);
            }
        }
    }
    unbindMatchMediaListener() {
        if (this.matchMediaListener) {
            this.query.removeEventListener('change', this.matchMediaListener);
            this.matchMediaListener = null;
        }
    }
    createProcessedItems(items, level = 0, parent = {}, parentKey = '', columnIndex) {
        const processedItems = [];
        items &&
            items.forEach((item, index) => {
                const key = (parentKey !== '' ? parentKey + '_' : '') + (columnIndex !== undefined ? columnIndex + '_' : '') + index;
                const newItem = {
                    item,
                    index,
                    level,
                    key,
                    parent,
                    parentKey,
                    columnIndex: columnIndex !== undefined ? columnIndex : parent.columnIndex !== undefined ? parent.columnIndex : index
                };
                newItem['items'] =
                    level === 0 && item.items && item.items.length > 0
                        ? item.items.map((_items, _index) => this.createProcessedItems(_items, level + 1, newItem, key, _index))
                        : this.createProcessedItems(item.items, level + 1, newItem, key);
                processedItems.push(newItem);
            });
        return processedItems;
    }
    getItemProp(item, name) {
        return item ? resolve(item[name]) : undefined;
    }
    onItemClick(event) {
        this.dirty = true;
        const { originalEvent, processedItem } = event;
        const grouped = this.isProcessedItemGroup(processedItem);
        const root = isEmpty(processedItem.parent);
        const selected = this.isSelected(processedItem);
        if (selected) {
            const { index, key, parentKey, item } = processedItem;
            this.activeItem.set(null);
            this.focusedItemInfo.set({ index, key, parentKey, item });
            this.dirty = !root;
            if (!this.mobileActive) {
                focus(this.rootmenu()?.el?.nativeElement, { preventScroll: true });
            }
        }
        else {
            if (grouped) {
                this.onItemChange(event);
            }
            else {
                this.hide(originalEvent);
            }
        }
    }
    onItemMouseEnter(event) {
        if (!this.mobileActive && this.dirty) {
            this.onItemChange(event);
        }
    }
    menuButtonClick(event) {
        this.toggle(event);
    }
    menuButtonKeydown(event) {
        (event.code === 'Enter' || event.code === 'NumpadEnter' || event.code === 'Space') && this.menuButtonClick(event);
    }
    toggle(event) {
        if (this.mobileActive) {
            this.mobileActive = false;
            ZIndexUtils.clear(this.rootmenu()?.el.nativeElement);
            this.hide();
        }
        else {
            this.mobileActive = true;
            ZIndexUtils.set('menu', this.rootmenu()?.el.nativeElement, this.config.zIndex.menu);
            setTimeout(() => {
                this.show();
            }, 0);
        }
        this.bindOutsideClickListener();
        event.preventDefault();
    }
    show() {
        this.focusedItemInfo.set({ index: this.findFirstFocusedItemIndex(), level: 0, parentKey: '' });
        focus(this.rootmenu()?.el.nativeElement);
    }
    scrollInView(index = -1) {
        const id = index !== -1 ? `${this.resolvedId}_${index}` : this.focusedItemId;
        let element;
        if (id === null && this.queryMatches()) {
            element = this.menubuttonViewChild()?.nativeElement;
        }
        else {
            element = findSingle(this.rootmenu()?.el?.nativeElement, `li[id="${id}"]`);
        }
        if (element) {
            element.scrollIntoView && element.scrollIntoView({ block: 'nearest', inline: 'nearest', behavior: 'smooth' });
        }
    }
    onItemChange(event) {
        const { processedItem, isFocus } = event;
        if (isEmpty(processedItem))
            return;
        const { index, key, parentKey, items, item } = processedItem;
        const grouped = isNotEmpty(items);
        if (grouped) {
            this.activeItem.set(processedItem);
        }
        this.focusedItemInfo.set({ index, key, parentKey, item });
        grouped && (this.dirty = true);
        isFocus && focus(this.rootmenu()?.el?.nativeElement);
    }
    hide(event, isFocus) {
        if (this.mobileActive) {
            this.mobileActive = false;
            setTimeout(() => {
                focus(this.menubuttonViewChild()?.nativeElement);
                this.scrollInView();
            }, 100);
        }
        this.activeItem.set(null);
        this.focusedItemInfo.set({ index: -1, key: '', parentKey: '', item: null });
        isFocus && focus(this.rootmenu()?.el?.nativeElement);
        this.dirty = false;
    }
    onMenuMouseDown() {
        this.dirty = true;
    }
    onMenuFocus(event) {
        this.focused = true;
        const relatedTarget = event.relatedTarget;
        const isFromOutside = !relatedTarget || !this.el.nativeElement.contains(relatedTarget);
        if (isFromOutside && this.focusedItemInfo().index === -1 && isEmpty(this.activeItem()) && !this.dirty) {
            const index = this.findFirstFocusedItemIndex();
            const processedItem = this.findVisibleItem(index);
            this.focusedItemInfo.set({ index, key: processedItem.key, parentKey: processedItem.parentKey, item: processedItem.item });
        }
    }
    onMenuBlur(event) {
        const relatedTarget = event.relatedTarget;
        if (relatedTarget && this.el.nativeElement.contains(relatedTarget)) {
            return;
        }
        setTimeout(() => {
            const activeElement = this.document.activeElement;
            if (activeElement && this.el.nativeElement.contains(activeElement)) {
                return;
            }
            this.focused = false;
            this.focusedItemInfo.set({ index: -1, level: 0, parentKey: '', item: null });
            this.searchValue = '';
            this.dirty = false;
        });
    }
    onKeyDown(event) {
        const metaKey = event.metaKey || event.ctrlKey;
        switch (event.code) {
            case 'ArrowDown':
                this.onArrowDownKey(event);
                break;
            case 'ArrowUp':
                this.onArrowUpKey(event);
                break;
            case 'ArrowLeft':
                this.onArrowLeftKey(event);
                break;
            case 'ArrowRight':
                this.onArrowRightKey(event);
                break;
            case 'Home':
                this.onHomeKey(event);
                break;
            case 'End':
                this.onEndKey(event);
                break;
            case 'Space':
                this.onSpaceKey(event);
                break;
            case 'Enter':
                this.onEnterKey(event);
                break;
            case 'Escape':
                this.onEscapeKey(event);
                break;
            case 'Tab':
                this.onTabKey(event);
                break;
            case 'PageDown':
            case 'PageUp':
            case 'Backspace':
            case 'ShiftLeft':
            case 'ShiftRight':
                //NOOP
                break;
            default:
                if (!metaKey && isPrintableCharacter(event.key)) {
                    this.searchItems(event, event.key);
                }
                break;
        }
    }
    findFirstFocusedItemIndex() {
        const selectedIndex = this.findSelectedItemIndex();
        return selectedIndex < 0 ? this.findFirstItemIndex() : selectedIndex;
    }
    findFirstItemIndex() {
        return this.visibleItems.findIndex((processedItem) => this.isValidItem(processedItem));
    }
    findSelectedItemIndex() {
        return this.visibleItems.findIndex((processedItem) => this.isValidSelectedItem(processedItem));
    }
    isProcessedItemGroup(processedItem) {
        return processedItem && isNotEmpty(processedItem.items);
    }
    isSelected(processedItem) {
        return isNotEmpty(this.activeItem()) ? this.activeItem().key === processedItem.key : false;
    }
    isValidSelectedItem(processedItem) {
        return this.isValidItem(processedItem) && this.isSelected(processedItem);
    }
    isValidItem(processedItem) {
        return !!processedItem && !this.isItemDisabled(processedItem.item) && !this.isItemSeparator(processedItem.item);
    }
    isItemDisabled(item) {
        return this.getItemProp(item, 'disabled');
    }
    isItemSeparator(item) {
        return this.getItemProp(item, 'separator');
    }
    isItemMatched(processedItem) {
        return this.isValidItem(processedItem) && this.getProccessedItemLabel(processedItem).toLocaleLowerCase().startsWith(this.searchValue.toLocaleLowerCase());
    }
    isProccessedItemGroup(processedItem) {
        return processedItem && isNotEmpty(processedItem.items);
    }
    searchItems(event, char) {
        this.searchValue = (this.searchValue || '') + char;
        let itemIndex = -1;
        let matched = false;
        if (this.focusedItemInfo().index !== -1) {
            itemIndex = this.visibleItems.slice(this.focusedItemInfo().index).findIndex((processedItem) => this.isItemMatched(processedItem));
            itemIndex = itemIndex === -1 ? this.visibleItems.slice(0, this.focusedItemInfo().index).findIndex((processedItem) => this.isItemMatched(processedItem)) : itemIndex + this.focusedItemInfo().index;
        }
        else {
            itemIndex = this.visibleItems.findIndex((processedItem) => this.isItemMatched(processedItem));
        }
        if (itemIndex !== -1) {
            matched = true;
        }
        if (itemIndex === -1 && this.focusedItemInfo().index === -1) {
            itemIndex = this.findFirstFocusedItemIndex();
        }
        if (itemIndex !== -1) {
            this.changeFocusedItemInfo(event, itemIndex);
        }
        if (this.searchTimeout) {
            clearTimeout(this.searchTimeout);
        }
        this.searchTimeout = setTimeout(() => {
            this.searchValue = '';
            this.searchTimeout = null;
        }, 500);
        return matched;
    }
    getProccessedItemLabel(processedItem) {
        return processedItem ? this.getItemLabel(processedItem.item) : undefined;
    }
    getItemLabel(item) {
        return this.getItemProp(item, 'label');
    }
    changeFocusedItemInfo(event, index) {
        const processedItem = this.findVisibleItem(index);
        if (isNotEmpty(processedItem)) {
            const { key, parentKey, item } = processedItem;
            this.focusedItemInfo.set({ index, key: key ? key : '', parentKey, item });
        }
        this.scrollInView();
    }
    onArrowDownKey(event) {
        if (this.orientation() === 'horizontal') {
            if (isNotEmpty(this.activeItem()) && this.activeItem().key === this.focusedItemInfo().key) {
                const { key, item } = this.activeItem();
                this.focusedItemInfo.set({ index: -1, key: '', parentKey: key, item });
            }
            else {
                const processedItem = this.findVisibleItem(this.focusedItemInfo().index);
                const grouped = this.isProccessedItemGroup(processedItem);
                if (grouped) {
                    const { parentKey, key, item } = processedItem;
                    this.onItemChange({ originalEvent: event, processedItem });
                    this.focusedItemInfo.set({ index: -1, key: key, parentKey: parentKey, item: item });
                    this.searchValue = '';
                }
            }
        }
        const itemIndex = this.focusedItemInfo().index !== -1 ? this.findNextItemIndex(this.focusedItemInfo().index) : this.findFirstFocusedItemIndex();
        this.changeFocusedItemInfo(event, itemIndex);
        event.preventDefault();
    }
    onArrowRightKey(event) {
        const processedItem = this.findVisibleItem(this.focusedItemInfo().index);
        const grouped = this.isProccessedItemGroup(processedItem);
        if (grouped) {
            if (this.orientation() === 'vertical') {
                if (isNotEmpty(this.activeItem()) && this.activeItem().key === processedItem.key) {
                    this.focusedItemInfo.set({ index: -1, key: '', parentKey: this.activeItem().key, item: processedItem.item });
                }
                else {
                    const processedItem = this.findVisibleItem(this.focusedItemInfo().index);
                    const grouped = this.isProccessedItemGroup(processedItem);
                    if (grouped) {
                        this.onItemChange({ originalEvent: event, processedItem });
                        this.focusedItemInfo.set({
                            index: -1,
                            key: processedItem.key,
                            parentKey: processedItem.parentKey,
                            item: processedItem.item
                        });
                        this.searchValue = '';
                    }
                }
            }
            const itemIndex = this.focusedItemInfo().index !== -1 ? this.findNextItemIndex(this.focusedItemInfo().index) : this.findFirstFocusedItemIndex();
            this.changeFocusedItemInfo(event, itemIndex);
        }
        else {
            const columnIndex = processedItem.columnIndex + 1;
            const itemIndex = this.visibleItems.findIndex((item) => item.columnIndex === columnIndex);
            itemIndex !== -1 && this.changeFocusedItemInfo(event, itemIndex);
        }
        event.preventDefault();
    }
    onArrowUpKey(event) {
        if (event.altKey && this.orientation() === 'horizontal') {
            if (this.focusedItemInfo().index !== -1) {
                const processedItem = this.findVisibleItem(this.focusedItemInfo().index);
                const grouped = this.isProccessedItemGroup(processedItem);
                if (!grouped && isNotEmpty(this.activeItem)) {
                    if (this.focusedItemInfo().index === 0) {
                        this.focusedItemInfo.set({
                            index: this.activeItem().index,
                            key: this.activeItem().key,
                            parentKey: this.activeItem().parentKey,
                            item: processedItem.item
                        });
                        this.activeItem.set(null);
                    }
                    else {
                        this.changeFocusedItemInfo(event, this.findFirstItemIndex());
                    }
                }
            }
            event.preventDefault();
        }
        else {
            const itemIndex = this.focusedItemInfo().index !== -1 ? this.findPrevItemIndex(this.focusedItemInfo().index) : this.findLastFocusedItemIndex();
            this.changeFocusedItemInfo(event, itemIndex);
            event.preventDefault();
        }
    }
    onArrowLeftKey(event) {
        const processedItem = this.findVisibleItem(this.focusedItemInfo().index);
        const grouped = this.isProccessedItemGroup(processedItem);
        if (grouped) {
            if (this.orientation() === 'horizontal') {
                const itemIndex = this.focusedItemInfo().index !== -1 ? this.findPrevItemIndex(this.focusedItemInfo().index) : this.findLastFocusedItemIndex();
                this.changeFocusedItemInfo(event, itemIndex);
            }
        }
        else {
            if (this.orientation() === 'vertical' && isNotEmpty(this.activeItem())) {
                if (processedItem.columnIndex === 0) {
                    this.focusedItemInfo.set({
                        index: this.activeItem().index,
                        key: this.activeItem().key,
                        parentKey: this.activeItem().parentKey,
                        item: processedItem.item
                    });
                    this.activeItem.set(null);
                }
            }
            const columnIndex = processedItem.columnIndex - 1;
            const itemIndex = this.visibleItems.findIndex((item) => item.columnIndex === columnIndex);
            itemIndex !== -1 && this.changeFocusedItemInfo(event, itemIndex);
        }
        event.preventDefault();
    }
    onHomeKey(event) {
        this.changeFocusedItemInfo(event, this.findFirstItemIndex());
        event.preventDefault();
    }
    onEndKey(event) {
        this.changeFocusedItemInfo(event, this.findLastItemIndex());
        event.preventDefault();
    }
    onSpaceKey(event) {
        this.onEnterKey(event);
    }
    onEscapeKey(event) {
        if (isNotEmpty(this.activeItem())) {
            this.focusedItemInfo.set({ index: this.activeItem().index, key: this.activeItem().key, item: this.activeItem().item });
            this.activeItem.set(null);
        }
        event.preventDefault();
    }
    onTabKey(event) {
        if (this.focusedItemInfo().index !== -1) {
            const processedItem = this.findVisibleItem(this.focusedItemInfo().index);
            const grouped = this.isProccessedItemGroup(processedItem);
            !grouped && this.onItemChange({ originalEvent: event, processedItem });
        }
        this.hide();
    }
    onEnterKey(event) {
        if (this.focusedItemInfo().index !== -1) {
            const element = findSingle(this.rootmenu()?.el?.nativeElement, `li[id="${`${this.focusedItemId}`}"]`);
            const anchorElement = element && (findSingle(element, '[data-pc-section="itemlink"]') || findSingle(element, 'a,button'));
            anchorElement ? anchorElement.click() : element && element.click();
            const processedItem = this.visibleItems[this.focusedItemInfo().index];
            const grouped = this.isProccessedItemGroup(processedItem);
            !grouped && this.changeFocusedItemInfo(event, this.findFirstFocusedItemIndex());
        }
        event.preventDefault();
    }
    findVisibleItem(index) {
        return isNotEmpty(this.visibleItems) ? this.visibleItems[index] : null;
    }
    findLastFocusedItemIndex() {
        const selectedIndex = this.findSelectedItemIndex();
        return selectedIndex < 0 ? this.findLastItemIndex() : selectedIndex;
    }
    findLastItemIndex() {
        return findLastIndex(this.visibleItems, (processedItem) => this.isValidItem(processedItem));
    }
    findPrevItemIndex(index) {
        const matchedItemIndex = index > 0 ? findLastIndex(this.visibleItems.slice(0, index), (processedItem) => this.isValidItem(processedItem)) : -1;
        return matchedItemIndex > -1 ? matchedItemIndex : index;
    }
    findNextItemIndex(index) {
        const matchedItemIndex = index < this.visibleItems.length - 1 ? this.visibleItems.slice(index + 1).findIndex((processedItem) => this.isValidItem(processedItem)) : -1;
        return matchedItemIndex > -1 ? matchedItemIndex + index + 1 : index;
    }
    bindResizeListener() {
        if (!this.resizeListener) {
            this.resizeListener = (event) => {
                if (!isTouchDevice()) {
                    this.hide(event, true);
                }
                this.mobileActive = false;
            };
            window.addEventListener('resize', this.resizeListener);
        }
    }
    bindOutsideClickListener() {
        if (isPlatformBrowser(this.platformId)) {
            if (!this.outsideClickListener) {
                this.outsideClickListener = this.renderer.listen(this.document, 'click', (event) => {
                    const isOutsideContainer = this.el?.nativeElement !== event.target && !this.el?.nativeElement.contains(event.target);
                    if (isOutsideContainer) {
                        this.hide();
                    }
                });
            }
        }
    }
    unbindOutsideClickListener() {
        if (this.outsideClickListener) {
            this.outsideClickListener();
            this.outsideClickListener = null;
        }
    }
    unbindResizeListener() {
        if (this.resizeListener) {
            window.removeEventListener('resize', this.resizeListener);
            this.resizeListener = null;
        }
    }
    onDestroy() {
        this.unbindOutsideClickListener();
        this.unbindResizeListener();
        this.unbindMatchMediaListener();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MegaMenu, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: MegaMenu, isStandalone: true, selector: "p-megaMenu, p-megamenu, p-mega-menu", inputs: { model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, breakpoint: { classPropertyName: "breakpoint", publicName: "breakpoint", isSignal: true, isRequired: false, transformFunction: null }, scrollHeight: { classPropertyName: "scrollHeight", publicName: "scrollHeight", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "cn(cx(\"root\"), styleClass())", "id": "resolvedId" } }, providers: [MegaMenuStyle, { provide: MEGAMENU_INSTANCE, useExisting: MegaMenu }, { provide: PARENT_INSTANCE, useExisting: MegaMenu }], queries: [{ propertyName: "menuIconTemplate", first: true, predicate: ["menuicon"], isSignal: true }, { propertyName: "submenuIconTemplate", first: true, predicate: ["submenuicon"], isSignal: true }, { propertyName: "itemTemplate", first: true, predicate: ["item"], isSignal: true }, { propertyName: "buttonTemplate", first: true, predicate: ["button"], isSignal: true }, { propertyName: "buttonIconTemplate", first: true, predicate: ["buttonicon"], isSignal: true }, { propertyName: "templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "startTemplate", first: true, predicate: ["start"] }, { propertyName: "endTemplate", first: true, predicate: ["end"] }], viewQueries: [{ propertyName: "menubuttonViewChild", first: true, predicate: ["menubutton"], descendants: true, isSignal: true }, { propertyName: "rootmenu", first: true, predicate: ["rootmenu"], descendants: true, isSignal: true }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        @if (startTemplate || _startTemplate) {
            <div [class]="cx('start')" [pBind]="ptm('start')">
                <ng-container *ngTemplateOutlet="startTemplate || _startTemplate"></ng-container>
            </div>
        }
        @if (!buttonTemplate() && !_buttonTemplate) {
            @if (model() && model()!.length > 0) {
                <a
                    #menubutton
                    role="button"
                    tabindex="0"
                    [class]="cx('button')"
                    [attr.aria-haspopup]="model()!.length && model()!.length > 0 ? true : false"
                    [attr.aria-expanded]="mobileActive"
                    [attr.aria-controls]="resolvedId"
                    [attr.aria-label]="config.translation.aria.navigation"
                    [pBind]="ptm('button')"
                    (click)="menuButtonClick($event)"
                    (keydown)="menuButtonKeydown($event)"
                >
                    @if (!buttonIconTemplate() && !_buttonIconTemplate) {
                        <svg data-p-icon="bars" [pBind]="ptm('buttonIcon')" />
                    }
                    <ng-template *ngTemplateOutlet="buttonIconTemplate() || _buttonIconTemplate"></ng-template>
                </a>
            }
        }
        <ng-container *ngTemplateOutlet="buttonTemplate() || _buttonTemplate"></ng-container>
        <ul
            pMegaMenuSub
            #rootmenu
            [itemTemplate]="itemTemplate() || _itemTemplate"
            [items]="processedItems"
            [attr.id]="resolvedId + '_list'"
            [menuId]="resolvedId"
            [root]="true"
            [orientation]="orientation()"
            [ariaLabel]="ariaLabel()"
            [disabled]="disabled()"
            [tabindex]="!disabled() ? tabindex() : -1"
            [activeItem]="activeItem()"
            [level]="0"
            [ariaLabelledBy]="ariaLabelledBy()"
            [focusedItemId]="focused ? focusedItemId : undefined"
            [mobileActive]="mobileActive"
            (itemClick)="onItemClick($event)"
            (menuFocus)="onMenuFocus($event)"
            (menuBlur)="onMenuBlur($event)"
            (menuKeydown)="onKeyDown($event)"
            (menuMouseDown)="onMenuMouseDown()"
            (itemMouseEnter)="onItemMouseEnter($event)"
            [queryMatches]="queryMatches()"
            [scrollHeight]="scrollHeight()"
            [pt]="pt()"
            [unstyled]="unstyled()"
        ></ul>
        @if (endTemplate || _endTemplate) {
            <div [class]="cx('end')" [pBind]="ptm('end')">
                <ng-container *ngTemplateOutlet="endTemplate || _endTemplate"></ng-container>
            </div>
        }
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: RouterModule }, { kind: "component", type: MegaMenuSub, selector: "p-megaMenuSub, p-megamenu-sub, ul[pMegaMenuSub]", inputs: ["id", "items", "itemTemplate", "menuId", "ariaLabel", "ariaLabelledBy", "level", "focusedItemId", "disabled", "orientation", "activeItem", "submenu", "queryMatches", "mobileActive", "scrollHeight", "tabindex", "root"], outputs: ["itemClick", "itemMouseEnter", "menuFocus", "menuBlur", "menuKeydown", "menuMouseDown"] }, { kind: "ngmodule", type: TooltipModule }, { kind: "directive", type: i1.Bind, selector: "[pBind]", inputs: ["pBind"] }, { kind: "component", type: BarsIcon, selector: "[data-p-icon=\"bars\"]" }, { kind: "ngmodule", type: BadgeModule }, { kind: "ngmodule", type: SharedModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MegaMenu, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-megaMenu, p-megamenu, p-mega-menu',
                    standalone: true,
                    imports: [CommonModule, RouterModule, MegaMenuSub, TooltipModule, BarsIcon, BadgeModule, SharedModule, Bind],
                    template: `
        @if (startTemplate || _startTemplate) {
            <div [class]="cx('start')" [pBind]="ptm('start')">
                <ng-container *ngTemplateOutlet="startTemplate || _startTemplate"></ng-container>
            </div>
        }
        @if (!buttonTemplate() && !_buttonTemplate) {
            @if (model() && model()!.length > 0) {
                <a
                    #menubutton
                    role="button"
                    tabindex="0"
                    [class]="cx('button')"
                    [attr.aria-haspopup]="model()!.length && model()!.length > 0 ? true : false"
                    [attr.aria-expanded]="mobileActive"
                    [attr.aria-controls]="resolvedId"
                    [attr.aria-label]="config.translation.aria.navigation"
                    [pBind]="ptm('button')"
                    (click)="menuButtonClick($event)"
                    (keydown)="menuButtonKeydown($event)"
                >
                    @if (!buttonIconTemplate() && !_buttonIconTemplate) {
                        <svg data-p-icon="bars" [pBind]="ptm('buttonIcon')" />
                    }
                    <ng-template *ngTemplateOutlet="buttonIconTemplate() || _buttonIconTemplate"></ng-template>
                </a>
            }
        }
        <ng-container *ngTemplateOutlet="buttonTemplate() || _buttonTemplate"></ng-container>
        <ul
            pMegaMenuSub
            #rootmenu
            [itemTemplate]="itemTemplate() || _itemTemplate"
            [items]="processedItems"
            [attr.id]="resolvedId + '_list'"
            [menuId]="resolvedId"
            [root]="true"
            [orientation]="orientation()"
            [ariaLabel]="ariaLabel()"
            [disabled]="disabled()"
            [tabindex]="!disabled() ? tabindex() : -1"
            [activeItem]="activeItem()"
            [level]="0"
            [ariaLabelledBy]="ariaLabelledBy()"
            [focusedItemId]="focused ? focusedItemId : undefined"
            [mobileActive]="mobileActive"
            (itemClick)="onItemClick($event)"
            (menuFocus)="onMenuFocus($event)"
            (menuBlur)="onMenuBlur($event)"
            (menuKeydown)="onKeyDown($event)"
            (menuMouseDown)="onMenuMouseDown()"
            (itemMouseEnter)="onItemMouseEnter($event)"
            [queryMatches]="queryMatches()"
            [scrollHeight]="scrollHeight()"
            [pt]="pt()"
            [unstyled]="unstyled()"
        ></ul>
        @if (endTemplate || _endTemplate) {
            <div [class]="cx('end')" [pBind]="ptm('end')">
                <ng-container *ngTemplateOutlet="endTemplate || _endTemplate"></ng-container>
            </div>
        }
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [MegaMenuStyle, { provide: MEGAMENU_INSTANCE, useExisting: MegaMenu }, { provide: PARENT_INSTANCE, useExisting: MegaMenu }],
                    host: {
                        '[class]': 'cn(cx("root"), styleClass())',
                        '[id]': 'resolvedId'
                    },
                    hostDirectives: [Bind]
                }]
        }], ctorParameters: () => [], propDecorators: { model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], breakpoint: [{ type: i0.Input, args: [{ isSignal: true, alias: "breakpoint", required: false }] }], scrollHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollHeight", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], startTemplate: [{
                type: ContentChild,
                args: ['start', { descendants: false }]
            }], endTemplate: [{
                type: ContentChild,
                args: ['end', { descendants: false }]
            }], menuIconTemplate: [{ type: i0.ContentChild, args: ['menuicon', { ...{ descendants: false }, isSignal: true }] }], submenuIconTemplate: [{ type: i0.ContentChild, args: ['submenuicon', { ...{ descendants: false }, isSignal: true }] }], itemTemplate: [{ type: i0.ContentChild, args: ['item', { ...{ descendants: false }, isSignal: true }] }], buttonTemplate: [{ type: i0.ContentChild, args: ['button', { ...{ descendants: false }, isSignal: true }] }], buttonIconTemplate: [{ type: i0.ContentChild, args: ['buttonicon', { ...{ descendants: false }, isSignal: true }] }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }], menubuttonViewChild: [{ type: i0.ViewChild, args: ['menubutton', { isSignal: true }] }], rootmenu: [{ type: i0.ViewChild, args: ['rootmenu', { isSignal: true }] }] } });
class MegaMenuModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MegaMenuModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: MegaMenuModule, imports: [MegaMenu, SharedModule], exports: [MegaMenu, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MegaMenuModule, imports: [MegaMenu, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MegaMenuModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [MegaMenu, SharedModule],
                    exports: [MegaMenu, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { MegaMenu, MegaMenuClasses, MegaMenuModule, MegaMenuStyle, MegaMenuSub };
//# sourceMappingURL=wawjs-ngx-prime-megamenu.mjs.map
