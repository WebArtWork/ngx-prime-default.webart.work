export * from '@wawjs/ngx-prime/types/panelmenu';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, input, numberAttribute, booleanAttribute, output, inject, ElementRef, forwardRef, ViewEncapsulation, Component, viewChild, signal, computed, effect, ChangeDetectionStrategy, contentChild, contentChildren, NgModule } from '@angular/core';
import * as i3 from '@angular/router';
import { RouterModule } from '@angular/router';
import { resolve, isNotEmpty, findLast, findSingle, isPrintableCharacter, isEmpty, uuid, equals, focus, getAttribute } from '@wawjs/css-prime-utils';
import { SharedModule, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind, BindModule } from '@wawjs/ngx-prime/bind';
import { ChevronDownIcon, ChevronRightIcon } from '@wawjs/ngx-prime/icons';
import * as i5 from '@wawjs/ngx-prime/motion';
import { MotionModule } from '@wawjs/ngx-prime/motion';
import * as i4 from '@wawjs/ngx-prime/tooltip';
import { TooltipModule } from '@wawjs/ngx-prime/tooltip';
import { style as style$1 } from '@wawjs/css-prime-styles/panelmenu';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const style = /*css*/ `
    ${style$1}
    /*For ngx-prime*/


    .p-panelmenu-root-list,
    .p-panelmenu-submenu,
    .p-panelmenu-item-link {
        outline: 0 none;
    }
`;
const classes = {
    root: () => ['p-panelmenu p-component'],
    panel: 'p-panelmenu-panel',
    header: ({ instance, item }) => [
        'p-panelmenu-header',
        {
            'p-panelmenu-header-active': instance.isItemActive(item) && !!item.items,
            'p-disabled': instance.isItemDisabled(item)
        }
    ],
    headerContent: 'p-panelmenu-header-content',
    headerLink: 'p-panelmenu-header-link',
    headerIcon: 'p-panelmenu-header-icon',
    headerLabel: 'p-panelmenu-header-label',
    contentContainer: ({ instance, processedItem }) => ['p-panelmenu-content-container', { 'p-panelmenu-expanded': instance.isItemActive(processedItem) }],
    contentWrapper: 'p-panelmenu-content-wrapper',
    content: 'p-panelmenu-content',
    rootList: 'p-panelmenu-root-list',
    item: ({ instance, processedItem }) => [
        'p-panelmenu-item',
        {
            'p-focus': instance.isItemFocused(processedItem) && !instance.isItemDisabled(processedItem),
            'p-disabled': instance.isItemDisabled(processedItem)
        }
    ],
    itemContent: 'p-panelmenu-item-content',
    itemLink: 'p-panelmenu-item-link',
    itemIcon: 'p-panelmenu-item-icon',
    itemLabel: 'p-panelmenu-item-label',
    submenuIcon: 'p-panelmenu-submenu-icon',
    submenu: 'p-panelmenu-submenu',
    separator: 'p-menuitem-separator',
    badge: 'p-menuitem-badge'
};
class PanelMenuStyle extends BaseStyle {
    name = 'panelmenu';
    style = style;
    classes = classes;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PanelMenuStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PanelMenuStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PanelMenuStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * PanelMenu is a hybrid of Accordion and Tree components.
 *
 * [Live Demo](https://www.ngx-prime.org/panelmenu/)
 *
 * @module panelmenustyle
 *
 */
var PanelMenuClasses;
(function (PanelMenuClasses) {
    /**
     * Class name of the root element
     */
    PanelMenuClasses["root"] = "p-panelmenu";
    /**
     * Class name of the panel element
     */
    PanelMenuClasses["panel"] = "p-panelmenu-panel";
    /**
     * Class name of the header element
     */
    PanelMenuClasses["header"] = "p-panelmenu-header";
    /**
     * Class name of the header content element
     */
    PanelMenuClasses["headerContent"] = "p-panelmenu-header-content";
    /**
     * Class name of the header link element
     */
    PanelMenuClasses["headerLink"] = "p-panelmenu-header-link";
    /**
     * Class name of the header icon element
     */
    PanelMenuClasses["headerIcon"] = "p-panelmenu-header-icon";
    /**
     * Class name of the header label element
     */
    PanelMenuClasses["headerLabel"] = "p-panelmenu-header-label";
    /**
     * Class name of the content container element
     */
    PanelMenuClasses["contentContainer"] = "p-panelmenu-content-container";
    /**
     * Class name of the content element
     */
    PanelMenuClasses["content"] = "p-panelmenu-content";
    /**
     * Class name of the root list element
     */
    PanelMenuClasses["rootList"] = "p-panelmenu-root-list";
    /**
     * Class name of the item element
     */
    PanelMenuClasses["item"] = "p-panelmenu-item";
    /**
     * Class name of the item content element
     */
    PanelMenuClasses["itemContent"] = "p-panelmenu-item-content";
    /**
     * Class name of the item link element
     */
    PanelMenuClasses["itemLink"] = "p-panelmenu-item-link";
    /**
     * Class name of the item icon element
     */
    PanelMenuClasses["itemIcon"] = "p-panelmenu-item-icon";
    /**
     * Class name of the item label element
     */
    PanelMenuClasses["itemLabel"] = "p-panelmenu-item-label";
    /**
     * Class name of the submenu icon element
     */
    PanelMenuClasses["submenuIcon"] = "p-panelmenu-submenu-icon";
    /**
     * Class name of the submenu element
     */
    PanelMenuClasses["submenu"] = "p-panelmenu-submenu";
    PanelMenuClasses["separator"] = "p-menuitem-separator";
})(PanelMenuClasses || (PanelMenuClasses = {}));

const PANELMENU_INSTANCE = new InjectionToken('PANELMENU_INSTANCE');
const PANELMENUSUB_INSTANCE = new InjectionToken('PANELMENUSUB_INSTANCE');
class PanelMenuSub extends BaseComponent {
    panelId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "panelId" }] : /* istanbul ignore next */ []));
    focusedItemId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "focusedItemId" }] : /* istanbul ignore next */ []));
    items = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "items" }] : /* istanbul ignore next */ []));
    itemTemplate = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "itemTemplate" }] : /* istanbul ignore next */ []));
    level = input(0, { ...(ngDevMode ? { debugName: "level" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    activeItemPath = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "activeItemPath" }] : /* istanbul ignore next */ []));
    root = input(undefined, { ...(ngDevMode ? { debugName: "root" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    tabindex = input(undefined, { ...(ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    transitionOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "transitionOptions" }] : /* istanbul ignore next */ []));
    parentExpanded = input(undefined, { ...(ngDevMode ? { debugName: "parentExpanded" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    motionOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "motionOptions" }] : /* istanbul ignore next */ []));
    itemToggle = output();
    menuFocus = output();
    menuBlur = output();
    menuKeyDown = output();
    listViewChild = inject(ElementRef);
    panelMenu = inject(forwardRef(() => PanelMenu));
    _componentStyle = inject(PanelMenuStyle);
    bindDirectiveInstance = inject(Bind, { self: true });
    $pcPanelMenu = inject(PANELMENU_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptm(this.root() ? 'rootList' : 'submenu'));
    }
    getPTOptions(processedItem, index, key) {
        return this.ptm(key, {
            context: {
                item: processedItem.item,
                index,
                active: this.isItemActive(processedItem),
                focused: this.isItemFocused(processedItem),
                disabled: this.isItemDisabled(processedItem)
            }
        });
    }
    getItemId(processedItem) {
        return processedItem.item?.id ?? `${this.panelId()}_${processedItem.key}`;
    }
    getItemKey(processedItem) {
        return this.getItemId(processedItem);
    }
    getItemClass(processedItem) {
        return {
            'p-panelmenu-item': true,
            'p-disabled': this.isItemDisabled(processedItem),
            'p-focus': this.isItemFocused(processedItem)
        };
    }
    getItemProp(processedItem, name, params) {
        return processedItem && processedItem.item ? resolve(processedItem.item[name], params) : undefined;
    }
    getItemLabel(processedItem) {
        return this.getItemProp(processedItem, 'label');
    }
    isItemExpanded(processedItem) {
        return processedItem.expanded;
    }
    isItemActive(processedItem) {
        return this.isItemExpanded(processedItem) || (this.activeItemPath() ?? []).some((path) => path && path.key === processedItem.key);
    }
    isItemVisible(processedItem) {
        return this.getItemProp(processedItem, 'visible') !== false;
    }
    isItemDisabled(processedItem) {
        return this.getItemProp(processedItem, 'disabled');
    }
    isItemFocused(processedItem) {
        return this.focusedItemId() === this.getItemId(processedItem);
    }
    isItemGroup(processedItem) {
        return isNotEmpty(processedItem.items);
    }
    getAriaSetSize() {
        return (this.items() ?? []).filter((processedItem) => this.isItemVisible(processedItem) && !this.getItemProp(processedItem, 'separator')).length;
    }
    getAriaPosInset(index) {
        return index - (this.items() ?? []).slice(0, index).filter((processedItem) => this.isItemVisible(processedItem) && this.getItemProp(processedItem, 'separator')).length + 1;
    }
    onItemClick(event, processedItem) {
        if (!this.isItemDisabled(processedItem)) {
            this.getItemProp(processedItem, 'command', { originalEvent: event, item: processedItem.item });
            this.itemToggle.emit({ processedItem, expanded: !this.isItemActive(processedItem) });
        }
    }
    onItemToggle(event) {
        this.itemToggle.emit(event);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PanelMenuSub, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: PanelMenuSub, isStandalone: true, selector: "ul[pPanelMenuSub]", inputs: { panelId: { classPropertyName: "panelId", publicName: "panelId", isSignal: true, isRequired: false, transformFunction: null }, focusedItemId: { classPropertyName: "focusedItemId", publicName: "focusedItemId", isSignal: true, isRequired: false, transformFunction: null }, items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, itemTemplate: { classPropertyName: "itemTemplate", publicName: "itemTemplate", isSignal: true, isRequired: false, transformFunction: null }, level: { classPropertyName: "level", publicName: "level", isSignal: true, isRequired: false, transformFunction: null }, activeItemPath: { classPropertyName: "activeItemPath", publicName: "activeItemPath", isSignal: true, isRequired: false, transformFunction: null }, root: { classPropertyName: "root", publicName: "root", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, transitionOptions: { classPropertyName: "transitionOptions", publicName: "transitionOptions", isSignal: true, isRequired: false, transformFunction: null }, parentExpanded: { classPropertyName: "parentExpanded", publicName: "parentExpanded", isSignal: true, isRequired: false, transformFunction: null }, motionOptions: { classPropertyName: "motionOptions", publicName: "motionOptions", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { itemToggle: "itemToggle", menuFocus: "menuFocus", menuBlur: "menuBlur", menuKeyDown: "menuKeyDown" }, host: { attributes: { "role": "tree" }, listeners: { "focusin": "menuFocus.emit($event)", "focusout": "menuBlur.emit($event)", "keydown": "menuKeyDown.emit($event)" }, properties: { "class": "root() ? cn(cx(\"rootList\"), cx(\"submenu\")) : cx(\"submenu\")", "tabindex": "-1", "attr.aria-activedescendant": "focusedItemId()", "attr.aria-hidden": "!parentExpanded()" } }, providers: [PanelMenuStyle, { provide: PANELMENUSUB_INSTANCE, useExisting: PanelMenuSub }, { provide: PARENT_INSTANCE, useExisting: PanelMenuSub }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        @for (processedItem of items(); track processedItem; let index = $index) {
            @if (processedItem.separator) {
                <li [class]="cn(cx('separator'), getItemProp(processedItem, 'styleClass'))" role="separator" [pBind]="ptm('separator')"></li>
            }
            @if (!processedItem.separator && isItemVisible(processedItem)) {
                <li
                    role="treeitem"
                    [attr.id]="getItemId(processedItem)"
                    [attr.aria-label]="getItemProp(processedItem, 'label')"
                    [attr.aria-expanded]="isItemGroup(processedItem) ? isItemActive(processedItem) : undefined"
                    [attr.aria-level]="level() + 1"
                    [attr.aria-setsize]="getAriaSetSize()"
                    [attr.aria-posinset]="getAriaPosInset(index)"
                    [class]="cn(cx('item', { processedItem }), getItemProp(processedItem, 'styleClass'))"
                    [ngStyle]="getItemProp(processedItem, 'style')"
                    [pTooltip]="getItemProp(processedItem, 'tooltip')"
                    [pTooltipUnstyled]="unstyled()"
                    [pBind]="getPTOptions(processedItem, index, 'item')"
                    [attr.data-p-disabled]="isItemDisabled(processedItem)"
                    [attr.data-p-focused]="isItemFocused(processedItem)"
                    [tooltipOptions]="getItemProp(processedItem, 'tooltipOptions')"
                >
                    <div [class]="cx('itemContent')" [pBind]="getPTOptions(processedItem, index, 'itemContent')" (click)="onItemClick($event, processedItem)">
                        @if (!itemTemplate()) {
                            @if (!getItemProp(processedItem, 'routerLink')) {
                                <a
                                    [attr.href]="getItemProp(processedItem, 'url')"
                                    [attr.title]="getItemProp(processedItem, 'title')"
                                    [attr.data-automationid]="getItemProp(processedItem, 'automationId')"
                                    [class]="cn(cx('itemLink'), getItemProp(processedItem, 'linkClass'))"
                                    [ngStyle]="getItemProp(processedItem, 'linkStyle')"
                                    [target]="getItemProp(processedItem, 'target')"
                                    [attr.tabindex]="!!parentExpanded() ? '0' : '-1'"
                                    [pBind]="getPTOptions(processedItem, index, 'itemLink')"
                                >
                                    @if (isItemGroup(processedItem)) {
                                        @if (!panelMenu.submenuIconTemplate() && !panelMenu._submenuIconTemplate) {
                                            @if (isItemActive(processedItem)) {
                                                <svg
                                                    data-p-icon="chevron-down"
                                                    [class]="cn(cx('submenuIcon'), getItemProp(processedItem, 'icon'))"
                                                    [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                                    [pBind]="getPTOptions(processedItem, index, 'submenuIcon')"
                                                />
                                            }
                                            @if (!isItemActive(processedItem)) {
                                                <svg
                                                    data-p-icon="chevron-right"
                                                    [class]="cn(cx('submenuIcon'), getItemProp(processedItem, 'icon'))"
                                                    [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                                    [pBind]="getPTOptions(processedItem, index, 'submenuIcon')"
                                                />
                                            }
                                        }
                                        <ng-template *ngTemplateOutlet="panelMenu.submenuIconTemplate() || panelMenu._submenuIconTemplate"></ng-template>
                                    }
                                    @if (processedItem.icon) {
                                        <span
                                            [class]="cn(cx('itemIcon'), getItemProp(processedItem, 'icon'), getItemProp(processedItem, 'iconClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                            [pBind]="getPTOptions(processedItem, index, 'itemIcon')"
                                        ></span>
                                    }
                                    @if (processedItem.item?.escape !== false) {
                                        <span [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))" [ngStyle]="getItemProp(processedItem, 'labelStyle')" [pBind]="getPTOptions(processedItem, index, 'itemLabel')">{{
                                            getItemProp(processedItem, 'label')
                                        }}</span>
                                    } @else {
                                        <span
                                            [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'labelStyle')"
                                            [innerHTML]="getItemProp(processedItem, 'label')"
                                            [pBind]="getPTOptions(processedItem, index, 'itemLabel')"
                                        ></span>
                                    }
                                </a>
                            }
                            @if (getItemProp(processedItem, 'routerLink')) {
                                <a
                                    [routerLink]="getItemProp(processedItem, 'routerLink')"
                                    [queryParams]="getItemProp(processedItem, 'queryParams')"
                                    [routerLinkActive]="'p-panelmenu-item-link-active'"
                                    [routerLinkActiveOptions]="getItemProp(processedItem, 'routerLinkActiveOptions') || { exact: false }"
                                    [class]="cn(cx('itemLink'), getItemProp(processedItem, 'linkClass'))"
                                    [ngStyle]="getItemProp(processedItem, 'linkStyle')"
                                    [target]="getItemProp(processedItem, 'target')"
                                    [attr.title]="getItemProp(processedItem, 'title')"
                                    [attr.data-automationid]="getItemProp(processedItem, 'automationId')"
                                    [fragment]="getItemProp(processedItem, 'fragment')"
                                    [queryParamsHandling]="getItemProp(processedItem, 'queryParamsHandling')"
                                    [preserveFragment]="getItemProp(processedItem, 'preserveFragment')"
                                    [skipLocationChange]="getItemProp(processedItem, 'skipLocationChange')"
                                    [replaceUrl]="getItemProp(processedItem, 'replaceUrl')"
                                    [state]="getItemProp(processedItem, 'state')"
                                    [attr.tabindex]="!!parentExpanded() ? '0' : '-1'"
                                    [pBind]="getPTOptions(processedItem, index, 'itemLink')"
                                >
                                    @if (isItemGroup(processedItem)) {
                                        @if (!panelMenu.submenuIconTemplate() && !panelMenu._submenuIconTemplate) {
                                            @if (isItemActive(processedItem)) {
                                                <svg
                                                    data-p-icon="chevron-down"
                                                    [class]="cn(cx('submenuIcon'), getItemProp(processedItem, 'icon'))"
                                                    [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                                    [pBind]="getPTOptions(processedItem, index, 'submenuIcon')"
                                                />
                                            }
                                            @if (!isItemActive(processedItem)) {
                                                <svg
                                                    data-p-icon="chevron-right"
                                                    [class]="cn(cx('submenuIcon'), getItemProp(processedItem, 'icon'))"
                                                    [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                                    [pBind]="getPTOptions(processedItem, index, 'submenuIcon')"
                                                />
                                            }
                                        }
                                        <ng-template *ngTemplateOutlet="panelMenu.submenuIconTemplate() && panelMenu._submenuIconTemplate"></ng-template>
                                    }
                                    @if (processedItem.icon) {
                                        <span
                                            [class]="cn(cx('itemIcon'), getItemProp(processedItem, 'icon'), getItemProp(processedItem, 'iconClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                            [pBind]="getPTOptions(processedItem, index, 'itemIcon')"
                                        ></span>
                                    }
                                    @if (getItemProp(processedItem, 'label')) {
                                        <span
                                            [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'labelStyle')"
                                            [innerHTML]="getItemProp(processedItem, 'label')"
                                            [pBind]="getPTOptions(processedItem, index, 'itemLabel')"
                                        ></span>
                                    }
                                    @if (processedItem.badge) {
                                        <span [class]="cn(cx('badge'), getItemProp(processedItem, 'badgeStyleClass'))">{{ processedItem.badge }}</span>
                                    }
                                </a>
                            }
                        }
                        @if (itemTemplate()) {
                            <ng-template *ngTemplateOutlet="itemTemplate(); context: { $implicit: processedItem.item }"></ng-template>
                        }
                    </div>
                    <div
                        [class]="cx('contentContainer', { processedItem: processedItem })"
                        pMotionName="p-collapsible"
                        [pMotion]="isItemVisible(processedItem) && isItemGroup(processedItem) && isItemExpanded(processedItem)"
                        [pMotionOptions]="motionOptions()"
                    >
                        <div [class]="cx('contentWrapper')" [pBind]="ptm('contentWrapper')">
                            <ul
                                pPanelMenuSub
                                [id]="getItemId(processedItem) + '_list'"
                                [panelId]="panelId()"
                                [items]="processedItem?.items"
                                [itemTemplate]="itemTemplate()"
                                [transitionOptions]="transitionOptions()"
                                [focusedItemId]="focusedItemId()"
                                [activeItemPath]="activeItemPath()"
                                [level]="level() + 1"
                                [pt]="pt()"
                                [unstyled]="unstyled()"
                                [parentExpanded]="!!parentExpanded() && isItemExpanded(processedItem)"
                                (itemToggle)="onItemToggle($event)"
                                [motionOptions]="motionOptions()"
                            ></ul>
                        </div>
                    </div>
                </li>
            }
        }
    `, isInline: true, dependencies: [{ kind: "component", type: PanelMenuSub, selector: "ul[pPanelMenuSub]", inputs: ["panelId", "focusedItemId", "items", "itemTemplate", "level", "activeItemPath", "root", "tabindex", "transitionOptions", "parentExpanded", "motionOptions"], outputs: ["itemToggle", "menuFocus", "menuBlur", "menuKeyDown"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i3.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "browserUrl", "routerLink"] }, { kind: "directive", type: i3.RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "ngmodule", type: TooltipModule }, { kind: "directive", type: i4.Tooltip, selector: "[pTooltip]", inputs: ["tooltipPosition", "tooltipEvent", "positionStyle", "tooltipStyleClass", "tooltipZIndex", "escape", "showDelay", "hideDelay", "life", "positionTop", "positionLeft", "autoHide", "fitContent", "hideOnEscape", "showOnEllipsis", "pTooltip", "tooltipDisabled", "tooltipOptions", "appendTo", "ptTooltip", "pTooltipPT", "pTooltipUnstyled"] }, { kind: "directive", type: i1.Bind, selector: "[pBind]", inputs: ["pBind"] }, { kind: "component", type: ChevronDownIcon, selector: "[data-p-icon=\"chevron-down\"]" }, { kind: "component", type: ChevronRightIcon, selector: "[data-p-icon=\"chevron-right\"]" }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: BindModule }, { kind: "ngmodule", type: MotionModule }, { kind: "directive", type: i5.MotionDirective, selector: "[pMotion]", inputs: ["pMotion", "pMotionName", "pMotionType", "pMotionSafe", "pMotionDisabled", "pMotionAppear", "pMotionEnter", "pMotionLeave", "pMotionDuration", "pMotionHideStrategy", "pMotionEnterFromClass", "pMotionEnterToClass", "pMotionEnterActiveClass", "pMotionLeaveFromClass", "pMotionLeaveToClass", "pMotionLeaveActiveClass", "pMotionOptions"], outputs: ["pMotionOnBeforeEnter", "pMotionOnEnter", "pMotionOnAfterEnter", "pMotionOnEnterCancelled", "pMotionOnBeforeLeave", "pMotionOnLeave", "pMotionOnAfterLeave", "pMotionOnLeaveCancelled"] }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PanelMenuSub, decorators: [{
            type: Component,
            args: [{
                    selector: 'ul[pPanelMenuSub]',
                    imports: [CommonModule, RouterModule, TooltipModule, ChevronDownIcon, ChevronRightIcon, SharedModule, BindModule, MotionModule],
                    standalone: true,
                    template: `
        @for (processedItem of items(); track processedItem; let index = $index) {
            @if (processedItem.separator) {
                <li [class]="cn(cx('separator'), getItemProp(processedItem, 'styleClass'))" role="separator" [pBind]="ptm('separator')"></li>
            }
            @if (!processedItem.separator && isItemVisible(processedItem)) {
                <li
                    role="treeitem"
                    [attr.id]="getItemId(processedItem)"
                    [attr.aria-label]="getItemProp(processedItem, 'label')"
                    [attr.aria-expanded]="isItemGroup(processedItem) ? isItemActive(processedItem) : undefined"
                    [attr.aria-level]="level() + 1"
                    [attr.aria-setsize]="getAriaSetSize()"
                    [attr.aria-posinset]="getAriaPosInset(index)"
                    [class]="cn(cx('item', { processedItem }), getItemProp(processedItem, 'styleClass'))"
                    [ngStyle]="getItemProp(processedItem, 'style')"
                    [pTooltip]="getItemProp(processedItem, 'tooltip')"
                    [pTooltipUnstyled]="unstyled()"
                    [pBind]="getPTOptions(processedItem, index, 'item')"
                    [attr.data-p-disabled]="isItemDisabled(processedItem)"
                    [attr.data-p-focused]="isItemFocused(processedItem)"
                    [tooltipOptions]="getItemProp(processedItem, 'tooltipOptions')"
                >
                    <div [class]="cx('itemContent')" [pBind]="getPTOptions(processedItem, index, 'itemContent')" (click)="onItemClick($event, processedItem)">
                        @if (!itemTemplate()) {
                            @if (!getItemProp(processedItem, 'routerLink')) {
                                <a
                                    [attr.href]="getItemProp(processedItem, 'url')"
                                    [attr.title]="getItemProp(processedItem, 'title')"
                                    [attr.data-automationid]="getItemProp(processedItem, 'automationId')"
                                    [class]="cn(cx('itemLink'), getItemProp(processedItem, 'linkClass'))"
                                    [ngStyle]="getItemProp(processedItem, 'linkStyle')"
                                    [target]="getItemProp(processedItem, 'target')"
                                    [attr.tabindex]="!!parentExpanded() ? '0' : '-1'"
                                    [pBind]="getPTOptions(processedItem, index, 'itemLink')"
                                >
                                    @if (isItemGroup(processedItem)) {
                                        @if (!panelMenu.submenuIconTemplate() && !panelMenu._submenuIconTemplate) {
                                            @if (isItemActive(processedItem)) {
                                                <svg
                                                    data-p-icon="chevron-down"
                                                    [class]="cn(cx('submenuIcon'), getItemProp(processedItem, 'icon'))"
                                                    [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                                    [pBind]="getPTOptions(processedItem, index, 'submenuIcon')"
                                                />
                                            }
                                            @if (!isItemActive(processedItem)) {
                                                <svg
                                                    data-p-icon="chevron-right"
                                                    [class]="cn(cx('submenuIcon'), getItemProp(processedItem, 'icon'))"
                                                    [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                                    [pBind]="getPTOptions(processedItem, index, 'submenuIcon')"
                                                />
                                            }
                                        }
                                        <ng-template *ngTemplateOutlet="panelMenu.submenuIconTemplate() || panelMenu._submenuIconTemplate"></ng-template>
                                    }
                                    @if (processedItem.icon) {
                                        <span
                                            [class]="cn(cx('itemIcon'), getItemProp(processedItem, 'icon'), getItemProp(processedItem, 'iconClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                            [pBind]="getPTOptions(processedItem, index, 'itemIcon')"
                                        ></span>
                                    }
                                    @if (processedItem.item?.escape !== false) {
                                        <span [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))" [ngStyle]="getItemProp(processedItem, 'labelStyle')" [pBind]="getPTOptions(processedItem, index, 'itemLabel')">{{
                                            getItemProp(processedItem, 'label')
                                        }}</span>
                                    } @else {
                                        <span
                                            [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'labelStyle')"
                                            [innerHTML]="getItemProp(processedItem, 'label')"
                                            [pBind]="getPTOptions(processedItem, index, 'itemLabel')"
                                        ></span>
                                    }
                                </a>
                            }
                            @if (getItemProp(processedItem, 'routerLink')) {
                                <a
                                    [routerLink]="getItemProp(processedItem, 'routerLink')"
                                    [queryParams]="getItemProp(processedItem, 'queryParams')"
                                    [routerLinkActive]="'p-panelmenu-item-link-active'"
                                    [routerLinkActiveOptions]="getItemProp(processedItem, 'routerLinkActiveOptions') || { exact: false }"
                                    [class]="cn(cx('itemLink'), getItemProp(processedItem, 'linkClass'))"
                                    [ngStyle]="getItemProp(processedItem, 'linkStyle')"
                                    [target]="getItemProp(processedItem, 'target')"
                                    [attr.title]="getItemProp(processedItem, 'title')"
                                    [attr.data-automationid]="getItemProp(processedItem, 'automationId')"
                                    [fragment]="getItemProp(processedItem, 'fragment')"
                                    [queryParamsHandling]="getItemProp(processedItem, 'queryParamsHandling')"
                                    [preserveFragment]="getItemProp(processedItem, 'preserveFragment')"
                                    [skipLocationChange]="getItemProp(processedItem, 'skipLocationChange')"
                                    [replaceUrl]="getItemProp(processedItem, 'replaceUrl')"
                                    [state]="getItemProp(processedItem, 'state')"
                                    [attr.tabindex]="!!parentExpanded() ? '0' : '-1'"
                                    [pBind]="getPTOptions(processedItem, index, 'itemLink')"
                                >
                                    @if (isItemGroup(processedItem)) {
                                        @if (!panelMenu.submenuIconTemplate() && !panelMenu._submenuIconTemplate) {
                                            @if (isItemActive(processedItem)) {
                                                <svg
                                                    data-p-icon="chevron-down"
                                                    [class]="cn(cx('submenuIcon'), getItemProp(processedItem, 'icon'))"
                                                    [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                                    [pBind]="getPTOptions(processedItem, index, 'submenuIcon')"
                                                />
                                            }
                                            @if (!isItemActive(processedItem)) {
                                                <svg
                                                    data-p-icon="chevron-right"
                                                    [class]="cn(cx('submenuIcon'), getItemProp(processedItem, 'icon'))"
                                                    [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                                    [pBind]="getPTOptions(processedItem, index, 'submenuIcon')"
                                                />
                                            }
                                        }
                                        <ng-template *ngTemplateOutlet="panelMenu.submenuIconTemplate() && panelMenu._submenuIconTemplate"></ng-template>
                                    }
                                    @if (processedItem.icon) {
                                        <span
                                            [class]="cn(cx('itemIcon'), getItemProp(processedItem, 'icon'), getItemProp(processedItem, 'iconClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                            [pBind]="getPTOptions(processedItem, index, 'itemIcon')"
                                        ></span>
                                    }
                                    @if (getItemProp(processedItem, 'label')) {
                                        <span
                                            [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'labelStyle')"
                                            [innerHTML]="getItemProp(processedItem, 'label')"
                                            [pBind]="getPTOptions(processedItem, index, 'itemLabel')"
                                        ></span>
                                    }
                                    @if (processedItem.badge) {
                                        <span [class]="cn(cx('badge'), getItemProp(processedItem, 'badgeStyleClass'))">{{ processedItem.badge }}</span>
                                    }
                                </a>
                            }
                        }
                        @if (itemTemplate()) {
                            <ng-template *ngTemplateOutlet="itemTemplate(); context: { $implicit: processedItem.item }"></ng-template>
                        }
                    </div>
                    <div
                        [class]="cx('contentContainer', { processedItem: processedItem })"
                        pMotionName="p-collapsible"
                        [pMotion]="isItemVisible(processedItem) && isItemGroup(processedItem) && isItemExpanded(processedItem)"
                        [pMotionOptions]="motionOptions()"
                    >
                        <div [class]="cx('contentWrapper')" [pBind]="ptm('contentWrapper')">
                            <ul
                                pPanelMenuSub
                                [id]="getItemId(processedItem) + '_list'"
                                [panelId]="panelId()"
                                [items]="processedItem?.items"
                                [itemTemplate]="itemTemplate()"
                                [transitionOptions]="transitionOptions()"
                                [focusedItemId]="focusedItemId()"
                                [activeItemPath]="activeItemPath()"
                                [level]="level() + 1"
                                [pt]="pt()"
                                [unstyled]="unstyled()"
                                [parentExpanded]="!!parentExpanded() && isItemExpanded(processedItem)"
                                (itemToggle)="onItemToggle($event)"
                                [motionOptions]="motionOptions()"
                            ></ul>
                        </div>
                    </div>
                </li>
            }
        }
    `,
                    encapsulation: ViewEncapsulation.None,
                    providers: [PanelMenuStyle, { provide: PANELMENUSUB_INSTANCE, useExisting: PanelMenuSub }, { provide: PARENT_INSTANCE, useExisting: PanelMenuSub }],
                    host: {
                        '[class]': 'root() ? cn(cx("rootList"), cx("submenu")) : cx("submenu")',
                        role: 'tree',
                        '[tabindex]': '-1',
                        '[attr.aria-activedescendant]': 'focusedItemId()',
                        '[attr.aria-hidden]': '!parentExpanded()',
                        '(focusin)': 'menuFocus.emit($event)',
                        '(focusout)': 'menuBlur.emit($event)',
                        '(keydown)': 'menuKeyDown.emit($event)'
                    },
                    hostDirectives: [Bind]
                }]
        }], propDecorators: { panelId: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelId", required: false }] }], focusedItemId: [{ type: i0.Input, args: [{ isSignal: true, alias: "focusedItemId", required: false }] }], items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }], itemTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemTemplate", required: false }] }], level: [{ type: i0.Input, args: [{ isSignal: true, alias: "level", required: false }] }], activeItemPath: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeItemPath", required: false }] }], root: [{ type: i0.Input, args: [{ isSignal: true, alias: "root", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], transitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "transitionOptions", required: false }] }], parentExpanded: [{ type: i0.Input, args: [{ isSignal: true, alias: "parentExpanded", required: false }] }], motionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "motionOptions", required: false }] }], itemToggle: [{ type: i0.Output, args: ["itemToggle"] }], menuFocus: [{ type: i0.Output, args: ["menuFocus"] }], menuBlur: [{ type: i0.Output, args: ["menuBlur"] }], menuKeyDown: [{ type: i0.Output, args: ["menuKeyDown"] }] } });
class PanelMenuList extends BaseComponent {
    panelId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "panelId" }] : /* istanbul ignore next */ []));
    id = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "id" }] : /* istanbul ignore next */ []));
    items = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "items" }] : /* istanbul ignore next */ []));
    itemTemplate = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "itemTemplate" }] : /* istanbul ignore next */ []));
    parentExpanded = input(undefined, { ...(ngDevMode ? { debugName: "parentExpanded" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    expanded = input(undefined, { ...(ngDevMode ? { debugName: "expanded" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    transitionOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "transitionOptions" }] : /* istanbul ignore next */ []));
    root = input(undefined, { ...(ngDevMode ? { debugName: "root" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    tabindex = input(undefined, { ...(ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    activeItem = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "activeItem" }] : /* istanbul ignore next */ []));
    motionOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "motionOptions" }] : /* istanbul ignore next */ []));
    itemToggle = output();
    headerFocus = output();
    subMenuViewChild = viewChild.required('submenu', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "subMenuViewChild" }] : /* istanbul ignore next */ []));
    searchTimeout;
    searchValue;
    focused;
    focusedItem = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusedItem" }] : /* istanbul ignore next */ []));
    activeItemPath = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeItemPath" }] : /* istanbul ignore next */ []));
    processedItems = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "processedItems" }] : /* istanbul ignore next */ []));
    visibleItems = computed(() => {
        const processedItems = this.processedItems();
        return this.flatItems(processedItems);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visibleItems" }] : /* istanbul ignore next */ []));
    get focusedItemId() {
        const focusedItem = this.focusedItem();
        return focusedItem && focusedItem.item?.id ? focusedItem.item.id : isNotEmpty(this.focusedItem()) ? `${this.panelId()}_${this.focusedItem().key}` : undefined;
    }
    constructor() {
        super();
        effect(() => {
            this.processedItems.set(this.createProcessedItems(this.items() || []));
        });
    }
    getItemProp(processedItem, name) {
        return processedItem && processedItem.item ? resolve(processedItem.item[name]) : undefined;
    }
    getItemLabel(processedItem) {
        return this.getItemProp(processedItem, 'label');
    }
    isItemVisible(processedItem) {
        return this.getItemProp(processedItem, 'visible') !== false;
    }
    isItemDisabled(processedItem) {
        return this.getItemProp(processedItem, 'disabled');
    }
    isItemActive(processedItem) {
        return this.activeItemPath().some((path) => path.key === processedItem.parentKey);
    }
    isItemGroup(processedItem) {
        return isNotEmpty(processedItem.items);
    }
    isElementInPanel(event, element) {
        const panel = event.currentTarget.closest('[data-pc-name="panelmenu"]');
        return panel && panel.contains(element);
    }
    isItemMatched(processedItem) {
        return this.isValidItem(processedItem) && this.getItemLabel(processedItem).toLocaleLowerCase().startsWith(this.searchValue.toLocaleLowerCase());
    }
    isVisibleItem(processedItem) {
        return !!processedItem && (processedItem.level === 0 || this.isItemActive(processedItem)) && this.isItemVisible(processedItem);
    }
    isValidItem(processedItem) {
        return !!processedItem && !this.isItemDisabled(processedItem) && !processedItem.separator;
    }
    findFirstItem() {
        return this.visibleItems().find((processedItem) => this.isValidItem(processedItem));
    }
    findLastItem() {
        return findLast(this.visibleItems(), (processedItem) => this.isValidItem(processedItem));
    }
    findItemByEventTarget(target) {
        let parentNode = target;
        while (parentNode && parentNode.tagName?.toLowerCase() !== 'li') {
            parentNode = parentNode?.parentNode;
        }
        return parentNode?.id && this.visibleItems().find((processedItem) => this.isValidItem(processedItem) && `${this.panelId()}_${processedItem.key}` === parentNode.id);
    }
    createProcessedItems(items, level = 0, parent = {}, parentKey = '') {
        const processedItems = [];
        items &&
            items.forEach((item, index) => {
                const key = (parentKey !== '' ? parentKey + '_' : '') + index;
                const newItem = {
                    icon: item.icon,
                    expanded: item.expanded,
                    separator: item.separator,
                    item,
                    index,
                    level,
                    key,
                    parent,
                    parentKey
                };
                newItem['items'] = this.createProcessedItems(item.items, level + 1, newItem, key);
                processedItems.push(newItem);
            });
        return processedItems;
    }
    findProcessedItemByItemKey(key, processedItems, level = 0) {
        processedItems = processedItems || this.processedItems();
        if (processedItems && processedItems.length) {
            for (let i = 0; i < processedItems.length; i++) {
                const processedItem = processedItems[i];
                if (this.getItemProp(processedItem, 'key') === key)
                    return processedItem;
                const matchedItem = this.findProcessedItemByItemKey(key, processedItem.items, level + 1);
                if (matchedItem)
                    return matchedItem;
            }
        }
    }
    flatItems(processedItems, processedFlattenItems = []) {
        processedItems &&
            processedItems.forEach((processedItem) => {
                if (this.isVisibleItem(processedItem)) {
                    processedFlattenItems.push(processedItem);
                    this.flatItems(processedItem.items, processedFlattenItems);
                }
            });
        return processedFlattenItems;
    }
    changeFocusedItem(event) {
        const { originalEvent, processedItem, focusOnNext, selfCheck, allowHeaderFocus = true } = event;
        if (isNotEmpty(this.focusedItem()) && this.focusedItem().key !== processedItem.key) {
            this.focusedItem.set(processedItem);
            this.scrollInView();
        }
        else if (allowHeaderFocus) {
            this.headerFocus.emit({ originalEvent, focusOnNext, selfCheck });
        }
    }
    scrollInView() {
        const element = findSingle(this.subMenuViewChild().listViewChild.nativeElement, `li[id="${`${this.focusedItemId}`}"]`);
        if (element) {
            element.scrollIntoView && element.scrollIntoView({ block: 'nearest', inline: 'nearest' });
        }
    }
    onFocus(event) {
        if (!this.focused) {
            this.focused = true;
            const focusedItem = this.focusedItem() || (this.isElementInPanel(event, event.relatedTarget) ? this.findItemByEventTarget(event.target) || this.findFirstItem() : this.findLastItem());
            if (event.relatedTarget !== null)
                this.focusedItem.set(focusedItem);
        }
    }
    onBlur(event) {
        const target = event.relatedTarget;
        if (this.focused && !this.el.nativeElement.contains(target)) {
            this.focused = false;
            this.focusedItem.set(null);
            this.searchValue = '';
        }
    }
    onItemToggle(event) {
        const { processedItem, expanded } = event;
        // Update the original item object's 'expanded' property
        if (processedItem.item) {
            processedItem.item.expanded = expanded;
        }
        // Update the expanded property in the existing processedItem
        processedItem.expanded = expanded;
        // Trigger signal update without recreating the entire tree
        this.processedItems.update((items) => [...items]);
        // Update activeItemPath
        const activeItemPath = this.activeItemPath().filter((p) => p.parentKey !== processedItem.parentKey);
        if (expanded) {
            activeItemPath.push(processedItem);
        }
        this.activeItemPath.set(activeItemPath);
        // Update focusedItem
        this.focusedItem.set(processedItem);
    }
    onKeyDown(event) {
        const metaKey = event.metaKey || event.ctrlKey;
        switch (event.code) {
            case 'ArrowDown':
                this.onArrowDownKey(event);
                break;
            case 'ArrowUp':
                this.onArrowUpKey(event);
                break;
            case 'ArrowLeft':
                this.onArrowLeftKey(event);
                break;
            case 'ArrowRight':
                this.onArrowRightKey(event);
                break;
            case 'Home':
                this.onHomeKey(event);
                break;
            case 'End':
                this.onEndKey(event);
                break;
            case 'Space':
                this.onSpaceKey(event);
                break;
            case 'Enter':
                this.onEnterKey(event);
                break;
            case 'Escape':
            case 'Tab':
            case 'PageDown':
            case 'PageUp':
            case 'Backspace':
            case 'ShiftLeft':
            case 'ShiftRight':
                //NOOP
                break;
            default:
                if (!metaKey && isPrintableCharacter(event.key)) {
                    this.searchItems(event, event.key);
                }
                break;
        }
    }
    onArrowDownKey(event) {
        const processedItem = isNotEmpty(this.focusedItem()) ? this.findNextItem(this.focusedItem()) : this.findFirstItem();
        this.changeFocusedItem({ originalEvent: event, processedItem, focusOnNext: true });
        event.preventDefault();
    }
    onArrowUpKey(event) {
        const processedItem = isNotEmpty(this.focusedItem()) ? this.findPrevItem(this.focusedItem()) : this.findLastItem();
        this.changeFocusedItem({ originalEvent: event, processedItem, selfCheck: true });
        event.preventDefault();
    }
    onArrowLeftKey(event) {
        if (isNotEmpty(this.focusedItem())) {
            const matched = this.activeItemPath().some((p) => p.key === this.focusedItem().key);
            if (matched) {
                const activeItemPath = this.activeItemPath().filter((p) => p.key !== this.focusedItem().key);
                this.activeItemPath.set(activeItemPath);
            }
            else {
                const focusedItem = isNotEmpty(this.focusedItem().parent) ? this.focusedItem().parent : this.focusedItem();
                this.focusedItem.set(focusedItem);
            }
            event.preventDefault();
        }
    }
    onArrowRightKey(event) {
        if (isNotEmpty(this.focusedItem())) {
            const grouped = this.isItemGroup(this.focusedItem());
            if (grouped) {
                const matched = this.activeItemPath().some((p) => p.key === this.focusedItem().key);
                if (matched) {
                    this.onArrowDownKey(event);
                }
                else {
                    const activeItemPath = this.activeItemPath().filter((p) => p.parentKey !== this.focusedItem().parentKey);
                    activeItemPath.push(this.focusedItem());
                    this.activeItemPath.set(activeItemPath);
                }
            }
            event.preventDefault();
        }
    }
    onHomeKey(event) {
        this.changeFocusedItem({ originalEvent: event, processedItem: this.findFirstItem(), allowHeaderFocus: false });
        event.preventDefault();
    }
    onEndKey(event) {
        this.changeFocusedItem({ originalEvent: event, processedItem: this.findLastItem(), focusOnNext: true, allowHeaderFocus: false });
        event.preventDefault();
    }
    onEnterKey(event) {
        if (isNotEmpty(this.focusedItem())) {
            const element = findSingle(this.subMenuViewChild().listViewChild.nativeElement, `li[id="${`${this.focusedItemId}`}"]`);
            const anchorElement = element && (findSingle(element, 'a') || findSingle(element, 'button'));
            anchorElement ? anchorElement.click() : element && element.click();
        }
        event.preventDefault();
    }
    onSpaceKey(event) {
        this.onEnterKey(event);
    }
    findNextItem(processedItem) {
        const index = this.visibleItems().findIndex((item) => item.key === processedItem.key);
        const matchedItem = index < this.visibleItems().length - 1
            ? this.visibleItems()
                .slice(index + 1)
                .find((pItem) => this.isValidItem(pItem))
            : undefined;
        return matchedItem || processedItem;
    }
    findPrevItem(processedItem) {
        const index = this.visibleItems().findIndex((item) => item.key === processedItem.key);
        const matchedItem = index > 0 ? findLast(this.visibleItems().slice(0, index), (pItem) => this.isValidItem(pItem)) : undefined;
        return matchedItem || processedItem;
    }
    searchItems(event, char) {
        this.searchValue = (this.searchValue || '') + char;
        let matchedItem = null;
        let matched = false;
        if (isNotEmpty(this.focusedItem())) {
            const focusedItemIndex = this.visibleItems().findIndex((processedItem) => processedItem.key === this.focusedItem().key);
            matchedItem =
                this.visibleItems()
                    .slice(focusedItemIndex)
                    .find((processedItem) => this.isItemMatched(processedItem)) || null;
            matchedItem = isEmpty(matchedItem)
                ? this.visibleItems()
                    .slice(0, focusedItemIndex)
                    .find((processedItem) => this.isItemMatched(processedItem)) || null
                : matchedItem;
        }
        else {
            matchedItem = this.visibleItems().find((processedItem) => this.isItemMatched(processedItem)) || null;
        }
        if (isNotEmpty(matchedItem)) {
            matched = true;
        }
        if (isEmpty(matchedItem) && isEmpty(this.focusedItem())) {
            matchedItem = this.findFirstItem() || null;
        }
        if (isNotEmpty(matchedItem)) {
            this.changeFocusedItem({
                originalEvent: event,
                processedItem: matchedItem,
                allowHeaderFocus: false
            });
        }
        if (this.searchTimeout) {
            clearTimeout(this.searchTimeout);
        }
        this.searchTimeout = setTimeout(() => {
            this.searchValue = '';
            this.searchTimeout = null;
        }, 500);
        return matched;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PanelMenuList, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "22.1.2", type: PanelMenuList, isStandalone: true, selector: "ul[pPanelMenuList]", inputs: { panelId: { classPropertyName: "panelId", publicName: "panelId", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, itemTemplate: { classPropertyName: "itemTemplate", publicName: "itemTemplate", isSignal: true, isRequired: false, transformFunction: null }, parentExpanded: { classPropertyName: "parentExpanded", publicName: "parentExpanded", isSignal: true, isRequired: false, transformFunction: null }, expanded: { classPropertyName: "expanded", publicName: "expanded", isSignal: true, isRequired: false, transformFunction: null }, transitionOptions: { classPropertyName: "transitionOptions", publicName: "transitionOptions", isSignal: true, isRequired: false, transformFunction: null }, root: { classPropertyName: "root", publicName: "root", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, activeItem: { classPropertyName: "activeItem", publicName: "activeItem", isSignal: true, isRequired: false, transformFunction: null }, motionOptions: { classPropertyName: "motionOptions", publicName: "motionOptions", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { itemToggle: "itemToggle", headerFocus: "headerFocus" }, viewQueries: [{ propertyName: "subMenuViewChild", first: true, predicate: ["submenu"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: `
        <ul
            pPanelMenuSub
            #submenu
            [root]="root()"
            [id]="panelId() + '_list'"
            [panelId]="panelId()"
            [tabindex]="tabindex()"
            [itemTemplate]="itemTemplate()"
            [focusedItemId]="focused ? focusedItemId : undefined"
            [activeItemPath]="activeItemPath()"
            [transitionOptions]="transitionOptions()"
            [items]="processedItems()"
            [parentExpanded]="parentExpanded()"
            (itemToggle)="onItemToggle($event)"
            (keydown)="onKeyDown($event)"
            (menuFocus)="onFocus($event)"
            (menuBlur)="onBlur($event)"
            [pt]="pt()"
            [unstyled]="unstyled()"
            [motionOptions]="motionOptions()"
        ></ul>
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: PanelMenuSub, selector: "ul[pPanelMenuSub]", inputs: ["panelId", "focusedItemId", "items", "itemTemplate", "level", "activeItemPath", "root", "tabindex", "transitionOptions", "parentExpanded", "motionOptions"], outputs: ["itemToggle", "menuFocus", "menuBlur", "menuKeyDown"] }, { kind: "ngmodule", type: RouterModule }, { kind: "ngmodule", type: TooltipModule }, { kind: "ngmodule", type: SharedModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PanelMenuList, decorators: [{
            type: Component,
            args: [{
                    selector: 'ul[pPanelMenuList]',
                    imports: [CommonModule, PanelMenuSub, RouterModule, TooltipModule, SharedModule],
                    standalone: true,
                    template: `
        <ul
            pPanelMenuSub
            #submenu
            [root]="root()"
            [id]="panelId() + '_list'"
            [panelId]="panelId()"
            [tabindex]="tabindex()"
            [itemTemplate]="itemTemplate()"
            [focusedItemId]="focused ? focusedItemId : undefined"
            [activeItemPath]="activeItemPath()"
            [transitionOptions]="transitionOptions()"
            [items]="processedItems()"
            [parentExpanded]="parentExpanded()"
            (itemToggle)="onItemToggle($event)"
            (keydown)="onKeyDown($event)"
            (menuFocus)="onFocus($event)"
            (menuBlur)="onBlur($event)"
            [pt]="pt()"
            [unstyled]="unstyled()"
            [motionOptions]="motionOptions()"
        ></ul>
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None
                }]
        }], ctorParameters: () => [], propDecorators: { panelId: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelId", required: false }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }], itemTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemTemplate", required: false }] }], parentExpanded: [{ type: i0.Input, args: [{ isSignal: true, alias: "parentExpanded", required: false }] }], expanded: [{ type: i0.Input, args: [{ isSignal: true, alias: "expanded", required: false }] }], transitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "transitionOptions", required: false }] }], root: [{ type: i0.Input, args: [{ isSignal: true, alias: "root", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], activeItem: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeItem", required: false }] }], motionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "motionOptions", required: false }] }], itemToggle: [{ type: i0.Output, args: ["itemToggle"] }], headerFocus: [{ type: i0.Output, args: ["headerFocus"] }], subMenuViewChild: [{ type: i0.ViewChild, args: ['submenu', { isSignal: true }] }] } });
/**
 * PanelMenu is a hybrid of Accordion and Tree components.
 * @group Components
 */
class PanelMenu extends BaseComponent {
    componentName = 'PanelMenu';
    /**
     * An array of menuitems.
     * @group Props
     */
    model = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "model" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Whether multiple tabs can be activated at the same time or not.
     * @group Props
     */
    multiple = input(false, { ...(ngDevMode ? { debugName: "multiple" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Transition options of the animation.
     * @group Props
     * @deprecated since v21.0.0, use `motionOptions` instead.
     */
    transitionOptions = input('400ms cubic-bezier(0.86, 0, 0.07, 1)', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "transitionOptions" }] : /* istanbul ignore next */ []));
    /**
     * The motion options.
     * @group Props
     */
    motionOptions = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "motionOptions" }] : /* istanbul ignore next */ []));
    computedMotionOptions = computed(() => ({
        ...this.ptm('motion'),
        ...this.motionOptions()
    }), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "computedMotionOptions" }] : /* istanbul ignore next */ []));
    /**
     * Current id state as a string.
     * @group Props
     */
    id = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "id" }] : /* istanbul ignore next */ []));
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex = input(0, { ...(ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    containerViewChild = viewChild('container', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "containerViewChild" }] : /* istanbul ignore next */ []));
    /**
     * Template option of submenu icon.
     * @group Templates
     */
    submenuIconTemplate = contentChild('submenuicon', { ...(ngDevMode ? { debugName: "submenuIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Template option of header icon.
     * @group Templates
     */
    headerIconTemplate = contentChild('headericon', { ...(ngDevMode ? { debugName: "headerIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Template option of item.
     * @param {PanelMenuItemTemplateContext} context - item context.
     * @see {@link PanelMenuItemTemplateContext}
     * @group Templates
     */
    itemTemplate = contentChild('item', { ...(ngDevMode ? { debugName: "itemTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    _submenuIconTemplate;
    _headerIconTemplate;
    _itemTemplate;
    activeItem = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeItem" }] : /* istanbul ignore next */ []));
    _componentStyle = inject(PanelMenuStyle);
    bindDirectiveInstance = inject(Bind, { self: true });
    $pcPanelMenu = inject(PANELMENU_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    _generatedId;
    get resolvedId() {
        return this.id() || (this._generatedId ??= uuid('pn_id_'));
    }
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    getPTOptions(key, item, index) {
        return this.ptm(key, {
            context: {
                item: item,
                index,
                active: this.isItemActive(item)
            }
        });
    }
    onAfterContentInit() {
        this.templates()?.forEach((item) => {
            switch (item.getType()) {
                case 'submenuicon':
                    this._submenuIconTemplate = item.template;
                    break;
                case 'headericon':
                    this._headerIconTemplate = item.template;
                    break;
                case 'item':
                    this._itemTemplate = item.template;
                    break;
                default:
                    this._itemTemplate = item.template;
                    break;
            }
        });
    }
    /**
     * Collapses open panels.
     * @group Method
     */
    collapseAll() {
        for (let item of this.model()) {
            if (item.expanded) {
                item.expanded = false;
            }
        }
        this.cd.detectChanges();
    }
    changeActiveItem(event, item, index, selfActive = false) {
        if (!this.isItemDisabled(item)) {
            const activeItem = selfActive ? item : this.activeItem && equals(item, this.activeItem) ? null : item;
            this.activeItem.set(activeItem);
        }
    }
    getItemProp(item, name) {
        return item ? resolve(item[name]) : undefined;
    }
    getItemLabel(item) {
        return this.getItemProp(item, 'label');
    }
    isItemActive(item) {
        return item.expanded;
    }
    isItemVisible(item) {
        return this.getItemProp(item, 'visible') !== false;
    }
    isItemDisabled(item) {
        return this.getItemProp(item, 'disabled');
    }
    isItemGroup(item) {
        return isNotEmpty(item.items);
    }
    getPanelId(index, item) {
        return item && item.id ? item.id : `${this.resolvedId}_${index}`;
    }
    getHeaderId(item, index) {
        return item.id ? item.id + '_header' : `${this.getPanelId(index)}_header`;
    }
    getContentId(item, index) {
        return item.id ? item.id + '_content' : `${this.getPanelId(index)}_content`;
    }
    updateFocusedHeader(event) {
        const { originalEvent, focusOnNext, selfCheck } = event;
        const panelElement = originalEvent.currentTarget.closest('[data-pc-section="panel"]');
        const header = selfCheck ? findSingle(panelElement, '[data-pc-section="header"]') : focusOnNext ? this.findNextHeader(panelElement) : this.findPrevHeader(panelElement);
        header ? this.changeFocusedHeader(originalEvent, header) : focusOnNext ? this.onHeaderHomeKey(originalEvent) : this.onHeaderEndKey(originalEvent);
    }
    changeFocusedHeader(event, element) {
        element && focus(element);
    }
    findNextHeader(panelElement, selfCheck = false) {
        const nextPanelElement = selfCheck ? panelElement : panelElement.nextElementSibling;
        const headerElement = findSingle(nextPanelElement, '[data-pc-section="header"]');
        return headerElement ? (getAttribute(headerElement, 'data-p-disabled') ? this.findNextHeader(headerElement.parentElement) : headerElement) : null;
    }
    findPrevHeader(panelElement, selfCheck = false) {
        const prevPanelElement = selfCheck ? panelElement : panelElement.previousElementSibling;
        const headerElement = findSingle(prevPanelElement, '[data-pc-section="header"]');
        return headerElement ? (getAttribute(headerElement, 'data-p-disabled') ? this.findPrevHeader(headerElement.parentElement) : headerElement) : null;
    }
    findFirstHeader() {
        const containerViewChild = this.containerViewChild();
        return containerViewChild?.nativeElement ? this.findNextHeader(containerViewChild.nativeElement.firstElementChild, true) : null;
    }
    findLastHeader() {
        const containerViewChild = this.containerViewChild();
        return containerViewChild?.nativeElement ? this.findPrevHeader(containerViewChild.nativeElement.lastElementChild, true) : null;
    }
    onHeaderClick(event, item, index) {
        if (this.isItemDisabled(item)) {
            event.preventDefault();
            return;
        }
        if (item.command) {
            item.command({ originalEvent: event, item });
        }
        if (!this.multiple()) {
            for (let modelItem of this.model()) {
                if (item !== modelItem && modelItem.expanded) {
                    modelItem.expanded = false;
                }
            }
        }
        item.expanded = !item.expanded;
        this.changeActiveItem(event, item, index);
        focus(event.currentTarget);
    }
    onHeaderKeyDown(event, item, index) {
        switch (event.code) {
            case 'ArrowDown':
                this.onHeaderArrowDownKey(event);
                break;
            case 'ArrowUp':
                this.onHeaderArrowUpKey(event);
                break;
            case 'Home':
                this.onHeaderHomeKey(event);
                break;
            case 'End':
                this.onHeaderEndKey(event);
                break;
            case 'Enter':
            case 'Space':
                this.onHeaderEnterKey(event, item, index);
                break;
            default:
                break;
        }
    }
    onHeaderArrowDownKey(event) {
        const rootList = getAttribute(event.currentTarget, 'data-p-highlight') === true ? findSingle(event.currentTarget.nextElementSibling, '[data-pc-section="rootlist"]') : null;
        rootList ? focus(rootList) : this.updateFocusedHeader({ originalEvent: event, focusOnNext: true });
        event.preventDefault();
    }
    onHeaderArrowUpKey(event) {
        const prevHeader = this.findPrevHeader(event.currentTarget.parentElement) || this.findLastHeader();
        const rootList = getAttribute(prevHeader, 'data-p-highlight') === true ? findSingle(prevHeader.nextElementSibling, '[data-pc-section="rootlist"]') : null;
        rootList ? focus(rootList) : this.updateFocusedHeader({ originalEvent: event, focusOnNext: false });
        event.preventDefault();
    }
    onHeaderHomeKey(event) {
        this.changeFocusedHeader(event, this.findFirstHeader());
        event.preventDefault();
    }
    onHeaderEndKey(event) {
        this.changeFocusedHeader(event, this.findLastHeader());
        event.preventDefault();
    }
    onHeaderEnterKey(event, item, index) {
        const headerAction = findSingle(event.currentTarget, '[data-pc-section="headerlink"]');
        headerAction ? headerAction.click() : this.onHeaderClick(event, item, index);
        event.preventDefault();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PanelMenu, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: PanelMenu, isStandalone: true, selector: "p-panelMenu, p-panelmenu, p-panel-menu", inputs: { model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, multiple: { classPropertyName: "multiple", publicName: "multiple", isSignal: true, isRequired: false, transformFunction: null }, transitionOptions: { classPropertyName: "transitionOptions", publicName: "transitionOptions", isSignal: true, isRequired: false, transformFunction: null }, motionOptions: { classPropertyName: "motionOptions", publicName: "motionOptions", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "cn(cx(\"root\"), styleClass())" } }, providers: [PanelMenuStyle, { provide: PANELMENU_INSTANCE, useExisting: PanelMenu }, { provide: PARENT_INSTANCE, useExisting: PanelMenu }], queries: [{ propertyName: "submenuIconTemplate", first: true, predicate: ["submenuicon"], isSignal: true }, { propertyName: "headerIconTemplate", first: true, predicate: ["headericon"], isSignal: true }, { propertyName: "itemTemplate", first: true, predicate: ["item"], isSignal: true }, { propertyName: "templates", predicate: PrimeTemplate, isSignal: true }], viewQueries: [{ propertyName: "containerViewChild", first: true, predicate: ["container"], descendants: true, isSignal: true }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        @for (item of model(); track item; let f = $first; let l = $last; let i = $index) {
            @if (isItemVisible(item)) {
                <div [class]="cn(cx('panel'), getItemProp(item, 'headerClass'))" [ngStyle]="getItemProp(item, 'style')" [pBind]="ptm('panel')">
                    <div
                        [class]="cn(cx('header', { item }), getItemProp(item, 'styleClass'))"
                        [ngStyle]="getItemProp(item, 'style')"
                        [pTooltip]="getItemProp(item, 'tooltip')"
                        [pTooltipUnstyled]="unstyled()"
                        [attr.id]="getHeaderId(item, i)"
                        [tabindex]="0"
                        role="button"
                        [tooltipOptions]="getItemProp(item, 'tooltipOptions')"
                        [attr.aria-expanded]="isItemActive(item)"
                        [attr.aria-label]="getItemProp(item, 'label')"
                        [attr.aria-controls]="getContentId(item, i)"
                        [attr.aria-disabled]="isItemDisabled(item)"
                        [attr.data-p-highlight]="isItemActive(item)"
                        [attr.data-p-disabled]="isItemDisabled(item)"
                        [pBind]="getPTOptions('header', item, i)"
                        (click)="onHeaderClick($event, item, i)"
                        (keydown)="onHeaderKeyDown($event, item, i)"
                    >
                        <div [class]="cx('headerContent')" [pBind]="getPTOptions('headerContent', item, i)">
                            @if (!itemTemplate() && !_itemTemplate) {
                                @if (!getItemProp(item, 'routerLink')) {
                                    <a
                                        [attr.href]="getItemProp(item, 'url')"
                                        [attr.tabindex]="-1"
                                        [target]="getItemProp(item, 'target')"
                                        [attr.title]="getItemProp(item, 'title')"
                                        [attr.data-automationid]="getItemProp(item, 'automationId')"
                                        [class]="cn(cx('headerLink'), getItemProp(item, 'linkClass'))"
                                        [ngStyle]="getItemProp(item, 'linkStyle')"
                                        [pBind]="getPTOptions('headerLink', item, i)"
                                    >
                                        @if (isItemGroup(item)) {
                                            @if (!headerIconTemplate() && !_headerIconTemplate) {
                                                @if (isItemActive(item)) {
                                                    <svg data-p-icon="chevron-down" [class]="cx('submenuIcon')" [pBind]="getPTOptions('submenuIcon', item, i)" />
                                                }
                                                @if (!isItemActive(item)) {
                                                    <svg data-p-icon="chevron-right" [class]="cx('submenuIcon')" [pBind]="getPTOptions('submenuIcon', item, i)" />
                                                }
                                            }
                                            <ng-template *ngTemplateOutlet="headerIconTemplate() || _headerIconTemplate"></ng-template>
                                        }
                                        @if (item.icon) {
                                            <span [class]="cn(cx('headerIcon'), item.icon, getItemProp(item, 'iconClass'))" [ngStyle]="getItemProp(item, 'iconStyle')" [pBind]="getPTOptions('headerIcon', item, i)"></span>
                                        }
                                        @if (getItemProp(item, 'escape') !== false) {
                                            <span [class]="cn(cx('headerLabel'), getItemProp(item, 'labelClass'))" [ngStyle]="getItemProp(item, 'labelStyle')" [pBind]="getPTOptions('headerLabel', item, i)">{{ getItemProp(item, 'label') }}</span>
                                        } @else {
                                            <span
                                                [class]="cn(cx('headerLabel'), getItemProp(item, 'labelClass'))"
                                                [ngStyle]="getItemProp(item, 'labelStyle')"
                                                [innerHTML]="getItemProp(item, 'label')"
                                                [pBind]="getPTOptions('headerLabel', item, i)"
                                            ></span>
                                        }
                                        @if (getItemProp(item, 'badge')) {
                                            <span [class]="cn(cx('badge'), getItemProp(item, 'badgeStyleClass'))">{{ getItemProp(item, 'badge') }}</span>
                                        }
                                    </a>
                                }
                            }
                            <ng-container *ngTemplateOutlet="itemTemplate(); context: { $implicit: item }"></ng-container>
                            @if (getItemProp(item, 'routerLink')) {
                                <a
                                    [routerLink]="getItemProp(item, 'routerLink')"
                                    [queryParams]="getItemProp(item, 'queryParams')"
                                    [routerLinkActive]="'p-panelmenu-item-link-active'"
                                    [routerLinkActiveOptions]="getItemProp(item, 'routerLinkActiveOptions') || { exact: false }"
                                    [target]="getItemProp(item, 'target')"
                                    [attr.title]="getItemProp(item, 'title')"
                                    [attr.data-automationid]="getItemProp(item, 'automationId')"
                                    [class]="cn(cx('headerLink'), getItemProp(item, 'linkClass'))"
                                    [ngStyle]="getItemProp(item, 'linkStyle')"
                                    [attr.tabindex]="-1"
                                    [fragment]="getItemProp(item, 'fragment')"
                                    [queryParamsHandling]="getItemProp(item, 'queryParamsHandling')"
                                    [preserveFragment]="getItemProp(item, 'preserveFragment')"
                                    [skipLocationChange]="getItemProp(item, 'skipLocationChange')"
                                    [replaceUrl]="getItemProp(item, 'replaceUrl')"
                                    [state]="getItemProp(item, 'state')"
                                    [pBind]="getPTOptions('headerLink', item, i)"
                                >
                                    @if (isItemGroup(item)) {
                                        @if (!headerIconTemplate() && !_headerIconTemplate) {
                                            @if (isItemActive(item)) {
                                                <svg data-p-icon="chevron-down" [class]="cx('submenuIcon')" [pBind]="getPTOptions('submenuIcon', item, i)" />
                                            }
                                            @if (!isItemActive(item)) {
                                                <svg data-p-icon="chevron-right" [class]="cx('submenuIcon')" [pBind]="getPTOptions('submenuIcon', item, i)" />
                                            }
                                        }
                                        <ng-template *ngTemplateOutlet="headerIconTemplate() || _headerIconTemplate"></ng-template>
                                    }
                                    @if (item.icon) {
                                        <span [class]="cn(cx('headerIcon'), item.icon, getItemProp(item, 'iconClass'))" [ngStyle]="getItemProp(item, 'iconStyle')" [pBind]="getPTOptions('headerIcon', item, i)"></span>
                                    }
                                    @if (getItemProp(item, 'escape') !== false) {
                                        <span [class]="cn(cx('headerLabel'), getItemProp(item, 'labelClass'))" [ngStyle]="getItemProp(item, 'labelStyle')" [pBind]="getPTOptions('headerLabel', item, i)">{{ getItemProp(item, 'label') }}</span>
                                    } @else {
                                        <span [class]="cn(cx('headerLabel'), getItemProp(item, 'labelClass'))" [ngStyle]="getItemProp(item, 'labelStyle')" [innerHTML]="getItemProp(item, 'label')" [pBind]="getPTOptions('headerLabel', item, i)"></span>
                                    }
                                    @if (getItemProp(item, 'badge')) {
                                        <span [class]="cn(cx('badge'), getItemProp(item, 'badgeStyleClass'))">{{ getItemProp(item, 'badge') }}</span>
                                    }
                                </a>
                            }
                        </div>
                    </div>
                    <div
                        [class]="cx('contentContainer', { processedItem: item })"
                        role="region"
                        [attr.id]="getContentId(item, i)"
                        [attr.aria-labelledby]="getHeaderId(item, i)"
                        [pBind]="ptm('contentContainer')"
                        pMotionName="p-collapsible"
                        [pMotion]="isItemActive(item)"
                        [pMotionOptions]="computedMotionOptions()"
                    >
                        <div [class]="cx('contentWrapper')" [pBind]="ptm('contentWrapper')">
                            <div [class]="cx('content')" [pBind]="ptm('content')">
                                <ul
                                    pPanelMenuList
                                    [panelId]="getPanelId(i, item)"
                                    [items]="getItemProp(item, 'items')"
                                    [itemTemplate]="itemTemplate() || _itemTemplate"
                                    [transitionOptions]="transitionOptions()"
                                    [root]="true"
                                    [activeItem]="activeItem()"
                                    [tabindex]="tabindex()"
                                    [parentExpanded]="isItemActive(item)"
                                    (headerFocus)="updateFocusedHeader($event)"
                                    [pt]="pt()"
                                    [unstyled]="unstyled()"
                                    [motionOptions]="computedMotionOptions()"
                                ></ul>
                            </div>
                        </div>
                    </div>
                </div>
            }
        }
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: PanelMenuList, selector: "ul[pPanelMenuList]", inputs: ["panelId", "id", "items", "itemTemplate", "parentExpanded", "expanded", "transitionOptions", "root", "tabindex", "activeItem", "motionOptions"], outputs: ["itemToggle", "headerFocus"] }, { kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i3.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "browserUrl", "routerLink"] }, { kind: "directive", type: i3.RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "ngmodule", type: TooltipModule }, { kind: "directive", type: i4.Tooltip, selector: "[pTooltip]", inputs: ["tooltipPosition", "tooltipEvent", "positionStyle", "tooltipStyleClass", "tooltipZIndex", "escape", "showDelay", "hideDelay", "life", "positionTop", "positionLeft", "autoHide", "fitContent", "hideOnEscape", "showOnEllipsis", "pTooltip", "tooltipDisabled", "tooltipOptions", "appendTo", "ptTooltip", "pTooltipPT", "pTooltipUnstyled"] }, { kind: "directive", type: i1.Bind, selector: "[pBind]", inputs: ["pBind"] }, { kind: "component", type: ChevronDownIcon, selector: "[data-p-icon=\"chevron-down\"]" }, { kind: "component", type: ChevronRightIcon, selector: "[data-p-icon=\"chevron-right\"]" }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: BindModule }, { kind: "ngmodule", type: MotionModule }, { kind: "directive", type: i5.MotionDirective, selector: "[pMotion]", inputs: ["pMotion", "pMotionName", "pMotionType", "pMotionSafe", "pMotionDisabled", "pMotionAppear", "pMotionEnter", "pMotionLeave", "pMotionDuration", "pMotionHideStrategy", "pMotionEnterFromClass", "pMotionEnterToClass", "pMotionEnterActiveClass", "pMotionLeaveFromClass", "pMotionLeaveToClass", "pMotionLeaveActiveClass", "pMotionOptions"], outputs: ["pMotionOnBeforeEnter", "pMotionOnEnter", "pMotionOnAfterEnter", "pMotionOnEnterCancelled", "pMotionOnBeforeLeave", "pMotionOnLeave", "pMotionOnAfterLeave", "pMotionOnLeaveCancelled"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PanelMenu, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-panelMenu, p-panelmenu, p-panel-menu',
                    imports: [CommonModule, PanelMenuList, RouterModule, TooltipModule, ChevronDownIcon, ChevronRightIcon, SharedModule, BindModule, MotionModule],
                    standalone: true,
                    template: `
        @for (item of model(); track item; let f = $first; let l = $last; let i = $index) {
            @if (isItemVisible(item)) {
                <div [class]="cn(cx('panel'), getItemProp(item, 'headerClass'))" [ngStyle]="getItemProp(item, 'style')" [pBind]="ptm('panel')">
                    <div
                        [class]="cn(cx('header', { item }), getItemProp(item, 'styleClass'))"
                        [ngStyle]="getItemProp(item, 'style')"
                        [pTooltip]="getItemProp(item, 'tooltip')"
                        [pTooltipUnstyled]="unstyled()"
                        [attr.id]="getHeaderId(item, i)"
                        [tabindex]="0"
                        role="button"
                        [tooltipOptions]="getItemProp(item, 'tooltipOptions')"
                        [attr.aria-expanded]="isItemActive(item)"
                        [attr.aria-label]="getItemProp(item, 'label')"
                        [attr.aria-controls]="getContentId(item, i)"
                        [attr.aria-disabled]="isItemDisabled(item)"
                        [attr.data-p-highlight]="isItemActive(item)"
                        [attr.data-p-disabled]="isItemDisabled(item)"
                        [pBind]="getPTOptions('header', item, i)"
                        (click)="onHeaderClick($event, item, i)"
                        (keydown)="onHeaderKeyDown($event, item, i)"
                    >
                        <div [class]="cx('headerContent')" [pBind]="getPTOptions('headerContent', item, i)">
                            @if (!itemTemplate() && !_itemTemplate) {
                                @if (!getItemProp(item, 'routerLink')) {
                                    <a
                                        [attr.href]="getItemProp(item, 'url')"
                                        [attr.tabindex]="-1"
                                        [target]="getItemProp(item, 'target')"
                                        [attr.title]="getItemProp(item, 'title')"
                                        [attr.data-automationid]="getItemProp(item, 'automationId')"
                                        [class]="cn(cx('headerLink'), getItemProp(item, 'linkClass'))"
                                        [ngStyle]="getItemProp(item, 'linkStyle')"
                                        [pBind]="getPTOptions('headerLink', item, i)"
                                    >
                                        @if (isItemGroup(item)) {
                                            @if (!headerIconTemplate() && !_headerIconTemplate) {
                                                @if (isItemActive(item)) {
                                                    <svg data-p-icon="chevron-down" [class]="cx('submenuIcon')" [pBind]="getPTOptions('submenuIcon', item, i)" />
                                                }
                                                @if (!isItemActive(item)) {
                                                    <svg data-p-icon="chevron-right" [class]="cx('submenuIcon')" [pBind]="getPTOptions('submenuIcon', item, i)" />
                                                }
                                            }
                                            <ng-template *ngTemplateOutlet="headerIconTemplate() || _headerIconTemplate"></ng-template>
                                        }
                                        @if (item.icon) {
                                            <span [class]="cn(cx('headerIcon'), item.icon, getItemProp(item, 'iconClass'))" [ngStyle]="getItemProp(item, 'iconStyle')" [pBind]="getPTOptions('headerIcon', item, i)"></span>
                                        }
                                        @if (getItemProp(item, 'escape') !== false) {
                                            <span [class]="cn(cx('headerLabel'), getItemProp(item, 'labelClass'))" [ngStyle]="getItemProp(item, 'labelStyle')" [pBind]="getPTOptions('headerLabel', item, i)">{{ getItemProp(item, 'label') }}</span>
                                        } @else {
                                            <span
                                                [class]="cn(cx('headerLabel'), getItemProp(item, 'labelClass'))"
                                                [ngStyle]="getItemProp(item, 'labelStyle')"
                                                [innerHTML]="getItemProp(item, 'label')"
                                                [pBind]="getPTOptions('headerLabel', item, i)"
                                            ></span>
                                        }
                                        @if (getItemProp(item, 'badge')) {
                                            <span [class]="cn(cx('badge'), getItemProp(item, 'badgeStyleClass'))">{{ getItemProp(item, 'badge') }}</span>
                                        }
                                    </a>
                                }
                            }
                            <ng-container *ngTemplateOutlet="itemTemplate(); context: { $implicit: item }"></ng-container>
                            @if (getItemProp(item, 'routerLink')) {
                                <a
                                    [routerLink]="getItemProp(item, 'routerLink')"
                                    [queryParams]="getItemProp(item, 'queryParams')"
                                    [routerLinkActive]="'p-panelmenu-item-link-active'"
                                    [routerLinkActiveOptions]="getItemProp(item, 'routerLinkActiveOptions') || { exact: false }"
                                    [target]="getItemProp(item, 'target')"
                                    [attr.title]="getItemProp(item, 'title')"
                                    [attr.data-automationid]="getItemProp(item, 'automationId')"
                                    [class]="cn(cx('headerLink'), getItemProp(item, 'linkClass'))"
                                    [ngStyle]="getItemProp(item, 'linkStyle')"
                                    [attr.tabindex]="-1"
                                    [fragment]="getItemProp(item, 'fragment')"
                                    [queryParamsHandling]="getItemProp(item, 'queryParamsHandling')"
                                    [preserveFragment]="getItemProp(item, 'preserveFragment')"
                                    [skipLocationChange]="getItemProp(item, 'skipLocationChange')"
                                    [replaceUrl]="getItemProp(item, 'replaceUrl')"
                                    [state]="getItemProp(item, 'state')"
                                    [pBind]="getPTOptions('headerLink', item, i)"
                                >
                                    @if (isItemGroup(item)) {
                                        @if (!headerIconTemplate() && !_headerIconTemplate) {
                                            @if (isItemActive(item)) {
                                                <svg data-p-icon="chevron-down" [class]="cx('submenuIcon')" [pBind]="getPTOptions('submenuIcon', item, i)" />
                                            }
                                            @if (!isItemActive(item)) {
                                                <svg data-p-icon="chevron-right" [class]="cx('submenuIcon')" [pBind]="getPTOptions('submenuIcon', item, i)" />
                                            }
                                        }
                                        <ng-template *ngTemplateOutlet="headerIconTemplate() || _headerIconTemplate"></ng-template>
                                    }
                                    @if (item.icon) {
                                        <span [class]="cn(cx('headerIcon'), item.icon, getItemProp(item, 'iconClass'))" [ngStyle]="getItemProp(item, 'iconStyle')" [pBind]="getPTOptions('headerIcon', item, i)"></span>
                                    }
                                    @if (getItemProp(item, 'escape') !== false) {
                                        <span [class]="cn(cx('headerLabel'), getItemProp(item, 'labelClass'))" [ngStyle]="getItemProp(item, 'labelStyle')" [pBind]="getPTOptions('headerLabel', item, i)">{{ getItemProp(item, 'label') }}</span>
                                    } @else {
                                        <span [class]="cn(cx('headerLabel'), getItemProp(item, 'labelClass'))" [ngStyle]="getItemProp(item, 'labelStyle')" [innerHTML]="getItemProp(item, 'label')" [pBind]="getPTOptions('headerLabel', item, i)"></span>
                                    }
                                    @if (getItemProp(item, 'badge')) {
                                        <span [class]="cn(cx('badge'), getItemProp(item, 'badgeStyleClass'))">{{ getItemProp(item, 'badge') }}</span>
                                    }
                                </a>
                            }
                        </div>
                    </div>
                    <div
                        [class]="cx('contentContainer', { processedItem: item })"
                        role="region"
                        [attr.id]="getContentId(item, i)"
                        [attr.aria-labelledby]="getHeaderId(item, i)"
                        [pBind]="ptm('contentContainer')"
                        pMotionName="p-collapsible"
                        [pMotion]="isItemActive(item)"
                        [pMotionOptions]="computedMotionOptions()"
                    >
                        <div [class]="cx('contentWrapper')" [pBind]="ptm('contentWrapper')">
                            <div [class]="cx('content')" [pBind]="ptm('content')">
                                <ul
                                    pPanelMenuList
                                    [panelId]="getPanelId(i, item)"
                                    [items]="getItemProp(item, 'items')"
                                    [itemTemplate]="itemTemplate() || _itemTemplate"
                                    [transitionOptions]="transitionOptions()"
                                    [root]="true"
                                    [activeItem]="activeItem()"
                                    [tabindex]="tabindex()"
                                    [parentExpanded]="isItemActive(item)"
                                    (headerFocus)="updateFocusedHeader($event)"
                                    [pt]="pt()"
                                    [unstyled]="unstyled()"
                                    [motionOptions]="computedMotionOptions()"
                                ></ul>
                            </div>
                        </div>
                    </div>
                </div>
            }
        }
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [PanelMenuStyle, { provide: PANELMENU_INSTANCE, useExisting: PanelMenu }, { provide: PARENT_INSTANCE, useExisting: PanelMenu }],
                    host: {
                        '[class]': 'cn(cx("root"), styleClass())'
                    },
                    hostDirectives: [Bind]
                }]
        }], propDecorators: { model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], multiple: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiple", required: false }] }], transitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "transitionOptions", required: false }] }], motionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "motionOptions", required: false }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], containerViewChild: [{ type: i0.ViewChild, args: ['container', { isSignal: true }] }], submenuIconTemplate: [{ type: i0.ContentChild, args: ['submenuicon', { ...{ descendants: false }, isSignal: true }] }], headerIconTemplate: [{ type: i0.ContentChild, args: ['headericon', { ...{ descendants: false }, isSignal: true }] }], itemTemplate: [{ type: i0.ContentChild, args: ['item', { ...{ descendants: false }, isSignal: true }] }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class PanelMenuModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PanelMenuModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: PanelMenuModule, imports: [PanelMenu, SharedModule], exports: [PanelMenu, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PanelMenuModule, imports: [PanelMenu, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PanelMenuModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [PanelMenu, SharedModule],
                    exports: [PanelMenu, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { PanelMenu, PanelMenuClasses, PanelMenuList, PanelMenuModule, PanelMenuStyle, PanelMenuSub };
//# sourceMappingURL=wawjs-ngx-prime-panelmenu.mjs.map
