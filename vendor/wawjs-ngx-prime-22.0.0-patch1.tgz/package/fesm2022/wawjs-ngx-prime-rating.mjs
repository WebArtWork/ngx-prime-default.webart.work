export * from '@wawjs/ngx-prime/types/rating';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, inject, input, booleanAttribute, numberAttribute, output, forwardRef, Directive, InjectionToken, contentChildren, signal, ContentChild, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { equals, uuid, getFirstFocusableElement, focus } from '@wawjs/css-prime-utils';
import { PrimeTemplate, SharedModule } from '@wawjs/ngx-prime/api';
import { AutoFocus } from '@wawjs/ngx-prime/autofocus';
import { PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind, BindModule } from '@wawjs/ngx-prime/bind';
import { StarFillIcon, StarIcon } from '@wawjs/ngx-prime/icons';
import { style as style$1 } from '@wawjs/css-prime-styles/rating';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const style = /*css*/ `
    ${style$1}

    /* For ngx-prime */
    p-rating.ng-invalid.ng-dirty > .p-rating > .p-rating-icon {
        stroke: dt('rating.invalid.icon.color');
    }
`;
const classes = {
    root: ({ instance }) => [
        'p-rating',
        {
            'p-readonly': instance.readonly(),
            'p-disabled': instance.$disabled()
        }
    ],
    option: ({ instance, star, value }) => [
        'p-rating-option',
        {
            'p-rating-option-active': star + 1 <= value,
            'p-focus-visible': star + 1 === instance.focusedOptionIndex() && instance.isFocusVisibleItem
        }
    ],
    onIcon: ({ instance }) => ['p-rating-icon p-rating-on-icon', { 'p-invalid': instance.invalid() }],
    offIcon: ({ instance }) => ['p-rating-icon p-rating-off-icon', { 'p-invalid': instance.invalid() }]
};
class RatingStyle extends BaseStyle {
    name = 'rating';
    style = style;
    classes = classes;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RatingStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RatingStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RatingStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * Rating component is a star based selection input.
 *
 * [Live Demo](https://www.ngx-prime.org/rating/)
 *
 * @module ratingstyle
 *
 */
var RatingClasses;
(function (RatingClasses) {
    /**
     * Class name of the root element
     */
    RatingClasses["root"] = "p-rating";
    /**
     * Class name of the option element
     */
    RatingClasses["option"] = "p-rating-option";
    /**
     * Class name of the on icon element
     */
    RatingClasses["onIcon"] = "p-rating-on-icon";
    /**
     * Class name of the off icon element
     */
    RatingClasses["offIcon"] = "p-rating-off-icon";
})(RatingClasses || (RatingClasses = {}));

/** Adds Prime state attributes to a native radio used in a rating group. */
class RatingDirective extends BaseEditableHolder {
    componentName = 'Rating';
    _componentStyle = inject(RatingStyle);
    readonly = input(false, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    value = input(0, { ...(ngDevMode ? { debugName: "value" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    autofocus = input(false, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    onRate = output();
    onFocus = output();
    onBlur = output();
    touch = output();
    onInputClick(event) {
        if (this.readonly()) {
            event.preventDefault();
            return;
        }
        if (this.checked) {
            event.preventDefault();
            this.setRating(event, null);
        }
    }
    onInputChange(event) {
        if (!this.readonly() && event.target.checked) {
            this.setRating(event, this.value());
        }
    }
    onInputFocus(event) {
        this.onFocus.emit(event);
    }
    onInputBlur(event) {
        this.onModelTouched();
        this.touch.emit();
        this.onBlur.emit(event);
    }
    get checked() {
        return equals(this.modelValue(), this.value());
    }
    setRating(event, value) {
        this.writeModelValue(value);
        this.onModelChange(value);
        if (value !== null) {
            this.onRate.emit({ originalEvent: event, value });
        }
    }
    writeControlValue(value, setModelValue) {
        setModelValue(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RatingDirective, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: RatingDirective, isStandalone: true, selector: "input[type='radio'][pRating]", inputs: { readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onRate: "onRate", onFocus: "onFocus", onBlur: "onBlur", touch: "touch" }, host: { listeners: { "click": "onInputClick($event)", "change": "onInputChange($event)", "focus": "onInputFocus($event)", "blur": "onInputBlur($event)" }, properties: { "class": "cx('root')", "attr.data-pc-name": "'rating'", "attr.data-pc-section": "'input'", "attr.data-p-invalid": "invalid() || null", "attr.aria-label": "ariaLabel() || null", "attr.aria-labelledby": "ariaLabelledBy() || null", "autofocus": "autofocus()", "disabled": "$disabled()", "required": "required()", "attr.name": "name() || null", "value": "value()", "checked": "checked" } }, providers: [RatingStyle, { provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => RatingDirective), multi: true }], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RatingDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: "input[type='radio'][pRating]",
                    standalone: true,
                    host: {
                        '[class]': "cx('root')",
                        '[attr.data-pc-name]': "'rating'",
                        '[attr.data-pc-section]': "'input'",
                        '[attr.data-p-invalid]': 'invalid() || null',
                        '[attr.aria-label]': 'ariaLabel() || null',
                        '[attr.aria-labelledby]': 'ariaLabelledBy() || null',
                        '[autofocus]': 'autofocus()',
                        '[disabled]': '$disabled()',
                        '[required]': 'required()',
                        '[attr.name]': 'name() || null',
                        '[value]': 'value()',
                        '[checked]': 'checked',
                        '(click)': 'onInputClick($event)',
                        '(change)': 'onInputChange($event)',
                        '(focus)': 'onInputFocus($event)',
                        '(blur)': 'onInputBlur($event)'
                    },
                    providers: [RatingStyle, { provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => RatingDirective), multi: true }]
                }]
        }], propDecorators: { readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], onRate: [{ type: i0.Output, args: ["onRate"] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], touch: [{ type: i0.Output, args: ["touch"] }] } });

const RATING_INSTANCE = new InjectionToken('RATING_INSTANCE');
const RATING_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => Rating),
    multi: true
};
/**
 * Rating is an extension to standard radio button element with theming.
 * @group Components
 */
class Rating extends BaseEditableHolder {
    componentName = 'Rating';
    $pcRating = inject(RATING_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    /**
     * When present, changing the value is not possible.
     * @group Props
     */
    readonly = input(undefined, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Number of stars.
     * @group Props
     */
    stars = input(5, { ...(ngDevMode ? { debugName: "stars" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Style class of the on icon.
     * @group Props
     */
    iconOnClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "iconOnClass" }] : /* istanbul ignore next */ []));
    /**
     * Inline style of the on icon.
     * @group Props
     */
    iconOnStyle = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "iconOnStyle" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the off icon.
     * @group Props
     */
    iconOffClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "iconOffClass" }] : /* istanbul ignore next */ []));
    /**
     * Inline style of the off icon.
     * @group Props
     */
    iconOffStyle = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "iconOffStyle" }] : /* istanbul ignore next */ []));
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus = input(undefined, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Emitted on value change.
     * @param {RatingRateEvent} value - Custom rate event.
     * @group Emits
     */
    onRate = output();
    /**
     * Emitted when the rating receives focus.
     * @param {Event} value - Browser event.
     * @group Emits
     */
    onFocus = output();
    /**
     * Emitted when the rating loses focus.
     * @param {Event} value - Browser event.
     * @group Emits
     */
    onBlur = output();
    /**
     * Custom on icon template.
     * @param {RatingIconTemplateContext} context - icon context.
     * @see {@link RatingIconTemplateContext}
     * @group Templates
     */
    onIconTemplate;
    /**
     * Custom off icon template.
     * @param {RatingIconTemplateContext} context - icon context.
     * @see {@link RatingIconTemplateContext}
     * @group Templates
     */
    offIconTemplate;
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    value;
    starsArray;
    isFocusVisibleItem = true;
    focusedOptionIndex = signal(-1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusedOptionIndex" }] : /* istanbul ignore next */ []));
    nameattr;
    _componentStyle = inject(RatingStyle);
    _onIconTemplate;
    _offIconTemplate;
    onInit() {
        this.nameattr = this.nameattr || uuid('pn_id_');
        this.starsArray = [];
        for (let i = 0; i < this.stars(); i++) {
            this.starsArray[i] = i;
        }
    }
    onAfterContentInit() {
        this.templates().forEach((item) => {
            switch (item.getType()) {
                case 'onicon':
                    this._onIconTemplate = item.template;
                    break;
                case 'officon':
                    this._offIconTemplate = item.template;
                    break;
            }
        });
    }
    onOptionClick(event, value) {
        if (!this.readonly() && !this.$disabled()) {
            this.onOptionSelect(event, value);
            this.isFocusVisibleItem = false;
            const firstFocusableEl = getFirstFocusableElement(event.currentTarget, '');
            firstFocusableEl && focus(firstFocusableEl);
        }
    }
    onOptionSelect(event, value) {
        if (!this.readonly() && !this.$disabled()) {
            if (this.focusedOptionIndex() === value || value === this.value) {
                this.focusedOptionIndex.set(-1);
                this.updateModel(event, null);
            }
            else {
                this.focusedOptionIndex.set(value);
                this.updateModel(event, value || null);
            }
        }
    }
    onChange(event, value) {
        this.onOptionSelect(event, value);
        this.isFocusVisibleItem = true;
    }
    onInputBlur(event) {
        this.focusedOptionIndex.set(-1);
        this.onBlur.emit(event);
    }
    onInputFocus(event, value) {
        if (!this.readonly() && !this.$disabled()) {
            this.focusedOptionIndex.set(value);
            this.isFocusVisibleItem = event.sourceCapabilities?.firesTouchEvents === false;
            this.onFocus.emit(event);
        }
    }
    updateModel(event, value) {
        this.writeValue(value);
        this.onModelChange(this.value);
        this.onModelTouched();
        this.onRate.emit({
            originalEvent: event,
            value
        });
    }
    starAriaLabel(value) {
        return value === 1 ? this.config.translation.aria?.star : this.config.translation.aria?.stars?.replace(/{star}/g, value);
    }
    getIconTemplate(i) {
        return !this.value || i >= this.value ? this.offIconTemplate || this._offIconTemplate : this.onIconTemplate || this.offIconTemplate;
    }
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value, setModelValue) {
        this.value = value;
        setModelValue(value);
    }
    get isCustomIcon() {
        return !!(this.onIconTemplate || this._onIconTemplate || this.offIconTemplate || this._offIconTemplate);
    }
    get dataP() {
        return this.cn({
            readonly: this.readonly(),
            disabled: this.$disabled()
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Rating, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: Rating, isStandalone: true, selector: "p-rating", inputs: { readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, stars: { classPropertyName: "stars", publicName: "stars", isSignal: true, isRequired: false, transformFunction: null }, iconOnClass: { classPropertyName: "iconOnClass", publicName: "iconOnClass", isSignal: true, isRequired: false, transformFunction: null }, iconOnStyle: { classPropertyName: "iconOnStyle", publicName: "iconOnStyle", isSignal: true, isRequired: false, transformFunction: null }, iconOffClass: { classPropertyName: "iconOffClass", publicName: "iconOffClass", isSignal: true, isRequired: false, transformFunction: null }, iconOffStyle: { classPropertyName: "iconOffStyle", publicName: "iconOffStyle", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onRate: "onRate", onFocus: "onFocus", onBlur: "onBlur" }, host: { properties: { "class": "cx('root')", "attr.data-p": "dataP" } }, providers: [RATING_VALUE_ACCESSOR, RatingStyle, { provide: RATING_INSTANCE, useExisting: Rating }, { provide: PARENT_INSTANCE, useExisting: Rating }], queries: [{ propertyName: "templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "onIconTemplate", first: true, predicate: ["onicon"] }, { propertyName: "offIconTemplate", first: true, predicate: ["officon"] }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        @for (star of starsArray; track star; let i = $index) {
            <div [class]="cx('option', { star, value })" (click)="onOptionClick($event, star + 1)" [pBind]="ptm('option')">
                <span class="p-hidden-accessible" [attr.data-p-hidden-accessible]="true" [pBind]="ptm('hiddenOptionInputContainer')">
                    <input
                        type="radio"
                        [value]="star + 1"
                        [attr.name]="name() || nameattr + '_name'"
                        [attr.value]="modelValue()"
                        [attr.required]="required() ? '' : undefined"
                        [attr.readonly]="readonly() ? '' : undefined"
                        [attr.disabled]="$disabled() ? '' : undefined"
                        [checked]="value === star + 1"
                        [attr.aria-label]="starAriaLabel(star + 1)"
                        (focus)="onInputFocus($event, star + 1)"
                        (blur)="onInputBlur($event)"
                        (change)="onChange($event, star + 1)"
                        [pAutoFocus]="autofocus()"
                        [pBind]="ptm('hiddenOptionInput')"
                    />
                </span>
                @if (star + 1 <= value) {
                    @if (onIconTemplate || _onIconTemplate) {
                        <ng-container *ngTemplateOutlet="onIconTemplate || _onIconTemplate; context: { $implicit: star + 1, class: cx('onIcon') }"></ng-container>
                    } @else {
                        @if (iconOnClass()) {
                            <span [class]="cx('onIcon')" [ngStyle]="iconOnStyle()" [ngClass]="iconOnClass()" [pBind]="ptm('onIcon')"></span>
                        }
                        @if (!iconOnClass()) {
                            <svg data-p-icon="star-fill" [ngStyle]="iconOnStyle()" [class]="cx('onIcon')" [pBind]="ptm('onIcon')" />
                        }
                    }
                } @else {
                    @if (offIconTemplate || _offIconTemplate) {
                        <ng-container *ngTemplateOutlet="offIconTemplate || _offIconTemplate; context: { $implicit: star + 1, class: cx('offIcon') }"></ng-container>
                    } @else {
                        @if (iconOffClass()) {
                            <span [class]="cx('offIcon')" [ngStyle]="iconOffStyle()" [ngClass]="iconOffClass()" [pBind]="ptm('offIcon')"></span>
                        }
                        @if (!iconOffClass()) {
                            <svg data-p-icon="star" [ngStyle]="iconOffStyle()" [class]="cx('offIcon')" [pBind]="ptm('offIcon')" />
                        }
                    }
                }
            </div>
        }
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: AutoFocus, selector: "[pAutoFocus]", inputs: ["pAutoFocus"] }, { kind: "component", type: StarFillIcon, selector: "[data-p-icon=\"star-fill\"]" }, { kind: "component", type: StarIcon, selector: "[data-p-icon=\"star\"]" }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: BindModule }, { kind: "directive", type: i1.Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Rating, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-rating',
                    imports: [CommonModule, AutoFocus, StarFillIcon, StarIcon, SharedModule, BindModule],
                    standalone: true,
                    template: `
        @for (star of starsArray; track star; let i = $index) {
            <div [class]="cx('option', { star, value })" (click)="onOptionClick($event, star + 1)" [pBind]="ptm('option')">
                <span class="p-hidden-accessible" [attr.data-p-hidden-accessible]="true" [pBind]="ptm('hiddenOptionInputContainer')">
                    <input
                        type="radio"
                        [value]="star + 1"
                        [attr.name]="name() || nameattr + '_name'"
                        [attr.value]="modelValue()"
                        [attr.required]="required() ? '' : undefined"
                        [attr.readonly]="readonly() ? '' : undefined"
                        [attr.disabled]="$disabled() ? '' : undefined"
                        [checked]="value === star + 1"
                        [attr.aria-label]="starAriaLabel(star + 1)"
                        (focus)="onInputFocus($event, star + 1)"
                        (blur)="onInputBlur($event)"
                        (change)="onChange($event, star + 1)"
                        [pAutoFocus]="autofocus()"
                        [pBind]="ptm('hiddenOptionInput')"
                    />
                </span>
                @if (star + 1 <= value) {
                    @if (onIconTemplate || _onIconTemplate) {
                        <ng-container *ngTemplateOutlet="onIconTemplate || _onIconTemplate; context: { $implicit: star + 1, class: cx('onIcon') }"></ng-container>
                    } @else {
                        @if (iconOnClass()) {
                            <span [class]="cx('onIcon')" [ngStyle]="iconOnStyle()" [ngClass]="iconOnClass()" [pBind]="ptm('onIcon')"></span>
                        }
                        @if (!iconOnClass()) {
                            <svg data-p-icon="star-fill" [ngStyle]="iconOnStyle()" [class]="cx('onIcon')" [pBind]="ptm('onIcon')" />
                        }
                    }
                } @else {
                    @if (offIconTemplate || _offIconTemplate) {
                        <ng-container *ngTemplateOutlet="offIconTemplate || _offIconTemplate; context: { $implicit: star + 1, class: cx('offIcon') }"></ng-container>
                    } @else {
                        @if (iconOffClass()) {
                            <span [class]="cx('offIcon')" [ngStyle]="iconOffStyle()" [ngClass]="iconOffClass()" [pBind]="ptm('offIcon')"></span>
                        }
                        @if (!iconOffClass()) {
                            <svg data-p-icon="star" [ngStyle]="iconOffStyle()" [class]="cx('offIcon')" [pBind]="ptm('offIcon')" />
                        }
                    }
                }
            </div>
        }
    `,
                    providers: [RATING_VALUE_ACCESSOR, RatingStyle, { provide: RATING_INSTANCE, useExisting: Rating }, { provide: PARENT_INSTANCE, useExisting: Rating }],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class]': "cx('root')",
                        '[attr.data-p]': 'dataP'
                    },
                    hostDirectives: [Bind]
                }]
        }], propDecorators: { readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], stars: [{ type: i0.Input, args: [{ isSignal: true, alias: "stars", required: false }] }], iconOnClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconOnClass", required: false }] }], iconOnStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconOnStyle", required: false }] }], iconOffClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconOffClass", required: false }] }], iconOffStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconOffStyle", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], onRate: [{ type: i0.Output, args: ["onRate"] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], onIconTemplate: [{
                type: ContentChild,
                args: ['onicon', { descendants: false }]
            }], offIconTemplate: [{
                type: ContentChild,
                args: ['officon', { descendants: false }]
            }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class RatingModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RatingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: RatingModule, imports: [Rating, RatingDirective, SharedModule], exports: [Rating, RatingDirective, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RatingModule, imports: [Rating, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RatingModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [Rating, RatingDirective, SharedModule],
                    exports: [Rating, RatingDirective, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { RATING_VALUE_ACCESSOR, Rating, RatingClasses, RatingDirective, RatingModule, RatingStyle };
//# sourceMappingURL=wawjs-ngx-prime-rating.mjs.map
