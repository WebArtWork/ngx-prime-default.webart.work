export * from '@wawjs/ngx-prime/types/card';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, input, contentChild, signal, effect, contentChildren, ContentChild, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { equals } from '@wawjs/css-prime-utils';
import { Header, Footer, PrimeTemplate, SharedModule } from '@wawjs/ngx-prime/api';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind, BindModule } from '@wawjs/ngx-prime/bind';
import { style as style$1 } from '@wawjs/css-prime-styles/card';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const style = /*css*/ `
    ${style$1}

    .p-card {
        display: block;
    }
`;
const classes = {
    root: 'p-card p-component',
    header: 'p-card-header',
    body: 'p-card-body',
    caption: 'p-card-caption',
    title: 'p-card-title',
    subtitle: 'p-card-subtitle',
    content: 'p-card-content',
    footer: 'p-card-footer'
};
class CardStyle extends BaseStyle {
    name = 'card';
    style = style;
    classes = classes;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CardStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CardStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CardStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * Card is a flexible container component.
 *
 * [Live Demo](https://www.ngx-prime.org/card/)
 *
 * @module cardstyle
 *
 */
var CardClasses;
(function (CardClasses) {
    /**
     * Class name of the root element
     */
    CardClasses["root"] = "p-card";
    /**
     * Class name of the header element
     */
    CardClasses["header"] = "p-card-header";
    /**
     * Class name of the body element
     */
    CardClasses["body"] = "p-card-body";
    /**
     * Class name of the caption element
     */
    CardClasses["caption"] = "p-card-caption";
    /**
     * Class name of the title element
     */
    CardClasses["title"] = "p-card-title";
    /**
     * Class name of the subtitle element
     */
    CardClasses["subtitle"] = "p-card-subtitle";
    /**
     * Class name of the content element
     */
    CardClasses["content"] = "p-card-content";
    /**
     * Class name of the footer element
     */
    CardClasses["footer"] = "p-card-footer";
})(CardClasses || (CardClasses = {}));

const CARD_INSTANCE = new InjectionToken('CARD_INSTANCE');
/**
 * Card is a flexible container component.
 * @group Components
 */
class Card extends BaseComponent {
    componentName = 'Card';
    $pcCard = inject(CARD_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    bindDirectiveInstance = inject(Bind, { self: true });
    _componentStyle = inject(CardStyle);
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    /**
     * Header of the card.
     * @group Props
     */
    header = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "header" }] : /* istanbul ignore next */ []));
    /**
     * Subheader of the card.
     * @group Props
     */
    subheader = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "subheader" }] : /* istanbul ignore next */ []));
    /**
     * Inline style of the element.
     * @group Props
     */
    style = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "style" }] : /* istanbul ignore next */ []));
    /**
     * Class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    headerFacet = contentChild(Header, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "headerFacet" }] : /* istanbul ignore next */ []));
    footerFacet = contentChild(Footer, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "footerFacet" }] : /* istanbul ignore next */ []));
    /**
     * Custom header template.
     * @group Templates
     */
    headerTemplate;
    /**
     * Custom title template.
     * @group Templates
     */
    titleTemplate;
    /**
     * Custom subtitle template.
     * @group Templates
     */
    subtitleTemplate;
    /**
     * Custom content template.
     * @group Templates
     */
    contentTemplate = contentChild('content', { ...(ngDevMode ? { debugName: "contentTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom footer template.
     * @group Templates
     */
    footerTemplate;
    _headerTemplate;
    _titleTemplate;
    _subtitleTemplate;
    _contentTemplate;
    _footerTemplate;
    _style = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_style" }] : /* istanbul ignore next */ []));
    constructor() {
        super();
        effect(() => {
            const value = this.style();
            if (!equals(this._style(), value)) {
                this._style.set(value);
                // Apply style directly to avoid infinite loop in host binding
                if (this.el?.nativeElement) {
                    if (value) {
                        Object.keys(value).forEach((key) => {
                            this.el.nativeElement.style[key] = value[key];
                        });
                    }
                }
            }
        });
    }
    getBlockableElement() {
        return this.el.nativeElement;
    }
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    onAfterContentInit() {
        this.templates().forEach((item) => {
            switch (item.getType()) {
                case 'header':
                    this._headerTemplate = item.template;
                    break;
                case 'title':
                    this._titleTemplate = item.template;
                    break;
                case 'subtitle':
                    this._subtitleTemplate = item.template;
                    break;
                case 'content':
                    this._contentTemplate = item.template;
                    break;
                case 'footer':
                    this._footerTemplate = item.template;
                    break;
                default:
                    this._contentTemplate = item.template;
                    break;
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Card, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: Card, isStandalone: true, selector: "p-card", inputs: { header: { classPropertyName: "header", publicName: "header", isSignal: true, isRequired: false, transformFunction: null }, subheader: { classPropertyName: "subheader", publicName: "subheader", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "cn(cx('root'), styleClass())", "style": "_style()" } }, providers: [CardStyle, { provide: CARD_INSTANCE, useExisting: Card }, { provide: PARENT_INSTANCE, useExisting: Card }], queries: [{ propertyName: "headerFacet", first: true, predicate: Header, descendants: true, isSignal: true }, { propertyName: "footerFacet", first: true, predicate: Footer, descendants: true, isSignal: true }, { propertyName: "contentTemplate", first: true, predicate: ["content"], isSignal: true }, { propertyName: "templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "headerTemplate", first: true, predicate: ["header"] }, { propertyName: "titleTemplate", first: true, predicate: ["title"] }, { propertyName: "subtitleTemplate", first: true, predicate: ["subtitle"] }, { propertyName: "footerTemplate", first: true, predicate: ["footer"] }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        @if (headerFacet() || headerTemplate || _headerTemplate) {
            <div [pBind]="ptm('header')" [class]="cx('header')">
                <ng-content select="p-header"></ng-content>
                <ng-container *ngTemplateOutlet="headerTemplate || _headerTemplate"></ng-container>
            </div>
        }
        <div [pBind]="ptm('body')" [class]="cx('body')">
            @if (header() || titleTemplate || _titleTemplate) {
                <div [pBind]="ptm('title')" [class]="cx('title')">
                    @if (header() && !_titleTemplate && !titleTemplate) {
                        {{ header() }}
                    }
                    <ng-container *ngTemplateOutlet="titleTemplate || _titleTemplate"></ng-container>
                </div>
            }
            @if (subheader() || subtitleTemplate || _subtitleTemplate) {
                <div [pBind]="ptm('subtitle')" [class]="cx('subtitle')">
                    @if (subheader() && !_subtitleTemplate && !subtitleTemplate) {
                        {{ subheader() }}
                    }
                    <ng-container *ngTemplateOutlet="subtitleTemplate || _subtitleTemplate"></ng-container>
                </div>
            }
            <div [pBind]="ptm('content')" [class]="cx('content')">
                <ng-content></ng-content>
                <ng-container *ngTemplateOutlet="contentTemplate() || _contentTemplate"></ng-container>
            </div>
            @if (footerFacet() || footerTemplate || _footerTemplate) {
                <div [pBind]="ptm('footer')" [class]="cx('footer')">
                    <ng-content select="p-footer"></ng-content>
                    <ng-container *ngTemplateOutlet="footerTemplate || _footerTemplate"></ng-container>
                </div>
            }
        </div>
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: BindModule }, { kind: "directive", type: i1.Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Card, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-card',
                    standalone: true,
                    imports: [CommonModule, SharedModule, BindModule],
                    template: `
        @if (headerFacet() || headerTemplate || _headerTemplate) {
            <div [pBind]="ptm('header')" [class]="cx('header')">
                <ng-content select="p-header"></ng-content>
                <ng-container *ngTemplateOutlet="headerTemplate || _headerTemplate"></ng-container>
            </div>
        }
        <div [pBind]="ptm('body')" [class]="cx('body')">
            @if (header() || titleTemplate || _titleTemplate) {
                <div [pBind]="ptm('title')" [class]="cx('title')">
                    @if (header() && !_titleTemplate && !titleTemplate) {
                        {{ header() }}
                    }
                    <ng-container *ngTemplateOutlet="titleTemplate || _titleTemplate"></ng-container>
                </div>
            }
            @if (subheader() || subtitleTemplate || _subtitleTemplate) {
                <div [pBind]="ptm('subtitle')" [class]="cx('subtitle')">
                    @if (subheader() && !_subtitleTemplate && !subtitleTemplate) {
                        {{ subheader() }}
                    }
                    <ng-container *ngTemplateOutlet="subtitleTemplate || _subtitleTemplate"></ng-container>
                </div>
            }
            <div [pBind]="ptm('content')" [class]="cx('content')">
                <ng-content></ng-content>
                <ng-container *ngTemplateOutlet="contentTemplate() || _contentTemplate"></ng-container>
            </div>
            @if (footerFacet() || footerTemplate || _footerTemplate) {
                <div [pBind]="ptm('footer')" [class]="cx('footer')">
                    <ng-content select="p-footer"></ng-content>
                    <ng-container *ngTemplateOutlet="footerTemplate || _footerTemplate"></ng-container>
                </div>
            }
        </div>
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [CardStyle, { provide: CARD_INSTANCE, useExisting: Card }, { provide: PARENT_INSTANCE, useExisting: Card }],
                    host: {
                        '[class]': "cn(cx('root'), styleClass())",
                        '[style]': '_style()'
                    },
                    hostDirectives: [Bind]
                }]
        }], ctorParameters: () => [], propDecorators: { header: [{ type: i0.Input, args: [{ isSignal: true, alias: "header", required: false }] }], subheader: [{ type: i0.Input, args: [{ isSignal: true, alias: "subheader", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], headerFacet: [{ type: i0.ContentChild, args: [i0.forwardRef(() => Header), { isSignal: true }] }], footerFacet: [{ type: i0.ContentChild, args: [i0.forwardRef(() => Footer), { isSignal: true }] }], headerTemplate: [{
                type: ContentChild,
                args: ['header', { descendants: false }]
            }], titleTemplate: [{
                type: ContentChild,
                args: ['title', { descendants: false }]
            }], subtitleTemplate: [{
                type: ContentChild,
                args: ['subtitle', { descendants: false }]
            }], contentTemplate: [{ type: i0.ContentChild, args: ['content', { ...{ descendants: false }, isSignal: true }] }], footerTemplate: [{
                type: ContentChild,
                args: ['footer', { descendants: false }]
            }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class CardModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CardModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: CardModule, imports: [Card, SharedModule, BindModule], exports: [Card, SharedModule, BindModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CardModule, imports: [Card, SharedModule, BindModule, SharedModule, BindModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CardModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [Card, SharedModule, BindModule],
                    exports: [Card, SharedModule, BindModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { Card, CardClasses, CardModule, CardStyle };
//# sourceMappingURL=wawjs-ngx-prime-card.mjs.map
