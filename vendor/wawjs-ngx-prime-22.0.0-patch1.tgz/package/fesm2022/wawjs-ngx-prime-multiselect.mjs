export * from '@wawjs/ngx-prime/types/multiselect';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, forwardRef, inject, input, booleanAttribute, numberAttribute, output, ViewEncapsulation, Component, NgZone, model, viewChild, contentChild, signal, contentChildren, computed, effect, ContentChild, ChangeDetectionStrategy, NgModule } from '@angular/core';
import * as i2 from '@angular/forms';
import { NG_VALUE_ACCESSOR, FormsModule } from '@angular/forms';
import { uuid, isNotEmpty, isArray, deepEquals, equals, focus, findLastIndex, resolveFieldData, isPrintableCharacter, getFirstFocusableElement, getLastFocusableElement, findSingle, getFocusableElements } from '@wawjs/css-prime-utils';
import { SharedModule, FilterService, OverlayService, Footer, Header, PrimeTemplate, TranslationKeys } from '@wawjs/ngx-prime/api';
import { AutoFocus } from '@wawjs/ngx-prime/autofocus';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import { BaseEditableHolder } from '@wawjs/ngx-prime/baseeditableholder';
import * as i3 from '@wawjs/ngx-prime/bind';
import { Bind, BindModule } from '@wawjs/ngx-prime/bind';
import { Checkbox } from '@wawjs/ngx-prime/checkbox';
import { Chip } from '@wawjs/ngx-prime/chip';
import { DomHandler, unblockBodyScroll } from '@wawjs/ngx-prime/dom';
import { Fluid } from '@wawjs/ngx-prime/fluid';
import { IconField } from '@wawjs/ngx-prime/iconfield';
import { CheckIcon, SearchIcon, TimesIcon, ChevronDownIcon } from '@wawjs/ngx-prime/icons';
import { InputIcon } from '@wawjs/ngx-prime/inputicon';
import { InputText } from '@wawjs/ngx-prime/inputtext';
import { Overlay } from '@wawjs/ngx-prime/overlay';
import { Scroller } from '@wawjs/ngx-prime/scroller';
import { Tooltip } from '@wawjs/ngx-prime/tooltip';
import { ObjectUtils } from '@wawjs/ngx-prime/utils';
import { style as style$1 } from '@wawjs/css-prime-styles/multiselect';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const style = /*css*/ `
    ${style$1}

    /* For ngx-prime */
   .p-multiselect.ng-invalid.ng-dirty {
        border-color: dt('multiselect.invalid.border.color');
    }
    p-multiSelect.ng-invalid.ng-dirty .p-multiselect-label.p-placeholder,
    p-multi-select.ng-invalid.ng-dirty .p-multiselect-label.p-placeholder,
    p-multiselect.ng-invalid.ng-dirty .p-multiselect-label.p-placeholder {
        color: dt('multiselect.invalid.placeholder.color');
    }
`;
const inlineStyles = {
    root: ({ instance }) => ({ position: instance.$appendTo() === 'self' ? 'relative' : undefined })
};
const classes = {
    root: ({ instance }) => [
        'p-multiselect p-component p-inputwrapper',
        {
            'p-multiselect p-component p-inputwrapper': true,
            'p-multiselect-display-chip': instance.display === 'chip',
            'p-disabled': instance.$disabled(),
            'p-invalid': instance.invalid(),
            'p-variant-filled': instance.$variant() === 'filled',
            'p-focus': instance.focused,
            'p-inputwrapper-filled': instance.$filled(),
            'p-inputwrapper-focus': instance.focused || instance.overlayVisible,
            'p-multiselect-open': instance.overlayVisible,
            'p-multiselect-fluid': instance.hasFluid,
            'p-multiselect-sm p-inputfield-sm': instance.size() === 'small',
            'p-multiselect-lg p-inputfield-lg': instance.size() === 'large'
        }
    ],
    labelContainer: 'p-multiselect-label-container',
    label: ({ instance }) => ({
        'p-multiselect-label': true,
        'p-placeholder': instance.label() === instance.placeholder(),
        'p-multiselect-label-empty': !instance.placeholder() && !instance.defaultLabel && (!instance.modelValue() || instance.modelValue().length === 0)
    }),
    chipItem: 'p-multiselect-chip-item',
    pcChip: 'p-multiselect-chip',
    chipIcon: 'p-multiselect-chip-icon',
    dropdown: 'p-multiselect-dropdown',
    loadingIcon: 'p-multiselect-loading-icon',
    dropdownIcon: 'p-multiselect-dropdown-icon',
    overlay: 'p-multiselect-overlay p-component-overlay p-component',
    header: 'p-multiselect-header',
    pcFilterContainer: 'p-multiselect-filter-container',
    pcFilter: 'p-multiselect-filter',
    listContainer: 'p-multiselect-list-container',
    list: 'p-multiselect-list',
    optionGroup: 'p-multiselect-option-group',
    option: ({ instance }) => ({
        'p-multiselect-option': true,
        'p-multiselect-option-selected': instance.selected && instance.highlightOnSelect,
        'p-disabled': instance.disabled,
        'p-focus': instance.focused
    }),
    emptyMessage: 'p-multiselect-empty-message',
    clearIcon: 'p-multiselect-clear-icon'
};
class MultiSelectStyle extends BaseStyle {
    name = 'multiselect';
    style = style;
    classes = classes;
    inlineStyles = inlineStyles;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MultiSelectStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MultiSelectStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MultiSelectStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * MultiSelect is used to select multiple items from a collection.
 *
 * [Live Demo](https://www.ngx-prime.org/multiselect/)
 *
 * @module multiselectstyle
 *
 */
var MultiSelectClasses;
(function (MultiSelectClasses) {
    /**
     * Class name of the root element
     */
    MultiSelectClasses["root"] = "p-multiselect";
    /**
     * Class name of the label container element
     */
    MultiSelectClasses["labelContainer"] = "p-multiselect-label-container";
    /**
     * Class name of the label element
     */
    MultiSelectClasses["label"] = "p-multiselect-label";
    /**
     * Class name of the chip item element
     */
    MultiSelectClasses["chipItem"] = "p-multiselect-chip-item";
    /**
     * Class name of the chip element
     */
    MultiSelectClasses["pcChip"] = "p-multiselect-chip";
    /**
     * Class name of the chip icon element
     */
    MultiSelectClasses["chipIcon"] = "p-multiselect-chip-icon";
    /**
     * Class name of the dropdown element
     */
    MultiSelectClasses["dropdown"] = "p-multiselect-dropdown";
    /**
     * Class name of the loading icon element
     */
    MultiSelectClasses["loadingIcon"] = "p-multiselect-loading-icon";
    /**
     * Class name of the dropdown icon element
     */
    MultiSelectClasses["dropdownIcon"] = "p-multiselect-dropdown-icon";
    /**
     * Class name of the overlay element
     */
    MultiSelectClasses["overlay"] = "p-multiselect-overlay";
    /**
     * Class name of the header element
     */
    MultiSelectClasses["header"] = "p-multiselect-header";
    /**
     * Class name of the filter container element
     */
    MultiSelectClasses["pcFilterContainer"] = "p-multiselect-filter-container";
    /**
     * Class name of the filter element
     */
    MultiSelectClasses["pcFilter"] = "p-multiselect-filter";
    /**
     * Class name of the list container element
     */
    MultiSelectClasses["listContainer"] = "p-multiselect-list-container";
    /**
     * Class name of the list element
     */
    MultiSelectClasses["list"] = "p-multiselect-list";
    /**
     * Class name of the option group element
     */
    MultiSelectClasses["optionGroup"] = "p-multiselect-option-group";
    /**
     * Class name of the option element
     */
    MultiSelectClasses["option"] = "p-multiselect-option";
    /**
     * Class name of the empty message element
     */
    MultiSelectClasses["emptyMessage"] = "p-multiselect-empty-message";
    /**
     * Class name of the clear icon
     */
    MultiSelectClasses["clearIcon"] = "p-autocomplete-clear-icon";
})(MultiSelectClasses || (MultiSelectClasses = {}));

const MULTISELECT_INSTANCE = new InjectionToken('MULTISELECT_INSTANCE');
const MULTISELECT_ITEM_INSTANCE = new InjectionToken('MULTISELECT_ITEM_INSTANCE');
const MULTISELECT_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => MultiSelect),
    multi: true
};
class MultiSelectItem extends BaseComponent {
    $pcMultiSelectItem = inject(MULTISELECT_ITEM_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    hostName = 'MultiSelect';
    getPTOptions(key) {
        return this.ptm(key, {
            context: {
                selected: this.selected(),
                focused: this.focused(),
                disabled: this.disabled()
            }
        });
    }
    option = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "option" }] : /* istanbul ignore next */ []));
    selected = input(undefined, { ...(ngDevMode ? { debugName: "selected" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    label = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "label" }] : /* istanbul ignore next */ []));
    disabled = input(undefined, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    itemSize = input(undefined, { ...(ngDevMode ? { debugName: "itemSize" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    focused = input(undefined, { ...(ngDevMode ? { debugName: "focused" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    ariaPosInset = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaPosInset" }] : /* istanbul ignore next */ []));
    ariaSetSize = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaSetSize" }] : /* istanbul ignore next */ []));
    variant = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    template = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "template" }] : /* istanbul ignore next */ []));
    checkIconTemplate = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "checkIconTemplate" }] : /* istanbul ignore next */ []));
    itemCheckboxIconTemplate = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "itemCheckboxIconTemplate" }] : /* istanbul ignore next */ []));
    highlightOnSelect = input(undefined, { ...(ngDevMode ? { debugName: "highlightOnSelect" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    onClick = output();
    onMouseEnter = output();
    _componentStyle = inject(MultiSelectStyle);
    onOptionClick(event) {
        this.onClick.emit({
            originalEvent: event,
            option: this.option(),
            selected: this.selected()
        });
        event.stopPropagation();
        event.preventDefault();
    }
    onOptionMouseEnter(event) {
        this.onMouseEnter.emit({
            originalEvent: event,
            option: this.option(),
            selected: this.selected()
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MultiSelectItem, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: MultiSelectItem, isStandalone: true, selector: "li[pMultiSelectItem]", inputs: { option: { classPropertyName: "option", publicName: "option", isSignal: true, isRequired: false, transformFunction: null }, selected: { classPropertyName: "selected", publicName: "selected", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, itemSize: { classPropertyName: "itemSize", publicName: "itemSize", isSignal: true, isRequired: false, transformFunction: null }, focused: { classPropertyName: "focused", publicName: "focused", isSignal: true, isRequired: false, transformFunction: null }, ariaPosInset: { classPropertyName: "ariaPosInset", publicName: "ariaPosInset", isSignal: true, isRequired: false, transformFunction: null }, ariaSetSize: { classPropertyName: "ariaSetSize", publicName: "ariaSetSize", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, template: { classPropertyName: "template", publicName: "template", isSignal: true, isRequired: false, transformFunction: null }, checkIconTemplate: { classPropertyName: "checkIconTemplate", publicName: "checkIconTemplate", isSignal: true, isRequired: false, transformFunction: null }, itemCheckboxIconTemplate: { classPropertyName: "itemCheckboxIconTemplate", publicName: "itemCheckboxIconTemplate", isSignal: true, isRequired: false, transformFunction: null }, highlightOnSelect: { classPropertyName: "highlightOnSelect", publicName: "highlightOnSelect", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onClick: "onClick", onMouseEnter: "onMouseEnter" }, host: { attributes: { "role": "option" }, listeners: { "click": "onOptionClick($event)", "mouseenter": "onOptionMouseEnter($event)" }, properties: { "style.height.px": "itemSize()", "attr.aria-label": "label()", "attr.aria-setsize": "ariaSetSize()", "attr.aria-posinset": "ariaPosInset()", "attr.aria-selected": "selected()", "attr.data-p-selected": "selected()", "attr.data-p-focused": "focused()", "attr.data-p-highlight": "selected()", "attr.data-p-disabled": "disabled()", "attr.aria-checked": "selected()", "class": "cx('option')" } }, providers: [MultiSelectStyle], usesInheritance: true, ngImport: i0, template: `
        <p-checkbox [ngModel]="selected()" [binary]="true" [tabindex]="-1" [variant]="variant()" [ariaLabel]="label()" [pt]="getPTOptions('pcOptionCheckbox')" [unstyled]="unstyled()">
            @if (itemCheckboxIconTemplate()) {
                <ng-template #icon let-klass="class">
                    <ng-template *ngTemplateOutlet="itemCheckboxIconTemplate(); context: { checked: selected(), class: klass }"></ng-template>
                </ng-template>
            }
        </p-checkbox>
        @if (!template()) {
            <span>{{ label() ?? 'empty' }}</span>
        }
        <ng-container *ngTemplateOutlet="template(); context: { $implicit: option() }"></ng-container>
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: Checkbox, selector: "p-checkbox, p-checkBox, p-check-box", inputs: ["hostName", "value", "binary", "ariaLabelledBy", "ariaLabel", "tabindex", "inputId", "inputStyle", "styleClass", "inputClass", "indeterminate", "formControl", "checkboxIcon", "readonly", "autofocus", "trueValue", "falseValue", "variant", "size"], outputs: ["onChange", "onFocus", "onBlur"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: SharedModule }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MultiSelectItem, decorators: [{
            type: Component,
            args: [{
                    selector: 'li[pMultiSelectItem]',
                    standalone: true,
                    imports: [CommonModule, Checkbox, FormsModule, SharedModule],
                    template: `
        <p-checkbox [ngModel]="selected()" [binary]="true" [tabindex]="-1" [variant]="variant()" [ariaLabel]="label()" [pt]="getPTOptions('pcOptionCheckbox')" [unstyled]="unstyled()">
            @if (itemCheckboxIconTemplate()) {
                <ng-template #icon let-klass="class">
                    <ng-template *ngTemplateOutlet="itemCheckboxIconTemplate(); context: { checked: selected(), class: klass }"></ng-template>
                </ng-template>
            }
        </p-checkbox>
        @if (!template()) {
            <span>{{ label() ?? 'empty' }}</span>
        }
        <ng-container *ngTemplateOutlet="template(); context: { $implicit: option() }"></ng-container>
    `,
                    encapsulation: ViewEncapsulation.None,
                    providers: [MultiSelectStyle],
                    host: {
                        '[style.height.px]': 'itemSize()',
                        '[attr.aria-label]': 'label()',
                        role: 'option',
                        '[attr.aria-setsize]': 'ariaSetSize()',
                        '[attr.aria-posinset]': 'ariaPosInset()',
                        '[attr.aria-selected]': 'selected()',
                        '[attr.data-p-selected]': 'selected()',
                        '[attr.data-p-focused]': 'focused()',
                        '[attr.data-p-highlight]': 'selected()',
                        '[attr.data-p-disabled]': 'disabled()',
                        '[attr.aria-checked]': 'selected()',
                        '(click)': 'onOptionClick($event)',
                        '(mouseenter)': 'onOptionMouseEnter($event)',
                        '[class]': "cx('option')"
                    }
                }]
        }], propDecorators: { option: [{ type: i0.Input, args: [{ isSignal: true, alias: "option", required: false }] }], selected: [{ type: i0.Input, args: [{ isSignal: true, alias: "selected", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], itemSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemSize", required: false }] }], focused: [{ type: i0.Input, args: [{ isSignal: true, alias: "focused", required: false }] }], ariaPosInset: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaPosInset", required: false }] }], ariaSetSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaSetSize", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], template: [{ type: i0.Input, args: [{ isSignal: true, alias: "template", required: false }] }], checkIconTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "checkIconTemplate", required: false }] }], itemCheckboxIconTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemCheckboxIconTemplate", required: false }] }], highlightOnSelect: [{ type: i0.Input, args: [{ isSignal: true, alias: "highlightOnSelect", required: false }] }], onClick: [{ type: i0.Output, args: ["onClick"] }], onMouseEnter: [{ type: i0.Output, args: ["onMouseEnter"] }] } });
/**
 * MultiSelect is used to select multiple items from a collection.
 * @group Components
 */
class MultiSelect extends BaseEditableHolder {
    zone = inject(NgZone);
    filterService = inject(FilterService);
    overlayService = inject(OverlayService);
    componentName = 'MultiSelect';
    /**
     * Unique identifier of the component
     * @group Props
     */
    id = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "id" }] : /* istanbul ignore next */ []));
    _generatedId;
    get resolvedId() {
        return this.id() || (this._generatedId ??= uuid('pn_id_'));
    }
    /**
     * Defines a string that labels the input for accessibility.
     * @group Props
     */
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the element.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Inline style of the overlay panel.
     * @group Props
     */
    panelStyle = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "panelStyle" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the overlay panel element.
     * @group Props
     */
    panelStyleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "panelStyleClass" }] : /* istanbul ignore next */ []));
    /**
     * Identifier of the focus input to match a label defined for the component.
     * @group Props
     */
    inputId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "inputId" }] : /* istanbul ignore next */ []));
    /**
     * When present, it specifies that the component cannot be edited.
     * @group Props
     */
    readonly = input(undefined, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to display options as grouped when nested options are provided.
     * @group Props
     */
    group = input(undefined, { ...(ngDevMode ? { debugName: "group" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * When specified, displays an input field to filter the items on keyup.
     * @group Props
     */
    filter = input(true, { ...(ngDevMode ? { debugName: "filter" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Defines placeholder of the filter input.
     * @group Props
     */
    filterPlaceHolder = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "filterPlaceHolder" }] : /* istanbul ignore next */ []));
    /**
     * Locale to use in filtering. The default locale is the host environment's current locale.
     * @group Props
     */
    filterLocale = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "filterLocale" }] : /* istanbul ignore next */ []));
    /**
     * Specifies the visibility of the options panel.
     * @group Props
     */
    overlayVisible = model(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "overlayVisible" }] : /* istanbul ignore next */ []));
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    tabindex = input(0, { ...(ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * A property to uniquely identify a value in options.
     * @group Props
     */
    dataKey = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "dataKey" }] : /* istanbul ignore next */ []));
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    /**
     * Whether to show labels of selected item labels or use default label.
     * @group Props
     * @defaultValue true
     */
    displaySelectedLabel = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "displaySelectedLabel" }] : /* istanbul ignore next */ []));
    /**
     * Decides how many selected item labels to show at most.
     * @group Props
     * @defaultValue 3
     */
    maxSelectedLabels = input(3, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "maxSelectedLabels" }] : /* istanbul ignore next */ []));
    /**
     * Maximum number of selectable items.
     * @group Props
     */
    selectionLimit = input(undefined, { ...(ngDevMode ? { debugName: "selectionLimit" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Label to display after exceeding max selected labels e.g. ({0} items selected), defaults "ellipsis" keyword to indicate a text-overflow.
     * @group Props
     */
    selectedItemsLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "selectedItemsLabel" }] : /* istanbul ignore next */ []));
    /**
     * Whether to show the checkbox at header to toggle all items at once.
     * @group Props
     */
    showToggleAll = input(true, { ...(ngDevMode ? { debugName: "showToggleAll" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Text to display when filtering does not return any results.
     * @group Props
     */
    emptyFilterMessage = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyFilterMessage" }] : /* istanbul ignore next */ []));
    /**
     * Text to display when there is no data. Defaults to global value in i18n translation configuration.
     * @group Props
     */
    emptyMessage = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptyMessage" }] : /* istanbul ignore next */ []));
    /**
     * Clears the filter value when hiding the dropdown.
     * @group Props
     */
    resetFilterOnHide = input(false, { ...(ngDevMode ? { debugName: "resetFilterOnHide" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Icon class of the dropdown icon.
     * @group Props
     */
    dropdownIcon = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "dropdownIcon" }] : /* istanbul ignore next */ []));
    /**
     * Icon class of the chip icon.
     * @group Props
     */
    chipIcon = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "chipIcon" }] : /* istanbul ignore next */ []));
    /**
     * Name of the label field of an option.
     * @group Props
     */
    optionLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "optionLabel" }] : /* istanbul ignore next */ []));
    /**
     * Name of the value field of an option.
     * @group Props
     */
    optionValue = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "optionValue" }] : /* istanbul ignore next */ []));
    /**
     * Name of the disabled field of an option.
     * @group Props
     */
    optionDisabled = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "optionDisabled" }] : /* istanbul ignore next */ []));
    /**
     * Name of the label field of an option group.
     * @group Props
     */
    optionGroupLabel = input('label', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "optionGroupLabel" }] : /* istanbul ignore next */ []));
    /**
     * Name of the options field of an option group.
     * @group Props
     */
    optionGroupChildren = input('items', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "optionGroupChildren" }] : /* istanbul ignore next */ []));
    /**
     * Whether to show the header.
     * @group Props
     */
    showHeader = input(true, { ...(ngDevMode ? { debugName: "showHeader" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * When filtering is enabled, filterBy decides which field or fields (comma separated) to search against.
     * @group Props
     */
    filterBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "filterBy" }] : /* istanbul ignore next */ []));
    /**
     * Height of the viewport in pixels, a scrollbar is defined if height of list exceeds this value.
     * @group Props
     */
    scrollHeight = input('200px', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scrollHeight" }] : /* istanbul ignore next */ []));
    /**
     * Defines if data is loaded and interacted with in lazy manner.
     * @group Props
     */
    lazy = input(false, { ...(ngDevMode ? { debugName: "lazy" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether the data should be loaded on demand during scroll.
     * @group Props
     */
    virtualScroll = input(undefined, { ...(ngDevMode ? { debugName: "virtualScroll" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether the multiselect is in loading state.
     * @group Props
     */
    loading = input(false, { ...(ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Height of an item in the list for VirtualScrolling.
     * @group Props
     */
    virtualScrollItemSize = input(undefined, { ...(ngDevMode ? { debugName: "virtualScrollItemSize" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Icon to display in loading state.
     * @group Props
     */
    loadingIcon = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "loadingIcon" }] : /* istanbul ignore next */ []));
    /**
     * Whether to use the scroller feature. The properties of scroller component can be used like an object in it.
     * @group Props
     */
    virtualScrollOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "virtualScrollOptions" }] : /* istanbul ignore next */ []));
    /**
     * Whether to use overlay API feature. The properties of overlay API can be used like an object in it.
     * @group Props
     */
    overlayOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "overlayOptions" }] : /* istanbul ignore next */ []));
    /**
     * Defines a string that labels the filter input.
     * @group Props
     */
    ariaFilterLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaFilterLabel" }] : /* istanbul ignore next */ []));
    /**
     * Defines how the items are filtered.
     * @group Props
     */
    filterMatchMode = input('contains', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterMatchMode" }] : /* istanbul ignore next */ []));
    /**
     * Advisory information to display in a tooltip on hover.
     * @group Props
     */
    tooltip = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltip" }] : /* istanbul ignore next */ []));
    /**
     * Position of the tooltip.
     * @group Props
     */
    tooltipPosition = input('right', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltipPosition" }] : /* istanbul ignore next */ []));
    /**
     * Type of CSS position.
     * @group Props
     */
    tooltipPositionStyle = input('absolute', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tooltipPositionStyle" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the tooltip.
     * @group Props
     */
    tooltipStyleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "tooltipStyleClass" }] : /* istanbul ignore next */ []));
    /**
     * Applies focus to the filter element when the overlay is shown.
     * @group Props
     */
    autofocusFilter = input(false, { ...(ngDevMode ? { debugName: "autofocusFilter" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Defines how the selected items are displayed.
     * @group Props
     */
    display = input('comma', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "display" }] : /* istanbul ignore next */ []));
    /**
     * Defines the autocomplete is active.
     * @group Props
     */
    autocomplete = input('off', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "autocomplete" }] : /* istanbul ignore next */ []));
    /**
     * When enabled, a clear icon is displayed to clear the value.
     * @group Props
     */
    showClear = input(false, { ...(ngDevMode ? { debugName: "showClear" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    autofocus = input(undefined, { ...(ngDevMode ? { debugName: "autofocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Label to display when there are no selections.
     * @group Props
     */
    placeholder = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "placeholder" }] : /* istanbul ignore next */ []));
    /**
     * An array of objects to display as the available options.
     * @group Props
     */
    options = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "options" }] : /* istanbul ignore next */ []));
    /**
     * When specified, filter displays with this value.
     * @group Props
     */
    filterValue = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "filterValue" }] : /* istanbul ignore next */ []));
    /**
     * Whether all data is selected.
     * @group Props
     */
    selectAll = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "selectAll" }] : /* istanbul ignore next */ []));
    /**
     * Indicates whether to focus on options when hovering over them, defaults to optionLabel.
     * @group Props
     */
    focusOnHover = input(true, { ...(ngDevMode ? { debugName: "focusOnHover" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Fields used when filtering the options, defaults to optionLabel.
     * @group Props
     */
    filterFields = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "filterFields" }] : /* istanbul ignore next */ []));
    /**
     * Determines if the option will be selected on focus.
     * @group Props
     */
    selectOnFocus = input(false, { ...(ngDevMode ? { debugName: "selectOnFocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to focus on the first visible or selected element when the overlay panel is shown.
     * @group Props
     */
    autoOptionFocus = input(false, { ...(ngDevMode ? { debugName: "autoOptionFocus" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether the selected option will be add highlight class.
     * @group Props
     */
    highlightOnSelect = input(true, { ...(ngDevMode ? { debugName: "highlightOnSelect" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Specifies the size of the component.
     * @defaultValue undefined
     * @group Props
     */
    size = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "size" }] : /* istanbul ignore next */ []));
    /**
     * Specifies the input variant of the component.
     * @defaultValue undefined
     * @group Props
     */
    variant = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "variant" }] : /* istanbul ignore next */ []));
    /**
     * Spans 100% width of the container when enabled.
     * @defaultValue undefined
     * @group Props
     */
    fluid = input(undefined, { ...(ngDevMode ? { debugName: "fluid" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'self'
     * @group Props
     */
    appendTo = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "appendTo" }] : /* istanbul ignore next */ []));
    /**
     * The motion options.
     * @group Props
     */
    motionOptions = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "motionOptions" }] : /* istanbul ignore next */ []));
    /**
     * Callback to invoke when value changes.
     * @param {MultiSelectChangeEvent} event - Custom change event.
     * @group Emits
     */
    onChange = output();
    /**
     * Callback to invoke when data is filtered.
     * @param {MultiSelectFilterEvent} event - Custom filter event.
     * @group Emits
     */
    onFilter = output();
    /**
     * Callback to invoke when multiselect receives focus.
     * @param {MultiSelectFocusEvent} event - Custom focus event.
     * @group Emits
     */
    onFocus = output();
    /**
     * Callback to invoke when multiselect loses focus.
     * @param {MultiSelectBlurEvent} event - Custom blur event.
     * @group Emits
     */
    onBlur = output();
    /**
     * Callback to invoke when component is clicked.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    onClick = output();
    /**
     * Callback to invoke when input field is cleared.
     * @group Emits
     */
    onClear = output();
    /**
     * Callback to invoke when overlay panel becomes visible.
     * @param {AnimationEvent} event - Animation event.
     * @group Emits
     */
    onPanelShow = output();
    /**
     * Callback to invoke when overlay panel becomes hidden.
     * @param {AnimationEvent} event - Animation event.
     * @group Emits
     */
    onPanelHide = output();
    /**
     * Callback to invoke in lazy mode to load new data.
     * @param {MultiSelectLazyLoadEvent} event - Lazy load event.
     * @group Emits
     */
    onLazyLoad = output();
    /**
     * Callback to invoke in lazy mode to load new data.
     * @param {MultiSelectRemoveEvent} event - Remove event.
     * @group Emits
     */
    onRemove = output();
    /**
     * Callback to invoke when all data is selected.
     * @param {MultiSelectSelectAllChangeEvent} event - Custom select event.
     * @group Emits
     */
    onSelectAllChange = output();
    overlayViewChild = viewChild('overlay', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "overlayViewChild" }] : /* istanbul ignore next */ []));
    filterInputChild = viewChild('filterInput', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterInputChild" }] : /* istanbul ignore next */ []));
    focusInputViewChild = viewChild('focusInput', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusInputViewChild" }] : /* istanbul ignore next */ []));
    itemsViewChild = viewChild('items', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "itemsViewChild" }] : /* istanbul ignore next */ []));
    scroller = viewChild('scroller', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scroller" }] : /* istanbul ignore next */ []));
    lastHiddenFocusableElementOnOverlay = viewChild('lastHiddenFocusableEl', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "lastHiddenFocusableElementOnOverlay" }] : /* istanbul ignore next */ []));
    firstHiddenFocusableElementOnOverlay = viewChild('firstHiddenFocusableEl', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "firstHiddenFocusableElementOnOverlay" }] : /* istanbul ignore next */ []));
    headerCheckboxViewChild = viewChild('headerCheckbox', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "headerCheckboxViewChild" }] : /* istanbul ignore next */ []));
    footerFacet = contentChild(Footer, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "footerFacet" }] : /* istanbul ignore next */ []));
    headerFacet = contentChild(Header, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "headerFacet" }] : /* istanbul ignore next */ []));
    _componentStyle = inject(MultiSelectStyle);
    bindDirectiveInstance = inject(Bind, { self: true });
    searchValue;
    searchTimeout;
    _selectAll = null;
    _placeholder = signal(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_placeholder" }] : /* istanbul ignore next */ []));
    _disableTooltip = false;
    value;
    _filteredOptions;
    focus;
    filtered;
    /**
     * Custom item template.
     * @group Templates
     */
    itemTemplate = contentChild('item', { ...(ngDevMode ? { debugName: "itemTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom group template.
     * @group Templates
     */
    groupTemplate;
    /**
     * Custom loader template.
     * @group Templates
     */
    loaderTemplate;
    /**
     * Custom header template.
     * @group Templates
     */
    headerTemplate = contentChild('header', { ...(ngDevMode ? { debugName: "headerTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom filter template.
     * @group Templates
     */
    filterTemplate;
    /**
     * Custom footer template.
     * @group Templates
     */
    footerTemplate;
    /**
     * Custom empty filter template.
     * @group Templates
     */
    emptyFilterTemplate = contentChild('emptyfilter', { ...(ngDevMode ? { debugName: "emptyFilterTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom empty template.
     * @group Templates
     */
    emptyTemplate = contentChild('empty', { ...(ngDevMode ? { debugName: "emptyTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom selected items template.
     * @group Templates
     */
    selectedItemsTemplate;
    /**
     * Custom loading icon template.
     * @group Templates
     */
    loadingIconTemplate;
    /**
     * Custom filter icon template.
     * @group Templates
     */
    filterIconTemplate;
    /**
     * Custom remove token icon template.
     * @group Templates
     */
    removeTokenIconTemplate;
    /**
     * Custom chip icon template.
     * @group Templates
     */
    chipIconTemplate;
    /**
     * Custom clear icon template.
     * @group Templates
     */
    clearIconTemplate;
    /**
     * Custom dropdown icon template.
     * @group Templates
     */
    dropdownIconTemplate;
    /**
     * Custom item checkbox icon template.
     * @group Templates
     */
    itemCheckboxIconTemplate = contentChild('itemcheckboxicon', { ...(ngDevMode ? { debugName: "itemCheckboxIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom header checkbox icon template.
     * @group Templates
     */
    headerCheckboxIconTemplate = contentChild('headercheckboxicon', { ...(ngDevMode ? { debugName: "headerCheckboxIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    _itemTemplate;
    _groupTemplate;
    _loaderTemplate;
    _headerTemplate;
    _filterTemplate;
    _footerTemplate;
    _emptyFilterTemplate;
    _emptyTemplate;
    _selectedItemsTemplate;
    _loadingIconTemplate;
    _filterIconTemplate;
    _removeTokenIconTemplate;
    _chipIconTemplate;
    _clearIconTemplate;
    _dropdownIconTemplate;
    _itemCheckboxIconTemplate;
    _headerCheckboxIconTemplate;
    $variant = computed(() => this.variant() || this.config.inputStyle() || this.config.inputVariant(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "$variant" }] : /* istanbul ignore next */ []));
    $appendTo = computed(() => this.appendTo() || this.config.overlayAppendTo(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "$appendTo" }] : /* istanbul ignore next */ []));
    $pcMultiSelect = inject(MULTISELECT_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    pcFluid = inject(Fluid, { optional: true, host: true, skipSelf: true });
    get hasFluid() {
        return this.fluid() ?? !!this.pcFluid;
    }
    onAfterContentInit() {
        this.templates().forEach((item) => {
            switch (item.getType()) {
                case 'item':
                    this._itemTemplate = item.template;
                    break;
                case 'group':
                    this._groupTemplate = item.template;
                    break;
                case 'selectedItems':
                case 'selecteditems':
                    this._selectedItemsTemplate = item.template;
                    break;
                case 'header':
                    this._headerTemplate = item.template;
                    break;
                case 'filter':
                    this._filterTemplate = item.template;
                    break;
                case 'emptyfilter':
                    this._emptyFilterTemplate = item.template;
                    break;
                case 'empty':
                    this._emptyTemplate = item.template;
                    break;
                case 'footer':
                    this._footerTemplate = item.template;
                    break;
                case 'loader':
                    this._loaderTemplate = item.template;
                    break;
                case 'headercheckboxicon':
                    this._headerCheckboxIconTemplate = item.template;
                    break;
                case 'loadingicon':
                    this._loadingIconTemplate = item.template;
                    break;
                case 'filtericon':
                    this._filterIconTemplate = item.template;
                    break;
                case 'removetokenicon':
                    this._removeTokenIconTemplate = item.template;
                    break;
                case 'clearicon':
                    this._clearIconTemplate = item.template;
                    break;
                case 'dropdownicon':
                    this._dropdownIconTemplate = item.template;
                    break;
                case 'itemcheckboxicon':
                    this._itemCheckboxIconTemplate = item.template;
                    break;
                case 'chipicon':
                    this._chipIconTemplate = item.template;
                    break;
                default:
                    this._itemTemplate = item.template;
                    break;
            }
        });
    }
    headerCheckboxFocus;
    filterOptions;
    preventModelTouched;
    focused = false;
    itemsWrapper;
    _displaySelectedLabel = true;
    _maxSelectedLabels = 3;
    modelValue = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "modelValue" }] : /* istanbul ignore next */ []));
    _filterValue = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_filterValue" }] : /* istanbul ignore next */ []));
    _options = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_options" }] : /* istanbul ignore next */ []));
    startRangeIndex = signal(-1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "startRangeIndex" }] : /* istanbul ignore next */ []));
    focusedOptionIndex = signal(-1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusedOptionIndex" }] : /* istanbul ignore next */ []));
    selectedOptions;
    clickInProgress = false;
    get emptyMessageLabel() {
        return this.emptyMessage() || this.config.getTranslation(TranslationKeys.EMPTY_MESSAGE);
    }
    get emptyFilterMessageLabel() {
        return this.emptyFilterMessage() || this.config.getTranslation(TranslationKeys.EMPTY_FILTER_MESSAGE);
    }
    get isVisibleClearIcon() {
        return this.modelValue() != null && this.modelValue() !== '' && isNotEmpty(this.modelValue()) && this.showClear() && !this.$disabled() && !this.readonly() && this.$filled();
    }
    get toggleAllAriaLabel() {
        return this.config.translation.aria ? this.config.translation.aria[this.allSelected() ? 'selectAll' : 'unselectAll'] : undefined;
    }
    get listLabel() {
        return this.config.getTranslation(TranslationKeys.ARIA)['listLabel'];
    }
    getAllVisibleAndNonVisibleOptions() {
        return this.group() ? this.flatOptions(this.options) : this.options || [];
    }
    visibleOptions = computed(() => {
        const options = this.getAllVisibleAndNonVisibleOptions();
        const isArrayOfObjects = isArray(options) && ObjectUtils.isObject(options[0]);
        if (this._filterValue()) {
            let filteredOptions;
            if (isArrayOfObjects) {
                filteredOptions = this.filterService.filter(options, this.searchFields(), this._filterValue(), this.filterMatchMode(), this.filterLocale());
            }
            else {
                filteredOptions = options.filter((option) => option.toString().toLocaleLowerCase().includes(this._filterValue().toLocaleLowerCase()));
            }
            if (this.group()) {
                const optionGroups = this._options() || [];
                const filtered = [];
                optionGroups.forEach((group) => {
                    const groupChildren = this.getOptionGroupChildren(group);
                    const filteredItems = groupChildren.filter((item) => filteredOptions.includes(item));
                    const optionGroupChildren = this.optionGroupChildren();
                    if (filteredItems.length > 0)
                        filtered.push({
                            ...group,
                            [typeof optionGroupChildren === 'string' ? optionGroupChildren : 'items']: [...filteredItems]
                        });
                });
                return this.flatOptions(filtered);
            }
            return filteredOptions;
        }
        return options;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visibleOptions" }] : /* istanbul ignore next */ []));
    label = computed(() => {
        let label;
        const modelValue = this.modelValue();
        if (modelValue && modelValue?.length && this.displaySelectedLabel()) {
            if (isNotEmpty(this.maxSelectedLabels()) && modelValue?.length > (this.maxSelectedLabels() || 0)) {
                return this.getSelectedItemsLabel();
            }
            else {
                label = '';
                for (let i = 0; i < modelValue.length; i++) {
                    if (i !== 0) {
                        label += ', ';
                    }
                    label += this.getLabelByValue(modelValue[i]);
                }
            }
        }
        else {
            label = this.placeholder() || '';
        }
        return label;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    chipSelectedItems = computed(() => (isNotEmpty(this.maxSelectedLabels()) && this.modelValue() && this.modelValue()?.length > (this.maxSelectedLabels() || 0) ? this.modelValue()?.slice(0, this.maxSelectedLabels()) : this.modelValue()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "chipSelectedItems" }] : /* istanbul ignore next */ []));
    constructor() {
        super();
        effect(() => {
            const modelValue = this.modelValue();
            const allVisibleAndNonVisibleOptions = this.getAllVisibleAndNonVisibleOptions();
            if (allVisibleAndNonVisibleOptions && isNotEmpty(allVisibleAndNonVisibleOptions)) {
                if (this.optionValue() && this.optionLabel() && modelValue) {
                    this.selectedOptions = allVisibleAndNonVisibleOptions.filter((option) => modelValue.includes(option[this.optionLabel()]) || modelValue.includes(option[this.optionValue()]));
                }
                else {
                    this.selectedOptions = modelValue;
                }
                this.cd.markForCheck();
            }
        });
        effect(() => {
            this._placeholder.set(this.placeholder());
        });
        effect(() => {
            const val = this.options();
            if (!deepEquals(this._options(), val)) {
                this._options.set(val || []);
            }
        });
        effect(() => {
            this._filterValue.set(this.filterValue());
        });
    }
    onInit() {
        this.autoUpdateModel();
        if (this.filterBy()) {
            this.filterOptions = {
                filter: (value) => this.onFilterInputChange(value),
                reset: () => this.resetFilter()
            };
        }
    }
    maxSelectionLimitReached() {
        const selectionLimit = this.selectionLimit();
        return selectionLimit && this.modelValue() && this.modelValue().length === selectionLimit;
    }
    onAfterViewInit() {
        if (this.overlayVisible()) {
            this.show();
        }
    }
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
        if (this.filtered) {
            this.zone.runOutsideAngular(() => {
                setTimeout(() => {
                    this.overlayViewChild()?.alignOverlay();
                }, 1);
            });
            this.filtered = false;
        }
    }
    flatOptions(options) {
        return (options || []).reduce((result, option, index) => {
            result.push({ optionGroup: option, group: true, index });
            const optionGroupChildren = this.getOptionGroupChildren(option);
            optionGroupChildren && optionGroupChildren.forEach((o) => result.push(o));
            return result;
        }, []);
    }
    autoUpdateModel() {
        if (this.selectOnFocus() && this.autoOptionFocus() && !this.hasSelectedOption()) {
            this.focusedOptionIndex.set(this.findFirstFocusedOptionIndex());
            const value = this.getOptionValue(this.visibleOptions()[this.focusedOptionIndex()]);
            this.onOptionSelect({ originalEvent: null, option: [value] });
        }
    }
    /**
     * Updates the model value.
     * @group Method
     */
    // eslint-disable-next-line @typescript-eslint/no-unused-vars -- `event` is part of this public method's documented signature, kept for a consistent API across the select-family components.
    updateModel(value, event) {
        this.value = value;
        this.onModelChange(value);
        this.writeValue(value);
    }
    onInputClick(event) {
        event.stopPropagation();
        event.preventDefault();
        this.focusedOptionIndex.set(-1);
    }
    onOptionSelect(event, isFocus = false, index = -1) {
        const { originalEvent, option } = event;
        if (this.$disabled() || this.isOptionDisabled(option)) {
            return;
        }
        let selected = this.isSelected(option);
        let value = [];
        if (selected) {
            value = this.modelValue().filter((val) => !equals(val, this.getOptionValue(option), this.equalityKey() || ''));
        }
        else {
            value = [...(this.modelValue() || []), this.getOptionValue(option)];
        }
        this.updateModel(value, originalEvent);
        index !== -1 && this.focusedOptionIndex.set(index);
        isFocus && focus(this.focusInputViewChild()?.nativeElement);
        this.onChange.emit({
            originalEvent: event,
            value: value,
            itemValue: option
        });
    }
    findSelectedOptionIndex() {
        return this.hasSelectedOption() ? this.visibleOptions().findIndex((option) => this.isValidSelectedOption(option)) : -1;
    }
    onOptionSelectRange(event, start = -1, end = -1) {
        start === -1 && (start = this.findNearestSelectedOptionIndex(end, true));
        end === -1 && (end = this.findNearestSelectedOptionIndex(start));
        if (start !== -1 && end !== -1) {
            const rangeStart = Math.min(start, end);
            const rangeEnd = Math.max(start, end);
            const value = this.visibleOptions()
                .slice(rangeStart, rangeEnd + 1)
                .filter((option) => this.isValidOption(option))
                .map((option) => this.getOptionValue(option));
            this.updateModel(value, event);
        }
    }
    searchFields() {
        return (this.filterBy() || this.optionLabel() || 'label').split(',');
    }
    findNearestSelectedOptionIndex(index, firstCheckUp = false) {
        let matchedOptionIndex = -1;
        if (this.hasSelectedOption()) {
            if (firstCheckUp) {
                matchedOptionIndex = this.findPrevSelectedOptionIndex(index);
                matchedOptionIndex = matchedOptionIndex === -1 ? this.findNextSelectedOptionIndex(index) : matchedOptionIndex;
            }
            else {
                matchedOptionIndex = this.findNextSelectedOptionIndex(index);
                matchedOptionIndex = matchedOptionIndex === -1 ? this.findPrevSelectedOptionIndex(index) : matchedOptionIndex;
            }
        }
        return matchedOptionIndex > -1 ? matchedOptionIndex : index;
    }
    findPrevSelectedOptionIndex(index) {
        const matchedOptionIndex = this.hasSelectedOption() && index > 0 ? findLastIndex(this.visibleOptions().slice(0, index), (option) => this.isValidSelectedOption(option)) : -1;
        return matchedOptionIndex > -1 ? matchedOptionIndex : -1;
    }
    findFirstFocusedOptionIndex() {
        const selectedIndex = this.findFirstSelectedOptionIndex();
        return selectedIndex < 0 ? this.findFirstOptionIndex() : selectedIndex;
    }
    findFirstOptionIndex() {
        return this.visibleOptions().findIndex((option) => this.isValidOption(option));
    }
    findFirstSelectedOptionIndex() {
        return this.hasSelectedOption() ? this.visibleOptions().findIndex((option) => this.isValidSelectedOption(option)) : -1;
    }
    findNextSelectedOptionIndex(index) {
        const matchedOptionIndex = this.hasSelectedOption() && index < this.visibleOptions().length - 1
            ? this.visibleOptions()
                .slice(index + 1)
                .findIndex((option) => this.isValidSelectedOption(option))
            : -1;
        return matchedOptionIndex > -1 ? matchedOptionIndex + index + 1 : -1;
    }
    equalityKey() {
        return this.optionValue() ? null : this.dataKey();
    }
    hasSelectedOption() {
        return isNotEmpty(this.modelValue());
    }
    isValidSelectedOption(option) {
        return this.isValidOption(option) && this.isSelected(option);
    }
    isOptionGroup(option) {
        return option && (this.group() || this.optionGroupLabel()) && option.optionGroup && option.group;
    }
    isValidOption(option) {
        return option && !(this.isOptionDisabled(option) || this.isOptionGroup(option));
    }
    isOptionDisabled(option) {
        if (this.maxSelectionLimitReached() && !this.isSelected(option)) {
            return true;
        }
        const optionDisabled = this.optionDisabled();
        return optionDisabled ? resolveFieldData(option, optionDisabled) : option && option.disabled !== undefined ? option.disabled : false;
    }
    isSelected(option) {
        const optionValue = this.getOptionValue(option);
        return (this.modelValue() || []).some((value) => equals(value, optionValue, this.equalityKey() || ''));
    }
    isOptionMatched(option) {
        return this.isValidOption(option) && this.getOptionLabel(option).toString().toLocaleLowerCase(this.filterLocale()).startsWith(this.searchValue?.toLocaleLowerCase(this.filterLocale()));
    }
    isEmpty() {
        return !this._options() || (this.visibleOptions() && this.visibleOptions().length === 0);
    }
    getOptionIndex(index, scrollerOptions) {
        return this.virtualScrollerDisabled ? index : scrollerOptions && scrollerOptions.getItemOptions(index)['index'];
    }
    getAriaPosInset(index) {
        return ((this.optionGroupLabel()
            ? index -
                this.visibleOptions()
                    .slice(0, index)
                    .filter((option) => this.isOptionGroup(option)).length
            : index) + 1);
    }
    get ariaSetSize() {
        return this.visibleOptions().filter((option) => !this.isOptionGroup(option)).length;
    }
    getLabelByValue(value) {
        const options = this.group() ? this.flatOptions(this._options()) : this._options() || [];
        const matchedOption = options.find((option) => !this.isOptionGroup(option) && equals(this.getOptionValue(option), value, this.equalityKey() || ''));
        return matchedOption ? this.getOptionLabel(matchedOption) : null;
    }
    getSelectedItemsLabel() {
        let pattern = /{(.*?)}/;
        const selectedItemsLabel = this.selectedItemsLabel();
        let message = selectedItemsLabel ? selectedItemsLabel : this.config.getTranslation(TranslationKeys.SELECTION_MESSAGE);
        if (pattern.test(message)) {
            return message.replace(message.match(pattern)[0], this.modelValue().length + '');
        }
        return message;
    }
    getOptionLabel(option) {
        const optionLabel = this.optionLabel();
        return optionLabel ? resolveFieldData(option, optionLabel) : option && option.label != undefined ? option.label : option;
    }
    getOptionValue(option) {
        const optionValue = this.optionValue();
        return optionValue ? resolveFieldData(option, optionValue) : !this.optionLabel() && option && option.value !== undefined ? option.value : option;
    }
    getOptionGroupLabel(optionGroup) {
        const optionGroupLabel = this.optionGroupLabel();
        return optionGroupLabel ? resolveFieldData(optionGroup, optionGroupLabel) : optionGroup && optionGroup.label != undefined ? optionGroup.label : optionGroup;
    }
    getOptionGroupChildren(optionGroup) {
        const optionGroupChildren = this.optionGroupChildren();
        return optionGroup ? (optionGroupChildren ? resolveFieldData(optionGroup, optionGroupChildren) : optionGroup.items) : [];
    }
    onKeyDown(event) {
        if (this.$disabled()) {
            event.preventDefault();
            return;
        }
        const metaKey = event.metaKey || event.ctrlKey;
        switch (event.code) {
            case 'ArrowDown':
                this.onArrowDownKey(event);
                break;
            case 'ArrowUp':
                this.onArrowUpKey(event);
                break;
            case 'Home':
                this.onHomeKey(event);
                break;
            case 'End':
                this.onEndKey(event);
                break;
            case 'PageDown':
                this.onPageDownKey(event);
                break;
            case 'PageUp':
                this.onPageUpKey(event);
                break;
            case 'Enter':
            case 'Space':
                this.onEnterKey(event);
                break;
            case 'Escape':
                this.onEscapeKey(event);
                break;
            case 'Tab':
                this.onTabKey(event);
                break;
            case 'ShiftLeft':
            case 'ShiftRight':
                this.onShiftKey();
                break;
            default:
                if (event.code === 'KeyA' && metaKey) {
                    const value = this.visibleOptions()
                        .filter((option) => this.isValidOption(option))
                        .map((option) => this.getOptionValue(option));
                    this.updateModel(value, event);
                    event.preventDefault();
                    break;
                }
                if (!metaKey && isPrintableCharacter(event.key)) {
                    !this.overlayVisible() && this.show();
                    this.searchOptions(event, event.key);
                    event.preventDefault();
                }
                break;
        }
    }
    onFilterKeyDown(event) {
        switch (event.code) {
            case 'ArrowDown':
                this.onArrowDownKey(event);
                break;
            case 'ArrowUp':
                this.onArrowUpKey(event, true);
                break;
            case 'ArrowLeft':
            case 'ArrowRight':
                this.onArrowLeftKey(event, true);
                break;
            case 'Home':
                this.onHomeKey(event, true);
                break;
            case 'End':
                this.onEndKey(event, true);
                break;
            case 'Enter':
            case 'NumpadEnter':
                this.onEnterKey(event);
                break;
            case 'Escape':
                this.onEscapeKey(event);
                break;
            case 'Tab':
                this.onTabKey(event, true);
                break;
            default:
                break;
        }
    }
    onArrowLeftKey(event, pressedInInputText = false) {
        pressedInInputText && this.focusedOptionIndex.set(-1);
    }
    onArrowDownKey(event) {
        const optionIndex = this.focusedOptionIndex() !== -1 ? this.findNextOptionIndex(this.focusedOptionIndex()) : this.findFirstFocusedOptionIndex();
        if (event.shiftKey) {
            this.onOptionSelectRange(event, this.startRangeIndex(), optionIndex);
        }
        this.changeFocusedOptionIndex(event, optionIndex);
        !this.overlayVisible() && this.show();
        event.preventDefault();
        event.stopPropagation();
    }
    onArrowUpKey(event, pressedInInputText = false) {
        if (event.altKey && !pressedInInputText) {
            if (this.focusedOptionIndex() !== -1) {
                this.onOptionSelect(event, this.visibleOptions()[this.focusedOptionIndex()]);
            }
            this.overlayVisible() && this.hide();
            event.preventDefault();
        }
        else {
            const optionIndex = this.focusedOptionIndex() !== -1 ? this.findPrevOptionIndex(this.focusedOptionIndex()) : this.findLastFocusedOptionIndex();
            if (event.shiftKey) {
                this.onOptionSelectRange(event, optionIndex, this.startRangeIndex());
            }
            this.changeFocusedOptionIndex(event, optionIndex);
            !this.overlayVisible() && this.show();
            event.preventDefault();
        }
        event.stopPropagation();
    }
    onHomeKey(event, pressedInInputText = false) {
        const { currentTarget } = event;
        if (pressedInInputText) {
            const len = currentTarget.value.length;
            currentTarget.setSelectionRange(0, event.shiftKey ? len : 0);
            this.focusedOptionIndex.set(-1);
        }
        else {
            let metaKey = event.metaKey || event.ctrlKey;
            let optionIndex = this.findFirstOptionIndex();
            if (event.shiftKey && metaKey) {
                this.onOptionSelectRange(event, optionIndex, this.startRangeIndex());
            }
            this.changeFocusedOptionIndex(event, optionIndex);
            !this.overlayVisible() && this.show();
        }
        event.preventDefault();
    }
    onEndKey(event, pressedInInputText = false) {
        const { currentTarget } = event;
        if (pressedInInputText) {
            const len = currentTarget.value.length;
            currentTarget.setSelectionRange(event.shiftKey ? 0 : len, len);
            this.focusedOptionIndex.set(-1);
        }
        else {
            let metaKey = event.metaKey || event.ctrlKey;
            let optionIndex = this.findLastFocusedOptionIndex();
            if (event.shiftKey && metaKey) {
                this.onOptionSelectRange(event, this.startRangeIndex(), optionIndex);
            }
            this.changeFocusedOptionIndex(event, optionIndex);
            !this.overlayVisible() && this.show();
        }
        event.preventDefault();
    }
    onPageDownKey(event) {
        this.scrollInView(this.visibleOptions().length - 1);
        event.preventDefault();
    }
    onPageUpKey(event) {
        this.scrollInView(0);
        event.preventDefault();
    }
    onEnterKey(event) {
        if (!this.overlayVisible()) {
            this.onArrowDownKey(event);
        }
        else {
            if (this.focusedOptionIndex() !== -1) {
                if (event.shiftKey) {
                    this.onOptionSelectRange(event, this.focusedOptionIndex());
                }
                else {
                    this.onOptionSelect({ originalEvent: event, option: this.visibleOptions()[this.focusedOptionIndex()] });
                }
            }
        }
        event.preventDefault();
    }
    onEscapeKey(event) {
        if (this.overlayVisible()) {
            this.hide(true);
            event.stopPropagation();
            event.preventDefault();
        }
    }
    onTabKey(event, pressedInInputText = false) {
        if (!pressedInInputText) {
            const overlayVisible = this.overlayVisible();
            if (overlayVisible && this.hasFocusableElements()) {
                focus(event.shiftKey ? this.lastHiddenFocusableElementOnOverlay()?.nativeElement : this.firstHiddenFocusableElementOnOverlay()?.nativeElement);
                event.preventDefault();
            }
            else {
                if (this.focusedOptionIndex() !== -1) {
                    const option = this.visibleOptions()[this.focusedOptionIndex()];
                    !this.isSelected(option) && this.onOptionSelect({ originalEvent: event, option });
                }
                overlayVisible && this.hide(this.filter());
            }
        }
    }
    onShiftKey() {
        this.startRangeIndex.set(this.focusedOptionIndex());
    }
    onContainerClick(event) {
        const focusInputViewChild = this.focusInputViewChild();
        if (this.$disabled() || this.loading() || this.readonly() || event.target?.isSameNode?.(focusInputViewChild?.nativeElement)) {
            return;
        }
        const overlayViewChild = this.overlayViewChild();
        if (!overlayViewChild || !overlayViewChild.el.nativeElement.contains(event.target)) {
            if (this.clickInProgress) {
                return;
            }
            this.clickInProgress = true;
            setTimeout(() => {
                this.clickInProgress = false;
            }, 150);
            this.overlayVisible() ? this.hide(true) : this.show(true);
        }
        focusInputViewChild?.nativeElement.focus({ preventScroll: true });
        this.onClick.emit(event);
        this.cd.detectChanges();
    }
    onFirstHiddenFocus(event) {
        const focusInputViewChild = this.focusInputViewChild();
        const focusableEl = event.relatedTarget === focusInputViewChild?.nativeElement ? getFirstFocusableElement(this.overlayViewChild()?.overlayViewChild()?.nativeElement, ':not([data-p-hidden-focusable="true"])') : focusInputViewChild?.nativeElement;
        focus(focusableEl);
    }
    onInputFocus(event) {
        this.focused = true;
        const focusedOptionIndex = this.focusedOptionIndex() !== -1 ? this.focusedOptionIndex() : this.overlayVisible() && this.autoOptionFocus() ? this.findFirstFocusedOptionIndex() : -1;
        this.focusedOptionIndex.set(focusedOptionIndex);
        this.overlayVisible() && this.scrollInView(this.focusedOptionIndex());
        this.onFocus.emit({ originalEvent: event });
    }
    onInputBlur(event) {
        this.focused = false;
        this.onBlur.emit({ originalEvent: event });
        if (!this.preventModelTouched) {
            this.onModelTouched();
        }
        this.preventModelTouched = false;
    }
    onFilterInputChange(event) {
        let value = event.target.value;
        this._filterValue.set(value);
        this.focusedOptionIndex.set(-1);
        this.onFilter.emit({ originalEvent: event, filter: this._filterValue() });
        !this.virtualScrollerDisabled && this.scroller()?.scrollToIndex(0);
        setTimeout(() => {
            this.overlayViewChild()?.alignOverlay();
        });
    }
    onLastHiddenFocus(event) {
        const focusInputViewChild = this.focusInputViewChild();
        const focusableEl = event.relatedTarget === focusInputViewChild?.nativeElement ? getLastFocusableElement(this.overlayViewChild()?.overlayViewChild()?.nativeElement, ':not([data-p-hidden-focusable="true"])') : focusInputViewChild?.nativeElement;
        focus(focusableEl);
    }
    onOptionMouseEnter(event, index) {
        if (this.focusOnHover()) {
            this.changeFocusedOptionIndex(event, index);
        }
    }
    onFilterBlur() {
        this.focusedOptionIndex.set(-1);
    }
    onToggleAll(event) {
        if (this.$disabled() || this.readonly()) {
            return;
        }
        if (this.selectAll() != null) {
            this.onSelectAllChange.emit({
                originalEvent: event,
                checked: !this.allSelected()
            });
        }
        else {
            // pre-selected disabled options should always be selected.
            const selectedDisabledOptions = this.getAllVisibleAndNonVisibleOptions().filter((option) => {
                const optionDisabled = this.optionDisabled();
                return this.isSelected(option) && (optionDisabled ? resolveFieldData(option, optionDisabled) : option && option.disabled !== undefined ? option.disabled : false);
            });
            const visibleOptions = this.allSelected()
                ? this.visibleOptions().filter((option) => !this.isValidOption(option) && this.isSelected(option))
                : this.visibleOptions().filter((option) => this.isSelected(option) || this.isValidOption(option));
            const selectedOptionsBeforeSearch = this.filter() && !this.allSelected() ? this.getAllVisibleAndNonVisibleOptions().filter((option) => this.isSelected(option) && this.isValidOption(option)) : [];
            const optionValues = [...selectedOptionsBeforeSearch, ...selectedDisabledOptions, ...visibleOptions].map((option) => this.getOptionValue(option));
            const value = [...new Set(optionValues)];
            this.updateModel(value, event);
            // because onToggleAll could have been called during filtering, this additional test needs to be performed before calling onSelectAllChange.emit
            if (!value.length || value.length === this.getAllVisibleAndNonVisibleOptions().length) {
                this.onSelectAllChange.emit({
                    originalEvent: event,
                    checked: !!value.length
                });
            }
        }
        if (this.partialSelected()) {
            this.selectedOptions = [];
            this.cd.markForCheck();
        }
        this.onChange.emit({ originalEvent: event, value: this.value });
        DomHandler.focus(this.headerCheckboxViewChild()?.inputViewChild()?.nativeElement);
        this.headerCheckboxFocus = true;
        event.originalEvent.preventDefault();
        event.originalEvent.stopPropagation();
    }
    changeFocusedOptionIndex(event, index) {
        if (this.focusedOptionIndex() !== index) {
            this.focusedOptionIndex.set(index);
            this.scrollInView();
        }
    }
    get virtualScrollerDisabled() {
        return !this.virtualScroll();
    }
    scrollInView(index = -1) {
        const id = index !== -1 ? `${this.resolvedId}_${index}` : this.focusedOptionId;
        const itemsViewChild = this.itemsViewChild();
        if (itemsViewChild && itemsViewChild.nativeElement) {
            const element = findSingle(itemsViewChild.nativeElement, `li[id="${id}"]`);
            if (element) {
                element.scrollIntoView && element.scrollIntoView({ block: 'nearest', inline: 'nearest' });
            }
            else if (!this.virtualScrollerDisabled) {
                setTimeout(() => {
                    this.virtualScroll() && this.scroller()?.scrollToIndex(index !== -1 ? index : this.focusedOptionIndex());
                }, 0);
            }
        }
    }
    get focusedOptionId() {
        return this.focusedOptionIndex() !== -1 ? `${this.resolvedId}_${this.focusedOptionIndex()}` : null;
    }
    allSelected() {
        return this.selectAll !== null ? this.selectAll : isNotEmpty(this.visibleOptions()) && this.visibleOptions().every((option) => this.isOptionGroup(option) || this.isOptionDisabled(option) || this.isSelected(option));
    }
    partialSelected() {
        return this.selectedOptions && this.selectedOptions.length > 0 && this.selectedOptions.length < (this._options()?.length || 0);
    }
    /**
     * Displays the panel.
     * @group Method
     */
    show(isFocus) {
        this.overlayVisible.set(true);
        const focusedOptionIndex = this.focusedOptionIndex() !== -1 ? this.focusedOptionIndex() : this.autoOptionFocus() ? this.findFirstFocusedOptionIndex() : this.findSelectedOptionIndex();
        this.focusedOptionIndex.set(focusedOptionIndex);
        if (isFocus) {
            focus(this.focusInputViewChild()?.nativeElement);
        }
        this.cd.markForCheck();
    }
    /**
     * Hides the panel.
     * @group Method
     */
    hide(isFocus) {
        this.overlayVisible.set(false);
        this.focusedOptionIndex.set(-1);
        if (this.filter() && this.resetFilterOnHide()) {
            this.resetFilter();
        }
        if (this.overlayOptions()?.mode === 'modal') {
            unblockBodyScroll();
        }
        isFocus && focus(this.focusInputViewChild()?.nativeElement);
        this.cd.markForCheck();
    }
    onOverlayBeforeEnter(event) {
        this.itemsWrapper = findSingle(this.overlayViewChild()?.overlayViewChild()?.nativeElement, this.virtualScroll() ? '[data-pc-name="virtualscroller"]' : '[data-pc-section="listcontainer"]');
        this.virtualScroll() && this.scroller()?.setContentEl(this.itemsViewChild()?.nativeElement);
        if (this._options() && this._options().length) {
            if (this.virtualScroll()) {
                const selectedIndex = this.modelValue() ? this.focusedOptionIndex() : -1;
                if (selectedIndex !== -1) {
                    this.scroller()?.scrollToIndex(selectedIndex);
                }
            }
            else {
                let selectedListItem = findSingle(this.itemsWrapper, '[data-pc-section="option"][data-p-selected="true"]');
                if (selectedListItem) {
                    selectedListItem.scrollIntoView({ block: 'nearest', inline: 'nearest' });
                }
            }
        }
        const filterInputChild = this.filterInputChild();
        if (filterInputChild && filterInputChild.nativeElement) {
            this.preventModelTouched = true;
            if (this.autofocusFilter()) {
                filterInputChild.nativeElement.focus();
            }
        }
        this.onPanelShow.emit(event);
    }
    onOverlayAfterLeave(event) {
        this.itemsWrapper = null;
        this.onModelTouched();
        this.onPanelHide.emit(event);
    }
    resetFilter() {
        const filterInputChild = this.filterInputChild();
        if (filterInputChild && filterInputChild.nativeElement) {
            filterInputChild.nativeElement.value = '';
        }
        this._filterValue.set(null);
        this._filteredOptions = null;
    }
    onOverlayHide() {
        // Called when overlay completes its hide animation
        // Don't call hide() again to avoid recursive calls
        this.focusedOptionIndex.set(-1);
        if (this.filter() && this.resetFilterOnHide()) {
            this.resetFilter();
        }
    }
    close(event) {
        this.hide();
        event.preventDefault();
        event.stopPropagation();
    }
    clear(event) {
        this.value = [];
        this.updateModel(null, event);
        this.selectedOptions = [];
        this.onClear.emit();
        this._disableTooltip = true;
        event.stopPropagation();
    }
    labelContainerMouseLeave() {
        if (this._disableTooltip)
            this._disableTooltip = false;
    }
    removeOption(optionValue, event) {
        let value = this.modelValue().filter((val) => !equals(val, optionValue, this.equalityKey() || ''));
        this.updateModel(value, event);
        this.onChange.emit({
            originalEvent: event,
            value: value,
            itemValue: optionValue
        });
        this.onRemove.emit({
            newValue: value,
            removed: optionValue
        });
        event && event.stopPropagation();
    }
    findNextOptionIndex(index) {
        const matchedOptionIndex = index < this.visibleOptions().length - 1
            ? this.visibleOptions()
                .slice(index + 1)
                .findIndex((option) => this.isValidOption(option))
            : -1;
        return matchedOptionIndex > -1 ? matchedOptionIndex + index + 1 : index;
    }
    findPrevOptionIndex(index) {
        const matchedOptionIndex = index > 0 ? findLastIndex(this.visibleOptions().slice(0, index), (option) => this.isValidOption(option)) : -1;
        return matchedOptionIndex > -1 ? matchedOptionIndex : index;
    }
    findLastSelectedOptionIndex() {
        return this.hasSelectedOption() ? findLastIndex(this.visibleOptions(), (option) => this.isValidSelectedOption(option)) : -1;
    }
    findLastFocusedOptionIndex() {
        const selectedIndex = this.findLastSelectedOptionIndex();
        return selectedIndex < 0 ? this.findLastOptionIndex() : selectedIndex;
    }
    findLastOptionIndex() {
        return findLastIndex(this.visibleOptions(), (option) => this.isValidOption(option));
    }
    searchOptions(event, char) {
        this.searchValue = (this.searchValue || '') + char;
        let optionIndex = -1;
        let matched = false;
        if (this.focusedOptionIndex() !== -1) {
            optionIndex = this.visibleOptions()
                .slice(this.focusedOptionIndex())
                .findIndex((option) => this.isOptionMatched(option));
            optionIndex =
                optionIndex === -1
                    ? this.visibleOptions()
                        .slice(0, this.focusedOptionIndex())
                        .findIndex((option) => this.isOptionMatched(option))
                    : optionIndex + this.focusedOptionIndex();
        }
        else {
            optionIndex = this.visibleOptions().findIndex((option) => this.isOptionMatched(option));
        }
        if (optionIndex !== -1) {
            matched = true;
        }
        if (optionIndex === -1 && this.focusedOptionIndex() === -1) {
            optionIndex = this.findFirstFocusedOptionIndex();
        }
        if (optionIndex !== -1) {
            this.changeFocusedOptionIndex(event, optionIndex);
        }
        if (this.searchTimeout) {
            clearTimeout(this.searchTimeout);
        }
        this.searchTimeout = setTimeout(() => {
            this.searchValue = '';
            this.searchTimeout = null;
        }, 500);
        return matched;
    }
    hasFocusableElements() {
        return getFocusableElements(this.overlayViewChild()?.overlayViewChild()?.nativeElement, ':not([data-p-hidden-focusable="true"])').length > 0;
    }
    hasFilter() {
        return this._filterValue() && this._filterValue().trim().length > 0;
    }
    get containerDataP() {
        return this.cn({
            invalid: this.invalid(),
            disabled: this.$disabled(),
            focus: this.focused,
            fluid: this.hasFluid,
            filled: this.$variant() === 'filled',
            [this.size()]: this.size()
        });
    }
    get labelDataP() {
        return this.cn({
            placeholder: this.label() === this.placeholder(),
            clearable: this.showClear(),
            disabled: this.disabled,
            [this.size()]: this.size(),
            'has-chip': this.display() === 'chip' && this.value && this.value.length && (this.maxSelectedLabels() ? this.value.length <= this.maxSelectedLabels() : true),
            empty: !this.placeholder() && !this.$filled
        });
    }
    get dropdownIconDataP() {
        return this.cn({
            [this.size()]: this.size()
        });
    }
    get overlayDataP() {
        return this.cn({
            ['overlay-' + this.appendTo]: 'overlay-' + this.appendTo
        });
    }
    /**
     * @override
     *
     * @see {@link BaseEditableHolder.writeControlValue}
     * Writes the value to the control.
     */
    writeControlValue(value, setModelValue) {
        this.value = value;
        setModelValue(value);
        this.cd.markForCheck();
    }
    getHeaderCheckboxPTOptions(key) {
        return this.ptm(key, {
            context: {
                selected: this.allSelected()
            }
        });
    }
    getPTOptions(option, itemOptions, index, key) {
        return this.ptm(key, {
            context: {
                selected: this.isSelected(option),
                focused: this.focusedOptionIndex() === this.getOptionIndex(index, itemOptions),
                disabled: this.isOptionDisabled(option)
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MultiSelect, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: MultiSelect, isStandalone: true, selector: "p-multiSelect, p-multiselect, p-multi-select", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, panelStyle: { classPropertyName: "panelStyle", publicName: "panelStyle", isSignal: true, isRequired: false, transformFunction: null }, panelStyleClass: { classPropertyName: "panelStyleClass", publicName: "panelStyleClass", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, group: { classPropertyName: "group", publicName: "group", isSignal: true, isRequired: false, transformFunction: null }, filter: { classPropertyName: "filter", publicName: "filter", isSignal: true, isRequired: false, transformFunction: null }, filterPlaceHolder: { classPropertyName: "filterPlaceHolder", publicName: "filterPlaceHolder", isSignal: true, isRequired: false, transformFunction: null }, filterLocale: { classPropertyName: "filterLocale", publicName: "filterLocale", isSignal: true, isRequired: false, transformFunction: null }, overlayVisible: { classPropertyName: "overlayVisible", publicName: "overlayVisible", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null }, dataKey: { classPropertyName: "dataKey", publicName: "dataKey", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, displaySelectedLabel: { classPropertyName: "displaySelectedLabel", publicName: "displaySelectedLabel", isSignal: true, isRequired: false, transformFunction: null }, maxSelectedLabels: { classPropertyName: "maxSelectedLabels", publicName: "maxSelectedLabels", isSignal: true, isRequired: false, transformFunction: null }, selectionLimit: { classPropertyName: "selectionLimit", publicName: "selectionLimit", isSignal: true, isRequired: false, transformFunction: null }, selectedItemsLabel: { classPropertyName: "selectedItemsLabel", publicName: "selectedItemsLabel", isSignal: true, isRequired: false, transformFunction: null }, showToggleAll: { classPropertyName: "showToggleAll", publicName: "showToggleAll", isSignal: true, isRequired: false, transformFunction: null }, emptyFilterMessage: { classPropertyName: "emptyFilterMessage", publicName: "emptyFilterMessage", isSignal: true, isRequired: false, transformFunction: null }, emptyMessage: { classPropertyName: "emptyMessage", publicName: "emptyMessage", isSignal: true, isRequired: false, transformFunction: null }, resetFilterOnHide: { classPropertyName: "resetFilterOnHide", publicName: "resetFilterOnHide", isSignal: true, isRequired: false, transformFunction: null }, dropdownIcon: { classPropertyName: "dropdownIcon", publicName: "dropdownIcon", isSignal: true, isRequired: false, transformFunction: null }, chipIcon: { classPropertyName: "chipIcon", publicName: "chipIcon", isSignal: true, isRequired: false, transformFunction: null }, optionLabel: { classPropertyName: "optionLabel", publicName: "optionLabel", isSignal: true, isRequired: false, transformFunction: null }, optionValue: { classPropertyName: "optionValue", publicName: "optionValue", isSignal: true, isRequired: false, transformFunction: null }, optionDisabled: { classPropertyName: "optionDisabled", publicName: "optionDisabled", isSignal: true, isRequired: false, transformFunction: null }, optionGroupLabel: { classPropertyName: "optionGroupLabel", publicName: "optionGroupLabel", isSignal: true, isRequired: false, transformFunction: null }, optionGroupChildren: { classPropertyName: "optionGroupChildren", publicName: "optionGroupChildren", isSignal: true, isRequired: false, transformFunction: null }, showHeader: { classPropertyName: "showHeader", publicName: "showHeader", isSignal: true, isRequired: false, transformFunction: null }, filterBy: { classPropertyName: "filterBy", publicName: "filterBy", isSignal: true, isRequired: false, transformFunction: null }, scrollHeight: { classPropertyName: "scrollHeight", publicName: "scrollHeight", isSignal: true, isRequired: false, transformFunction: null }, lazy: { classPropertyName: "lazy", publicName: "lazy", isSignal: true, isRequired: false, transformFunction: null }, virtualScroll: { classPropertyName: "virtualScroll", publicName: "virtualScroll", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, virtualScrollItemSize: { classPropertyName: "virtualScrollItemSize", publicName: "virtualScrollItemSize", isSignal: true, isRequired: false, transformFunction: null }, loadingIcon: { classPropertyName: "loadingIcon", publicName: "loadingIcon", isSignal: true, isRequired: false, transformFunction: null }, virtualScrollOptions: { classPropertyName: "virtualScrollOptions", publicName: "virtualScrollOptions", isSignal: true, isRequired: false, transformFunction: null }, overlayOptions: { classPropertyName: "overlayOptions", publicName: "overlayOptions", isSignal: true, isRequired: false, transformFunction: null }, ariaFilterLabel: { classPropertyName: "ariaFilterLabel", publicName: "ariaFilterLabel", isSignal: true, isRequired: false, transformFunction: null }, filterMatchMode: { classPropertyName: "filterMatchMode", publicName: "filterMatchMode", isSignal: true, isRequired: false, transformFunction: null }, tooltip: { classPropertyName: "tooltip", publicName: "tooltip", isSignal: true, isRequired: false, transformFunction: null }, tooltipPosition: { classPropertyName: "tooltipPosition", publicName: "tooltipPosition", isSignal: true, isRequired: false, transformFunction: null }, tooltipPositionStyle: { classPropertyName: "tooltipPositionStyle", publicName: "tooltipPositionStyle", isSignal: true, isRequired: false, transformFunction: null }, tooltipStyleClass: { classPropertyName: "tooltipStyleClass", publicName: "tooltipStyleClass", isSignal: true, isRequired: false, transformFunction: null }, autofocusFilter: { classPropertyName: "autofocusFilter", publicName: "autofocusFilter", isSignal: true, isRequired: false, transformFunction: null }, display: { classPropertyName: "display", publicName: "display", isSignal: true, isRequired: false, transformFunction: null }, autocomplete: { classPropertyName: "autocomplete", publicName: "autocomplete", isSignal: true, isRequired: false, transformFunction: null }, showClear: { classPropertyName: "showClear", publicName: "showClear", isSignal: true, isRequired: false, transformFunction: null }, autofocus: { classPropertyName: "autofocus", publicName: "autofocus", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, filterValue: { classPropertyName: "filterValue", publicName: "filterValue", isSignal: true, isRequired: false, transformFunction: null }, selectAll: { classPropertyName: "selectAll", publicName: "selectAll", isSignal: true, isRequired: false, transformFunction: null }, focusOnHover: { classPropertyName: "focusOnHover", publicName: "focusOnHover", isSignal: true, isRequired: false, transformFunction: null }, filterFields: { classPropertyName: "filterFields", publicName: "filterFields", isSignal: true, isRequired: false, transformFunction: null }, selectOnFocus: { classPropertyName: "selectOnFocus", publicName: "selectOnFocus", isSignal: true, isRequired: false, transformFunction: null }, autoOptionFocus: { classPropertyName: "autoOptionFocus", publicName: "autoOptionFocus", isSignal: true, isRequired: false, transformFunction: null }, highlightOnSelect: { classPropertyName: "highlightOnSelect", publicName: "highlightOnSelect", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, fluid: { classPropertyName: "fluid", publicName: "fluid", isSignal: true, isRequired: false, transformFunction: null }, appendTo: { classPropertyName: "appendTo", publicName: "appendTo", isSignal: true, isRequired: false, transformFunction: null }, motionOptions: { classPropertyName: "motionOptions", publicName: "motionOptions", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { overlayVisible: "overlayVisibleChange", onChange: "onChange", onFilter: "onFilter", onFocus: "onFocus", onBlur: "onBlur", onClick: "onClick", onClear: "onClear", onPanelShow: "onPanelShow", onPanelHide: "onPanelHide", onLazyLoad: "onLazyLoad", onRemove: "onRemove", onSelectAllChange: "onSelectAllChange" }, host: { listeners: { "click": "onContainerClick($event)" }, properties: { "attr.id": "resolvedId", "attr.data-p": "containerDataP", "class": "cn(cx('root'), styleClass())", "style": "sx('root')" } }, providers: [MULTISELECT_VALUE_ACCESSOR, MultiSelectStyle, { provide: MULTISELECT_INSTANCE, useExisting: MultiSelect }, { provide: PARENT_INSTANCE, useExisting: MultiSelect }], queries: [{ propertyName: "footerFacet", first: true, predicate: Footer, descendants: true, isSignal: true }, { propertyName: "headerFacet", first: true, predicate: Header, descendants: true, isSignal: true }, { propertyName: "itemTemplate", first: true, predicate: ["item"], isSignal: true }, { propertyName: "headerTemplate", first: true, predicate: ["header"], isSignal: true }, { propertyName: "emptyFilterTemplate", first: true, predicate: ["emptyfilter"], isSignal: true }, { propertyName: "emptyTemplate", first: true, predicate: ["empty"], isSignal: true }, { propertyName: "itemCheckboxIconTemplate", first: true, predicate: ["itemcheckboxicon"], isSignal: true }, { propertyName: "headerCheckboxIconTemplate", first: true, predicate: ["headercheckboxicon"], isSignal: true }, { propertyName: "templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "groupTemplate", first: true, predicate: ["group"] }, { propertyName: "loaderTemplate", first: true, predicate: ["loader"] }, { propertyName: "filterTemplate", first: true, predicate: ["filter"] }, { propertyName: "footerTemplate", first: true, predicate: ["footer"] }, { propertyName: "selectedItemsTemplate", first: true, predicate: ["selecteditems"] }, { propertyName: "loadingIconTemplate", first: true, predicate: ["loadingicon"] }, { propertyName: "filterIconTemplate", first: true, predicate: ["filtericon"] }, { propertyName: "removeTokenIconTemplate", first: true, predicate: ["removetokenicon"] }, { propertyName: "chipIconTemplate", first: true, predicate: ["chipicon"] }, { propertyName: "clearIconTemplate", first: true, predicate: ["clearicon"] }, { propertyName: "dropdownIconTemplate", first: true, predicate: ["dropdownicon"] }], viewQueries: [{ propertyName: "overlayViewChild", first: true, predicate: ["overlay"], descendants: true, isSignal: true }, { propertyName: "filterInputChild", first: true, predicate: ["filterInput"], descendants: true, isSignal: true }, { propertyName: "focusInputViewChild", first: true, predicate: ["focusInput"], descendants: true, isSignal: true }, { propertyName: "itemsViewChild", first: true, predicate: ["items"], descendants: true, isSignal: true }, { propertyName: "scroller", first: true, predicate: ["scroller"], descendants: true, isSignal: true }, { propertyName: "lastHiddenFocusableElementOnOverlay", first: true, predicate: ["lastHiddenFocusableEl"], descendants: true, isSignal: true }, { propertyName: "firstHiddenFocusableElementOnOverlay", first: true, predicate: ["firstHiddenFocusableEl"], descendants: true, isSignal: true }, { propertyName: "headerCheckboxViewChild", first: true, predicate: ["headerCheckbox"], descendants: true, isSignal: true }], usesInheritance: true, hostDirectives: [{ directive: i3.Bind }], ngImport: i0, template: `
        <div class="p-hidden-accessible" [attr.data-p-hidden-accessible]="true" [pBind]="ptm('hiddenInputContainer')">
            <input
                #focusInput
                [pTooltip]="tooltip()"
                [pTooltipUnstyled]="unstyled()"
                [tooltipPosition]="tooltipPosition()"
                [positionStyle]="tooltipPositionStyle()"
                [tooltipStyleClass]="tooltipStyleClass()"
                [attr.aria-disabled]="$disabled()"
                [attr.id]="inputId()"
                role="combobox"
                [attr.aria-label]="ariaLabel()"
                [attr.aria-labelledby]="ariaLabelledBy()"
                [attr.aria-haspopup]="'listbox'"
                [attr.aria-expanded]="overlayVisible() ?? false"
                [attr.aria-controls]="overlayVisible() ? id() + '_list' : null"
                [attr.tabindex]="!$disabled() ? tabindex() : -1"
                [attr.aria-activedescendant]="focused ? focusedOptionId : undefined"
                (focus)="onInputFocus($event)"
                (blur)="onInputBlur($event)"
                (keydown)="onKeyDown($event)"
                [pAutoFocus]="autofocus()"
                [attr.value]="modelValue()"
                [attr.name]="name()"
                [attr.required]="required() ? '' : undefined"
                [attr.disabled]="$disabled() ? '' : undefined"
                [pBind]="ptm('hiddenInput')"
            />
        </div>
        <div
            [pBind]="ptm('labelContainer')"
            [class]="cx('labelContainer')"
            [pTooltip]="tooltip()"
            [pTooltipUnstyled]="unstyled()"
            (mouseleave)="labelContainerMouseLeave()"
            [tooltipDisabled]="_disableTooltip"
            [tooltipPosition]="tooltipPosition()"
            [positionStyle]="tooltipPositionStyle()"
            [tooltipStyleClass]="tooltipStyleClass()"
        >
            <div [pBind]="ptm('label')" [class]="cx('label')" [attr.data-p]="labelDataP">
                @if (!selectedItemsTemplate && !_selectedItemsTemplate) {
                    @if (display() === 'comma') {
                        <ng-container>{{ label() || 'empty' }}</ng-container>
                    }
                    @if (display() === 'chip') {
                        @if (chipSelectedItems() && chipSelectedItems().length === maxSelectedLabels) {
                            {{ getSelectedItemsLabel() }}
                        } @else {
                            @for (item of chipSelectedItems(); track item; let i = $index) {
                                <div #token [pBind]="ptm('chipItem')" [class]="cx('chipItem')">
                                    <p-chip
                                        [pt]="ptm('pcChip')"
                                        [unstyled]="unstyled()"
                                        [class]="cx('pcChip')"
                                        [label]="getLabelByValue(item)"
                                        [removable]="!$disabled() && !readonly()"
                                        (onRemove)="removeOption(item, $event)"
                                        [removeIcon]="chipIcon()"
                                    >
                                        @if (chipIconTemplate || _chipIconTemplate || removeTokenIconTemplate || _removeTokenIconTemplate) {
                                            <ng-template #removeicon>
                                                @if (!$disabled() && !readonly()) {
                                                    <span [class]="cx('chipIcon')" (click)="removeOption(item, $event)" [attr.aria-hidden]="true" [pBind]="ptm('chipIcon')">
                                                        <ng-container *ngTemplateOutlet="chipIconTemplate || _chipIconTemplate || removeTokenIconTemplate || _removeTokenIconTemplate; context: { class: 'p-multiselect-chip-icon' }"></ng-container>
                                                    </span>
                                                }
                                            </ng-template>
                                        }
                                    </p-chip>
                                </div>
                            }
                        }
                        @if (!modelValue() || modelValue().length === 0) {
                            <ng-container>{{ placeholder() || 'empty' }}</ng-container>
                        }
                    }
                }
                @if (selectedItemsTemplate || _selectedItemsTemplate) {
                    <ng-container *ngTemplateOutlet="selectedItemsTemplate || _selectedItemsTemplate; context: { $implicit: selectedOptions, removeChip: removeOption.bind(this) }"></ng-container>
                    @if (!modelValue() || modelValue().length === 0) {
                        <ng-container>{{ placeholder() || 'empty' }}</ng-container>
                    }
                }
            </div>
        </div>
        @if (isVisibleClearIcon) {
            <ng-container>
                @if (!clearIconTemplate && !_clearIconTemplate) {
                    <svg data-p-icon="times" [pBind]="ptm('clearIcon')" [class]="cx('clearIcon')" (click)="clear($event)" [attr.aria-hidden]="true" />
                }
                @if (clearIconTemplate || _clearIconTemplate) {
                    <span [pBind]="ptm('clearIcon')" [class]="cx('clearIcon')" (click)="clear($event)" [attr.aria-hidden]="true">
                        <ng-template *ngTemplateOutlet="clearIconTemplate || _clearIconTemplate"></ng-template>
                    </span>
                }
            </ng-container>
        }
        <div [pBind]="ptm('dropdown')" [class]="cx('dropdown')">
            @if (loading()) {
                <ng-container>
                    @if (loadingIconTemplate || _loadingIconTemplate) {
                        <ng-container *ngTemplateOutlet="loadingIconTemplate || _loadingIconTemplate"></ng-container>
                    }
                    @if (!loadingIconTemplate && !_loadingIconTemplate) {
                        <ng-container>
                            @if (loadingIcon()) {
                                <span [pBind]="ptm('loadingIcon')" [class]="cn(cx('loadingIcon'), 'pi-spin ' + loadingIcon())" [attr.aria-hidden]="true"></span>
                            }
                            @if (!loadingIcon()) {
                                <span [pBind]="ptm('loadingIcon')" [class]="cn(cx('loadingIcon'), 'pi pi-spinner pi-spin')" [attr.aria-hidden]="true"></span>
                            }
                        </ng-container>
                    }
                </ng-container>
            } @else {
                @if (!dropdownIconTemplate && !_dropdownIconTemplate) {
                    <ng-container>
                        @if (dropdownIcon()) {
                            <span [pBind]="ptm('dropdownIcon')" [class]="cx('dropdownIcon')" [ngClass]="dropdownIcon()" [attr.aria-hidden]="true" [attr.data-p]="dropdownIconDataP"></span>
                        }
                        @if (!dropdownIcon()) {
                            <svg data-p-icon="chevron-down" [pBind]="ptm('dropdownIcon')" [class]="cx('dropdownIcon')" [attr.aria-hidden]="true" [attr.data-p]="dropdownIconDataP" />
                        }
                    </ng-container>
                }
                @if (dropdownIconTemplate || _dropdownIconTemplate) {
                    <span [pBind]="ptm('dropdownIcon')" [class]="cx('dropdownIcon')" [attr.aria-hidden]="true">
                        <ng-template *ngTemplateOutlet="dropdownIconTemplate || _dropdownIconTemplate; context: { dataP: dropdownIconDataP }"></ng-template>
                    </span>
                }
            }
        </div>
        <p-overlay
            #overlay
            [hostAttrSelector]="$attrSelector"
            [visible]="overlayVisible()"
            (visibleChange)="overlayVisible.set($event)"
            [options]="overlayOptions()"
            [target]="'@parent'"
            [appendTo]="$appendTo()"
            [unstyled]="unstyled()"
            [pt]="ptm('pcOverlay')"
            [motionOptions]="motionOptions()"
            (onBeforeEnter)="onOverlayBeforeEnter($event)"
            (onAfterLeave)="onOverlayAfterLeave($event)"
            (onHide)="onOverlayHide()"
        >
            <ng-template #content>
                <div [pBind]="ptm('overlay')" [attr.data-p]="overlayDataP" [attr.id]="id() + '_list'" [class]="cn(cx('overlay'), panelStyleClass())" [ngStyle]="panelStyle()">
                    <span
                        #firstHiddenFocusableEl
                        role="presentation"
                        class="p-hidden-accessible p-hidden-focusable"
                        [attr.tabindex]="0"
                        (focus)="onFirstHiddenFocus($event)"
                        [attr.data-p-hidden-accessible]="true"
                        [attr.data-p-hidden-focusable]="true"
                        [pBind]="ptm('firstHiddenFocusableEl')"
                    >
                    </span>
                    <ng-container *ngTemplateOutlet="headerTemplate() || _headerTemplate"></ng-container>
                    @if (showHeader()) {
                        <div [pBind]="ptm('header')" [class]="cx('header')">
                            <ng-content select="p-header"></ng-content>
                            @if (filterTemplate || _filterTemplate) {
                                <ng-container *ngTemplateOutlet="filterTemplate || _filterTemplate; context: { options: filterOptions }"></ng-container>
                            } @else {
                                @if (showToggleAll() && !selectionLimit()) {
                                    <p-checkbox
                                        [pt]="getHeaderCheckboxPTOptions('pcHeaderCheckbox')"
                                        [ngModel]="allSelected()"
                                        [ariaLabel]="toggleAllAriaLabel"
                                        [binary]="true"
                                        (onChange)="onToggleAll($event)"
                                        [variant]="$variant()"
                                        [disabled]="$disabled()"
                                        [unstyled]="unstyled()"
                                        #headerCheckbox
                                    >
                                        <ng-template #icon let-klass="class">
                                            @if (!headerCheckboxIconTemplate() && !_headerCheckboxIconTemplate && allSelected()) {
                                                <svg data-p-icon="check" [class]="klass" [pBind]="getHeaderCheckboxPTOptions('pcHeaderCheckbox.icon')" />
                                            }
                                            <ng-template
                                                *ngTemplateOutlet="
                                                    headerCheckboxIconTemplate() || _headerCheckboxIconTemplate;
                                                    context: {
                                                        checked: allSelected(),
                                                        partialSelected: partialSelected(),
                                                        class: klass
                                                    }
                                                "
                                            ></ng-template>
                                        </ng-template>
                                    </p-checkbox>
                                }

                                @if (filter()) {
                                    <p-iconfield [pt]="ptm('pcFilterContainer')" [class]="cx('pcFilterContainer')" [unstyled]="unstyled()">
                                        <input
                                            #filterInput
                                            pInputText
                                            [pt]="ptm('pcFilter')"
                                            [variant]="$variant()"
                                            type="text"
                                            [attr.autocomplete]="autocomplete()"
                                            role="searchbox"
                                            [attr.aria-owns]="id() + '_list'"
                                            [attr.aria-activedescendant]="focusedOptionId"
                                            [value]="_filterValue() || ''"
                                            (input)="onFilterInputChange($event)"
                                            (keydown)="onFilterKeyDown($event)"
                                            (click)="onInputClick($event)"
                                            (blur)="onFilterBlur($event)"
                                            [class]="cx('pcFilter')"
                                            [attr.disabled]="$disabled() ? '' : undefined"
                                            [attr.placeholder]="filterPlaceHolder()"
                                            [attr.aria-label]="ariaFilterLabel()"
                                            [unstyled]="unstyled()"
                                        />
                                        <p-inputicon [pt]="ptm('pcFilterIconContainer')" [unstyled]="unstyled()">
                                            @if (!filterIconTemplate && !_filterIconTemplate) {
                                                <svg data-p-icon="search" [pBind]="ptm('filterIcon')" />
                                            }
                                            @if (filterIconTemplate || _filterIconTemplate) {
                                                <span [pBind]="ptm('filterIcon')" class="p-multiselect-filter-icon">
                                                    <ng-template *ngTemplateOutlet="filterIconTemplate || _filterIconTemplate"></ng-template>
                                                </span>
                                            }
                                        </p-inputicon>
                                    </p-iconfield>
                                }
                            }
                        </div>
                    }
                    <div [pBind]="ptm('listContainer')" [class]="cx('listContainer')" [style.max-height]="virtualScroll() ? 'auto' : scrollHeight() || 'auto'">
                        @if (virtualScroll()) {
                            <p-scroller
                                #scroller
                                [items]="visibleOptions()"
                                [style]="{ height: scrollHeight() }"
                                [itemSize]="virtualScrollItemSize()"
                                [autoSize]="true"
                                [tabindex]="-1"
                                [lazy]="lazy()"
                                (onLazyLoad)="onLazyLoad.emit($event)"
                                [options]="virtualScrollOptions()"
                            >
                                <ng-template #content let-items let-scrollerOptions="options">
                                    <ng-container *ngTemplateOutlet="buildInItems; context: { $implicit: items, options: scrollerOptions }"></ng-container>
                                </ng-template>
                                @if (loaderTemplate || _loaderTemplate) {
                                    <ng-template #loader let-scrollerOptions="options">
                                        <ng-container *ngTemplateOutlet="loaderTemplate || _loaderTemplate; context: { options: scrollerOptions }"></ng-container>
                                    </ng-template>
                                }
                            </p-scroller>
                        }
                        @if (!virtualScroll()) {
                            <ng-container *ngTemplateOutlet="buildInItems; context: { $implicit: visibleOptions(), options: {} }"></ng-container>
                        }

                        <ng-template #buildInItems let-items let-scrollerOptions="options">
                            <ul #items [pBind]="ptm('list')" [class]="cn(cx('list'), scrollerOptions.contentStyleClass)" [style]="scrollerOptions.contentStyle" role="listbox" aria-multiselectable="true" [attr.aria-label]="listLabel">
                                @for (option of items; track option; let i = $index) {
                                    @if (isOptionGroup(option)) {
                                        <li [pBind]="ptm('optionGroup')" [attr.id]="id() + '_' + getOptionIndex(i, scrollerOptions)" [class]="cx('optionGroup')" [ngStyle]="{ height: scrollerOptions.itemSize + 'px' }" role="option">
                                            @if (!groupTemplate && option.optionGroup) {
                                                <span>{{ getOptionGroupLabel(option.optionGroup) }}</span>
                                            }
                                            @if (option.optionGroup && groupTemplate) {
                                                <ng-container [ngTemplateOutlet]="groupTemplate" [ngTemplateOutletContext]="{ $implicit: option.optionGroup }"></ng-container>
                                            }
                                        </li>
                                    }
                                    @if (!isOptionGroup(option)) {
                                        <li
                                            pMultiSelectItem
                                            pRipple
                                            [pBind]="getPTOptions(option, getItemOptions, i, 'option')"
                                            [id]="id() + '_' + getOptionIndex(i, scrollerOptions)"
                                            [option]="option"
                                            [selected]="isSelected(option)"
                                            [label]="getOptionLabel(option)"
                                            [disabled]="isOptionDisabled(option)"
                                            [template]="itemTemplate() || _itemTemplate"
                                            [itemCheckboxIconTemplate]="itemCheckboxIconTemplate() || _itemCheckboxIconTemplate"
                                            [itemSize]="scrollerOptions.itemSize"
                                            [focused]="focusedOptionIndex() === getOptionIndex(i, scrollerOptions)"
                                            [ariaPosInset]="getAriaPosInset(getOptionIndex(i, scrollerOptions))"
                                            [ariaSetSize]="ariaSetSize"
                                            [variant]="$variant()"
                                            [highlightOnSelect]="highlightOnSelect()"
                                            (onClick)="onOptionSelect($event, false, getOptionIndex(i, scrollerOptions))"
                                            (onMouseEnter)="onOptionMouseEnter($event, getOptionIndex(i, scrollerOptions))"
                                            [pt]="pt"
                                            [unstyled]="unstyled()"
                                        ></li>
                                    }
                                }

                                @if (hasFilter() && isEmpty()) {
                                    <li [pBind]="ptm('emptyMessage')" [class]="cx('emptyMessage')" [ngStyle]="{ height: scrollerOptions.itemSize + 'px' }" role="option">
                                        @if (!emptyFilterTemplate() && !_emptyFilterTemplate && !emptyTemplate() && !_emptyTemplate) {
                                            {{ emptyFilterMessageLabel }}
                                        } @else {
                                            <ng-container *ngTemplateOutlet="emptyFilterTemplate() || _emptyFilterTemplate || emptyTemplate() || _emptyFilterTemplate"></ng-container>
                                        }
                                    </li>
                                }
                                @if (!hasFilter() && isEmpty()) {
                                    <li [pBind]="ptm('emptyMessage')" [class]="cx('emptyMessage')" [ngStyle]="{ height: scrollerOptions.itemSize + 'px' }" role="option">
                                        @if (!emptyTemplate() && !_emptyTemplate) {
                                            {{ emptyMessageLabel }}
                                        } @else {
                                            <ng-container *ngTemplateOutlet="emptyTemplate() || _emptyTemplate"></ng-container>
                                        }
                                    </li>
                                }
                            </ul>
                        </ng-template>
                    </div>
                    @if (footerFacet() || footerTemplate || _footerTemplate) {
                        <div>
                            <ng-content select="p-footer"></ng-content>
                            <ng-container *ngTemplateOutlet="footerTemplate || _footerTemplate"></ng-container>
                        </div>
                    }

                    <span
                        #lastHiddenFocusableEl
                        role="presentation"
                        class="p-hidden-accessible p-hidden-focusable"
                        [attr.tabindex]="0"
                        (focus)="onLastHiddenFocus($event)"
                        [attr.data-p-hidden-accessible]="true"
                        [attr.data-p-hidden-focusable]="true"
                        [pBind]="ptm('lastHiddenFocusableEl')"
                    ></span>
                </div>
            </ng-template>
        </p-overlay>
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: MultiSelectItem, selector: "li[pMultiSelectItem]", inputs: ["option", "selected", "label", "disabled", "itemSize", "focused", "ariaPosInset", "ariaSetSize", "variant", "template", "checkIconTemplate", "itemCheckboxIconTemplate", "highlightOnSelect"], outputs: ["onClick", "onMouseEnter"] }, { kind: "component", type: Overlay, selector: "p-overlay", inputs: ["hostName", "visible", "mode", "style", "styleClass", "contentStyle", "contentStyleClass", "target", "autoZIndex", "baseZIndex", "showTransitionOptions", "hideTransitionOptions", "listener", "responsive", "options", "appendTo", "inline", "motionOptions", "hostAttrSelector"], outputs: ["visibleChange", "onBeforeShow", "onShow", "onBeforeHide", "onHide", "onAnimationStart", "onAnimationDone", "onBeforeEnter", "onEnter", "onAfterEnter", "onBeforeLeave", "onLeave", "onAfterLeave"] }, { kind: "ngmodule", type: SharedModule }, { kind: "directive", type: Tooltip, selector: "[pTooltip]", inputs: ["tooltipPosition", "tooltipEvent", "positionStyle", "tooltipStyleClass", "tooltipZIndex", "escape", "showDelay", "hideDelay", "life", "positionTop", "positionLeft", "autoHide", "fitContent", "hideOnEscape", "showOnEllipsis", "pTooltip", "tooltipDisabled", "tooltipOptions", "appendTo", "ptTooltip", "pTooltipPT", "pTooltipUnstyled"] }, { kind: "component", type: Scroller, selector: "p-scroller, p-virtualscroller, p-virtual-scroller, p-virtualScroller", inputs: ["hostName", "id", "style", "styleClass", "tabindex", "items", "itemSize", "scrollHeight", "scrollWidth", "orientation", "step", "delay", "resizeDelay", "appendOnly", "inline", "lazy", "disabled", "loaderDisabled", "columns", "showSpacer", "showLoader", "numToleratedItems", "loading", "autoSize", "trackBy", "options"], outputs: ["onLazyLoad", "onScroll", "onScrollIndexChange"] }, { kind: "directive", type: AutoFocus, selector: "[pAutoFocus]", inputs: ["pAutoFocus"] }, { kind: "component", type: CheckIcon, selector: "[data-p-icon=\"check\"]" }, { kind: "component", type: SearchIcon, selector: "[data-p-icon=\"search\"]" }, { kind: "component", type: TimesIcon, selector: "[data-p-icon=\"times\"]" }, { kind: "component", type: ChevronDownIcon, selector: "[data-p-icon=\"chevron-down\"]" }, { kind: "component", type: IconField, selector: "p-iconfield, p-iconField, p-icon-field", inputs: ["hostName", "iconPosition", "styleClass"] }, { kind: "component", type: InputIcon, selector: "p-inputicon, p-inputIcon", inputs: ["hostName", "styleClass"] }, { kind: "directive", type: InputText, selector: "[pInputText]", inputs: ["hostName", "ptInputText", "pInputTextPT", "pInputTextUnstyled", "pSize", "variant", "fluid", "invalid"] }, { kind: "component", type: Chip, selector: "p-chip", inputs: ["label", "icon", "image", "alt", "styleClass", "disabled", "removable", "removeIcon", "chipProps"], outputs: ["onRemove", "onImageError"] }, { kind: "component", type: Checkbox, selector: "p-checkbox, p-checkBox, p-check-box", inputs: ["hostName", "value", "binary", "ariaLabelledBy", "ariaLabel", "tabindex", "inputId", "inputStyle", "styleClass", "inputClass", "indeterminate", "formControl", "checkboxIcon", "readonly", "autofocus", "trueValue", "falseValue", "variant", "size"], outputs: ["onChange", "onFocus", "onBlur"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: BindModule }, { kind: "directive", type: i3.Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MultiSelect, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-multiSelect, p-multiselect, p-multi-select',
                    standalone: true,
                    imports: [CommonModule, MultiSelectItem, Overlay, SharedModule, Tooltip, Scroller, AutoFocus, CheckIcon, SearchIcon, TimesIcon, ChevronDownIcon, IconField, InputIcon, InputText, Chip, Checkbox, FormsModule, BindModule],
                    hostDirectives: [Bind],
                    template: `
        <div class="p-hidden-accessible" [attr.data-p-hidden-accessible]="true" [pBind]="ptm('hiddenInputContainer')">
            <input
                #focusInput
                [pTooltip]="tooltip()"
                [pTooltipUnstyled]="unstyled()"
                [tooltipPosition]="tooltipPosition()"
                [positionStyle]="tooltipPositionStyle()"
                [tooltipStyleClass]="tooltipStyleClass()"
                [attr.aria-disabled]="$disabled()"
                [attr.id]="inputId()"
                role="combobox"
                [attr.aria-label]="ariaLabel()"
                [attr.aria-labelledby]="ariaLabelledBy()"
                [attr.aria-haspopup]="'listbox'"
                [attr.aria-expanded]="overlayVisible() ?? false"
                [attr.aria-controls]="overlayVisible() ? id() + '_list' : null"
                [attr.tabindex]="!$disabled() ? tabindex() : -1"
                [attr.aria-activedescendant]="focused ? focusedOptionId : undefined"
                (focus)="onInputFocus($event)"
                (blur)="onInputBlur($event)"
                (keydown)="onKeyDown($event)"
                [pAutoFocus]="autofocus()"
                [attr.value]="modelValue()"
                [attr.name]="name()"
                [attr.required]="required() ? '' : undefined"
                [attr.disabled]="$disabled() ? '' : undefined"
                [pBind]="ptm('hiddenInput')"
            />
        </div>
        <div
            [pBind]="ptm('labelContainer')"
            [class]="cx('labelContainer')"
            [pTooltip]="tooltip()"
            [pTooltipUnstyled]="unstyled()"
            (mouseleave)="labelContainerMouseLeave()"
            [tooltipDisabled]="_disableTooltip"
            [tooltipPosition]="tooltipPosition()"
            [positionStyle]="tooltipPositionStyle()"
            [tooltipStyleClass]="tooltipStyleClass()"
        >
            <div [pBind]="ptm('label')" [class]="cx('label')" [attr.data-p]="labelDataP">
                @if (!selectedItemsTemplate && !_selectedItemsTemplate) {
                    @if (display() === 'comma') {
                        <ng-container>{{ label() || 'empty' }}</ng-container>
                    }
                    @if (display() === 'chip') {
                        @if (chipSelectedItems() && chipSelectedItems().length === maxSelectedLabels) {
                            {{ getSelectedItemsLabel() }}
                        } @else {
                            @for (item of chipSelectedItems(); track item; let i = $index) {
                                <div #token [pBind]="ptm('chipItem')" [class]="cx('chipItem')">
                                    <p-chip
                                        [pt]="ptm('pcChip')"
                                        [unstyled]="unstyled()"
                                        [class]="cx('pcChip')"
                                        [label]="getLabelByValue(item)"
                                        [removable]="!$disabled() && !readonly()"
                                        (onRemove)="removeOption(item, $event)"
                                        [removeIcon]="chipIcon()"
                                    >
                                        @if (chipIconTemplate || _chipIconTemplate || removeTokenIconTemplate || _removeTokenIconTemplate) {
                                            <ng-template #removeicon>
                                                @if (!$disabled() && !readonly()) {
                                                    <span [class]="cx('chipIcon')" (click)="removeOption(item, $event)" [attr.aria-hidden]="true" [pBind]="ptm('chipIcon')">
                                                        <ng-container *ngTemplateOutlet="chipIconTemplate || _chipIconTemplate || removeTokenIconTemplate || _removeTokenIconTemplate; context: { class: 'p-multiselect-chip-icon' }"></ng-container>
                                                    </span>
                                                }
                                            </ng-template>
                                        }
                                    </p-chip>
                                </div>
                            }
                        }
                        @if (!modelValue() || modelValue().length === 0) {
                            <ng-container>{{ placeholder() || 'empty' }}</ng-container>
                        }
                    }
                }
                @if (selectedItemsTemplate || _selectedItemsTemplate) {
                    <ng-container *ngTemplateOutlet="selectedItemsTemplate || _selectedItemsTemplate; context: { $implicit: selectedOptions, removeChip: removeOption.bind(this) }"></ng-container>
                    @if (!modelValue() || modelValue().length === 0) {
                        <ng-container>{{ placeholder() || 'empty' }}</ng-container>
                    }
                }
            </div>
        </div>
        @if (isVisibleClearIcon) {
            <ng-container>
                @if (!clearIconTemplate && !_clearIconTemplate) {
                    <svg data-p-icon="times" [pBind]="ptm('clearIcon')" [class]="cx('clearIcon')" (click)="clear($event)" [attr.aria-hidden]="true" />
                }
                @if (clearIconTemplate || _clearIconTemplate) {
                    <span [pBind]="ptm('clearIcon')" [class]="cx('clearIcon')" (click)="clear($event)" [attr.aria-hidden]="true">
                        <ng-template *ngTemplateOutlet="clearIconTemplate || _clearIconTemplate"></ng-template>
                    </span>
                }
            </ng-container>
        }
        <div [pBind]="ptm('dropdown')" [class]="cx('dropdown')">
            @if (loading()) {
                <ng-container>
                    @if (loadingIconTemplate || _loadingIconTemplate) {
                        <ng-container *ngTemplateOutlet="loadingIconTemplate || _loadingIconTemplate"></ng-container>
                    }
                    @if (!loadingIconTemplate && !_loadingIconTemplate) {
                        <ng-container>
                            @if (loadingIcon()) {
                                <span [pBind]="ptm('loadingIcon')" [class]="cn(cx('loadingIcon'), 'pi-spin ' + loadingIcon())" [attr.aria-hidden]="true"></span>
                            }
                            @if (!loadingIcon()) {
                                <span [pBind]="ptm('loadingIcon')" [class]="cn(cx('loadingIcon'), 'pi pi-spinner pi-spin')" [attr.aria-hidden]="true"></span>
                            }
                        </ng-container>
                    }
                </ng-container>
            } @else {
                @if (!dropdownIconTemplate && !_dropdownIconTemplate) {
                    <ng-container>
                        @if (dropdownIcon()) {
                            <span [pBind]="ptm('dropdownIcon')" [class]="cx('dropdownIcon')" [ngClass]="dropdownIcon()" [attr.aria-hidden]="true" [attr.data-p]="dropdownIconDataP"></span>
                        }
                        @if (!dropdownIcon()) {
                            <svg data-p-icon="chevron-down" [pBind]="ptm('dropdownIcon')" [class]="cx('dropdownIcon')" [attr.aria-hidden]="true" [attr.data-p]="dropdownIconDataP" />
                        }
                    </ng-container>
                }
                @if (dropdownIconTemplate || _dropdownIconTemplate) {
                    <span [pBind]="ptm('dropdownIcon')" [class]="cx('dropdownIcon')" [attr.aria-hidden]="true">
                        <ng-template *ngTemplateOutlet="dropdownIconTemplate || _dropdownIconTemplate; context: { dataP: dropdownIconDataP }"></ng-template>
                    </span>
                }
            }
        </div>
        <p-overlay
            #overlay
            [hostAttrSelector]="$attrSelector"
            [visible]="overlayVisible()"
            (visibleChange)="overlayVisible.set($event)"
            [options]="overlayOptions()"
            [target]="'@parent'"
            [appendTo]="$appendTo()"
            [unstyled]="unstyled()"
            [pt]="ptm('pcOverlay')"
            [motionOptions]="motionOptions()"
            (onBeforeEnter)="onOverlayBeforeEnter($event)"
            (onAfterLeave)="onOverlayAfterLeave($event)"
            (onHide)="onOverlayHide()"
        >
            <ng-template #content>
                <div [pBind]="ptm('overlay')" [attr.data-p]="overlayDataP" [attr.id]="id() + '_list'" [class]="cn(cx('overlay'), panelStyleClass())" [ngStyle]="panelStyle()">
                    <span
                        #firstHiddenFocusableEl
                        role="presentation"
                        class="p-hidden-accessible p-hidden-focusable"
                        [attr.tabindex]="0"
                        (focus)="onFirstHiddenFocus($event)"
                        [attr.data-p-hidden-accessible]="true"
                        [attr.data-p-hidden-focusable]="true"
                        [pBind]="ptm('firstHiddenFocusableEl')"
                    >
                    </span>
                    <ng-container *ngTemplateOutlet="headerTemplate() || _headerTemplate"></ng-container>
                    @if (showHeader()) {
                        <div [pBind]="ptm('header')" [class]="cx('header')">
                            <ng-content select="p-header"></ng-content>
                            @if (filterTemplate || _filterTemplate) {
                                <ng-container *ngTemplateOutlet="filterTemplate || _filterTemplate; context: { options: filterOptions }"></ng-container>
                            } @else {
                                @if (showToggleAll() && !selectionLimit()) {
                                    <p-checkbox
                                        [pt]="getHeaderCheckboxPTOptions('pcHeaderCheckbox')"
                                        [ngModel]="allSelected()"
                                        [ariaLabel]="toggleAllAriaLabel"
                                        [binary]="true"
                                        (onChange)="onToggleAll($event)"
                                        [variant]="$variant()"
                                        [disabled]="$disabled()"
                                        [unstyled]="unstyled()"
                                        #headerCheckbox
                                    >
                                        <ng-template #icon let-klass="class">
                                            @if (!headerCheckboxIconTemplate() && !_headerCheckboxIconTemplate && allSelected()) {
                                                <svg data-p-icon="check" [class]="klass" [pBind]="getHeaderCheckboxPTOptions('pcHeaderCheckbox.icon')" />
                                            }
                                            <ng-template
                                                *ngTemplateOutlet="
                                                    headerCheckboxIconTemplate() || _headerCheckboxIconTemplate;
                                                    context: {
                                                        checked: allSelected(),
                                                        partialSelected: partialSelected(),
                                                        class: klass
                                                    }
                                                "
                                            ></ng-template>
                                        </ng-template>
                                    </p-checkbox>
                                }

                                @if (filter()) {
                                    <p-iconfield [pt]="ptm('pcFilterContainer')" [class]="cx('pcFilterContainer')" [unstyled]="unstyled()">
                                        <input
                                            #filterInput
                                            pInputText
                                            [pt]="ptm('pcFilter')"
                                            [variant]="$variant()"
                                            type="text"
                                            [attr.autocomplete]="autocomplete()"
                                            role="searchbox"
                                            [attr.aria-owns]="id() + '_list'"
                                            [attr.aria-activedescendant]="focusedOptionId"
                                            [value]="_filterValue() || ''"
                                            (input)="onFilterInputChange($event)"
                                            (keydown)="onFilterKeyDown($event)"
                                            (click)="onInputClick($event)"
                                            (blur)="onFilterBlur($event)"
                                            [class]="cx('pcFilter')"
                                            [attr.disabled]="$disabled() ? '' : undefined"
                                            [attr.placeholder]="filterPlaceHolder()"
                                            [attr.aria-label]="ariaFilterLabel()"
                                            [unstyled]="unstyled()"
                                        />
                                        <p-inputicon [pt]="ptm('pcFilterIconContainer')" [unstyled]="unstyled()">
                                            @if (!filterIconTemplate && !_filterIconTemplate) {
                                                <svg data-p-icon="search" [pBind]="ptm('filterIcon')" />
                                            }
                                            @if (filterIconTemplate || _filterIconTemplate) {
                                                <span [pBind]="ptm('filterIcon')" class="p-multiselect-filter-icon">
                                                    <ng-template *ngTemplateOutlet="filterIconTemplate || _filterIconTemplate"></ng-template>
                                                </span>
                                            }
                                        </p-inputicon>
                                    </p-iconfield>
                                }
                            }
                        </div>
                    }
                    <div [pBind]="ptm('listContainer')" [class]="cx('listContainer')" [style.max-height]="virtualScroll() ? 'auto' : scrollHeight() || 'auto'">
                        @if (virtualScroll()) {
                            <p-scroller
                                #scroller
                                [items]="visibleOptions()"
                                [style]="{ height: scrollHeight() }"
                                [itemSize]="virtualScrollItemSize()"
                                [autoSize]="true"
                                [tabindex]="-1"
                                [lazy]="lazy()"
                                (onLazyLoad)="onLazyLoad.emit($event)"
                                [options]="virtualScrollOptions()"
                            >
                                <ng-template #content let-items let-scrollerOptions="options">
                                    <ng-container *ngTemplateOutlet="buildInItems; context: { $implicit: items, options: scrollerOptions }"></ng-container>
                                </ng-template>
                                @if (loaderTemplate || _loaderTemplate) {
                                    <ng-template #loader let-scrollerOptions="options">
                                        <ng-container *ngTemplateOutlet="loaderTemplate || _loaderTemplate; context: { options: scrollerOptions }"></ng-container>
                                    </ng-template>
                                }
                            </p-scroller>
                        }
                        @if (!virtualScroll()) {
                            <ng-container *ngTemplateOutlet="buildInItems; context: { $implicit: visibleOptions(), options: {} }"></ng-container>
                        }

                        <ng-template #buildInItems let-items let-scrollerOptions="options">
                            <ul #items [pBind]="ptm('list')" [class]="cn(cx('list'), scrollerOptions.contentStyleClass)" [style]="scrollerOptions.contentStyle" role="listbox" aria-multiselectable="true" [attr.aria-label]="listLabel">
                                @for (option of items; track option; let i = $index) {
                                    @if (isOptionGroup(option)) {
                                        <li [pBind]="ptm('optionGroup')" [attr.id]="id() + '_' + getOptionIndex(i, scrollerOptions)" [class]="cx('optionGroup')" [ngStyle]="{ height: scrollerOptions.itemSize + 'px' }" role="option">
                                            @if (!groupTemplate && option.optionGroup) {
                                                <span>{{ getOptionGroupLabel(option.optionGroup) }}</span>
                                            }
                                            @if (option.optionGroup && groupTemplate) {
                                                <ng-container [ngTemplateOutlet]="groupTemplate" [ngTemplateOutletContext]="{ $implicit: option.optionGroup }"></ng-container>
                                            }
                                        </li>
                                    }
                                    @if (!isOptionGroup(option)) {
                                        <li
                                            pMultiSelectItem
                                            pRipple
                                            [pBind]="getPTOptions(option, getItemOptions, i, 'option')"
                                            [id]="id() + '_' + getOptionIndex(i, scrollerOptions)"
                                            [option]="option"
                                            [selected]="isSelected(option)"
                                            [label]="getOptionLabel(option)"
                                            [disabled]="isOptionDisabled(option)"
                                            [template]="itemTemplate() || _itemTemplate"
                                            [itemCheckboxIconTemplate]="itemCheckboxIconTemplate() || _itemCheckboxIconTemplate"
                                            [itemSize]="scrollerOptions.itemSize"
                                            [focused]="focusedOptionIndex() === getOptionIndex(i, scrollerOptions)"
                                            [ariaPosInset]="getAriaPosInset(getOptionIndex(i, scrollerOptions))"
                                            [ariaSetSize]="ariaSetSize"
                                            [variant]="$variant()"
                                            [highlightOnSelect]="highlightOnSelect()"
                                            (onClick)="onOptionSelect($event, false, getOptionIndex(i, scrollerOptions))"
                                            (onMouseEnter)="onOptionMouseEnter($event, getOptionIndex(i, scrollerOptions))"
                                            [pt]="pt"
                                            [unstyled]="unstyled()"
                                        ></li>
                                    }
                                }

                                @if (hasFilter() && isEmpty()) {
                                    <li [pBind]="ptm('emptyMessage')" [class]="cx('emptyMessage')" [ngStyle]="{ height: scrollerOptions.itemSize + 'px' }" role="option">
                                        @if (!emptyFilterTemplate() && !_emptyFilterTemplate && !emptyTemplate() && !_emptyTemplate) {
                                            {{ emptyFilterMessageLabel }}
                                        } @else {
                                            <ng-container *ngTemplateOutlet="emptyFilterTemplate() || _emptyFilterTemplate || emptyTemplate() || _emptyFilterTemplate"></ng-container>
                                        }
                                    </li>
                                }
                                @if (!hasFilter() && isEmpty()) {
                                    <li [pBind]="ptm('emptyMessage')" [class]="cx('emptyMessage')" [ngStyle]="{ height: scrollerOptions.itemSize + 'px' }" role="option">
                                        @if (!emptyTemplate() && !_emptyTemplate) {
                                            {{ emptyMessageLabel }}
                                        } @else {
                                            <ng-container *ngTemplateOutlet="emptyTemplate() || _emptyTemplate"></ng-container>
                                        }
                                    </li>
                                }
                            </ul>
                        </ng-template>
                    </div>
                    @if (footerFacet() || footerTemplate || _footerTemplate) {
                        <div>
                            <ng-content select="p-footer"></ng-content>
                            <ng-container *ngTemplateOutlet="footerTemplate || _footerTemplate"></ng-container>
                        </div>
                    }

                    <span
                        #lastHiddenFocusableEl
                        role="presentation"
                        class="p-hidden-accessible p-hidden-focusable"
                        [attr.tabindex]="0"
                        (focus)="onLastHiddenFocus($event)"
                        [attr.data-p-hidden-accessible]="true"
                        [attr.data-p-hidden-focusable]="true"
                        [pBind]="ptm('lastHiddenFocusableEl')"
                    ></span>
                </div>
            </ng-template>
        </p-overlay>
    `,
                    providers: [MULTISELECT_VALUE_ACCESSOR, MultiSelectStyle, { provide: MULTISELECT_INSTANCE, useExisting: MultiSelect }, { provide: PARENT_INSTANCE, useExisting: MultiSelect }],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[attr.id]': 'resolvedId',
                        '[attr.data-p]': 'containerDataP',
                        '(click)': 'onContainerClick($event)',
                        '[class]': "cn(cx('root'), styleClass())",
                        '[style]': "sx('root')"
                    }
                }]
        }], ctorParameters: () => [], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], panelStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelStyle", required: false }] }], panelStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelStyleClass", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], group: [{ type: i0.Input, args: [{ isSignal: true, alias: "group", required: false }] }], filter: [{ type: i0.Input, args: [{ isSignal: true, alias: "filter", required: false }] }], filterPlaceHolder: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterPlaceHolder", required: false }] }], filterLocale: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterLocale", required: false }] }], overlayVisible: [{ type: i0.Input, args: [{ isSignal: true, alias: "overlayVisible", required: false }] }, { type: i0.Output, args: ["overlayVisibleChange"] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], dataKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataKey", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], displaySelectedLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "displaySelectedLabel", required: false }] }], maxSelectedLabels: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxSelectedLabels", required: false }] }], selectionLimit: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectionLimit", required: false }] }], selectedItemsLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectedItemsLabel", required: false }] }], showToggleAll: [{ type: i0.Input, args: [{ isSignal: true, alias: "showToggleAll", required: false }] }], emptyFilterMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyFilterMessage", required: false }] }], emptyMessage: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptyMessage", required: false }] }], resetFilterOnHide: [{ type: i0.Input, args: [{ isSignal: true, alias: "resetFilterOnHide", required: false }] }], dropdownIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "dropdownIcon", required: false }] }], chipIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "chipIcon", required: false }] }], optionLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionLabel", required: false }] }], optionValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionValue", required: false }] }], optionDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionDisabled", required: false }] }], optionGroupLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionGroupLabel", required: false }] }], optionGroupChildren: [{ type: i0.Input, args: [{ isSignal: true, alias: "optionGroupChildren", required: false }] }], showHeader: [{ type: i0.Input, args: [{ isSignal: true, alias: "showHeader", required: false }] }], filterBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterBy", required: false }] }], scrollHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollHeight", required: false }] }], lazy: [{ type: i0.Input, args: [{ isSignal: true, alias: "lazy", required: false }] }], virtualScroll: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScroll", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], virtualScrollItemSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScrollItemSize", required: false }] }], loadingIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "loadingIcon", required: false }] }], virtualScrollOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScrollOptions", required: false }] }], overlayOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "overlayOptions", required: false }] }], ariaFilterLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaFilterLabel", required: false }] }], filterMatchMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterMatchMode", required: false }] }], tooltip: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltip", required: false }] }], tooltipPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipPosition", required: false }] }], tooltipPositionStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipPositionStyle", required: false }] }], tooltipStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "tooltipStyleClass", required: false }] }], autofocusFilter: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocusFilter", required: false }] }], display: [{ type: i0.Input, args: [{ isSignal: true, alias: "display", required: false }] }], autocomplete: [{ type: i0.Input, args: [{ isSignal: true, alias: "autocomplete", required: false }] }], showClear: [{ type: i0.Input, args: [{ isSignal: true, alias: "showClear", required: false }] }], autofocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autofocus", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], filterValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterValue", required: false }] }], selectAll: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectAll", required: false }] }], focusOnHover: [{ type: i0.Input, args: [{ isSignal: true, alias: "focusOnHover", required: false }] }], filterFields: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterFields", required: false }] }], selectOnFocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectOnFocus", required: false }] }], autoOptionFocus: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoOptionFocus", required: false }] }], highlightOnSelect: [{ type: i0.Input, args: [{ isSignal: true, alias: "highlightOnSelect", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], fluid: [{ type: i0.Input, args: [{ isSignal: true, alias: "fluid", required: false }] }], appendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "appendTo", required: false }] }], motionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "motionOptions", required: false }] }], onChange: [{ type: i0.Output, args: ["onChange"] }], onFilter: [{ type: i0.Output, args: ["onFilter"] }], onFocus: [{ type: i0.Output, args: ["onFocus"] }], onBlur: [{ type: i0.Output, args: ["onBlur"] }], onClick: [{ type: i0.Output, args: ["onClick"] }], onClear: [{ type: i0.Output, args: ["onClear"] }], onPanelShow: [{ type: i0.Output, args: ["onPanelShow"] }], onPanelHide: [{ type: i0.Output, args: ["onPanelHide"] }], onLazyLoad: [{ type: i0.Output, args: ["onLazyLoad"] }], onRemove: [{ type: i0.Output, args: ["onRemove"] }], onSelectAllChange: [{ type: i0.Output, args: ["onSelectAllChange"] }], overlayViewChild: [{ type: i0.ViewChild, args: ['overlay', { isSignal: true }] }], filterInputChild: [{ type: i0.ViewChild, args: ['filterInput', { isSignal: true }] }], focusInputViewChild: [{ type: i0.ViewChild, args: ['focusInput', { isSignal: true }] }], itemsViewChild: [{ type: i0.ViewChild, args: ['items', { isSignal: true }] }], scroller: [{ type: i0.ViewChild, args: ['scroller', { isSignal: true }] }], lastHiddenFocusableElementOnOverlay: [{ type: i0.ViewChild, args: ['lastHiddenFocusableEl', { isSignal: true }] }], firstHiddenFocusableElementOnOverlay: [{ type: i0.ViewChild, args: ['firstHiddenFocusableEl', { isSignal: true }] }], headerCheckboxViewChild: [{ type: i0.ViewChild, args: ['headerCheckbox', { isSignal: true }] }], footerFacet: [{ type: i0.ContentChild, args: [i0.forwardRef(() => Footer), { isSignal: true }] }], headerFacet: [{ type: i0.ContentChild, args: [i0.forwardRef(() => Header), { isSignal: true }] }], itemTemplate: [{ type: i0.ContentChild, args: ['item', { ...{ descendants: false }, isSignal: true }] }], groupTemplate: [{
                type: ContentChild,
                args: ['group', { descendants: false }]
            }], loaderTemplate: [{
                type: ContentChild,
                args: ['loader', { descendants: false }]
            }], headerTemplate: [{ type: i0.ContentChild, args: ['header', { ...{ descendants: false }, isSignal: true }] }], filterTemplate: [{
                type: ContentChild,
                args: ['filter', { descendants: false }]
            }], footerTemplate: [{
                type: ContentChild,
                args: ['footer', { descendants: false }]
            }], emptyFilterTemplate: [{ type: i0.ContentChild, args: ['emptyfilter', { ...{ descendants: false }, isSignal: true }] }], emptyTemplate: [{ type: i0.ContentChild, args: ['empty', { ...{ descendants: false }, isSignal: true }] }], selectedItemsTemplate: [{
                type: ContentChild,
                args: ['selecteditems', { descendants: false }]
            }], loadingIconTemplate: [{
                type: ContentChild,
                args: ['loadingicon', { descendants: false }]
            }], filterIconTemplate: [{
                type: ContentChild,
                args: ['filtericon', { descendants: false }]
            }], removeTokenIconTemplate: [{
                type: ContentChild,
                args: ['removetokenicon', { descendants: false }]
            }], chipIconTemplate: [{
                type: ContentChild,
                args: ['chipicon', { descendants: false }]
            }], clearIconTemplate: [{
                type: ContentChild,
                args: ['clearicon', { descendants: false }]
            }], dropdownIconTemplate: [{
                type: ContentChild,
                args: ['dropdownicon', { descendants: false }]
            }], itemCheckboxIconTemplate: [{ type: i0.ContentChild, args: ['itemcheckboxicon', { ...{ descendants: false }, isSignal: true }] }], headerCheckboxIconTemplate: [{ type: i0.ContentChild, args: ['headercheckboxicon', { ...{ descendants: false }, isSignal: true }] }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class MultiSelectModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MultiSelectModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: MultiSelectModule, imports: [MultiSelect, SharedModule], exports: [MultiSelect, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MultiSelectModule, imports: [MultiSelect, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: MultiSelectModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [MultiSelect, SharedModule],
                    exports: [MultiSelect, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { MULTISELECT_VALUE_ACCESSOR, MultiSelect, MultiSelectClasses, MultiSelectItem, MultiSelectModule, MultiSelectStyle };
//# sourceMappingURL=wawjs-ngx-prime-multiselect.mjs.map
