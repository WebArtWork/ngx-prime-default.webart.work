import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, input, numberAttribute, booleanAttribute, output, viewChild, inject, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import * as i2 from '@angular/router';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { find, findSingle } from '@wawjs/css-prime-utils';
import { SharedModule } from '@wawjs/ngx-prime/api';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';
import * as i3 from '@wawjs/ngx-prime/tooltip';
import { TooltipModule } from '@wawjs/ngx-prime/tooltip';
import { style } from '@wawjs/css-prime-styles/steps';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const classes = {
    root: ({ instance }) => ['p-steps p-component', { 'p-readonly': instance.readonly() }],
    list: 'p-steps-list',
    item: ({ instance, item, index }) => [
        'p-steps-item',
        {
            'p-steps-item-active': instance.isActive(item, index),
            'p-disabled': instance.isItemDisabled(item, index)
        }
    ],
    itemLink: 'p-steps-item-link',
    itemNumber: 'p-steps-item-number',
    itemLabel: 'p-steps-item-label'
};
class StepsStyle extends BaseStyle {
    name = 'steps';
    style = style;
    classes = classes;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: StepsStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: StepsStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: StepsStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * Steps components is an indicator for the steps in a wizard workflow. Example below uses nested routes with Steps.
 *
 * [Live Demo](https://www.ngx-prime.org/steps/)
 *
 * @module stepsstyle
 *
 */
var StepsClasses;
(function (StepsClasses) {
    /**
     * Class name of the root element
     */
    StepsClasses["root"] = "p-steps";
    /**
     * Class name of the list element
     */
    StepsClasses["list"] = "p-steps-list";
    /**
     * Class name of the item element
     */
    StepsClasses["item"] = "p-steps-item";
    /**
     * Class name of the item link element
     */
    StepsClasses["itemLink"] = "p-steps-item-link";
    /**
     * Class name of the item number element
     */
    StepsClasses["itemNumber"] = "p-steps-item-number";
    /**
     * Class name of the item label element
     */
    StepsClasses["itemLabel"] = "p-steps-item-label";
})(StepsClasses || (StepsClasses = {}));

/**
 * Steps components is an indicator for the steps in a wizard workflow.
 * @group Components
 */
class Steps extends BaseComponent {
    componentName = 'Steps';
    /**
     * Index of the active item.
     * @group Props
     */
    activeIndex = input(0, { ...(ngDevMode ? { debugName: "activeIndex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * An array of menu items.
     * @group Props
     */
    model = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "model" }] : /* istanbul ignore next */ []));
    /**
     * Whether the items are clickable or not.
     * @group Props
     */
    readonly = input(true, { ...(ngDevMode ? { debugName: "readonly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Inline style of the component.
     * @group Props
     */
    style = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "style" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the component.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Whether to apply 'router-link-active-exact' class if route exactly matches the item path.
     * @group Props
     */
    exact = input(true, { ...(ngDevMode ? { debugName: "exact" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Callback to invoke when the new step is selected.
     * @param {number} number - current index.
     * @group Emits
     */
    activeIndexChange = output();
    listViewChild = viewChild('list', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "listViewChild" }] : /* istanbul ignore next */ []));
    router = inject(Router);
    route = inject(ActivatedRoute);
    _componentStyle = inject(StepsStyle);
    subscription;
    onInit() {
        this.subscription = this.router.events.subscribe(() => this.cd.markForCheck());
    }
    onItemClick(event, item, i) {
        if (this.readonly() || item.disabled) {
            event.preventDefault();
            return;
        }
        this.activeIndexChange.emit(i);
        if (!item.url && !item.routerLink) {
            event.preventDefault();
        }
        if (item.command) {
            item.command({
                originalEvent: event,
                item: item,
                index: i
            });
        }
    }
    onItemKeydown(event, item, i) {
        switch (event.code) {
            case 'ArrowRight': {
                this.navigateToNextItem(event.target);
                event.preventDefault();
                break;
            }
            case 'ArrowLeft': {
                this.navigateToPrevItem(event.target);
                event.preventDefault();
                break;
            }
            case 'Home': {
                this.navigateToFirstItem(event.target);
                event.preventDefault();
                break;
            }
            case 'End': {
                this.navigateToLastItem(event.target);
                event.preventDefault();
                break;
            }
            case 'Tab':
                if (i !== (this.activeIndex() ?? -1)) {
                    const siblings = find(this.listViewChild()?.nativeElement, '[data-pc-section="menuitem"]');
                    siblings[i].children[0].tabIndex = '-1';
                    siblings[this.activeIndex() ?? 0].children[0].tabIndex = '0';
                }
                break;
            case 'Enter':
            case 'Space': {
                this.onItemClick(event, item, i);
                event.preventDefault();
                break;
            }
            default:
                break;
        }
    }
    navigateToNextItem(target) {
        const nextItem = this.findNextItem(target);
        nextItem && this.setFocusToMenuitem(target, nextItem);
    }
    navigateToPrevItem(target) {
        const prevItem = this.findPrevItem(target);
        prevItem && this.setFocusToMenuitem(target, prevItem);
    }
    navigateToFirstItem(target) {
        const firstItem = this.findFirstItem();
        firstItem && this.setFocusToMenuitem(target, firstItem);
    }
    navigateToLastItem(target) {
        const lastItem = this.findLastItem();
        lastItem && this.setFocusToMenuitem(target, lastItem);
    }
    findNextItem(item) {
        const nextItem = item.parentElement.nextElementSibling;
        return nextItem ? nextItem.children[0] : null;
    }
    findPrevItem(item) {
        const prevItem = item.parentElement.previousElementSibling;
        return prevItem ? prevItem.children[0] : null;
    }
    findFirstItem() {
        const firstSibling = findSingle(this.listViewChild()?.nativeElement, '[data-pc-section="menuitem"]');
        return firstSibling ? firstSibling.children[0] : null;
    }
    findLastItem() {
        const siblings = find(this.listViewChild()?.nativeElement, '[data-pc-section="menuitem"]');
        return siblings ? siblings[siblings.length - 1].children[0] : null;
    }
    setFocusToMenuitem(target, focusableItem) {
        target.tabIndex = '-1';
        focusableItem.tabIndex = '0';
        focusableItem.focus();
    }
    isClickableRouterLink(item) {
        return item.routerLink && !this.readonly() && !item.disabled;
    }
    isItemDisabled(item, index) {
        return item.disabled || (this.readonly() && !this.isActive(item, index));
    }
    isActive(item, index) {
        if (item.routerLink) {
            let routerLink = Array.isArray(item.routerLink) ? item.routerLink : [item.routerLink];
            return this.router.isActive(this.router.createUrlTree(routerLink, { relativeTo: this.route }).toString(), false);
        }
        return index === this.activeIndex();
    }
    getItemTabIndex(item, index) {
        if (item.disabled) {
            return '-1';
        }
        if (!item.disabled && this.activeIndex() === index) {
            return item.tabindex || '0';
        }
        return item.tabindex ?? '-1';
    }
    onDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Steps, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: Steps, isStandalone: true, selector: "p-steps", inputs: { activeIndex: { classPropertyName: "activeIndex", publicName: "activeIndex", isSignal: true, isRequired: false, transformFunction: null }, model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: false, transformFunction: null }, readonly: { classPropertyName: "readonly", publicName: "readonly", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, exact: { classPropertyName: "exact", publicName: "exact", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { activeIndexChange: "activeIndexChange" }, providers: [StepsStyle], viewQueries: [{ propertyName: "listViewChild", first: true, predicate: ["list"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: `
        <nav [class]="cn(cx('root'), styleClass())" [ngStyle]="style()" [attr.data-pc-name]="'steps'">
            <ul #list [attr.data-pc-section]="'menu'" [class]="cx('list')">
                @for (item of model(); track item.label; let i = $index) {
                    @if (item.visible !== false) {
                        <li
                            [class]="cx('item', { item, index: i })"
                            #menuitem
                            [ngStyle]="item.style"
                            [attr.aria-current]="isActive(item, i) ? 'step' : undefined"
                            [attr.id]="item.id"
                            pTooltip
                            [tooltipOptions]="item.tooltipOptions"
                            [pTooltipUnstyled]="unstyled()"
                            [attr.data-pc-section]="'menuitem'"
                        >
                            @if (isClickableRouterLink(item)) {
                                <a
                                    role="link"
                                    [routerLink]="item.routerLink"
                                    [queryParams]="item.queryParams"
                                    [routerLinkActiveOptions]="item.routerLinkActiveOptions || { exact: false }"
                                    [class]="cx('itemLink')"
                                    (click)="onItemClick($event, item, i)"
                                    (keydown)="onItemKeydown($event, item, i)"
                                    [target]="item.target"
                                    [attr.tabindex]="getItemTabIndex(item, i)"
                                    [attr.aria-expanded]="i === activeIndex()"
                                    [attr.aria-disabled]="item.disabled || (readonly() && i !== activeIndex())"
                                    [fragment]="item.fragment"
                                    [queryParamsHandling]="item.queryParamsHandling"
                                    [preserveFragment]="item.preserveFragment"
                                    [skipLocationChange]="item.skipLocationChange"
                                    [replaceUrl]="item.replaceUrl"
                                    [state]="item.state"
                                    [attr.ariaCurrentWhenActive]="exact() ? 'step' : undefined"
                                >
                                    <span [class]="cx('itemNumber')">{{ i + 1 }}</span>
                                    @if (item.escape !== false) {
                                        <span [class]="cx('itemLabel')">{{ item.label }}</span>
                                    } @else {
                                        <span [class]="cx('itemLabel')" [innerHTML]="item.label"></span>
                                    }
                                </a>
                            } @else {
                                <a
                                    role="link"
                                    [attr.href]="item.url"
                                    [class]="cx('itemLink')"
                                    (click)="onItemClick($event, item, i)"
                                    (keydown)="onItemKeydown($event, item, i)"
                                    [target]="item.target"
                                    [attr.tabindex]="getItemTabIndex(item, i)"
                                    [attr.aria-expanded]="i === activeIndex()"
                                    [attr.aria-disabled]="item.disabled || (readonly() && i !== activeIndex())"
                                    [attr.ariaCurrentWhenActive]="exact() && (!item.disabled || readonly()) ? 'step' : undefined"
                                >
                                    <span [class]="cx('itemNumber')">{{ i + 1 }}</span>
                                    @if (item.escape !== false) {
                                        <span [class]="cx('itemLabel')">{{ item.label }}</span>
                                    } @else {
                                        <span [class]="cx('itemLabel')" [innerHTML]="item.label"></span>
                                    }
                                </a>
                            }
                        </li>
                    }
                }
            </ul>
        </nav>
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i2.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "browserUrl", "routerLink"] }, { kind: "ngmodule", type: TooltipModule }, { kind: "directive", type: i3.Tooltip, selector: "[pTooltip]", inputs: ["tooltipPosition", "tooltipEvent", "positionStyle", "tooltipStyleClass", "tooltipZIndex", "escape", "showDelay", "hideDelay", "life", "positionTop", "positionLeft", "autoHide", "fitContent", "hideOnEscape", "showOnEllipsis", "pTooltip", "tooltipDisabled", "tooltipOptions", "appendTo", "ptTooltip", "pTooltipPT", "pTooltipUnstyled"] }, { kind: "ngmodule", type: SharedModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Steps, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-steps',
                    standalone: true,
                    imports: [CommonModule, RouterModule, TooltipModule, SharedModule],
                    template: `
        <nav [class]="cn(cx('root'), styleClass())" [ngStyle]="style()" [attr.data-pc-name]="'steps'">
            <ul #list [attr.data-pc-section]="'menu'" [class]="cx('list')">
                @for (item of model(); track item.label; let i = $index) {
                    @if (item.visible !== false) {
                        <li
                            [class]="cx('item', { item, index: i })"
                            #menuitem
                            [ngStyle]="item.style"
                            [attr.aria-current]="isActive(item, i) ? 'step' : undefined"
                            [attr.id]="item.id"
                            pTooltip
                            [tooltipOptions]="item.tooltipOptions"
                            [pTooltipUnstyled]="unstyled()"
                            [attr.data-pc-section]="'menuitem'"
                        >
                            @if (isClickableRouterLink(item)) {
                                <a
                                    role="link"
                                    [routerLink]="item.routerLink"
                                    [queryParams]="item.queryParams"
                                    [routerLinkActiveOptions]="item.routerLinkActiveOptions || { exact: false }"
                                    [class]="cx('itemLink')"
                                    (click)="onItemClick($event, item, i)"
                                    (keydown)="onItemKeydown($event, item, i)"
                                    [target]="item.target"
                                    [attr.tabindex]="getItemTabIndex(item, i)"
                                    [attr.aria-expanded]="i === activeIndex()"
                                    [attr.aria-disabled]="item.disabled || (readonly() && i !== activeIndex())"
                                    [fragment]="item.fragment"
                                    [queryParamsHandling]="item.queryParamsHandling"
                                    [preserveFragment]="item.preserveFragment"
                                    [skipLocationChange]="item.skipLocationChange"
                                    [replaceUrl]="item.replaceUrl"
                                    [state]="item.state"
                                    [attr.ariaCurrentWhenActive]="exact() ? 'step' : undefined"
                                >
                                    <span [class]="cx('itemNumber')">{{ i + 1 }}</span>
                                    @if (item.escape !== false) {
                                        <span [class]="cx('itemLabel')">{{ item.label }}</span>
                                    } @else {
                                        <span [class]="cx('itemLabel')" [innerHTML]="item.label"></span>
                                    }
                                </a>
                            } @else {
                                <a
                                    role="link"
                                    [attr.href]="item.url"
                                    [class]="cx('itemLink')"
                                    (click)="onItemClick($event, item, i)"
                                    (keydown)="onItemKeydown($event, item, i)"
                                    [target]="item.target"
                                    [attr.tabindex]="getItemTabIndex(item, i)"
                                    [attr.aria-expanded]="i === activeIndex()"
                                    [attr.aria-disabled]="item.disabled || (readonly() && i !== activeIndex())"
                                    [attr.ariaCurrentWhenActive]="exact() && (!item.disabled || readonly()) ? 'step' : undefined"
                                >
                                    <span [class]="cx('itemNumber')">{{ i + 1 }}</span>
                                    @if (item.escape !== false) {
                                        <span [class]="cx('itemLabel')">{{ item.label }}</span>
                                    } @else {
                                        <span [class]="cx('itemLabel')" [innerHTML]="item.label"></span>
                                    }
                                </a>
                            }
                        </li>
                    }
                }
            </ul>
        </nav>
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [StepsStyle]
                }]
        }], propDecorators: { activeIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeIndex", required: false }] }], model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: false }] }], readonly: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonly", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], exact: [{ type: i0.Input, args: [{ isSignal: true, alias: "exact", required: false }] }], activeIndexChange: [{ type: i0.Output, args: ["activeIndexChange"] }], listViewChild: [{ type: i0.ViewChild, args: ['list', { isSignal: true }] }] } });
class StepsModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: StepsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: StepsModule, imports: [Steps, SharedModule], exports: [Steps, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: StepsModule, imports: [Steps, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: StepsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [Steps, SharedModule],
                    exports: [Steps, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { Steps, StepsClasses, StepsModule, StepsStyle };
//# sourceMappingURL=wawjs-ngx-prime-steps.mjs.map
