export * from '@wawjs/ngx-prime/icons/angledoubledown';
export * from '@wawjs/ngx-prime/icons/angledoubleleft';
export * from '@wawjs/ngx-prime/icons/angledoubleright';
export * from '@wawjs/ngx-prime/icons/angledoubleup';
export * from '@wawjs/ngx-prime/icons/angledown';
export * from '@wawjs/ngx-prime/icons/angleleft';
export * from '@wawjs/ngx-prime/icons/angleright';
export * from '@wawjs/ngx-prime/icons/angleup';
export * from '@wawjs/ngx-prime/icons/arrowdown';
export * from '@wawjs/ngx-prime/icons/arrowdownleft';
export * from '@wawjs/ngx-prime/icons/arrowdownright';
export * from '@wawjs/ngx-prime/icons/arrowleft';
export * from '@wawjs/ngx-prime/icons/arrowright';
export * from '@wawjs/ngx-prime/icons/arrowup';
export * from '@wawjs/ngx-prime/icons/ban';
export * from '@wawjs/ngx-prime/icons/bars';
export * from '@wawjs/ngx-prime/icons/blank';
export * from '@wawjs/ngx-prime/icons/calendar';
export * from '@wawjs/ngx-prime/icons/caretleft';
export * from '@wawjs/ngx-prime/icons/caretright';
export * from '@wawjs/ngx-prime/icons/check';
export * from '@wawjs/ngx-prime/icons/chevrondown';
export * from '@wawjs/ngx-prime/icons/chevronleft';
export * from '@wawjs/ngx-prime/icons/chevronright';
export * from '@wawjs/ngx-prime/icons/chevronup';
export * from '@wawjs/ngx-prime/icons/exclamationtriangle';
export * from '@wawjs/ngx-prime/icons/eye';
export * from '@wawjs/ngx-prime/icons/eyeslash';
export * from '@wawjs/ngx-prime/icons/filter';
export * from '@wawjs/ngx-prime/icons/filterslash';
export * from '@wawjs/ngx-prime/icons/home';
export * from '@wawjs/ngx-prime/icons/infocircle';
export * from '@wawjs/ngx-prime/icons/minus';
export * from '@wawjs/ngx-prime/icons/pencil';
export * from '@wawjs/ngx-prime/icons/plus';
export * from '@wawjs/ngx-prime/icons/refresh';
export * from '@wawjs/ngx-prime/icons/search';
export * from '@wawjs/ngx-prime/icons/searchminus';
export * from '@wawjs/ngx-prime/icons/searchplus';
export * from '@wawjs/ngx-prime/icons/sortalt';
export * from '@wawjs/ngx-prime/icons/sortamountdown';
export * from '@wawjs/ngx-prime/icons/sortamountupalt';
export * from '@wawjs/ngx-prime/icons/spinner';
export * from '@wawjs/ngx-prime/icons/star';
export * from '@wawjs/ngx-prime/icons/starfill';
export * from '@wawjs/ngx-prime/icons/thlarge';
export * from '@wawjs/ngx-prime/icons/times';
export * from '@wawjs/ngx-prime/icons/timescircle';
export * from '@wawjs/ngx-prime/icons/trash';
export * from '@wawjs/ngx-prime/icons/undo';
export * from '@wawjs/ngx-prime/icons/upload';
export * from '@wawjs/ngx-prime/icons/windowmaximize';
export * from '@wawjs/ngx-prime/icons/windowminimize';

/**
 * @file
 * THIS FILE IS AUTO-GENERATED. PLEASE DO NOT MODIFY.
 */

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=wawjs-ngx-prime-icons.mjs.map
