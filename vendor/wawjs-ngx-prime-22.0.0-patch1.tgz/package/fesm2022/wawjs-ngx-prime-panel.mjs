export * from '@wawjs/ngx-prime/types/panel';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, input, booleanAttribute, model, computed, output, contentChild, contentChildren, ViewChild, ContentChild, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { uuid } from '@wawjs/css-prime-utils';
import { Footer, PrimeTemplate, SharedModule } from '@wawjs/ngx-prime/api';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind, BindModule } from '@wawjs/ngx-prime/bind';
import * as i3 from '@wawjs/ngx-prime/button';
import { ButtonModule } from '@wawjs/ngx-prime/button';
import { PlusIcon, MinusIcon } from '@wawjs/ngx-prime/icons';
import * as i4 from '@wawjs/ngx-prime/motion';
import { MotionModule } from '@wawjs/ngx-prime/motion';
import { style } from '@wawjs/css-prime-styles/panel';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const classes = {
    root: ({ instance }) => [
        'p-panel p-component',
        {
            'p-panel-toggleable': instance.toggleable(),
            'p-panel-expanded': !instance.collapsed() && instance.toggleable(),
            'p-panel-collapsed': instance.collapsed() && instance.toggleable()
        }
    ],
    header: 'p-panel-header',
    title: 'p-panel-title',
    headerActions: ({ instance }) => [
        'p-panel-header-actions',
        {
            'p-panel-icons-start': instance.iconPos() === 'start',
            'p-panel-icons-end': instance.iconPos() === 'end',
            'p-panel-icons-center': instance.iconPos() === 'center'
        }
    ],
    pcToggleButton: 'p-panel-toggle-button',
    contentContainer: 'p-panel-content-container',
    contentWrapper: 'p-panel-content-wrapper',
    content: 'p-panel-content',
    footer: 'p-panel-footer'
};
class PanelStyle extends BaseStyle {
    name = 'panel';
    style = style;
    classes = classes;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PanelStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PanelStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PanelStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * Panel is a container with the optional content toggle feature.
 *
 * [Live Demo](https://www.ngx-prime.org/panel/)
 *
 * @module panelstyle
 *
 */
var PanelClasses;
(function (PanelClasses) {
    /**
     * Class name of the root element
     */
    PanelClasses["root"] = "p-panel";
    /**
     * Class name of the header element
     */
    PanelClasses["header"] = "p-panel-header";
    /**
     * Class name of the title element
     */
    PanelClasses["title"] = "p-panel-title";
    /**
     * Class name of the header actions element
     */
    PanelClasses["headerActions"] = "p-panel-header-actions";
    /**
     * Class name of the toggle button element
     */
    PanelClasses["pcToggleButton"] = "p-panel-toggle-button";
    /**
     * Class name of the content container element
     */
    PanelClasses["contentContainer"] = "p-panel-content-container";
    /**
     * Class name of the content wrapper element
     */
    PanelClasses["contentWrapper"] = "p-panel-content-wrapper";
    /**
     * Class name of the content element
     */
    PanelClasses["content"] = "p-panel-content";
    /**
     * Class name of the footer element
     */
    PanelClasses["footer"] = "p-panel-footer";
})(PanelClasses || (PanelClasses = {}));

const PANEL_INSTANCE = new InjectionToken('PANEL_INSTANCE');
/**
 * Panel is a container with the optional content toggle feature.
 * @group Components
 */
class Panel extends BaseComponent {
    componentName = 'Panel';
    $pcPanel = inject(PANEL_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    _componentStyle = inject(PanelStyle);
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    /**
     * Id of the component.
     */
    id = input(uuid('pn_id_'), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "id" }] : /* istanbul ignore next */ []));
    /**
     * Defines if content of panel can be expanded and collapsed.
     * @group Props
     */
    toggleable = input(undefined, { ...(ngDevMode ? { debugName: "toggleable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Header text of the panel.
     * @group Props
     */
    // eslint-disable-next-line @angular-eslint/no-input-rename -- `header` is published public API; renaming would break consumers.
    _header = input(undefined, { ...(ngDevMode ? { debugName: "_header" } : /* istanbul ignore next */ {}), alias: 'header' });
    /**
     * Defines the initial state of panel content, supports one or two-way binding as well.
     * @group Props
     */
    collapsed = model(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "collapsed" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the component.
     * @group Props
     * @deprecated since v20.0.0, use `class` instead.
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Position of the icons.
     * @group Props
     */
    iconPos = input('end', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "iconPos" }] : /* istanbul ignore next */ []));
    /**
     * Specifies if header of panel cannot be displayed.
     * @group Props
     */
    showHeader = input(true, { ...(ngDevMode ? { debugName: "showHeader" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Specifies the toggler element to toggle the panel content.
     * @group Props
     */
    toggler = input('icon', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "toggler" }] : /* istanbul ignore next */ []));
    /**
     * Transition options of the animation.
     * @group Props
     * @deprecated since v21.0.0, use `motionOptions` instead.
     */
    transitionOptions = input('400ms cubic-bezier(0.86, 0, 0.07, 1)', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "transitionOptions" }] : /* istanbul ignore next */ []));
    /**
     * Used to pass all properties of the ButtonProps to the Button component.
     * @group Props
     */
    toggleButtonProps = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "toggleButtonProps" }] : /* istanbul ignore next */ []));
    /**
     * The motion options.
     * @group Props
     */
    motionOptions = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "motionOptions" }] : /* istanbul ignore next */ []));
    computedMotionOptions = computed(() => ({
        ...this.ptm('motion'),
        ...this.motionOptions()
    }), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "computedMotionOptions" }] : /* istanbul ignore next */ []));
    /**
     * Callback to invoke before panel toggle.
     * @param {PanelBeforeToggleEvent} event - Custom panel toggle event
     * @group Emits
     */
    onBeforeToggle = output();
    /**
     * Callback to invoke after panel toggle.
     * @param {PanelAfterToggleEvent} event - Custom panel toggle event
     * @group Emits
     */
    onAfterToggle = output();
    footerFacet = contentChild(Footer, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "footerFacet" }] : /* istanbul ignore next */ []));
    /**
     * Defines template option for header.
     * @group Templates
     */
    headerTemplate = contentChild('header', { ...(ngDevMode ? { debugName: "headerTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Defines template option for icons.
     * @example
     * ```html
     * <ng-template #icons> </ng-template>
     * ```
     * @group Templates
     */
    iconsTemplate = contentChild('icons', { ...(ngDevMode ? { debugName: "iconsTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Defines template option for content.
     * @example
     * ```html
     * <ng-template #content> </ng-template>
     * ```
     * @group Templates
     */
    contentTemplate = contentChild('content', { ...(ngDevMode ? { debugName: "contentTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Defines template option for footer.
     * @example
     * ```html
     * <ng-template #footer> </ng-template>
     * ```
     * @group Templates
     */
    footerTemplate;
    /**
     * Defines template option for headerIcon.
     * @param {PanelHeaderIconsTemplateContext} context - context of the template.
     * @example
     * ```html
     * <ng-template #headericons let-collapsed> </ng-template>
     * ```
     * @see {@link PanelHeaderIconsTemplateContext}
     * @group Templates
     */
    headerIconsTemplate = contentChild('headericons', { ...(ngDevMode ? { debugName: "headerIconsTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    _headerTemplate;
    _iconsTemplate;
    _contentTemplate;
    _footerTemplate;
    _headerIconsTemplate;
    contentWrapperViewChild;
    get buttonAriaLabel() {
        return this._header();
    }
    onHeaderClick(event) {
        if (this.toggler() === 'header') {
            this.toggle(event);
        }
    }
    onIconClick(event) {
        if (this.toggler() === 'icon') {
            this.toggle(event);
        }
    }
    toggle(event) {
        this.onBeforeToggle.emit({ originalEvent: event, collapsed: this.collapsed() });
        if (this.collapsed())
            this.expand();
        else
            this.collapse();
        event.preventDefault();
    }
    expand() {
        this.collapsed.set(false);
        this.updateTabIndex();
    }
    collapse() {
        this.collapsed.set(true);
        this.updateTabIndex();
    }
    getBlockableElement() {
        return this.el.nativeElement;
    }
    updateTabIndex() {
        if (this.contentWrapperViewChild) {
            const focusableElements = this.contentWrapperViewChild.nativeElement.querySelectorAll('input, button, select, a, textarea, [tabindex]');
            focusableElements.forEach((element) => {
                if (this.collapsed()) {
                    element.setAttribute('tabindex', '-1');
                }
                else {
                    element.removeAttribute('tabindex');
                }
            });
        }
    }
    onKeyDown(event) {
        if (event.code === 'Enter' || event.code === 'Space') {
            this.toggle(event);
            event.preventDefault();
        }
    }
    onToggleDone(event) {
        this.onAfterToggle.emit({ originalEvent: event, collapsed: this.collapsed() });
    }
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    onAfterContentInit() {
        this.templates().forEach((item) => {
            switch (item.getType()) {
                case 'header':
                    this._headerTemplate = item.template;
                    break;
                case 'content':
                    this._contentTemplate = item.template;
                    break;
                case 'footer':
                    this._footerTemplate = item.template;
                    break;
                case 'icons':
                    this._iconsTemplate = item.template;
                    break;
                case 'headericons':
                    this._headerIconsTemplate = item.template;
                    break;
                default:
                    this._contentTemplate = item.template;
                    break;
            }
        });
    }
    get dataP() {
        return this.cn({
            toggleable: this.toggleable()
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Panel, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: Panel, isStandalone: true, selector: "p-panel", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, toggleable: { classPropertyName: "toggleable", publicName: "toggleable", isSignal: true, isRequired: false, transformFunction: null }, _header: { classPropertyName: "_header", publicName: "header", isSignal: true, isRequired: false, transformFunction: null }, collapsed: { classPropertyName: "collapsed", publicName: "collapsed", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, iconPos: { classPropertyName: "iconPos", publicName: "iconPos", isSignal: true, isRequired: false, transformFunction: null }, showHeader: { classPropertyName: "showHeader", publicName: "showHeader", isSignal: true, isRequired: false, transformFunction: null }, toggler: { classPropertyName: "toggler", publicName: "toggler", isSignal: true, isRequired: false, transformFunction: null }, transitionOptions: { classPropertyName: "transitionOptions", publicName: "transitionOptions", isSignal: true, isRequired: false, transformFunction: null }, toggleButtonProps: { classPropertyName: "toggleButtonProps", publicName: "toggleButtonProps", isSignal: true, isRequired: false, transformFunction: null }, motionOptions: { classPropertyName: "motionOptions", publicName: "motionOptions", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { collapsed: "collapsedChange", onBeforeToggle: "onBeforeToggle", onAfterToggle: "onAfterToggle" }, host: { properties: { "id": "id()", "class": "cn(cx('root'), styleClass())", "attr.data-p": "dataP" } }, providers: [PanelStyle, { provide: PANEL_INSTANCE, useExisting: Panel }, { provide: PARENT_INSTANCE, useExisting: Panel }], queries: [{ propertyName: "footerFacet", first: true, predicate: Footer, descendants: true, isSignal: true }, { propertyName: "headerTemplate", first: true, predicate: ["header"], isSignal: true }, { propertyName: "iconsTemplate", first: true, predicate: ["icons"], isSignal: true }, { propertyName: "contentTemplate", first: true, predicate: ["content"], isSignal: true }, { propertyName: "headerIconsTemplate", first: true, predicate: ["headericons"], isSignal: true }, { propertyName: "templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "footerTemplate", first: true, predicate: ["footer"] }], viewQueries: [{ propertyName: "contentWrapperViewChild", first: true, predicate: ["contentWrapper"], descendants: true }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        @if (showHeader()) {
            <div [pBind]="ptm('header')" [class]="cx('header')" (click)="onHeaderClick($event)" [attr.id]="id() + '-titlebar'" [attr.data-p]="dataP">
                @if (_header()) {
                    <span [pBind]="ptm('title')" [class]="cx('title')" [attr.id]="id() + '_header'">{{ _header() }}</span>
                }
                <ng-content select="p-header"></ng-content>
                <ng-container *ngTemplateOutlet="headerTemplate() || _headerTemplate"></ng-container>
                <div [pBind]="ptm('headerActions')" [class]="cx('headerActions')">
                    <ng-template *ngTemplateOutlet="iconsTemplate() || _iconsTemplate"></ng-template>
                    @if (toggleable()) {
                        <p-button
                            [attr.id]="id() + '_header'"
                            severity="secondary"
                            [text]="true"
                            [rounded]="true"
                            type="button"
                            role="button"
                            [styleClass]="cx('pcToggleButton')"
                            [attr.aria-label]="buttonAriaLabel"
                            [attr.aria-controls]="id() + '_content'"
                            [attr.aria-expanded]="!collapsed()"
                            (click)="onIconClick($event)"
                            (keydown)="onKeyDown($event)"
                            [buttonProps]="toggleButtonProps()"
                            [pt]="ptm('pcToggleButton')"
                            [unstyled]="unstyled()"
                        >
                            <ng-template #icon>
                                @if (!headerIconsTemplate() && !_headerIconsTemplate && !toggleButtonProps()?.icon) {
                                    @if (!collapsed()) {
                                        <svg data-p-icon="minus" [pBind]="ptm('pcToggleButton.icon')" />
                                    }
                                    @if (collapsed()) {
                                        <svg data-p-icon="plus" [pBind]="ptm('pcToggleButton.icon')" />
                                    }
                                }
                                <ng-template *ngTemplateOutlet="headerIconsTemplate() || _headerIconsTemplate; context: { $implicit: collapsed() }"></ng-template>
                            </ng-template>
                        </p-button>
                    }
                </div>
            </div>
        }
        <div
            [pBind]="ptm('contentContainer')"
            [pMotion]="!toggleable() || (toggleable() && !collapsed())"
            pMotionName="p-collapsible"
            [pMotionOptions]="computedMotionOptions()"
            [class]="cx('contentContainer')"
            [id]="id() + '_content'"
            role="region"
            [attr.aria-labelledby]="id() + '_header'"
            [attr.aria-hidden]="collapsed()"
            [attr.tabindex]="collapsed() ? '-1' : undefined"
            (pMotionOnAfterEnter)="onToggleDone($event)"
        >
            <div [pBind]="ptm('contentWrapper')" [class]="cx('contentWrapper')">
                <div [pBind]="ptm('content')" [class]="cx('content')" #contentWrapper>
                    <ng-content></ng-content>
                    <ng-container *ngTemplateOutlet="contentTemplate() || _contentTemplate"></ng-container>
                </div>

                @if (footerFacet() || footerTemplate || _footerTemplate) {
                    <div [pBind]="ptm('footer')" [class]="cx('footer')">
                        <ng-content select="p-footer"></ng-content>
                        <ng-container *ngTemplateOutlet="footerTemplate || _footerTemplate"></ng-container>
                    </div>
                }
            </div>
        </div>
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: PlusIcon, selector: "[data-p-icon=\"plus\"]" }, { kind: "component", type: MinusIcon, selector: "[data-p-icon=\"minus\"]" }, { kind: "ngmodule", type: ButtonModule }, { kind: "component", type: i3.Button, selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: BindModule }, { kind: "directive", type: i1.Bind, selector: "[pBind]", inputs: ["pBind"] }, { kind: "ngmodule", type: MotionModule }, { kind: "directive", type: i4.MotionDirective, selector: "[pMotion]", inputs: ["pMotion", "pMotionName", "pMotionType", "pMotionSafe", "pMotionDisabled", "pMotionAppear", "pMotionEnter", "pMotionLeave", "pMotionDuration", "pMotionHideStrategy", "pMotionEnterFromClass", "pMotionEnterToClass", "pMotionEnterActiveClass", "pMotionLeaveFromClass", "pMotionLeaveToClass", "pMotionLeaveActiveClass", "pMotionOptions"], outputs: ["pMotionOnBeforeEnter", "pMotionOnEnter", "pMotionOnAfterEnter", "pMotionOnEnterCancelled", "pMotionOnBeforeLeave", "pMotionOnLeave", "pMotionOnAfterLeave", "pMotionOnLeaveCancelled"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Panel, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-panel',
                    standalone: true,
                    imports: [CommonModule, PlusIcon, MinusIcon, ButtonModule, SharedModule, BindModule, MotionModule],
                    template: `
        @if (showHeader()) {
            <div [pBind]="ptm('header')" [class]="cx('header')" (click)="onHeaderClick($event)" [attr.id]="id() + '-titlebar'" [attr.data-p]="dataP">
                @if (_header()) {
                    <span [pBind]="ptm('title')" [class]="cx('title')" [attr.id]="id() + '_header'">{{ _header() }}</span>
                }
                <ng-content select="p-header"></ng-content>
                <ng-container *ngTemplateOutlet="headerTemplate() || _headerTemplate"></ng-container>
                <div [pBind]="ptm('headerActions')" [class]="cx('headerActions')">
                    <ng-template *ngTemplateOutlet="iconsTemplate() || _iconsTemplate"></ng-template>
                    @if (toggleable()) {
                        <p-button
                            [attr.id]="id() + '_header'"
                            severity="secondary"
                            [text]="true"
                            [rounded]="true"
                            type="button"
                            role="button"
                            [styleClass]="cx('pcToggleButton')"
                            [attr.aria-label]="buttonAriaLabel"
                            [attr.aria-controls]="id() + '_content'"
                            [attr.aria-expanded]="!collapsed()"
                            (click)="onIconClick($event)"
                            (keydown)="onKeyDown($event)"
                            [buttonProps]="toggleButtonProps()"
                            [pt]="ptm('pcToggleButton')"
                            [unstyled]="unstyled()"
                        >
                            <ng-template #icon>
                                @if (!headerIconsTemplate() && !_headerIconsTemplate && !toggleButtonProps()?.icon) {
                                    @if (!collapsed()) {
                                        <svg data-p-icon="minus" [pBind]="ptm('pcToggleButton.icon')" />
                                    }
                                    @if (collapsed()) {
                                        <svg data-p-icon="plus" [pBind]="ptm('pcToggleButton.icon')" />
                                    }
                                }
                                <ng-template *ngTemplateOutlet="headerIconsTemplate() || _headerIconsTemplate; context: { $implicit: collapsed() }"></ng-template>
                            </ng-template>
                        </p-button>
                    }
                </div>
            </div>
        }
        <div
            [pBind]="ptm('contentContainer')"
            [pMotion]="!toggleable() || (toggleable() && !collapsed())"
            pMotionName="p-collapsible"
            [pMotionOptions]="computedMotionOptions()"
            [class]="cx('contentContainer')"
            [id]="id() + '_content'"
            role="region"
            [attr.aria-labelledby]="id() + '_header'"
            [attr.aria-hidden]="collapsed()"
            [attr.tabindex]="collapsed() ? '-1' : undefined"
            (pMotionOnAfterEnter)="onToggleDone($event)"
        >
            <div [pBind]="ptm('contentWrapper')" [class]="cx('contentWrapper')">
                <div [pBind]="ptm('content')" [class]="cx('content')" #contentWrapper>
                    <ng-content></ng-content>
                    <ng-container *ngTemplateOutlet="contentTemplate() || _contentTemplate"></ng-container>
                </div>

                @if (footerFacet() || footerTemplate || _footerTemplate) {
                    <div [pBind]="ptm('footer')" [class]="cx('footer')">
                        <ng-content select="p-footer"></ng-content>
                        <ng-container *ngTemplateOutlet="footerTemplate || _footerTemplate"></ng-container>
                    </div>
                }
            </div>
        </div>
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [PanelStyle, { provide: PANEL_INSTANCE, useExisting: Panel }, { provide: PARENT_INSTANCE, useExisting: Panel }],
                    host: {
                        '[id]': 'id()',
                        '[class]': "cn(cx('root'), styleClass())",
                        '[attr.data-p]': 'dataP'
                    },
                    hostDirectives: [Bind]
                }]
        }], propDecorators: { id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], toggleable: [{ type: i0.Input, args: [{ isSignal: true, alias: "toggleable", required: false }] }], _header: [{ type: i0.Input, args: [{ isSignal: true, alias: "header", required: false }] }], collapsed: [{ type: i0.Input, args: [{ isSignal: true, alias: "collapsed", required: false }] }, { type: i0.Output, args: ["collapsedChange"] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], iconPos: [{ type: i0.Input, args: [{ isSignal: true, alias: "iconPos", required: false }] }], showHeader: [{ type: i0.Input, args: [{ isSignal: true, alias: "showHeader", required: false }] }], toggler: [{ type: i0.Input, args: [{ isSignal: true, alias: "toggler", required: false }] }], transitionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "transitionOptions", required: false }] }], toggleButtonProps: [{ type: i0.Input, args: [{ isSignal: true, alias: "toggleButtonProps", required: false }] }], motionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "motionOptions", required: false }] }], onBeforeToggle: [{ type: i0.Output, args: ["onBeforeToggle"] }], onAfterToggle: [{ type: i0.Output, args: ["onAfterToggle"] }], footerFacet: [{ type: i0.ContentChild, args: [i0.forwardRef(() => Footer), { isSignal: true }] }], headerTemplate: [{ type: i0.ContentChild, args: ['header', { ...{ descendants: false }, isSignal: true }] }], iconsTemplate: [{ type: i0.ContentChild, args: ['icons', { ...{ descendants: false }, isSignal: true }] }], contentTemplate: [{ type: i0.ContentChild, args: ['content', { ...{ descendants: false }, isSignal: true }] }], footerTemplate: [{
                type: ContentChild,
                args: ['footer', { descendants: false }]
            }], headerIconsTemplate: [{ type: i0.ContentChild, args: ['headericons', { ...{ descendants: false }, isSignal: true }] }], contentWrapperViewChild: [{
                type: ViewChild,
                args: ['contentWrapper']
            }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class PanelModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PanelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: PanelModule, imports: [Panel, SharedModule, BindModule], exports: [Panel, SharedModule, BindModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PanelModule, imports: [Panel, SharedModule, BindModule, SharedModule, BindModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: PanelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [Panel, SharedModule, BindModule],
                    exports: [Panel, SharedModule, BindModule]
                }]
        }] });

// Backwards compatibility

/**
 * Generated bundle index. Do not edit.
 */

export { Panel, PanelClasses, PanelModule, PanelStyle };
//# sourceMappingURL=wawjs-ngx-prime-panel.mjs.map
