export * from '@wawjs/ngx-prime/types/contextmenu';
import * as i1 from '@angular/common';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, ElementRef, Renderer2, input, booleanAttribute, numberAttribute, output, viewChild, signal, effect, ViewEncapsulation, Component, computed, contentChild, contentChildren, ViewChild, ChangeDetectionStrategy, NgModule } from '@angular/core';
import * as i2 from '@angular/router';
import { RouterModule } from '@angular/router';
import { resolve, isNotEmpty, getOffset, getViewport, getHiddenElementOuterWidth, getOuterWidth, calculateScrollbarWidth, uuid, isIOS, isAndroid, focus, isPrintableCharacter, isEmpty, findSingle, appendChild, getHiddenElementOuterHeight, findLastIndex } from '@wawjs/css-prime-utils';
import { SharedModule, OverlayService, PrimeTemplate } from '@wawjs/ngx-prime/api';
import * as i5 from '@wawjs/ngx-prime/badge';
import { BadgeModule } from '@wawjs/ngx-prime/badge';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i4 from '@wawjs/ngx-prime/bind';
import { BindModule } from '@wawjs/ngx-prime/bind';
import { AngleRightIcon } from '@wawjs/ngx-prime/icons';
import * as i6 from '@wawjs/ngx-prime/motion';
import { MotionModule } from '@wawjs/ngx-prime/motion';
import { Ripple } from '@wawjs/ngx-prime/ripple';
import * as i3 from '@wawjs/ngx-prime/tooltip';
import { TooltipModule } from '@wawjs/ngx-prime/tooltip';
import { ZIndexUtils } from '@wawjs/ngx-prime/utils';
import { style } from '@wawjs/css-prime-styles/contextmenu';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const inlineStyles = {
    root: { position: 'absolute' }
};
const classes = {
    root: () => ['p-contextmenu p-component'],
    rootList: 'p-contextmenu-root-list',
    item: ({ instance, processedItem }) => [
        'p-contextmenu-item',
        {
            'p-contextmenu-item-active': instance.isItemActive(processedItem),
            'p-focus': instance.isItemFocused(processedItem),
            'p-disabled': instance.isItemDisabled(processedItem),
            'p-contextmenu-mobile': instance.queryMatches
        }
    ],
    itemContent: 'p-contextmenu-item-content',
    itemLink: 'p-contextmenu-item-link',
    itemIcon: 'p-contextmenu-item-icon',
    itemLabel: 'p-contextmenu-item-label',
    submenuIcon: 'p-contextmenu-submenu-icon',
    submenu: 'p-contextmenu-submenu',
    separator: 'p-contextmenu-separator'
};
class ContextMenuStyle extends BaseStyle {
    name = 'contextmenu';
    style = style;
    classes = classes;
    inlineStyles = inlineStyles;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ContextMenuStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ContextMenuStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ContextMenuStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * ContextMenu displays an overlay menu on right click of its target. Note that components like DataTable has special integration with ContextMenu.
 * Refer to documentation of the individual documentation of the with context menu support.
 *
 * [Live Demo](https://www.ngx-prime.org/contextmenu/)
 *
 * @module contextmenustyle
 *
 */
var ContextMenuClasses;
(function (ContextMenuClasses) {
    /**
     * Class name of the root element
     */
    ContextMenuClasses["root"] = "p-contextmenu";
    /**
     * Class name of the root list element
     */
    ContextMenuClasses["rootList"] = "p-contextmenu-root-list";
    /**
     * Class name of the item element
     */
    ContextMenuClasses["item"] = "p-contextmenu-item";
    /**
     * Class name of the item content element
     */
    ContextMenuClasses["itemContent"] = "p-contextmenu-item-content";
    /**
     * Class name of the item link element
     */
    ContextMenuClasses["itemLink"] = "p-contextmenu-item-link";
    /**
     * Class name of the item icon element
     */
    ContextMenuClasses["itemIcon"] = "p-contextmenu-item-icon";
    /**
     * Class name of the item label element
     */
    ContextMenuClasses["itemLabel"] = "p-contextmenu-item-label";
    /**
     * Class name of the submenu icon element
     */
    ContextMenuClasses["submenuIcon"] = "p-contextmenu-submenu-icon";
    /**
     * Class name of the submenu element
     */
    ContextMenuClasses["submenu"] = "p-contextmenu-submenu";
    /**
     * Class name of the separator element
     */
    ContextMenuClasses["separator"] = "p-contextmenu-separator";
})(ContextMenuClasses || (ContextMenuClasses = {}));

const CONTEXTMENU_INSTANCE = new InjectionToken('CONTEXTMENU_INSTANCE');
const CONTEXTMENUSUB_INSTANCE = new InjectionToken('CONTEXTMENUSUB_INSTANCE');
class ContextMenuSub extends BaseComponent {
    el = inject(ElementRef);
    renderer = inject(Renderer2);
    contextMenu = inject(ContextMenu);
    visible = input(false, { ...(ngDevMode ? { debugName: "visible" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    items = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "items" }] : /* istanbul ignore next */ []));
    itemTemplate = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "itemTemplate" }] : /* istanbul ignore next */ []));
    root = input(false, { ...(ngDevMode ? { debugName: "root" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    autoZIndex = input(true, { ...(ngDevMode ? { debugName: "autoZIndex" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    baseZIndex = input(0, { ...(ngDevMode ? { debugName: "baseZIndex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    popup = input(undefined, { ...(ngDevMode ? { debugName: "popup" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    menuId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "menuId" }] : /* istanbul ignore next */ []));
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    level = input(0, { ...(ngDevMode ? { debugName: "level" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    focusedItemId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "focusedItemId" }] : /* istanbul ignore next */ []));
    activeItemPath = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "activeItemPath" }] : /* istanbul ignore next */ []));
    motionOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "motionOptions" }] : /* istanbul ignore next */ []));
    tabindex = input(0, { ...(ngDevMode ? { debugName: "tabindex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    itemClick = output();
    itemMouseEnter = output();
    menuFocus = output();
    menuBlur = output();
    menuKeydown = output();
    sublistViewChild = viewChild.required('sublist', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sublistViewChild" }] : /* istanbul ignore next */ []));
    render = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "render" }] : /* istanbul ignore next */ []));
    hostName = 'ContextMenu';
    _componentStyle = inject(ContextMenuStyle);
    $pcContextMenu = inject(CONTEXTMENU_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    $pcContextMenuSub = inject(CONTEXTMENUSUB_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    constructor() {
        super();
        this.contextMenu.handleSubmenuAfterLeave = () => {
            if (this.root()) {
                this.onAfterLeave();
            }
        };
        effect(() => {
            if (this.visible() || this.root()) {
                this.render.set(true);
            }
        });
    }
    getItemProp(processedItem, name, params = null) {
        return processedItem && processedItem.item ? resolve(processedItem.item[name], params) : undefined;
    }
    getItemId(processedItem) {
        return processedItem.item && processedItem.item?.id ? processedItem.item.id : `${this.menuId()}_${processedItem.key}`;
    }
    getItemKey(processedItem) {
        return this.getItemId(processedItem);
    }
    getItemLabel(processedItem) {
        return this.getItemProp(processedItem, 'label');
    }
    getAriaSetSize() {
        return this.items()?.filter((processedItem) => this.isItemVisible(processedItem) && !this.getItemProp(processedItem, 'separator')).length;
    }
    getAriaPosInset(index) {
        return (index -
            (this.items()
                ?.slice(0, index)
                .filter((processedItem) => this.isItemVisible(processedItem) && this.getItemProp(processedItem, 'separator')).length || 0) +
            1);
    }
    isItemVisible(processedItem) {
        return this.getItemProp(processedItem, 'visible') !== false;
    }
    isItemActive(processedItem) {
        const activeItemPath = this.activeItemPath();
        if (activeItemPath) {
            return activeItemPath.some((path) => path.key === processedItem.key);
        }
    }
    isItemDisabled(processedItem) {
        return this.getItemProp(processedItem, 'disabled');
    }
    isItemFocused(processedItem) {
        return this.focusedItemId() === this.getItemId(processedItem);
    }
    isItemGroup(processedItem) {
        return isNotEmpty(processedItem.items);
    }
    onItemMouseEnter(param) {
        const { event, processedItem } = param;
        this.itemMouseEnter.emit({ originalEvent: event, processedItem });
    }
    onItemClick(event, processedItem) {
        this.getItemProp(processedItem, 'command', { originalEvent: event, item: processedItem.item });
        this.itemClick.emit({ originalEvent: event, processedItem, isFocus: true });
    }
    onBeforeEnter(event) {
        this.position(event.element);
    }
    onAfterLeave() {
        this.render.set(false);
    }
    // TODO: will be removed later. Helper method to get PT from parent ContextMenu if available, otherwise use own PT
    _ptm(section, options) {
        return this.$pcContextMenu ? this.$pcContextMenu.ptm(section, options) : this.ptm(section, options);
    }
    getPTOptions(processedItem, index, key) {
        return this._ptm(key, {
            context: {
                item: processedItem.item,
                index: index,
                active: this.isItemActive(processedItem),
                focused: this.isItemFocused(processedItem),
                disabled: this.isItemDisabled(processedItem)
            }
        });
    }
    position(sublist) {
        const parentItem = sublist.parentElement.parentElement;
        const containerOffset = getOffset(sublist.parentElement.parentElement);
        const viewport = getViewport();
        const sublistWidth = sublist.offsetParent ? sublist.offsetWidth : getHiddenElementOuterWidth(sublist);
        const itemOuterWidth = getOuterWidth(parentItem.children[0]);
        sublist.style.top = '0px';
        if (parseInt(containerOffset.left, 10) + itemOuterWidth + sublistWidth > viewport.width - calculateScrollbarWidth()) {
            sublist.style.left = -1 * sublistWidth + 'px';
        }
        else {
            sublist.style.left = itemOuterWidth + 'px';
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ContextMenuSub, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: ContextMenuSub, isStandalone: true, selector: "p-contextMenuSub, p-contextmenu-sub", inputs: { visible: { classPropertyName: "visible", publicName: "visible", isSignal: true, isRequired: false, transformFunction: null }, items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, itemTemplate: { classPropertyName: "itemTemplate", publicName: "itemTemplate", isSignal: true, isRequired: false, transformFunction: null }, root: { classPropertyName: "root", publicName: "root", isSignal: true, isRequired: false, transformFunction: null }, autoZIndex: { classPropertyName: "autoZIndex", publicName: "autoZIndex", isSignal: true, isRequired: false, transformFunction: null }, baseZIndex: { classPropertyName: "baseZIndex", publicName: "baseZIndex", isSignal: true, isRequired: false, transformFunction: null }, popup: { classPropertyName: "popup", publicName: "popup", isSignal: true, isRequired: false, transformFunction: null }, menuId: { classPropertyName: "menuId", publicName: "menuId", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, level: { classPropertyName: "level", publicName: "level", isSignal: true, isRequired: false, transformFunction: null }, focusedItemId: { classPropertyName: "focusedItemId", publicName: "focusedItemId", isSignal: true, isRequired: false, transformFunction: null }, activeItemPath: { classPropertyName: "activeItemPath", publicName: "activeItemPath", isSignal: true, isRequired: false, transformFunction: null }, motionOptions: { classPropertyName: "motionOptions", publicName: "motionOptions", isSignal: true, isRequired: false, transformFunction: null }, tabindex: { classPropertyName: "tabindex", publicName: "tabindex", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { itemClick: "itemClick", itemMouseEnter: "itemMouseEnter", menuFocus: "menuFocus", menuBlur: "menuBlur", menuKeydown: "menuKeydown" }, providers: [ContextMenuStyle, { provide: CONTEXTMENUSUB_INSTANCE, useExisting: ContextMenuSub }, { provide: PARENT_INSTANCE, useExisting: ContextMenuSub }], viewQueries: [{ propertyName: "sublistViewChild", first: true, predicate: ["sublist"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: `
        @if (render()) {
            <ul
                #sublist
                role="menu"
                [class]="root() ? cx('rootList') : cx('submenu')"
                [pBind]="_ptm(root() ? 'rootList' : 'submenu')"
                [attr.id]="menuId() + '_list'"
                [tabindex]="tabindex()"
                [attr.aria-label]="ariaLabel()"
                [attr.aria-labelledBy]="ariaLabelledBy()"
                [attr.aria-activedescendant]="focusedItemId()"
                [attr.aria-orientation]="'vertical'"
                (keydown)="menuKeydown.emit($event)"
                (focus)="menuFocus.emit($event)"
                (blur)="menuBlur.emit($event)"
                [pMotion]="root() ? true : visible()"
                [pMotionAppear]="true"
                [pMotionName]="'p-anchored-overlay'"
                [pMotionOptions]="motionOptions()"
                (pMotionOnBeforeEnter)="onBeforeEnter($event)"
                (pMotionOnAfterLeave)="onAfterLeave()"
            >
                @for (processedItem of items(); track processedItem; let index = $index) {
                    @if (isItemVisible(processedItem) && getItemProp(processedItem, 'separator')) {
                        <li [attr.id]="getItemId(processedItem)" [style]="getItemProp(processedItem, 'style')" [class]="cn(cx('separator'), getItemProp(processedItem, 'styleClass'))" role="separator" [pBind]="_ptm('separator')"></li>
                    }
                    @if (isItemVisible(processedItem) && !getItemProp(processedItem, 'separator')) {
                        <li
                            #listItem
                            role="menuitem"
                            [attr.id]="getItemId(processedItem)"
                            [attr.data-p-highlight]="isItemActive(processedItem)"
                            [attr.data-p-focused]="isItemFocused(processedItem)"
                            [attr.data-p-disabled]="isItemDisabled(processedItem)"
                            [attr.aria-label]="getItemLabel(processedItem)"
                            [attr.aria-disabled]="isItemDisabled(processedItem) || undefined"
                            [attr.aria-haspopup]="isItemGroup(processedItem) && !getItemProp(processedItem, 'to') ? 'menu' : undefined"
                            [attr.aria-expanded]="isItemGroup(processedItem) ? isItemActive(processedItem) : undefined"
                            [attr.aria-level]="level() + 1"
                            [attr.aria-setsize]="getAriaSetSize()"
                            [attr.aria-posinset]="getAriaPosInset(index)"
                            [style]="getItemProp(processedItem, 'style')"
                            [class]="cn(cx('item', { instance: this, processedItem }), getItemProp(processedItem, 'styleClass'))"
                            [pBind]="getPTOptions(processedItem, index, 'item')"
                            pTooltip
                            [tooltipOptions]="getItemProp(processedItem, 'tooltipOptions')"
                            [pTooltipUnstyled]="unstyled()"
                        >
                            <div [class]="cx('itemContent')" [pBind]="getPTOptions(processedItem, index, 'itemContent')" (click)="onItemClick($event, processedItem)" (mouseenter)="onItemMouseEnter({ $event, processedItem })">
                                @if (!itemTemplate()) {
                                    @if (!getItemProp(processedItem, 'routerLink')) {
                                        <a
                                            [attr.href]="getItemProp(processedItem, 'url')"
                                            [attr.data-automationid]="getItemProp(processedItem, 'automationId')"
                                            [attr.title]="getItemProp(processedItem, 'title')"
                                            [target]="getItemProp(processedItem, 'target')"
                                            [class]="cn(cx('itemLink'), getItemProp(processedItem, 'linkClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'linkStyle')"
                                            [attr.tabindex]="-1"
                                            [pBind]="getPTOptions(processedItem, index, 'itemLink')"
                                            pRipple
                                        >
                                            @if (getItemProp(processedItem, 'icon')) {
                                                <span
                                                    [class]="cn(cx('itemIcon'), getItemProp(processedItem, 'icon'), getItemProp(processedItem, 'iconClass'))"
                                                    [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                                    [pBind]="getPTOptions(processedItem, index, 'itemIcon')"
                                                    [attr.aria-hidden]="true"
                                                    [attr.tabindex]="-1"
                                                >
                                                </span>
                                            }
                                            @if (getItemProp(processedItem, 'escape')) {
                                                <span [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))" [ngStyle]="getItemProp(processedItem, 'labelStyle')" [pBind]="getPTOptions(processedItem, index, 'itemLabel')">
                                                    {{ getItemLabel(processedItem) }}
                                                </span>
                                            } @else {
                                                <span
                                                    [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))"
                                                    [ngStyle]="getItemProp(processedItem, 'labelStyle')"
                                                    [innerHTML]="getItemLabel(processedItem)"
                                                    [pBind]="getPTOptions(processedItem, index, 'itemLabel')"
                                                ></span>
                                            }
                                            @if (getItemProp(processedItem, 'badge')) {
                                                <p-badge [class]="getItemProp(processedItem, 'badgeStyleClass')" [value]="getItemProp(processedItem, 'badge')" [unstyled]="unstyled()" />
                                            }
                                            @if (isItemGroup(processedItem)) {
                                                <ng-container>
                                                    @if (!contextMenu.submenuIconTemplate() && !contextMenu._submenuIconTemplate) {
                                                        <svg data-p-icon="angle-right" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" [attr.aria-hidden]="true" />
                                                    }
                                                    <ng-template *ngTemplateOutlet="contextMenu.submenuIconTemplate() || contextMenu._submenuIconTemplate; context: { class: 'p-contextmenu-submenu-icon' }" [attr.aria-hidden]="true"></ng-template>
                                                </ng-container>
                                            }
                                        </a>
                                    }
                                    @if (getItemProp(processedItem, 'routerLink')) {
                                        <a
                                            [routerLink]="getItemProp(processedItem, 'routerLink')"
                                            [attr.data-automationid]="getItemProp(processedItem, 'automationId')"
                                            [attr.title]="getItemProp(processedItem, 'title')"
                                            [attr.tabindex]="-1"
                                            [queryParams]="getItemProp(processedItem, 'queryParams')"
                                            [routerLinkActiveOptions]="getItemProp(processedItem, 'routerLinkActiveOptions') || { exact: false }"
                                            [target]="getItemProp(processedItem, 'target')"
                                            [class]="cn(cx('itemLink'), getItemProp(processedItem, 'linkClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'linkStyle')"
                                            [fragment]="getItemProp(processedItem, 'fragment')"
                                            [queryParamsHandling]="getItemProp(processedItem, 'queryParamsHandling')"
                                            [preserveFragment]="getItemProp(processedItem, 'preserveFragment')"
                                            [skipLocationChange]="getItemProp(processedItem, 'skipLocationChange')"
                                            [replaceUrl]="getItemProp(processedItem, 'replaceUrl')"
                                            [state]="getItemProp(processedItem, 'state')"
                                            [pBind]="getPTOptions(processedItem, index, 'itemLink')"
                                            pRipple
                                        >
                                            @if (getItemProp(processedItem, 'icon')) {
                                                <span
                                                    [class]="cn(cx('itemIcon'), getItemProp(processedItem, 'icon'), getItemProp(processedItem, 'iconClass'))"
                                                    [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                                    [pBind]="getPTOptions(processedItem, index, 'itemIcon')"
                                                    [attr.aria-hidden]="true"
                                                    [attr.tabindex]="-1"
                                                >
                                                </span>
                                            }
                                            @if (getItemProp(processedItem, 'escape')) {
                                                <span [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))" [ngStyle]="getItemProp(processedItem, 'labelStyle')" [pBind]="getPTOptions(processedItem, index, 'itemLabel')">
                                                    {{ getItemLabel(processedItem) }}
                                                </span>
                                            } @else {
                                                <span
                                                    [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))"
                                                    [ngStyle]="getItemProp(processedItem, 'labelStyle')"
                                                    [innerHTML]="getItemLabel(processedItem)"
                                                    [pBind]="getPTOptions(processedItem, index, 'itemLabel')"
                                                ></span>
                                            }
                                            @if (getItemProp(processedItem, 'badge')) {
                                                <p-badge [class]="getItemProp(processedItem, 'badgeStyleClass')" [value]="getItemProp(processedItem, 'badge')" [unstyled]="unstyled()" />
                                            }
                                            @if (isItemGroup(processedItem)) {
                                                <ng-container>
                                                    @if (!contextMenu.submenuIconTemplate() && !contextMenu._submenuIconTemplate) {
                                                        <svg data-p-icon="angle-right" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" [attr.aria-hidden]="true" />
                                                    }
                                                    <ng-template *ngTemplateOutlet="contextMenu.submenuIconTemplate() || contextMenu._submenuIconTemplate; context: { class: 'p-contextmenu-submenu-icon' }" [attr.aria-hidden]="true"></ng-template>
                                                </ng-container>
                                            }
                                        </a>
                                    }
                                }
                                @if (itemTemplate()) {
                                    <ng-container>
                                        <ng-template *ngTemplateOutlet="itemTemplate(); context: { $implicit: processedItem.item }"></ng-template>
                                    </ng-container>
                                }
                            </div>

                            @if (isItemVisible(processedItem) && isItemGroup(processedItem)) {
                                <p-contextmenu-sub
                                    [items]="processedItem.items"
                                    [itemTemplate]="itemTemplate()"
                                    [menuId]="menuId()"
                                    [visible]="isItemActive(processedItem) && isItemGroup(processedItem)"
                                    [activeItemPath]="activeItemPath()"
                                    [focusedItemId]="focusedItemId()"
                                    [level]="level() + 1"
                                    (itemClick)="itemClick.emit($event)"
                                    (itemMouseEnter)="onItemMouseEnter($event)"
                                    [pt]="pt()"
                                    [motionOptions]="motionOptions()"
                                    [unstyled]="unstyled()"
                                />
                            }
                        </li>
                    }
                }
            </ul>
        }
    `, isInline: true, dependencies: [{ kind: "component", type: ContextMenuSub, selector: "p-contextMenuSub, p-contextmenu-sub", inputs: ["visible", "items", "itemTemplate", "root", "autoZIndex", "baseZIndex", "popup", "menuId", "ariaLabel", "ariaLabelledBy", "level", "focusedItemId", "activeItemPath", "motionOptions", "tabindex"], outputs: ["itemClick", "itemMouseEnter", "menuFocus", "menuBlur", "menuKeydown"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i2.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "browserUrl", "routerLink"] }, { kind: "directive", type: Ripple, selector: "[pRipple]" }, { kind: "ngmodule", type: TooltipModule }, { kind: "directive", type: i3.Tooltip, selector: "[pTooltip]", inputs: ["tooltipPosition", "tooltipEvent", "positionStyle", "tooltipStyleClass", "tooltipZIndex", "escape", "showDelay", "hideDelay", "life", "positionTop", "positionLeft", "autoHide", "fitContent", "hideOnEscape", "showOnEllipsis", "pTooltip", "tooltipDisabled", "tooltipOptions", "appendTo", "ptTooltip", "pTooltipPT", "pTooltipUnstyled"] }, { kind: "directive", type: i4.Bind, selector: "[pBind]", inputs: ["pBind"] }, { kind: "component", type: AngleRightIcon, selector: "[data-p-icon=\"angle-right\"]" }, { kind: "ngmodule", type: BadgeModule }, { kind: "component", type: i5.Badge, selector: "p-badge", inputs: ["styleClass", "badgeSize", "size", "severity", "value", "badgeDisabled"] }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: BindModule }, { kind: "ngmodule", type: MotionModule }, { kind: "directive", type: i6.MotionDirective, selector: "[pMotion]", inputs: ["pMotion", "pMotionName", "pMotionType", "pMotionSafe", "pMotionDisabled", "pMotionAppear", "pMotionEnter", "pMotionLeave", "pMotionDuration", "pMotionHideStrategy", "pMotionEnterFromClass", "pMotionEnterToClass", "pMotionEnterActiveClass", "pMotionLeaveFromClass", "pMotionLeaveToClass", "pMotionLeaveActiveClass", "pMotionOptions"], outputs: ["pMotionOnBeforeEnter", "pMotionOnEnter", "pMotionOnAfterEnter", "pMotionOnEnterCancelled", "pMotionOnBeforeLeave", "pMotionOnLeave", "pMotionOnAfterLeave", "pMotionOnLeaveCancelled"] }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ContextMenuSub, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-contextMenuSub, p-contextmenu-sub',
                    standalone: true,
                    imports: [CommonModule, RouterModule, Ripple, TooltipModule, AngleRightIcon, BadgeModule, SharedModule, BindModule, MotionModule],
                    template: `
        @if (render()) {
            <ul
                #sublist
                role="menu"
                [class]="root() ? cx('rootList') : cx('submenu')"
                [pBind]="_ptm(root() ? 'rootList' : 'submenu')"
                [attr.id]="menuId() + '_list'"
                [tabindex]="tabindex()"
                [attr.aria-label]="ariaLabel()"
                [attr.aria-labelledBy]="ariaLabelledBy()"
                [attr.aria-activedescendant]="focusedItemId()"
                [attr.aria-orientation]="'vertical'"
                (keydown)="menuKeydown.emit($event)"
                (focus)="menuFocus.emit($event)"
                (blur)="menuBlur.emit($event)"
                [pMotion]="root() ? true : visible()"
                [pMotionAppear]="true"
                [pMotionName]="'p-anchored-overlay'"
                [pMotionOptions]="motionOptions()"
                (pMotionOnBeforeEnter)="onBeforeEnter($event)"
                (pMotionOnAfterLeave)="onAfterLeave()"
            >
                @for (processedItem of items(); track processedItem; let index = $index) {
                    @if (isItemVisible(processedItem) && getItemProp(processedItem, 'separator')) {
                        <li [attr.id]="getItemId(processedItem)" [style]="getItemProp(processedItem, 'style')" [class]="cn(cx('separator'), getItemProp(processedItem, 'styleClass'))" role="separator" [pBind]="_ptm('separator')"></li>
                    }
                    @if (isItemVisible(processedItem) && !getItemProp(processedItem, 'separator')) {
                        <li
                            #listItem
                            role="menuitem"
                            [attr.id]="getItemId(processedItem)"
                            [attr.data-p-highlight]="isItemActive(processedItem)"
                            [attr.data-p-focused]="isItemFocused(processedItem)"
                            [attr.data-p-disabled]="isItemDisabled(processedItem)"
                            [attr.aria-label]="getItemLabel(processedItem)"
                            [attr.aria-disabled]="isItemDisabled(processedItem) || undefined"
                            [attr.aria-haspopup]="isItemGroup(processedItem) && !getItemProp(processedItem, 'to') ? 'menu' : undefined"
                            [attr.aria-expanded]="isItemGroup(processedItem) ? isItemActive(processedItem) : undefined"
                            [attr.aria-level]="level() + 1"
                            [attr.aria-setsize]="getAriaSetSize()"
                            [attr.aria-posinset]="getAriaPosInset(index)"
                            [style]="getItemProp(processedItem, 'style')"
                            [class]="cn(cx('item', { instance: this, processedItem }), getItemProp(processedItem, 'styleClass'))"
                            [pBind]="getPTOptions(processedItem, index, 'item')"
                            pTooltip
                            [tooltipOptions]="getItemProp(processedItem, 'tooltipOptions')"
                            [pTooltipUnstyled]="unstyled()"
                        >
                            <div [class]="cx('itemContent')" [pBind]="getPTOptions(processedItem, index, 'itemContent')" (click)="onItemClick($event, processedItem)" (mouseenter)="onItemMouseEnter({ $event, processedItem })">
                                @if (!itemTemplate()) {
                                    @if (!getItemProp(processedItem, 'routerLink')) {
                                        <a
                                            [attr.href]="getItemProp(processedItem, 'url')"
                                            [attr.data-automationid]="getItemProp(processedItem, 'automationId')"
                                            [attr.title]="getItemProp(processedItem, 'title')"
                                            [target]="getItemProp(processedItem, 'target')"
                                            [class]="cn(cx('itemLink'), getItemProp(processedItem, 'linkClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'linkStyle')"
                                            [attr.tabindex]="-1"
                                            [pBind]="getPTOptions(processedItem, index, 'itemLink')"
                                            pRipple
                                        >
                                            @if (getItemProp(processedItem, 'icon')) {
                                                <span
                                                    [class]="cn(cx('itemIcon'), getItemProp(processedItem, 'icon'), getItemProp(processedItem, 'iconClass'))"
                                                    [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                                    [pBind]="getPTOptions(processedItem, index, 'itemIcon')"
                                                    [attr.aria-hidden]="true"
                                                    [attr.tabindex]="-1"
                                                >
                                                </span>
                                            }
                                            @if (getItemProp(processedItem, 'escape')) {
                                                <span [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))" [ngStyle]="getItemProp(processedItem, 'labelStyle')" [pBind]="getPTOptions(processedItem, index, 'itemLabel')">
                                                    {{ getItemLabel(processedItem) }}
                                                </span>
                                            } @else {
                                                <span
                                                    [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))"
                                                    [ngStyle]="getItemProp(processedItem, 'labelStyle')"
                                                    [innerHTML]="getItemLabel(processedItem)"
                                                    [pBind]="getPTOptions(processedItem, index, 'itemLabel')"
                                                ></span>
                                            }
                                            @if (getItemProp(processedItem, 'badge')) {
                                                <p-badge [class]="getItemProp(processedItem, 'badgeStyleClass')" [value]="getItemProp(processedItem, 'badge')" [unstyled]="unstyled()" />
                                            }
                                            @if (isItemGroup(processedItem)) {
                                                <ng-container>
                                                    @if (!contextMenu.submenuIconTemplate() && !contextMenu._submenuIconTemplate) {
                                                        <svg data-p-icon="angle-right" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" [attr.aria-hidden]="true" />
                                                    }
                                                    <ng-template *ngTemplateOutlet="contextMenu.submenuIconTemplate() || contextMenu._submenuIconTemplate; context: { class: 'p-contextmenu-submenu-icon' }" [attr.aria-hidden]="true"></ng-template>
                                                </ng-container>
                                            }
                                        </a>
                                    }
                                    @if (getItemProp(processedItem, 'routerLink')) {
                                        <a
                                            [routerLink]="getItemProp(processedItem, 'routerLink')"
                                            [attr.data-automationid]="getItemProp(processedItem, 'automationId')"
                                            [attr.title]="getItemProp(processedItem, 'title')"
                                            [attr.tabindex]="-1"
                                            [queryParams]="getItemProp(processedItem, 'queryParams')"
                                            [routerLinkActiveOptions]="getItemProp(processedItem, 'routerLinkActiveOptions') || { exact: false }"
                                            [target]="getItemProp(processedItem, 'target')"
                                            [class]="cn(cx('itemLink'), getItemProp(processedItem, 'linkClass'))"
                                            [ngStyle]="getItemProp(processedItem, 'linkStyle')"
                                            [fragment]="getItemProp(processedItem, 'fragment')"
                                            [queryParamsHandling]="getItemProp(processedItem, 'queryParamsHandling')"
                                            [preserveFragment]="getItemProp(processedItem, 'preserveFragment')"
                                            [skipLocationChange]="getItemProp(processedItem, 'skipLocationChange')"
                                            [replaceUrl]="getItemProp(processedItem, 'replaceUrl')"
                                            [state]="getItemProp(processedItem, 'state')"
                                            [pBind]="getPTOptions(processedItem, index, 'itemLink')"
                                            pRipple
                                        >
                                            @if (getItemProp(processedItem, 'icon')) {
                                                <span
                                                    [class]="cn(cx('itemIcon'), getItemProp(processedItem, 'icon'), getItemProp(processedItem, 'iconClass'))"
                                                    [ngStyle]="getItemProp(processedItem, 'iconStyle')"
                                                    [pBind]="getPTOptions(processedItem, index, 'itemIcon')"
                                                    [attr.aria-hidden]="true"
                                                    [attr.tabindex]="-1"
                                                >
                                                </span>
                                            }
                                            @if (getItemProp(processedItem, 'escape')) {
                                                <span [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))" [ngStyle]="getItemProp(processedItem, 'labelStyle')" [pBind]="getPTOptions(processedItem, index, 'itemLabel')">
                                                    {{ getItemLabel(processedItem) }}
                                                </span>
                                            } @else {
                                                <span
                                                    [class]="cn(cx('itemLabel'), getItemProp(processedItem, 'labelClass'))"
                                                    [ngStyle]="getItemProp(processedItem, 'labelStyle')"
                                                    [innerHTML]="getItemLabel(processedItem)"
                                                    [pBind]="getPTOptions(processedItem, index, 'itemLabel')"
                                                ></span>
                                            }
                                            @if (getItemProp(processedItem, 'badge')) {
                                                <p-badge [class]="getItemProp(processedItem, 'badgeStyleClass')" [value]="getItemProp(processedItem, 'badge')" [unstyled]="unstyled()" />
                                            }
                                            @if (isItemGroup(processedItem)) {
                                                <ng-container>
                                                    @if (!contextMenu.submenuIconTemplate() && !contextMenu._submenuIconTemplate) {
                                                        <svg data-p-icon="angle-right" [class]="cx('submenuIcon')" [pBind]="getPTOptions(processedItem, index, 'submenuIcon')" [attr.aria-hidden]="true" />
                                                    }
                                                    <ng-template *ngTemplateOutlet="contextMenu.submenuIconTemplate() || contextMenu._submenuIconTemplate; context: { class: 'p-contextmenu-submenu-icon' }" [attr.aria-hidden]="true"></ng-template>
                                                </ng-container>
                                            }
                                        </a>
                                    }
                                }
                                @if (itemTemplate()) {
                                    <ng-container>
                                        <ng-template *ngTemplateOutlet="itemTemplate(); context: { $implicit: processedItem.item }"></ng-template>
                                    </ng-container>
                                }
                            </div>

                            @if (isItemVisible(processedItem) && isItemGroup(processedItem)) {
                                <p-contextmenu-sub
                                    [items]="processedItem.items"
                                    [itemTemplate]="itemTemplate()"
                                    [menuId]="menuId()"
                                    [visible]="isItemActive(processedItem) && isItemGroup(processedItem)"
                                    [activeItemPath]="activeItemPath()"
                                    [focusedItemId]="focusedItemId()"
                                    [level]="level() + 1"
                                    (itemClick)="itemClick.emit($event)"
                                    (itemMouseEnter)="onItemMouseEnter($event)"
                                    [pt]="pt()"
                                    [motionOptions]="motionOptions()"
                                    [unstyled]="unstyled()"
                                />
                            }
                        </li>
                    }
                }
            </ul>
        }
    `,
                    encapsulation: ViewEncapsulation.None,
                    providers: [ContextMenuStyle, { provide: CONTEXTMENUSUB_INSTANCE, useExisting: ContextMenuSub }, { provide: PARENT_INSTANCE, useExisting: ContextMenuSub }]
                }]
        }], ctorParameters: () => [], propDecorators: { visible: [{ type: i0.Input, args: [{ isSignal: true, alias: "visible", required: false }] }], items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }], itemTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "itemTemplate", required: false }] }], root: [{ type: i0.Input, args: [{ isSignal: true, alias: "root", required: false }] }], autoZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoZIndex", required: false }] }], baseZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "baseZIndex", required: false }] }], popup: [{ type: i0.Input, args: [{ isSignal: true, alias: "popup", required: false }] }], menuId: [{ type: i0.Input, args: [{ isSignal: true, alias: "menuId", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], level: [{ type: i0.Input, args: [{ isSignal: true, alias: "level", required: false }] }], focusedItemId: [{ type: i0.Input, args: [{ isSignal: true, alias: "focusedItemId", required: false }] }], activeItemPath: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeItemPath", required: false }] }], motionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "motionOptions", required: false }] }], tabindex: [{ type: i0.Input, args: [{ isSignal: true, alias: "tabindex", required: false }] }], itemClick: [{ type: i0.Output, args: ["itemClick"] }], itemMouseEnter: [{ type: i0.Output, args: ["itemMouseEnter"] }], menuFocus: [{ type: i0.Output, args: ["menuFocus"] }], menuBlur: [{ type: i0.Output, args: ["menuBlur"] }], menuKeydown: [{ type: i0.Output, args: ["menuKeydown"] }], sublistViewChild: [{ type: i0.ViewChild, args: ['sublist', { isSignal: true }] }] } });
/**
 * ContextMenu displays an overlay menu on right click of its target. Note that components like Table has special integration with ContextMenu.
 * @group Components
 */
class ContextMenu extends BaseComponent {
    overlayService = inject(OverlayService);
    componentName = 'ContextMenu';
    /**
     * An array of menuitems.
     * @group Props
     */
    model = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "model" }] : /* istanbul ignore next */ []));
    /**
     * Event for which the menu must be displayed.
     * @group Props
     */
    triggerEvent = input('contextmenu', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "triggerEvent" }] : /* istanbul ignore next */ []));
    /**
     * Local template variable name of the element to attach the context menu.
     * @group Props
     */
    target = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "target" }] : /* istanbul ignore next */ []));
    _target;
    /**
     * Attaches the menu to document instead of a particular item.
     * @group Props
     */
    global = input(undefined, { ...(ngDevMode ? { debugName: "global" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Inline style of the component.
     * @group Props
     */
    style = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "style" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the component.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Whether to automatically manage layering.
     * @group Props
     */
    autoZIndex = input(true, { ...(ngDevMode ? { debugName: "autoZIndex" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Base zIndex value to use in layering.
     * @group Props
     */
    baseZIndex = input(0, { ...(ngDevMode ? { debugName: "baseZIndex" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Current id state as a string.
     * @group Props
     */
    id = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "id" }] : /* istanbul ignore next */ []));
    /**
     * The breakpoint to define the maximum width boundary.
     * @group Props
     */
    breakpoint = input('960px', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "breakpoint" }] : /* istanbul ignore next */ []));
    /**
     * Defines a string value that labels an interactive element.
     * @group Props
     */
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /**
     * Identifier of the underlying input element.
     * @group Props
     */
    ariaLabelledBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabelledBy" }] : /* istanbul ignore next */ []));
    /**
     * Press delay in touch devices as miliseconds.
     * @group Props
     */
    pressDelay = input(500, { ...(ngDevMode ? { debugName: "pressDelay" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @defaultValue 'self'
     * @group Props
     */
    appendTo = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "appendTo" }] : /* istanbul ignore next */ []));
    /**
     * The motion options.
     * @group Props
     */
    motionOptions = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "motionOptions" }] : /* istanbul ignore next */ []));
    computedMotionOptions = computed(() => ({
        ...this.ptm('motion'),
        ...this.motionOptions()
    }), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "computedMotionOptions" }] : /* istanbul ignore next */ []));
    /**
     * Callback to invoke when overlay menu is shown.
     * @group Emits
     */
    onShow = output();
    /**
     * Callback to invoke when overlay menu is hidden.
     * @group Emits
     */
    onHide = output();
    rootmenu;
    container;
    handleSubmenuAfterLeave = null;
    outsideClickListener;
    resizeListener;
    triggerEventListener;
    documentClickListener;
    documentTriggerListener;
    touchEndListener;
    pageX;
    pageY;
    visible = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "visible" }] : /* istanbul ignore next */ []));
    render = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "render" }] : /* istanbul ignore next */ []));
    focused = false;
    activeItemPath = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "activeItemPath" }] : /* istanbul ignore next */ []));
    focusedItemInfo = signal({ index: -1, level: 0, parentKey: '', item: null }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "focusedItemInfo" }] : /* istanbul ignore next */ []));
    submenuVisible = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "submenuVisible" }] : /* istanbul ignore next */ []));
    $appendTo = computed(() => this.appendTo() || this.config.overlayAppendTo(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "$appendTo" }] : /* istanbul ignore next */ []));
    searchValue = '';
    searchTimeout;
    _processedItems;
    pressTimer;
    hideCallback;
    matchMediaListener;
    query;
    queryMatches = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "queryMatches" }] : /* istanbul ignore next */ []));
    _componentStyle = inject(ContextMenuStyle);
    _generatedId;
    get resolvedId() {
        return this.id() || (this._generatedId ??= uuid('pn_id_'));
    }
    get visibleItems() {
        const processedItem = this.activeItemPath().find((p) => p.key === this.focusedItemInfo().parentKey);
        return processedItem ? processedItem.items : this.processedItems;
    }
    get processedItems() {
        if (!this._processedItems || !this._processedItems.length) {
            this._processedItems = this.createProcessedItems(this.model() || []);
        }
        return this._processedItems;
    }
    get focusedItemId() {
        const focusedItem = this.focusedItemInfo();
        return focusedItem.item && focusedItem.item?.id ? focusedItem.item.id : focusedItem.index !== -1 ? `${this.resolvedId}${isNotEmpty(focusedItem.parentKey) ? '_' + focusedItem.parentKey : ''}_${focusedItem.index}` : null;
    }
    constructor() {
        super();
        effect(() => {
            const path = this.activeItemPath();
            if (isNotEmpty(path)) {
                this.bindGlobalListeners();
            }
            else if (!this.visible()) {
                this.unbindGlobalListeners();
            }
        });
        effect(() => {
            this._target = this.target();
        });
    }
    onInit() {
        this.bindMatchMediaListener();
        this.bindTriggerEventListener();
    }
    isMobile() {
        return isIOS() || isAndroid();
    }
    bindTriggerEventListener() {
        if (isPlatformBrowser(this.platformId)) {
            if (!this.triggerEventListener) {
                if (!this.isMobile()) {
                    if (this.global()) {
                        this.triggerEventListener = this.renderer.listen(this.document, this.triggerEvent(), (event) => {
                            this.show(event);
                        });
                    }
                    else if (this._target) {
                        this.triggerEventListener = this.renderer.listen(this._target, this.triggerEvent(), (event) => {
                            this.show(event);
                        });
                    }
                }
                else {
                    if (this.global()) {
                        this.triggerEventListener = this.renderer.listen(this.document, 'touchstart', this.onTouchStart.bind(this));
                        this.touchEndListener = this.renderer.listen(this.document, 'touchend', this.onTouchEnd.bind(this));
                    }
                    else if (this._target) {
                        this.triggerEventListener = this.renderer.listen(this._target, 'touchstart', this.onTouchStart.bind(this));
                        this.touchEndListener = this.renderer.listen(this._target, 'touchend', this.onTouchEnd.bind(this));
                    }
                }
            }
        }
    }
    bindGlobalListeners() {
        if (isPlatformBrowser(this.platformId)) {
            if (!this.documentClickListener) {
                const documentTarget = this.el ? this.el.nativeElement.ownerDocument : 'document';
                this.documentClickListener = this.renderer.listen(documentTarget, 'click', (event) => {
                    if (this.container?.offsetParent && this.isOutsideClicked(event) && !event.ctrlKey && event.button !== 2) {
                        this.hide();
                    }
                });
            }
            if (!this.resizeListener) {
                this.resizeListener = this.renderer.listen(this.document.defaultView, 'resize', () => {
                    this.hide();
                });
            }
        }
    }
    /**
     * Custom item template.
     * @group Templates
     */
    itemTemplate = contentChild('item', { ...(ngDevMode ? { debugName: "itemTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    /**
     * Custom submenu icon template.
     * @group Templates
     */
    submenuIconTemplate = contentChild('submenuicon', { ...(ngDevMode ? { debugName: "submenuIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    _submenuIconTemplate;
    _itemTemplate;
    onAfterContentInit() {
        this.templates()?.forEach((item) => {
            switch (item.getType()) {
                case 'submenuicon':
                    this._submenuIconTemplate = item.template;
                    break;
                case 'item':
                    this._itemTemplate = item.template;
                    break;
                default:
                    this._itemTemplate = item.template;
                    break;
            }
        });
    }
    getPTOptions(key, item, index) {
        return this.ptm(key, {
            context: {
                item: item,
                index: index,
                focused: this.isItemFocused({ index, item }),
                disabled: this.isItemDisabled(item)
            }
        });
    }
    isItemFocused(itemInfo) {
        return this.focusedItemInfo().index === itemInfo.index;
    }
    createProcessedItems(items, level = 0, parent = {}, parentKey = '') {
        const processedItems = [];
        items &&
            items.forEach((item, index) => {
                const key = (parentKey !== '' ? parentKey + '_' : '') + index;
                const newItem = {
                    item,
                    index,
                    level,
                    key,
                    parent,
                    parentKey
                };
                newItem['items'] = this.createProcessedItems(item.items, level + 1, newItem, key);
                processedItems.push(newItem);
            });
        return processedItems;
    }
    bindMatchMediaListener() {
        if (isPlatformBrowser(this.platformId)) {
            if (!this.matchMediaListener) {
                const query = window.matchMedia(`(max-width: ${this.breakpoint()})`);
                this.query = query;
                this.queryMatches.set(query.matches);
                this.matchMediaListener = () => {
                    this.queryMatches.set(query.matches);
                    this.cd.markForCheck();
                };
                query.addEventListener('change', this.matchMediaListener);
            }
        }
    }
    unbindMatchMediaListener() {
        if (this.matchMediaListener) {
            this.query.removeEventListener('change', this.matchMediaListener);
            this.matchMediaListener = null;
        }
    }
    getItemProp(item, name) {
        return item ? resolve(item[name]) : undefined;
    }
    getProccessedItemLabel(processedItem) {
        return processedItem ? this.getItemLabel(processedItem.item) : undefined;
    }
    getItemLabel(item) {
        return this.getItemProp(item, 'label');
    }
    isProcessedItemGroup(processedItem) {
        return processedItem && isNotEmpty(processedItem.items);
    }
    isSelected(processedItem) {
        return this.activeItemPath().some((p) => p.key === processedItem.key);
    }
    isValidSelectedItem(processedItem) {
        return this.isValidItem(processedItem) && this.isSelected(processedItem);
    }
    isValidItem(processedItem) {
        return !!processedItem && !this.isItemDisabled(processedItem.item) && !this.isItemSeparator(processedItem.item);
    }
    isItemDisabled(item) {
        return this.getItemProp(item, 'disabled');
    }
    isItemSeparator(item) {
        return this.getItemProp(item, 'separator');
    }
    isItemMatched(processedItem) {
        return this.isValidItem(processedItem) && this.getProccessedItemLabel(processedItem).toLocaleLowerCase().startsWith(this.searchValue.toLocaleLowerCase());
    }
    isProccessedItemGroup(processedItem) {
        return processedItem && isNotEmpty(processedItem.items);
    }
    onItemClick(event) {
        const { processedItem } = event;
        const grouped = this.isProcessedItemGroup(processedItem);
        const selected = this.isSelected(processedItem);
        if (selected) {
            const { index, key, level, parentKey, item } = processedItem;
            this.activeItemPath.set(this.activeItemPath().filter((p) => key !== p.key && key.startsWith(p.key)));
            this.focusedItemInfo.set({ index, level, parentKey, item });
            focus(this.rootmenu?.sublistViewChild()?.nativeElement);
        }
        else {
            grouped ? this.onItemChange(event) : this.hide();
        }
    }
    onItemMouseEnter(event) {
        this.onItemChange(event, 'hover');
    }
    onKeyDown(event) {
        const metaKey = event.metaKey || event.ctrlKey;
        switch (event.code) {
            case 'ArrowDown':
                this.onArrowDownKey(event);
                break;
            case 'ArrowUp':
                this.onArrowUpKey(event);
                break;
            case 'ArrowLeft':
                this.onArrowLeftKey(event);
                break;
            case 'ArrowRight':
                this.onArrowRightKey(event);
                break;
            case 'Home':
                this.onHomeKey(event);
                break;
            case 'End':
                this.onEndKey(event);
                break;
            case 'Space':
                this.onSpaceKey(event);
                break;
            case 'Enter':
                this.onEnterKey(event);
                break;
            case 'Escape':
                this.onEscapeKey(event);
                break;
            case 'Tab':
                this.onTabKey(event);
                break;
            case 'PageDown':
            case 'PageUp':
            case 'Backspace':
            case 'ShiftLeft':
            case 'ShiftRight':
                //NOOP
                break;
            default:
                if (!metaKey && isPrintableCharacter(event.key)) {
                    this.searchItems(event, event.key);
                }
                break;
        }
    }
    onArrowDownKey(event) {
        const itemIndex = this.focusedItemInfo().index !== -1 ? this.findNextItemIndex(this.focusedItemInfo().index) : this.findFirstFocusedItemIndex();
        this.changeFocusedItemIndex(event, itemIndex);
        event.preventDefault();
    }
    onArrowRightKey(event) {
        const processedItem = this.visibleItems[this.focusedItemInfo().index];
        const grouped = this.isProccessedItemGroup(processedItem);
        if (grouped) {
            this.onItemChange({ originalEvent: event, processedItem });
            this.focusedItemInfo.set({ index: -1, parentKey: processedItem.key, item: processedItem.item });
            this.searchValue = '';
            this.onArrowDownKey(event);
        }
        event.preventDefault();
    }
    onArrowUpKey(event) {
        if (event.altKey) {
            if (this.focusedItemInfo().index !== -1) {
                const processedItem = this.visibleItems[this.focusedItemInfo().index];
                const grouped = this.isProccessedItemGroup(processedItem);
                !grouped && this.onItemChange({ originalEvent: event, processedItem });
            }
            this.hide();
            event.preventDefault();
        }
        else {
            const itemIndex = this.focusedItemInfo().index !== -1 ? this.findPrevItemIndex(this.focusedItemInfo().index) : this.findLastFocusedItemIndex();
            this.changeFocusedItemIndex(event, itemIndex);
            event.preventDefault();
        }
    }
    onArrowLeftKey(event) {
        const processedItem = this.visibleItems[this.focusedItemInfo().index];
        const parentItem = this.activeItemPath().find((p) => p.key === processedItem.parentKey);
        const root = isEmpty(processedItem.parent);
        if (!root) {
            this.focusedItemInfo.set({ index: -1, parentKey: parentItem ? parentItem.parentKey : '', item: processedItem.item });
            this.searchValue = '';
            this.onArrowDownKey(event);
        }
        const activeItemPath = this.activeItemPath().filter((p) => p.parentKey !== this.focusedItemInfo().parentKey);
        this.activeItemPath.set(activeItemPath);
        event.preventDefault();
    }
    onHomeKey(event) {
        this.changeFocusedItemIndex(event, this.findFirstItemIndex());
        event.preventDefault();
    }
    onEndKey(event) {
        this.changeFocusedItemIndex(event, this.findLastItemIndex());
        event.preventDefault();
    }
    onSpaceKey(event) {
        this.onEnterKey(event);
    }
    onEscapeKey(event) {
        this.hide();
        const processedItem = this.findVisibleItem(this.findFirstFocusedItemIndex());
        const focusedItemInfo = this.focusedItemInfo();
        this.focusedItemInfo.set({ ...focusedItemInfo, index: this.findFirstFocusedItemIndex(), item: processedItem.item });
        event.preventDefault();
    }
    onTabKey(event) {
        if (this.focusedItemInfo().index !== -1) {
            const processedItem = this.visibleItems[this.focusedItemInfo().index];
            const grouped = this.isProccessedItemGroup(processedItem);
            !grouped && this.onItemChange({ originalEvent: event, processedItem });
        }
        this.hide();
    }
    onEnterKey(event) {
        if (this.focusedItemInfo().index !== -1) {
            const element = findSingle(this.rootmenu?.el?.nativeElement, `li[id="${`${this.focusedItemId}`}"]`);
            const anchorElement = element && (findSingle(element, '[data-pc-section="itemlink"]') || findSingle(element, 'a,button'));
            anchorElement ? anchorElement.click() : element && element.click();
            const processedItem = this.visibleItems[this.focusedItemInfo().index];
            const grouped = this.isProccessedItemGroup(processedItem);
            if (!grouped) {
                const focusedItemInfo = this.focusedItemInfo();
                this.focusedItemInfo.set({ ...focusedItemInfo, index: this.findFirstFocusedItemIndex() });
            }
        }
        event.preventDefault();
    }
    onItemChange(event, type) {
        const { processedItem, isFocus } = event;
        if (isEmpty(processedItem))
            return;
        const { index, key, level, parentKey, items } = processedItem;
        const grouped = isNotEmpty(items);
        const activeItemPath = this.activeItemPath().filter((p) => p.parentKey !== parentKey && p.parentKey !== key);
        if (grouped) {
            activeItemPath.push(processedItem);
            this.submenuVisible.set(true);
        }
        this.focusedItemInfo.set({ index, level, parentKey, item: processedItem.item });
        isFocus && focus(this.rootmenu?.sublistViewChild()?.nativeElement);
        if (type === 'hover' && this.queryMatches()) {
            return;
        }
        this.activeItemPath.set(activeItemPath);
    }
    onMenuFocus() {
        this.focused = true;
        const focusedItemInfo = this.focusedItemInfo().index !== -1 ? this.focusedItemInfo() : { index: -1, level: 0, parentKey: '', item: null };
        this.focusedItemInfo.set(focusedItemInfo);
    }
    onMenuBlur() {
        this.focused = false;
        this.focusedItemInfo.set({ index: -1, level: 0, parentKey: '', item: null });
        this.searchValue = '';
    }
    onBeforeEnter(event) {
        this.container = event.element;
        this.appendOverlay();
        this.moveOnTop();
        this.position();
        this.$attrSelector && this.container?.setAttribute(this.$attrSelector, '');
    }
    onAfterEnter() {
        this.bindGlobalListeners();
        focus(this.rootmenu?.sublistViewChild()?.nativeElement);
    }
    onAfterLeave() {
        this.restoreOverlayAppend();
        this.onOverlayHide();
        this.handleSubmenuAfterLeave?.();
        this.render.set(false);
    }
    appendOverlay() {
        if (this.$appendTo() && this.$appendTo() !== 'self') {
            if (this.$appendTo() === 'body') {
                appendChild(this.document.body, this.container);
            }
            else {
                appendChild(this.$appendTo(), this.container);
            }
        }
    }
    restoreOverlayAppend() {
        if (this.container && this.$appendTo() !== 'self') {
            this.el.nativeElement.appendChild(this.container);
        }
    }
    moveOnTop() {
        if (this.autoZIndex() && this.container) {
            ZIndexUtils.set('menu', this.container, this.baseZIndex() + this.config.zIndex.menu);
        }
    }
    onOverlayHide() {
        this.unbindGlobalListeners();
        if (!this.cd.destroyed) {
            this._target = null;
        }
        if (this.container && this.autoZIndex()) {
            ZIndexUtils.clear(this.container);
        }
        this.container = null;
    }
    onTouchStart(event) {
        this.pressTimer = setTimeout(() => {
            this.show(event);
        }, this.pressDelay());
    }
    onTouchEnd() {
        clearTimeout(this.pressTimer);
    }
    hide() {
        this.visible.set(false);
        this.onHide.emit(null);
        this.hideCallback?.();
        this.activeItemPath.set([]);
        this.focusedItemInfo.set({ index: -1, level: 0, parentKey: '', item: null });
    }
    toggle(event) {
        this.visible() ? this.hide() : this.show(event);
    }
    show(event) {
        this.activeItemPath.set([]);
        this.focusedItemInfo.set({ index: -1, level: 0, parentKey: '', item: null });
        focus(this.rootmenu?.sublistViewChild()?.nativeElement);
        this.pageX = event.pageX;
        this.pageY = event.pageY;
        this.onShow.emit(null);
        this.visible() ? this.position() : this.visible.set(true);
        this.render.set(true);
        event.stopPropagation();
        event.preventDefault();
    }
    position() {
        if (!this.document.scrollingElement || !this.container)
            return;
        let left = this.pageX + 1;
        let top = this.pageY + 1;
        let width = this.container.offsetParent ? this.container.offsetWidth : getHiddenElementOuterWidth(this.container);
        let height = this.container.offsetParent ? this.container.offsetHeight : getHiddenElementOuterHeight(this.container);
        let viewport = getViewport();
        //flip
        if (left + width - this.document.scrollingElement.scrollLeft > viewport.width) {
            left -= width;
        }
        //flip
        if (top + height - this.document.scrollingElement.scrollTop > viewport.height) {
            top -= height;
        }
        //fit
        if (left < this.document.scrollingElement.scrollLeft) {
            left = this.document.scrollingElement.scrollLeft;
        }
        //fit
        if (top < this.document.scrollingElement.scrollTop) {
            top = this.document.scrollingElement.scrollTop;
        }
        this.container.style.left = left + 'px';
        this.container.style.top = top + 'px';
    }
    searchItems(event, char) {
        this.searchValue = (this.searchValue || '') + char;
        let itemIndex = -1;
        let matched = false;
        if (this.focusedItemInfo().index !== -1) {
            itemIndex = this.visibleItems.slice(this.focusedItemInfo().index).findIndex((processedItem) => this.isItemMatched(processedItem));
            itemIndex = itemIndex === -1 ? this.visibleItems.slice(0, this.focusedItemInfo().index).findIndex((processedItem) => this.isItemMatched(processedItem)) : itemIndex + this.focusedItemInfo().index;
        }
        else {
            itemIndex = this.visibleItems.findIndex((processedItem) => this.isItemMatched(processedItem));
        }
        if (itemIndex !== -1) {
            matched = true;
        }
        if (itemIndex === -1 && this.focusedItemInfo().index === -1) {
            itemIndex = this.findFirstFocusedItemIndex();
        }
        if (itemIndex !== -1) {
            this.changeFocusedItemIndex(event, itemIndex);
        }
        if (this.searchTimeout) {
            clearTimeout(this.searchTimeout);
        }
        this.searchTimeout = setTimeout(() => {
            this.searchValue = '';
            this.searchTimeout = null;
        }, 500);
        return matched;
    }
    findVisibleItem(index) {
        return isNotEmpty(this.visibleItems) ? this.visibleItems[index] : null;
    }
    findLastFocusedItemIndex() {
        const selectedIndex = this.findSelectedItemIndex();
        return selectedIndex < 0 ? this.findLastItemIndex() : selectedIndex;
    }
    findLastItemIndex() {
        return findLastIndex(this.visibleItems, (processedItem) => this.isValidItem(processedItem));
    }
    findPrevItemIndex(index) {
        const matchedItemIndex = index > 0 ? findLastIndex(this.visibleItems.slice(0, index), (processedItem) => this.isValidItem(processedItem)) : -1;
        return matchedItemIndex > -1 ? matchedItemIndex : index;
    }
    findNextItemIndex(index) {
        const matchedItemIndex = index < this.visibleItems.length - 1 ? this.visibleItems.slice(index + 1).findIndex((processedItem) => this.isValidItem(processedItem)) : -1;
        return matchedItemIndex > -1 ? matchedItemIndex + index + 1 : index;
    }
    findFirstFocusedItemIndex() {
        const selectedIndex = this.findSelectedItemIndex();
        return selectedIndex < 0 ? this.findFirstItemIndex() : selectedIndex;
    }
    findFirstItemIndex() {
        return this.visibleItems.findIndex((processedItem) => this.isValidItem(processedItem));
    }
    findSelectedItemIndex() {
        return this.visibleItems.findIndex((processedItem) => this.isValidSelectedItem(processedItem));
    }
    changeFocusedItemIndex(event, index) {
        const processedItem = this.findVisibleItem(index);
        const focusedItemInfo = this.focusedItemInfo();
        if (focusedItemInfo.index !== index) {
            this.focusedItemInfo.set({ ...focusedItemInfo, index, item: processedItem.item });
            this.scrollInView();
        }
    }
    scrollInView(index = -1) {
        const id = index !== -1 ? `${this.resolvedId}_${index}` : this.focusedItemId;
        const element = findSingle(this.rootmenu?.el?.nativeElement, `li[id="${id}"]`);
        if (element) {
            element.scrollIntoView && element.scrollIntoView({ block: 'nearest', inline: 'nearest' });
        }
    }
    bindResizeListener() {
        if (isPlatformBrowser(this.platformId)) {
            if (!this.resizeListener) {
                this.resizeListener = this.renderer.listen(this.document.defaultView, 'resize', () => {
                    this.hide();
                });
            }
        }
    }
    isOutsideClicked(event) {
        return !(this.container?.isSameNode(event.target) || this.container?.contains(event.target));
    }
    unbindResizeListener() {
        if (this.resizeListener) {
            this.resizeListener();
            this.resizeListener = null;
        }
    }
    unbindGlobalListeners() {
        if (this.documentClickListener) {
            this.documentClickListener();
            this.documentClickListener = null;
        }
        if (this.documentTriggerListener) {
            this.documentTriggerListener();
            this.documentTriggerListener = null;
        }
        if (this.resizeListener) {
            this.resizeListener();
            this.resizeListener = null;
        }
        if (this.touchEndListener) {
            this.touchEndListener();
            this.touchEndListener = null;
        }
    }
    unbindTriggerEventListener() {
        if (this.triggerEventListener) {
            this.triggerEventListener();
            this.triggerEventListener = null;
        }
    }
    onDestroy() {
        this.unbindGlobalListeners();
        this.unbindTriggerEventListener();
        this.unbindMatchMediaListener();
        this.restoreOverlayAppend();
        this.onOverlayHide();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ContextMenu, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: ContextMenu, isStandalone: true, selector: "p-contextMenu, p-contextmenu, p-context-menu", inputs: { model: { classPropertyName: "model", publicName: "model", isSignal: true, isRequired: false, transformFunction: null }, triggerEvent: { classPropertyName: "triggerEvent", publicName: "triggerEvent", isSignal: true, isRequired: false, transformFunction: null }, target: { classPropertyName: "target", publicName: "target", isSignal: true, isRequired: false, transformFunction: null }, global: { classPropertyName: "global", publicName: "global", isSignal: true, isRequired: false, transformFunction: null }, style: { classPropertyName: "style", publicName: "style", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, autoZIndex: { classPropertyName: "autoZIndex", publicName: "autoZIndex", isSignal: true, isRequired: false, transformFunction: null }, baseZIndex: { classPropertyName: "baseZIndex", publicName: "baseZIndex", isSignal: true, isRequired: false, transformFunction: null }, id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, breakpoint: { classPropertyName: "breakpoint", publicName: "breakpoint", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledBy: { classPropertyName: "ariaLabelledBy", publicName: "ariaLabelledBy", isSignal: true, isRequired: false, transformFunction: null }, pressDelay: { classPropertyName: "pressDelay", publicName: "pressDelay", isSignal: true, isRequired: false, transformFunction: null }, appendTo: { classPropertyName: "appendTo", publicName: "appendTo", isSignal: true, isRequired: false, transformFunction: null }, motionOptions: { classPropertyName: "motionOptions", publicName: "motionOptions", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onShow: "onShow", onHide: "onHide" }, providers: [ContextMenuStyle, { provide: CONTEXTMENU_INSTANCE, useExisting: ContextMenu }], queries: [{ propertyName: "itemTemplate", first: true, predicate: ["item"], isSignal: true }, { propertyName: "submenuIconTemplate", first: true, predicate: ["submenuicon"], isSignal: true }, { propertyName: "templates", predicate: PrimeTemplate, isSignal: true }], viewQueries: [{ propertyName: "rootmenu", first: true, predicate: ["rootmenu"], descendants: true }], usesInheritance: true, ngImport: i0, template: `
        @if (render()) {
            <div
                #container
                [attr.id]="resolvedId"
                [class]="cn(cx('root'), styleClass())"
                [style]="sx('root')"
                [ngStyle]="style()"
                [pBind]="ptm('root')"
                [pMotion]="visible()"
                [pMotionName]="'p-anchored-overlay'"
                [pMotionAppear]="true"
                [pMotionOptions]="computedMotionOptions()"
                (pMotionOnBeforeEnter)="onBeforeEnter($event)"
                (pMotionOnAfterEnter)="onAfterEnter()"
                (pMotionOnAfterLeave)="onAfterLeave()"
            >
                <p-contextmenu-sub
                    #rootmenu
                    [root]="true"
                    [items]="processedItems"
                    [itemTemplate]="itemTemplate() || _itemTemplate"
                    [menuId]="resolvedId"
                    [ariaLabel]="ariaLabel()"
                    [ariaLabelledBy]="ariaLabelledBy()"
                    [baseZIndex]="baseZIndex()"
                    [autoZIndex]="autoZIndex()"
                    [visible]="submenuVisible()"
                    [focusedItemId]="focused ? focusedItemId : undefined"
                    [activeItemPath]="activeItemPath()"
                    (itemClick)="onItemClick($event)"
                    (menuFocus)="onMenuFocus($event)"
                    (menuBlur)="onMenuBlur($event)"
                    (menuKeydown)="onKeyDown($event)"
                    (itemMouseEnter)="onItemMouseEnter($event)"
                    [pt]="pt()"
                    [unstyled]="unstyled()"
                    [motionOptions]="computedMotionOptions()"
                />
            </div>
        }
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: ContextMenuSub, selector: "p-contextMenuSub, p-contextmenu-sub", inputs: ["visible", "items", "itemTemplate", "root", "autoZIndex", "baseZIndex", "popup", "menuId", "ariaLabel", "ariaLabelledBy", "level", "focusedItemId", "activeItemPath", "motionOptions", "tabindex"], outputs: ["itemClick", "itemMouseEnter", "menuFocus", "menuBlur", "menuKeydown"] }, { kind: "ngmodule", type: RouterModule }, { kind: "ngmodule", type: TooltipModule }, { kind: "directive", type: i4.Bind, selector: "[pBind]", inputs: ["pBind"] }, { kind: "ngmodule", type: BadgeModule }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: BindModule }, { kind: "ngmodule", type: MotionModule }, { kind: "directive", type: i6.MotionDirective, selector: "[pMotion]", inputs: ["pMotion", "pMotionName", "pMotionType", "pMotionSafe", "pMotionDisabled", "pMotionAppear", "pMotionEnter", "pMotionLeave", "pMotionDuration", "pMotionHideStrategy", "pMotionEnterFromClass", "pMotionEnterToClass", "pMotionEnterActiveClass", "pMotionLeaveFromClass", "pMotionLeaveToClass", "pMotionLeaveActiveClass", "pMotionOptions"], outputs: ["pMotionOnBeforeEnter", "pMotionOnEnter", "pMotionOnAfterEnter", "pMotionOnEnterCancelled", "pMotionOnBeforeLeave", "pMotionOnLeave", "pMotionOnAfterLeave", "pMotionOnLeaveCancelled"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ContextMenu, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-contextMenu, p-contextmenu, p-context-menu',
                    standalone: true,
                    imports: [CommonModule, ContextMenuSub, RouterModule, TooltipModule, BadgeModule, SharedModule, BindModule, MotionModule],
                    template: `
        @if (render()) {
            <div
                #container
                [attr.id]="resolvedId"
                [class]="cn(cx('root'), styleClass())"
                [style]="sx('root')"
                [ngStyle]="style()"
                [pBind]="ptm('root')"
                [pMotion]="visible()"
                [pMotionName]="'p-anchored-overlay'"
                [pMotionAppear]="true"
                [pMotionOptions]="computedMotionOptions()"
                (pMotionOnBeforeEnter)="onBeforeEnter($event)"
                (pMotionOnAfterEnter)="onAfterEnter()"
                (pMotionOnAfterLeave)="onAfterLeave()"
            >
                <p-contextmenu-sub
                    #rootmenu
                    [root]="true"
                    [items]="processedItems"
                    [itemTemplate]="itemTemplate() || _itemTemplate"
                    [menuId]="resolvedId"
                    [ariaLabel]="ariaLabel()"
                    [ariaLabelledBy]="ariaLabelledBy()"
                    [baseZIndex]="baseZIndex()"
                    [autoZIndex]="autoZIndex()"
                    [visible]="submenuVisible()"
                    [focusedItemId]="focused ? focusedItemId : undefined"
                    [activeItemPath]="activeItemPath()"
                    (itemClick)="onItemClick($event)"
                    (menuFocus)="onMenuFocus($event)"
                    (menuBlur)="onMenuBlur($event)"
                    (menuKeydown)="onKeyDown($event)"
                    (itemMouseEnter)="onItemMouseEnter($event)"
                    [pt]="pt()"
                    [unstyled]="unstyled()"
                    [motionOptions]="computedMotionOptions()"
                />
            </div>
        }
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [ContextMenuStyle, { provide: CONTEXTMENU_INSTANCE, useExisting: ContextMenu }]
                }]
        }], ctorParameters: () => [], propDecorators: { model: [{ type: i0.Input, args: [{ isSignal: true, alias: "model", required: false }] }], triggerEvent: [{ type: i0.Input, args: [{ isSignal: true, alias: "triggerEvent", required: false }] }], target: [{ type: i0.Input, args: [{ isSignal: true, alias: "target", required: false }] }], global: [{ type: i0.Input, args: [{ isSignal: true, alias: "global", required: false }] }], style: [{ type: i0.Input, args: [{ isSignal: true, alias: "style", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], autoZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "autoZIndex", required: false }] }], baseZIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "baseZIndex", required: false }] }], id: [{ type: i0.Input, args: [{ isSignal: true, alias: "id", required: false }] }], breakpoint: [{ type: i0.Input, args: [{ isSignal: true, alias: "breakpoint", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], ariaLabelledBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabelledBy", required: false }] }], pressDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "pressDelay", required: false }] }], appendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "appendTo", required: false }] }], motionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "motionOptions", required: false }] }], onShow: [{ type: i0.Output, args: ["onShow"] }], onHide: [{ type: i0.Output, args: ["onHide"] }], rootmenu: [{
                type: ViewChild,
                args: ['rootmenu']
            }], itemTemplate: [{ type: i0.ContentChild, args: ['item', { ...{ descendants: false }, isSignal: true }] }], submenuIconTemplate: [{ type: i0.ContentChild, args: ['submenuicon', { ...{ descendants: false }, isSignal: true }] }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }] } });
class ContextMenuModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ContextMenuModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: ContextMenuModule, imports: [ContextMenu, SharedModule], exports: [ContextMenu, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ContextMenuModule, imports: [ContextMenu, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ContextMenuModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [ContextMenu, SharedModule],
                    exports: [ContextMenu, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { ContextMenu, ContextMenuClasses, ContextMenuModule, ContextMenuStyle, ContextMenuSub };
//# sourceMappingURL=wawjs-ngx-prime-contextmenu.mjs.map
