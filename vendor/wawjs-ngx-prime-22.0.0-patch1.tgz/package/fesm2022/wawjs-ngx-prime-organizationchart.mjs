export * from '@wawjs/ngx-prime/types/organizationchart';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, ChangeDetectorRef, input, booleanAttribute, ChangeDetectionStrategy, ViewEncapsulation, Component, ElementRef, model, output, contentChildren, effect, ContentChild, NgModule } from '@angular/core';
import { isAttributeEquals } from '@wawjs/css-prime-utils';
import { SharedModule, PrimeTemplate } from '@wawjs/ngx-prime/api';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i2 from '@wawjs/ngx-prime/bind';
import { BindModule, Bind } from '@wawjs/ngx-prime/bind';
import { ChevronDownIcon, ChevronUpIcon } from '@wawjs/ngx-prime/icons';
import { Subject } from 'rxjs';
import { style } from '@wawjs/css-prime-styles/organizationchart';
import { BaseStyle } from '@wawjs/ngx-prime/base';

const classes = {
    root: ({ instance }) => ['p-organizationchart p-component', { 'p-organizationchart-preservespace': instance.preserveSpace() }],
    table: 'p-organizationchart-table',
    node: ({ instance }) => [
        'p-organizationchart-node',
        { 'p-organizationchart-node': true, 'p-organizationchart-node-selectable': instance.chart.selectionMode() && instance.node().selectable !== false, 'p-organizationchart-node-selected': instance.isSelected() }
    ],
    nodeToggleButton: 'p-organizationchart-node-toggle-button',
    nodeToggleButtonIcon: 'p-organizationchart-node-toggle-button-icon',
    connectors: 'p-organizationchart-connectors',
    connectorDown: 'p-organizationchart-connector-down',
    connectorLeft: ({ first }) => ['p-organizationchart-connector-left', { 'p-organizationchart-connector-top': !first }],
    connectorRight: ({ last }) => ['p-organizationchart-connector-right', { 'p-organizationchart-connector-top': !last }],
    nodeChildren: 'p-organizationchart-node-children'
};
class OrganizationChartStyle extends BaseStyle {
    name = 'organizationchart';
    style = style;
    classes = classes;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OrganizationChartStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OrganizationChartStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OrganizationChartStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * OrganizationChart visualizes hierarchical organization data.
 *
 * [Live Demo](https://www.ngx-prime.org/organizationchart)
 *
 * @module organizationchartstyle
 *
 */
var OrganizationChartClasses;
(function (OrganizationChartClasses) {
    /**
     * Class name of the root element
     */
    OrganizationChartClasses["root"] = "p-organizationchart";
    /**
     * Class name of the table element
     */
    OrganizationChartClasses["table"] = "p-organizationchart-table";
    /**
     * Class name of the node element
     */
    OrganizationChartClasses["node"] = "p-organizationchart-node";
    /**
     * Class name of the node toggle button element
     */
    OrganizationChartClasses["nodeToggleButton"] = "p-organizationchart-node-toggle-button";
    /**
     * Class name of the node toggle button icon element
     */
    OrganizationChartClasses["nodeToggleButtonIcon"] = "p-organizationchart-node-toggle-button-icon";
    /**
     * Class name of the connectors element
     */
    OrganizationChartClasses["connectors"] = "p-organizationchart-connectors";
    /**
     * Class name of the connector down element
     */
    OrganizationChartClasses["connectorDown"] = "p-organizationchart-connector-down";
    /**
     * Class name of the connector left element
     */
    OrganizationChartClasses["connectorLeft"] = "p-organizationchart-connector-left";
    /**
     * Class name of the connector right element
     */
    OrganizationChartClasses["connectorRight"] = "p-organizationchart-connector-right";
    /**
     * Class name of the node children element
     */
    OrganizationChartClasses["nodeChildren"] = "p-organizationchart-node-children";
})(OrganizationChartClasses || (OrganizationChartClasses = {}));

const ORGANIZATIONCHART_INSTANCE = new InjectionToken('ORGANIZATIONCHART_INSTANCE');
class OrganizationChartNode extends BaseComponent {
    cd = inject(ChangeDetectorRef);
    node = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "node" }] : /* istanbul ignore next */ []));
    root = input(undefined, { ...(ngDevMode ? { debugName: "root" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    first = input(undefined, { ...(ngDevMode ? { debugName: "first" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    last = input(undefined, { ...(ngDevMode ? { debugName: "last" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    collapsible = input(undefined, { ...(ngDevMode ? { debugName: "collapsible" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    chart;
    subscription;
    _componentStyle = inject(OrganizationChartStyle);
    constructor() {
        const chart = inject(OrganizationChart);
        super();
        this.chart = chart;
        this.subscription = this.chart.selectionSource$.subscribe(() => {
            this.cd.markForCheck();
        });
    }
    get leaf() {
        const node = this.node();
        if (node) {
            return node.leaf == false ? false : !(node.children && node.children.length);
        }
    }
    get colspan() {
        const node = this.node();
        if (node) {
            return node.children && node.children.length ? node.children.length * 2 : null;
        }
    }
    getChildStyle(node) {
        return {
            visibility: !this.leaf && node.expanded ? 'inherit' : 'hidden'
        };
    }
    getPTOptions(key) {
        const node = this.node();
        return this.ptm(key, {
            context: {
                expanded: node?.expanded,
                selectable: node?.selectable !== false && this.chart.selectionMode(),
                selected: this.isSelected(),
                toggleable: this.collapsible() && !this.leaf,
                active: this.isSelected()
            }
        });
    }
    getNodeOptions(lineTop, key) {
        return this.ptm(key, {
            context: {
                lineTop
            }
        });
    }
    onNodeClick(event, node) {
        this.chart.onNodeClick(event, node);
    }
    toggleNode(event, node) {
        node.expanded = !node.expanded;
        if (node.expanded)
            this.chart.onNodeExpand.emit({ originalEvent: event, node: this.node() });
        else
            this.chart.onNodeCollapse.emit({ originalEvent: event, node: this.node() });
        event.preventDefault();
    }
    isSelected() {
        return this.chart.isSelected(this.node());
    }
    onDestroy() {
        this.subscription.unsubscribe();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OrganizationChartNode, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: OrganizationChartNode, isStandalone: true, selector: "[pOrganizationChartNode]", inputs: { node: { classPropertyName: "node", publicName: "node", isSignal: true, isRequired: false, transformFunction: null }, root: { classPropertyName: "root", publicName: "root", isSignal: true, isRequired: false, transformFunction: null }, first: { classPropertyName: "first", publicName: "first", isSignal: true, isRequired: false, transformFunction: null }, last: { classPropertyName: "last", publicName: "last", isSignal: true, isRequired: false, transformFunction: null }, collapsible: { classPropertyName: "collapsible", publicName: "collapsible", isSignal: true, isRequired: false, transformFunction: null } }, providers: [OrganizationChartStyle, { provide: PARENT_INSTANCE, useExisting: OrganizationChartNode }], usesInheritance: true, ngImport: i0, template: `
        @if (node()) {
            <tbody [pBind]="ptm('body')">
                <tr [pBind]="ptm('row')">
                    <td [attr.colspan]="colspan" [pBind]="ptm('cell')">
                        <div [class]="cn(cx('node'), node().styleClass)" (click)="onNodeClick($event, node())" [pBind]="getPTOptions('node')">
                            @if (!chart.getTemplateForNode(node())) {
                                <div>{{ node().label }}</div>
                            }
                            @if (chart.getTemplateForNode(node())) {
                                <div>
                                    <ng-container *ngTemplateOutlet="chart.getTemplateForNode(node()); context: { $implicit: node() }"></ng-container>
                                </div>
                            }
                            @if (collapsible()) {
                                @if (!leaf) {
                                    <a
                                        tabindex="0"
                                        [class]="cx('nodeToggleButton')"
                                        (click)="toggleNode($event, node())"
                                        (keydown.enter)="toggleNode($event, node())"
                                        (keydown.space)="toggleNode($event, node())"
                                        [pBind]="getPTOptions('nodeToggleButton')"
                                    >
                                        @if (!chart.togglerIconTemplate && !chart._togglerIconTemplate) {
                                            @if (node().expanded) {
                                                <svg data-p-icon="chevron-down" [class]="cx('nodeToggleButtonIcon')" [pBind]="getPTOptions('nodeToggleButtonIcon')" />
                                            }
                                            @if (!node().expanded) {
                                                <svg data-p-icon="chevron-up" [class]="cx('nodeToggleButtonIcon')" [pBind]="getPTOptions('nodeToggleButtonIcon')" />
                                            }
                                        }
                                        @if (chart.togglerIconTemplate || chart._togglerIconTemplate) {
                                            <span [class]="cx('nodeToggleButtonIcon')" [pBind]="getPTOptions('nodeToggleButtonIcon')">
                                                <ng-template *ngTemplateOutlet="chart.togglerIconTemplate || chart._togglerIconTemplate; context: { $implicit: node().expanded }"></ng-template>
                                            </span>
                                        }
                                    </a>
                                }
                            }
                        </div>
                    </td>
                </tr>
                <tr [ngStyle]="getChildStyle(node())" [class]="cx('connectors')" [pBind]="ptm('connectors')">
                    <td [pBind]="ptm('lineCell')" [attr.colspan]="colspan">
                        <div [pBind]="ptm('connectorDown')" [class]="cx('connectorDown')"></div>
                    </td>
                </tr>
                <tr [ngStyle]="getChildStyle(node())" [class]="cx('connectors')" [pBind]="ptm('connectors')">
                    @if (node().children && node().children.length === 1) {
                        <td [pBind]="ptm('lineCell')" [attr.colspan]="colspan">
                            <div [pBind]="ptm('connectorDown')" [class]="cx('connectorDown')"></div>
                        </td>
                    }
                    @if (node().children && node().children.length > 1) {
                        @for (child of node().children; track child; let first = $first; let last = $last; let index = $index) {
                            <td [class]="cx('connectorLeft', { first })" [pBind]="getNodeOptions(!(index === 0), 'connectorLeft')">&nbsp;</td>
                            <td [class]="cx('connectorRight', { last })" [pBind]="getNodeOptions(!(index === node().children.length - 1), 'connectorRight')">&nbsp;</td>
                        }
                    }
                </tr>
                <tr [ngStyle]="getChildStyle(node())" [class]="cx('nodeChildren')" [pBind]="ptm('nodeChildren')">
                    @for (child of node().children; track child) {
                        <td colspan="2" [pBind]="ptm('nodeCell')">
                            <table [class]="cx('table')" pOrganizationChartNode [unstyled]="unstyled()" [pt]="pt" [node]="child" [collapsible]="node().children && node().children.length > 0 && collapsible()"></table>
                        </td>
                    }
                </tr>
            </tbody>
        }
    `, isInline: true, dependencies: [{ kind: "component", type: OrganizationChartNode, selector: "[pOrganizationChartNode]", inputs: ["node", "root", "first", "last", "collapsible"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: ChevronDownIcon, selector: "[data-p-icon=\"chevron-down\"]" }, { kind: "component", type: ChevronUpIcon, selector: "[data-p-icon=\"chevron-up\"]" }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: BindModule }, { kind: "directive", type: i2.Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OrganizationChartNode, decorators: [{
            type: Component,
            args: [{
                    selector: '[pOrganizationChartNode]',
                    standalone: true,
                    imports: [CommonModule, ChevronDownIcon, ChevronUpIcon, SharedModule, BindModule],
                    template: `
        @if (node()) {
            <tbody [pBind]="ptm('body')">
                <tr [pBind]="ptm('row')">
                    <td [attr.colspan]="colspan" [pBind]="ptm('cell')">
                        <div [class]="cn(cx('node'), node().styleClass)" (click)="onNodeClick($event, node())" [pBind]="getPTOptions('node')">
                            @if (!chart.getTemplateForNode(node())) {
                                <div>{{ node().label }}</div>
                            }
                            @if (chart.getTemplateForNode(node())) {
                                <div>
                                    <ng-container *ngTemplateOutlet="chart.getTemplateForNode(node()); context: { $implicit: node() }"></ng-container>
                                </div>
                            }
                            @if (collapsible()) {
                                @if (!leaf) {
                                    <a
                                        tabindex="0"
                                        [class]="cx('nodeToggleButton')"
                                        (click)="toggleNode($event, node())"
                                        (keydown.enter)="toggleNode($event, node())"
                                        (keydown.space)="toggleNode($event, node())"
                                        [pBind]="getPTOptions('nodeToggleButton')"
                                    >
                                        @if (!chart.togglerIconTemplate && !chart._togglerIconTemplate) {
                                            @if (node().expanded) {
                                                <svg data-p-icon="chevron-down" [class]="cx('nodeToggleButtonIcon')" [pBind]="getPTOptions('nodeToggleButtonIcon')" />
                                            }
                                            @if (!node().expanded) {
                                                <svg data-p-icon="chevron-up" [class]="cx('nodeToggleButtonIcon')" [pBind]="getPTOptions('nodeToggleButtonIcon')" />
                                            }
                                        }
                                        @if (chart.togglerIconTemplate || chart._togglerIconTemplate) {
                                            <span [class]="cx('nodeToggleButtonIcon')" [pBind]="getPTOptions('nodeToggleButtonIcon')">
                                                <ng-template *ngTemplateOutlet="chart.togglerIconTemplate || chart._togglerIconTemplate; context: { $implicit: node().expanded }"></ng-template>
                                            </span>
                                        }
                                    </a>
                                }
                            }
                        </div>
                    </td>
                </tr>
                <tr [ngStyle]="getChildStyle(node())" [class]="cx('connectors')" [pBind]="ptm('connectors')">
                    <td [pBind]="ptm('lineCell')" [attr.colspan]="colspan">
                        <div [pBind]="ptm('connectorDown')" [class]="cx('connectorDown')"></div>
                    </td>
                </tr>
                <tr [ngStyle]="getChildStyle(node())" [class]="cx('connectors')" [pBind]="ptm('connectors')">
                    @if (node().children && node().children.length === 1) {
                        <td [pBind]="ptm('lineCell')" [attr.colspan]="colspan">
                            <div [pBind]="ptm('connectorDown')" [class]="cx('connectorDown')"></div>
                        </td>
                    }
                    @if (node().children && node().children.length > 1) {
                        @for (child of node().children; track child; let first = $first; let last = $last; let index = $index) {
                            <td [class]="cx('connectorLeft', { first })" [pBind]="getNodeOptions(!(index === 0), 'connectorLeft')">&nbsp;</td>
                            <td [class]="cx('connectorRight', { last })" [pBind]="getNodeOptions(!(index === node().children.length - 1), 'connectorRight')">&nbsp;</td>
                        }
                    }
                </tr>
                <tr [ngStyle]="getChildStyle(node())" [class]="cx('nodeChildren')" [pBind]="ptm('nodeChildren')">
                    @for (child of node().children; track child) {
                        <td colspan="2" [pBind]="ptm('nodeCell')">
                            <table [class]="cx('table')" pOrganizationChartNode [unstyled]="unstyled()" [pt]="pt" [node]="child" [collapsible]="node().children && node().children.length > 0 && collapsible()"></table>
                        </td>
                    }
                </tr>
            </tbody>
        }
    `,
                    encapsulation: ViewEncapsulation.None,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    providers: [OrganizationChartStyle, { provide: PARENT_INSTANCE, useExisting: OrganizationChartNode }]
                }]
        }], ctorParameters: () => [], propDecorators: { node: [{ type: i0.Input, args: [{ isSignal: true, alias: "node", required: false }] }], root: [{ type: i0.Input, args: [{ isSignal: true, alias: "root", required: false }] }], first: [{ type: i0.Input, args: [{ isSignal: true, alias: "first", required: false }] }], last: [{ type: i0.Input, args: [{ isSignal: true, alias: "last", required: false }] }], collapsible: [{ type: i0.Input, args: [{ isSignal: true, alias: "collapsible", required: false }] }] } });
/**
 * OrganizationChart visualizes hierarchical organization data.
 * @group Components
 */
class OrganizationChart extends BaseComponent {
    el = inject(ElementRef);
    cd = inject(ChangeDetectorRef);
    componentName = 'OrganizationChart';
    /**
     * An array of nested TreeNodes.
     * @group Props
     */
    value = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "value" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Defines the selection mode.
     * @group Props
     */
    selectionMode = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "selectionMode" }] : /* istanbul ignore next */ []));
    /**
     * Whether the nodes can be expanded or toggled.
     * @group Props
     */
    collapsible = input(undefined, { ...(ngDevMode ? { debugName: "collapsible" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether the space allocated by a node is preserved when hidden.
     * @deprecated since v20.0.0.
     * @group Props
     */
    preserveSpace = input(true, { ...(ngDevMode ? { debugName: "preserveSpace" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * A single treenode instance or an array to refer to the selections.
     * @group Props
     */
    selection = model(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "selection" }] : /* istanbul ignore next */ []));
    /**
     * Callback to invoke when a node is selected.
     * @param {OrganizationChartNodeSelectEvent} event - custom node select event.
     * @group Emits
     */
    onNodeSelect = output();
    /**
     * Callback to invoke when a node is unselected.
     * @param {OrganizationChartNodeUnSelectEvent} event - custom node unselect event.
     * @group Emits
     */
    onNodeUnselect = output();
    /**
     * Callback to invoke when a node is expanded.
     * @param {OrganizationChartNodeExpandEvent} event - custom node expand event.
     * @group Emits
     */
    onNodeExpand = output();
    /**
     * Callback to invoke when a node is collapsed.
     * @param {OrganizationChartNodeCollapseEvent} event - custom node collapse event.
     * @group Emits
     */
    onNodeCollapse = output();
    templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "templates" }] : /* istanbul ignore next */ []));
    togglerIconTemplate;
    templateMap;
    _togglerIconTemplate;
    selectionSource = new Subject();
    initialized;
    selectionSource$ = this.selectionSource.asObservable();
    _componentStyle = inject(OrganizationChartStyle);
    bindDirectiveInstance = inject(Bind, { self: true });
    $pcOrganizationChart = inject(ORGANIZATIONCHART_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    constructor() {
        super();
        effect(() => {
            this.selection();
            if (this.initialized) {
                this.selectionSource.next(null);
            }
        });
    }
    ngAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    get root() {
        const value = this.value();
        return value && value.length ? value[0] : null;
    }
    onAfterContentInit() {
        if (this.templates().length) {
            this.templateMap = {};
        }
        this.templates().forEach((item) => {
            if (item.getType() === 'togglericon') {
                this._togglerIconTemplate = item.template;
            }
            else {
                this.templateMap[item.getType()] = item.template;
            }
        });
        this.initialized = true;
    }
    getTemplateForNode(node) {
        if (this.templateMap)
            return node.type ? this.templateMap[node.type] : this.templateMap['default'];
        else
            return null;
    }
    onNodeClick(event, node) {
        let eventTarget = event.target;
        if (isAttributeEquals(eventTarget, 'data-pc-section', 'nodetogglebutton') || isAttributeEquals(eventTarget, 'data-pc-section', 'nodetogglebuttonicon')) {
            return;
        }
        else if (this.selectionMode()) {
            if (node.selectable === false) {
                return;
            }
            let index = this.findIndexInSelection(node);
            let selected = index >= 0;
            if (this.selectionMode() === 'single') {
                if (selected) {
                    this.selection.set(null);
                    this.onNodeUnselect.emit({ originalEvent: event, node: node });
                }
                else {
                    this.selection.set(node);
                    this.onNodeSelect.emit({ originalEvent: event, node: node });
                }
            }
            else if (this.selectionMode() === 'multiple') {
                if (selected) {
                    this.selection.set(this.selection().filter((val, i) => i != index));
                    this.onNodeUnselect.emit({ originalEvent: event, node: node });
                }
                else {
                    this.selection.set([...(this.selection() || []), node]);
                    this.onNodeSelect.emit({ originalEvent: event, node: node });
                }
            }
        }
    }
    findIndexInSelection(node) {
        let index = -1;
        if (this.selectionMode() && this.selection()) {
            if (this.selectionMode() === 'single') {
                index = this.selection() == node ? 0 : -1;
            }
            else if (this.selectionMode() === 'multiple') {
                for (let i = 0; i < this.selection().length; i++) {
                    if (this.selection()[i] == node) {
                        index = i;
                        break;
                    }
                }
            }
        }
        return index;
    }
    isSelected(node) {
        return this.findIndexInSelection(node) != -1;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OrganizationChart, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: OrganizationChart, isStandalone: true, selector: "p-organizationChart, p-organization-chart, p-organizationchart", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, selectionMode: { classPropertyName: "selectionMode", publicName: "selectionMode", isSignal: true, isRequired: false, transformFunction: null }, collapsible: { classPropertyName: "collapsible", publicName: "collapsible", isSignal: true, isRequired: false, transformFunction: null }, preserveSpace: { classPropertyName: "preserveSpace", publicName: "preserveSpace", isSignal: true, isRequired: false, transformFunction: null }, selection: { classPropertyName: "selection", publicName: "selection", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selection: "selectionChange", onNodeSelect: "onNodeSelect", onNodeUnselect: "onNodeUnselect", onNodeExpand: "onNodeExpand", onNodeCollapse: "onNodeCollapse" }, host: { properties: { "class": "cn(cx('root'), styleClass())" } }, providers: [OrganizationChartStyle, { provide: ORGANIZATIONCHART_INSTANCE, useExisting: OrganizationChart }, { provide: PARENT_INSTANCE, useExisting: OrganizationChart }], queries: [{ propertyName: "templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "togglerIconTemplate", first: true, predicate: ["togglericon"] }], usesInheritance: true, hostDirectives: [{ directive: i2.Bind }], ngImport: i0, template: `
        @if (root) {
            <table [class]="cx('table')" [collapsible]="collapsible()" pOrganizationChartNode [pt]="pt" [unstyled]="unstyled()" [node]="root" [pBind]="ptm('table')"></table>
        }
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: OrganizationChartNode, selector: "[pOrganizationChartNode]", inputs: ["node", "root", "first", "last", "collapsible"] }, { kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: BindModule }, { kind: "directive", type: i2.Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OrganizationChart, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-organizationChart, p-organization-chart, p-organizationchart',
                    standalone: true,
                    imports: [CommonModule, OrganizationChartNode, SharedModule, BindModule],
                    template: `
        @if (root) {
            <table [class]="cx('table')" [collapsible]="collapsible()" pOrganizationChartNode [pt]="pt" [unstyled]="unstyled()" [node]="root" [pBind]="ptm('table')"></table>
        }
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    providers: [OrganizationChartStyle, { provide: ORGANIZATIONCHART_INSTANCE, useExisting: OrganizationChart }, { provide: PARENT_INSTANCE, useExisting: OrganizationChart }],
                    host: {
                        '[class]': "cn(cx('root'), styleClass())"
                    },
                    hostDirectives: [Bind]
                }]
        }], ctorParameters: () => [], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], selectionMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectionMode", required: false }] }], collapsible: [{ type: i0.Input, args: [{ isSignal: true, alias: "collapsible", required: false }] }], preserveSpace: [{ type: i0.Input, args: [{ isSignal: true, alias: "preserveSpace", required: false }] }], selection: [{ type: i0.Input, args: [{ isSignal: true, alias: "selection", required: false }] }, { type: i0.Output, args: ["selectionChange"] }], onNodeSelect: [{ type: i0.Output, args: ["onNodeSelect"] }], onNodeUnselect: [{ type: i0.Output, args: ["onNodeUnselect"] }], onNodeExpand: [{ type: i0.Output, args: ["onNodeExpand"] }], onNodeCollapse: [{ type: i0.Output, args: ["onNodeCollapse"] }], templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }], togglerIconTemplate: [{
                type: ContentChild,
                args: ['togglericon', { descendants: false }]
            }] } });
class OrganizationChartModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OrganizationChartModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: OrganizationChartModule, imports: [OrganizationChart, OrganizationChartNode, SharedModule], exports: [OrganizationChart, OrganizationChartNode, SharedModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OrganizationChartModule, imports: [OrganizationChart, OrganizationChartNode, SharedModule, SharedModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: OrganizationChartModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [OrganizationChart, OrganizationChartNode, SharedModule],
                    exports: [OrganizationChart, OrganizationChartNode, SharedModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { OrganizationChart, OrganizationChartClasses, OrganizationChartModule, OrganizationChartNode, OrganizationChartStyle };
//# sourceMappingURL=wawjs-ngx-prime-organizationchart.mjs.map
