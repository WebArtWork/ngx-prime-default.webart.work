export * from '@wawjs/ngx-prime/types/table';
import * as i0 from '@angular/core';
import { Injectable, InjectionToken, input, booleanAttribute, numberAttribute, output, viewChild, contentChildren, contentChild, inject, NgZone, effect, ContentChild, ViewEncapsulation, ChangeDetectionStrategy, Component, forwardRef, Directive, ChangeDetectorRef, ElementRef, computed, signal, NgModule } from '@angular/core';
import { style as style$1 } from '@wawjs/css-prime-styles/datatable';
import { BaseStyle } from '@wawjs/ngx-prime/base';
import { isPlatformBrowser, NgTemplateOutlet, NgStyle, NgClass, CommonModule } from '@angular/common';
import * as i2 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { isClickable, setAttribute, getAttribute, find, findSingle, appendChild, addStyle, absolutePosition } from '@wawjs/css-prime-utils';
import { PrimeTemplate, OverlayService, FilterService, FilterOperator, FilterMatchMode, TranslationKeys, SharedModule } from '@wawjs/ngx-prime/api';
import { Badge, BadgeModule } from '@wawjs/ngx-prime/badge';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind, BindModule } from '@wawjs/ngx-prime/bind';
import { Button, ButtonModule } from '@wawjs/ngx-prime/button';
import { Checkbox, CheckboxModule } from '@wawjs/ngx-prime/checkbox';
import { DatePicker, DatePickerModule } from '@wawjs/ngx-prime/datepicker';
import { DomHandler, ConnectedOverlayScrollHandler } from '@wawjs/ngx-prime/dom';
import { ArrowDownIcon } from '@wawjs/ngx-prime/icons/arrowdown';
import { ArrowUpIcon } from '@wawjs/ngx-prime/icons/arrowup';
import { FilterIcon } from '@wawjs/ngx-prime/icons/filter';
import { FilterFillIcon } from '@wawjs/ngx-prime/icons/filterfill';
import { FilterSlashIcon } from '@wawjs/ngx-prime/icons/filterslash';
import { PlusIcon } from '@wawjs/ngx-prime/icons/plus';
import { SortAltIcon } from '@wawjs/ngx-prime/icons/sortalt';
import { SortAmountDownIcon } from '@wawjs/ngx-prime/icons/sortamountdown';
import { SortAmountUpAltIcon } from '@wawjs/ngx-prime/icons/sortamountupalt';
import { SpinnerIcon } from '@wawjs/ngx-prime/icons/spinner';
import { TrashIcon } from '@wawjs/ngx-prime/icons/trash';
import { InputNumber, InputNumberModule } from '@wawjs/ngx-prime/inputnumber';
import { InputText, InputTextModule } from '@wawjs/ngx-prime/inputtext';
import { MotionDirective, MotionModule } from '@wawjs/ngx-prime/motion';
import { Paginator, PaginatorModule } from '@wawjs/ngx-prime/paginator';
import { RadioButton, RadioButtonModule } from '@wawjs/ngx-prime/radiobutton';
import { Scroller, ScrollerModule } from '@wawjs/ngx-prime/scroller';
import { Select, SelectModule } from '@wawjs/ngx-prime/select';
import { SelectButtonModule } from '@wawjs/ngx-prime/selectbutton';
import { UniqueComponentId, ObjectUtils, ZIndexUtils } from '@wawjs/ngx-prime/utils';
import { Subject } from 'rxjs';

const style = /*css*/ `
${style$1}

/* For ngx-prime */
.p-datatable-scrollable-table > .p-datatable-thead {
    top: 0;
    z-index: 2;
}

.p-datatable-scrollable-table > .p-datatable-frozen-tbody {
    position: sticky;
    z-index: 2;
}

.p-datatable-scrollable-table > .p-datatable-frozen-tbody + .p-datatable-frozen-tbody {
    z-index: 1;
}

.p-datatable-mask.p-overlay-mask {
    position: absolute;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 3;
}

.p-datatable-filter-overlay {
    position: absolute;
    background: dt('datatable.filter.overlay.select.background');
    color: dt('datatable.filter.overlay.select.color');
    border: 1px solid dt('datatable.filter.overlay.select.border.color');
    border-radius: dt('datatable.filter.overlay.select.border.radius');
    box-shadow: dt('datatable.filter.overlay.select.shadow');
    min-width: 12.5rem;
}

.p-datatable-filter-rule {
    border-bottom: 1px solid dt('datatable.filter.rule.border.color');
}

.p-datatable-filter-rule:last-child {
    border-bottom: 0 none;
}

.p-datatable-filter-add-rule-button,
.p-datatable-filter-remove-rule-button {
    width: 100%;
}

.p-datatable-filter-remove-button {
    width: 100%;
}

.p-datatable-thead > tr > th {
    padding: dt('datatable.header.cell.padding');
    background: dt('datatable.header.cell.background');
    border-color: dt('datatable.header.cell.border.color');
    border-style: solid;
    border-width: 0 0 1px 0;
    color: dt('datatable.header.cell.color');
    font-weight: dt('datatable.column.title.font.weight');
    text-align: start;
    transition:
        background dt('datatable.transition.duration'),
        color dt('datatable.transition.duration'),
        border-color dt('datatable.transition.duration'),
        outline-color dt('datatable.transition.duration'),
        box-shadow dt('datatable.transition.duration');
}

.p-datatable-thead > tr > th p-columnfilter {
    font-weight: normal;
}

.p-datatable-thead > tr > th,
.p-datatable-sort-icon,
.p-datatable-sort-badge {
    vertical-align: middle;
}

.p-datatable-thead > tr > th.p-datatable-column-sorted {
    background: dt('datatable.header.cell.selected.background');
    color: dt('datatable.header.cell.selected.color');
}

.p-datatable-thead > tr > th.p-datatable-column-sorted .p-datatable-sort-icon {
    color: dt('datatable.header.cell.selected.color');
}

.p-datatable.p-datatable-striped .p-datatable-tbody > tr:nth-child(odd) {
    background: dt('datatable.row.striped.background');
}

.p-datatable.p-datatable-striped .p-datatable-tbody > tr:nth-child(odd).p-datatable-row-selected {
    background: dt('datatable.row.selected.background');
    color: dt('datatable.row.selected.color');
}

p-sortIcon, p-sort-icon, p-sorticon {
    display: inline-flex;
    align-items: center;
    gap: dt('datatable.header.cell.gap');
}

.p-datatable .p-editable-column.p-cell-editing {
    padding: 0;
}

.p-datatable .p-editable-column.p-cell-editing p-celleditor {
    display: block;
    width: 100%;
}
`;
const classes = {
    root: ({ instance }) => [
        'p-datatable p-component',
        {
            'p-datatable-hoverable': instance.rowHover() || instance.selectionMode(),
            'p-datatable-resizable': instance.resizableColumns(),
            'p-datatable-resizable-fit': instance.resizableColumns() && instance.columnResizeMode() === 'fit',
            'p-datatable-scrollable': instance.scrollable(),
            'p-datatable-flex-scrollable': instance.scrollable() && instance.scrollHeight() === 'flex',
            'p-datatable-striped': instance.stripedRows(),
            'p-datatable-gridlines': instance.showGridlines(),
            'p-datatable-sm': instance.size() === 'small',
            'p-datatable-lg': instance.size() === 'large'
        }
    ],
    mask: 'p-datatable-mask p-overlay-mask',
    loadingIcon: 'p-datatable-loading-icon',
    header: 'p-datatable-header',
    pcPaginator: ({ instance }) => 'p-datatable-paginator-' + instance.paginatorPosition(),
    tableContainer: 'p-datatable-table-container',
    table: ({ instance }) => [
        'p-datatable-table',
        {
            'p-datatable-scrollable-table': instance.scrollable(),
            'p-datatable-resizable-table': instance.resizableColumns(),
            'p-datatable-resizable-table-fit': instance.resizableColumns() && instance.columnResizeMode() === 'fit'
        }
    ],
    thead: 'p-datatable-thead',
    columnResizer: 'p-datatable-column-resizer',
    columnHeaderContent: 'p-datatable-column-header-content',
    columnTitle: 'p-datatable-column-title',
    columnFooter: 'p-datatable-column-footer',
    sortIcon: 'p-datatable-sort-icon',
    pcSortBadge: 'p-datatable-sort-badge',
    filter: ({ instance }) => ({
        'p-datatable-filter': true,
        'p-datatable-inline-filter': instance.display() === 'row',
        'p-datatable-popover-filter': instance.display() === 'menu'
    }),
    filterElementContainer: 'p-datatable-filter-element-container',
    pcColumnFilterButton: 'p-datatable-column-filter-button',
    pcColumnFilterClearButton: 'p-datatable-column-filter-clear-button',
    filterOverlay: ({ instance }) => ({
        'p-datatable-filter-overlay p-component': true,
        'p-datatable-filter-overlay-popover': instance.display() === 'menu'
    }),
    filterConstraintList: 'p-datatable-filter-constraint-list',
    filterConstraint: ({ selected }) => ({
        'p-datatable-filter-constraint': true,
        'p-datatable-filter-constraint-selected': selected
    }),
    filterConstraintSeparator: 'p-datatable-filter-constraint-separator',
    filterOperator: 'p-datatable-filter-operator',
    pcFilterOperatorDropdown: 'p-datatable-filter-operator-dropdown',
    filterRuleList: 'p-datatable-filter-rule-list',
    filterRule: 'p-datatable-filter-rule',
    pcFilterConstraintDropdown: 'p-datatable-filter-constraint-dropdown',
    pcFilterRemoveRuleButton: 'p-datatable-filter-remove-rule-button',
    pcFilterAddRuleButton: 'p-datatable-filter-add-rule-button',
    filterButtonbar: 'p-datatable-filter-buttonbar',
    pcFilterClearButton: 'p-datatable-filter-clear-button',
    pcFilterApplyButton: 'p-datatable-filter-apply-button',
    tbody: ({ instance }) => ({
        'p-datatable-tbody': true,
        'p-datatable-frozen-tbody': instance.frozenValue() || instance.frozenBodyTemplate,
        'p-virtualscroller-content': instance.virtualScroll()
    }),
    rowGroupHeader: 'p-datatable-row-group-header',
    rowToggleButton: 'p-datatable-row-toggle-button',
    rowToggleIcon: 'p-datatable-row-toggle-icon',
    rowExpansion: 'p-datatable-row-expansion',
    rowGroupFooter: 'p-datatable-row-group-footer',
    emptyMessage: 'p-datatable-empty-message',
    bodyCell: ({ instance }) => ({
        'p-datatable-frozen-column': instance.columnProp('frozen')
    }),
    reorderableRowHandle: 'p-datatable-reorderable-row-handle',
    pcRowEditorInit: 'p-datatable-row-editor-init',
    pcRowEditorSave: 'p-datatable-row-editor-save',
    pcRowEditorCancel: 'p-datatable-row-editor-cancel',
    tfoot: 'p-datatable-tfoot',
    footerCell: ({ instance }) => ({
        'p-datatable-frozen-column': instance.columnProp('frozen')
    }),
    virtualScrollerSpacer: 'p-datatable-virtualscroller-spacer',
    footer: 'p-datatable-tfoot',
    columnResizeIndicator: 'p-datatable-column-resize-indicator',
    rowReorderIndicatorUp: 'p-datatable-row-reorder-indicator-up',
    rowReorderIndicatorDown: 'p-datatable-row-reorder-indicator-down',
    sortableColumn: ({ instance }) => ({
        'p-datatable-sortable-column': instance.isEnabled(),
        ' p-datatable-column-sorted': instance.sorted
    }),
    sortableColumnIcon: 'p-datatable-sort-icon',
    sortableColumnBadge: 'p-sortable-column-badge',
    selectableRow: ({ instance }) => ({
        'p-datatable-selectable-row': instance.isEnabled(),
        'p-datatable-row-selected': instance.selected
    }),
    resizableColumn: 'p-datatable-resizable-column',
    reorderableColumn: 'p-datatable-reorderable-column',
    rowEditorCancel: 'p-datatable-row-editor-cancel',
    frozenColumn: ({ instance }) => ({
        'p-datatable-frozen-column': instance.frozen(),
        'p-datatable-frozen-column-left': instance.alignFrozenLeft === 'left'
    }),
    contextMenuRowSelected: ({ instance }) => ({
        'p-datatable-contextmenu-row-selected': instance.selected
    })
};
const inlineStyles = {
    tableContainer: ({ instance }) => ({
        'max-height': instance.virtualScroll() ? '' : instance.scrollHeight(),
        overflow: 'auto'
    }),
    thead: { position: 'sticky' },
    tfoot: { position: 'sticky' },
    rowGroupHeader: ({ instance }) => ({
        top: instance.getFrozenRowGroupHeaderStickyPosition
    })
};
class TableStyle extends BaseStyle {
    name = 'datatable';
    style = style;
    classes = classes;
    inlineStyles = inlineStyles;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * DataTable displays data in tabular format.
 *
 * [Live Demo](https://www.ngx-prime.org/table/)
 *
 * @module tablestyle
 *
 */
var TableClasses;
(function (TableClasses) {
    /**
     * Class name of the root element
     */
    TableClasses["root"] = "p-datatable";
    /**
     * Class name of the mask element
     */
    TableClasses["mask"] = "p-datatable-mask";
    /**
     * Class name of the loading icon element
     */
    TableClasses["loadingIcon"] = "p-datatable-loading-icon";
    /**
     * Class name of the header element
     */
    TableClasses["header"] = "p-datatable-header";
    /**
     * Class name of the paginator element
     */
    TableClasses["pcPaginator"] = "p-datatable-paginator-[position]";
    /**
     * Class name of the table container element
     */
    TableClasses["tableContainer"] = "p-datatable-table-container";
    /**
     * Class name of the table element
     */
    TableClasses["table"] = "p-datatable-table";
    /**
     * Class name of the thead element
     */
    TableClasses["thead"] = "p-datatable-thead";
    /**
     * Class name of the column resizer element
     */
    TableClasses["columnResizer"] = "p-datatable-column-resizer";
    /**
     * Class name of the column header content element
     */
    TableClasses["columnHeaderContent"] = "p-datatable-column-header-content";
    /**
     * Class name of the column title element
     */
    TableClasses["columnTitle"] = "p-datatable-column-title";
    /**
     * Class name of the sort icon element
     */
    TableClasses["sortIcon"] = "p-datatable-sort-icon";
    /**
     * Class name of the sort badge element
     */
    TableClasses["pcSortBadge"] = "p-datatable-sort-badge";
    /**
     * Class name of the filter element
     */
    TableClasses["filter"] = "p-datatable-filter";
    /**
     * Class name of the filter element container element
     */
    TableClasses["filterElementContainer"] = "p-datatable-filter-element-container";
    /**
     * Class name of the column filter button element
     */
    TableClasses["pcColumnFilterButton"] = "p-datatable-column-filter-button";
    /**
     * Class name of the column filter clear button element
     */
    TableClasses["pcColumnFilterClearButton"] = "p-datatable-column-filter-clear-button";
    /**
     * Class name of the filter overlay element
     */
    TableClasses["filterOverlay"] = "p-datatable-filter-overlay";
    /**
     * Class name of the filter constraint list element
     */
    TableClasses["filterConstraintList"] = "p-datatable-filter-constraint-list";
    /**
     * Class name of the filter constraint element
     */
    TableClasses["filterConstraint"] = "p-datatable-filter-constraint";
    /**
     * Class name of the filter constraint separator element
     */
    TableClasses["filterConstraintSeparator"] = "p-datatable-filter-constraint-separator";
    /**
     * Class name of the filter operator element
     */
    TableClasses["filterOperator"] = "p-datatable-filter-operator";
    /**
     * Class name of the filter operator dropdown element
     */
    TableClasses["pcFilterOperatorDropdown"] = "p-datatable-filter-operator-dropdown";
    /**
     * Class name of the filter rule list element
     */
    TableClasses["filterRuleList"] = "p-datatable-filter-rule-list";
    /**
     * Class name of the filter rule element
     */
    TableClasses["filterRule"] = "p-datatable-filter-rule";
    /**
     * Class name of the filter constraint dropdown element
     */
    TableClasses["pcFilterConstraintDropdown"] = "p-datatable-filter-constraint-dropdown";
    /**
     * Class name of the filter remove rule button element
     */
    TableClasses["pcFilterRemoveRuleButton"] = "p-datatable-filter-remove-rule-button";
    /**
     * Class name of the filter add rule button element
     */
    TableClasses["pcFilterAddRuleButton"] = "p-datatable-filter-add-rule-button";
    /**
     * Class name of the filter buttonbar element
     */
    TableClasses["filterButtonbar"] = "p-datatable-filter-buttonbar";
    /**
     * Class name of the filter clear button element
     */
    TableClasses["pcFilterClearButton"] = "p-datatable-filter-clear-button";
    /**
     * Class name of the filter apply button element
     */
    TableClasses["pcFilterApplyButton"] = "p-datatable-filter-apply-button";
    /**
     * Class name of the tbody element
     */
    TableClasses["tbody"] = "p-datatable-tbody";
    /**
     * Class name of the row group header element
     */
    TableClasses["rowGroupHeader"] = "p-datatable-row-group-header";
    /**
     * Class name of the row toggle button element
     */
    TableClasses["rowToggleButton"] = "p-datatable-row-toggle-button";
    /**
     * Class name of the row toggle icon element
     */
    TableClasses["rowToggleIcon"] = "p-datatable-row-toggle-icon";
    /**
     * Class name of the row expansion element
     */
    TableClasses["rowExpansion"] = "p-datatable-row-expansion";
    /**
     * Class name of the row group footer element
     */
    TableClasses["rowGroupFooter"] = "p-datatable-row-group-footer";
    /**
     * Class name of the empty message element
     */
    TableClasses["emptyMessage"] = "p-datatable-empty-message";
    /**
     * Class name of the reorderable row handle element
     */
    TableClasses["reorderableRowHandle"] = "p-datatable-reorderable-row-handle";
    /**
     * Class name of the row editor init element
     */
    TableClasses["pcRowEditorInit"] = "p-datatable-row-editor-init";
    /**
     * Class name of the row editor save element
     */
    TableClasses["pcRowEditorSave"] = "p-datatable-row-editor-save";
    /**
     * Class name of the row editor cancel element
     */
    TableClasses["pcRowEditorCancel"] = "p-datatable-row-editor-cancel";
    /**
     * Class name of the tfoot element
     */
    TableClasses["tfoot"] = "p-datatable-tfoot";
    /**
     * Class name of the virtual scroller spacer element
     */
    TableClasses["virtualScrollerSpacer"] = "p-datatable-virtualscroller-spacer";
    /**
     * Class name of the footer element
     */
    TableClasses["footer"] = "p-datatable-footer";
    /**
     * Class name of the column resize indicator element
     */
    TableClasses["columnResizeIndicator"] = "p-datatable-column-resize-indicator";
    /**
     * Class name of the row reorder indicator up element
     */
    TableClasses["rowReorderIndicatorUp"] = "p-datatable-row-reorder-indicator-up";
    /**
     * Class name of the row reorder indicator down element
     */
    TableClasses["rowReorderIndicatorDown"] = "p-datatable-row-reorder-indicator-down";
    /**
     * Class name of the sortable column element
     */
    TableClasses["sortableColumn"] = "p-datatable-sortable-column";
    /**
     * Class name of the sortable column icon element
     */
    TableClasses["sortableColumnIcon"] = "p-sortable-column-icon";
    /**
     * Class name of the sortable column badge element
     */
    TableClasses["sortableColumnBadge"] = "p-sortable-column-badge";
    /**
     * Class name of the selectable row element
     */
    TableClasses["selectableRow"] = "p-datatable-selectable-row";
    /**
     * Class name of the resizable column element
     */
    TableClasses["resizableColumn"] = "p-datatable-resizable-column";
    /**
     * Class name of the frozen column element
     */
    TableClasses["frozenColumn"] = "p-datatable-frozen-column";
    /**
     * Class name of the contextmenu row selected element
     */
    TableClasses["contextMenuRowSelected"] = "p-datatable-contextmenu-row-selected";
})(TableClasses || (TableClasses = {}));

const TABLE_INSTANCE = new InjectionToken('TABLE_INSTANCE');
class TableService {
    sortSource = new Subject();
    selectionSource = new Subject();
    contextMenuSource = new Subject();
    valueSource = new Subject();
    columnsSource = new Subject();
    sortSource$ = this.sortSource.asObservable();
    selectionSource$ = this.selectionSource.asObservable();
    contextMenuSource$ = this.contextMenuSource.asObservable();
    valueSource$ = this.valueSource.asObservable();
    columnsSource$ = this.columnsSource.asObservable();
    onSort(sortMeta) {
        this.sortSource.next(sortMeta);
    }
    onSelectionChange() {
        this.selectionSource.next(null);
    }
    onContextMenu(data) {
        this.contextMenuSource.next(data);
    }
    onValueChange(value) {
        this.valueSource.next(value);
    }
    onColumnsChange(columns) {
        this.columnsSource.next(columns);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableService, decorators: [{
            type: Injectable
        }] });
/**
 * Table displays data in tabular format.
 * @group Components
 */
class Table extends BaseComponent {
    componentName = 'DataTable';
    /**
     * An array of objects to represent dynamic columns that are frozen.
     * @group Props
     */
    frozenColumns = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "frozenColumns" }] : /* istanbul ignore next */ []));
    /**
     * An array of objects to display as frozen.
     * @group Props
     */
    frozenValue = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "frozenValue" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Inline style of the table.
     * @group Props
     */
    tableStyle = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "tableStyle" }] : /* istanbul ignore next */ []));
    /**
     * Style class of the table.
     * @group Props
     */
    tableStyleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "tableStyleClass" }] : /* istanbul ignore next */ []));
    /**
     * When specified as true, enables the pagination.
     * @group Props
     */
    paginator = input(undefined, { ...(ngDevMode ? { debugName: "paginator" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Number of page links to display in paginator.
     * @group Props
     */
    pageLinks = input(5, { ...(ngDevMode ? { debugName: "pageLinks" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Array of integer/object values to display inside rows per page dropdown of paginator
     * @group Props
     */
    rowsPerPageOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "rowsPerPageOptions" }] : /* istanbul ignore next */ []));
    /**
     * Whether to show it even there is only one page.
     * @group Props
     */
    alwaysShowPaginator = input(true, { ...(ngDevMode ? { debugName: "alwaysShowPaginator" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Position of the paginator, options are "top", "bottom" or "both".
     * @group Props
     */
    paginatorPosition = input('bottom', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "paginatorPosition" }] : /* istanbul ignore next */ []));
    /**
     * Custom style class for paginator
     * @group Props
     */
    paginatorStyleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "paginatorStyleClass" }] : /* istanbul ignore next */ []));
    /**
     * Target element to attach the paginator dropdown overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @group Props
     */
    paginatorDropdownAppendTo = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "paginatorDropdownAppendTo" }] : /* istanbul ignore next */ []));
    /**
     * Paginator dropdown height of the viewport in pixels, a scrollbar is defined if height of list exceeds this value.
     * @group Props
     */
    paginatorDropdownScrollHeight = input('200px', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "paginatorDropdownScrollHeight" }] : /* istanbul ignore next */ []));
    /**
     * Template of the current page report element. Available placeholders are {currentPage},{totalPages},{rows},{first},{last} and {totalRecords}
     * @group Props
     */
    currentPageReportTemplate = input('{currentPage} of {totalPages}', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentPageReportTemplate" }] : /* istanbul ignore next */ []));
    /**
     * Whether to display current page report.
     * @group Props
     */
    showCurrentPageReport = input(undefined, { ...(ngDevMode ? { debugName: "showCurrentPageReport" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to display a dropdown to navigate to any page.
     * @group Props
     */
    showJumpToPageDropdown = input(undefined, { ...(ngDevMode ? { debugName: "showJumpToPageDropdown" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to display a input to navigate to any page.
     * @group Props
     */
    showJumpToPageInput = input(undefined, { ...(ngDevMode ? { debugName: "showJumpToPageInput" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * When enabled, icons are displayed on paginator to go first and last page.
     * @group Props
     */
    showFirstLastIcon = input(true, { ...(ngDevMode ? { debugName: "showFirstLastIcon" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to show page links.
     * @group Props
     */
    showPageLinks = input(true, { ...(ngDevMode ? { debugName: "showPageLinks" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Sort order to use when an unsorted column gets sorted by user interaction.
     * @group Props
     */
    defaultSortOrder = input(1, { ...(ngDevMode ? { debugName: "defaultSortOrder" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Defines whether sorting works on single column or on multiple columns.
     * @group Props
     */
    sortMode = input('single', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sortMode" }] : /* istanbul ignore next */ []));
    /**
     * When true, resets paginator to first page after sorting. Available only when sortMode is set to single.
     * @group Props
     */
    resetPageOnSort = input(true, { ...(ngDevMode ? { debugName: "resetPageOnSort" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Specifies the selection mode, valid values are "single" and "multiple".
     * @group Props
     */
    selectionMode = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "selectionMode" }] : /* istanbul ignore next */ []));
    /**
     * When enabled with paginator and checkbox selection mode, the select all checkbox in the header will select all rows on the current page.
     * @group Props
     */
    selectionPageOnly = input(undefined, { ...(ngDevMode ? { debugName: "selectionPageOnly" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Selected row with a context menu.
     * @group Props
     */
    contextMenuSelection = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "contextMenuSelection" }] : /* istanbul ignore next */ []));
    /**
     * Callback to invoke on context menu selection change.
     * @param {*} object - row data.
     * @group Emits
     */
    contextMenuSelectionChange = output();
    /**
     *  Defines the behavior of context menu selection, in "separate" mode context menu updates contextMenuSelection property whereas in joint mode selection property is used instead so that when row selection is enabled, both row selection and context menu selection use the same property.
     * @group Props
     */
    contextMenuSelectionMode = input('separate', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "contextMenuSelectionMode" }] : /* istanbul ignore next */ []));
    /**
     * A property to uniquely identify a record in data.
     * @group Props
     */
    dataKey = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "dataKey" }] : /* istanbul ignore next */ []));
    /**
     * Defines whether metaKey should be considered for the selection. On touch enabled devices, metaKeySelection is turned off automatically.
     * @group Props
     */
    metaKeySelection = input(false, { ...(ngDevMode ? { debugName: "metaKeySelection" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Defines if the row is selectable.
     * @group Props
     */
    rowSelectable = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rowSelectable" }] : /* istanbul ignore next */ []));
    /**
     * Function to optimize the dom operations by delegating to ngForTrackBy, default algorithm checks for object identity.
     * @group Props
     */
    rowTrackBy = input((index, item) => item, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rowTrackBy" }] : /* istanbul ignore next */ []));
    /**
     * Defines if data is loaded and interacted with in lazy manner.
     * @group Props
     */
    lazy = input(false, { ...(ngDevMode ? { debugName: "lazy" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to call lazy loading on initialization.
     * @group Props
     */
    lazyLoadOnInit = input(true, { ...(ngDevMode ? { debugName: "lazyLoadOnInit" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Algorithm to define if a row is selected, valid values are "equals" that compares by reference and "deepEquals" that compares all fields.
     * @group Props
     */
    compareSelectionBy = input('deepEquals', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "compareSelectionBy" }] : /* istanbul ignore next */ []));
    /**
     * Character to use as the csv separator.
     * @group Props
     */
    csvSeparator = input(',', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "csvSeparator" }] : /* istanbul ignore next */ []));
    /**
     * Name of the exported file.
     * @group Props
     */
    exportFilename = input('download', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "exportFilename" }] : /* istanbul ignore next */ []));
    /**
     * An array of FilterMetadata objects to provide external filters.
     * @group Props
     */
    filters = input({}, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filters" }] : /* istanbul ignore next */ []));
    /**
     * An array of fields as string to use in global filtering.
     * @group Props
     */
    globalFilterFields = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "globalFilterFields" }] : /* istanbul ignore next */ []));
    /**
     * Delay in milliseconds before filtering the data.
     * @group Props
     */
    filterDelay = input(300, { ...(ngDevMode ? { debugName: "filterDelay" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Locale to use in filtering. The default locale is the host environment's current locale.
     * @group Props
     */
    filterLocale = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "filterLocale" }] : /* istanbul ignore next */ []));
    /**
     * Map instance to keep the expanded rows where key of the map is the data key of the row.
     * @group Props
     */
    expandedRowKeys = input({}, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "expandedRowKeys" }] : /* istanbul ignore next */ []));
    /**
     * Map instance to keep the rows being edited where key of the map is the data key of the row.
     * @group Props
     */
    editingRowKeys = input({}, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "editingRowKeys" }] : /* istanbul ignore next */ []));
    /**
     * Whether multiple rows can be expanded at any time. Valid values are "multiple" and "single".
     * @group Props
     */
    rowExpandMode = input('multiple', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "rowExpandMode" }] : /* istanbul ignore next */ []));
    /**
     * Enables scrollable tables.
     * @group Props
     */
    scrollable = input(undefined, { ...(ngDevMode ? { debugName: "scrollable" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Type of the row grouping, valid values are "subheader" and "rowspan".
     * @group Props
     */
    rowGroupMode = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "rowGroupMode" }] : /* istanbul ignore next */ []));
    /**
     * Height of the scroll viewport in fixed pixels or the "flex" keyword for a dynamic size.
     * @group Props
     */
    scrollHeight = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "scrollHeight" }] : /* istanbul ignore next */ []));
    /**
     * Whether the data should be loaded on demand during scroll.
     * @group Props
     */
    virtualScroll = input(undefined, { ...(ngDevMode ? { debugName: "virtualScroll" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Height of a row to use in calculations of virtual scrolling.
     * @group Props
     */
    virtualScrollItemSize = input(undefined, { ...(ngDevMode ? { debugName: "virtualScrollItemSize" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Whether to use the scroller feature. The properties of scroller component can be used like an object in it.
     * @group Props
     */
    virtualScrollOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "virtualScrollOptions" }] : /* istanbul ignore next */ []));
    /**
     * Threshold in milliseconds to delay lazy loading during scrolling.
     * @group Props
     */
    virtualScrollDelay = input(250, { ...(ngDevMode ? { debugName: "virtualScrollDelay" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Width of the frozen columns container.
     * @group Props
     */
    frozenWidth = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "frozenWidth" }] : /* istanbul ignore next */ []));
    /**
     * Local ng-template varilable of a ContextMenu.
     * @group Props
     */
    contextMenu = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "contextMenu" }] : /* istanbul ignore next */ []));
    /**
     * When enabled, columns can be resized using drag and drop.
     * @group Props
     */
    resizableColumns = input(undefined, { ...(ngDevMode ? { debugName: "resizableColumns" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Defines whether the overall table width should change on column resize, valid values are "fit" and "expand".
     * @group Props
     */
    columnResizeMode = input('fit', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "columnResizeMode" }] : /* istanbul ignore next */ []));
    /**
     * When enabled, columns can be reordered using drag and drop.
     * @group Props
     */
    reorderableColumns = input(undefined, { ...(ngDevMode ? { debugName: "reorderableColumns" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Displays a loader to indicate data load is in progress.
     * @group Props
     */
    loading = input(undefined, { ...(ngDevMode ? { debugName: "loading" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * The icon to show while indicating data load is in progress.
     * @group Props
     */
    loadingIcon = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "loadingIcon" }] : /* istanbul ignore next */ []));
    /**
     * Whether to show the loading mask when loading property is true.
     * @group Props
     */
    showLoader = input(true, { ...(ngDevMode ? { debugName: "showLoader" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Adds hover effect to rows without the need for selectionMode. Note that tr elements that can be hovered need to have "p-selectable-row" class for rowHover to work.
     * @group Props
     */
    rowHover = input(undefined, { ...(ngDevMode ? { debugName: "rowHover" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to use the default sorting or a custom one using sortFunction.
     * @group Props
     */
    customSort = input(undefined, { ...(ngDevMode ? { debugName: "customSort" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to use the initial sort badge or not.
     * @group Props
     */
    showInitialSortBadge = input(true, { ...(ngDevMode ? { debugName: "showInitialSortBadge" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Export function.
     * @group Props
     */
    exportFunction = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "exportFunction" }] : /* istanbul ignore next */ []));
    /**
     * Custom export header of the column to be exported as CSV.
     * @group Props
     */
    exportHeader = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "exportHeader" }] : /* istanbul ignore next */ []));
    /**
     * Unique identifier of a stateful table to use in state storage.
     * @group Props
     */
    stateKey = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "stateKey" }] : /* istanbul ignore next */ []));
    /**
     * Defines where a stateful table keeps its state, valid values are "session" for sessionStorage and "local" for localStorage.
     * @group Props
     */
    stateStorage = input('session', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "stateStorage" }] : /* istanbul ignore next */ []));
    /**
     * Defines the editing mode, valid values are "cell" and "row".
     * @group Props
     */
    editMode = input('cell', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "editMode" }] : /* istanbul ignore next */ []));
    /**
     * Field name to use in row grouping.
     * @group Props
     */
    groupRowsBy = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "groupRowsBy" }] : /* istanbul ignore next */ []));
    /**
     * Defines the size of the table.
     * @group Props
     */
    size = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "size" }] : /* istanbul ignore next */ []));
    /**
     * Whether to show grid lines between cells.
     * @group Props
     */
    showGridlines = input(undefined, { ...(ngDevMode ? { debugName: "showGridlines" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Whether to display rows with alternating colors.
     * @group Props
     */
    stripedRows = input(undefined, { ...(ngDevMode ? { debugName: "stripedRows" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Order to sort when default row grouping is enabled.
     * @group Props
     */
    groupRowsByOrder = input(1, { ...(ngDevMode ? { debugName: "groupRowsByOrder" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Defines the responsive mode, valid options are "stack" and "scroll".
     * @deprecated since v20.0.0, always defaults to scroll, stack mode needs custom implementation
     * @group Props
     */
    responsiveLayout = input('scroll', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "responsiveLayout" }] : /* istanbul ignore next */ []));
    /**
     * The breakpoint to define the maximum width boundary when using stack responsive layout.
     * @group Props
     */
    breakpoint = input('960px', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "breakpoint" }] : /* istanbul ignore next */ []));
    /**
     * Locale to be used in paginator formatting.
     * @group Props
     */
    paginatorLocale = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "paginatorLocale" }] : /* istanbul ignore next */ []));
    /**
     * An array of objects to display.
     * @group Props
     */
    value = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "value" }] : /* istanbul ignore next */ []));
    /**
     * An array of objects to represent dynamic columns.
     * @group Props
     */
    columns = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "columns" }] : /* istanbul ignore next */ []));
    /**
     * Index of the first row to be displayed.
     * @group Props
     */
    first = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "first" }] : /* istanbul ignore next */ []));
    /**
     * Number of rows to display per page.
     * @group Props
     */
    rows = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "rows" }] : /* istanbul ignore next */ []));
    /**
     * Number of total records, defaults to length of value when not defined.
     * @group Props
     */
    totalRecords = input(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "totalRecords" }] : /* istanbul ignore next */ []));
    /**
     * Name of the field to sort data by default.
     * @group Props
     */
    sortField = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "sortField" }] : /* istanbul ignore next */ []));
    /**
     * Order to sort when default sorting is enabled.
     * @group Props
     */
    sortOrder = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "sortOrder" }] : /* istanbul ignore next */ []));
    /**
     * An array of SortMeta objects to sort the data by default in multiple sort mode.
     * @group Props
     */
    multiSortMeta = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "multiSortMeta" }] : /* istanbul ignore next */ []));
    /**
     * Selected row in single mode or an array of values in multiple mode.
     * @group Props
     */
    selection = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "selection" }] : /* istanbul ignore next */ []));
    /**
     * Whether all data is selected.
     * @group Props
     */
    selectAll = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "selectAll" }] : /* istanbul ignore next */ []));
    /**
     * Emits when the all of the items selected or unselected.
     * @param {TableSelectAllChangeEvent} event - custom  all selection change event.
     * @group Emits
     */
    selectAllChange = output();
    /**
     * Callback to invoke on selection changed.
     * @param {any | null} value - selected data.
     * @group Emits
     */
    selectionChange = output();
    /**
     * Callback to invoke when a row is selected.
     * @param {TableRowSelectEvent} event - custom select event.
     * @group Emits
     */
    onRowSelect = output();
    /**
     * Callback to invoke when a row is unselected.
     * @param {TableRowUnSelectEvent} event - custom unselect event.
     * @group Emits
     */
    onRowUnselect = output();
    /**
     * Callback to invoke when pagination occurs.
     * @param {TablePageEvent} event - custom pagination event.
     * @group Emits
     */
    onPage = output();
    /**
     * Callback to invoke when a column gets sorted.
     * @param {Object} object - sort meta.
     * @group Emits
     */
    onSort = output();
    /**
     * Callback to invoke when data is filtered.
     * @param {TableFilterEvent} event - custom filtering event.
     * @group Emits
     */
    onFilter = output();
    /**
     * Callback to invoke when paging, sorting or filtering happens in lazy mode.
     * @param {TableLazyLoadEvent} event - custom lazy loading event.
     * @group Emits
     */
    onLazyLoad = output();
    /**
     * Callback to invoke when a row is expanded.
     * @param {TableRowExpandEvent} event - custom row expand event.
     * @group Emits
     */
    onRowExpand = output();
    /**
     * Callback to invoke when a row is collapsed.
     * @param {TableRowCollapseEvent} event - custom row collapse event.
     * @group Emits
     */
    onRowCollapse = output();
    /**
     * Callback to invoke when a row is selected with right click.
     * @param {TableContextMenuSelectEvent} event - custom context menu select event.
     * @group Emits
     */
    onContextMenuSelect = output();
    /**
     * Callback to invoke when a column is resized.
     * @param {TableColResizeEvent} event - custom column resize event.
     * @group Emits
     */
    onColResize = output();
    /**
     * Callback to invoke when a column is reordered.
     * @param {TableColumnReorderEvent} event - custom column reorder event.
     * @group Emits
     */
    onColReorder = output();
    /**
     * Callback to invoke when a row is reordered.
     * @param {TableRowReorderEvent} event - custom row reorder event.
     * @group Emits
     */
    onRowReorder = output();
    /**
     * Callback to invoke when a cell switches to edit mode.
     * @param {TableEditInitEvent} event - custom edit init event.
     * @group Emits
     */
    onEditInit = output();
    /**
     * Callback to invoke when cell edit is completed.
     * @param {TableEditCompleteEvent} event - custom edit complete event.
     * @group Emits
     */
    onEditComplete = output();
    /**
     * Callback to invoke when cell edit is cancelled with escape key.
     * @param {TableEditCancelEvent} event - custom edit cancel event.
     * @group Emits
     */
    onEditCancel = output();
    /**
     * Callback to invoke when state of header checkbox changes.
     * @param {TableHeaderCheckboxToggleEvent} event - custom header checkbox event.
     * @group Emits
     */
    onHeaderCheckboxToggle = output();
    /**
     * A function to implement custom sorting, refer to sorting section for details.
     * @param {any} any - sort meta.
     * @group Emits
     */
    sortFunction = output();
    /**
     * Callback to invoke on pagination.
     * @param {number} number - first element.
     * @group Emits
     */
    firstChange = output();
    /**
     * Callback to invoke on rows change.
     * @param {number} number - Row count.
     * @group Emits
     */
    rowsChange = output();
    /**
     * Callback to invoke table state is saved.
     * @param {TableState} object - table state.
     * @group Emits
     */
    onStateSave = output();
    /**
     * Callback to invoke table state is restored.
     * @param {TableState} object - table state.
     * @group Emits
     */
    onStateRestore = output();
    resizeHelperViewChild = viewChild('resizeHelper', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "resizeHelperViewChild" }] : /* istanbul ignore next */ []));
    reorderIndicatorUpViewChild = viewChild('reorderIndicatorUp', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "reorderIndicatorUpViewChild" }] : /* istanbul ignore next */ []));
    reorderIndicatorDownViewChild = viewChild('reorderIndicatorDown', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "reorderIndicatorDownViewChild" }] : /* istanbul ignore next */ []));
    wrapperViewChild = viewChild('wrapper', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "wrapperViewChild" }] : /* istanbul ignore next */ []));
    tableViewChild = viewChild('table', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tableViewChild" }] : /* istanbul ignore next */ []));
    tableHeaderViewChild = viewChild('thead', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tableHeaderViewChild" }] : /* istanbul ignore next */ []));
    tableFooterViewChild = viewChild('tfoot', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "tableFooterViewChild" }] : /* istanbul ignore next */ []));
    scroller = viewChild('scroller', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "scroller" }] : /* istanbul ignore next */ []));
    _templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_templates" }] : /* istanbul ignore next */ []));
    _value = [];
    _columns;
    _totalRecords = 0;
    _first = 0;
    _rows;
    filteredValue;
    // @todo will be refactored later
    _headerTemplate = contentChild('header', { ...(ngDevMode ? { debugName: "_headerTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    headerTemplate;
    _headerGroupedTemplate = contentChild('headergrouped', { ...(ngDevMode ? { debugName: "_headerGroupedTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    headerGroupedTemplate;
    _bodyTemplate = contentChild('body', { ...(ngDevMode ? { debugName: "_bodyTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    bodyTemplate;
    _loadingBodyTemplate = contentChild('loadingbody', { ...(ngDevMode ? { debugName: "_loadingBodyTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    loadingBodyTemplate;
    _captionTemplate;
    captionTemplate;
    _footerTemplate;
    footerTemplate;
    _footerGroupedTemplate;
    footerGroupedTemplate;
    _summaryTemplate;
    summaryTemplate;
    _colGroupTemplate = contentChild('colgroup', { ...(ngDevMode ? { debugName: "_colGroupTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    colGroupTemplate;
    _expandedRowTemplate;
    expandedRowTemplate;
    _groupHeaderTemplate;
    groupHeaderTemplate;
    _groupFooterTemplate;
    groupFooterTemplate;
    _frozenExpandedRowTemplate;
    frozenExpandedRowTemplate;
    _frozenHeaderTemplate = contentChild('frozenheader', { ...(ngDevMode ? { debugName: "_frozenHeaderTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    frozenHeaderTemplate;
    _frozenBodyTemplate;
    frozenBodyTemplate;
    _frozenFooterTemplate = contentChild('frozenfooter', { ...(ngDevMode ? { debugName: "_frozenFooterTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    frozenFooterTemplate;
    _frozenColGroupTemplate = contentChild('frozencolgroup', { ...(ngDevMode ? { debugName: "_frozenColGroupTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    frozenColGroupTemplate;
    _emptyMessageTemplate = contentChild('emptymessage', { ...(ngDevMode ? { debugName: "_emptyMessageTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    emptyMessageTemplate;
    _paginatorLeftTemplate = contentChild('paginatorleft', { ...(ngDevMode ? { debugName: "_paginatorLeftTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    paginatorLeftTemplate;
    _paginatorRightTemplate = contentChild('paginatorright', { ...(ngDevMode ? { debugName: "_paginatorRightTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    paginatorRightTemplate;
    _paginatorDropdownItemTemplate = contentChild('paginatordropdownitem', { ...(ngDevMode ? { debugName: "_paginatorDropdownItemTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    paginatorDropdownItemTemplate;
    _loadingIconTemplate;
    loadingIconTemplate;
    _reorderIndicatorUpIconTemplate = contentChild('reorderindicatorupicon', { ...(ngDevMode ? { debugName: "_reorderIndicatorUpIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    reorderIndicatorUpIconTemplate;
    _reorderIndicatorDownIconTemplate = contentChild('reorderindicatordownicon', { ...(ngDevMode ? { debugName: "_reorderIndicatorDownIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    reorderIndicatorDownIconTemplate;
    _sortIconTemplate;
    sortIconTemplate;
    _checkboxIconTemplate = contentChild('checkboxicon', { ...(ngDevMode ? { debugName: "_checkboxIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    checkboxIconTemplate;
    _headerCheckboxIconTemplate = contentChild('headercheckboxicon', { ...(ngDevMode ? { debugName: "_headerCheckboxIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    headerCheckboxIconTemplate;
    _paginatorDropdownIconTemplate;
    paginatorDropdownIconTemplate;
    _paginatorFirstPageLinkIconTemplate;
    paginatorFirstPageLinkIconTemplate;
    _paginatorLastPageLinkIconTemplate;
    paginatorLastPageLinkIconTemplate;
    _paginatorPreviousPageLinkIconTemplate;
    paginatorPreviousPageLinkIconTemplate;
    _paginatorNextPageLinkIconTemplate;
    paginatorNextPageLinkIconTemplate;
    selectionKeys = {};
    lastResizerHelperX;
    reorderIconWidth;
    reorderIconHeight;
    draggedColumn;
    draggedRowIndex;
    droppedRowIndex;
    rowDragging;
    dropPosition;
    editingCell;
    editingCellData;
    editingCellField;
    editingCellRowIndex;
    selfClick;
    documentEditListener;
    _multiSortMeta;
    _sortField;
    _sortOrder = 1;
    preventSelectionSetterPropagation;
    _selection;
    _selectAll = null;
    _contextMenuSelection;
    _filters = {};
    _expandedRowKeys = {};
    anchorRowIndex;
    rangeRowIndex;
    filterTimeout;
    initialized;
    rowTouched;
    restoringSort;
    restoringFilter;
    stateRestored;
    columnOrderStateRestored;
    columnWidthsState;
    tableWidthState;
    overlaySubscription;
    resizeColumnElement;
    columnResizing = false;
    rowGroupHeaderStyleObject = {};
    id = UniqueComponentId();
    styleElement;
    responsiveStyleElement;
    overlayService = inject(OverlayService);
    filterService = inject(FilterService);
    tableService = inject(TableService);
    zone = inject(NgZone);
    _componentStyle = inject(TableStyle);
    bindDirectiveInstance = inject(Bind, { self: true });
    _totalRecordsSynced = false;
    _prevValue;
    _prevColumns;
    _prevSortField;
    _prevSortOrder;
    _prevMultiSortMeta;
    _prevSelection;
    _prevSelectAll;
    constructor() {
        super();
        effect(() => {
            const totalRecords = this.totalRecords();
            if (!this._totalRecordsSynced) {
                this._totalRecordsSynced = true;
                this._totalRecords = totalRecords;
            }
        });
        effect(() => {
            this._first = this.first();
        });
        effect(() => {
            this._rows = this.rows();
        });
        effect(() => {
            this._contextMenuSelection = this.contextMenuSelection();
        });
        effect(() => {
            this._filters = this.filters();
        });
        effect(() => {
            this._expandedRowKeys = this.expandedRowKeys();
        });
        effect(() => {
            const value = this.value();
            const columns = this.columns();
            const sortField = this.sortField();
            const sortOrder = this.sortOrder();
            const multiSortMeta = this.multiSortMeta();
            const selection = this.selection();
            const selectAll = this.selectAll();
            const valueChanged = this._prevValue !== value;
            const columnsChanged = this._prevColumns !== columns;
            const sortFieldChanged = this._prevSortField !== sortField;
            const sortOrderChanged = this._prevSortOrder !== sortOrder;
            const multiSortMetaChanged = this._prevMultiSortMeta !== multiSortMeta;
            const selectionChanged = this._prevSelection !== selection;
            const selectAllChanged = this._prevSelectAll !== selectAll;
            const lazy = this.lazy();
            if (valueChanged) {
                if (this.isStateful() && !this.stateRestored && isPlatformBrowser(this.platformId)) {
                    this.restoreState();
                }
                this._value = value;
                if (!lazy) {
                    this._totalRecords = this._totalRecords === 0 && this._value ? this._value.length : (this._totalRecords ?? 0);
                    const sortMode = this.sortMode();
                    const groupRowsBy = this.groupRowsBy();
                    if (sortMode == 'single' && (this._sortField || groupRowsBy))
                        this.sortSingle();
                    else if (sortMode == 'multiple' && (this._multiSortMeta || groupRowsBy))
                        this.sortMultiple();
                    else if (this.hasFilter())
                        //sort already filters
                        this._filter();
                }
                this.tableService.onValueChange(value);
            }
            if (columnsChanged) {
                if (!this.isStateful()) {
                    this._columns = columns;
                    this.tableService.onColumnsChange(columns);
                }
                if (this._columns && this.isStateful() && this.reorderableColumns() && !this.columnOrderStateRestored) {
                    this.restoreColumnOrder();
                    this.tableService.onColumnsChange(this._columns);
                }
            }
            const sortMode = this.sortMode();
            if (sortFieldChanged) {
                this._sortField = sortField;
                //avoid triggering lazy load prior to lazy initialization at onInit
                if (!lazy || this.initialized) {
                    if (sortMode === 'single') {
                        this.sortSingle();
                    }
                }
            }
            if (sortOrderChanged) {
                this._sortOrder = sortOrder;
                //avoid triggering lazy load prior to lazy initialization at onInit
                if (!lazy || this.initialized) {
                    if (sortMode === 'single') {
                        this.sortSingle();
                    }
                }
            }
            if (multiSortMetaChanged) {
                this._multiSortMeta = multiSortMeta;
                if (sortMode === 'multiple' && (this.initialized || (!lazy && !this.virtualScroll()))) {
                    this.sortMultiple();
                }
            }
            if (selectionChanged) {
                this._selection = selection;
                if (!this.preventSelectionSetterPropagation) {
                    this.updateSelectionKeys();
                    this.tableService.onSelectionChange();
                }
                this.preventSelectionSetterPropagation = false;
            }
            if (selectAllChanged) {
                this._selectAll = selectAll;
                if (!this.preventSelectionSetterPropagation) {
                    this.updateSelectionKeys();
                    this.tableService.onSelectionChange();
                    if (this.isStateful()) {
                        this.saveState();
                    }
                }
                this.preventSelectionSetterPropagation = false;
            }
            this._prevValue = value;
            this._prevColumns = columns;
            this._prevSortField = sortField;
            this._prevSortOrder = sortOrder;
            this._prevMultiSortMeta = multiSortMeta;
            this._prevSelection = selection;
            this._prevSelectAll = selectAll;
        });
    }
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    onInit() {
        if (this.lazy() && this.lazyLoadOnInit()) {
            if (!this.virtualScroll()) {
                this.onLazyLoad.emit(this.createLazyLoadMetadata());
            }
            if (this.restoringFilter) {
                this.restoringFilter = false;
            }
        }
        if (this.responsiveLayout() === 'stack') {
            this.createResponsiveStyle();
        }
        this.initialized = true;
    }
    onAfterContentInit() {
        this._templates().forEach((item) => {
            switch (item.getType()) {
                case 'caption':
                    this.captionTemplate = item.template;
                    break;
                case 'header':
                    this.headerTemplate = item.template;
                    break;
                case 'headergrouped':
                    this.headerGroupedTemplate = item.template;
                    break;
                case 'body':
                    this.bodyTemplate = item.template;
                    break;
                case 'loadingbody':
                    this.loadingBodyTemplate = item.template;
                    break;
                case 'footer':
                    this.footerTemplate = item.template;
                    break;
                case 'footergrouped':
                    this.footerGroupedTemplate = item.template;
                    break;
                case 'summary':
                    this.summaryTemplate = item.template;
                    break;
                case 'colgroup':
                    this.colGroupTemplate = item.template;
                    break;
                case 'expandedrow':
                    this.expandedRowTemplate = item.template;
                    break;
                case 'groupheader':
                    this.groupHeaderTemplate = item.template;
                    break;
                case 'groupfooter':
                    this.groupFooterTemplate = item.template;
                    break;
                case 'frozenheader':
                    this.frozenHeaderTemplate = item.template;
                    break;
                case 'frozenbody':
                    this.frozenBodyTemplate = item.template;
                    break;
                case 'frozenfooter':
                    this.frozenFooterTemplate = item.template;
                    break;
                case 'frozencolgroup':
                    this.frozenColGroupTemplate = item.template;
                    break;
                case 'frozenexpandedrow':
                    this.frozenExpandedRowTemplate = item.template;
                    break;
                case 'emptymessage':
                    this.emptyMessageTemplate = item.template;
                    break;
                case 'paginatorleft':
                    this.paginatorLeftTemplate = item.template;
                    break;
                case 'paginatorright':
                    this.paginatorRightTemplate = item.template;
                    break;
                case 'paginatordropdownicon':
                    this.paginatorDropdownIconTemplate = item.template;
                    break;
                case 'paginatordropdownitem':
                    this.paginatorDropdownItemTemplate = item.template;
                    break;
                case 'paginatorfirstpagelinkicon':
                    this.paginatorFirstPageLinkIconTemplate = item.template;
                    break;
                case 'paginatorlastpagelinkicon':
                    this.paginatorLastPageLinkIconTemplate = item.template;
                    break;
                case 'paginatorpreviouspagelinkicon':
                    this.paginatorPreviousPageLinkIconTemplate = item.template;
                    break;
                case 'paginatornextpagelinkicon':
                    this.paginatorNextPageLinkIconTemplate = item.template;
                    break;
                case 'loadingicon':
                    this.loadingIconTemplate = item.template;
                    break;
                case 'reorderindicatorupicon':
                    this.reorderIndicatorUpIconTemplate = item.template;
                    break;
                case 'reorderindicatordownicon':
                    this.reorderIndicatorDownIconTemplate = item.template;
                    break;
                case 'sorticon':
                    this.sortIconTemplate = item.template;
                    break;
                case 'checkboxicon':
                    this.checkboxIconTemplate = item.template;
                    break;
                case 'headercheckboxicon':
                    this.headerCheckboxIconTemplate = item.template;
                    break;
            }
        });
    }
    onAfterViewInit() {
        if (isPlatformBrowser(this.platformId)) {
            if (this.isStateful() && this.resizableColumns()) {
                this.restoreColumnWidths();
            }
        }
    }
    get processedData() {
        return this.filteredValue || this._value || [];
    }
    _initialColWidths;
    dataToRender(data) {
        const _data = data || this.processedData;
        if (_data && this.paginator()) {
            const first = this.lazy() ? 0 : (this.first() ?? 0);
            const rows = this.rows() ?? 0;
            return _data.slice(first, first + rows);
        }
        return _data;
    }
    updateSelectionKeys() {
        const dataKey = this.dataKey();
        if (dataKey && this._selection) {
            this.selectionKeys = {};
            if (Array.isArray(this._selection)) {
                for (let data of this._selection) {
                    this.selectionKeys[String(ObjectUtils.resolveFieldData(data, dataKey))] = 1;
                }
            }
            else {
                this.selectionKeys[String(ObjectUtils.resolveFieldData(this._selection, dataKey))] = 1;
            }
        }
    }
    onPageChange(event) {
        this._first = event.first;
        this._rows = event.rows;
        this.onPage.emit({
            first: this._first,
            rows: this._rows
        });
        if (this.lazy()) {
            this.onLazyLoad.emit(this.createLazyLoadMetadata());
        }
        this.firstChange.emit(this._first);
        this.rowsChange.emit(this._rows);
        this.tableService.onValueChange(this._value);
        if (this.isStateful()) {
            this.saveState();
        }
        this.anchorRowIndex = null;
        if (this.scrollable()) {
            this.resetScrollTop();
        }
    }
    sort(event) {
        let originalEvent = event.originalEvent;
        const sortMode = this.sortMode();
        const resetPageOnSort = this.resetPageOnSort();
        if (sortMode === 'single') {
            this._sortOrder = this._sortField === event.field ? this._sortOrder * -1 : this.defaultSortOrder();
            this._sortField = event.field;
            if (resetPageOnSort) {
                this._first = 0;
                this.firstChange.emit(this._first);
                if (this.scrollable()) {
                    this.resetScrollTop();
                }
            }
            this.sortSingle();
        }
        if (sortMode === 'multiple') {
            let metaKey = originalEvent.metaKey || originalEvent.ctrlKey;
            let sortMeta = this.getSortMeta(event.field);
            if (sortMeta) {
                if (!metaKey) {
                    this._multiSortMeta = [
                        {
                            field: event.field,
                            order: sortMeta.order * -1
                        }
                    ];
                    if (resetPageOnSort) {
                        this._first = 0;
                        this.firstChange.emit(this._first);
                        if (this.scrollable()) {
                            this.resetScrollTop();
                        }
                    }
                }
                else {
                    sortMeta.order = sortMeta.order * -1;
                }
            }
            else {
                if (!metaKey || !this._multiSortMeta) {
                    this._multiSortMeta = [];
                    if (resetPageOnSort) {
                        this._first = 0;
                        this.firstChange.emit(this._first);
                    }
                }
                this._multiSortMeta.push({
                    field: event.field,
                    order: this.defaultSortOrder()
                });
            }
            this.sortMultiple();
        }
        if (this.isStateful()) {
            this.saveState();
        }
        this.anchorRowIndex = null;
    }
    sortSingle() {
        let field = this._sortField || this.groupRowsBy();
        let order = this._sortField ? this._sortOrder : this.groupRowsByOrder();
        const groupRowsBy = this.groupRowsBy();
        if (groupRowsBy && this._sortField && groupRowsBy !== this._sortField) {
            this._multiSortMeta = [this.getGroupRowsMeta(), { field: this._sortField, order: this._sortOrder }];
            this.sortMultiple();
            return;
        }
        if (field && order) {
            if (this.restoringSort) {
                this.restoringSort = false;
            }
            if (this.lazy()) {
                this.onLazyLoad.emit(this.createLazyLoadMetadata());
            }
            else if (this._value) {
                if (this.customSort()) {
                    this.sortFunction.emit({
                        data: this._value,
                        mode: this.sortMode(),
                        field: field,
                        order: order
                    });
                }
                else {
                    this._value.sort((data1, data2) => {
                        let value1 = ObjectUtils.resolveFieldData(data1, field);
                        let value2 = ObjectUtils.resolveFieldData(data2, field);
                        let result = null;
                        if (value1 == null && value2 != null)
                            result = -1;
                        else if (value1 != null && value2 == null)
                            result = 1;
                        else if (value1 == null && value2 == null)
                            result = 0;
                        else if (typeof value1 === 'string' && typeof value2 === 'string')
                            result = value1.localeCompare(value2);
                        else
                            result = value1 < value2 ? -1 : value1 > value2 ? 1 : 0;
                        return order * (result || 0);
                    });
                    this._value = [...this._value];
                }
                if (this.hasFilter()) {
                    this._filter();
                }
            }
            let sortMeta = {
                field: field,
                order: order
            };
            this.onSort.emit(sortMeta);
            this.tableService.onSort(sortMeta);
        }
    }
    sortMultiple() {
        const groupRowsBy = this.groupRowsBy();
        if (groupRowsBy) {
            if (!this._multiSortMeta)
                this._multiSortMeta = [this.getGroupRowsMeta()];
            else if (this._multiSortMeta[0].field !== groupRowsBy)
                this._multiSortMeta = [this.getGroupRowsMeta(), ...this._multiSortMeta];
        }
        if (this._multiSortMeta) {
            if (this.lazy()) {
                this.onLazyLoad.emit(this.createLazyLoadMetadata());
            }
            else if (this._value) {
                if (this.customSort()) {
                    this.sortFunction.emit({
                        data: this._value,
                        mode: this.sortMode(),
                        multiSortMeta: this._multiSortMeta
                    });
                }
                else {
                    this._value.sort((data1, data2) => this.multisortField(data1, data2, this._multiSortMeta, 0));
                    this._value = [...this._value];
                }
                if (this.hasFilter()) {
                    this._filter();
                }
            }
            this.onSort.emit({
                multisortmeta: this._multiSortMeta
            });
            this.tableService.onSort(this._multiSortMeta);
        }
    }
    multisortField(data1, data2, multiSortMeta, index) {
        const value1 = ObjectUtils.resolveFieldData(data1, multiSortMeta[index].field);
        const value2 = ObjectUtils.resolveFieldData(data2, multiSortMeta[index].field);
        if (ObjectUtils.compare(value1, value2, this.filterLocale()) === 0) {
            return multiSortMeta.length - 1 > index ? this.multisortField(data1, data2, multiSortMeta, index + 1) : 0;
        }
        return this.compareValuesOnSort(value1, value2, multiSortMeta[index].order);
    }
    compareValuesOnSort(value1, value2, order) {
        return ObjectUtils.sort(value1, value2, order, this.filterLocale(), this._sortOrder);
    }
    getSortMeta(field) {
        if (this._multiSortMeta && this._multiSortMeta.length) {
            for (let i = 0; i < this._multiSortMeta.length; i++) {
                if (this._multiSortMeta[i].field === field) {
                    return this._multiSortMeta[i];
                }
            }
        }
        return null;
    }
    isSorted(field) {
        const sortMode = this.sortMode();
        if (sortMode === 'single') {
            return this._sortField && this._sortField === field;
        }
        else if (sortMode === 'multiple') {
            let sorted = false;
            if (this._multiSortMeta) {
                for (let i = 0; i < this._multiSortMeta.length; i++) {
                    if (this._multiSortMeta[i].field == field) {
                        sorted = true;
                        break;
                    }
                }
            }
            return sorted;
        }
    }
    handleRowClick(event) {
        let target = event.originalEvent.target;
        let targetNode = target.nodeName;
        let parentNode = target.parentElement && target.parentElement.nodeName;
        if (targetNode == 'INPUT' || targetNode == 'BUTTON' || targetNode == 'A' || parentNode == 'INPUT' || parentNode == 'BUTTON' || parentNode == 'A' || isClickable(event.originalEvent.target)) {
            return;
        }
        const selectionMode = this.selectionMode();
        if (selectionMode) {
            let rowData = event.rowData;
            let rowIndex = event.rowIndex;
            this.preventSelectionSetterPropagation = true;
            if (this.isMultipleSelectionMode() && event.originalEvent.shiftKey && this.anchorRowIndex != null) {
                DomHandler.clearSelection();
                if (this.rangeRowIndex != null) {
                    this.clearSelectionRange(event.originalEvent);
                }
                this.rangeRowIndex = rowIndex;
                this.selectRange(event.originalEvent, rowIndex);
            }
            else {
                let selected = this.isSelected(rowData);
                if (!selected && !this.isRowSelectable(rowData, rowIndex)) {
                    return;
                }
                let metaSelection = this.rowTouched ? false : this.metaKeySelection();
                const dataKey = this.dataKey();
                let dataKeyValue = dataKey ? String(ObjectUtils.resolveFieldData(rowData, dataKey)) : null;
                this.anchorRowIndex = rowIndex;
                this.rangeRowIndex = rowIndex;
                if (metaSelection) {
                    let metaKey = event.originalEvent.metaKey || event.originalEvent.ctrlKey;
                    if (selected && metaKey) {
                        if (this.isSingleSelectionMode()) {
                            this._selection = null;
                            this.selectionKeys = {};
                            this.selectionChange.emit(null);
                        }
                        else {
                            let selectionIndex = this.findIndexInSelection(rowData);
                            this._selection = this._selection.filter((val, i) => i != selectionIndex);
                            this.selectionChange.emit(this._selection);
                            if (dataKeyValue) {
                                delete this.selectionKeys[dataKeyValue];
                            }
                        }
                        this.onRowUnselect.emit({
                            originalEvent: event.originalEvent,
                            data: rowData,
                            type: 'row'
                        });
                    }
                    else {
                        if (this.isSingleSelectionMode()) {
                            this._selection = rowData;
                            this.selectionChange.emit(rowData);
                            if (dataKeyValue) {
                                this.selectionKeys = {};
                                this.selectionKeys[dataKeyValue] = 1;
                            }
                        }
                        else if (this.isMultipleSelectionMode()) {
                            if (metaKey) {
                                this._selection = this._selection || [];
                            }
                            else {
                                this._selection = [];
                                this.selectionKeys = {};
                            }
                            this._selection = [...this._selection, rowData];
                            this.selectionChange.emit(this._selection);
                            if (dataKeyValue) {
                                this.selectionKeys[dataKeyValue] = 1;
                            }
                        }
                        this.onRowSelect.emit({
                            originalEvent: event.originalEvent,
                            data: rowData,
                            type: 'row',
                            index: rowIndex
                        });
                    }
                }
                else {
                    if (selectionMode === 'single') {
                        if (selected) {
                            this._selection = null;
                            this.selectionKeys = {};
                            this.selectionChange.emit(this._selection);
                            this.onRowUnselect.emit({
                                originalEvent: event.originalEvent,
                                data: rowData,
                                type: 'row',
                                index: rowIndex
                            });
                        }
                        else {
                            this._selection = rowData;
                            this.selectionChange.emit(this._selection);
                            this.onRowSelect.emit({
                                originalEvent: event.originalEvent,
                                data: rowData,
                                type: 'row',
                                index: rowIndex
                            });
                            if (dataKeyValue) {
                                this.selectionKeys = {};
                                this.selectionKeys[dataKeyValue] = 1;
                            }
                        }
                    }
                    else if (selectionMode === 'multiple') {
                        if (selected) {
                            let selectionIndex = this.findIndexInSelection(rowData);
                            this._selection = this._selection.filter((val, i) => i != selectionIndex);
                            this.selectionChange.emit(this._selection);
                            this.onRowUnselect.emit({
                                originalEvent: event.originalEvent,
                                data: rowData,
                                type: 'row',
                                index: rowIndex
                            });
                            if (dataKeyValue) {
                                delete this.selectionKeys[dataKeyValue];
                            }
                        }
                        else {
                            this._selection = this._selection ? [...this._selection, rowData] : [rowData];
                            this.selectionChange.emit(this._selection);
                            this.onRowSelect.emit({
                                originalEvent: event.originalEvent,
                                data: rowData,
                                type: 'row',
                                index: rowIndex
                            });
                            if (dataKeyValue) {
                                this.selectionKeys[dataKeyValue] = 1;
                            }
                        }
                    }
                }
            }
            this.tableService.onSelectionChange();
            if (this.isStateful()) {
                this.saveState();
            }
        }
        this.rowTouched = false;
    }
    handleRowTouchEnd() {
        this.rowTouched = true;
    }
    handleRowRightClick(event) {
        if (this.contextMenu()) {
            const rowData = event.rowData;
            const rowIndex = event.rowIndex;
            const showContextMenu = () => {
                this.contextMenu().show(event.originalEvent);
                this.contextMenu().hideCallback = () => {
                    this._contextMenuSelection = null;
                    this.contextMenuSelectionChange.emit(null);
                    this.tableService.onContextMenu(null);
                };
            };
            const contextMenuSelectionMode = this.contextMenuSelectionMode();
            if (contextMenuSelectionMode === 'separate') {
                this._contextMenuSelection = rowData;
                this.contextMenuSelectionChange.emit(rowData);
                this.tableService.onContextMenu(rowData);
                showContextMenu();
                this.onContextMenuSelect.emit({
                    originalEvent: event.originalEvent,
                    data: rowData,
                    index: event.rowIndex
                });
            }
            else if (contextMenuSelectionMode === 'joint') {
                this.preventSelectionSetterPropagation = true;
                let selected = this.isSelected(rowData);
                const dataKey = this.dataKey();
                let dataKeyValue = dataKey ? String(ObjectUtils.resolveFieldData(rowData, dataKey)) : null;
                if (!selected) {
                    if (!this.isRowSelectable(rowData, rowIndex)) {
                        return;
                    }
                    if (this.isSingleSelectionMode()) {
                        this._selection = rowData;
                        this.selectionChange.emit(rowData);
                        if (dataKeyValue) {
                            this.selectionKeys = {};
                            this.selectionKeys[dataKeyValue] = 1;
                        }
                    }
                    else if (this.isMultipleSelectionMode()) {
                        this._selection = this._selection ? [...this._selection, rowData] : [rowData];
                        this.selectionChange.emit(this._selection);
                        if (dataKeyValue) {
                            this.selectionKeys[dataKeyValue] = 1;
                        }
                    }
                }
                // Also update contextMenuSelection in joint mode
                this._contextMenuSelection = rowData;
                this.contextMenuSelectionChange.emit(rowData);
                this.tableService.onContextMenu(rowData);
                this.tableService.onSelectionChange();
                showContextMenu();
                this.onContextMenuSelect.emit({
                    originalEvent: event,
                    data: rowData,
                    index: event.rowIndex
                });
            }
        }
    }
    selectRange(event, rowIndex, isMetaKeySelection) {
        let rangeStart, rangeEnd;
        if (this.anchorRowIndex > rowIndex) {
            rangeStart = rowIndex;
            rangeEnd = this.anchorRowIndex;
        }
        else if (this.anchorRowIndex < rowIndex) {
            rangeStart = this.anchorRowIndex;
            rangeEnd = rowIndex;
        }
        else {
            rangeStart = rowIndex;
            rangeEnd = rowIndex;
        }
        if (this.lazy() && this.paginator()) {
            rangeStart -= this._first;
            rangeEnd -= this._first;
        }
        let rangeRowsData = [];
        for (let i = rangeStart; i <= rangeEnd; i++) {
            let rangeRowData = this.filteredValue ? this.filteredValue[i] : this._value[i];
            if (!this.isSelected(rangeRowData) && !isMetaKeySelection) {
                if (!this.isRowSelectable(rangeRowData, rowIndex)) {
                    continue;
                }
                rangeRowsData.push(rangeRowData);
                this._selection = [...this._selection, rangeRowData];
                const dataKey = this.dataKey();
                let dataKeyValue = dataKey ? String(ObjectUtils.resolveFieldData(rangeRowData, dataKey)) : null;
                if (dataKeyValue) {
                    this.selectionKeys[dataKeyValue] = 1;
                }
            }
        }
        this.selectionChange.emit(this._selection);
        this.onRowSelect.emit({
            originalEvent: event,
            data: rangeRowsData,
            type: 'row'
        });
    }
    clearSelectionRange(event) {
        let rangeStart, rangeEnd;
        let rangeRowIndex = this.rangeRowIndex;
        let anchorRowIndex = this.anchorRowIndex;
        if (rangeRowIndex > anchorRowIndex) {
            rangeStart = this.anchorRowIndex;
            rangeEnd = this.rangeRowIndex;
        }
        else if (rangeRowIndex < anchorRowIndex) {
            rangeStart = this.rangeRowIndex;
            rangeEnd = this.anchorRowIndex;
        }
        else {
            rangeStart = this.rangeRowIndex;
            rangeEnd = this.rangeRowIndex;
        }
        for (let i = rangeStart; i <= rangeEnd; i++) {
            let rangeRowData = this._value[i];
            let selectionIndex = this.findIndexInSelection(rangeRowData);
            this._selection = this._selection.filter((val, i) => i != selectionIndex);
            const dataKey = this.dataKey();
            let dataKeyValue = dataKey ? String(ObjectUtils.resolveFieldData(rangeRowData, dataKey)) : null;
            if (dataKeyValue) {
                delete this.selectionKeys[dataKeyValue];
            }
            this.onRowUnselect.emit({
                originalEvent: event,
                data: rangeRowData,
                type: 'row'
            });
        }
    }
    isSelected(rowData) {
        if (rowData && this._selection) {
            const dataKey = this.dataKey();
            if (dataKey) {
                return this.selectionKeys[ObjectUtils.resolveFieldData(rowData, dataKey)] !== undefined;
            }
            else {
                if (Array.isArray(this._selection))
                    return this.findIndexInSelection(rowData) > -1;
                else
                    return this.equals(rowData, this._selection);
            }
        }
        return false;
    }
    findIndexInSelection(rowData) {
        let index = -1;
        if (this._selection && this._selection.length) {
            for (let i = 0; i < this._selection.length; i++) {
                if (this.equals(rowData, this._selection[i])) {
                    index = i;
                    break;
                }
            }
        }
        return index;
    }
    isRowSelectable(data, index) {
        const rowSelectable = this.rowSelectable();
        if (rowSelectable && !rowSelectable({ data, index })) {
            return false;
        }
        return true;
    }
    toggleRowWithRadio(event, rowData) {
        this.preventSelectionSetterPropagation = true;
        if (this._selection != rowData) {
            if (!this.isRowSelectable(rowData, event.rowIndex)) {
                return;
            }
            this._selection = rowData;
            this.selectionChange.emit(this._selection);
            this.onRowSelect.emit({
                originalEvent: event.originalEvent,
                index: event.rowIndex,
                data: rowData,
                type: 'radiobutton'
            });
            const dataKey = this.dataKey();
            if (dataKey) {
                this.selectionKeys = {};
                this.selectionKeys[String(ObjectUtils.resolveFieldData(rowData, dataKey))] = 1;
            }
        }
        else {
            this._selection = null;
            this.selectionChange.emit(this._selection);
            this.onRowUnselect.emit({
                originalEvent: event.originalEvent,
                index: event.rowIndex,
                data: rowData,
                type: 'radiobutton'
            });
        }
        this.tableService.onSelectionChange();
        if (this.isStateful()) {
            this.saveState();
        }
    }
    toggleRowWithCheckbox(event, rowData) {
        this._selection = this._selection || [];
        let selected = this.isSelected(rowData);
        const dataKey = this.dataKey();
        let dataKeyValue = dataKey ? String(ObjectUtils.resolveFieldData(rowData, dataKey)) : null;
        this.preventSelectionSetterPropagation = true;
        if (selected) {
            let selectionIndex = this.findIndexInSelection(rowData);
            this._selection = this._selection.filter((val, i) => i != selectionIndex);
            this.selectionChange.emit(this._selection);
            this.onRowUnselect.emit({
                originalEvent: event.originalEvent,
                index: event.rowIndex,
                data: rowData,
                type: 'checkbox'
            });
            if (dataKeyValue) {
                delete this.selectionKeys[dataKeyValue];
            }
        }
        else {
            if (!this.isRowSelectable(rowData, event.rowIndex)) {
                return;
            }
            this._selection = this._selection ? [...this._selection, rowData] : [rowData];
            this.selectionChange.emit(this._selection);
            this.onRowSelect.emit({
                originalEvent: event.originalEvent,
                index: event.rowIndex,
                data: rowData,
                type: 'checkbox'
            });
            if (dataKeyValue) {
                this.selectionKeys[dataKeyValue] = 1;
            }
        }
        this.tableService.onSelectionChange();
        if (this.isStateful()) {
            this.saveState();
        }
    }
    toggleRowsWithCheckbox({ originalEvent }, check) {
        if (this._selectAll !== null) {
            this.selectAllChange.emit({ originalEvent: originalEvent, checked: check });
        }
        else {
            const data = this.selectionPageOnly() ? this.dataToRender(this.processedData) : this.processedData;
            let selection = this.selectionPageOnly() && this._selection ? this._selection.filter((s) => !data.some((d) => this.equals(s, d))) : [];
            if (check) {
                const frozenValue = this.frozenValue();
                selection = frozenValue ? [...selection, ...frozenValue, ...data] : [...selection, ...data];
                selection = this.rowSelectable() ? selection.filter((data, index) => this.rowSelectable()({ data, index })) : selection;
            }
            this._selection = selection;
            this.preventSelectionSetterPropagation = true;
            this.updateSelectionKeys();
            this.selectionChange.emit(this._selection);
            this.tableService.onSelectionChange();
            this.onHeaderCheckboxToggle.emit({
                originalEvent: originalEvent,
                checked: check
            });
            if (this.isStateful()) {
                this.saveState();
            }
        }
    }
    equals(data1, data2) {
        return this.compareSelectionBy() === 'equals' ? data1 === data2 : ObjectUtils.equals(data1, data2, this.dataKey());
    }
    /* Legacy Filtering for custom elements */
    filter(value, field, matchMode) {
        if (this.filterTimeout) {
            clearTimeout(this.filterTimeout);
        }
        const filters = this._filters;
        if (!this.isFilterBlank(value)) {
            this._filters[field] = { value: value, matchMode: matchMode };
        }
        else if (filters[field]) {
            delete filters[field];
        }
        this.filterTimeout = setTimeout(() => {
            this._filter();
            this.filterTimeout = null;
        }, this.filterDelay());
        this.anchorRowIndex = null;
    }
    filterGlobal(value, matchMode) {
        this.filter(value, 'global', matchMode);
    }
    isFilterBlank(filter) {
        if (filter !== null && filter !== undefined) {
            if ((typeof filter === 'string' && filter.trim().length == 0) || (Array.isArray(filter) && filter.length == 0))
                return true;
            else
                return false;
        }
        return true;
    }
    _filter() {
        if (!this.restoringFilter) {
            this._first = 0;
            this.firstChange.emit(this._first);
        }
        if (this.lazy()) {
            this.onLazyLoad.emit(this.createLazyLoadMetadata());
        }
        else {
            if (!this._value) {
                return;
            }
            if (!this.hasFilter()) {
                this.filteredValue = null;
                if (this.paginator()) {
                    this._totalRecords = this._totalRecords === 0 && this._value ? this._value.length : this._totalRecords;
                }
            }
            else {
                let globalFilterFieldsArray;
                const filters = this._filters;
                if (filters['global']) {
                    const globalFilterFields = this.globalFilterFields();
                    if (!this._columns && !globalFilterFields)
                        throw new Error('Global filtering requires dynamic columns or globalFilterFields to be defined.');
                    else
                        globalFilterFieldsArray = globalFilterFields || this._columns;
                }
                this.filteredValue = [];
                for (let i = 0; i < this._value.length; i++) {
                    let localMatch = true;
                    let globalMatch = false;
                    let localFiltered = false;
                    for (let prop in filters) {
                        if (Object.prototype.hasOwnProperty.call(filters, prop) && prop !== 'global') {
                            localFiltered = true;
                            let filterField = prop;
                            let filterMeta = filters[filterField];
                            if (Array.isArray(filterMeta)) {
                                for (let meta of filterMeta) {
                                    localMatch = this.executeLocalFilter(filterField, this._value[i], meta);
                                    if ((meta.operator === FilterOperator.OR && localMatch) || (meta.operator === FilterOperator.AND && !localMatch)) {
                                        break;
                                    }
                                }
                            }
                            else {
                                localMatch = this.executeLocalFilter(filterField, this._value[i], filterMeta);
                            }
                            if (!localMatch) {
                                break;
                            }
                        }
                    }
                    if (filters['global'] && !globalMatch && globalFilterFieldsArray) {
                        for (let j = 0; j < globalFilterFieldsArray.length; j++) {
                            let globalFilterField = globalFilterFieldsArray[j].field || globalFilterFieldsArray[j];
                            globalMatch = this.filterService.filters[filters['global'].matchMode](ObjectUtils.resolveFieldData(this._value[i], globalFilterField), filters['global'].value, this.filterLocale());
                            if (globalMatch) {
                                break;
                            }
                        }
                    }
                    let matches;
                    if (filters['global']) {
                        matches = localFiltered ? localFiltered && localMatch && globalMatch : globalMatch;
                    }
                    else {
                        matches = localFiltered && localMatch;
                    }
                    if (matches) {
                        this.filteredValue.push(this._value[i]);
                    }
                }
                if (this.filteredValue.length === this._value.length) {
                    this.filteredValue = null;
                }
                if (this.paginator()) {
                    this._totalRecords = this.filteredValue ? this.filteredValue.length : this._totalRecords === 0 && this._value ? this._value.length : (this._totalRecords ?? 0);
                }
            }
        }
        this.onFilter.emit({
            filters: this._filters,
            filteredValue: this.filteredValue || this._value
        });
        this.tableService.onValueChange(this._value);
        if (this.isStateful() && !this.restoringFilter) {
            this.saveState();
        }
        if (this.restoringFilter) {
            this.restoringFilter = false;
        }
        this.cd.markForCheck();
        if (this.scrollable()) {
            this.resetScrollTop();
        }
    }
    executeLocalFilter(field, rowData, filterMeta) {
        let filterValue = filterMeta.value;
        let filterMatchMode = filterMeta.matchMode || FilterMatchMode.STARTS_WITH;
        let dataFieldValue = ObjectUtils.resolveFieldData(rowData, field);
        let filterConstraint = this.filterService.filters[filterMatchMode];
        return filterConstraint(dataFieldValue, filterValue, this.filterLocale());
    }
    hasFilter() {
        let empty = true;
        for (let prop in this._filters) {
            if (Object.prototype.hasOwnProperty.call(this._filters, prop)) {
                empty = false;
                break;
            }
        }
        return !empty;
    }
    createLazyLoadMetadata() {
        const filters = this._filters;
        return {
            first: this._first,
            rows: this._rows,
            sortField: this._sortField,
            sortOrder: this._sortOrder,
            filters: this._filters,
            globalFilter: filters && filters['global'] ? filters['global'].value : null,
            multiSortMeta: this._multiSortMeta,
            forceUpdate: () => this.cd.detectChanges()
        };
    }
    clear() {
        this._sortField = null;
        this._sortOrder = this.defaultSortOrder();
        this._multiSortMeta = null;
        this.tableService.onSort(null);
        this.clearFilterValues();
        this.filteredValue = null;
        this._first = 0;
        this.firstChange.emit(this._first);
        if (this.lazy()) {
            this.onLazyLoad.emit(this.createLazyLoadMetadata());
        }
        else {
            this._totalRecords = this._totalRecords === 0 && this._value ? this._value.length : (this._totalRecords ?? 0);
        }
    }
    clearFilterValues() {
        for (const [, filterMetadata] of Object.entries(this._filters)) {
            if (Array.isArray(filterMetadata)) {
                for (let filter of filterMetadata) {
                    filter.value = null;
                }
            }
            else if (filterMetadata) {
                filterMetadata.value = null;
            }
        }
    }
    reset() {
        this.clear();
    }
    getExportHeader(column) {
        return column[this.exportHeader()] || column.header || column.field;
    }
    /**
     * Data export method.
     * @param {ExportCSVOptions} object - Export options.
     * @group Method
     */
    exportCSV(options) {
        let data;
        let csv = '';
        let columns = this._columns;
        if (options && options.selectionOnly) {
            data = this._selection || [];
        }
        else if (options && options.allValues) {
            data = this._value || [];
        }
        else {
            data = this.filteredValue || this._value;
            const frozenValue = this.frozenValue();
            if (frozenValue) {
                data = data ? [...frozenValue, ...data] : frozenValue;
            }
        }
        const exportableColumns = columns.filter((column) => column.exportable !== false && column.field);
        //headers
        csv += exportableColumns.map((column) => '"' + this.getExportHeader(column) + '"').join(this.csvSeparator());
        //body
        const body = data
            .map((record) => exportableColumns
            .map((column) => {
            let cellData = ObjectUtils.resolveFieldData(record, column.field);
            if (cellData != null) {
                const exportFunction = this.exportFunction();
                if (exportFunction) {
                    cellData = exportFunction({
                        data: cellData,
                        field: column.field
                    });
                }
                else
                    cellData = String(cellData).replace(/"/g, '""');
            }
            else
                cellData = '';
            return '"' + cellData + '"';
        })
            .join(this.csvSeparator()))
            .join('\n');
        if (body.length) {
            csv += '\n' + body;
        }
        let blob = new Blob([new Uint8Array([0xef, 0xbb, 0xbf]), csv], {
            type: 'text/csv;charset=utf-8;'
        });
        let link = this.renderer.createElement('a');
        link.style.display = 'none';
        this.renderer.appendChild(this.document.body, link);
        if (link.download !== undefined) {
            link.setAttribute('href', URL.createObjectURL(blob));
            link.setAttribute('download', this.exportFilename() + '.csv');
            link.click();
        }
        else {
            csv = 'data:text/csv;charset=utf-8,' + csv;
            this.document.defaultView?.open(encodeURI(csv));
        }
        this.renderer.removeChild(this.document.body, link);
    }
    onLazyItemLoad(event) {
        this.onLazyLoad.emit({
            ...this.createLazyLoadMetadata(),
            ...event,
            rows: event.last - event.first
        });
    }
    /**
     * Resets scroll to top.
     * @group Method
     */
    resetScrollTop() {
        if (this.virtualScroll())
            this.scrollToVirtualIndex(0);
        else
            this.scrollTo({ top: 0 });
    }
    /**
     * Scrolls to given index when using virtual scroll.
     * @param {number} index - index of the element.
     * @group Method
     */
    scrollToVirtualIndex(index) {
        const scroller = this.scroller();
        scroller && scroller.scrollToIndex(index);
    }
    /**
     * Scrolls to given index.
     * @param {ScrollToOptions} options - scroll options.
     * @group Method
     */
    scrollTo(options) {
        const wrapperViewChild = this.wrapperViewChild();
        if (this.virtualScroll()) {
            this.scroller()?.scrollTo(options);
        }
        else if (wrapperViewChild && wrapperViewChild.nativeElement) {
            if (wrapperViewChild.nativeElement.scrollTo) {
                wrapperViewChild.nativeElement.scrollTo(options);
            }
            else {
                wrapperViewChild.nativeElement.scrollLeft = options.left;
                wrapperViewChild.nativeElement.scrollTop = options.top;
            }
        }
    }
    updateEditingCell(cell, data, field, index) {
        this.editingCell = cell;
        this.editingCellData = data;
        this.editingCellField = field;
        this.editingCellRowIndex = index;
        this.bindDocumentEditListener();
    }
    isEditingCellValid() {
        return this.editingCell && DomHandler.find(this.editingCell, '.ng-invalid.ng-dirty').length === 0;
    }
    bindDocumentEditListener() {
        if (!this.documentEditListener) {
            this.documentEditListener = this.renderer.listen(this.document, 'click', (event) => {
                if (this.editingCell && !this.selfClick && this.isEditingCellValid()) {
                    !this.$unstyled() && DomHandler.removeClass(this.editingCell, 'p-cell-editing');
                    setAttribute(this.editingCell, 'data-p-cell-editing', 'false');
                    this.editingCell = null;
                    this.onEditComplete.emit({
                        field: this.editingCellField,
                        data: this.editingCellData,
                        originalEvent: event,
                        index: this.editingCellRowIndex
                    });
                    this.editingCellField = null;
                    this.editingCellData = null;
                    this.editingCellRowIndex = null;
                    this.unbindDocumentEditListener();
                    this.cd.markForCheck();
                    if (this.overlaySubscription) {
                        this.overlaySubscription.unsubscribe();
                    }
                }
                this.selfClick = false;
            });
        }
    }
    unbindDocumentEditListener() {
        if (this.documentEditListener) {
            this.documentEditListener();
            this.documentEditListener = null;
        }
    }
    initRowEdit(rowData) {
        let dataKeyValue = String(ObjectUtils.resolveFieldData(rowData, this.dataKey()));
        this.editingRowKeys()[dataKeyValue] = true;
    }
    saveRowEdit(rowData, rowElement) {
        if (DomHandler.find(rowElement, '.ng-invalid.ng-dirty').length === 0) {
            let dataKeyValue = String(ObjectUtils.resolveFieldData(rowData, this.dataKey()));
            delete this.editingRowKeys()[dataKeyValue];
        }
    }
    cancelRowEdit(rowData) {
        let dataKeyValue = String(ObjectUtils.resolveFieldData(rowData, this.dataKey()));
        delete this.editingRowKeys()[dataKeyValue];
    }
    toggleRow(rowData, event) {
        const groupRowsBy = this.groupRowsBy();
        const dataKey = this.dataKey();
        if (!dataKey && !groupRowsBy) {
            throw new Error('dataKey or groupRowsBy must be defined to use row expansion');
        }
        let dataKeyValue = groupRowsBy ? String(ObjectUtils.resolveFieldData(rowData, groupRowsBy)) : String(ObjectUtils.resolveFieldData(rowData, dataKey));
        const expandedRowKeys = this._expandedRowKeys;
        if (expandedRowKeys[dataKeyValue] != null) {
            delete expandedRowKeys[dataKeyValue];
            this.onRowCollapse.emit({
                originalEvent: event,
                data: rowData
            });
        }
        else {
            if (this.rowExpandMode() === 'single') {
                this._expandedRowKeys = {};
            }
            expandedRowKeys[dataKeyValue] = true;
            this.onRowExpand.emit({
                originalEvent: event,
                data: rowData
            });
        }
        if (event) {
            event.preventDefault();
        }
        if (this.isStateful()) {
            this.saveState();
        }
    }
    isRowExpanded(rowData) {
        const groupRowsBy = this.groupRowsBy();
        return groupRowsBy ? this._expandedRowKeys[String(ObjectUtils.resolveFieldData(rowData, groupRowsBy))] === true : this._expandedRowKeys[String(ObjectUtils.resolveFieldData(rowData, this.dataKey()))] === true;
    }
    isRowEditing(rowData) {
        return this.editingRowKeys()[String(ObjectUtils.resolveFieldData(rowData, this.dataKey()))] === true;
    }
    isSingleSelectionMode() {
        return this.selectionMode() === 'single';
    }
    isMultipleSelectionMode() {
        return this.selectionMode() === 'multiple';
    }
    onColumnResizeBegin(event) {
        let containerLeft = DomHandler.getOffset(this.el?.nativeElement).left;
        this.resizeColumnElement = event.target.closest('th');
        this.columnResizing = true;
        if (event.type == 'touchstart') {
            this.lastResizerHelperX = event.changedTouches[0].clientX - containerLeft + this.el?.nativeElement.scrollLeft;
        }
        else {
            this.lastResizerHelperX = event.pageX - containerLeft + this.el?.nativeElement.scrollLeft;
        }
        this.onColumnResize(event);
        event.preventDefault();
    }
    onColumnResize(event) {
        let containerLeft = DomHandler.getOffset(this.el?.nativeElement).left;
        !this.$unstyled() && DomHandler.addClass(this.el?.nativeElement, 'p-unselectable-text');
        this.resizeHelperViewChild().nativeElement.style.height = this.el?.nativeElement.offsetHeight + 'px';
        this.resizeHelperViewChild().nativeElement.style.top = 0 + 'px';
        if (event.type == 'touchmove') {
            this.resizeHelperViewChild().nativeElement.style.left = event.changedTouches[0].clientX - containerLeft + this.el?.nativeElement.scrollLeft + 'px';
        }
        else {
            this.resizeHelperViewChild().nativeElement.style.left = event.pageX - containerLeft + this.el?.nativeElement.scrollLeft + 'px';
        }
        this.resizeHelperViewChild().nativeElement.style.display = 'block';
    }
    onColumnResizeEnd() {
        const isRTL = getComputedStyle(this.el?.nativeElement ?? document.documentElement).direction === 'rtl';
        const resizeHelperViewChild = this.resizeHelperViewChild();
        const rawDelta = resizeHelperViewChild?.nativeElement.offsetLeft - this.lastResizerHelperX;
        const delta = isRTL ? -rawDelta : rawDelta;
        const columnWidth = this.resizeColumnElement.offsetWidth;
        const newColumnWidth = columnWidth + delta;
        const elementMinWidth = this.resizeColumnElement.style.minWidth.replace(/[^\d.]/g, '');
        const minWidth = elementMinWidth ? parseFloat(elementMinWidth) : 15;
        if (newColumnWidth >= minWidth) {
            const columnResizeMode = this.columnResizeMode();
            if (columnResizeMode === 'fit') {
                const nextColumn = this.resizeColumnElement.nextElementSibling;
                const nextColumnWidth = nextColumn.offsetWidth - delta;
                if (newColumnWidth > 15 && nextColumnWidth > 15) {
                    this.resizeTableCells(newColumnWidth, nextColumnWidth);
                }
            }
            else if (columnResizeMode === 'expand') {
                this._initialColWidths = this._totalTableWidth();
                const tableWidth = this.tableViewChild()?.nativeElement.offsetWidth + delta;
                this.setResizeTableWidth(tableWidth + 'px');
                this.resizeTableCells(newColumnWidth, null);
            }
            this.onColResize.emit({
                element: this.resizeColumnElement,
                delta: delta
            });
            if (this.isStateful()) {
                this.saveState();
            }
        }
        resizeHelperViewChild.nativeElement.style.display = 'none';
        DomHandler.removeClass(this.el?.nativeElement, 'p-unselectable-text');
    }
    _totalTableWidth() {
        let widths = [];
        const tableHead = DomHandler.findSingle(this.el.nativeElement, '[data-pc-section="thead"]');
        let headers = DomHandler.find(tableHead, 'tr > th');
        headers.forEach((header) => widths.push(DomHandler.getOuterWidth(header)));
        return widths;
    }
    onColumnDragStart(event, columnElement) {
        this.reorderIconWidth = DomHandler.getHiddenElementOuterWidth(this.reorderIndicatorUpViewChild()?.nativeElement);
        this.reorderIconHeight = DomHandler.getHiddenElementOuterHeight(this.reorderIndicatorDownViewChild()?.nativeElement);
        this.draggedColumn = columnElement;
        event.dataTransfer.setData('text', 'b'); // For firefox
    }
    onColumnDragEnter(event, dropHeader) {
        if (this.reorderableColumns() && this.draggedColumn && dropHeader) {
            event.preventDefault();
            let containerOffset = DomHandler.getOffset(this.el?.nativeElement);
            let dropHeaderOffset = DomHandler.getOffset(dropHeader);
            if (this.draggedColumn != dropHeader) {
                let targetLeft = dropHeaderOffset.left - containerOffset.left;
                let columnCenter = dropHeaderOffset.left + dropHeader.offsetWidth / 2;
                this.reorderIndicatorUpViewChild().nativeElement.style.top = dropHeaderOffset.top - containerOffset.top - (this.reorderIconHeight - 1) + 'px';
                this.reorderIndicatorDownViewChild().nativeElement.style.top = dropHeaderOffset.top - containerOffset.top + dropHeader.offsetHeight + 'px';
                if (event.pageX > columnCenter) {
                    this.reorderIndicatorUpViewChild().nativeElement.style.left = targetLeft + dropHeader.offsetWidth - Math.ceil(this.reorderIconWidth / 2) + 'px';
                    this.reorderIndicatorDownViewChild().nativeElement.style.left = targetLeft + dropHeader.offsetWidth - Math.ceil(this.reorderIconWidth / 2) + 'px';
                    this.dropPosition = 1;
                }
                else {
                    this.reorderIndicatorUpViewChild().nativeElement.style.left = targetLeft - Math.ceil(this.reorderIconWidth / 2) + 'px';
                    this.reorderIndicatorDownViewChild().nativeElement.style.left = targetLeft - Math.ceil(this.reorderIconWidth / 2) + 'px';
                    this.dropPosition = -1;
                }
                this.reorderIndicatorUpViewChild().nativeElement.style.display = 'block';
                this.reorderIndicatorDownViewChild().nativeElement.style.display = 'block';
            }
            else {
                event.dataTransfer.dropEffect = 'none';
            }
        }
    }
    onColumnDragLeave(event) {
        if (this.reorderableColumns() && this.draggedColumn) {
            event.preventDefault();
        }
    }
    onColumnDrop(event, dropColumn) {
        event.preventDefault();
        if (this.draggedColumn) {
            let dragIndex = DomHandler.indexWithinGroup(this.draggedColumn, 'preorderablecolumn');
            let dropIndex = DomHandler.indexWithinGroup(dropColumn, 'preorderablecolumn');
            let allowDrop = dragIndex != dropIndex;
            if (allowDrop && ((dropIndex - dragIndex == 1 && this.dropPosition === -1) || (dragIndex - dropIndex == 1 && this.dropPosition === 1))) {
                allowDrop = false;
            }
            if (allowDrop && dropIndex < dragIndex && this.dropPosition === 1) {
                dropIndex = dropIndex + 1;
            }
            if (allowDrop && dropIndex > dragIndex && this.dropPosition === -1) {
                dropIndex = dropIndex - 1;
            }
            if (allowDrop) {
                ObjectUtils.reorderArray(this._columns, dragIndex, dropIndex);
                this.onColReorder.emit({
                    dragIndex: dragIndex,
                    dropIndex: dropIndex,
                    columns: this._columns
                });
                if (this.isStateful()) {
                    this.zone.runOutsideAngular(() => {
                        setTimeout(() => {
                            this.saveState();
                        });
                    });
                }
            }
            if (this.resizableColumns() && this.resizeColumnElement) {
                let width = this.columnResizeMode() === 'expand' ? this._initialColWidths : this._totalTableWidth();
                ObjectUtils.reorderArray(width, dragIndex + 1, dropIndex + 1);
                this.updateStyleElement(width, dragIndex, 0, 0);
            }
            this.reorderIndicatorUpViewChild().nativeElement.style.display = 'none';
            this.reorderIndicatorDownViewChild().nativeElement.style.display = 'none';
            this.draggedColumn.draggable = false;
            this.draggedColumn = null;
            this.dropPosition = null;
        }
    }
    resizeTableCells(newColumnWidth, nextColumnWidth) {
        let colIndex = DomHandler.index(this.resizeColumnElement);
        let width = this.columnResizeMode() === 'expand' ? this._initialColWidths : this._totalTableWidth();
        this.updateStyleElement(width, colIndex, newColumnWidth, nextColumnWidth);
    }
    updateStyleElement(width, colIndex, newColumnWidth, nextColumnWidth) {
        this.destroyStyleElement();
        this.createStyleElement();
        let innerHTML = '';
        width.forEach((width, index) => {
            let colWidth = index === colIndex ? newColumnWidth : nextColumnWidth && index === colIndex + 1 ? nextColumnWidth : width;
            let style = `width: ${colWidth}px !important; max-width: ${colWidth}px !important;`;
            innerHTML += `
                #${this.id}-table > .p-datatable-thead > tr > th:nth-child(${index + 1}),
                #${this.id}-table > .p-datatable-tbody > tr > td:nth-child(${index + 1}),
                #${this.id}-table > .p-datatable-tfoot > tr > td:nth-child(${index + 1}) {
                    ${style}
                }
            `;
        });
        this.renderer.setProperty(this.styleElement, 'innerHTML', innerHTML);
    }
    onRowDragStart(event, index) {
        this.rowDragging = true;
        this.draggedRowIndex = index;
        event.dataTransfer.setData('text', 'b'); // For firefox
    }
    onRowDragOver(event, index, rowElement) {
        if (this.rowDragging && this.draggedRowIndex !== index) {
            let rowY = DomHandler.getOffset(rowElement).top;
            let pageY = event.pageY;
            let rowMidY = rowY + DomHandler.getOuterHeight(rowElement) / 2;
            let prevRowElement = rowElement.previousElementSibling;
            if (pageY < rowMidY) {
                DomHandler.removeClass(rowElement, 'p-datatable-dragpoint-bottom');
                this.droppedRowIndex = index;
                if (prevRowElement && !this.$unstyled())
                    DomHandler.addClass(prevRowElement, 'p-datatable-dragpoint-bottom');
                else
                    !this.$unstyled() && DomHandler.addClass(rowElement, 'p-datatable-dragpoint-top');
            }
            else {
                if (prevRowElement && !this.$unstyled())
                    DomHandler.removeClass(prevRowElement, 'p-datatable-dragpoint-bottom');
                else
                    !this.$unstyled() && DomHandler.addClass(rowElement, 'p-datatable-dragpoint-top');
                this.droppedRowIndex = index + 1;
                !this.$unstyled() && DomHandler.addClass(rowElement, 'p-datatable-dragpoint-bottom');
            }
        }
    }
    onRowDragLeave(event, rowElement) {
        let prevRowElement = rowElement.previousElementSibling;
        if (prevRowElement) {
            !this.$unstyled() && DomHandler.removeClass(prevRowElement, 'p-datatable-dragpoint-bottom');
        }
        !this.$unstyled() && DomHandler.removeClass(rowElement, 'p-datatable-dragpoint-bottom');
        !this.$unstyled() && DomHandler.removeClass(rowElement, 'p-datatable-dragpoint-top');
    }
    onRowDragEnd() {
        this.rowDragging = false;
        this.draggedRowIndex = null;
        this.droppedRowIndex = null;
    }
    onRowDrop(event, rowElement) {
        if (this.droppedRowIndex != null) {
            let dropIndex = this.draggedRowIndex > this.droppedRowIndex ? this.droppedRowIndex : this.droppedRowIndex === 0 ? 0 : this.droppedRowIndex - 1;
            ObjectUtils.reorderArray(this._value, this.draggedRowIndex, dropIndex);
            if (this.virtualScroll()) {
                // TODO: Check
                this._value = [...this._value];
            }
            this.onRowReorder.emit({
                dragIndex: this.draggedRowIndex,
                dropIndex: dropIndex
            });
        }
        //cleanup
        this.onRowDragLeave(event, rowElement);
        this.onRowDragEnd();
    }
    isEmpty() {
        let data = this.filteredValue || this._value;
        return data == null || data.length == 0;
    }
    getBlockableElement() {
        return this.el.nativeElement.children[0];
    }
    getStorage() {
        if (isPlatformBrowser(this.platformId)) {
            const stateStorage = this.stateStorage();
            switch (stateStorage) {
                case 'local':
                    return window.localStorage;
                case 'session':
                    return window.sessionStorage;
                default:
                    throw new Error(stateStorage + ' is not a valid value for the state storage, supported values are "local" and "session".');
            }
        }
        else {
            throw new Error('Browser storage is not available in the server side.');
        }
    }
    isStateful() {
        return this.stateKey != null;
    }
    saveState() {
        const storage = this.getStorage();
        let state = {};
        if (this.paginator()) {
            state.first = this._first;
            state.rows = this._rows;
        }
        if (this._sortField) {
            state.sortField = this._sortField;
            state.sortOrder = this._sortOrder;
        }
        if (this._multiSortMeta) {
            state.multiSortMeta = this._multiSortMeta;
        }
        if (this.hasFilter()) {
            state.filters = this._filters;
        }
        if (this.resizableColumns()) {
            this.saveColumnWidths(state);
        }
        if (this.reorderableColumns()) {
            this.saveColumnOrder(state);
        }
        if (this._selection) {
            state.selection = this._selection;
        }
        if (Object.keys(this._expandedRowKeys).length) {
            state.expandedRowKeys = this._expandedRowKeys;
        }
        storage.setItem(this.stateKey(), JSON.stringify(state));
        this.onStateSave.emit(state);
    }
    clearState() {
        const storage = this.getStorage();
        const stateKey = this.stateKey();
        if (stateKey) {
            storage.removeItem(stateKey);
        }
    }
    restoreState() {
        const storage = this.getStorage();
        const stateString = storage.getItem(this.stateKey());
        const dateFormat = /\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}.\d{3}Z/;
        const reviver = function (key, value) {
            if (typeof value === 'string' && dateFormat.test(value)) {
                return new Date(value);
            }
            return value;
        };
        if (stateString) {
            let state = JSON.parse(stateString, reviver);
            if (this.paginator()) {
                if (this._first !== undefined) {
                    this._first = state.first;
                    this.firstChange.emit(this._first);
                }
                if (this._rows !== undefined) {
                    this._rows = state.rows;
                    this.rowsChange.emit(this._rows);
                }
            }
            if (state.sortField) {
                this.restoringSort = true;
                this._sortField = state.sortField;
                this._sortOrder = state.sortOrder;
            }
            if (state.multiSortMeta) {
                this.restoringSort = true;
                this._multiSortMeta = state.multiSortMeta;
            }
            if (state.filters) {
                this.restoringFilter = true;
                this._filters = state.filters;
            }
            if (this.resizableColumns()) {
                this.columnWidthsState = state.columnWidths;
                this.tableWidthState = state.tableWidth;
            }
            // if (this.reorderableColumns) {
            //     this.restoreColumnOrder();
            // }
            if (state.expandedRowKeys) {
                this._expandedRowKeys = state.expandedRowKeys;
            }
            if (state.selection) {
                Promise.resolve(null).then(() => this.selectionChange.emit(state.selection));
            }
            this.stateRestored = true;
            this.onStateRestore.emit(state);
        }
    }
    saveColumnWidths(state) {
        let widths = [];
        let headers = [];
        const container = this.el?.nativeElement;
        if (container) {
            headers = DomHandler.find(container, '[data-pc-section="thead"] > tr > th');
        }
        headers.forEach((header) => widths.push(DomHandler.getOuterWidth(header)));
        state.columnWidths = widths.join(',');
        const tableViewChild = this.tableViewChild();
        if (this.columnResizeMode() === 'expand' && tableViewChild) {
            state.tableWidth = DomHandler.getOuterWidth(tableViewChild.nativeElement);
        }
    }
    setResizeTableWidth(width) {
        this.tableViewChild().nativeElement.style.width = width;
        this.tableViewChild().nativeElement.style.minWidth = width;
    }
    restoreColumnWidths() {
        if (this.columnWidthsState) {
            let widths = this.columnWidthsState.split(',');
            if (this.columnResizeMode() === 'expand' && this.tableWidthState) {
                this.setResizeTableWidth(this.tableWidthState + 'px');
            }
            if (ObjectUtils.isNotEmpty(widths)) {
                this.createStyleElement();
                let innerHTML = '';
                widths.forEach((width, index) => {
                    let style = `width: ${width}px !important; max-width: ${width}px !important`;
                    innerHTML += `
                        #${this.id}-table > .p-datatable-thead > tr > th:nth-child(${index + 1}),
                        #${this.id}-table > .p-datatable-tbody > tr > td:nth-child(${index + 1}),
                        #${this.id}-table > .p-datatable-tfoot > tr > td:nth-child(${index + 1}) {
                            ${style}
                        }
                    `;
                });
                this.styleElement.innerHTML = innerHTML;
            }
        }
    }
    saveColumnOrder(state) {
        if (this._columns) {
            let columnOrder = [];
            this._columns.map((column) => {
                columnOrder.push(column.field || column.key);
            });
            state.columnOrder = columnOrder;
        }
    }
    restoreColumnOrder() {
        const storage = this.getStorage();
        const stateString = storage.getItem(this.stateKey());
        if (stateString) {
            let state = JSON.parse(stateString);
            let columnOrder = state.columnOrder;
            if (columnOrder) {
                let reorderedColumns = [];
                columnOrder.map((key) => {
                    let col = this.findColumnByKey(key);
                    if (col) {
                        reorderedColumns.push(col);
                    }
                });
                this.columnOrderStateRestored = true;
                this._columns = reorderedColumns;
            }
        }
    }
    findColumnByKey(key) {
        if (this._columns) {
            for (let col of this._columns) {
                if (col.key === key || col.field === key)
                    return col;
                else
                    continue;
            }
        }
        else {
            return null;
        }
    }
    createStyleElement() {
        this.styleElement = this.renderer.createElement('style');
        this.styleElement.type = 'text/css';
        DomHandler.setAttribute(this.styleElement, 'nonce', this.config?.csp()?.nonce);
        this.renderer.appendChild(this.document.head, this.styleElement);
        DomHandler.setAttribute(this.styleElement, 'nonce', this.config?.csp()?.nonce);
    }
    getGroupRowsMeta() {
        return { field: this.groupRowsBy(), order: this.groupRowsByOrder() };
    }
    createResponsiveStyle() {
        if (isPlatformBrowser(this.platformId)) {
            if (!this.responsiveStyleElement) {
                this.responsiveStyleElement = this.renderer.createElement('style');
                this.responsiveStyleElement.type = 'text/css';
                DomHandler.setAttribute(this.responsiveStyleElement, 'nonce', this.config?.csp()?.nonce);
                this.renderer.appendChild(this.document.head, this.responsiveStyleElement);
                let innerHTML = `
    @media screen and (max-width: ${this.breakpoint()}) {
        #${this.id}-table > .p-datatable-thead > tr > th,
        #${this.id}-table > .p-datatable-tfoot > tr > td {
            display: none !important;
        }

        #${this.id}-table > .p-datatable-tbody > tr > td {
            display: flex;
            width: 100% !important;
            align-items: center;
            justify-content: space-between;
        }

        #${this.id}-table > .p-datatable-tbody > tr > td:not(:last-child) {
            border: 0 none;
        }

        #${this.id}.p-datatable-gridlines > .p-datatable-table-container > .p-datatable-table > .p-datatable-tbody > tr > td:last-child {
            border-top: 0;
            border-right: 0;
            border-left: 0;
        }

        #${this.id}-table > .p-datatable-tbody > tr > td > .p-datatable-column-title {
            display: block;
        }
    }
    `;
                this.renderer.setProperty(this.responsiveStyleElement, 'innerHTML', innerHTML);
                DomHandler.setAttribute(this.responsiveStyleElement, 'nonce', this.config?.csp()?.nonce);
            }
        }
    }
    destroyResponsiveStyle() {
        if (this.responsiveStyleElement) {
            this.renderer.removeChild(this.document.head, this.responsiveStyleElement);
            this.responsiveStyleElement = null;
        }
    }
    destroyStyleElement() {
        if (this.styleElement) {
            this.renderer.removeChild(this.document.head, this.styleElement);
            this.styleElement = null;
        }
    }
    ngAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    onDestroy() {
        this.unbindDocumentEditListener();
        this.editingCell = null;
        this.initialized = null;
        this.destroyStyleElement();
        this.destroyResponsiveStyle();
    }
    get dataP() {
        return this.cn({
            scrollable: this.scrollable(),
            'flex-scrollable': this.scrollable() && this.scrollHeight() === 'flex',
            [this.size()]: this.size(),
            loading: this.loading(),
            empty: this.isEmpty()
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Table, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: Table, isStandalone: true, selector: "p-table", inputs: { frozenColumns: { classPropertyName: "frozenColumns", publicName: "frozenColumns", isSignal: true, isRequired: false, transformFunction: null }, frozenValue: { classPropertyName: "frozenValue", publicName: "frozenValue", isSignal: true, isRequired: false, transformFunction: null }, styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, tableStyle: { classPropertyName: "tableStyle", publicName: "tableStyle", isSignal: true, isRequired: false, transformFunction: null }, tableStyleClass: { classPropertyName: "tableStyleClass", publicName: "tableStyleClass", isSignal: true, isRequired: false, transformFunction: null }, paginator: { classPropertyName: "paginator", publicName: "paginator", isSignal: true, isRequired: false, transformFunction: null }, pageLinks: { classPropertyName: "pageLinks", publicName: "pageLinks", isSignal: true, isRequired: false, transformFunction: null }, rowsPerPageOptions: { classPropertyName: "rowsPerPageOptions", publicName: "rowsPerPageOptions", isSignal: true, isRequired: false, transformFunction: null }, alwaysShowPaginator: { classPropertyName: "alwaysShowPaginator", publicName: "alwaysShowPaginator", isSignal: true, isRequired: false, transformFunction: null }, paginatorPosition: { classPropertyName: "paginatorPosition", publicName: "paginatorPosition", isSignal: true, isRequired: false, transformFunction: null }, paginatorStyleClass: { classPropertyName: "paginatorStyleClass", publicName: "paginatorStyleClass", isSignal: true, isRequired: false, transformFunction: null }, paginatorDropdownAppendTo: { classPropertyName: "paginatorDropdownAppendTo", publicName: "paginatorDropdownAppendTo", isSignal: true, isRequired: false, transformFunction: null }, paginatorDropdownScrollHeight: { classPropertyName: "paginatorDropdownScrollHeight", publicName: "paginatorDropdownScrollHeight", isSignal: true, isRequired: false, transformFunction: null }, currentPageReportTemplate: { classPropertyName: "currentPageReportTemplate", publicName: "currentPageReportTemplate", isSignal: true, isRequired: false, transformFunction: null }, showCurrentPageReport: { classPropertyName: "showCurrentPageReport", publicName: "showCurrentPageReport", isSignal: true, isRequired: false, transformFunction: null }, showJumpToPageDropdown: { classPropertyName: "showJumpToPageDropdown", publicName: "showJumpToPageDropdown", isSignal: true, isRequired: false, transformFunction: null }, showJumpToPageInput: { classPropertyName: "showJumpToPageInput", publicName: "showJumpToPageInput", isSignal: true, isRequired: false, transformFunction: null }, showFirstLastIcon: { classPropertyName: "showFirstLastIcon", publicName: "showFirstLastIcon", isSignal: true, isRequired: false, transformFunction: null }, showPageLinks: { classPropertyName: "showPageLinks", publicName: "showPageLinks", isSignal: true, isRequired: false, transformFunction: null }, defaultSortOrder: { classPropertyName: "defaultSortOrder", publicName: "defaultSortOrder", isSignal: true, isRequired: false, transformFunction: null }, sortMode: { classPropertyName: "sortMode", publicName: "sortMode", isSignal: true, isRequired: false, transformFunction: null }, resetPageOnSort: { classPropertyName: "resetPageOnSort", publicName: "resetPageOnSort", isSignal: true, isRequired: false, transformFunction: null }, selectionMode: { classPropertyName: "selectionMode", publicName: "selectionMode", isSignal: true, isRequired: false, transformFunction: null }, selectionPageOnly: { classPropertyName: "selectionPageOnly", publicName: "selectionPageOnly", isSignal: true, isRequired: false, transformFunction: null }, contextMenuSelection: { classPropertyName: "contextMenuSelection", publicName: "contextMenuSelection", isSignal: true, isRequired: false, transformFunction: null }, contextMenuSelectionMode: { classPropertyName: "contextMenuSelectionMode", publicName: "contextMenuSelectionMode", isSignal: true, isRequired: false, transformFunction: null }, dataKey: { classPropertyName: "dataKey", publicName: "dataKey", isSignal: true, isRequired: false, transformFunction: null }, metaKeySelection: { classPropertyName: "metaKeySelection", publicName: "metaKeySelection", isSignal: true, isRequired: false, transformFunction: null }, rowSelectable: { classPropertyName: "rowSelectable", publicName: "rowSelectable", isSignal: true, isRequired: false, transformFunction: null }, rowTrackBy: { classPropertyName: "rowTrackBy", publicName: "rowTrackBy", isSignal: true, isRequired: false, transformFunction: null }, lazy: { classPropertyName: "lazy", publicName: "lazy", isSignal: true, isRequired: false, transformFunction: null }, lazyLoadOnInit: { classPropertyName: "lazyLoadOnInit", publicName: "lazyLoadOnInit", isSignal: true, isRequired: false, transformFunction: null }, compareSelectionBy: { classPropertyName: "compareSelectionBy", publicName: "compareSelectionBy", isSignal: true, isRequired: false, transformFunction: null }, csvSeparator: { classPropertyName: "csvSeparator", publicName: "csvSeparator", isSignal: true, isRequired: false, transformFunction: null }, exportFilename: { classPropertyName: "exportFilename", publicName: "exportFilename", isSignal: true, isRequired: false, transformFunction: null }, filters: { classPropertyName: "filters", publicName: "filters", isSignal: true, isRequired: false, transformFunction: null }, globalFilterFields: { classPropertyName: "globalFilterFields", publicName: "globalFilterFields", isSignal: true, isRequired: false, transformFunction: null }, filterDelay: { classPropertyName: "filterDelay", publicName: "filterDelay", isSignal: true, isRequired: false, transformFunction: null }, filterLocale: { classPropertyName: "filterLocale", publicName: "filterLocale", isSignal: true, isRequired: false, transformFunction: null }, expandedRowKeys: { classPropertyName: "expandedRowKeys", publicName: "expandedRowKeys", isSignal: true, isRequired: false, transformFunction: null }, editingRowKeys: { classPropertyName: "editingRowKeys", publicName: "editingRowKeys", isSignal: true, isRequired: false, transformFunction: null }, rowExpandMode: { classPropertyName: "rowExpandMode", publicName: "rowExpandMode", isSignal: true, isRequired: false, transformFunction: null }, scrollable: { classPropertyName: "scrollable", publicName: "scrollable", isSignal: true, isRequired: false, transformFunction: null }, rowGroupMode: { classPropertyName: "rowGroupMode", publicName: "rowGroupMode", isSignal: true, isRequired: false, transformFunction: null }, scrollHeight: { classPropertyName: "scrollHeight", publicName: "scrollHeight", isSignal: true, isRequired: false, transformFunction: null }, virtualScroll: { classPropertyName: "virtualScroll", publicName: "virtualScroll", isSignal: true, isRequired: false, transformFunction: null }, virtualScrollItemSize: { classPropertyName: "virtualScrollItemSize", publicName: "virtualScrollItemSize", isSignal: true, isRequired: false, transformFunction: null }, virtualScrollOptions: { classPropertyName: "virtualScrollOptions", publicName: "virtualScrollOptions", isSignal: true, isRequired: false, transformFunction: null }, virtualScrollDelay: { classPropertyName: "virtualScrollDelay", publicName: "virtualScrollDelay", isSignal: true, isRequired: false, transformFunction: null }, frozenWidth: { classPropertyName: "frozenWidth", publicName: "frozenWidth", isSignal: true, isRequired: false, transformFunction: null }, contextMenu: { classPropertyName: "contextMenu", publicName: "contextMenu", isSignal: true, isRequired: false, transformFunction: null }, resizableColumns: { classPropertyName: "resizableColumns", publicName: "resizableColumns", isSignal: true, isRequired: false, transformFunction: null }, columnResizeMode: { classPropertyName: "columnResizeMode", publicName: "columnResizeMode", isSignal: true, isRequired: false, transformFunction: null }, reorderableColumns: { classPropertyName: "reorderableColumns", publicName: "reorderableColumns", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, loadingIcon: { classPropertyName: "loadingIcon", publicName: "loadingIcon", isSignal: true, isRequired: false, transformFunction: null }, showLoader: { classPropertyName: "showLoader", publicName: "showLoader", isSignal: true, isRequired: false, transformFunction: null }, rowHover: { classPropertyName: "rowHover", publicName: "rowHover", isSignal: true, isRequired: false, transformFunction: null }, customSort: { classPropertyName: "customSort", publicName: "customSort", isSignal: true, isRequired: false, transformFunction: null }, showInitialSortBadge: { classPropertyName: "showInitialSortBadge", publicName: "showInitialSortBadge", isSignal: true, isRequired: false, transformFunction: null }, exportFunction: { classPropertyName: "exportFunction", publicName: "exportFunction", isSignal: true, isRequired: false, transformFunction: null }, exportHeader: { classPropertyName: "exportHeader", publicName: "exportHeader", isSignal: true, isRequired: false, transformFunction: null }, stateKey: { classPropertyName: "stateKey", publicName: "stateKey", isSignal: true, isRequired: false, transformFunction: null }, stateStorage: { classPropertyName: "stateStorage", publicName: "stateStorage", isSignal: true, isRequired: false, transformFunction: null }, editMode: { classPropertyName: "editMode", publicName: "editMode", isSignal: true, isRequired: false, transformFunction: null }, groupRowsBy: { classPropertyName: "groupRowsBy", publicName: "groupRowsBy", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, showGridlines: { classPropertyName: "showGridlines", publicName: "showGridlines", isSignal: true, isRequired: false, transformFunction: null }, stripedRows: { classPropertyName: "stripedRows", publicName: "stripedRows", isSignal: true, isRequired: false, transformFunction: null }, groupRowsByOrder: { classPropertyName: "groupRowsByOrder", publicName: "groupRowsByOrder", isSignal: true, isRequired: false, transformFunction: null }, responsiveLayout: { classPropertyName: "responsiveLayout", publicName: "responsiveLayout", isSignal: true, isRequired: false, transformFunction: null }, breakpoint: { classPropertyName: "breakpoint", publicName: "breakpoint", isSignal: true, isRequired: false, transformFunction: null }, paginatorLocale: { classPropertyName: "paginatorLocale", publicName: "paginatorLocale", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, columns: { classPropertyName: "columns", publicName: "columns", isSignal: true, isRequired: false, transformFunction: null }, first: { classPropertyName: "first", publicName: "first", isSignal: true, isRequired: false, transformFunction: null }, rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: false, transformFunction: null }, totalRecords: { classPropertyName: "totalRecords", publicName: "totalRecords", isSignal: true, isRequired: false, transformFunction: null }, sortField: { classPropertyName: "sortField", publicName: "sortField", isSignal: true, isRequired: false, transformFunction: null }, sortOrder: { classPropertyName: "sortOrder", publicName: "sortOrder", isSignal: true, isRequired: false, transformFunction: null }, multiSortMeta: { classPropertyName: "multiSortMeta", publicName: "multiSortMeta", isSignal: true, isRequired: false, transformFunction: null }, selection: { classPropertyName: "selection", publicName: "selection", isSignal: true, isRequired: false, transformFunction: null }, selectAll: { classPropertyName: "selectAll", publicName: "selectAll", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { contextMenuSelectionChange: "contextMenuSelectionChange", selectAllChange: "selectAllChange", selectionChange: "selectionChange", onRowSelect: "onRowSelect", onRowUnselect: "onRowUnselect", onPage: "onPage", onSort: "onSort", onFilter: "onFilter", onLazyLoad: "onLazyLoad", onRowExpand: "onRowExpand", onRowCollapse: "onRowCollapse", onContextMenuSelect: "onContextMenuSelect", onColResize: "onColResize", onColReorder: "onColReorder", onRowReorder: "onRowReorder", onEditInit: "onEditInit", onEditComplete: "onEditComplete", onEditCancel: "onEditCancel", onHeaderCheckboxToggle: "onHeaderCheckboxToggle", sortFunction: "sortFunction", firstChange: "firstChange", rowsChange: "rowsChange", onStateSave: "onStateSave", onStateRestore: "onStateRestore" }, host: { properties: { "class": "cn(cx('root'), styleClass())", "attr.data-p": "dataP" } }, providers: [TableService, TableStyle, { provide: TABLE_INSTANCE, useExisting: Table }, { provide: PARENT_INSTANCE, useExisting: Table }], queries: [{ propertyName: "_templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "_headerTemplate", first: true, predicate: ["header"], isSignal: true }, { propertyName: "_headerGroupedTemplate", first: true, predicate: ["headergrouped"], isSignal: true }, { propertyName: "_bodyTemplate", first: true, predicate: ["body"], isSignal: true }, { propertyName: "_loadingBodyTemplate", first: true, predicate: ["loadingbody"], isSignal: true }, { propertyName: "_colGroupTemplate", first: true, predicate: ["colgroup"], isSignal: true }, { propertyName: "_frozenHeaderTemplate", first: true, predicate: ["frozenheader"], isSignal: true }, { propertyName: "_frozenFooterTemplate", first: true, predicate: ["frozenfooter"], isSignal: true }, { propertyName: "_frozenColGroupTemplate", first: true, predicate: ["frozencolgroup"], isSignal: true }, { propertyName: "_emptyMessageTemplate", first: true, predicate: ["emptymessage"], isSignal: true }, { propertyName: "_paginatorLeftTemplate", first: true, predicate: ["paginatorleft"], isSignal: true }, { propertyName: "_paginatorRightTemplate", first: true, predicate: ["paginatorright"], isSignal: true }, { propertyName: "_paginatorDropdownItemTemplate", first: true, predicate: ["paginatordropdownitem"], isSignal: true }, { propertyName: "_reorderIndicatorUpIconTemplate", first: true, predicate: ["reorderindicatorupicon"], isSignal: true }, { propertyName: "_reorderIndicatorDownIconTemplate", first: true, predicate: ["reorderindicatordownicon"], isSignal: true }, { propertyName: "_checkboxIconTemplate", first: true, predicate: ["checkboxicon"], isSignal: true }, { propertyName: "_headerCheckboxIconTemplate", first: true, predicate: ["headercheckboxicon"], isSignal: true }, { propertyName: "_captionTemplate", first: true, predicate: ["caption"] }, { propertyName: "_footerTemplate", first: true, predicate: ["footer"] }, { propertyName: "_footerGroupedTemplate", first: true, predicate: ["footergrouped"] }, { propertyName: "_summaryTemplate", first: true, predicate: ["summary"] }, { propertyName: "_expandedRowTemplate", first: true, predicate: ["expandedrow"] }, { propertyName: "_groupHeaderTemplate", first: true, predicate: ["groupheader"] }, { propertyName: "_groupFooterTemplate", first: true, predicate: ["groupfooter"] }, { propertyName: "_frozenExpandedRowTemplate", first: true, predicate: ["frozenexpandedrow"] }, { propertyName: "_frozenBodyTemplate", first: true, predicate: ["frozenbody"] }, { propertyName: "_loadingIconTemplate", first: true, predicate: ["loadingicon"] }, { propertyName: "_sortIconTemplate", first: true, predicate: ["sorticon"] }, { propertyName: "_paginatorDropdownIconTemplate", first: true, predicate: ["paginatordropdownicon"] }, { propertyName: "_paginatorFirstPageLinkIconTemplate", first: true, predicate: ["paginatorfirstpagelinkicon"] }, { propertyName: "_paginatorLastPageLinkIconTemplate", first: true, predicate: ["paginatorlastpagelinkicon"] }, { propertyName: "_paginatorPreviousPageLinkIconTemplate", first: true, predicate: ["paginatorpreviouspagelinkicon"] }, { propertyName: "_paginatorNextPageLinkIconTemplate", first: true, predicate: ["paginatornextpagelinkicon"] }], viewQueries: [{ propertyName: "resizeHelperViewChild", first: true, predicate: ["resizeHelper"], descendants: true, isSignal: true }, { propertyName: "reorderIndicatorUpViewChild", first: true, predicate: ["reorderIndicatorUp"], descendants: true, isSignal: true }, { propertyName: "reorderIndicatorDownViewChild", first: true, predicate: ["reorderIndicatorDown"], descendants: true, isSignal: true }, { propertyName: "wrapperViewChild", first: true, predicate: ["wrapper"], descendants: true, isSignal: true }, { propertyName: "tableViewChild", first: true, predicate: ["table"], descendants: true, isSignal: true }, { propertyName: "tableHeaderViewChild", first: true, predicate: ["thead"], descendants: true, isSignal: true }, { propertyName: "tableFooterViewChild", first: true, predicate: ["tfoot"], descendants: true, isSignal: true }, { propertyName: "scroller", first: true, predicate: ["scroller"], descendants: true, isSignal: true }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        @if (loading() && showLoader()) {
            <div [class]="cx('mask')" [pBind]="ptm('mask')" animate.enter="p-overlay-mask-enter-active" animate.leave="p-overlay-mask-leave-active">
                @if (loadingIcon()) {
                    <i [class]="cn(cx('loadingIcon'), loadingIcon())" [pBind]="ptm('loadingIcon')"></i>
                }
                @if (!loadingIcon()) {
                    @if (!loadingIconTemplate && !_loadingIconTemplate) {
                        <svg data-p-icon="spinner" [spin]="true" [class]="cx('loadingIcon')" [pBind]="ptm('loadingIcon')" />
                    }
                    @if (loadingIconTemplate || _loadingIconTemplate) {
                        <span [class]="cx('loadingIcon')" [pBind]="ptm('loadingIcon')">
                            <ng-template *ngTemplateOutlet="loadingIconTemplate || _loadingIconTemplate"></ng-template>
                        </span>
                    }
                }
            </div>
        }
        @if (captionTemplate || _captionTemplate) {
            <div [class]="cx('header')" [pBind]="ptm('header')">
                <ng-container *ngTemplateOutlet="captionTemplate || _captionTemplate"></ng-container>
            </div>
        }
        @if (paginator() && (paginatorPosition() === 'top' || paginatorPosition() === 'both')) {
            <p-paginator
                [rows]="_rows"
                [first]="_first"
                [totalRecords]="totalRecords()"
                [pageLinkSize]="pageLinks()"
                [alwaysShow]="alwaysShowPaginator()"
                (onPageChange)="onPageChange($event)"
                [rowsPerPageOptions]="rowsPerPageOptions()"
                [templateLeft]="paginatorLeftTemplate || _paginatorLeftTemplate()"
                [templateRight]="paginatorRightTemplate || _paginatorRightTemplate()"
                [appendTo]="paginatorDropdownAppendTo()"
                [dropdownScrollHeight]="paginatorDropdownScrollHeight()"
                [currentPageReportTemplate]="currentPageReportTemplate()"
                [showFirstLastIcon]="showFirstLastIcon()"
                [dropdownItemTemplate]="paginatorDropdownItemTemplate || _paginatorDropdownItemTemplate()"
                [showCurrentPageReport]="showCurrentPageReport()"
                [showJumpToPageDropdown]="showJumpToPageDropdown()"
                [showJumpToPageInput]="showJumpToPageInput()"
                [showPageLinks]="showPageLinks()"
                [styleClass]="cx('pcPaginator') + ' ' + paginatorStyleClass() && paginatorStyleClass()"
                [locale]="paginatorLocale()"
                [pt]="ptm('pcPaginator')"
                [unstyled]="unstyled()"
            >
                @if (paginatorDropdownIconTemplate || _paginatorDropdownIconTemplate) {
                    <ng-template pTemplate="dropdownicon">
                        <ng-container *ngTemplateOutlet="paginatorDropdownIconTemplate || _paginatorDropdownIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorFirstPageLinkIconTemplate || _paginatorFirstPageLinkIconTemplate) {
                    <ng-template pTemplate="firstpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorFirstPageLinkIconTemplate || _paginatorFirstPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorPreviousPageLinkIconTemplate || _paginatorPreviousPageLinkIconTemplate) {
                    <ng-template pTemplate="previouspagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorPreviousPageLinkIconTemplate || _paginatorPreviousPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorLastPageLinkIconTemplate || _paginatorLastPageLinkIconTemplate) {
                    <ng-template pTemplate="lastpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorLastPageLinkIconTemplate || _paginatorLastPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorNextPageLinkIconTemplate || _paginatorNextPageLinkIconTemplate) {
                    <ng-template pTemplate="nextpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorNextPageLinkIconTemplate || _paginatorNextPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
            </p-paginator>
        }

        <div #wrapper [class]="cx('tableContainer')" [ngStyle]="sx('tableContainer')" [pBind]="ptm('tableContainer')" [attr.data-p]="dataP">
            @if (virtualScroll()) {
                <p-scroller
                    #scroller
                    [items]="processedData"
                    [columns]="_columns"
                    [style]="{
                        height: scrollHeight() !== 'flex' ? scrollHeight() : undefined
                    }"
                    [scrollHeight]="scrollHeight() !== 'flex' ? undefined : '100%'"
                    [itemSize]="virtualScrollItemSize()"
                    [step]="_rows"
                    [delay]="lazy() ? virtualScrollDelay() : 0"
                    [inline]="true"
                    [autoSize]="true"
                    [lazy]="lazy()"
                    (onLazyLoad)="onLazyItemLoad($event)"
                    [loaderDisabled]="true"
                    [showSpacer]="false"
                    [showLoader]="loadingBodyTemplate || _loadingBodyTemplate()"
                    [options]="virtualScrollOptions()"
                    [pt]="ptm('virtualScroller')"
                >
                    <ng-template #content let-items let-scrollerOptions="options">
                        <ng-container
                            *ngTemplateOutlet="
                                buildInTable;
                                context: {
                                    $implicit: items,
                                    options: scrollerOptions
                                }
                            "
                        ></ng-container>
                    </ng-template>
                </p-scroller>
            }
            @if (!virtualScroll()) {
                <ng-container
                    *ngTemplateOutlet="
                        buildInTable;
                        context: {
                            $implicit: processedData,
                            options: { columns: _columns }
                        }
                    "
                ></ng-container>
            }

            <ng-template #buildInTable let-items let-scrollerOptions="options">
                <table #table role="table" [class]="cn(cx('table'), tableStyleClass())" [pBind]="ptm('table')" [style]="tableStyle()" [attr.id]="id + '-table'">
                    <ng-container *ngTemplateOutlet="colGroupTemplate || _colGroupTemplate(); context: { $implicit: scrollerOptions.columns }"></ng-container>
                    <thead role="rowgroup" #thead [class]="cx('thead')" [ngStyle]="sx('thead')" [pBind]="ptm('thead')">
                        <ng-container
                            *ngTemplateOutlet="
                                headerGroupedTemplate || headerTemplate || _headerTemplate();
                                context: {
                                    $implicit: scrollerOptions.columns
                                }
                            "
                        ></ng-container>
                    </thead>
                    @if (frozenValue() || frozenBodyTemplate || _frozenBodyTemplate) {
                        <tbody
                            role="rowgroup"
                            [class]="cx('tbody')"
                            [pBind]="ptm('tbody')"
                            [value]="frozenValue()"
                            [frozenRows]="true"
                            [pTableBody]="scrollerOptions.columns"
                            [pTableBodyTemplate]="frozenBodyTemplate || _frozenBodyTemplate"
                            [unstyled]="unstyled()"
                            [frozen]="true"
                            [attr.data-p-virtualscroll]="virtualScroll()"
                        ></tbody>
                    }
                    <tbody
                        role="rowgroup"
                        [class]="cx('tbody', scrollerOptions.contentStyleClass)"
                        [pBind]="ptm('tbody')"
                        [style]="scrollerOptions.contentStyle"
                        [value]="dataToRender(scrollerOptions.rows)"
                        [pTableBody]="scrollerOptions.columns"
                        [pTableBodyTemplate]="bodyTemplate || _bodyTemplate()"
                        [scrollerOptions]="scrollerOptions"
                        [unstyled]="unstyled()"
                        [attr.data-p-virtualscroll]="virtualScroll()"
                    ></tbody>
                    @if (scrollerOptions.spacerStyle) {
                        <tbody
                            role="rowgroup"
                            [style]="'height: calc(' + scrollerOptions.spacerStyle.height + ' - ' + scrollerOptions.rows.length * scrollerOptions.itemSize + 'px);'"
                            [class]="cx('virtualScrollerSpacer')"
                            [pBind]="ptm('virtualScrollerSpacer')"
                        ></tbody>
                    }
                    @if (footerGroupedTemplate || footerTemplate || _footerTemplate || _footerGroupedTemplate) {
                        <tfoot role="rowgroup" #tfoot [ngClass]="cx('footer')" [ngStyle]="sx('tfoot')" [pBind]="ptm('tfoot')">
                            <ng-container
                                *ngTemplateOutlet="
                                    footerGroupedTemplate || footerTemplate || _footerTemplate || _footerGroupedTemplate;
                                    context: {
                                        $implicit: scrollerOptions.columns
                                    }
                                "
                            ></ng-container>
                        </tfoot>
                    }
                </table>
            </ng-template>
        </div>

        @if (paginator() && (paginatorPosition() === 'bottom' || paginatorPosition() === 'both')) {
            <p-paginator
                [rows]="_rows"
                [first]="_first"
                [totalRecords]="totalRecords()"
                [pageLinkSize]="pageLinks()"
                [alwaysShow]="alwaysShowPaginator()"
                (onPageChange)="onPageChange($event)"
                [rowsPerPageOptions]="rowsPerPageOptions()"
                [templateLeft]="paginatorLeftTemplate || _paginatorLeftTemplate()"
                [templateRight]="paginatorRightTemplate || _paginatorRightTemplate()"
                [appendTo]="paginatorDropdownAppendTo()"
                [dropdownScrollHeight]="paginatorDropdownScrollHeight()"
                [currentPageReportTemplate]="currentPageReportTemplate()"
                [showFirstLastIcon]="showFirstLastIcon()"
                [dropdownItemTemplate]="paginatorDropdownItemTemplate || _paginatorDropdownItemTemplate()"
                [showCurrentPageReport]="showCurrentPageReport()"
                [showJumpToPageDropdown]="showJumpToPageDropdown()"
                [showJumpToPageInput]="showJumpToPageInput()"
                [showPageLinks]="showPageLinks()"
                [styleClass]="cx('pcPaginator') + ' ' + paginatorStyleClass() && paginatorStyleClass()"
                [locale]="paginatorLocale()"
                [pt]="ptm('pcPaginator')"
                [unstyled]="unstyled()"
            >
                @if (paginatorDropdownIconTemplate || _paginatorDropdownIconTemplate) {
                    <ng-template pTemplate="dropdownicon">
                        <ng-container *ngTemplateOutlet="paginatorDropdownIconTemplate || _paginatorDropdownIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorFirstPageLinkIconTemplate || _paginatorFirstPageLinkIconTemplate) {
                    <ng-template pTemplate="firstpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorFirstPageLinkIconTemplate || _paginatorFirstPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorPreviousPageLinkIconTemplate || _paginatorPreviousPageLinkIconTemplate) {
                    <ng-template pTemplate="previouspagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorPreviousPageLinkIconTemplate || _paginatorPreviousPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorLastPageLinkIconTemplate || _paginatorLastPageLinkIconTemplate) {
                    <ng-template pTemplate="lastpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorLastPageLinkIconTemplate || _paginatorLastPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorNextPageLinkIconTemplate || _paginatorNextPageLinkIconTemplate) {
                    <ng-template pTemplate="nextpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorNextPageLinkIconTemplate || _paginatorNextPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
            </p-paginator>
        }

        @if (summaryTemplate || _summaryTemplate) {
            <div [ngClass]="cx('footer')" [pBind]="ptm('footer')">
                <ng-container *ngTemplateOutlet="summaryTemplate || _summaryTemplate"></ng-container>
            </div>
        }

        @if (resizableColumns()) {
            <div #resizeHelper [ngClass]="cx('columnResizeIndicator')" [pBind]="ptm('columnResizeIndicator')" [style.display]="'none'"></div>
        }
        @if (reorderableColumns()) {
            <span #reorderIndicatorUp [ngClass]="cx('rowReorderIndicatorUp')" [pBind]="ptm('rowReorderIndicatorUp')" [style.display]="'none'">
                @if (!reorderIndicatorUpIconTemplate && !_reorderIndicatorUpIconTemplate()) {
                    <svg data-p-icon="arrow-down" [pBind]="ptm('rowReorderIndicatorUp')['icon']" />
                }
                <ng-template *ngTemplateOutlet="reorderIndicatorUpIconTemplate || _reorderIndicatorUpIconTemplate()"></ng-template>
            </span>
        }
        @if (reorderableColumns()) {
            <span #reorderIndicatorDown [ngClass]="cx('rowReorderIndicatorDown')" [pBind]="ptm('rowReorderIndicatorDown')" [style.display]="'none'">
                @if (!reorderIndicatorDownIconTemplate && !_reorderIndicatorDownIconTemplate()) {
                    <svg data-p-icon="arrow-up" [pBind]="ptm('rowReorderIndicatorDown')['icon']" />
                }
                <ng-template *ngTemplateOutlet="reorderIndicatorDownIconTemplate || _reorderIndicatorDownIconTemplate()"></ng-template>
            </span>
        }
    `, isInline: true, dependencies: [{ kind: "directive", type: i0.forwardRef(() => Bind), selector: "[pBind]", inputs: ["pBind"] }, { kind: "component", type: i0.forwardRef(() => SpinnerIcon), selector: "[data-p-icon=\"spinner\"]" }, { kind: "directive", type: i0.forwardRef(() => NgTemplateOutlet), selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: i0.forwardRef(() => Paginator), selector: "p-paginator", inputs: ["pageLinkSize", "styleClass", "alwaysShow", "dropdownAppendTo", "templateLeft", "templateRight", "dropdownScrollHeight", "currentPageReportTemplate", "showCurrentPageReport", "showFirstLastIcon", "totalRecords", "rows", "rowsPerPageOptions", "showJumpToPageDropdown", "showJumpToPageInput", "jumpToPageItemTemplate", "showPageLinks", "locale", "dropdownItemTemplate", "first", "appendTo"], outputs: ["rowsChange", "onPageChange"] }, { kind: "directive", type: i0.forwardRef(() => PrimeTemplate), selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "directive", type: i0.forwardRef(() => NgStyle), selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: i0.forwardRef(() => Scroller), selector: "p-scroller, p-virtualscroller, p-virtual-scroller, p-virtualScroller", inputs: ["hostName", "id", "style", "styleClass", "tabindex", "items", "itemSize", "scrollHeight", "scrollWidth", "orientation", "step", "delay", "resizeDelay", "appendOnly", "inline", "lazy", "disabled", "loaderDisabled", "columns", "showSpacer", "showLoader", "numToleratedItems", "loading", "autoSize", "trackBy", "options"], outputs: ["onLazyLoad", "onScroll", "onScrollIndexChange"] }, { kind: "component", type: i0.forwardRef(() => TableBody), selector: "[pTableBody]", inputs: ["pTableBody", "pTableBodyTemplate", "value", "frozen", "frozenRows", "scrollerOptions"] }, { kind: "directive", type: i0.forwardRef(() => NgClass), selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: i0.forwardRef(() => ArrowDownIcon), selector: "[data-p-icon=\"arrow-down\"]" }, { kind: "component", type: i0.forwardRef(() => ArrowUpIcon), selector: "[data-p-icon=\"arrow-up\"]" }, { kind: "ngmodule", type: i0.forwardRef(() => TableModule) }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Table, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-table',
                    template: `
        @if (loading() && showLoader()) {
            <div [class]="cx('mask')" [pBind]="ptm('mask')" animate.enter="p-overlay-mask-enter-active" animate.leave="p-overlay-mask-leave-active">
                @if (loadingIcon()) {
                    <i [class]="cn(cx('loadingIcon'), loadingIcon())" [pBind]="ptm('loadingIcon')"></i>
                }
                @if (!loadingIcon()) {
                    @if (!loadingIconTemplate && !_loadingIconTemplate) {
                        <svg data-p-icon="spinner" [spin]="true" [class]="cx('loadingIcon')" [pBind]="ptm('loadingIcon')" />
                    }
                    @if (loadingIconTemplate || _loadingIconTemplate) {
                        <span [class]="cx('loadingIcon')" [pBind]="ptm('loadingIcon')">
                            <ng-template *ngTemplateOutlet="loadingIconTemplate || _loadingIconTemplate"></ng-template>
                        </span>
                    }
                }
            </div>
        }
        @if (captionTemplate || _captionTemplate) {
            <div [class]="cx('header')" [pBind]="ptm('header')">
                <ng-container *ngTemplateOutlet="captionTemplate || _captionTemplate"></ng-container>
            </div>
        }
        @if (paginator() && (paginatorPosition() === 'top' || paginatorPosition() === 'both')) {
            <p-paginator
                [rows]="_rows"
                [first]="_first"
                [totalRecords]="totalRecords()"
                [pageLinkSize]="pageLinks()"
                [alwaysShow]="alwaysShowPaginator()"
                (onPageChange)="onPageChange($event)"
                [rowsPerPageOptions]="rowsPerPageOptions()"
                [templateLeft]="paginatorLeftTemplate || _paginatorLeftTemplate()"
                [templateRight]="paginatorRightTemplate || _paginatorRightTemplate()"
                [appendTo]="paginatorDropdownAppendTo()"
                [dropdownScrollHeight]="paginatorDropdownScrollHeight()"
                [currentPageReportTemplate]="currentPageReportTemplate()"
                [showFirstLastIcon]="showFirstLastIcon()"
                [dropdownItemTemplate]="paginatorDropdownItemTemplate || _paginatorDropdownItemTemplate()"
                [showCurrentPageReport]="showCurrentPageReport()"
                [showJumpToPageDropdown]="showJumpToPageDropdown()"
                [showJumpToPageInput]="showJumpToPageInput()"
                [showPageLinks]="showPageLinks()"
                [styleClass]="cx('pcPaginator') + ' ' + paginatorStyleClass() && paginatorStyleClass()"
                [locale]="paginatorLocale()"
                [pt]="ptm('pcPaginator')"
                [unstyled]="unstyled()"
            >
                @if (paginatorDropdownIconTemplate || _paginatorDropdownIconTemplate) {
                    <ng-template pTemplate="dropdownicon">
                        <ng-container *ngTemplateOutlet="paginatorDropdownIconTemplate || _paginatorDropdownIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorFirstPageLinkIconTemplate || _paginatorFirstPageLinkIconTemplate) {
                    <ng-template pTemplate="firstpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorFirstPageLinkIconTemplate || _paginatorFirstPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorPreviousPageLinkIconTemplate || _paginatorPreviousPageLinkIconTemplate) {
                    <ng-template pTemplate="previouspagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorPreviousPageLinkIconTemplate || _paginatorPreviousPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorLastPageLinkIconTemplate || _paginatorLastPageLinkIconTemplate) {
                    <ng-template pTemplate="lastpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorLastPageLinkIconTemplate || _paginatorLastPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorNextPageLinkIconTemplate || _paginatorNextPageLinkIconTemplate) {
                    <ng-template pTemplate="nextpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorNextPageLinkIconTemplate || _paginatorNextPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
            </p-paginator>
        }

        <div #wrapper [class]="cx('tableContainer')" [ngStyle]="sx('tableContainer')" [pBind]="ptm('tableContainer')" [attr.data-p]="dataP">
            @if (virtualScroll()) {
                <p-scroller
                    #scroller
                    [items]="processedData"
                    [columns]="_columns"
                    [style]="{
                        height: scrollHeight() !== 'flex' ? scrollHeight() : undefined
                    }"
                    [scrollHeight]="scrollHeight() !== 'flex' ? undefined : '100%'"
                    [itemSize]="virtualScrollItemSize()"
                    [step]="_rows"
                    [delay]="lazy() ? virtualScrollDelay() : 0"
                    [inline]="true"
                    [autoSize]="true"
                    [lazy]="lazy()"
                    (onLazyLoad)="onLazyItemLoad($event)"
                    [loaderDisabled]="true"
                    [showSpacer]="false"
                    [showLoader]="loadingBodyTemplate || _loadingBodyTemplate()"
                    [options]="virtualScrollOptions()"
                    [pt]="ptm('virtualScroller')"
                >
                    <ng-template #content let-items let-scrollerOptions="options">
                        <ng-container
                            *ngTemplateOutlet="
                                buildInTable;
                                context: {
                                    $implicit: items,
                                    options: scrollerOptions
                                }
                            "
                        ></ng-container>
                    </ng-template>
                </p-scroller>
            }
            @if (!virtualScroll()) {
                <ng-container
                    *ngTemplateOutlet="
                        buildInTable;
                        context: {
                            $implicit: processedData,
                            options: { columns: _columns }
                        }
                    "
                ></ng-container>
            }

            <ng-template #buildInTable let-items let-scrollerOptions="options">
                <table #table role="table" [class]="cn(cx('table'), tableStyleClass())" [pBind]="ptm('table')" [style]="tableStyle()" [attr.id]="id + '-table'">
                    <ng-container *ngTemplateOutlet="colGroupTemplate || _colGroupTemplate(); context: { $implicit: scrollerOptions.columns }"></ng-container>
                    <thead role="rowgroup" #thead [class]="cx('thead')" [ngStyle]="sx('thead')" [pBind]="ptm('thead')">
                        <ng-container
                            *ngTemplateOutlet="
                                headerGroupedTemplate || headerTemplate || _headerTemplate();
                                context: {
                                    $implicit: scrollerOptions.columns
                                }
                            "
                        ></ng-container>
                    </thead>
                    @if (frozenValue() || frozenBodyTemplate || _frozenBodyTemplate) {
                        <tbody
                            role="rowgroup"
                            [class]="cx('tbody')"
                            [pBind]="ptm('tbody')"
                            [value]="frozenValue()"
                            [frozenRows]="true"
                            [pTableBody]="scrollerOptions.columns"
                            [pTableBodyTemplate]="frozenBodyTemplate || _frozenBodyTemplate"
                            [unstyled]="unstyled()"
                            [frozen]="true"
                            [attr.data-p-virtualscroll]="virtualScroll()"
                        ></tbody>
                    }
                    <tbody
                        role="rowgroup"
                        [class]="cx('tbody', scrollerOptions.contentStyleClass)"
                        [pBind]="ptm('tbody')"
                        [style]="scrollerOptions.contentStyle"
                        [value]="dataToRender(scrollerOptions.rows)"
                        [pTableBody]="scrollerOptions.columns"
                        [pTableBodyTemplate]="bodyTemplate || _bodyTemplate()"
                        [scrollerOptions]="scrollerOptions"
                        [unstyled]="unstyled()"
                        [attr.data-p-virtualscroll]="virtualScroll()"
                    ></tbody>
                    @if (scrollerOptions.spacerStyle) {
                        <tbody
                            role="rowgroup"
                            [style]="'height: calc(' + scrollerOptions.spacerStyle.height + ' - ' + scrollerOptions.rows.length * scrollerOptions.itemSize + 'px);'"
                            [class]="cx('virtualScrollerSpacer')"
                            [pBind]="ptm('virtualScrollerSpacer')"
                        ></tbody>
                    }
                    @if (footerGroupedTemplate || footerTemplate || _footerTemplate || _footerGroupedTemplate) {
                        <tfoot role="rowgroup" #tfoot [ngClass]="cx('footer')" [ngStyle]="sx('tfoot')" [pBind]="ptm('tfoot')">
                            <ng-container
                                *ngTemplateOutlet="
                                    footerGroupedTemplate || footerTemplate || _footerTemplate || _footerGroupedTemplate;
                                    context: {
                                        $implicit: scrollerOptions.columns
                                    }
                                "
                            ></ng-container>
                        </tfoot>
                    }
                </table>
            </ng-template>
        </div>

        @if (paginator() && (paginatorPosition() === 'bottom' || paginatorPosition() === 'both')) {
            <p-paginator
                [rows]="_rows"
                [first]="_first"
                [totalRecords]="totalRecords()"
                [pageLinkSize]="pageLinks()"
                [alwaysShow]="alwaysShowPaginator()"
                (onPageChange)="onPageChange($event)"
                [rowsPerPageOptions]="rowsPerPageOptions()"
                [templateLeft]="paginatorLeftTemplate || _paginatorLeftTemplate()"
                [templateRight]="paginatorRightTemplate || _paginatorRightTemplate()"
                [appendTo]="paginatorDropdownAppendTo()"
                [dropdownScrollHeight]="paginatorDropdownScrollHeight()"
                [currentPageReportTemplate]="currentPageReportTemplate()"
                [showFirstLastIcon]="showFirstLastIcon()"
                [dropdownItemTemplate]="paginatorDropdownItemTemplate || _paginatorDropdownItemTemplate()"
                [showCurrentPageReport]="showCurrentPageReport()"
                [showJumpToPageDropdown]="showJumpToPageDropdown()"
                [showJumpToPageInput]="showJumpToPageInput()"
                [showPageLinks]="showPageLinks()"
                [styleClass]="cx('pcPaginator') + ' ' + paginatorStyleClass() && paginatorStyleClass()"
                [locale]="paginatorLocale()"
                [pt]="ptm('pcPaginator')"
                [unstyled]="unstyled()"
            >
                @if (paginatorDropdownIconTemplate || _paginatorDropdownIconTemplate) {
                    <ng-template pTemplate="dropdownicon">
                        <ng-container *ngTemplateOutlet="paginatorDropdownIconTemplate || _paginatorDropdownIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorFirstPageLinkIconTemplate || _paginatorFirstPageLinkIconTemplate) {
                    <ng-template pTemplate="firstpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorFirstPageLinkIconTemplate || _paginatorFirstPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorPreviousPageLinkIconTemplate || _paginatorPreviousPageLinkIconTemplate) {
                    <ng-template pTemplate="previouspagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorPreviousPageLinkIconTemplate || _paginatorPreviousPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorLastPageLinkIconTemplate || _paginatorLastPageLinkIconTemplate) {
                    <ng-template pTemplate="lastpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorLastPageLinkIconTemplate || _paginatorLastPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
                @if (paginatorNextPageLinkIconTemplate || _paginatorNextPageLinkIconTemplate) {
                    <ng-template pTemplate="nextpagelinkicon">
                        <ng-container *ngTemplateOutlet="paginatorNextPageLinkIconTemplate || _paginatorNextPageLinkIconTemplate"></ng-container>
                    </ng-template>
                }
            </p-paginator>
        }

        @if (summaryTemplate || _summaryTemplate) {
            <div [ngClass]="cx('footer')" [pBind]="ptm('footer')">
                <ng-container *ngTemplateOutlet="summaryTemplate || _summaryTemplate"></ng-container>
            </div>
        }

        @if (resizableColumns()) {
            <div #resizeHelper [ngClass]="cx('columnResizeIndicator')" [pBind]="ptm('columnResizeIndicator')" [style.display]="'none'"></div>
        }
        @if (reorderableColumns()) {
            <span #reorderIndicatorUp [ngClass]="cx('rowReorderIndicatorUp')" [pBind]="ptm('rowReorderIndicatorUp')" [style.display]="'none'">
                @if (!reorderIndicatorUpIconTemplate && !_reorderIndicatorUpIconTemplate()) {
                    <svg data-p-icon="arrow-down" [pBind]="ptm('rowReorderIndicatorUp')['icon']" />
                }
                <ng-template *ngTemplateOutlet="reorderIndicatorUpIconTemplate || _reorderIndicatorUpIconTemplate()"></ng-template>
            </span>
        }
        @if (reorderableColumns()) {
            <span #reorderIndicatorDown [ngClass]="cx('rowReorderIndicatorDown')" [pBind]="ptm('rowReorderIndicatorDown')" [style.display]="'none'">
                @if (!reorderIndicatorDownIconTemplate && !_reorderIndicatorDownIconTemplate()) {
                    <svg data-p-icon="arrow-up" [pBind]="ptm('rowReorderIndicatorDown')['icon']" />
                }
                <ng-template *ngTemplateOutlet="reorderIndicatorDownIconTemplate || _reorderIndicatorDownIconTemplate()"></ng-template>
            </span>
        }
    `,
                    providers: [TableService, TableStyle, { provide: TABLE_INSTANCE, useExisting: Table }, { provide: PARENT_INSTANCE, useExisting: Table }],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[class]': "cn(cx('root'), styleClass())",
                        '[attr.data-p]': 'dataP'
                    },
                    hostDirectives: [Bind],
                    imports: [Bind, SpinnerIcon, NgTemplateOutlet, Paginator, PrimeTemplate, NgStyle, Scroller, forwardRef(() => TableBody), NgClass, ArrowDownIcon, ArrowUpIcon, forwardRef(() => TableModule)]
                }]
        }], ctorParameters: () => [], propDecorators: { frozenColumns: [{ type: i0.Input, args: [{ isSignal: true, alias: "frozenColumns", required: false }] }], frozenValue: [{ type: i0.Input, args: [{ isSignal: true, alias: "frozenValue", required: false }] }], styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], tableStyle: [{ type: i0.Input, args: [{ isSignal: true, alias: "tableStyle", required: false }] }], tableStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "tableStyleClass", required: false }] }], paginator: [{ type: i0.Input, args: [{ isSignal: true, alias: "paginator", required: false }] }], pageLinks: [{ type: i0.Input, args: [{ isSignal: true, alias: "pageLinks", required: false }] }], rowsPerPageOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowsPerPageOptions", required: false }] }], alwaysShowPaginator: [{ type: i0.Input, args: [{ isSignal: true, alias: "alwaysShowPaginator", required: false }] }], paginatorPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "paginatorPosition", required: false }] }], paginatorStyleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "paginatorStyleClass", required: false }] }], paginatorDropdownAppendTo: [{ type: i0.Input, args: [{ isSignal: true, alias: "paginatorDropdownAppendTo", required: false }] }], paginatorDropdownScrollHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "paginatorDropdownScrollHeight", required: false }] }], currentPageReportTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "currentPageReportTemplate", required: false }] }], showCurrentPageReport: [{ type: i0.Input, args: [{ isSignal: true, alias: "showCurrentPageReport", required: false }] }], showJumpToPageDropdown: [{ type: i0.Input, args: [{ isSignal: true, alias: "showJumpToPageDropdown", required: false }] }], showJumpToPageInput: [{ type: i0.Input, args: [{ isSignal: true, alias: "showJumpToPageInput", required: false }] }], showFirstLastIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "showFirstLastIcon", required: false }] }], showPageLinks: [{ type: i0.Input, args: [{ isSignal: true, alias: "showPageLinks", required: false }] }], defaultSortOrder: [{ type: i0.Input, args: [{ isSignal: true, alias: "defaultSortOrder", required: false }] }], sortMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "sortMode", required: false }] }], resetPageOnSort: [{ type: i0.Input, args: [{ isSignal: true, alias: "resetPageOnSort", required: false }] }], selectionMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectionMode", required: false }] }], selectionPageOnly: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectionPageOnly", required: false }] }], contextMenuSelection: [{ type: i0.Input, args: [{ isSignal: true, alias: "contextMenuSelection", required: false }] }], contextMenuSelectionChange: [{ type: i0.Output, args: ["contextMenuSelectionChange"] }], contextMenuSelectionMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "contextMenuSelectionMode", required: false }] }], dataKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "dataKey", required: false }] }], metaKeySelection: [{ type: i0.Input, args: [{ isSignal: true, alias: "metaKeySelection", required: false }] }], rowSelectable: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowSelectable", required: false }] }], rowTrackBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowTrackBy", required: false }] }], lazy: [{ type: i0.Input, args: [{ isSignal: true, alias: "lazy", required: false }] }], lazyLoadOnInit: [{ type: i0.Input, args: [{ isSignal: true, alias: "lazyLoadOnInit", required: false }] }], compareSelectionBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "compareSelectionBy", required: false }] }], csvSeparator: [{ type: i0.Input, args: [{ isSignal: true, alias: "csvSeparator", required: false }] }], exportFilename: [{ type: i0.Input, args: [{ isSignal: true, alias: "exportFilename", required: false }] }], filters: [{ type: i0.Input, args: [{ isSignal: true, alias: "filters", required: false }] }], globalFilterFields: [{ type: i0.Input, args: [{ isSignal: true, alias: "globalFilterFields", required: false }] }], filterDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterDelay", required: false }] }], filterLocale: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterLocale", required: false }] }], expandedRowKeys: [{ type: i0.Input, args: [{ isSignal: true, alias: "expandedRowKeys", required: false }] }], editingRowKeys: [{ type: i0.Input, args: [{ isSignal: true, alias: "editingRowKeys", required: false }] }], rowExpandMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowExpandMode", required: false }] }], scrollable: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollable", required: false }] }], rowGroupMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowGroupMode", required: false }] }], scrollHeight: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollHeight", required: false }] }], virtualScroll: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScroll", required: false }] }], virtualScrollItemSize: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScrollItemSize", required: false }] }], virtualScrollOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScrollOptions", required: false }] }], virtualScrollDelay: [{ type: i0.Input, args: [{ isSignal: true, alias: "virtualScrollDelay", required: false }] }], frozenWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "frozenWidth", required: false }] }], contextMenu: [{ type: i0.Input, args: [{ isSignal: true, alias: "contextMenu", required: false }] }], resizableColumns: [{ type: i0.Input, args: [{ isSignal: true, alias: "resizableColumns", required: false }] }], columnResizeMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "columnResizeMode", required: false }] }], reorderableColumns: [{ type: i0.Input, args: [{ isSignal: true, alias: "reorderableColumns", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], loadingIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "loadingIcon", required: false }] }], showLoader: [{ type: i0.Input, args: [{ isSignal: true, alias: "showLoader", required: false }] }], rowHover: [{ type: i0.Input, args: [{ isSignal: true, alias: "rowHover", required: false }] }], customSort: [{ type: i0.Input, args: [{ isSignal: true, alias: "customSort", required: false }] }], showInitialSortBadge: [{ type: i0.Input, args: [{ isSignal: true, alias: "showInitialSortBadge", required: false }] }], exportFunction: [{ type: i0.Input, args: [{ isSignal: true, alias: "exportFunction", required: false }] }], exportHeader: [{ type: i0.Input, args: [{ isSignal: true, alias: "exportHeader", required: false }] }], stateKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "stateKey", required: false }] }], stateStorage: [{ type: i0.Input, args: [{ isSignal: true, alias: "stateStorage", required: false }] }], editMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "editMode", required: false }] }], groupRowsBy: [{ type: i0.Input, args: [{ isSignal: true, alias: "groupRowsBy", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], showGridlines: [{ type: i0.Input, args: [{ isSignal: true, alias: "showGridlines", required: false }] }], stripedRows: [{ type: i0.Input, args: [{ isSignal: true, alias: "stripedRows", required: false }] }], groupRowsByOrder: [{ type: i0.Input, args: [{ isSignal: true, alias: "groupRowsByOrder", required: false }] }], responsiveLayout: [{ type: i0.Input, args: [{ isSignal: true, alias: "responsiveLayout", required: false }] }], breakpoint: [{ type: i0.Input, args: [{ isSignal: true, alias: "breakpoint", required: false }] }], paginatorLocale: [{ type: i0.Input, args: [{ isSignal: true, alias: "paginatorLocale", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "columns", required: false }] }], first: [{ type: i0.Input, args: [{ isSignal: true, alias: "first", required: false }] }], rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: false }] }], totalRecords: [{ type: i0.Input, args: [{ isSignal: true, alias: "totalRecords", required: false }] }], sortField: [{ type: i0.Input, args: [{ isSignal: true, alias: "sortField", required: false }] }], sortOrder: [{ type: i0.Input, args: [{ isSignal: true, alias: "sortOrder", required: false }] }], multiSortMeta: [{ type: i0.Input, args: [{ isSignal: true, alias: "multiSortMeta", required: false }] }], selection: [{ type: i0.Input, args: [{ isSignal: true, alias: "selection", required: false }] }], selectAll: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectAll", required: false }] }], selectAllChange: [{ type: i0.Output, args: ["selectAllChange"] }], selectionChange: [{ type: i0.Output, args: ["selectionChange"] }], onRowSelect: [{ type: i0.Output, args: ["onRowSelect"] }], onRowUnselect: [{ type: i0.Output, args: ["onRowUnselect"] }], onPage: [{ type: i0.Output, args: ["onPage"] }], onSort: [{ type: i0.Output, args: ["onSort"] }], onFilter: [{ type: i0.Output, args: ["onFilter"] }], onLazyLoad: [{ type: i0.Output, args: ["onLazyLoad"] }], onRowExpand: [{ type: i0.Output, args: ["onRowExpand"] }], onRowCollapse: [{ type: i0.Output, args: ["onRowCollapse"] }], onContextMenuSelect: [{ type: i0.Output, args: ["onContextMenuSelect"] }], onColResize: [{ type: i0.Output, args: ["onColResize"] }], onColReorder: [{ type: i0.Output, args: ["onColReorder"] }], onRowReorder: [{ type: i0.Output, args: ["onRowReorder"] }], onEditInit: [{ type: i0.Output, args: ["onEditInit"] }], onEditComplete: [{ type: i0.Output, args: ["onEditComplete"] }], onEditCancel: [{ type: i0.Output, args: ["onEditCancel"] }], onHeaderCheckboxToggle: [{ type: i0.Output, args: ["onHeaderCheckboxToggle"] }], sortFunction: [{ type: i0.Output, args: ["sortFunction"] }], firstChange: [{ type: i0.Output, args: ["firstChange"] }], rowsChange: [{ type: i0.Output, args: ["rowsChange"] }], onStateSave: [{ type: i0.Output, args: ["onStateSave"] }], onStateRestore: [{ type: i0.Output, args: ["onStateRestore"] }], resizeHelperViewChild: [{ type: i0.ViewChild, args: ['resizeHelper', { isSignal: true }] }], reorderIndicatorUpViewChild: [{ type: i0.ViewChild, args: ['reorderIndicatorUp', { isSignal: true }] }], reorderIndicatorDownViewChild: [{ type: i0.ViewChild, args: ['reorderIndicatorDown', { isSignal: true }] }], wrapperViewChild: [{ type: i0.ViewChild, args: ['wrapper', { isSignal: true }] }], tableViewChild: [{ type: i0.ViewChild, args: ['table', { isSignal: true }] }], tableHeaderViewChild: [{ type: i0.ViewChild, args: ['thead', { isSignal: true }] }], tableFooterViewChild: [{ type: i0.ViewChild, args: ['tfoot', { isSignal: true }] }], scroller: [{ type: i0.ViewChild, args: ['scroller', { isSignal: true }] }], _templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }], _headerTemplate: [{ type: i0.ContentChild, args: ['header', { ...{ descendants: false }, isSignal: true }] }], _headerGroupedTemplate: [{ type: i0.ContentChild, args: ['headergrouped', { ...{ descendants: false }, isSignal: true }] }], _bodyTemplate: [{ type: i0.ContentChild, args: ['body', { ...{ descendants: false }, isSignal: true }] }], _loadingBodyTemplate: [{ type: i0.ContentChild, args: ['loadingbody', { ...{ descendants: false }, isSignal: true }] }], _captionTemplate: [{
                type: ContentChild,
                args: ['caption', { descendants: false }]
            }], _footerTemplate: [{
                type: ContentChild,
                args: ['footer', { descendants: false }]
            }], _footerGroupedTemplate: [{
                type: ContentChild,
                args: ['footergrouped', { descendants: false }]
            }], _summaryTemplate: [{
                type: ContentChild,
                args: ['summary', { descendants: false }]
            }], _colGroupTemplate: [{ type: i0.ContentChild, args: ['colgroup', { ...{ descendants: false }, isSignal: true }] }], _expandedRowTemplate: [{
                type: ContentChild,
                args: ['expandedrow', { descendants: false }]
            }], _groupHeaderTemplate: [{
                type: ContentChild,
                args: ['groupheader', { descendants: false }]
            }], _groupFooterTemplate: [{
                type: ContentChild,
                args: ['groupfooter', { descendants: false }]
            }], _frozenExpandedRowTemplate: [{
                type: ContentChild,
                args: ['frozenexpandedrow', { descendants: false }]
            }], _frozenHeaderTemplate: [{ type: i0.ContentChild, args: ['frozenheader', { ...{ descendants: false }, isSignal: true }] }], _frozenBodyTemplate: [{
                type: ContentChild,
                args: ['frozenbody', { descendants: false }]
            }], _frozenFooterTemplate: [{ type: i0.ContentChild, args: ['frozenfooter', { ...{ descendants: false }, isSignal: true }] }], _frozenColGroupTemplate: [{ type: i0.ContentChild, args: ['frozencolgroup', { ...{ descendants: false }, isSignal: true }] }], _emptyMessageTemplate: [{ type: i0.ContentChild, args: ['emptymessage', { ...{ descendants: false }, isSignal: true }] }], _paginatorLeftTemplate: [{ type: i0.ContentChild, args: ['paginatorleft', { ...{ descendants: false }, isSignal: true }] }], _paginatorRightTemplate: [{ type: i0.ContentChild, args: ['paginatorright', { ...{ descendants: false }, isSignal: true }] }], _paginatorDropdownItemTemplate: [{ type: i0.ContentChild, args: ['paginatordropdownitem', { ...{ descendants: false }, isSignal: true }] }], _loadingIconTemplate: [{
                type: ContentChild,
                args: ['loadingicon', { descendants: false }]
            }], _reorderIndicatorUpIconTemplate: [{ type: i0.ContentChild, args: ['reorderindicatorupicon', { ...{ descendants: false }, isSignal: true }] }], _reorderIndicatorDownIconTemplate: [{ type: i0.ContentChild, args: ['reorderindicatordownicon', { ...{ descendants: false }, isSignal: true }] }], _sortIconTemplate: [{
                type: ContentChild,
                args: ['sorticon', { descendants: false }]
            }], _checkboxIconTemplate: [{ type: i0.ContentChild, args: ['checkboxicon', { ...{ descendants: false }, isSignal: true }] }], _headerCheckboxIconTemplate: [{ type: i0.ContentChild, args: ['headercheckboxicon', { ...{ descendants: false }, isSignal: true }] }], _paginatorDropdownIconTemplate: [{
                type: ContentChild,
                args: ['paginatordropdownicon', { descendants: false }]
            }], _paginatorFirstPageLinkIconTemplate: [{
                type: ContentChild,
                args: ['paginatorfirstpagelinkicon', { descendants: false }]
            }], _paginatorLastPageLinkIconTemplate: [{
                type: ContentChild,
                args: ['paginatorlastpagelinkicon', { descendants: false }]
            }], _paginatorPreviousPageLinkIconTemplate: [{
                type: ContentChild,
                args: ['paginatorpreviouspagelinkicon', { descendants: false }]
            }], _paginatorNextPageLinkIconTemplate: [{
                type: ContentChild,
                args: ['paginatornextpagelinkicon', { descendants: false }]
            }] } });
class TableBody extends BaseComponent {
    dataTable = inject(Table);
    tableService = inject(TableService);
    hostName = 'Table';
    columns = input(undefined, { ...(ngDevMode ? { debugName: "columns" } : /* istanbul ignore next */ {}), alias: 'pTableBody' });
    template = input(undefined, { ...(ngDevMode ? { debugName: "template" } : /* istanbul ignore next */ {}), alias: 'pTableBodyTemplate' });
    value = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "value" }] : /* istanbul ignore next */ []));
    frozen = input(undefined, { ...(ngDevMode ? { debugName: "frozen" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    frozenRows = input(undefined, { ...(ngDevMode ? { debugName: "frozenRows" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    scrollerOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "scrollerOptions" }] : /* istanbul ignore next */ []));
    subscription;
    _value;
    onAfterViewInit() {
        if (this.frozenRows()) {
            this.updateFrozenRowStickyPosition();
        }
        if (this.dataTable.scrollable() && this.dataTable.rowGroupMode() === 'subheader') {
            this.updateFrozenRowGroupHeaderStickyPosition();
        }
    }
    constructor() {
        super();
        this.subscription = this.dataTable.tableService.valueSource$.subscribe(() => {
            if (this.dataTable.virtualScroll()) {
                this.cd.detectChanges();
            }
        });
        effect(() => {
            this._value = this.value();
            if (this.frozenRows()) {
                this.updateFrozenRowStickyPosition();
            }
            if (this.dataTable.scrollable() && this.dataTable.rowGroupMode() === 'subheader') {
                this.updateFrozenRowGroupHeaderStickyPosition();
            }
        });
    }
    shouldRenderRowGroupHeader(value, rowData, i) {
        let currentRowFieldData = ObjectUtils.resolveFieldData(rowData, this.dataTable?.groupRowsBy() || '');
        let prevRowData = value[i - (this.dataTable?._first || 0) - 1];
        if (prevRowData) {
            let previousRowFieldData = ObjectUtils.resolveFieldData(prevRowData, this.dataTable?.groupRowsBy() || '');
            return currentRowFieldData !== previousRowFieldData;
        }
        else {
            return true;
        }
    }
    shouldRenderRowGroupFooter(value, rowData, i) {
        let currentRowFieldData = ObjectUtils.resolveFieldData(rowData, this.dataTable?.groupRowsBy() || '');
        let nextRowData = value[i - (this.dataTable?._first || 0) + 1];
        if (nextRowData) {
            let nextRowFieldData = ObjectUtils.resolveFieldData(nextRowData, this.dataTable?.groupRowsBy() || '');
            return currentRowFieldData !== nextRowFieldData;
        }
        else {
            return true;
        }
    }
    shouldRenderRowspan(value, rowData, i) {
        let currentRowFieldData = ObjectUtils.resolveFieldData(rowData, this.dataTable?.groupRowsBy() || '');
        let prevRowData = value[i - 1];
        if (prevRowData) {
            let previousRowFieldData = ObjectUtils.resolveFieldData(prevRowData, this.dataTable?.groupRowsBy() || '');
            return currentRowFieldData !== previousRowFieldData;
        }
        else {
            return true;
        }
    }
    calculateRowGroupSize(value, rowData, index) {
        let currentRowFieldData = ObjectUtils.resolveFieldData(rowData, this.dataTable?.groupRowsBy() || '');
        let nextRowFieldData = currentRowFieldData;
        let groupRowSpan = 0;
        while (currentRowFieldData === nextRowFieldData) {
            groupRowSpan++;
            let nextRowData = value[++index];
            if (nextRowData) {
                nextRowFieldData = ObjectUtils.resolveFieldData(nextRowData, this.dataTable?.groupRowsBy() || '');
            }
            else {
                break;
            }
        }
        return groupRowSpan === 1 ? null : groupRowSpan;
    }
    onDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    updateFrozenRowStickyPosition() {
        this.el.nativeElement.style.top = DomHandler.getOuterHeight(this.el.nativeElement.previousElementSibling) + 'px';
    }
    updateFrozenRowGroupHeaderStickyPosition() {
        if (this.el.nativeElement.previousElementSibling) {
            let tableHeaderHeight = DomHandler.getOuterHeight(this.el.nativeElement.previousElementSibling);
            this.dataTable.rowGroupHeaderStyleObject.top = tableHeaderHeight + 'px';
        }
    }
    getScrollerOption(option, options) {
        if (this.dataTable.virtualScroll()) {
            options = options || this.scrollerOptions();
            return options ? options[option] : null;
        }
        return null;
    }
    getRowIndex(rowIndex) {
        const index = this.dataTable.paginator() ? this.dataTable._first + rowIndex : rowIndex;
        const getItemOptions = this.getScrollerOption('getItemOptions');
        return getItemOptions ? getItemOptions(index).index : index;
    }
    get dataP() {
        return this.cn({
            hoverable: this.dataTable.rowHover() || this.dataTable.selectionMode(),
            frozen: this.frozen()
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableBody, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: TableBody, isStandalone: true, selector: "[pTableBody]", inputs: { columns: { classPropertyName: "columns", publicName: "pTableBody", isSignal: true, isRequired: false, transformFunction: null }, template: { classPropertyName: "template", publicName: "pTableBodyTemplate", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, frozen: { classPropertyName: "frozen", publicName: "frozen", isSignal: true, isRequired: false, transformFunction: null }, frozenRows: { classPropertyName: "frozenRows", publicName: "frozenRows", isSignal: true, isRequired: false, transformFunction: null }, scrollerOptions: { classPropertyName: "scrollerOptions", publicName: "scrollerOptions", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.data-p": "dataP" } }, usesInheritance: true, ngImport: i0, template: `
        @if (!dataTable.expandedRowTemplate && !dataTable._expandedRowTemplate) {
            @for (rowData of value(); track dataTable.rowTrackBy()(rowIndex, rowData); let rowIndex = $index) {
                @if ((dataTable.groupHeaderTemplate || dataTable._groupHeaderTemplate) && !dataTable.virtualScroll() && dataTable.rowGroupMode() === 'subheader' && shouldRenderRowGroupHeader(value(), rowData, getRowIndex(rowIndex))) {
                    <ng-container role="row">
                        <ng-container
                            *ngTemplateOutlet="
                                dataTable.groupHeaderTemplate || dataTable._groupHeaderTemplate;
                                context: {
                                    $implicit: rowData,
                                    rowIndex: getRowIndex(rowIndex),
                                    columns: columns(),
                                    editing: dataTable.editMode() === 'row' && dataTable.isRowEditing(rowData),
                                    frozen: frozen()
                                }
                            "
                        ></ng-container>
                    </ng-container>
                }
                @if (dataTable.rowGroupMode() !== 'rowspan') {
                    <ng-container
                        *ngTemplateOutlet="
                            rowData ? template() : dataTable.loadingBodyTemplate || dataTable._loadingBodyTemplate();
                            context: {
                                $implicit: rowData,
                                rowIndex: getRowIndex(rowIndex),
                                columns: columns(),
                                editing: dataTable.editMode() === 'row' && dataTable.isRowEditing(rowData),
                                frozen: frozen()
                            }
                        "
                    ></ng-container>
                }
                @if (dataTable.rowGroupMode() === 'rowspan') {
                    <ng-container
                        *ngTemplateOutlet="
                            rowData ? template() : dataTable.loadingBodyTemplate || dataTable._loadingBodyTemplate();
                            context: {
                                $implicit: rowData,
                                rowIndex: getRowIndex(rowIndex),
                                columns: columns(),
                                editing: dataTable.editMode() === 'row' && dataTable.isRowEditing(rowData),
                                frozen: frozen(),
                                rowgroup: shouldRenderRowspan(value(), rowData, rowIndex),
                                rowspan: calculateRowGroupSize(value(), rowData, rowIndex)
                            }
                        "
                    ></ng-container>
                }
                @if ((dataTable.groupFooterTemplate || dataTable._groupFooterTemplate) && !dataTable.virtualScroll() && dataTable.rowGroupMode() === 'subheader' && shouldRenderRowGroupFooter(value(), rowData, getRowIndex(rowIndex))) {
                    <ng-container role="row">
                        <ng-container
                            *ngTemplateOutlet="
                                dataTable.groupFooterTemplate || dataTable._groupFooterTemplate;
                                context: {
                                    $implicit: rowData,
                                    rowIndex: getRowIndex(rowIndex),
                                    columns: columns(),
                                    editing: dataTable.editMode() === 'row' && dataTable.isRowEditing(rowData),
                                    frozen: frozen()
                                }
                            "
                        ></ng-container>
                    </ng-container>
                }
            }
        }
        @if ((dataTable.expandedRowTemplate || dataTable._expandedRowTemplate) && !(frozen() && (dataTable.frozenExpandedRowTemplate || dataTable._frozenExpandedRowTemplate))) {
            @for (rowData of value(); track dataTable.rowTrackBy()(rowIndex, rowData); let rowIndex = $index) {
                @if (!(dataTable.groupHeaderTemplate && dataTable._groupHeaderTemplate)) {
                    <ng-container
                        *ngTemplateOutlet="
                            template();
                            context: {
                                $implicit: rowData,
                                rowIndex: getRowIndex(rowIndex),
                                columns: columns(),
                                expanded: dataTable.isRowExpanded(rowData),
                                editing: dataTable.editMode() === 'row' && dataTable.isRowEditing(rowData),
                                frozen: frozen()
                            }
                        "
                    ></ng-container>
                }
                @if ((dataTable.groupHeaderTemplate || dataTable._groupHeaderTemplate) && dataTable.rowGroupMode() === 'subheader' && shouldRenderRowGroupHeader(value(), rowData, getRowIndex(rowIndex))) {
                    <ng-container role="row">
                        <ng-container
                            *ngTemplateOutlet="
                                dataTable.groupHeaderTemplate || dataTable._groupHeaderTemplate;
                                context: {
                                    $implicit: rowData,
                                    rowIndex: getRowIndex(rowIndex),
                                    columns: columns(),
                                    expanded: dataTable.isRowExpanded(rowData),
                                    editing: dataTable.editMode() === 'row' && dataTable.isRowEditing(rowData),
                                    frozen: frozen()
                                }
                            "
                        ></ng-container>
                    </ng-container>
                }
                @if (dataTable.isRowExpanded(rowData)) {
                    <ng-container
                        *ngTemplateOutlet="
                            dataTable.expandedRowTemplate || dataTable._expandedRowTemplate;
                            context: {
                                $implicit: rowData,
                                rowIndex: getRowIndex(rowIndex),
                                columns: columns(),
                                frozen: frozen()
                            }
                        "
                    ></ng-container>
                    @if ((dataTable.groupFooterTemplate || dataTable._groupFooterTemplate) && dataTable.rowGroupMode() === 'subheader' && shouldRenderRowGroupFooter(value(), rowData, getRowIndex(rowIndex))) {
                        <ng-container role="row">
                            <ng-container
                                *ngTemplateOutlet="
                                    dataTable.groupFooterTemplate || dataTable._groupFooterTemplate;
                                    context: {
                                        $implicit: rowData,
                                        rowIndex: getRowIndex(rowIndex),
                                        columns: columns(),
                                        expanded: dataTable.isRowExpanded(rowData),
                                        editing: dataTable.editMode() === 'row' && dataTable.isRowEditing(rowData),
                                        frozen: frozen()
                                    }
                                "
                            ></ng-container>
                        </ng-container>
                    }
                }
            }
        }
        @if ((dataTable.frozenExpandedRowTemplate || dataTable._frozenExpandedRowTemplate) && frozen()) {
            @for (rowData of value(); track dataTable.rowTrackBy()(rowIndex, rowData); let rowIndex = $index) {
                <ng-container
                    *ngTemplateOutlet="
                        template();
                        context: {
                            $implicit: rowData,
                            rowIndex: getRowIndex(rowIndex),
                            columns: columns(),
                            expanded: dataTable.isRowExpanded(rowData),
                            editing: dataTable.editMode() === 'row' && dataTable.isRowEditing(rowData),
                            frozen: frozen()
                        }
                    "
                ></ng-container>
                @if (dataTable.isRowExpanded(rowData)) {
                    <ng-container
                        *ngTemplateOutlet="
                            dataTable.frozenExpandedRowTemplate || dataTable._frozenExpandedRowTemplate;
                            context: {
                                $implicit: rowData,
                                rowIndex: getRowIndex(rowIndex),
                                columns: columns(),
                                frozen: frozen()
                            }
                        "
                    ></ng-container>
                }
            }
        }
        @if (dataTable.loading()) {
            <ng-container *ngTemplateOutlet="dataTable.loadingBodyTemplate || dataTable._loadingBodyTemplate(); context: { $implicit: columns(), frozen: frozen() }"></ng-container>
        }
        @if (dataTable.isEmpty() && !dataTable.loading()) {
            <ng-container *ngTemplateOutlet="dataTable.emptyMessageTemplate || dataTable._emptyMessageTemplate(); context: { $implicit: columns(), frozen: frozen() }"></ng-container>
        }
    `, isInline: true, dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableBody, decorators: [{
            type: Component,
            args: [{
                    selector: '[pTableBody]',
                    template: `
        @if (!dataTable.expandedRowTemplate && !dataTable._expandedRowTemplate) {
            @for (rowData of value(); track dataTable.rowTrackBy()(rowIndex, rowData); let rowIndex = $index) {
                @if ((dataTable.groupHeaderTemplate || dataTable._groupHeaderTemplate) && !dataTable.virtualScroll() && dataTable.rowGroupMode() === 'subheader' && shouldRenderRowGroupHeader(value(), rowData, getRowIndex(rowIndex))) {
                    <ng-container role="row">
                        <ng-container
                            *ngTemplateOutlet="
                                dataTable.groupHeaderTemplate || dataTable._groupHeaderTemplate;
                                context: {
                                    $implicit: rowData,
                                    rowIndex: getRowIndex(rowIndex),
                                    columns: columns(),
                                    editing: dataTable.editMode() === 'row' && dataTable.isRowEditing(rowData),
                                    frozen: frozen()
                                }
                            "
                        ></ng-container>
                    </ng-container>
                }
                @if (dataTable.rowGroupMode() !== 'rowspan') {
                    <ng-container
                        *ngTemplateOutlet="
                            rowData ? template() : dataTable.loadingBodyTemplate || dataTable._loadingBodyTemplate();
                            context: {
                                $implicit: rowData,
                                rowIndex: getRowIndex(rowIndex),
                                columns: columns(),
                                editing: dataTable.editMode() === 'row' && dataTable.isRowEditing(rowData),
                                frozen: frozen()
                            }
                        "
                    ></ng-container>
                }
                @if (dataTable.rowGroupMode() === 'rowspan') {
                    <ng-container
                        *ngTemplateOutlet="
                            rowData ? template() : dataTable.loadingBodyTemplate || dataTable._loadingBodyTemplate();
                            context: {
                                $implicit: rowData,
                                rowIndex: getRowIndex(rowIndex),
                                columns: columns(),
                                editing: dataTable.editMode() === 'row' && dataTable.isRowEditing(rowData),
                                frozen: frozen(),
                                rowgroup: shouldRenderRowspan(value(), rowData, rowIndex),
                                rowspan: calculateRowGroupSize(value(), rowData, rowIndex)
                            }
                        "
                    ></ng-container>
                }
                @if ((dataTable.groupFooterTemplate || dataTable._groupFooterTemplate) && !dataTable.virtualScroll() && dataTable.rowGroupMode() === 'subheader' && shouldRenderRowGroupFooter(value(), rowData, getRowIndex(rowIndex))) {
                    <ng-container role="row">
                        <ng-container
                            *ngTemplateOutlet="
                                dataTable.groupFooterTemplate || dataTable._groupFooterTemplate;
                                context: {
                                    $implicit: rowData,
                                    rowIndex: getRowIndex(rowIndex),
                                    columns: columns(),
                                    editing: dataTable.editMode() === 'row' && dataTable.isRowEditing(rowData),
                                    frozen: frozen()
                                }
                            "
                        ></ng-container>
                    </ng-container>
                }
            }
        }
        @if ((dataTable.expandedRowTemplate || dataTable._expandedRowTemplate) && !(frozen() && (dataTable.frozenExpandedRowTemplate || dataTable._frozenExpandedRowTemplate))) {
            @for (rowData of value(); track dataTable.rowTrackBy()(rowIndex, rowData); let rowIndex = $index) {
                @if (!(dataTable.groupHeaderTemplate && dataTable._groupHeaderTemplate)) {
                    <ng-container
                        *ngTemplateOutlet="
                            template();
                            context: {
                                $implicit: rowData,
                                rowIndex: getRowIndex(rowIndex),
                                columns: columns(),
                                expanded: dataTable.isRowExpanded(rowData),
                                editing: dataTable.editMode() === 'row' && dataTable.isRowEditing(rowData),
                                frozen: frozen()
                            }
                        "
                    ></ng-container>
                }
                @if ((dataTable.groupHeaderTemplate || dataTable._groupHeaderTemplate) && dataTable.rowGroupMode() === 'subheader' && shouldRenderRowGroupHeader(value(), rowData, getRowIndex(rowIndex))) {
                    <ng-container role="row">
                        <ng-container
                            *ngTemplateOutlet="
                                dataTable.groupHeaderTemplate || dataTable._groupHeaderTemplate;
                                context: {
                                    $implicit: rowData,
                                    rowIndex: getRowIndex(rowIndex),
                                    columns: columns(),
                                    expanded: dataTable.isRowExpanded(rowData),
                                    editing: dataTable.editMode() === 'row' && dataTable.isRowEditing(rowData),
                                    frozen: frozen()
                                }
                            "
                        ></ng-container>
                    </ng-container>
                }
                @if (dataTable.isRowExpanded(rowData)) {
                    <ng-container
                        *ngTemplateOutlet="
                            dataTable.expandedRowTemplate || dataTable._expandedRowTemplate;
                            context: {
                                $implicit: rowData,
                                rowIndex: getRowIndex(rowIndex),
                                columns: columns(),
                                frozen: frozen()
                            }
                        "
                    ></ng-container>
                    @if ((dataTable.groupFooterTemplate || dataTable._groupFooterTemplate) && dataTable.rowGroupMode() === 'subheader' && shouldRenderRowGroupFooter(value(), rowData, getRowIndex(rowIndex))) {
                        <ng-container role="row">
                            <ng-container
                                *ngTemplateOutlet="
                                    dataTable.groupFooterTemplate || dataTable._groupFooterTemplate;
                                    context: {
                                        $implicit: rowData,
                                        rowIndex: getRowIndex(rowIndex),
                                        columns: columns(),
                                        expanded: dataTable.isRowExpanded(rowData),
                                        editing: dataTable.editMode() === 'row' && dataTable.isRowEditing(rowData),
                                        frozen: frozen()
                                    }
                                "
                            ></ng-container>
                        </ng-container>
                    }
                }
            }
        }
        @if ((dataTable.frozenExpandedRowTemplate || dataTable._frozenExpandedRowTemplate) && frozen()) {
            @for (rowData of value(); track dataTable.rowTrackBy()(rowIndex, rowData); let rowIndex = $index) {
                <ng-container
                    *ngTemplateOutlet="
                        template();
                        context: {
                            $implicit: rowData,
                            rowIndex: getRowIndex(rowIndex),
                            columns: columns(),
                            expanded: dataTable.isRowExpanded(rowData),
                            editing: dataTable.editMode() === 'row' && dataTable.isRowEditing(rowData),
                            frozen: frozen()
                        }
                    "
                ></ng-container>
                @if (dataTable.isRowExpanded(rowData)) {
                    <ng-container
                        *ngTemplateOutlet="
                            dataTable.frozenExpandedRowTemplate || dataTable._frozenExpandedRowTemplate;
                            context: {
                                $implicit: rowData,
                                rowIndex: getRowIndex(rowIndex),
                                columns: columns(),
                                frozen: frozen()
                            }
                        "
                    ></ng-container>
                }
            }
        }
        @if (dataTable.loading()) {
            <ng-container *ngTemplateOutlet="dataTable.loadingBodyTemplate || dataTable._loadingBodyTemplate(); context: { $implicit: columns(), frozen: frozen() }"></ng-container>
        }
        @if (dataTable.isEmpty() && !dataTable.loading()) {
            <ng-container *ngTemplateOutlet="dataTable.emptyMessageTemplate || dataTable._emptyMessageTemplate(); context: { $implicit: columns(), frozen: frozen() }"></ng-container>
        }
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[attr.data-p]': 'dataP'
                    },
                    imports: [NgTemplateOutlet]
                }]
        }], ctorParameters: () => [], propDecorators: { columns: [{ type: i0.Input, args: [{ isSignal: true, alias: "pTableBody", required: false }] }], template: [{ type: i0.Input, args: [{ isSignal: true, alias: "pTableBodyTemplate", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], frozen: [{ type: i0.Input, args: [{ isSignal: true, alias: "frozen", required: false }] }], frozenRows: [{ type: i0.Input, args: [{ isSignal: true, alias: "frozenRows", required: false }] }], scrollerOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "scrollerOptions", required: false }] }] } });
class RowGroupHeader extends BaseComponent {
    dataTable = inject(Table);
    _componentStyle = inject(TableStyle);
    get getFrozenRowGroupHeaderStickyPosition() {
        return this.dataTable.rowGroupHeaderStyleObject ? this.dataTable.rowGroupHeaderStyleObject.top : '';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RowGroupHeader, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.2", type: RowGroupHeader, isStandalone: true, selector: "[pRowGroupHeader]", host: { properties: { "class": "cx(\"rowGroupHeader\")", "style": "sx(\"rowGroupHeader\")" } }, providers: [TableStyle], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RowGroupHeader, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pRowGroupHeader]',
                    host: {
                        '[class]': 'cx("rowGroupHeader")',
                        '[style]': 'sx("rowGroupHeader")'
                    },
                    providers: [TableStyle]
                }]
        }] });
class FrozenColumn extends BaseComponent {
    frozen = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "frozen" }] : /* istanbul ignore next */ []));
    alignFrozen = input('left', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "alignFrozen" }] : /* istanbul ignore next */ []));
    resizeListener;
    resizeObserver;
    _componentStyle = inject(TableStyle);
    constructor() {
        super();
        effect(() => {
            this._frozen = this.frozen() ?? true;
            Promise.resolve(null).then(() => this.updateStickyPosition());
        });
    }
    onAfterViewInit() {
        this.bindResizeListener();
        this.observeChanges();
    }
    bindResizeListener() {
        if (isPlatformBrowser(this.platformId)) {
            if (!this.resizeListener) {
                this.resizeListener = this.renderer.listen(this.document.defaultView, 'resize', () => {
                    this.recalculateColumns();
                });
            }
        }
    }
    unbindResizeListener() {
        if (this.resizeListener) {
            this.resizeListener();
            this.resizeListener = null;
        }
    }
    observeChanges() {
        if (isPlatformBrowser(this.platformId)) {
            const resizeObserver = new ResizeObserver(() => {
                this.recalculateColumns();
            });
            resizeObserver.observe(this.el.nativeElement);
            this.resizeObserver = resizeObserver;
        }
    }
    recalculateColumns() {
        const siblings = DomHandler.siblings(this.el.nativeElement);
        const index = DomHandler.index(this.el.nativeElement);
        const time = (siblings.length - index + 1) * 50;
        setTimeout(() => {
            this.updateStickyPosition();
        }, time);
    }
    _frozen = true;
    updateStickyPosition() {
        if (this._frozen) {
            if (this.alignFrozen() === 'right') {
                let right = 0;
                let sibling = this.el.nativeElement.nextElementSibling;
                while (sibling) {
                    right += DomHandler.getOuterWidth(sibling);
                    sibling = sibling.nextElementSibling;
                }
                this.el.nativeElement.style.right = right + 'px';
            }
            else {
                let left = 0;
                let sibling = this.el.nativeElement.previousElementSibling;
                while (sibling) {
                    left += DomHandler.getOuterWidth(sibling);
                    sibling = sibling.previousElementSibling;
                }
                this.el.nativeElement.style.left = left + 'px';
            }
            const filterRow = this.el.nativeElement?.parentElement?.nextElementSibling;
            if (filterRow) {
                let index = DomHandler.index(this.el.nativeElement);
                if (filterRow.children && filterRow.children[index]) {
                    filterRow.children[index].style.left = this.el.nativeElement.style.left;
                    filterRow.children[index].style.right = this.el.nativeElement.style.right;
                }
            }
        }
    }
    onDestroy() {
        this.unbindResizeListener();
        if (this.resizeObserver) {
            this.resizeObserver.disconnect();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FrozenColumn, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: FrozenColumn, isStandalone: true, selector: "[pFrozenColumn]", inputs: { frozen: { classPropertyName: "frozen", publicName: "frozen", isSignal: true, isRequired: false, transformFunction: null }, alignFrozen: { classPropertyName: "alignFrozen", publicName: "alignFrozen", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "cx(\"frozenColumn\")" } }, providers: [TableStyle], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: FrozenColumn, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pFrozenColumn]',
                    host: {
                        '[class]': 'cx("frozenColumn")'
                    },
                    providers: [TableStyle]
                }]
        }], ctorParameters: () => [], propDecorators: { frozen: [{ type: i0.Input, args: [{ isSignal: true, alias: "frozen", required: false }] }], alignFrozen: [{ type: i0.Input, args: [{ isSignal: true, alias: "alignFrozen", required: false }] }] } });
class SortableColumn extends BaseComponent {
    dataTable = inject(Table);
    field = input(undefined, { ...(ngDevMode ? { debugName: "field" } : /* istanbul ignore next */ {}), alias: 'pSortableColumn' });
    pSortableColumnDisabled = input(undefined, { ...(ngDevMode ? { debugName: "pSortableColumnDisabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    role = this.el.nativeElement?.tagName !== 'TH' ? 'columnheader' : null;
    sorted;
    sortOrder;
    subscription;
    _componentStyle = inject(TableStyle);
    constructor() {
        super();
        if (this.isEnabled()) {
            this.subscription = this.dataTable.tableService.sortSource$.subscribe(() => {
                this.updateSortState();
            });
        }
    }
    onInit() {
        if (this.isEnabled()) {
            this.updateSortState();
        }
    }
    updateSortState() {
        let sorted = false;
        let sortOrder = 0;
        const sortMode = this.dataTable.sortMode();
        if (sortMode === 'single') {
            sorted = this.dataTable.isSorted(this.field());
            sortOrder = this.dataTable._sortOrder;
        }
        else if (sortMode === 'multiple') {
            const sortMeta = this.dataTable.getSortMeta(this.field());
            sorted = !!sortMeta;
            sortOrder = sortMeta ? sortMeta.order : 0;
        }
        this.sorted = sorted;
        this.sortOrder = sorted ? (sortOrder === 1 ? 'ascending' : 'descending') : 'none';
    }
    onClick(event) {
        if (this.isEnabled() && !this.isFilterElement(event.target)) {
            this.updateSortState();
            this.dataTable.sort({
                originalEvent: event,
                field: this.field()
            });
            DomHandler.clearSelection();
        }
    }
    onEnterKey(event) {
        this.onClick(event);
        event.preventDefault();
    }
    isEnabled() {
        return this.pSortableColumnDisabled() !== true;
    }
    isFilterElement(element) {
        const grandparent = element?.parentElement?.parentElement;
        return this.isFilterElementIconOrButton(element) || this.isFilterElementIconOrButton(grandparent);
    }
    isFilterElementIconOrButton(element) {
        return getAttribute(element, '[data-pc-name="pccolumnfilterbutton"]') || getAttribute(element, '[data-pc-section="columnfilterbuttonicon"]');
    }
    onDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SortableColumn, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: SortableColumn, isStandalone: true, selector: "[pSortableColumn]", inputs: { field: { classPropertyName: "field", publicName: "pSortableColumn", isSignal: true, isRequired: false, transformFunction: null }, pSortableColumnDisabled: { classPropertyName: "pSortableColumnDisabled", publicName: "pSortableColumnDisabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "columnheader" }, listeners: { "click": "onClick($event)", "keydown.space": "onEnterKey($event)", "keydown.enter": "onEnterKey($event)" }, properties: { "class": "cx('sortableColumn')", "tabindex": "isEnabled() ? \"0\" : null", "attr.aria-sort": "sortOrder" } }, providers: [TableStyle], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SortableColumn, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pSortableColumn]',
                    host: {
                        '[class]': "cx('sortableColumn')",
                        '[tabindex]': 'isEnabled() ? "0" : null',
                        role: 'columnheader',
                        '[attr.aria-sort]': 'sortOrder',
                        '(click)': 'onClick($event)',
                        '(keydown.space)': 'onEnterKey($event)',
                        '(keydown.enter)': 'onEnterKey($event)'
                    },
                    providers: [TableStyle]
                }]
        }], ctorParameters: () => [], propDecorators: { field: [{ type: i0.Input, args: [{ isSignal: true, alias: "pSortableColumn", required: false }] }], pSortableColumnDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "pSortableColumnDisabled", required: false }] }] } });
class SortIcon extends BaseComponent {
    dataTable = inject(Table);
    cd = inject(ChangeDetectorRef);
    field = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "field" }] : /* istanbul ignore next */ []));
    subscription;
    sortOrder;
    _componentStyle = inject(TableStyle);
    constructor() {
        super();
        this.subscription = this.dataTable.tableService.sortSource$.subscribe(() => {
            this.updateSortState();
        });
    }
    onInit() {
        this.updateSortState();
    }
    onClick(event) {
        event.preventDefault();
    }
    updateSortState() {
        const sortMode = this.dataTable.sortMode();
        if (sortMode === 'single') {
            this.sortOrder = this.dataTable.isSorted(this.field()) ? this.dataTable._sortOrder : 0;
        }
        else if (sortMode === 'multiple') {
            let sortMeta = this.dataTable.getSortMeta(this.field());
            this.sortOrder = sortMeta ? sortMeta.order : 0;
        }
        this.cd.markForCheck();
    }
    getMultiSortMetaIndex() {
        let multiSortMeta = this.dataTable._multiSortMeta;
        let index = -1;
        if (multiSortMeta && this.dataTable.sortMode() === 'multiple' && this.dataTable.showInitialSortBadge() && multiSortMeta.length > 1) {
            for (let i = 0; i < multiSortMeta.length; i++) {
                let meta = multiSortMeta[i];
                const field = this.field();
                if (meta.field === field || meta.field === field) {
                    index = i;
                    break;
                }
            }
        }
        return index;
    }
    getBadgeValue() {
        let index = this.getMultiSortMetaIndex();
        return (this.dataTable?.groupRowsBy() || '') && index > -1 ? index : index + 1;
    }
    isMultiSorted() {
        return this.dataTable.sortMode() === 'multiple' && this.getMultiSortMetaIndex() > -1;
    }
    onDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SortIcon, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: SortIcon, isStandalone: true, selector: "p-sortIcon, p-sort-icon, p-sorticon", inputs: { field: { classPropertyName: "field", publicName: "field", isSignal: true, isRequired: false, transformFunction: null } }, providers: [TableStyle], usesInheritance: true, ngImport: i0, template: `
        @if (!(dataTable.sortIconTemplate || dataTable._sortIconTemplate)) {
            @if (sortOrder === 0) {
                <svg data-p-icon="sort-alt" [class]="cx('sortableColumnIcon')" />
            }
            @if (sortOrder === 1) {
                <svg data-p-icon="sort-amount-up-alt" [class]="cx('sortableColumnIcon')" />
            }
            @if (sortOrder === -1) {
                <svg data-p-icon="sort-amount-down" [class]="cx('sortableColumnIcon')" />
            }
        }
        @if (dataTable.sortIconTemplate || dataTable._sortIconTemplate) {
            <span [class]="cx('sortableColumnIcon')">
                <ng-template *ngTemplateOutlet="dataTable.sortIconTemplate || dataTable._sortIconTemplate; context: { $implicit: sortOrder }"></ng-template>
            </span>
        }
        @if (isMultiSorted()) {
            <p-badge [class]="cx('sortableColumnBadge')" [value]="getBadgeValue()" size="small"></p-badge>
        }
    `, isInline: true, dependencies: [{ kind: "component", type: SortAltIcon, selector: "[data-p-icon=\"sort-alt\"]" }, { kind: "component", type: SortAmountUpAltIcon, selector: "[data-p-icon=\"sort-amount-up-alt\"]" }, { kind: "component", type: SortAmountDownIcon, selector: "[data-p-icon=\"sort-amount-down\"]" }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: Badge, selector: "p-badge", inputs: ["styleClass", "badgeSize", "size", "severity", "value", "badgeDisabled"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SortIcon, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-sortIcon, p-sort-icon, p-sorticon',
                    template: `
        @if (!(dataTable.sortIconTemplate || dataTable._sortIconTemplate)) {
            @if (sortOrder === 0) {
                <svg data-p-icon="sort-alt" [class]="cx('sortableColumnIcon')" />
            }
            @if (sortOrder === 1) {
                <svg data-p-icon="sort-amount-up-alt" [class]="cx('sortableColumnIcon')" />
            }
            @if (sortOrder === -1) {
                <svg data-p-icon="sort-amount-down" [class]="cx('sortableColumnIcon')" />
            }
        }
        @if (dataTable.sortIconTemplate || dataTable._sortIconTemplate) {
            <span [class]="cx('sortableColumnIcon')">
                <ng-template *ngTemplateOutlet="dataTable.sortIconTemplate || dataTable._sortIconTemplate; context: { $implicit: sortOrder }"></ng-template>
            </span>
        }
        @if (isMultiSorted()) {
            <p-badge [class]="cx('sortableColumnBadge')" [value]="getBadgeValue()" size="small"></p-badge>
        }
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    providers: [TableStyle],
                    imports: [SortAltIcon, SortAmountUpAltIcon, SortAmountDownIcon, NgTemplateOutlet, Bind, Badge]
                }]
        }], ctorParameters: () => [], propDecorators: { field: [{ type: i0.Input, args: [{ isSignal: true, alias: "field", required: false }] }] } });
class SelectableRow extends BaseComponent {
    dataTable = inject(Table);
    tableService = inject(TableService);
    data = input(undefined, { ...(ngDevMode ? { debugName: "data" } : /* istanbul ignore next */ {}), alias: 'pSelectableRow' });
    index = input(undefined, { ...(ngDevMode ? { debugName: "index" } : /* istanbul ignore next */ {}), alias: 'pSelectableRowIndex' });
    pSelectableRowDisabled = input(undefined, { ...(ngDevMode ? { debugName: "pSelectableRowDisabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    selected;
    subscription;
    _componentStyle = inject(TableStyle);
    constructor() {
        super();
        if (this.isEnabled()) {
            this.subscription = this.dataTable.tableService.selectionSource$.subscribe(() => {
                this.selected = this.dataTable.isSelected(this.data());
            });
        }
    }
    setRowTabIndex() {
        const selectionMode = this.dataTable.selectionMode();
        if (selectionMode === 'single' || selectionMode === 'multiple') {
            return !this.dataTable._selection ? 0 : this.dataTable.anchorRowIndex === this.index() ? 0 : -1;
        }
    }
    onInit() {
        if (this.isEnabled()) {
            this.selected = this.dataTable.isSelected(this.data());
        }
    }
    onClick(event) {
        if (this.isEnabled()) {
            this.dataTable.handleRowClick({
                originalEvent: event,
                rowData: this.data(),
                rowIndex: this.index()
            });
        }
    }
    onTouchEnd() {
        if (this.isEnabled()) {
            this.dataTable.handleRowTouchEnd();
        }
    }
    onKeyDown(event) {
        switch (event.code) {
            case 'ArrowDown':
                this.onArrowDownKey(event);
                break;
            case 'ArrowUp':
                this.onArrowUpKey(event);
                break;
            case 'Home':
                this.onHomeKey(event);
                break;
            case 'End':
                this.onEndKey(event);
                break;
            case 'Space':
                this.onSpaceKey(event);
                break;
            case 'Enter':
                this.onEnterKey(event);
                break;
            default:
                if (event.code === 'KeyA' && (event.metaKey || event.ctrlKey) && this.dataTable.selectionMode() === 'multiple') {
                    const data = this.dataTable.dataToRender(this.dataTable.processedData);
                    this.dataTable._selection = [...data];
                    this.dataTable.selectRange(event, data.length - 1, true);
                    event.preventDefault();
                }
                break;
        }
    }
    onArrowDownKey(event) {
        if (!this.isEnabled()) {
            return;
        }
        const row = event.currentTarget;
        const nextRow = this.findNextSelectableRow(row);
        if (nextRow) {
            nextRow.focus();
        }
        event.preventDefault();
    }
    onArrowUpKey(event) {
        if (!this.isEnabled()) {
            return;
        }
        const row = event.currentTarget;
        const prevRow = this.findPrevSelectableRow(row);
        if (prevRow) {
            prevRow.focus();
        }
        event.preventDefault();
    }
    onEnterKey(event) {
        if (!this.isEnabled()) {
            return;
        }
        this.dataTable.handleRowClick({
            originalEvent: event,
            rowData: this.data(),
            rowIndex: this.index()
        });
    }
    onEndKey(event) {
        const lastRow = this.findLastSelectableRow();
        lastRow && this.focusRowChange(this.el.nativeElement, lastRow);
        if (event.ctrlKey && event.shiftKey) {
            const data = this.dataTable.dataToRender(this.dataTable._rows);
            const lastSelectableRowIndex = DomHandler.getAttribute(lastRow, 'index');
            this.dataTable.anchorRowIndex = lastSelectableRowIndex;
            this.dataTable._selection = data.slice(this.index() || 0, data.length);
            this.dataTable.selectRange(event, this.index() || 0);
        }
        event.preventDefault();
    }
    onHomeKey(event) {
        const firstRow = this.findFirstSelectableRow();
        firstRow && this.focusRowChange(this.el.nativeElement, firstRow);
        if (event.ctrlKey && event.shiftKey) {
            const data = this.dataTable.dataToRender(this.dataTable._rows);
            const firstSelectableRowIndex = DomHandler.getAttribute(firstRow, 'index');
            this.dataTable.anchorRowIndex = this.dataTable.anchorRowIndex || firstSelectableRowIndex || 0;
            this.dataTable._selection = data.slice(0, (this.index() || 0) + 1);
            this.dataTable.selectRange(event, this.index() || 0);
        }
        event.preventDefault();
    }
    onSpaceKey(event) {
        const isInput = event.target instanceof HTMLInputElement || event.target instanceof HTMLSelectElement || event.target instanceof HTMLTextAreaElement;
        if (isInput) {
            return;
        }
        else {
            this.onEnterKey(event);
            if (event.shiftKey && this.dataTable._selection !== null) {
                const data = this.dataTable.dataToRender(this.dataTable._rows);
                let index;
                if (ObjectUtils.isNotEmpty(this.dataTable._selection) && this.dataTable._selection.length > 0) {
                    let firstSelectedRowIndex, lastSelectedRowIndex;
                    firstSelectedRowIndex = ObjectUtils.findIndexInList(this.dataTable._selection[0], data);
                    lastSelectedRowIndex = ObjectUtils.findIndexInList(this.dataTable._selection[this.dataTable._selection.length - 1], data);
                    index = (this.index() || 0) <= firstSelectedRowIndex ? lastSelectedRowIndex : firstSelectedRowIndex;
                }
                else {
                    index = ObjectUtils.findIndexInList(this.dataTable._selection, data);
                }
                this.dataTable.anchorRowIndex = index || 0;
                const indexValue = this.index();
                this.dataTable._selection = index !== indexValue ? data.slice(Math.min(index || 0, indexValue || 0), Math.max(index || 0, indexValue || 0) + 1) : [this.data()];
                this.dataTable.selectRange(event, this.index() || 0);
            }
            event.preventDefault();
        }
    }
    focusRowChange(firstFocusableRow, currentFocusedRow) {
        firstFocusableRow.tabIndex = '-1';
        currentFocusedRow.tabIndex = '0';
        DomHandler.focus(currentFocusedRow);
    }
    findLastSelectableRow() {
        const rows = DomHandler.find(this.dataTable.el.nativeElement, '[data-p-selectable-row="true"]');
        return rows ? rows[rows.length - 1] : null;
    }
    findFirstSelectableRow() {
        const firstRow = DomHandler.findSingle(this.dataTable.el.nativeElement, '[data-p-selectable-row="true"]');
        return firstRow;
    }
    findNextSelectableRow(row) {
        let nextRow = row.nextElementSibling;
        if (nextRow) {
            if (find(nextRow, '[data-p-selectable-row="true"]'))
                return nextRow;
            else
                return this.findNextSelectableRow(nextRow);
        }
        else {
            return null;
        }
    }
    findPrevSelectableRow(row) {
        let prevRow = row.previousElementSibling;
        if (prevRow) {
            if (find(prevRow, '[data-p-selectable-row="true"]'))
                return prevRow;
            else
                return this.findPrevSelectableRow(prevRow);
        }
        else {
            return null;
        }
    }
    isEnabled() {
        return this.pSelectableRowDisabled() !== true;
    }
    onDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SelectableRow, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: SelectableRow, isStandalone: true, selector: "[pSelectableRow]", inputs: { data: { classPropertyName: "data", publicName: "pSelectableRow", isSignal: true, isRequired: false, transformFunction: null }, index: { classPropertyName: "index", publicName: "pSelectableRowIndex", isSignal: true, isRequired: false, transformFunction: null }, pSelectableRowDisabled: { classPropertyName: "pSelectableRowDisabled", publicName: "pSelectableRowDisabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "onClick($event)", "touchend": "onTouchEnd()", "keydown": "onKeyDown($event)" }, properties: { "class": "cx('selectableRow')", "tabindex": "setRowTabIndex()", "attr.data-p-selectable-row": "true" } }, providers: [TableStyle], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SelectableRow, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pSelectableRow]',
                    host: {
                        '[class]': "cx('selectableRow')",
                        '[tabindex]': 'setRowTabIndex()',
                        '[attr.data-p-selectable-row]': 'true',
                        '(click)': 'onClick($event)',
                        '(touchend)': 'onTouchEnd()',
                        '(keydown)': 'onKeyDown($event)'
                    },
                    providers: [TableStyle]
                }]
        }], ctorParameters: () => [], propDecorators: { data: [{ type: i0.Input, args: [{ isSignal: true, alias: "pSelectableRow", required: false }] }], index: [{ type: i0.Input, args: [{ isSignal: true, alias: "pSelectableRowIndex", required: false }] }], pSelectableRowDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "pSelectableRowDisabled", required: false }] }] } });
class SelectableRowDblClick extends BaseComponent {
    dataTable = inject(Table);
    tableService = inject(TableService);
    data = input(undefined, { ...(ngDevMode ? { debugName: "data" } : /* istanbul ignore next */ {}), alias: 'pSelectableRowDblClick' });
    // eslint-disable-next-line @angular-eslint/no-input-rename -- `pSelectableRowIndex` is published public API; renaming would break consumers.
    index = input(undefined, { ...(ngDevMode ? { debugName: "index" } : /* istanbul ignore next */ {}), alias: 'pSelectableRowIndex' });
    pSelectableRowDisabled = input(undefined, { ...(ngDevMode ? { debugName: "pSelectableRowDisabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    selected;
    subscription;
    _componentStyle = inject(TableStyle);
    constructor() {
        super();
        if (this.isEnabled()) {
            this.subscription = this.dataTable.tableService.selectionSource$.subscribe(() => {
                this.selected = this.dataTable.isSelected(this.data());
            });
        }
    }
    onInit() {
        if (this.isEnabled()) {
            this.selected = this.dataTable.isSelected(this.data());
        }
    }
    onClick(event) {
        if (this.isEnabled()) {
            this.dataTable.handleRowClick({
                originalEvent: event,
                rowData: this.data(),
                rowIndex: this.index()
            });
        }
    }
    isEnabled() {
        return this.pSelectableRowDisabled() !== true;
    }
    onDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SelectableRowDblClick, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: SelectableRowDblClick, isStandalone: true, selector: "[pSelectableRowDblClick]", inputs: { data: { classPropertyName: "data", publicName: "pSelectableRowDblClick", isSignal: true, isRequired: false, transformFunction: null }, index: { classPropertyName: "index", publicName: "pSelectableRowIndex", isSignal: true, isRequired: false, transformFunction: null }, pSelectableRowDisabled: { classPropertyName: "pSelectableRowDisabled", publicName: "pSelectableRowDisabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "dblclick": "onClick($event)" }, properties: { "class": "cx(\"selectableRow\")" } }, providers: [TableStyle], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SelectableRowDblClick, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pSelectableRowDblClick]',
                    host: {
                        '[class]': 'cx("selectableRow")',
                        '(dblclick)': 'onClick($event)'
                    },
                    providers: [TableStyle]
                }]
        }], ctorParameters: () => [], propDecorators: { data: [{ type: i0.Input, args: [{ isSignal: true, alias: "pSelectableRowDblClick", required: false }] }], index: [{ type: i0.Input, args: [{ isSignal: true, alias: "pSelectableRowIndex", required: false }] }], pSelectableRowDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "pSelectableRowDisabled", required: false }] }] } });
class ContextMenuRow extends BaseComponent {
    dataTable = inject(Table);
    tableService = inject(TableService);
    data = input(undefined, { ...(ngDevMode ? { debugName: "data" } : /* istanbul ignore next */ {}), alias: 'pContextMenuRow' });
    index = input(undefined, { ...(ngDevMode ? { debugName: "index" } : /* istanbul ignore next */ {}), alias: 'pContextMenuRowIndex' });
    pContextMenuRowDisabled = input(undefined, { ...(ngDevMode ? { debugName: "pContextMenuRowDisabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    selected;
    subscription;
    _componentStyle = inject(TableStyle);
    constructor() {
        super();
        if (this.isEnabled()) {
            this.subscription = this.dataTable.tableService.contextMenuSource$.subscribe((data) => {
                this.selected = data ? this.dataTable.equals(this.data(), data) : false;
            });
        }
    }
    onContextMenu(event) {
        if (this.isEnabled()) {
            this.dataTable.handleRowRightClick({
                originalEvent: event,
                rowData: this.data(),
                rowIndex: this.index()
            });
            this.el.nativeElement.focus();
            event.preventDefault();
        }
    }
    isEnabled() {
        return this.pContextMenuRowDisabled() !== true;
    }
    onDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ContextMenuRow, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: ContextMenuRow, isStandalone: true, selector: "[pContextMenuRow]", inputs: { data: { classPropertyName: "data", publicName: "pContextMenuRow", isSignal: true, isRequired: false, transformFunction: null }, index: { classPropertyName: "index", publicName: "pContextMenuRowIndex", isSignal: true, isRequired: false, transformFunction: null }, pContextMenuRowDisabled: { classPropertyName: "pContextMenuRowDisabled", publicName: "pContextMenuRowDisabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "contextmenu": "onContextMenu($event)" }, properties: { "class": "cx(\"contextMenuRowSelected\")", "attr.tabindex": "isEnabled() ? 0 : undefined" } }, providers: [TableStyle], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ContextMenuRow, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pContextMenuRow]',
                    host: {
                        '[class]': 'cx("contextMenuRowSelected")',
                        '[attr.tabindex]': 'isEnabled() ? 0 : undefined',
                        '(contextmenu)': 'onContextMenu($event)'
                    },
                    providers: [TableStyle]
                }]
        }], ctorParameters: () => [], propDecorators: { data: [{ type: i0.Input, args: [{ isSignal: true, alias: "pContextMenuRow", required: false }] }], index: [{ type: i0.Input, args: [{ isSignal: true, alias: "pContextMenuRowIndex", required: false }] }], pContextMenuRowDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "pContextMenuRowDisabled", required: false }] }] } });
class RowToggler extends BaseComponent {
    dataTable = inject(Table);
    data = input(undefined, { ...(ngDevMode ? { debugName: "data" } : /* istanbul ignore next */ {}), alias: 'pRowToggler' });
    pRowTogglerDisabled = input(undefined, { ...(ngDevMode ? { debugName: "pRowTogglerDisabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    onClick(event) {
        if (this.isEnabled()) {
            this.dataTable.toggleRow(this.data(), event);
            event.preventDefault();
        }
    }
    isEnabled() {
        return this.pRowTogglerDisabled() !== true;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RowToggler, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: RowToggler, isStandalone: true, selector: "[pRowToggler]", inputs: { data: { classPropertyName: "data", publicName: "pRowToggler", isSignal: true, isRequired: false, transformFunction: null }, pRowTogglerDisabled: { classPropertyName: "pRowTogglerDisabled", publicName: "pRowTogglerDisabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "onClick($event)" } }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: RowToggler, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pRowToggler]',
                    host: {
                        '(click)': 'onClick($event)'
                    }
                }]
        }], propDecorators: { data: [{ type: i0.Input, args: [{ isSignal: true, alias: "pRowToggler", required: false }] }], pRowTogglerDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "pRowTogglerDisabled", required: false }] }] } });
class ResizableColumn extends BaseComponent {
    dataTable = inject(Table);
    zone = inject(NgZone);
    pResizableColumnDisabled = input(undefined, { ...(ngDevMode ? { debugName: "pResizableColumnDisabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    resizer;
    resizerMouseDownListener;
    resizerTouchStartListener;
    resizerTouchMoveListener;
    resizerTouchEndListener;
    documentMouseMoveListener;
    documentMouseUpListener;
    _componentStyle = inject(TableStyle);
    onAfterViewInit() {
        if (isPlatformBrowser(this.platformId)) {
            if (this.isEnabled()) {
                this.resizer = this.renderer.createElement('span');
                setAttribute(this.resizer, 'data-pc-column-resizer', 'true');
                !this.$unstyled() && this.renderer.addClass(this.resizer, 'p-datatable-column-resizer');
                this.renderer.appendChild(this.el.nativeElement, this.resizer);
                this.zone.runOutsideAngular(() => {
                    this.resizerMouseDownListener = this.renderer.listen(this.resizer, 'mousedown', this.onMouseDown.bind(this));
                    this.resizerTouchStartListener = this.renderer.listen(this.resizer, 'touchstart', this.onTouchStart.bind(this));
                });
            }
        }
    }
    bindDocumentEvents() {
        this.zone.runOutsideAngular(() => {
            this.documentMouseMoveListener = this.renderer.listen(this.document, 'mousemove', this.onDocumentMouseMove.bind(this));
            this.documentMouseUpListener = this.renderer.listen(this.document, 'mouseup', this.onDocumentMouseUp.bind(this));
            this.resizerTouchMoveListener = this.renderer.listen(this.resizer, 'touchmove', this.onTouchMove.bind(this));
            this.resizerTouchEndListener = this.renderer.listen(this.resizer, 'touchend', this.onTouchEnd.bind(this));
        });
    }
    unbindDocumentEvents() {
        if (this.documentMouseMoveListener) {
            this.documentMouseMoveListener();
            this.documentMouseMoveListener = null;
        }
        if (this.documentMouseUpListener) {
            this.documentMouseUpListener();
            this.documentMouseUpListener = null;
        }
        if (this.resizerTouchMoveListener) {
            this.resizerTouchMoveListener();
            this.resizerTouchMoveListener = null;
        }
        if (this.resizerTouchEndListener) {
            this.resizerTouchEndListener();
            this.resizerTouchEndListener = null;
        }
    }
    onMouseDown(event) {
        this.dataTable.onColumnResizeBegin(event);
        this.bindDocumentEvents();
    }
    onTouchStart(event) {
        this.dataTable.onColumnResizeBegin(event);
        this.bindDocumentEvents();
    }
    onTouchMove(event) {
        this.dataTable.onColumnResize(event);
    }
    onDocumentMouseMove(event) {
        this.dataTable.onColumnResize(event);
    }
    onDocumentMouseUp() {
        this.dataTable.onColumnResizeEnd();
        this.unbindDocumentEvents();
    }
    onTouchEnd() {
        this.dataTable.onColumnResizeEnd();
        this.unbindDocumentEvents();
    }
    isEnabled() {
        return this.pResizableColumnDisabled() !== true;
    }
    onDestroy() {
        if (this.resizerMouseDownListener) {
            this.resizerMouseDownListener();
            this.resizerMouseDownListener = null;
        }
        this.unbindDocumentEvents();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ResizableColumn, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: ResizableColumn, isStandalone: true, selector: "[pResizableColumn]", inputs: { pResizableColumnDisabled: { classPropertyName: "pResizableColumnDisabled", publicName: "pResizableColumnDisabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "cx('resizableColumn')" } }, providers: [TableStyle], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ResizableColumn, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pResizableColumn]',
                    host: {
                        '[class]': "cx('resizableColumn')"
                    },
                    providers: [TableStyle]
                }]
        }], propDecorators: { pResizableColumnDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "pResizableColumnDisabled", required: false }] }] } });
class ReorderableColumn extends BaseComponent {
    dataTable = inject(Table);
    el = inject(ElementRef);
    zone = inject(NgZone);
    pReorderableColumnDisabled = input(undefined, { ...(ngDevMode ? { debugName: "pReorderableColumnDisabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    dragStartListener;
    dragOverListener;
    dragEnterListener;
    dragLeaveListener;
    mouseDownListener;
    _componentStyle = inject(TableStyle);
    onAfterViewInit() {
        if (this.isEnabled()) {
            this.bindEvents();
        }
    }
    bindEvents() {
        if (isPlatformBrowser(this.platformId)) {
            this.zone.runOutsideAngular(() => {
                this.mouseDownListener = this.renderer.listen(this.el.nativeElement, 'mousedown', this.onMouseDown.bind(this));
                this.dragStartListener = this.renderer.listen(this.el.nativeElement, 'dragstart', this.onDragStart.bind(this));
                this.dragOverListener = this.renderer.listen(this.el.nativeElement, 'dragover', this.onDragOver.bind(this));
                this.dragEnterListener = this.renderer.listen(this.el.nativeElement, 'dragenter', this.onDragEnter.bind(this));
                this.dragLeaveListener = this.renderer.listen(this.el.nativeElement, 'dragleave', this.onDragLeave.bind(this));
            });
        }
    }
    unbindEvents() {
        if (this.mouseDownListener) {
            this.mouseDownListener();
            this.mouseDownListener = null;
        }
        if (this.dragStartListener) {
            this.dragStartListener();
            this.dragStartListener = null;
        }
        if (this.dragOverListener) {
            this.dragOverListener();
            this.dragOverListener = null;
        }
        if (this.dragEnterListener) {
            this.dragEnterListener();
            this.dragEnterListener = null;
        }
        if (this.dragLeaveListener) {
            this.dragLeaveListener();
            this.dragLeaveListener = null;
        }
    }
    onMouseDown(event) {
        if (event.target.nodeName === 'INPUT' || event.target.nodeName === 'TEXTAREA' || findSingle(event.target, '[data-pc-column-resizer="true"]'))
            this.el.nativeElement.draggable = false;
        else
            this.el.nativeElement.draggable = true;
    }
    onDragStart(event) {
        this.dataTable.onColumnDragStart(event, this.el.nativeElement);
    }
    onDragOver(event) {
        event.preventDefault();
    }
    onDragEnter(event) {
        this.dataTable.onColumnDragEnter(event, this.el.nativeElement);
    }
    onDragLeave(event) {
        this.dataTable.onColumnDragLeave(event);
    }
    onDrop(event) {
        if (this.isEnabled()) {
            this.dataTable.onColumnDrop(event, this.el.nativeElement);
        }
    }
    isEnabled() {
        return this.pReorderableColumnDisabled() !== true;
    }
    onDestroy() {
        this.unbindEvents();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReorderableColumn, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: ReorderableColumn, isStandalone: true, selector: "[pReorderableColumn]", inputs: { pReorderableColumnDisabled: { classPropertyName: "pReorderableColumnDisabled", publicName: "pReorderableColumnDisabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "drop": "onDrop($event)" }, properties: { "class": "cx('reorderableColumn')" } }, providers: [TableStyle], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReorderableColumn, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pReorderableColumn]',
                    host: {
                        '[class]': "cx('reorderableColumn')",
                        '(drop)': 'onDrop($event)'
                    },
                    providers: [TableStyle]
                }]
        }], propDecorators: { pReorderableColumnDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "pReorderableColumnDisabled", required: false }] }] } });
class EditableColumn extends BaseComponent {
    dataTable = inject(Table);
    zone = inject(NgZone);
    data = input(undefined, { ...(ngDevMode ? { debugName: "data" } : /* istanbul ignore next */ {}), alias: 'pEditableColumn' });
    field = input(undefined, { ...(ngDevMode ? { debugName: "field" } : /* istanbul ignore next */ {}), alias: 'pEditableColumnField' });
    rowIndex = input(undefined, { ...(ngDevMode ? { debugName: "rowIndex" } : /* istanbul ignore next */ {}), alias: 'pEditableColumnRowIndex' });
    pEditableColumnDisabled = input(undefined, { ...(ngDevMode ? { debugName: "pEditableColumnDisabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    pFocusCellSelector = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "pFocusCellSelector" }] : /* istanbul ignore next */ []));
    overlayEventListener;
    onChanges(changes) {
        if (this.el.nativeElement && !changes.data?.firstChange) {
            this.dataTable.updateEditingCell(this.el.nativeElement, this.data(), this.field(), this.rowIndex());
        }
    }
    onAfterViewInit() {
        if (this.isEnabled()) {
            !this.$unstyled() && DomHandler.addClass(this.el.nativeElement, 'p-editable-column');
        }
    }
    onClick(event) {
        if (this.isEnabled()) {
            this.dataTable.selfClick = true;
            if (this.dataTable.editingCell) {
                if (this.dataTable.editingCell !== this.el.nativeElement) {
                    if (!this.dataTable.isEditingCellValid()) {
                        return;
                    }
                    this.closeEditingCell(true, event);
                    this.openCell();
                }
            }
            else {
                this.openCell();
            }
        }
    }
    openCell() {
        const data = this.data();
        const field = this.field();
        const rowIndex = this.rowIndex();
        this.dataTable.updateEditingCell(this.el.nativeElement, data, field, rowIndex);
        !this.$unstyled() && DomHandler.addClass(this.el.nativeElement, 'p-cell-editing');
        setAttribute(this.el.nativeElement, 'data-p-cell-editing', 'true');
        this.dataTable.onEditInit.emit({
            field: field,
            data: data,
            index: rowIndex
        });
        this.zone.runOutsideAngular(() => {
            setTimeout(() => {
                let focusCellSelector = this.pFocusCellSelector() || 'input, textarea, select';
                let focusableElement = DomHandler.findSingle(this.el.nativeElement, focusCellSelector);
                if (focusableElement) {
                    focusableElement.focus();
                }
            }, 50);
        });
        this.overlayEventListener = (e) => {
            if (this.el && this.el.nativeElement.contains(e.target)) {
                this.dataTable.selfClick = true;
            }
        };
        this.dataTable.overlaySubscription = this.dataTable.overlayService.clickObservable.subscribe(this.overlayEventListener);
    }
    closeEditingCell(completed, event) {
        const eventData = {
            field: this.dataTable.editingCellField,
            data: this.dataTable.editingCellData,
            originalEvent: event,
            index: this.dataTable.editingCellRowIndex
        };
        if (completed) {
            this.dataTable.onEditComplete.emit(eventData);
        }
        else {
            this.dataTable.onEditCancel.emit(eventData);
            this.dataTable._value.forEach((element) => {
                if (element[this.dataTable.editingCellField] === this.data()) {
                    element[this.dataTable.editingCellField] = this.dataTable.editingCellData;
                }
            });
        }
        !this.$unstyled() && DomHandler.removeClass(this.dataTable.editingCell, 'p-cell-editing');
        setAttribute(this.el.nativeElement, 'data-p-cell-editing', 'false');
        this.dataTable.editingCell = null;
        this.dataTable.editingCellData = null;
        this.dataTable.editingCellField = null;
        this.dataTable.unbindDocumentEditListener();
        if (this.dataTable.overlaySubscription) {
            this.dataTable.overlaySubscription.unsubscribe();
        }
    }
    onEnterKeyDown(event) {
        if (this.isEnabled() && !event.shiftKey) {
            if (this.dataTable.isEditingCellValid()) {
                this.closeEditingCell(true, event);
            }
            event.preventDefault();
        }
    }
    onTabKeyDown(event) {
        if (this.isEnabled()) {
            if (this.dataTable.isEditingCellValid()) {
                this.closeEditingCell(true, event);
            }
            event.preventDefault();
        }
    }
    onEscapeKeyDown(event) {
        if (this.isEnabled()) {
            if (this.dataTable.isEditingCellValid()) {
                this.closeEditingCell(false, event);
            }
            event.preventDefault();
        }
    }
    onShiftKeyDown(event) {
        if (this.isEnabled()) {
            if (event.shiftKey)
                this.moveToPreviousCell(event);
            else {
                this.moveToNextCell(event);
            }
        }
    }
    onArrowDown(event) {
        if (this.isEnabled()) {
            let currentCell = this.findCell(event.target);
            if (currentCell) {
                let cellIndex = DomHandler.index(currentCell);
                let targetCell = this.findNextEditableColumnByIndex(currentCell, cellIndex);
                if (targetCell) {
                    if (this.dataTable.isEditingCellValid()) {
                        this.closeEditingCell(true, event);
                    }
                    DomHandler.invokeElementMethod(event.target, 'blur');
                    DomHandler.invokeElementMethod(targetCell, 'click');
                }
                event.preventDefault();
            }
        }
    }
    onArrowUp(event) {
        if (this.isEnabled()) {
            let currentCell = this.findCell(event.target);
            if (currentCell) {
                let cellIndex = DomHandler.index(currentCell);
                let targetCell = this.findPrevEditableColumnByIndex(currentCell, cellIndex);
                if (targetCell) {
                    if (this.dataTable.isEditingCellValid()) {
                        this.closeEditingCell(true, event);
                    }
                    DomHandler.invokeElementMethod(event.target, 'blur');
                    DomHandler.invokeElementMethod(targetCell, 'click');
                }
                event.preventDefault();
            }
        }
    }
    onArrowLeft(event) {
        if (this.isEnabled()) {
            this.moveToPreviousCell(event);
        }
    }
    onArrowRight(event) {
        if (this.isEnabled()) {
            this.moveToNextCell(event);
        }
    }
    findCell(element) {
        if (element) {
            let cell = element;
            while (cell && !findSingle(cell, '[data-p-cell-editing="true"]')) {
                cell = cell.parentElement;
            }
            return cell;
        }
        else {
            return null;
        }
    }
    moveToPreviousCell(event) {
        let currentCell = this.findCell(event.target);
        if (currentCell) {
            let targetCell = this.findPreviousEditableColumn(currentCell);
            if (targetCell) {
                if (this.dataTable.isEditingCellValid()) {
                    this.closeEditingCell(true, event);
                }
                DomHandler.invokeElementMethod(event.target, 'blur');
                DomHandler.invokeElementMethod(targetCell, 'click');
                event.preventDefault();
            }
        }
    }
    moveToNextCell(event) {
        let currentCell = this.findCell(event.target);
        if (currentCell) {
            let targetCell = this.findNextEditableColumn(currentCell);
            if (targetCell) {
                if (this.dataTable.isEditingCellValid()) {
                    this.closeEditingCell(true, event);
                }
                DomHandler.invokeElementMethod(event.target, 'blur');
                DomHandler.invokeElementMethod(targetCell, 'click');
                event.preventDefault();
            }
            else {
                if (this.dataTable.isEditingCellValid()) {
                    this.closeEditingCell(true, event);
                }
            }
        }
    }
    findPreviousEditableColumn(cell) {
        let prevCell = cell.previousElementSibling;
        if (!prevCell) {
            let previousRow = cell.parentElement?.previousElementSibling;
            if (previousRow) {
                prevCell = previousRow.lastElementChild;
            }
        }
        if (prevCell) {
            if (findSingle(prevCell, '[data-p-editable-column="true"]'))
                return prevCell;
            else
                return this.findPreviousEditableColumn(prevCell);
        }
        else {
            return null;
        }
    }
    findNextEditableColumn(cell) {
        let nextCell = cell.nextElementSibling;
        if (!nextCell) {
            let nextRow = cell.parentElement?.nextElementSibling;
            if (nextRow) {
                nextCell = nextRow.firstElementChild;
            }
        }
        if (nextCell) {
            if (findSingle(nextCell, '[data-p-editable-column="true"]'))
                return nextCell;
            else
                return this.findNextEditableColumn(nextCell);
        }
        else {
            return null;
        }
    }
    findNextEditableColumnByIndex(cell, index) {
        let nextRow = cell.parentElement?.nextElementSibling;
        if (nextRow) {
            let nextCell = nextRow.children[index];
            if (nextCell && findSingle(nextCell, '[data-p-editable-column="true"]')) {
                return nextCell;
            }
            return null;
        }
        else {
            return null;
        }
    }
    findPrevEditableColumnByIndex(cell, index) {
        let prevRow = cell.parentElement?.previousElementSibling;
        if (prevRow) {
            let prevCell = prevRow.children[index];
            if (prevCell && findSingle(prevCell, '[data-p-editable-column="true"]')) {
                return prevCell;
            }
            return null;
        }
        else {
            return null;
        }
    }
    isEnabled() {
        return this.pEditableColumnDisabled() !== true;
    }
    onDestroy() {
        if (this.dataTable.overlaySubscription) {
            this.dataTable.overlaySubscription.unsubscribe();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: EditableColumn, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: EditableColumn, isStandalone: true, selector: "[pEditableColumn]", inputs: { data: { classPropertyName: "data", publicName: "pEditableColumn", isSignal: true, isRequired: false, transformFunction: null }, field: { classPropertyName: "field", publicName: "pEditableColumnField", isSignal: true, isRequired: false, transformFunction: null }, rowIndex: { classPropertyName: "rowIndex", publicName: "pEditableColumnRowIndex", isSignal: true, isRequired: false, transformFunction: null }, pEditableColumnDisabled: { classPropertyName: "pEditableColumnDisabled", publicName: "pEditableColumnDisabled", isSignal: true, isRequired: false, transformFunction: null }, pFocusCellSelector: { classPropertyName: "pFocusCellSelector", publicName: "pFocusCellSelector", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "onClick($event)", "keydown.enter": "onEnterKeyDown($event)", "keydown.tab": "onTabKeyDown($event); onShiftKeyDown($event)", "keydown.escape": "onEscapeKeyDown($event)", "keydown.shift.tab": "onShiftKeyDown($event)", "keydown.meta.tab": "onShiftKeyDown($event)", "keydown.arrowdown": "onArrowDown($event)", "keydown.arrowup": "onArrowUp($event)", "keydown.arrowleft": "onArrowLeft($event)", "keydown.arrowright": "onArrowRight($event)" }, properties: { "attr.data-p-editable-column": "true" } }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: EditableColumn, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pEditableColumn]',
                    host: {
                        '[attr.data-p-editable-column]': 'true',
                        '(click)': 'onClick($event)',
                        '(keydown.enter)': 'onEnterKeyDown($event)',
                        '(keydown.tab)': 'onTabKeyDown($event); onShiftKeyDown($event)',
                        '(keydown.escape)': 'onEscapeKeyDown($event)',
                        '(keydown.shift.tab)': 'onShiftKeyDown($event)',
                        '(keydown.meta.tab)': 'onShiftKeyDown($event)',
                        '(keydown.arrowdown)': 'onArrowDown($event)',
                        '(keydown.arrowup)': 'onArrowUp($event)',
                        '(keydown.arrowleft)': 'onArrowLeft($event)',
                        '(keydown.arrowright)': 'onArrowRight($event)'
                    }
                }]
        }], propDecorators: { data: [{ type: i0.Input, args: [{ isSignal: true, alias: "pEditableColumn", required: false }] }], field: [{ type: i0.Input, args: [{ isSignal: true, alias: "pEditableColumnField", required: false }] }], rowIndex: [{ type: i0.Input, args: [{ isSignal: true, alias: "pEditableColumnRowIndex", required: false }] }], pEditableColumnDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "pEditableColumnDisabled", required: false }] }], pFocusCellSelector: [{ type: i0.Input, args: [{ isSignal: true, alias: "pFocusCellSelector", required: false }] }] } });
class EditableRow extends BaseComponent {
    data = input(undefined, { ...(ngDevMode ? { debugName: "data" } : /* istanbul ignore next */ {}), alias: 'pEditableRow' });
    pEditableRowDisabled = input(undefined, { ...(ngDevMode ? { debugName: "pEditableRowDisabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    isEnabled() {
        return this.pEditableRowDisabled() !== true;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: EditableRow, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: EditableRow, isStandalone: true, selector: "[pEditableRow]", inputs: { data: { classPropertyName: "data", publicName: "pEditableRow", isSignal: true, isRequired: false, transformFunction: null }, pEditableRowDisabled: { classPropertyName: "pEditableRowDisabled", publicName: "pEditableRowDisabled", isSignal: true, isRequired: false, transformFunction: null } }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: EditableRow, decorators: [{
            type: Directive,
            args: [{ selector: '[pEditableRow]' }]
        }], propDecorators: { data: [{ type: i0.Input, args: [{ isSignal: true, alias: "pEditableRow", required: false }] }], pEditableRowDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "pEditableRowDisabled", required: false }] }] } });
class InitEditableRow extends BaseComponent {
    dataTable = inject(Table);
    editableRow = inject(EditableRow);
    onClick(event) {
        this.dataTable.initRowEdit(this.editableRow.data());
        event.preventDefault();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InitEditableRow, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.2", type: InitEditableRow, isStandalone: true, selector: "[pInitEditableRow]", host: { listeners: { "click": "onClick($event)" }, classAttribute: "p-datatable-row-editor-init" }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: InitEditableRow, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pInitEditableRow]',
                    host: {
                        class: 'p-datatable-row-editor-init',
                        '(click)': 'onClick($event)'
                    }
                }]
        }] });
class SaveEditableRow extends BaseComponent {
    dataTable = inject(Table);
    editableRow = inject(EditableRow);
    onClick(event) {
        this.dataTable.saveRowEdit(this.editableRow.data(), this.editableRow.el.nativeElement);
        event.preventDefault();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SaveEditableRow, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.2", type: SaveEditableRow, isStandalone: true, selector: "[pSaveEditableRow]", host: { listeners: { "click": "onClick($event)" }, classAttribute: "p-datatable-row-editor-save" }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: SaveEditableRow, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pSaveEditableRow]',
                    host: {
                        class: 'p-datatable-row-editor-save',
                        '(click)': 'onClick($event)'
                    }
                }]
        }] });
class CancelEditableRow extends BaseComponent {
    dataTable = inject(Table);
    editableRow = inject(EditableRow);
    _componentStyle = inject(TableStyle);
    onClick(event) {
        this.dataTable.cancelRowEdit(this.editableRow.data());
        event.preventDefault();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CancelEditableRow, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.2", type: CancelEditableRow, isStandalone: true, selector: "[pCancelEditableRow]", host: { listeners: { "click": "onClick($event)" }, properties: { "class": "cx('rowEditorCancel')" } }, providers: [TableStyle], usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CancelEditableRow, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pCancelEditableRow]',
                    host: {
                        '[class]': "cx('rowEditorCancel')",
                        '(click)': 'onClick($event)'
                    },
                    providers: [TableStyle]
                }]
        }] });
class CellEditor extends BaseComponent {
    dataTable = inject(Table);
    editableColumn = inject(EditableColumn, { optional: true });
    editableRow = inject(EditableRow, { optional: true });
    _templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_templates" }] : /* istanbul ignore next */ []));
    _inputTemplate = contentChild('input', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_inputTemplate" }] : /* istanbul ignore next */ []));
    _outputTemplate = contentChild('output', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_outputTemplate" }] : /* istanbul ignore next */ []));
    inputTemplate;
    outputTemplate;
    onAfterContentInit() {
        this._templates().forEach((item) => {
            switch (item.getType()) {
                case 'input':
                    this.inputTemplate = item.template;
                    break;
                case 'output':
                    this.outputTemplate = item.template;
                    break;
            }
        });
    }
    get editing() {
        return !!((this.dataTable.editingCell && this.editableColumn && this.dataTable.editingCell === this.editableColumn.el.nativeElement) ||
            (this.editableRow && this.dataTable.editMode() === 'row' && this.dataTable.isRowEditing(this.editableRow.data())));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CellEditor, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: CellEditor, isStandalone: true, selector: "p-cellEditor, p-cell-editor, p-celleditor", queries: [{ propertyName: "_templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "_inputTemplate", first: true, predicate: ["input"], descendants: true, isSignal: true }, { propertyName: "_outputTemplate", first: true, predicate: ["output"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: `
        @if (editing) {
            <ng-container *ngTemplateOutlet="inputTemplate || _inputTemplate()"></ng-container>
        }
        @if (!editing) {
            <ng-container *ngTemplateOutlet="outputTemplate || _outputTemplate()"></ng-container>
        }
    `, isInline: true, dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: CellEditor, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-cellEditor, p-cell-editor, p-celleditor',
                    template: `
        @if (editing) {
            <ng-container *ngTemplateOutlet="inputTemplate || _inputTemplate()"></ng-container>
        }
        @if (!editing) {
            <ng-container *ngTemplateOutlet="outputTemplate || _outputTemplate()"></ng-container>
        }
    `,
                    encapsulation: ViewEncapsulation.None,
                    imports: [NgTemplateOutlet]
                }]
        }], propDecorators: { _templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }], _inputTemplate: [{ type: i0.ContentChild, args: ['input', { isSignal: true }] }], _outputTemplate: [{ type: i0.ContentChild, args: ['output', { isSignal: true }] }] } });
class TableRadioButton extends BaseComponent {
    dataTable = inject(Table);
    cd = inject(ChangeDetectorRef);
    value = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "value" }] : /* istanbul ignore next */ []));
    disabled = input(undefined, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    index = input(undefined, { ...(ngDevMode ? { debugName: "index" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    inputId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "inputId" }] : /* istanbul ignore next */ []));
    name = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "name" }] : /* istanbul ignore next */ []));
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    _ariaLabel;
    inputViewChild = viewChild('rb', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputViewChild" }] : /* istanbul ignore next */ []));
    checked;
    subscription;
    constructor() {
        super();
        effect(() => {
            this._ariaLabel = this.ariaLabel();
        });
        this.subscription = this.dataTable.tableService.selectionSource$.subscribe(() => {
            this.checked = this.dataTable.isSelected(this.value());
            this._ariaLabel = this._ariaLabel || (this.dataTable.config.translation.aria ? (this.checked ? this.dataTable.config.translation.aria.selectRow : this.dataTable.config.translation.aria.unselectRow) : undefined);
            this.cd.markForCheck();
        });
    }
    onInit() {
        this.checked = this.dataTable.isSelected(this.value());
    }
    onClick(event) {
        if (!this.disabled()) {
            this.dataTable.toggleRowWithRadio({
                originalEvent: event.originalEvent,
                rowIndex: this.index()
            }, this.value());
            this.inputViewChild()?.inputViewChild().nativeElement?.focus();
        }
        DomHandler.clearSelection();
    }
    onDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableRadioButton, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "22.1.2", type: TableRadioButton, isStandalone: true, selector: "p-tableRadioButton, p-table-radio-button, p-tableradiobutton", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, index: { classPropertyName: "index", publicName: "index", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null } }, viewQueries: [{ propertyName: "inputViewChild", first: true, predicate: ["rb"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: `<p-radioButton #rb [(ngModel)]="checked" [disabled]="disabled()" [inputId]="inputId()" [name]="name()" [ariaLabel]="_ariaLabel" [binary]="true" [value]="value()" (onClick)="onClick($event)" [unstyled]="unstyled()" /> `, isInline: true, dependencies: [{ kind: "component", type: RadioButton, selector: "p-radioButton, p-radiobutton, p-radio-button", inputs: ["value", "tabindex", "inputId", "ariaLabelledBy", "ariaLabel", "styleClass", "autofocus", "binary", "variant", "size"], outputs: ["onClick", "onFocus", "onBlur"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableRadioButton, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-tableRadioButton, p-table-radio-button, p-tableradiobutton',
                    template: `<p-radioButton #rb [(ngModel)]="checked" [disabled]="disabled()" [inputId]="inputId()" [name]="name()" [ariaLabel]="_ariaLabel" [binary]="true" [value]="value()" (onClick)="onClick($event)" [unstyled]="unstyled()" /> `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    imports: [Bind, RadioButton, FormsModule]
                }]
        }], ctorParameters: () => [], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], index: [{ type: i0.Input, args: [{ isSignal: true, alias: "index", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], inputViewChild: [{ type: i0.ViewChild, args: ['rb', { isSignal: true }] }] } });
class TableCheckbox extends BaseComponent {
    dataTable = inject(Table);
    tableService = inject(TableService);
    value = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "value" }] : /* istanbul ignore next */ []));
    disabled = input(undefined, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    required = input(undefined, { ...(ngDevMode ? { debugName: "required" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    index = input(undefined, { ...(ngDevMode ? { debugName: "index" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    inputId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "inputId" }] : /* istanbul ignore next */ []));
    name = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "name" }] : /* istanbul ignore next */ []));
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    _ariaLabel;
    checked;
    subscription;
    constructor() {
        super();
        effect(() => {
            this._ariaLabel = this.ariaLabel();
        });
        this.subscription = this.dataTable.tableService.selectionSource$.subscribe(() => {
            this.checked = this.dataTable.isSelected(this.value());
            this._ariaLabel = this._ariaLabel || (this.dataTable.config.translation.aria ? (this.checked ? this.dataTable.config.translation.aria.selectRow : this.dataTable.config.translation.aria.unselectRow) : undefined);
            this.cd.markForCheck();
        });
    }
    onInit() {
        this.checked = this.dataTable.isSelected(this.value());
    }
    onClick({ originalEvent }) {
        if (!this.disabled()) {
            this.dataTable.toggleRowWithCheckbox({
                originalEvent: originalEvent,
                rowIndex: this.index() || 0
            }, this.value());
        }
        DomHandler.clearSelection();
    }
    onDestroy() {
        if (this.subscription) {
            this.subscription.unsubscribe();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableCheckbox, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: TableCheckbox, isStandalone: true, selector: "p-tableCheckbox, p-table-checkbox, p-tablecheckbox", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null }, index: { classPropertyName: "index", publicName: "index", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null } }, usesInheritance: true, ngImport: i0, template: `
        <p-checkbox [(ngModel)]="checked" [binary]="true" (onChange)="onClick($event)" [required]="required()" [disabled]="disabled()" [inputId]="inputId()" [name]="name()" [ariaLabel]="_ariaLabel" [unstyled]="unstyled()">
            @if (dataTable.checkboxIconTemplate || dataTable._checkboxIconTemplate(); as template) {
                <ng-template pTemplate="icon">
                    <ng-template *ngTemplateOutlet="template; context: { $implicit: checked }" />
                </ng-template>
            }
        </p-checkbox>
    `, isInline: true, dependencies: [{ kind: "component", type: Checkbox, selector: "p-checkbox, p-checkBox, p-check-box", inputs: ["hostName", "value", "binary", "ariaLabelledBy", "ariaLabel", "tabindex", "inputId", "inputStyle", "styleClass", "inputClass", "indeterminate", "formControl", "checkboxIcon", "readonly", "autofocus", "trueValue", "falseValue", "variant", "size"], outputs: ["onChange", "onFocus", "onBlur"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.RequiredValidator, selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]", inputs: ["required"] }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableCheckbox, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-tableCheckbox, p-table-checkbox, p-tablecheckbox',
                    template: `
        <p-checkbox [(ngModel)]="checked" [binary]="true" (onChange)="onClick($event)" [required]="required()" [disabled]="disabled()" [inputId]="inputId()" [name]="name()" [ariaLabel]="_ariaLabel" [unstyled]="unstyled()">
            @if (dataTable.checkboxIconTemplate || dataTable._checkboxIconTemplate(); as template) {
                <ng-template pTemplate="icon">
                    <ng-template *ngTemplateOutlet="template; context: { $implicit: checked }" />
                </ng-template>
            }
        </p-checkbox>
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    imports: [Bind, Checkbox, FormsModule, PrimeTemplate, NgTemplateOutlet]
                }]
        }], ctorParameters: () => [], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }], index: [{ type: i0.Input, args: [{ isSignal: true, alias: "index", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }] } });
class TableHeaderCheckbox extends BaseComponent {
    dataTable = inject(Table);
    tableService = inject(TableService);
    hostName = 'Table';
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptm('headerCheckbox'));
    }
    disabled = input(undefined, { ...(ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    inputId = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "inputId" }] : /* istanbul ignore next */ []));
    name = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "name" }] : /* istanbul ignore next */ []));
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    _ariaLabel;
    checked;
    selectionChangeSubscription;
    valueChangeSubscription;
    constructor() {
        super();
        effect(() => {
            this._ariaLabel = this.ariaLabel();
        });
        this.valueChangeSubscription = this.dataTable.tableService.valueSource$.subscribe(() => {
            this.checked = this.updateCheckedState();
            this._ariaLabel = this._ariaLabel || (this.dataTable.config.translation.aria ? (this.checked ? this.dataTable.config.translation.aria.selectAll : this.dataTable.config.translation.aria.unselectAll) : undefined);
        });
        this.selectionChangeSubscription = this.dataTable.tableService.selectionSource$.subscribe(() => {
            this.checked = this.updateCheckedState();
        });
    }
    onInit() {
        this.checked = this.updateCheckedState();
    }
    onClick(event) {
        if (!this.disabled()) {
            if (this.dataTable._value && this.dataTable._value.length > 0) {
                this.dataTable.toggleRowsWithCheckbox(event, this.checked || false);
            }
        }
        DomHandler.clearSelection();
    }
    isDisabled() {
        return this.disabled() || !this.dataTable._value || !this.dataTable._value.length;
    }
    onDestroy() {
        if (this.selectionChangeSubscription) {
            this.selectionChangeSubscription.unsubscribe();
        }
        if (this.valueChangeSubscription) {
            this.valueChangeSubscription.unsubscribe();
        }
    }
    updateCheckedState() {
        this.cd.markForCheck();
        if (this.dataTable._selectAll !== null) {
            return this.dataTable._selectAll;
        }
        else {
            const data = this.dataTable.selectionPageOnly() ? this.dataTable.dataToRender(this.dataTable.processedData) : this.dataTable.processedData;
            const frozenValue = this.dataTable.frozenValue();
            const val = frozenValue ? [...frozenValue, ...data] : data;
            const selectableVal = this.dataTable.rowSelectable() ? val.filter((data, index) => this.dataTable.rowSelectable()({ data, index })) : val;
            return ObjectUtils.isNotEmpty(selectableVal) && ObjectUtils.isNotEmpty(this.dataTable._selection) && selectableVal.every((v) => this.dataTable._selection.some((s) => this.dataTable.equals(v, s)));
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableHeaderCheckbox, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: TableHeaderCheckbox, isStandalone: true, selector: "p-tableHeaderCheckbox, p-table-header-checkbox, p-tableheadercheckbox", inputs: { disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, inputId: { classPropertyName: "inputId", publicName: "inputId", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null } }, usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        <p-checkbox [pt]="ptm('pcCheckbox')" [(ngModel)]="checked" (onChange)="onClick($event)" [binary]="true" [disabled]="isDisabled()" [inputId]="inputId()" [name]="name()" [ariaLabel]="_ariaLabel" [unstyled]="unstyled()">
            @if (dataTable.headerCheckboxIconTemplate || dataTable._headerCheckboxIconTemplate(); as template) {
                <ng-template pTemplate="icon">
                    <ng-template *ngTemplateOutlet="template; context: { $implicit: checked }" />
                </ng-template>
            }
        </p-checkbox>
    `, isInline: true, dependencies: [{ kind: "component", type: Checkbox, selector: "p-checkbox, p-checkBox, p-check-box", inputs: ["hostName", "value", "binary", "ariaLabelledBy", "ariaLabel", "tabindex", "inputId", "inputStyle", "styleClass", "inputClass", "indeterminate", "formControl", "checkboxIcon", "readonly", "autofocus", "trueValue", "falseValue", "variant", "size"], outputs: ["onChange", "onFocus", "onBlur"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: PrimeTemplate, selector: "[pTemplate]", inputs: ["type", "pTemplate"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableHeaderCheckbox, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-tableHeaderCheckbox, p-table-header-checkbox, p-tableheadercheckbox',
                    template: `
        <p-checkbox [pt]="ptm('pcCheckbox')" [(ngModel)]="checked" (onChange)="onClick($event)" [binary]="true" [disabled]="isDisabled()" [inputId]="inputId()" [name]="name()" [ariaLabel]="_ariaLabel" [unstyled]="unstyled()">
            @if (dataTable.headerCheckboxIconTemplate || dataTable._headerCheckboxIconTemplate(); as template) {
                <ng-template pTemplate="icon">
                    <ng-template *ngTemplateOutlet="template; context: { $implicit: checked }" />
                </ng-template>
            }
        </p-checkbox>
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    hostDirectives: [Bind],
                    imports: [Bind, Checkbox, FormsModule, PrimeTemplate, NgTemplateOutlet]
                }]
        }], ctorParameters: () => [], propDecorators: { disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], inputId: [{ type: i0.Input, args: [{ isSignal: true, alias: "inputId", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }] } });
class ReorderableRowHandle extends BaseComponent {
    el = inject(ElementRef);
    hostName = 'Table';
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptm('reorderableRowHandle'));
    }
    _componentStyle = inject(TableStyle);
    onAfterViewInit() {
        // DomHandler.addClass(this.el.nativeElement, 'p-datatable-reorderable-row-handle');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReorderableRowHandle, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.1.2", type: ReorderableRowHandle, isStandalone: true, selector: "[pReorderableRowHandle]", host: { properties: { "class": "cx('reorderableRowHandle')" } }, providers: [TableStyle], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReorderableRowHandle, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pReorderableRowHandle]',
                    host: {
                        '[class]': "cx('reorderableRowHandle')"
                    },
                    providers: [TableStyle],
                    hostDirectives: [Bind]
                }]
        }] });
class ReorderableRow extends BaseComponent {
    dataTable = inject(Table);
    zone = inject(NgZone);
    hostName = 'Table';
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptm('reorderableRow'));
    }
    index = input(undefined, { ...(ngDevMode ? { debugName: "index" } : /* istanbul ignore next */ {}), alias: 'pReorderableRow' });
    pReorderableRowDisabled = input(undefined, { ...(ngDevMode ? { debugName: "pReorderableRowDisabled" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    mouseDownListener;
    dragStartListener;
    dragEndListener;
    dragOverListener;
    dragLeaveListener;
    dropListener;
    onAfterViewInit() {
        if (this.isEnabled()) {
            this.el.nativeElement.droppable = true;
            this.bindEvents();
        }
    }
    bindEvents() {
        this.zone.runOutsideAngular(() => {
            this.mouseDownListener = this.renderer.listen(this.el.nativeElement, 'mousedown', this.onMouseDown.bind(this));
            this.dragStartListener = this.renderer.listen(this.el.nativeElement, 'dragstart', this.onDragStart.bind(this));
            this.dragEndListener = this.renderer.listen(this.el.nativeElement, 'dragend', this.onDragEnd.bind(this));
            this.dragOverListener = this.renderer.listen(this.el.nativeElement, 'dragover', this.onDragOver.bind(this));
            this.dragLeaveListener = this.renderer.listen(this.el.nativeElement, 'dragleave', this.onDragLeave.bind(this));
        });
    }
    unbindEvents() {
        if (this.mouseDownListener) {
            this.mouseDownListener();
            this.mouseDownListener = null;
        }
        if (this.dragStartListener) {
            this.dragStartListener();
            this.dragStartListener = null;
        }
        if (this.dragEndListener) {
            this.dragEndListener();
            this.dragEndListener = null;
        }
        if (this.dragOverListener) {
            this.dragOverListener();
            this.dragOverListener = null;
        }
        if (this.dragLeaveListener) {
            this.dragLeaveListener();
            this.dragLeaveListener = null;
        }
    }
    onMouseDown(event) {
        const targetElement = event.target;
        const isHandleClicked = this.isHandleElement(targetElement);
        this.el.nativeElement.draggable = isHandleClicked;
    }
    isHandleElement(element) {
        if (element?.classList.contains('p-datatable-reorderable-row-handle')) {
            return true;
        }
        if (element?.parentElement && !['TD', 'TR'].includes(element?.parentElement?.tagName)) {
            return this.isHandleElement(element?.parentElement);
        }
        return false;
    }
    onDragStart(event) {
        this.dataTable.onRowDragStart(event, this.index());
    }
    onDragEnd() {
        this.dataTable.onRowDragEnd();
        this.el.nativeElement.draggable = false;
    }
    onDragOver(event) {
        this.dataTable.onRowDragOver(event, this.index(), this.el.nativeElement);
        event.preventDefault();
    }
    onDragLeave(event) {
        this.dataTable.onRowDragLeave(event, this.el.nativeElement);
    }
    isEnabled() {
        return this.pReorderableRowDisabled() !== true;
    }
    onDrop(event) {
        if (this.isEnabled() && this.dataTable.rowDragging) {
            this.dataTable.onRowDrop(event, this.el.nativeElement);
        }
        event.preventDefault();
    }
    onDestroy() {
        this.unbindEvents();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReorderableRow, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: ReorderableRow, isStandalone: true, selector: "[pReorderableRow]", inputs: { index: { classPropertyName: "index", publicName: "pReorderableRow", isSignal: true, isRequired: false, transformFunction: null }, pReorderableRowDisabled: { classPropertyName: "pReorderableRowDisabled", publicName: "pReorderableRowDisabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "drop": "onDrop($event)" } }, usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ReorderableRow, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pReorderableRow]',
                    host: {
                        '(drop)': 'onDrop($event)'
                    },
                    hostDirectives: [Bind]
                }]
        }], propDecorators: { index: [{ type: i0.Input, args: [{ isSignal: true, alias: "pReorderableRow", required: false }] }], pReorderableRowDisabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "pReorderableRowDisabled", required: false }] }] } });
/**
 * Column Filter Component.
 * @group Components
 */
class ColumnFilter extends BaseComponent {
    hostName = 'Table';
    bindDirectiveInstance = inject(Bind, { self: true });
    _componentStyle = inject(TableStyle);
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptm('columnFilter'));
    }
    ptmFilterConstraintOptions(matchMode) {
        return {
            context: {
                highlighted: matchMode && this.isRowMatchModeSelected(matchMode.value)
            }
        };
    }
    /**
     * Property represented by the column.
     * @group Props
     */
    field = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "field" }] : /* istanbul ignore next */ []));
    /**
     * Type of the input.
     * @group Props
     */
    type = input('text', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    /**
     * Filter display.
     * @group Props
     */
    display = input('row', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "display" }] : /* istanbul ignore next */ []));
    /**
     * Decides whether to display filter menu popup.
     * @group Props
     */
    showMenu = input(true, { ...(ngDevMode ? { debugName: "showMenu" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Filter match mode.
     * @group Props
     */
    matchMode = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "matchMode" }] : /* istanbul ignore next */ []));
    /**
     * Filter operator.
     * @defaultValue 'AND'
     * @group Props
     */
    operator = input(FilterOperator.AND, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "operator" }] : /* istanbul ignore next */ []));
    /**
     * Decides whether to display filter operator.
     * @group Props
     */
    showOperator = input(true, { ...(ngDevMode ? { debugName: "showOperator" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Decides whether to display clear filter button when display is menu.
     * @defaultValue true
     * @group Props
     */
    showClearButton = input(true, { ...(ngDevMode ? { debugName: "showClearButton" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Decides whether to display apply filter button when display is menu.
     * @group Props
     */
    showApplyButton = input(true, { ...(ngDevMode ? { debugName: "showApplyButton" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Decides whether to display filter match modes when display is menu.
     * @group Props
     */
    showMatchModes = input(true, { ...(ngDevMode ? { debugName: "showMatchModes" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Decides whether to display add filter button when display is menu.
     * @group Props
     */
    showAddButton = input(true, { ...(ngDevMode ? { debugName: "showAddButton" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Decides whether to close popup on clear button click.
     * @group Props
     */
    hideOnClear = input(true, { ...(ngDevMode ? { debugName: "hideOnClear" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Filter placeholder.
     * @group Props
     */
    placeholder = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "placeholder" }] : /* istanbul ignore next */ []));
    /**
     * Filter match mode options.
     * @group Props
     */
    matchModeOptions = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "matchModeOptions" }] : /* istanbul ignore next */ []));
    /**
     * Defines maximum amount of constraints.
     * @group Props
     */
    maxConstraints = input(2, { ...(ngDevMode ? { debugName: "maxConstraints" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Defines minimum fraction of digits.
     * @group Props
     */
    minFractionDigits = input(undefined, { ...(ngDevMode ? { debugName: "minFractionDigits" } : /* istanbul ignore next */ {}), transform: (value) => numberAttribute(value, undefined) });
    /**
     * Defines maximum fraction of digits.
     * @group Props
     */
    maxFractionDigits = input(undefined, { ...(ngDevMode ? { debugName: "maxFractionDigits" } : /* istanbul ignore next */ {}), transform: (value) => numberAttribute(value, undefined) });
    /**
     * Defines prefix of the filter.
     * @group Props
     */
    prefix = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "prefix" }] : /* istanbul ignore next */ []));
    /**
     * Defines suffix of the filter.
     * @group Props
     */
    suffix = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "suffix" }] : /* istanbul ignore next */ []));
    /**
     * Defines filter locale.
     * @group Props
     */
    locale = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "locale" }] : /* istanbul ignore next */ []));
    /**
     * Defines filter locale matcher.
     * @group Props
     */
    localeMatcher = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "localeMatcher" }] : /* istanbul ignore next */ []));
    /**
     * Enables currency input.
     * @group Props
     */
    currency = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "currency" }] : /* istanbul ignore next */ []));
    /**
     * Defines the display of the currency input.
     * @group Props
     */
    currencyDisplay = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "currencyDisplay" }] : /* istanbul ignore next */ []));
    /**
     * Default trigger to run filtering on built-in text and numeric filters, valid values are 'enter' and 'input'.
     * @defaultValue enter
     * @group Props
     */
    filterOn = input('enter', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterOn" }] : /* istanbul ignore next */ []));
    /**
     * Defines if filter grouping will be enabled.
     * @group Props
     */
    useGrouping = input(true, { ...(ngDevMode ? { debugName: "useGrouping" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Defines the visibility of buttons.
     * @group Props
     */
    showButtons = input(true, { ...(ngDevMode ? { debugName: "showButtons" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /**
     * Defines the aria-label of the form element.
     * @group Props
     */
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /**
     * Used to pass all filter button property object
     * @defaultValue {
     filter: { severity: 'secondary', text: true, rounded: true },
     inline: {
        clear: { severity: 'secondary', text: true, rounded: true }
     },
     popover: {
         addRule: { severity: 'info', text: true, size: 'small' },
         removeRule: { severity: 'danger', text: true, size: 'small' },
         apply: { size: 'small' },
         clear: { outlined: true, size: 'small' }
        }
     }
     @group Props
     */
    filterButtonProps = input({
        filter: { severity: 'secondary', text: true, rounded: true },
        inline: {
            clear: { severity: 'secondary', text: true, rounded: true }
        },
        popover: {
            addRule: { severity: 'info', text: true, size: 'small' },
            removeRule: { severity: 'danger', text: true, size: 'small' },
            apply: { size: 'small' },
            clear: { outlined: true, size: 'small' }
        }
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "filterButtonProps" }] : /* istanbul ignore next */ []));
    motionOptions = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "motionOptions" }] : /* istanbul ignore next */ []));
    computedMotionOptions = computed(() => ({
        ...this.ptm('motion'),
        ...this.motionOptions()
    }), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "computedMotionOptions" }] : /* istanbul ignore next */ []));
    /**
     * Callback to invoke on overlay is shown.
     * @param {AnimationEvent} originalEvent - animation event.
     * @group Emits
     */
    onShow = output();
    /**
     * Callback to invoke on overlay is hidden.
     * @param {AnimationEvent} originalEvent - animation event.
     * @group Emits
     */
    onHide = output();
    icon = viewChild(Button, { ...(ngDevMode ? { debugName: "icon" } : /* istanbul ignore next */ {}), read: ElementRef });
    clearButtonViewChild = viewChild('clearBtn', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "clearButtonViewChild" }] : /* istanbul ignore next */ []));
    _templates = contentChildren(PrimeTemplate, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "_templates" }] : /* istanbul ignore next */ []));
    overlaySubscription;
    renderOverlay = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "renderOverlay" }] : /* istanbul ignore next */ []));
    /**
     * Custom header template.
     * @group Templates
     */
    headerTemplate = contentChild('header', { ...(ngDevMode ? { debugName: "headerTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    _headerTemplate;
    /**
     * Custom filter template.
     * @group Templates
     */
    filterTemplate = contentChild('filter', { ...(ngDevMode ? { debugName: "filterTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    _filterTemplate;
    /**
     * Custom footer template.
     * @group Templates
     */
    footerTemplate = contentChild('footer', { ...(ngDevMode ? { debugName: "footerTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    _footerTemplate;
    /**
     * Custom filter icon template.
     * @group Templates
     */
    filterIconTemplate;
    _filterIconTemplate;
    /**
     * Custom remove rule button icon template.
     * @group Templates
     */
    removeRuleIconTemplate = contentChild('removeruleicon', { ...(ngDevMode ? { debugName: "removeRuleIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    _removeRuleIconTemplate;
    /**
     * Custom add rule button icon template.
     * @group Templates
     */
    addRuleIconTemplate = contentChild('addruleicon', { ...(ngDevMode ? { debugName: "addRuleIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    _addRuleIconTemplate;
    clearFilterIconTemplate = contentChild('clearfiltericon', { ...(ngDevMode ? { debugName: "clearFilterIconTemplate" } : /* istanbul ignore next */ {}), descendants: false });
    _clearFilterIconTemplate;
    operatorOptions;
    overlayVisible;
    overlay;
    scrollHandler;
    documentClickListener;
    _operator;
    constructor() {
        super();
        effect(() => {
            this._operator = this.operator();
        });
    }
    documentResizeListener;
    matchModes;
    translationSubscription;
    resetSubscription;
    selfClick;
    overlayEventListener;
    overlayId;
    get fieldConstraints() {
        const filters = this.dataTable._filters;
        return filters ? filters[this.field()] : null;
    }
    get showRemoveIcon() {
        return this.fieldConstraints ? this.fieldConstraints.length > 1 : false;
    }
    get showMenuButton() {
        return this.showMenu() && (this.display() === 'row' ? this.type() !== 'boolean' : true);
    }
    get isShowOperator() {
        return this.showOperator() && this.type() !== 'boolean';
    }
    get isShowAddConstraint() {
        return this.showAddButton() && this.type() !== 'boolean' && this.fieldConstraints && this.fieldConstraints.length < this.maxConstraints();
    }
    get showMenuButtonLabel() {
        return this.config.getTranslation(TranslationKeys.SHOW_FILTER_MENU);
    }
    get applyButtonLabel() {
        return this.config.getTranslation(TranslationKeys.APPLY);
    }
    get clearButtonLabel() {
        return this.config.getTranslation(TranslationKeys.CLEAR);
    }
    get addRuleButtonLabel() {
        return this.config.getTranslation(TranslationKeys.ADD_RULE);
    }
    get removeRuleButtonLabel() {
        return this.config.getTranslation(TranslationKeys.REMOVE_RULE);
    }
    get noFilterLabel() {
        return this.config.getTranslation(TranslationKeys.NO_FILTER);
    }
    get filterMenuButtonAriaLabel() {
        return this.config?.translation ? (this.overlayVisible ? this.config?.translation?.aria?.hideFilterMenu : this.config?.translation?.aria?.showFilterMenu) : undefined;
    }
    get removeRuleButtonAriaLabel() {
        return this.config?.translation ? this.config?.translation?.removeRule : undefined;
    }
    get filterOperatorAriaLabel() {
        return this.config?.translation ? this.config?.translation?.aria?.filterOperator : undefined;
    }
    get filterConstraintAriaLabel() {
        return this.config?.translation ? this.config?.translation?.aria?.filterConstraint : undefined;
    }
    dataTable = inject(Table);
    overlayService = inject(OverlayService);
    onInit() {
        this.overlayId = UniqueComponentId();
        if (!this.dataTable._filters[this.field()]) {
            this.initFieldFilterConstraint();
        }
        this.translationSubscription = this.config.translationObserver.subscribe(() => {
            this.generateMatchModeOptions();
            this.generateOperatorOptions();
        });
        this.generateMatchModeOptions();
        this.generateOperatorOptions();
    }
    generateMatchModeOptions() {
        this.matchModes =
            this.matchModeOptions() ||
                this.config.filterMatchModeOptions[this.type()]?.map((key) => ({
                    label: this.config.getTranslation(key),
                    value: key
                }));
    }
    generateOperatorOptions() {
        this.operatorOptions = [
            {
                label: this.config.getTranslation(TranslationKeys.MATCH_ALL),
                value: FilterOperator.AND
            },
            {
                label: this.config.getTranslation(TranslationKeys.MATCH_ANY),
                value: FilterOperator.OR
            }
        ];
    }
    onAfterContentInit() {
        this._templates().forEach((item) => {
            switch (item.getType()) {
                case 'header':
                    this._headerTemplate = item.template;
                    break;
                case 'filter':
                    this._filterTemplate = item.template;
                    break;
                case 'footer':
                    this._footerTemplate = item.template;
                    break;
                case 'filtericon':
                    this._filterIconTemplate = item.template;
                    break;
                case 'clearfiltericon':
                    this._clearFilterIconTemplate = item.template;
                    break;
                case 'removeruleicon':
                    this._removeRuleIconTemplate = item.template;
                    break;
                case 'addruleicon':
                    this._addRuleIconTemplate = item.template;
                    break;
                default:
                    this._filterTemplate = item.template;
                    break;
            }
        });
    }
    initFieldFilterConstraint() {
        let defaultMatchMode = this.getDefaultMatchMode();
        this.dataTable._filters[this.field()] =
            this.display() == 'row'
                ? { value: null, matchMode: defaultMatchMode }
                : [
                    {
                        value: null,
                        matchMode: defaultMatchMode,
                        operator: this._operator
                    }
                ];
    }
    onMenuMatchModeChange(value, filterMeta) {
        filterMeta.matchMode = value;
        if (!this.showApplyButton()) {
            this.dataTable._filter();
        }
    }
    onRowMatchModeChange(matchMode) {
        const fieldFilter = this.dataTable._filters[this.field()];
        fieldFilter.matchMode = matchMode;
        if (fieldFilter.value) {
            this.dataTable._filter();
        }
        this.hide();
    }
    onRowMatchModeKeyDown(event) {
        let item = event.target;
        switch (event.key) {
            case 'ArrowDown': {
                let nextItem = this.findNextItem(item);
                if (nextItem) {
                    item.removeAttribute('tabindex');
                    nextItem.tabIndex = '0';
                    nextItem.focus();
                }
                event.preventDefault();
                break;
            }
            case 'ArrowUp': {
                let prevItem = this.findPrevItem(item);
                if (prevItem) {
                    item.removeAttribute('tabindex');
                    prevItem.tabIndex = '0';
                    prevItem.focus();
                }
                event.preventDefault();
                break;
            }
        }
    }
    onRowClearItemClick() {
        this.clearFilter();
        this.hide();
    }
    isRowMatchModeSelected(matchMode) {
        return this.dataTable._filters[this.field()].matchMode === matchMode;
    }
    addConstraint() {
        this.dataTable._filters[this.field()].push({
            value: null,
            matchMode: this.getDefaultMatchMode(),
            operator: this.getDefaultOperator()
        });
        DomHandler.focus(this.clearButtonViewChild()?.nativeElement);
    }
    removeConstraint(filterMeta) {
        this.dataTable._filters[this.field()] = this.dataTable._filters[this.field()].filter((meta) => meta !== filterMeta);
        if (!this.showApplyButton()) {
            this.dataTable._filter();
        }
        DomHandler.focus(this.clearButtonViewChild()?.nativeElement);
    }
    onOperatorChange(value) {
        this.dataTable._filters[this.field()].forEach((filterMeta) => {
            filterMeta.operator = value;
            this._operator = value;
        });
        if (!this.showApplyButton()) {
            this.dataTable._filter();
        }
    }
    toggleMenu(event) {
        this.overlayVisible = !this.overlayVisible;
        this.renderOverlay.set(!this.renderOverlay());
        event.stopPropagation();
    }
    onToggleButtonKeyDown(event) {
        switch (event.key) {
            case 'Escape':
            case 'Tab':
                this.overlayVisible = false;
                break;
            case 'ArrowDown':
                if (this.overlayVisible) {
                    let focusable = DomHandler.getFocusableElements(this.overlay);
                    if (focusable) {
                        focusable[0].focus();
                    }
                    event.preventDefault();
                }
                else if (event.altKey) {
                    this.overlayVisible = true;
                    event.preventDefault();
                }
                break;
            case 'Enter':
                this.toggleMenu(event);
                event.preventDefault();
                break;
        }
    }
    onEscape() {
        this.overlayVisible = false;
        this.icon()?.nativeElement.focus();
    }
    findNextItem(item) {
        let nextItem = item.nextElementSibling;
        if (nextItem)
            return find(nextItem, '[data-pc-section="filterconstraintseparator"]') ? this.findNextItem(nextItem) : nextItem;
        else
            return item.parentElement?.firstElementChild;
    }
    findPrevItem(item) {
        let prevItem = item.previousElementSibling;
        if (prevItem)
            return find(prevItem, '[data-pc-section="filterconstraintseparator"]') ? this.findPrevItem(prevItem) : prevItem;
        else
            return item.parentElement?.lastElementChild;
    }
    onContentClick() {
        this.selfClick = true;
    }
    onOverlayBeforeEnter(event) {
        this.overlay = event.element;
        if (this.overlay && this.overlay.parentElement !== this.document.body) {
            const buttonEl = findSingle(this.el.nativeElement, '[data-pc-name="pccolumnfilterbutton"]');
            appendChild(this.document.body, this.overlay);
            addStyle(this.overlay, { position: 'absolute', top: '0' });
            absolutePosition(this.overlay, buttonEl);
            ZIndexUtils.set('overlay', this.overlay, this.config.zIndex.overlay);
        }
        this.bindDocumentClickListener();
        this.bindDocumentResizeListener();
        this.bindScrollListener();
        this.overlayEventListener = (e) => {
            if (this.overlay && this.overlay.contains(e.target)) {
                this.selfClick = true;
            }
        };
        this.overlaySubscription = this.overlayService.clickObservable.subscribe(this.overlayEventListener);
        this.onShow.emit({ originalEvent: event });
        this.focusOnFirstElement();
    }
    onOverlayAnimationAfterLeave(event) {
        this.restoreOverlayAppend();
        this.onOverlayHide();
        this.renderOverlay.set(false);
        if (this.overlaySubscription) {
            this.overlaySubscription.unsubscribe();
        }
        ZIndexUtils.clear(this.overlay);
        this.onHide.emit({ originalEvent: event });
    }
    restoreOverlayAppend() {
        if (this.overlay) {
            this.el.nativeElement.appendChild(this.overlay);
        }
    }
    focusOnFirstElement() {
        if (this.overlay) {
            DomHandler.focus(DomHandler.getFirstFocusableElement(this.overlay, ''));
        }
    }
    getDefaultMatchMode() {
        const matchMode = this.matchMode();
        if (matchMode) {
            return matchMode;
        }
        else {
            const type = this.type();
            if (type === 'text')
                return FilterMatchMode.STARTS_WITH;
            else if (type === 'numeric')
                return FilterMatchMode.EQUALS;
            else if (type === 'date')
                return FilterMatchMode.DATE_IS;
            else
                return FilterMatchMode.CONTAINS;
        }
    }
    getDefaultOperator() {
        const filters = this.dataTable._filters;
        return filters ? filters[this.field()][0].operator : this._operator;
    }
    hasRowFilter() {
        return this.dataTable._filters[this.field()] && !this.dataTable.isFilterBlank(this.dataTable._filters[this.field()].value);
    }
    get hasFilter() {
        let fieldFilter = this.dataTable._filters[this.field()];
        if (fieldFilter) {
            if (Array.isArray(fieldFilter))
                return !this.dataTable.isFilterBlank(fieldFilter[0].value);
            else
                return !this.dataTable.isFilterBlank(fieldFilter.value);
        }
        return false;
    }
    isOutsideClicked(event) {
        const icon = this.icon();
        return !(findSingle(this.overlay.nextElementSibling, '[data-pc-section="filteroverlay"]') ||
            findSingle(this.overlay.nextElementSibling, '[data-pc-name="popover"]') ||
            this.overlay?.isSameNode(event.target) ||
            this.overlay?.contains(event.target) ||
            icon?.nativeElement.isSameNode(event.target) ||
            icon?.nativeElement.contains(event.target) ||
            findSingle(event.target, '[data-pc-name="pcaddrulebuttonlabel"]') ||
            findSingle(event.target.parentElement, '[data-pc-name="pcaddrulebuttonlabel"]') ||
            findSingle(event.target, '[data-pc-name="pcfilterremoverulebutton"]') ||
            findSingle(event.target.parentElement, '[data-pc-name="pcfilterremoverulebutton"]'));
    }
    bindDocumentClickListener() {
        if (!this.documentClickListener) {
            const documentTarget = this.el ? this.el.nativeElement.ownerDocument : 'document';
            this.documentClickListener = this.renderer.listen(documentTarget, 'mousedown', (event) => {
                const dialogElements = document.querySelectorAll('[role="dialog"]');
                const targetIsColumnFilterMenuButton = event.target.closest('[data-pc-name="pccolumnfilterbutton"]');
                if (this.overlayVisible && this.isOutsideClicked(event) && (targetIsColumnFilterMenuButton || dialogElements?.length <= 1)) {
                    this.hide();
                }
                this.selfClick = false;
            });
        }
    }
    unbindDocumentClickListener() {
        if (this.documentClickListener) {
            this.documentClickListener();
            this.documentClickListener = null;
            this.selfClick = false;
        }
    }
    bindDocumentResizeListener() {
        if (!this.documentResizeListener) {
            this.documentResizeListener = this.renderer.listen(this.document.defaultView, 'resize', () => {
                if (this.overlayVisible && !DomHandler.isTouchDevice()) {
                    this.hide();
                }
            });
        }
    }
    unbindDocumentResizeListener() {
        if (this.documentResizeListener) {
            this.documentResizeListener();
            this.documentResizeListener = null;
        }
    }
    bindScrollListener() {
        if (!this.scrollHandler) {
            this.scrollHandler = new ConnectedOverlayScrollHandler(this.icon()?.nativeElement, () => {
                if (this.overlayVisible) {
                    this.hide();
                }
            });
        }
        this.scrollHandler.bindScrollListener();
    }
    unbindScrollListener() {
        if (this.scrollHandler) {
            this.scrollHandler.unbindScrollListener();
        }
    }
    hide() {
        this.overlayVisible = false;
        this.cd.markForCheck();
    }
    onOverlayHide() {
        this.unbindDocumentClickListener();
        this.unbindDocumentResizeListener();
        this.unbindScrollListener();
        this.overlay = null;
    }
    clearFilter() {
        this.initFieldFilterConstraint();
        this.dataTable._filter();
        if (this.hideOnClear())
            this.hide();
    }
    applyFilter() {
        this.dataTable._filter();
        this.hide();
    }
    onDestroy() {
        if (this.overlay) {
            this.restoreOverlayAppend();
            ZIndexUtils.clear(this.overlay);
            this.onOverlayHide();
        }
        if (this.translationSubscription) {
            this.translationSubscription.unsubscribe();
        }
        if (this.resetSubscription) {
            this.resetSubscription.unsubscribe();
        }
        if (this.overlaySubscription) {
            this.overlaySubscription.unsubscribe();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ColumnFilter, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: ColumnFilter, isStandalone: true, selector: "p-columnFilter, p-column-filter, p-columnfilter", inputs: { field: { classPropertyName: "field", publicName: "field", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, display: { classPropertyName: "display", publicName: "display", isSignal: true, isRequired: false, transformFunction: null }, showMenu: { classPropertyName: "showMenu", publicName: "showMenu", isSignal: true, isRequired: false, transformFunction: null }, matchMode: { classPropertyName: "matchMode", publicName: "matchMode", isSignal: true, isRequired: false, transformFunction: null }, operator: { classPropertyName: "operator", publicName: "operator", isSignal: true, isRequired: false, transformFunction: null }, showOperator: { classPropertyName: "showOperator", publicName: "showOperator", isSignal: true, isRequired: false, transformFunction: null }, showClearButton: { classPropertyName: "showClearButton", publicName: "showClearButton", isSignal: true, isRequired: false, transformFunction: null }, showApplyButton: { classPropertyName: "showApplyButton", publicName: "showApplyButton", isSignal: true, isRequired: false, transformFunction: null }, showMatchModes: { classPropertyName: "showMatchModes", publicName: "showMatchModes", isSignal: true, isRequired: false, transformFunction: null }, showAddButton: { classPropertyName: "showAddButton", publicName: "showAddButton", isSignal: true, isRequired: false, transformFunction: null }, hideOnClear: { classPropertyName: "hideOnClear", publicName: "hideOnClear", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, matchModeOptions: { classPropertyName: "matchModeOptions", publicName: "matchModeOptions", isSignal: true, isRequired: false, transformFunction: null }, maxConstraints: { classPropertyName: "maxConstraints", publicName: "maxConstraints", isSignal: true, isRequired: false, transformFunction: null }, minFractionDigits: { classPropertyName: "minFractionDigits", publicName: "minFractionDigits", isSignal: true, isRequired: false, transformFunction: null }, maxFractionDigits: { classPropertyName: "maxFractionDigits", publicName: "maxFractionDigits", isSignal: true, isRequired: false, transformFunction: null }, prefix: { classPropertyName: "prefix", publicName: "prefix", isSignal: true, isRequired: false, transformFunction: null }, suffix: { classPropertyName: "suffix", publicName: "suffix", isSignal: true, isRequired: false, transformFunction: null }, locale: { classPropertyName: "locale", publicName: "locale", isSignal: true, isRequired: false, transformFunction: null }, localeMatcher: { classPropertyName: "localeMatcher", publicName: "localeMatcher", isSignal: true, isRequired: false, transformFunction: null }, currency: { classPropertyName: "currency", publicName: "currency", isSignal: true, isRequired: false, transformFunction: null }, currencyDisplay: { classPropertyName: "currencyDisplay", publicName: "currencyDisplay", isSignal: true, isRequired: false, transformFunction: null }, filterOn: { classPropertyName: "filterOn", publicName: "filterOn", isSignal: true, isRequired: false, transformFunction: null }, useGrouping: { classPropertyName: "useGrouping", publicName: "useGrouping", isSignal: true, isRequired: false, transformFunction: null }, showButtons: { classPropertyName: "showButtons", publicName: "showButtons", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, filterButtonProps: { classPropertyName: "filterButtonProps", publicName: "filterButtonProps", isSignal: true, isRequired: false, transformFunction: null }, motionOptions: { classPropertyName: "motionOptions", publicName: "motionOptions", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { onShow: "onShow", onHide: "onHide" }, providers: [TableStyle], queries: [{ propertyName: "_templates", predicate: PrimeTemplate, isSignal: true }, { propertyName: "headerTemplate", first: true, predicate: ["header"], isSignal: true }, { propertyName: "filterTemplate", first: true, predicate: ["filter"], isSignal: true }, { propertyName: "footerTemplate", first: true, predicate: ["footer"], isSignal: true }, { propertyName: "removeRuleIconTemplate", first: true, predicate: ["removeruleicon"], isSignal: true }, { propertyName: "addRuleIconTemplate", first: true, predicate: ["addruleicon"], isSignal: true }, { propertyName: "clearFilterIconTemplate", first: true, predicate: ["clearfiltericon"], isSignal: true }, { propertyName: "filterIconTemplate", first: true, predicate: ["filtericon"] }], viewQueries: [{ propertyName: "icon", first: true, predicate: Button, descendants: true, read: ElementRef, isSignal: true }, { propertyName: "clearButtonViewChild", first: true, predicate: ["clearBtn"], descendants: true, isSignal: true }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        <div [class]="cx('filter')">
            @if (display() === 'row') {
                <p-columnFilterFormElement
                    class="p-fluid"
                    [type]="type()"
                    [field]="field()"
                    [ariaLabel]="ariaLabel()"
                    [filterConstraint]="dataTable._filters[field()]"
                    [filterTemplate]="filterTemplate() || _filterTemplate"
                    [placeholder]="placeholder()"
                    [minFractionDigits]="minFractionDigits()"
                    [maxFractionDigits]="maxFractionDigits()"
                    [prefix]="prefix()"
                    [suffix]="suffix()"
                    [locale]="locale()"
                    [localeMatcher]="localeMatcher()"
                    [currency]="currency()"
                    [currencyDisplay]="currencyDisplay()"
                    [useGrouping]="useGrouping()"
                    [showButtons]="showButtons()"
                    [filterOn]="filterOn()"
                    [pt]="pt()"
                    [unstyled]="unstyled()"
                ></p-columnFilterFormElement>
            }
            @if (showMenuButton) {
                <p-button
                    [styleClass]="cx('pcColumnFilterButton')"
                    [pt]="ptm('pcColumnFilterButton')"
                    [attr.aria-haspopup]="true"
                    [ariaLabel]="filterMenuButtonAriaLabel"
                    [attr.aria-controls]="overlayVisible ? overlayId : null"
                    [attr.aria-expanded]="overlayVisible ?? false"
                    (click)="toggleMenu($event)"
                    (keydown)="onToggleButtonKeyDown($event)"
                    [buttonProps]="filterButtonProps()?.filter"
                    #menuButton
                    [unstyled]="unstyled()"
                >
                    <ng-template #icon>
                        <ng-container>
                            @if (!filterIconTemplate && !_filterIconTemplate && !hasFilter) {
                                <svg data-p-icon="filter" [pBind]="ptm('pcColumnFilterButton')['icon']" />
                            }
                            @if (!filterIconTemplate && !_filterIconTemplate && hasFilter) {
                                <svg data-p-icon="filter-fill" [pBind]="ptm('pcColumnFilterButton')['icon']" />
                            }
                            @if (filterIconTemplate || _filterIconTemplate) {
                                <span [pBind]="ptm('pcColumnFilterButton')['icon']" [attr.data-pc-section]="'columnfilterbuttonicon'">
                                    <ng-template *ngTemplateOutlet="filterIconTemplate || _filterIconTemplate; context: { hasFilter: hasFilter }"></ng-template>
                                </span>
                            }
                        </ng-container>
                    </ng-template>
                </p-button>
            }
            @if (renderOverlay()) {
                <div
                    [pMotion]="showMenu() && overlayVisible"
                    [pMotionAppear]="true"
                    pMotionName="p-anchored-overlay"
                    (pMotionOnBeforeEnter)="onOverlayBeforeEnter($event)"
                    (pMotionOnAfterLeave)="onOverlayAnimationAfterLeave($event)"
                    [pMotionOptions]="computedMotionOptions()"
                    [class]="cx('filterOverlay')"
                    [pBind]="ptm('filterOverlay')"
                    [id]="overlayId"
                    [attr.aria-modal]="true"
                    role="dialog"
                    (click)="onContentClick()"
                    (keydown.escape)="onEscape()"
                >
                    <ng-container *ngTemplateOutlet="headerTemplate() || _headerTemplate; context: { $implicit: field() }"></ng-container>
                    @if (display() === 'row') {
                        <ul [class]="cx('filterConstraintList')" [pBind]="ptm('filterConstraintList')">
                            @for (matchMode of matchModes; track matchMode(); let i = $index) {
                                <li
                                    (click)="onRowMatchModeChange(matchMode().value)"
                                    (keydown)="onRowMatchModeKeyDown($event)"
                                    (keydown.enter)="onRowMatchModeChange(matchMode().value)"
                                    [class]="cx('filterConstraint')"
                                    [pBind]="ptm('filterConstraint', ptmFilterConstraintOptions(matchMode()))"
                                    [class.p-datatable-filter-constraint-selected]="isRowMatchModeSelected(matchMode().value)"
                                    [attr.tabindex]="i === 0 ? '0' : null"
                                >
                                    () {{ matchMode.label }}
                                </li>
                            }
                            <li [class]="cx('filterConstraintSeparator')" [pBind]="ptm('filterConstraintSeparator', { context: { index: i } })"></li>
                            <li [class]="cx('filterConstraint')" [pBind]="ptm('emtpyFilterLabel')" (click)="onRowClearItemClick()" (keydown)="onRowMatchModeKeyDown($event)" (keydown.enter)="onRowClearItemClick()">
                                {{ noFilterLabel }}
                            </li>
                        </ul>
                    } @else {
                        @if (isShowOperator) {
                            <div [class]="cx('filterOperator')" [pBind]="ptm('filterOperator')">
                                <p-select
                                    [options]="operatorOptions"
                                    [pt]="ptm('pcFilterOperatorDropdown')"
                                    [ngModel]="operator()"
                                    (ngModelChange)="onOperatorChange($event)"
                                    [styleClass]="cx('pcFilterOperatorDropdown')"
                                    [unstyled]="unstyled()"
                                ></p-select>
                            </div>
                        }
                        <div [class]="cx('filterRuleList')" [pBind]="ptm('filterRuleList')">
                            @for (fieldConstraint of fieldConstraints; track fieldConstraint; let i = $index) {
                                <div [ngClass]="cx('filterRule')" [pBind]="ptm('filterRule')">
                                    @if (showMatchModes() && matchModes) {
                                        <p-select
                                            [options]="matchModes"
                                            [ngModel]="fieldConstraint.matchMode"
                                            (ngModelChange)="onMenuMatchModeChange($event, fieldConstraint)"
                                            [styleClass]="cx('pcFilterConstraintDropdown')"
                                            [pt]="ptm('pcFilterConstraintDropdown')"
                                            [unstyled]="unstyled()"
                                        ></p-select>
                                    }
                                    <p-columnFilterFormElement
                                        [type]="type()"
                                        [field]="field()"
                                        [filterConstraint]="fieldConstraint"
                                        [filterTemplate]="filterTemplate() || _filterTemplate"
                                        [placeholder]="placeholder()"
                                        [minFractionDigits]="minFractionDigits()"
                                        [maxFractionDigits]="maxFractionDigits()"
                                        [prefix]="prefix()"
                                        [suffix]="suffix()"
                                        [locale]="locale()"
                                        [localeMatcher]="localeMatcher()"
                                        [currency]="currency()"
                                        [currencyDisplay]="currencyDisplay()"
                                        [useGrouping]="useGrouping()"
                                        [filterOn]="filterOn()"
                                        [pt]="pt()"
                                        [unstyled]="unstyled()"
                                    ></p-columnFilterFormElement>
                                    <div>
                                        @if (showRemoveIcon) {
                                            <p-button
                                                [styleClass]="cx('pcFilterRemoveRuleButton')"
                                                [pt]="ptm('pcFilterRemoveRuleButton')"
                                                [text]="true"
                                                severity="danger"
                                                size="small"
                                                (onClick)="removeConstraint(fieldConstraint)"
                                                [ariaLabel]="removeRuleButtonLabel"
                                                [label]="removeRuleButtonLabel"
                                                [buttonProps]="filterButtonProps()?.popover?.removeRule"
                                                [unstyled]="unstyled()"
                                            >
                                                <ng-template #icon>
                                                    @if (!removeRuleIconTemplate() && !_removeRuleIconTemplate) {
                                                        <svg data-p-icon="trash" [pBind]="ptm('pcFilterRemoveRuleButton')['icon']" />
                                                    }
                                                    <ng-template *ngTemplateOutlet="removeRuleIconTemplate() || _removeRuleIconTemplate"></ng-template>
                                                </ng-template>
                                            </p-button>
                                        }
                                    </div>
                                </div>
                            }
                        </div>
                        @if (isShowAddConstraint) {
                            <p-button
                                type="button"
                                [pt]="ptm('pcAddRuleButtonLabel')"
                                [label]="addRuleButtonLabel"
                                [attr.aria-label]="addRuleButtonLabel"
                                [styleClass]="cx('pcFilterAddRuleButton')"
                                [text]="true"
                                size="small"
                                (onClick)="addConstraint()"
                                [buttonProps]="filterButtonProps()?.popover?.addRule"
                                [unstyled]="unstyled()"
                            >
                                <ng-template #icon>
                                    @if (!addRuleIconTemplate() && !_addRuleIconTemplate) {
                                        <svg data-p-icon="plus" [pBind]="ptm('pcAddRuleButtonLabel')['icon']" />
                                    }
                                    <ng-template *ngTemplateOutlet="addRuleIconTemplate() || _addRuleIconTemplate"></ng-template>
                                </ng-template>
                            </p-button>
                        }
                        <div [class]="cx('filterButtonbar')" [pBind]="ptm('filterButtonBar')">
                            @if (showClearButton()) {
                                <p-button
                                    #clearBtn
                                    [outlined]="true"
                                    (onClick)="clearFilter()"
                                    [attr.aria-label]="clearButtonLabel"
                                    [label]="clearButtonLabel"
                                    [buttonProps]="filterButtonProps()?.popover?.clear"
                                    [pt]="ptm('pcFilterClearButton')"
                                    [unstyled]="unstyled()"
                                />
                            }
                            @if (showApplyButton()) {
                                <p-button
                                    (onClick)="applyFilter()"
                                    size="small"
                                    [label]="applyButtonLabel"
                                    [attr.aria-label]="applyButtonLabel"
                                    [buttonProps]="filterButtonProps()?.popover?.apply"
                                    [pt]="ptm('pcFilterApplyButton')"
                                    [unstyled]="unstyled()"
                                />
                            }
                        </div>
                    }
                    <ng-container *ngTemplateOutlet="footerTemplate() || _footerTemplate; context: { $implicit: field() }"></ng-container>
                </div>
            }
        </div>
    `, isInline: true, dependencies: [{ kind: "component", type: i0.forwardRef(() => ColumnFilterFormElement), selector: "p-columnFilterFormElement, p-column-filter-form-element, p-columnfilterformelement", inputs: ["field", "type", "filterConstraint", "filterTemplate", "placeholder", "minFractionDigits", "maxFractionDigits", "prefix", "suffix", "locale", "localeMatcher", "currency", "currencyDisplay", "useGrouping", "ariaLabel", "filterOn"] }, { kind: "component", type: i0.forwardRef(() => Button), selector: "p-button", inputs: ["hostName", "type", "badge", "disabled", "raised", "rounded", "text", "plain", "outlined", "link", "tabindex", "size", "variant", "style", "styleClass", "badgeClass", "badgeSeverity", "ariaLabel", "autofocus", "iconPos", "icon", "label", "loading", "loadingIcon", "severity", "buttonProps", "fluid"], outputs: ["onClick", "onFocus", "onBlur"] }, { kind: "component", type: i0.forwardRef(() => FilterIcon), selector: "[data-p-icon=\"filter\"]" }, { kind: "component", type: i0.forwardRef(() => FilterFillIcon), selector: "[data-p-icon=\"filter-fill\"]" }, { kind: "directive", type: i0.forwardRef(() => NgTemplateOutlet), selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: i0.forwardRef(() => MotionDirective), selector: "[pMotion]", inputs: ["pMotion", "pMotionName", "pMotionType", "pMotionSafe", "pMotionDisabled", "pMotionAppear", "pMotionEnter", "pMotionLeave", "pMotionDuration", "pMotionHideStrategy", "pMotionEnterFromClass", "pMotionEnterToClass", "pMotionEnterActiveClass", "pMotionLeaveFromClass", "pMotionLeaveToClass", "pMotionLeaveActiveClass", "pMotionOptions"], outputs: ["pMotionOnBeforeEnter", "pMotionOnEnter", "pMotionOnAfterEnter", "pMotionOnEnterCancelled", "pMotionOnBeforeLeave", "pMotionOnLeave", "pMotionOnAfterLeave", "pMotionOnLeaveCancelled"] }, { kind: "component", type: i0.forwardRef(() => Select), selector: "p-select", inputs: ["id", "scrollHeight", "filter", "panelStyle", "styleClass", "panelStyleClass", "readonly", "editable", "tabindex", "placeholder", "loadingIcon", "filterPlaceholder", "filterLocale", "inputId", "dataKey", "filterBy", "filterFields", "autofocus", "resetFilterOnHide", "checkmark", "dropdownIcon", "loading", "optionLabel", "optionValue", "optionDisabled", "optionGroupLabel", "optionGroupChildren", "group", "showClear", "emptyFilterMessage", "emptyMessage", "lazy", "virtualScroll", "virtualScrollItemSize", "virtualScrollOptions", "overlayOptions", "ariaFilterLabel", "ariaLabel", "ariaLabelledBy", "filterMatchMode", "tooltip", "tooltipPosition", "tooltipPositionStyle", "tooltipStyleClass", "focusOnHover", "selectOnFocus", "autoOptionFocus", "autofocusFilter", "filterValue", "options", "appendTo", "motionOptions"], outputs: ["onChange", "onFilter", "onFocus", "onBlur", "onClick", "onShow", "onHide", "onClear", "onLazyLoad"] }, { kind: "ngmodule", type: i0.forwardRef(() => FormsModule) }, { kind: "directive", type: i0.forwardRef(() => i2.NgControlStatus), selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i0.forwardRef(() => i2.NgModel), selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i0.forwardRef(() => NgClass), selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: i0.forwardRef(() => TrashIcon), selector: "[data-p-icon=\"trash\"]" }, { kind: "component", type: i0.forwardRef(() => PlusIcon), selector: "[data-p-icon=\"plus\"]" }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ColumnFilter, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-columnFilter, p-column-filter, p-columnfilter',
                    template: `
        <div [class]="cx('filter')">
            @if (display() === 'row') {
                <p-columnFilterFormElement
                    class="p-fluid"
                    [type]="type()"
                    [field]="field()"
                    [ariaLabel]="ariaLabel()"
                    [filterConstraint]="dataTable._filters[field()]"
                    [filterTemplate]="filterTemplate() || _filterTemplate"
                    [placeholder]="placeholder()"
                    [minFractionDigits]="minFractionDigits()"
                    [maxFractionDigits]="maxFractionDigits()"
                    [prefix]="prefix()"
                    [suffix]="suffix()"
                    [locale]="locale()"
                    [localeMatcher]="localeMatcher()"
                    [currency]="currency()"
                    [currencyDisplay]="currencyDisplay()"
                    [useGrouping]="useGrouping()"
                    [showButtons]="showButtons()"
                    [filterOn]="filterOn()"
                    [pt]="pt()"
                    [unstyled]="unstyled()"
                ></p-columnFilterFormElement>
            }
            @if (showMenuButton) {
                <p-button
                    [styleClass]="cx('pcColumnFilterButton')"
                    [pt]="ptm('pcColumnFilterButton')"
                    [attr.aria-haspopup]="true"
                    [ariaLabel]="filterMenuButtonAriaLabel"
                    [attr.aria-controls]="overlayVisible ? overlayId : null"
                    [attr.aria-expanded]="overlayVisible ?? false"
                    (click)="toggleMenu($event)"
                    (keydown)="onToggleButtonKeyDown($event)"
                    [buttonProps]="filterButtonProps()?.filter"
                    #menuButton
                    [unstyled]="unstyled()"
                >
                    <ng-template #icon>
                        <ng-container>
                            @if (!filterIconTemplate && !_filterIconTemplate && !hasFilter) {
                                <svg data-p-icon="filter" [pBind]="ptm('pcColumnFilterButton')['icon']" />
                            }
                            @if (!filterIconTemplate && !_filterIconTemplate && hasFilter) {
                                <svg data-p-icon="filter-fill" [pBind]="ptm('pcColumnFilterButton')['icon']" />
                            }
                            @if (filterIconTemplate || _filterIconTemplate) {
                                <span [pBind]="ptm('pcColumnFilterButton')['icon']" [attr.data-pc-section]="'columnfilterbuttonicon'">
                                    <ng-template *ngTemplateOutlet="filterIconTemplate || _filterIconTemplate; context: { hasFilter: hasFilter }"></ng-template>
                                </span>
                            }
                        </ng-container>
                    </ng-template>
                </p-button>
            }
            @if (renderOverlay()) {
                <div
                    [pMotion]="showMenu() && overlayVisible"
                    [pMotionAppear]="true"
                    pMotionName="p-anchored-overlay"
                    (pMotionOnBeforeEnter)="onOverlayBeforeEnter($event)"
                    (pMotionOnAfterLeave)="onOverlayAnimationAfterLeave($event)"
                    [pMotionOptions]="computedMotionOptions()"
                    [class]="cx('filterOverlay')"
                    [pBind]="ptm('filterOverlay')"
                    [id]="overlayId"
                    [attr.aria-modal]="true"
                    role="dialog"
                    (click)="onContentClick()"
                    (keydown.escape)="onEscape()"
                >
                    <ng-container *ngTemplateOutlet="headerTemplate() || _headerTemplate; context: { $implicit: field() }"></ng-container>
                    @if (display() === 'row') {
                        <ul [class]="cx('filterConstraintList')" [pBind]="ptm('filterConstraintList')">
                            @for (matchMode of matchModes; track matchMode(); let i = $index) {
                                <li
                                    (click)="onRowMatchModeChange(matchMode().value)"
                                    (keydown)="onRowMatchModeKeyDown($event)"
                                    (keydown.enter)="onRowMatchModeChange(matchMode().value)"
                                    [class]="cx('filterConstraint')"
                                    [pBind]="ptm('filterConstraint', ptmFilterConstraintOptions(matchMode()))"
                                    [class.p-datatable-filter-constraint-selected]="isRowMatchModeSelected(matchMode().value)"
                                    [attr.tabindex]="i === 0 ? '0' : null"
                                >
                                    () {{ matchMode.label }}
                                </li>
                            }
                            <li [class]="cx('filterConstraintSeparator')" [pBind]="ptm('filterConstraintSeparator', { context: { index: i } })"></li>
                            <li [class]="cx('filterConstraint')" [pBind]="ptm('emtpyFilterLabel')" (click)="onRowClearItemClick()" (keydown)="onRowMatchModeKeyDown($event)" (keydown.enter)="onRowClearItemClick()">
                                {{ noFilterLabel }}
                            </li>
                        </ul>
                    } @else {
                        @if (isShowOperator) {
                            <div [class]="cx('filterOperator')" [pBind]="ptm('filterOperator')">
                                <p-select
                                    [options]="operatorOptions"
                                    [pt]="ptm('pcFilterOperatorDropdown')"
                                    [ngModel]="operator()"
                                    (ngModelChange)="onOperatorChange($event)"
                                    [styleClass]="cx('pcFilterOperatorDropdown')"
                                    [unstyled]="unstyled()"
                                ></p-select>
                            </div>
                        }
                        <div [class]="cx('filterRuleList')" [pBind]="ptm('filterRuleList')">
                            @for (fieldConstraint of fieldConstraints; track fieldConstraint; let i = $index) {
                                <div [ngClass]="cx('filterRule')" [pBind]="ptm('filterRule')">
                                    @if (showMatchModes() && matchModes) {
                                        <p-select
                                            [options]="matchModes"
                                            [ngModel]="fieldConstraint.matchMode"
                                            (ngModelChange)="onMenuMatchModeChange($event, fieldConstraint)"
                                            [styleClass]="cx('pcFilterConstraintDropdown')"
                                            [pt]="ptm('pcFilterConstraintDropdown')"
                                            [unstyled]="unstyled()"
                                        ></p-select>
                                    }
                                    <p-columnFilterFormElement
                                        [type]="type()"
                                        [field]="field()"
                                        [filterConstraint]="fieldConstraint"
                                        [filterTemplate]="filterTemplate() || _filterTemplate"
                                        [placeholder]="placeholder()"
                                        [minFractionDigits]="minFractionDigits()"
                                        [maxFractionDigits]="maxFractionDigits()"
                                        [prefix]="prefix()"
                                        [suffix]="suffix()"
                                        [locale]="locale()"
                                        [localeMatcher]="localeMatcher()"
                                        [currency]="currency()"
                                        [currencyDisplay]="currencyDisplay()"
                                        [useGrouping]="useGrouping()"
                                        [filterOn]="filterOn()"
                                        [pt]="pt()"
                                        [unstyled]="unstyled()"
                                    ></p-columnFilterFormElement>
                                    <div>
                                        @if (showRemoveIcon) {
                                            <p-button
                                                [styleClass]="cx('pcFilterRemoveRuleButton')"
                                                [pt]="ptm('pcFilterRemoveRuleButton')"
                                                [text]="true"
                                                severity="danger"
                                                size="small"
                                                (onClick)="removeConstraint(fieldConstraint)"
                                                [ariaLabel]="removeRuleButtonLabel"
                                                [label]="removeRuleButtonLabel"
                                                [buttonProps]="filterButtonProps()?.popover?.removeRule"
                                                [unstyled]="unstyled()"
                                            >
                                                <ng-template #icon>
                                                    @if (!removeRuleIconTemplate() && !_removeRuleIconTemplate) {
                                                        <svg data-p-icon="trash" [pBind]="ptm('pcFilterRemoveRuleButton')['icon']" />
                                                    }
                                                    <ng-template *ngTemplateOutlet="removeRuleIconTemplate() || _removeRuleIconTemplate"></ng-template>
                                                </ng-template>
                                            </p-button>
                                        }
                                    </div>
                                </div>
                            }
                        </div>
                        @if (isShowAddConstraint) {
                            <p-button
                                type="button"
                                [pt]="ptm('pcAddRuleButtonLabel')"
                                [label]="addRuleButtonLabel"
                                [attr.aria-label]="addRuleButtonLabel"
                                [styleClass]="cx('pcFilterAddRuleButton')"
                                [text]="true"
                                size="small"
                                (onClick)="addConstraint()"
                                [buttonProps]="filterButtonProps()?.popover?.addRule"
                                [unstyled]="unstyled()"
                            >
                                <ng-template #icon>
                                    @if (!addRuleIconTemplate() && !_addRuleIconTemplate) {
                                        <svg data-p-icon="plus" [pBind]="ptm('pcAddRuleButtonLabel')['icon']" />
                                    }
                                    <ng-template *ngTemplateOutlet="addRuleIconTemplate() || _addRuleIconTemplate"></ng-template>
                                </ng-template>
                            </p-button>
                        }
                        <div [class]="cx('filterButtonbar')" [pBind]="ptm('filterButtonBar')">
                            @if (showClearButton()) {
                                <p-button
                                    #clearBtn
                                    [outlined]="true"
                                    (onClick)="clearFilter()"
                                    [attr.aria-label]="clearButtonLabel"
                                    [label]="clearButtonLabel"
                                    [buttonProps]="filterButtonProps()?.popover?.clear"
                                    [pt]="ptm('pcFilterClearButton')"
                                    [unstyled]="unstyled()"
                                />
                            }
                            @if (showApplyButton()) {
                                <p-button
                                    (onClick)="applyFilter()"
                                    size="small"
                                    [label]="applyButtonLabel"
                                    [attr.aria-label]="applyButtonLabel"
                                    [buttonProps]="filterButtonProps()?.popover?.apply"
                                    [pt]="ptm('pcFilterApplyButton')"
                                    [unstyled]="unstyled()"
                                />
                            }
                        </div>
                    }
                    <ng-container *ngTemplateOutlet="footerTemplate() || _footerTemplate; context: { $implicit: field() }"></ng-container>
                </div>
            }
        </div>
    `,
                    providers: [TableStyle],
                    encapsulation: ViewEncapsulation.None,
                    hostDirectives: [Bind],
                    imports: [forwardRef(() => ColumnFilterFormElement), Button, FilterIcon, FilterFillIcon, NgTemplateOutlet, MotionDirective, Select, FormsModule, NgClass, TrashIcon, PlusIcon]
                }]
        }], ctorParameters: () => [], propDecorators: { field: [{ type: i0.Input, args: [{ isSignal: true, alias: "field", required: false }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], display: [{ type: i0.Input, args: [{ isSignal: true, alias: "display", required: false }] }], showMenu: [{ type: i0.Input, args: [{ isSignal: true, alias: "showMenu", required: false }] }], matchMode: [{ type: i0.Input, args: [{ isSignal: true, alias: "matchMode", required: false }] }], operator: [{ type: i0.Input, args: [{ isSignal: true, alias: "operator", required: false }] }], showOperator: [{ type: i0.Input, args: [{ isSignal: true, alias: "showOperator", required: false }] }], showClearButton: [{ type: i0.Input, args: [{ isSignal: true, alias: "showClearButton", required: false }] }], showApplyButton: [{ type: i0.Input, args: [{ isSignal: true, alias: "showApplyButton", required: false }] }], showMatchModes: [{ type: i0.Input, args: [{ isSignal: true, alias: "showMatchModes", required: false }] }], showAddButton: [{ type: i0.Input, args: [{ isSignal: true, alias: "showAddButton", required: false }] }], hideOnClear: [{ type: i0.Input, args: [{ isSignal: true, alias: "hideOnClear", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], matchModeOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "matchModeOptions", required: false }] }], maxConstraints: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxConstraints", required: false }] }], minFractionDigits: [{ type: i0.Input, args: [{ isSignal: true, alias: "minFractionDigits", required: false }] }], maxFractionDigits: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxFractionDigits", required: false }] }], prefix: [{ type: i0.Input, args: [{ isSignal: true, alias: "prefix", required: false }] }], suffix: [{ type: i0.Input, args: [{ isSignal: true, alias: "suffix", required: false }] }], locale: [{ type: i0.Input, args: [{ isSignal: true, alias: "locale", required: false }] }], localeMatcher: [{ type: i0.Input, args: [{ isSignal: true, alias: "localeMatcher", required: false }] }], currency: [{ type: i0.Input, args: [{ isSignal: true, alias: "currency", required: false }] }], currencyDisplay: [{ type: i0.Input, args: [{ isSignal: true, alias: "currencyDisplay", required: false }] }], filterOn: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterOn", required: false }] }], useGrouping: [{ type: i0.Input, args: [{ isSignal: true, alias: "useGrouping", required: false }] }], showButtons: [{ type: i0.Input, args: [{ isSignal: true, alias: "showButtons", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], filterButtonProps: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterButtonProps", required: false }] }], motionOptions: [{ type: i0.Input, args: [{ isSignal: true, alias: "motionOptions", required: false }] }], onShow: [{ type: i0.Output, args: ["onShow"] }], onHide: [{ type: i0.Output, args: ["onHide"] }], icon: [{ type: i0.ViewChild, args: [i0.forwardRef(() => Button), { ...{ read: ElementRef }, isSignal: true }] }], clearButtonViewChild: [{ type: i0.ViewChild, args: ['clearBtn', { isSignal: true }] }], _templates: [{ type: i0.ContentChildren, args: [i0.forwardRef(() => PrimeTemplate), { isSignal: true }] }], headerTemplate: [{ type: i0.ContentChild, args: ['header', { ...{ descendants: false }, isSignal: true }] }], filterTemplate: [{ type: i0.ContentChild, args: ['filter', { ...{ descendants: false }, isSignal: true }] }], footerTemplate: [{ type: i0.ContentChild, args: ['footer', { ...{ descendants: false }, isSignal: true }] }], filterIconTemplate: [{
                type: ContentChild,
                args: ['filtericon', { descendants: false }]
            }], removeRuleIconTemplate: [{ type: i0.ContentChild, args: ['removeruleicon', { ...{ descendants: false }, isSignal: true }] }], addRuleIconTemplate: [{ type: i0.ContentChild, args: ['addruleicon', { ...{ descendants: false }, isSignal: true }] }], clearFilterIconTemplate: [{ type: i0.ContentChild, args: ['clearfiltericon', { ...{ descendants: false }, isSignal: true }] }] } });
class ColumnFilterFormElement extends BaseComponent {
    dataTable = inject(Table);
    colFilter = inject(ColumnFilter);
    hostName = 'Table';
    bindDirectiveInstance = inject(Bind, { self: true });
    _componentStyle = inject(TableStyle);
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptm('columnFilterFormElement'));
    }
    field = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "field" }] : /* istanbul ignore next */ []));
    type = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "type" }] : /* istanbul ignore next */ []));
    filterConstraint = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "filterConstraint" }] : /* istanbul ignore next */ []));
    filterTemplate = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "filterTemplate" }] : /* istanbul ignore next */ []));
    placeholder = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "placeholder" }] : /* istanbul ignore next */ []));
    minFractionDigits = input(undefined, { ...(ngDevMode ? { debugName: "minFractionDigits" } : /* istanbul ignore next */ {}), transform: (value) => numberAttribute(value, undefined) });
    maxFractionDigits = input(undefined, { ...(ngDevMode ? { debugName: "maxFractionDigits" } : /* istanbul ignore next */ {}), transform: (value) => numberAttribute(value, undefined) });
    prefix = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "prefix" }] : /* istanbul ignore next */ []));
    suffix = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "suffix" }] : /* istanbul ignore next */ []));
    locale = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "locale" }] : /* istanbul ignore next */ []));
    localeMatcher = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "localeMatcher" }] : /* istanbul ignore next */ []));
    currency = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "currency" }] : /* istanbul ignore next */ []));
    currencyDisplay = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "currencyDisplay" }] : /* istanbul ignore next */ []));
    useGrouping = input(true, { ...(ngDevMode ? { debugName: "useGrouping" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    ariaLabel = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    filterOn = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "filterOn" }] : /* istanbul ignore next */ []));
    get showButtons() {
        return this.colFilter.showButtons();
    }
    filterCallback;
    onInit() {
        this.filterCallback = (value) => {
            this.filterConstraint().value = value;
            this.dataTable._filter();
        };
    }
    onModelChange(value) {
        this.filterConstraint().value = value;
        const type = this.type();
        if (type === 'date' || type === 'boolean' || ((type === 'text' || type === 'numeric') && this.filterOn() === 'input') || !value) {
            this.dataTable._filter();
        }
    }
    onTextInputEnterKeyDown(event) {
        this.dataTable._filter();
        event.preventDefault();
    }
    onNumericInputKeyDown(event) {
        if (event.key === 'Enter') {
            this.dataTable._filter();
            event.preventDefault();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ColumnFilterFormElement, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.1.2", type: ColumnFilterFormElement, isStandalone: true, selector: "p-columnFilterFormElement, p-column-filter-form-element, p-columnfilterformelement", inputs: { field: { classPropertyName: "field", publicName: "field", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, filterConstraint: { classPropertyName: "filterConstraint", publicName: "filterConstraint", isSignal: true, isRequired: false, transformFunction: null }, filterTemplate: { classPropertyName: "filterTemplate", publicName: "filterTemplate", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, minFractionDigits: { classPropertyName: "minFractionDigits", publicName: "minFractionDigits", isSignal: true, isRequired: false, transformFunction: null }, maxFractionDigits: { classPropertyName: "maxFractionDigits", publicName: "maxFractionDigits", isSignal: true, isRequired: false, transformFunction: null }, prefix: { classPropertyName: "prefix", publicName: "prefix", isSignal: true, isRequired: false, transformFunction: null }, suffix: { classPropertyName: "suffix", publicName: "suffix", isSignal: true, isRequired: false, transformFunction: null }, locale: { classPropertyName: "locale", publicName: "locale", isSignal: true, isRequired: false, transformFunction: null }, localeMatcher: { classPropertyName: "localeMatcher", publicName: "localeMatcher", isSignal: true, isRequired: false, transformFunction: null }, currency: { classPropertyName: "currency", publicName: "currency", isSignal: true, isRequired: false, transformFunction: null }, currencyDisplay: { classPropertyName: "currencyDisplay", publicName: "currencyDisplay", isSignal: true, isRequired: false, transformFunction: null }, useGrouping: { classPropertyName: "useGrouping", publicName: "useGrouping", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, filterOn: { classPropertyName: "filterOn", publicName: "filterOn", isSignal: true, isRequired: false, transformFunction: null } }, providers: [TableStyle], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        @if (filterTemplate()) {
            <ng-container
                *ngTemplateOutlet="
                    filterTemplate();
                    context: {
                        $implicit: filterConstraint().value,
                        filterCallback: filterCallback,
                        type: type(),
                        field: field(),
                        filterConstraint: filterConstraint(),
                        placeholder: placeholder(),
                        minFractionDigits: minFractionDigits(),
                        maxFractionDigits: maxFractionDigits(),
                        prefix: prefix(),
                        suffix: suffix(),
                        locale: locale(),
                        localeMatcher: localeMatcher(),
                        currency: currency(),
                        currencyDisplay: currencyDisplay(),
                        useGrouping: useGrouping(),
                        showButtons: showButtons
                    }
                "
            ></ng-container>
        } @else {
            @switch (type()) {
                @case ('text') {
                    <input
                        type="text"
                        [ariaLabel]="ariaLabel()"
                        pInputText
                        [pt]="ptm('pcFilterInputText')"
                        [value]="filterConstraint()?.value"
                        (input)="onModelChange($event.target.value)"
                        (keydown.enter)="onTextInputEnterKeyDown($event)"
                        [attr.placeholder]="placeholder()"
                        [unstyled]="unstyled()"
                    />
                }
                @case ('numeric') {
                    <p-inputNumber
                        [ngModel]="filterConstraint()?.value"
                        (ngModelChange)="onModelChange($event)"
                        (onKeyDown)="onNumericInputKeyDown($event)"
                        [showButtons]="showButtons"
                        [minFractionDigits]="minFractionDigits()"
                        [maxFractionDigits]="maxFractionDigits()"
                        [ariaLabel]="ariaLabel()"
                        [prefix]="prefix()"
                        [suffix]="suffix()"
                        [placeholder]="placeholder()"
                        [mode]="currency() ? 'currency' : 'decimal'"
                        [locale]="locale()"
                        [localeMatcher]="localeMatcher()"
                        [currency]="currency()"
                        [currencyDisplay]="currencyDisplay()"
                        [useGrouping]="useGrouping()"
                        [pt]="ptm('pcFilterInputNumber')"
                        [unstyled]="unstyled()"
                    ></p-inputNumber>
                }
                @case ('boolean') {
                    <p-checkbox [pt]="ptm('pcFilterCheckbox')" [indeterminate]="filterConstraint()?.value === null" [binary]="true" [ngModel]="filterConstraint()?.value" (ngModelChange)="onModelChange($event)" [unstyled]="unstyled()" />
                }
                @case ('date') {
                    <p-datepicker
                        [pt]="ptm('pcFilterDatePicker')"
                        [ariaLabel]="ariaLabel()"
                        [placeholder]="placeholder()"
                        [ngModel]="filterConstraint()?.value"
                        (ngModelChange)="onModelChange($event)"
                        appendTo="body"
                        [unstyled]="unstyled()"
                    ></p-datepicker>
                }
            }
        }
    `, isInline: true, dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: InputText, selector: "[pInputText]", inputs: ["hostName", "ptInputText", "pInputTextPT", "pInputTextUnstyled", "pSize", "variant", "fluid", "invalid"] }, { kind: "component", type: InputNumber, selector: "p-inputNumber, p-inputnumber, p-input-number", inputs: ["showButtons", "format", "buttonLayout", "inputId", "styleClass", "placeholder", "tabindex", "title", "ariaLabelledBy", "ariaDescribedBy", "ariaLabel", "ariaRequired", "autocomplete", "incrementButtonClass", "decrementButtonClass", "incrementButtonIcon", "decrementButtonIcon", "readonly", "allowEmpty", "locale", "localeMatcher", "mode", "currency", "currencyDisplay", "useGrouping", "minFractionDigits", "maxFractionDigits", "prefix", "suffix", "inputStyle", "inputStyleClass", "showClear", "autofocus"], outputs: ["onInput", "onFocus", "onBlur", "onKeyDown", "onClear"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: Checkbox, selector: "p-checkbox, p-checkBox, p-check-box", inputs: ["hostName", "value", "binary", "ariaLabelledBy", "ariaLabel", "tabindex", "inputId", "inputStyle", "styleClass", "inputClass", "indeterminate", "formControl", "checkboxIcon", "readonly", "autofocus", "trueValue", "falseValue", "variant", "size"], outputs: ["onChange", "onFocus", "onBlur"] }, { kind: "component", type: DatePicker, selector: "p-datePicker, p-datepicker, p-date-picker", inputs: ["iconDisplay", "styleClass", "inputStyle", "inputId", "inputStyleClass", "placeholder", "ariaLabelledBy", "ariaLabel", "iconAriaLabel", "dateFormat", "multipleSeparator", "rangeSeparator", "inline", "showOtherMonths", "selectOtherMonths", "showIcon", "icon", "readonlyInput", "shortYearCutoff", "hourFormat", "timeOnly", "stepHour", "stepMinute", "stepSecond", "showSeconds", "showOnFocus", "showWeek", "startWeekFromFirstDayOfYear", "showClear", "dataType", "selectionMode", "maxDateCount", "showButtonBar", "todayButtonStyleClass", "clearButtonStyleClass", "autofocus", "autoZIndex", "baseZIndex", "panelStyleClass", "panelStyle", "keepInvalid", "hideOnDateTimeSelect", "touchUI", "timeSeparator", "focusTrap", "showTransitionOptions", "hideTransitionOptions", "tabindex", "minDate", "maxDate", "disabledDates", "disabledDays", "showTime", "responsiveOptions", "numberOfMonths", "firstDayOfWeek", "view", "defaultDate", "appendTo", "motionOptions"], outputs: ["onFocus", "onBlur", "onClose", "onSelect", "onClear", "onInput", "onTodayClick", "onClearClick", "onMonthChange", "onYearChange", "onClickOutside", "onShow"] }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: ColumnFilterFormElement, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-columnFilterFormElement, p-column-filter-form-element, p-columnfilterformelement',
                    template: `
        @if (filterTemplate()) {
            <ng-container
                *ngTemplateOutlet="
                    filterTemplate();
                    context: {
                        $implicit: filterConstraint().value,
                        filterCallback: filterCallback,
                        type: type(),
                        field: field(),
                        filterConstraint: filterConstraint(),
                        placeholder: placeholder(),
                        minFractionDigits: minFractionDigits(),
                        maxFractionDigits: maxFractionDigits(),
                        prefix: prefix(),
                        suffix: suffix(),
                        locale: locale(),
                        localeMatcher: localeMatcher(),
                        currency: currency(),
                        currencyDisplay: currencyDisplay(),
                        useGrouping: useGrouping(),
                        showButtons: showButtons
                    }
                "
            ></ng-container>
        } @else {
            @switch (type()) {
                @case ('text') {
                    <input
                        type="text"
                        [ariaLabel]="ariaLabel()"
                        pInputText
                        [pt]="ptm('pcFilterInputText')"
                        [value]="filterConstraint()?.value"
                        (input)="onModelChange($event.target.value)"
                        (keydown.enter)="onTextInputEnterKeyDown($event)"
                        [attr.placeholder]="placeholder()"
                        [unstyled]="unstyled()"
                    />
                }
                @case ('numeric') {
                    <p-inputNumber
                        [ngModel]="filterConstraint()?.value"
                        (ngModelChange)="onModelChange($event)"
                        (onKeyDown)="onNumericInputKeyDown($event)"
                        [showButtons]="showButtons"
                        [minFractionDigits]="minFractionDigits()"
                        [maxFractionDigits]="maxFractionDigits()"
                        [ariaLabel]="ariaLabel()"
                        [prefix]="prefix()"
                        [suffix]="suffix()"
                        [placeholder]="placeholder()"
                        [mode]="currency() ? 'currency' : 'decimal'"
                        [locale]="locale()"
                        [localeMatcher]="localeMatcher()"
                        [currency]="currency()"
                        [currencyDisplay]="currencyDisplay()"
                        [useGrouping]="useGrouping()"
                        [pt]="ptm('pcFilterInputNumber')"
                        [unstyled]="unstyled()"
                    ></p-inputNumber>
                }
                @case ('boolean') {
                    <p-checkbox [pt]="ptm('pcFilterCheckbox')" [indeterminate]="filterConstraint()?.value === null" [binary]="true" [ngModel]="filterConstraint()?.value" (ngModelChange)="onModelChange($event)" [unstyled]="unstyled()" />
                }
                @case ('date') {
                    <p-datepicker
                        [pt]="ptm('pcFilterDatePicker')"
                        [ariaLabel]="ariaLabel()"
                        [placeholder]="placeholder()"
                        [ngModel]="filterConstraint()?.value"
                        (ngModelChange)="onModelChange($event)"
                        appendTo="body"
                        [unstyled]="unstyled()"
                    ></p-datepicker>
                }
            }
        }
    `,
                    providers: [TableStyle],
                    encapsulation: ViewEncapsulation.None,
                    hostDirectives: [Bind],
                    imports: [NgTemplateOutlet, Bind, InputText, InputNumber, FormsModule, Checkbox, DatePicker]
                }]
        }], propDecorators: { field: [{ type: i0.Input, args: [{ isSignal: true, alias: "field", required: false }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], filterConstraint: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterConstraint", required: false }] }], filterTemplate: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterTemplate", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], minFractionDigits: [{ type: i0.Input, args: [{ isSignal: true, alias: "minFractionDigits", required: false }] }], maxFractionDigits: [{ type: i0.Input, args: [{ isSignal: true, alias: "maxFractionDigits", required: false }] }], prefix: [{ type: i0.Input, args: [{ isSignal: true, alias: "prefix", required: false }] }], suffix: [{ type: i0.Input, args: [{ isSignal: true, alias: "suffix", required: false }] }], locale: [{ type: i0.Input, args: [{ isSignal: true, alias: "locale", required: false }] }], localeMatcher: [{ type: i0.Input, args: [{ isSignal: true, alias: "localeMatcher", required: false }] }], currency: [{ type: i0.Input, args: [{ isSignal: true, alias: "currency", required: false }] }], currencyDisplay: [{ type: i0.Input, args: [{ isSignal: true, alias: "currencyDisplay", required: false }] }], useGrouping: [{ type: i0.Input, args: [{ isSignal: true, alias: "useGrouping", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], filterOn: [{ type: i0.Input, args: [{ isSignal: true, alias: "filterOn", required: false }] }] } });
class TableModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: TableModule, imports: [CommonModule,
            PaginatorModule,
            InputTextModule,
            SelectModule,
            FormsModule,
            ButtonModule,
            SelectButtonModule,
            DatePickerModule,
            InputNumberModule,
            BadgeModule,
            CheckboxModule,
            ScrollerModule,
            ArrowDownIcon,
            ArrowUpIcon,
            SpinnerIcon,
            SortAltIcon,
            SortAmountUpAltIcon,
            SortAmountDownIcon,
            FilterIcon,
            FilterFillIcon,
            FilterSlashIcon,
            PlusIcon,
            TrashIcon,
            RadioButtonModule,
            BindModule,
            MotionModule, Table, SortableColumn, FrozenColumn, RowGroupHeader, SelectableRow, RowToggler, ContextMenuRow, ResizableColumn, ReorderableColumn, EditableColumn, CellEditor, TableBody, SortIcon, TableRadioButton, TableCheckbox, TableHeaderCheckbox, ReorderableRowHandle, ReorderableRow, SelectableRowDblClick, EditableRow, InitEditableRow, SaveEditableRow, CancelEditableRow, ColumnFilter, ColumnFilterFormElement], exports: [Table, SharedModule, SortableColumn, FrozenColumn, RowGroupHeader, SelectableRow, RowToggler, ContextMenuRow, ResizableColumn, ReorderableColumn, EditableColumn, CellEditor, SortIcon, TableRadioButton, TableCheckbox, TableHeaderCheckbox, ReorderableRowHandle, ReorderableRow, SelectableRowDblClick, EditableRow, InitEditableRow, SaveEditableRow, CancelEditableRow, ColumnFilter, ColumnFilterFormElement, ScrollerModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableModule, providers: [TableStyle], imports: [CommonModule,
            PaginatorModule,
            InputTextModule,
            SelectModule,
            FormsModule,
            ButtonModule,
            SelectButtonModule,
            DatePickerModule,
            InputNumberModule,
            BadgeModule,
            CheckboxModule,
            ScrollerModule,
            ArrowDownIcon,
            ArrowUpIcon,
            SpinnerIcon,
            SortAltIcon,
            SortAmountUpAltIcon,
            SortAmountDownIcon,
            FilterIcon,
            FilterFillIcon,
            FilterSlashIcon,
            PlusIcon,
            TrashIcon,
            RadioButtonModule,
            BindModule,
            MotionModule,
            Table,
            SortIcon,
            TableRadioButton,
            TableCheckbox,
            TableHeaderCheckbox,
            ColumnFilter,
            ColumnFilterFormElement, SharedModule,
            ScrollerModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: TableModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        CommonModule,
                        PaginatorModule,
                        InputTextModule,
                        SelectModule,
                        FormsModule,
                        ButtonModule,
                        SelectButtonModule,
                        DatePickerModule,
                        InputNumberModule,
                        BadgeModule,
                        CheckboxModule,
                        ScrollerModule,
                        ArrowDownIcon,
                        ArrowUpIcon,
                        SpinnerIcon,
                        SortAltIcon,
                        SortAmountUpAltIcon,
                        SortAmountDownIcon,
                        FilterIcon,
                        FilterFillIcon,
                        FilterSlashIcon,
                        PlusIcon,
                        TrashIcon,
                        RadioButtonModule,
                        BindModule,
                        MotionModule,
                        Table,
                        SortableColumn,
                        FrozenColumn,
                        RowGroupHeader,
                        SelectableRow,
                        RowToggler,
                        ContextMenuRow,
                        ResizableColumn,
                        ReorderableColumn,
                        EditableColumn,
                        CellEditor,
                        TableBody,
                        SortIcon,
                        TableRadioButton,
                        TableCheckbox,
                        TableHeaderCheckbox,
                        ReorderableRowHandle,
                        ReorderableRow,
                        SelectableRowDblClick,
                        EditableRow,
                        InitEditableRow,
                        SaveEditableRow,
                        CancelEditableRow,
                        ColumnFilter,
                        ColumnFilterFormElement
                    ],
                    exports: [
                        Table,
                        SharedModule,
                        SortableColumn,
                        FrozenColumn,
                        RowGroupHeader,
                        SelectableRow,
                        RowToggler,
                        ContextMenuRow,
                        ResizableColumn,
                        ReorderableColumn,
                        EditableColumn,
                        CellEditor,
                        SortIcon,
                        TableRadioButton,
                        TableCheckbox,
                        TableHeaderCheckbox,
                        ReorderableRowHandle,
                        ReorderableRow,
                        SelectableRowDblClick,
                        EditableRow,
                        InitEditableRow,
                        SaveEditableRow,
                        CancelEditableRow,
                        ColumnFilter,
                        ColumnFilterFormElement,
                        ScrollerModule
                    ],
                    providers: [TableStyle]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { CancelEditableRow, CellEditor, ColumnFilter, ColumnFilterFormElement, ContextMenuRow, EditableColumn, EditableRow, FrozenColumn, InitEditableRow, ReorderableColumn, ReorderableRow, ReorderableRowHandle, ResizableColumn, RowGroupHeader, RowToggler, SaveEditableRow, SelectableRow, SelectableRowDblClick, SortIcon, SortableColumn, Table, TableBody, TableCheckbox, TableClasses, TableHeaderCheckbox, TableModule, TableRadioButton, TableService, TableStyle };
//# sourceMappingURL=wawjs-ngx-prime-table.mjs.map
