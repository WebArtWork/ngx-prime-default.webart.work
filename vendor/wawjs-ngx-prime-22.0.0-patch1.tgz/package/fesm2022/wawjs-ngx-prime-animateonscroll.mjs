import { isPlatformBrowser } from '@angular/common';
import * as i0 from '@angular/core';
import { input, numberAttribute, booleanAttribute, Directive, NgModule } from '@angular/core';
import { removeClass, addClass } from '@wawjs/css-prime-utils';
import { BaseComponent } from '@wawjs/ngx-prime/basecomponent';

/**
 * AnimateOnScroll is used to apply animations to elements when entering or leaving the viewport during scrolling.
 * @group Components
 */
class AnimateOnScroll extends BaseComponent {
    /**
     * Selector to define the CSS class for enter animation.
     * @group Props
     */
    enterClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "enterClass" }] : /* istanbul ignore next */ []));
    /**
     * Selector to define the CSS class for leave animation.
     * @group Props
     */
    leaveClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "leaveClass" }] : /* istanbul ignore next */ []));
    /**
     * Specifies the root option of the IntersectionObserver API.
     * @group Props
     */
    root = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "root" }] : /* istanbul ignore next */ []));
    /**
     * Specifies the rootMargin option of the IntersectionObserver API.
     * @group Props
     */
    rootMargin = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "rootMargin" }] : /* istanbul ignore next */ []));
    /**
     * Specifies the threshold option of the IntersectionObserver API
     * @group Props
     */
    threshold = input(0.5, { ...(ngDevMode ? { debugName: "threshold" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /**
     * Whether the scroll event listener should be removed after initial run.
     * @group Props
     */
    once = input(false, { ...(ngDevMode ? { debugName: "once" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    observer;
    resetObserver;
    isObserverActive = false;
    animationState;
    animationEndListener;
    onInit() {
        if (isPlatformBrowser(this.platformId)) {
            this.renderer.setStyle(this.el.nativeElement, 'opacity', this.enterClass() ? '0' : '');
        }
    }
    onAfterViewInit() {
        if (isPlatformBrowser(this.platformId)) {
            this.bindIntersectionObserver();
        }
    }
    get options() {
        return {
            root: this.root(),
            rootMargin: this.rootMargin(),
            threshold: this.threshold() || 0.5
        };
    }
    bindIntersectionObserver() {
        this.observer = new IntersectionObserver(([entry]) => {
            if (this.isObserverActive) {
                if (entry.boundingClientRect.top > 0) {
                    entry.isIntersecting ? this.enter() : this.leave();
                }
            }
            else if (entry.isIntersecting) {
                this.enter();
            }
            this.isObserverActive = true;
        }, this.options);
        setTimeout(() => this.observer?.observe(this.el.nativeElement), 0);
        // Reset
        this.resetObserver = new IntersectionObserver(([entry]) => {
            if (entry.boundingClientRect.top > 0 && !entry.isIntersecting) {
                this.el.nativeElement.style.opacity = this.enterClass() ? '0' : '';
                removeClass(this.el.nativeElement, [this.enterClass(), this.leaveClass()]);
                this.resetObserver.unobserve(this.el.nativeElement);
            }
            this.animationState = undefined;
        }, { ...this.options, threshold: 0 });
    }
    enter() {
        if (this.animationState !== 'enter' && this.enterClass()) {
            this.el.nativeElement.style.opacity = '';
            removeClass(this.el.nativeElement, this.leaveClass());
            addClass(this.el.nativeElement, this.enterClass());
            this.once() && this.unbindIntersectionObserver();
            this.bindAnimationEvents();
            this.animationState = 'enter';
        }
    }
    leave() {
        if (this.animationState !== 'leave' && this.leaveClass()) {
            this.el.nativeElement.style.opacity = this.enterClass() ? '0' : '';
            removeClass(this.el.nativeElement, this.enterClass());
            addClass(this.el.nativeElement, this.leaveClass());
            this.bindAnimationEvents();
            this.animationState = 'leave';
        }
    }
    bindAnimationEvents() {
        if (!this.animationEndListener) {
            this.animationEndListener = this.renderer.listen(this.el.nativeElement, 'animationend', () => {
                removeClass(this.el.nativeElement, [this.enterClass(), this.leaveClass()]);
                !this.once() && this.resetObserver.observe(this.el.nativeElement);
                this.unbindAnimationEvents();
            });
        }
    }
    unbindAnimationEvents() {
        if (this.animationEndListener) {
            this.animationEndListener();
            this.animationEndListener = null;
        }
    }
    unbindIntersectionObserver() {
        this.observer?.unobserve(this.el.nativeElement);
        this.resetObserver?.unobserve(this.el.nativeElement);
        this.isObserverActive = false;
    }
    onDestroy() {
        this.unbindAnimationEvents();
        this.unbindIntersectionObserver();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AnimateOnScroll, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.1.2", type: AnimateOnScroll, isStandalone: true, selector: "[pAnimateOnScroll]", inputs: { enterClass: { classPropertyName: "enterClass", publicName: "enterClass", isSignal: true, isRequired: false, transformFunction: null }, leaveClass: { classPropertyName: "leaveClass", publicName: "leaveClass", isSignal: true, isRequired: false, transformFunction: null }, root: { classPropertyName: "root", publicName: "root", isSignal: true, isRequired: false, transformFunction: null }, rootMargin: { classPropertyName: "rootMargin", publicName: "rootMargin", isSignal: true, isRequired: false, transformFunction: null }, threshold: { classPropertyName: "threshold", publicName: "threshold", isSignal: true, isRequired: false, transformFunction: null }, once: { classPropertyName: "once", publicName: "once", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.p-animateonscroll": "true" } }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AnimateOnScroll, decorators: [{
            type: Directive,
            args: [{
                    selector: '[pAnimateOnScroll]',
                    standalone: true,
                    host: {
                        '[class.p-animateonscroll]': 'true'
                    }
                }]
        }], propDecorators: { enterClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "enterClass", required: false }] }], leaveClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "leaveClass", required: false }] }], root: [{ type: i0.Input, args: [{ isSignal: true, alias: "root", required: false }] }], rootMargin: [{ type: i0.Input, args: [{ isSignal: true, alias: "rootMargin", required: false }] }], threshold: [{ type: i0.Input, args: [{ isSignal: true, alias: "threshold", required: false }] }], once: [{ type: i0.Input, args: [{ isSignal: true, alias: "once", required: false }] }] } });
class AnimateOnScrollModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AnimateOnScrollModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: AnimateOnScrollModule, imports: [AnimateOnScroll], exports: [AnimateOnScroll] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AnimateOnScrollModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: AnimateOnScrollModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [AnimateOnScroll],
                    exports: [AnimateOnScroll]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { AnimateOnScroll, AnimateOnScrollModule };
//# sourceMappingURL=wawjs-ngx-prime-animateonscroll.mjs.map
