import * as i0 from '@angular/core';
import { Injectable, InjectionToken, inject, input, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { SharedModule } from '@wawjs/ngx-prime/api';
import { BaseComponent, PARENT_INSTANCE } from '@wawjs/ngx-prime/basecomponent';
import * as i1 from '@wawjs/ngx-prime/bind';
import { Bind, BindModule } from '@wawjs/ngx-prime/bind';
import { style } from '@wawjs/css-prime-styles/divider';
import { BaseStyle } from '@wawjs/ngx-prime/base';

/* Position */
const inlineStyles = {
    root: ({ instance }) => ({
        justifyContent: instance.layout() === 'horizontal' ? (instance.align() === 'center' || instance.align() == null ? 'center' : instance.align() === 'left' ? 'flex-start' : instance.align() === 'right' ? 'flex-end' : null) : null,
        alignItems: instance.layout() === 'vertical' ? (instance.align() === 'center' || instance.align() == null ? 'center' : instance.align() === 'top' ? 'flex-start' : instance.align() === 'bottom' ? 'flex-end' : null) : null
    })
};
const classes = {
    root: ({ instance }) => [
        'p-divider p-component',
        'p-divider-' + instance.layout(),
        'p-divider-' + instance.type(),
        { 'p-divider-left': instance.layout() === 'horizontal' && (!instance.align() || instance.align() === 'left') },
        { 'p-divider-center': instance.layout() === 'horizontal' && instance.align() === 'center' },
        { 'p-divider-right': instance.layout() === 'horizontal' && instance.align() === 'right' },
        { 'p-divider-top': instance.layout() === 'vertical' && instance.align() === 'top' },
        { 'p-divider-center': instance.layout() === 'vertical' && (!instance.align() || instance.align() === 'center') },
        { 'p-divider-bottom': instance.layout() === 'vertical' && instance.align() === 'bottom' }
    ],
    content: 'p-divider-content'
};
class DividerStyle extends BaseStyle {
    name = 'divider';
    style = style;
    classes = classes;
    inlineStyles = inlineStyles;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DividerStyle, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DividerStyle });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DividerStyle, decorators: [{
            type: Injectable
        }] });
/**
 *
 * Divider is used to separate contents.
 *
 * [Live Demo](https://ngx-prime.org/divider)
 *
 * @module dividerstyle
 *
 */
var DividerClasses;
(function (DividerClasses) {
    /**
     * Class name of the root element
     */
    DividerClasses["root"] = "p-divider";
    /**
     * Class name of the content element
     */
    DividerClasses["content"] = "p-divider-content";
})(DividerClasses || (DividerClasses = {}));

const DIVIDER_INSTANCE = new InjectionToken('DIVIDER_INSTANCE');
/**
 * Divider is used to separate contents.
 * @group Components
 */
class Divider extends BaseComponent {
    componentName = 'Divider';
    $pcDivider = inject(DIVIDER_INSTANCE, { optional: true, skipSelf: true }) ?? undefined;
    bindDirectiveInstance = inject(Bind, { self: true });
    onAfterViewChecked() {
        this.bindDirectiveInstance.setAttrs(this.ptms(['host', 'root']));
    }
    /**
     * Style class of the component.
     * @deprecated since v20.0.0, use `class` instead.
     * @group Props
     */
    styleClass = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "styleClass" }] : /* istanbul ignore next */ []));
    /**
     * Specifies the orientation.
     * @group Props
     */
    layout = input('horizontal', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "layout" }] : /* istanbul ignore next */ []));
    /**
     * Border style type.
     * @group Props
     */
    type = input('solid', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    /**
     * Alignment of the content.
     * @group Props
     */
    align = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "align" }] : /* istanbul ignore next */ []));
    _componentStyle = inject(DividerStyle);
    get dataP() {
        return this.cn({
            [this.align()]: this.align(),
            [this.layout()]: this.layout(),
            [this.type()]: this.type()
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Divider, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.1.2", type: Divider, isStandalone: true, selector: "p-divider", inputs: { styleClass: { classPropertyName: "styleClass", publicName: "styleClass", isSignal: true, isRequired: false, transformFunction: null }, layout: { classPropertyName: "layout", publicName: "layout", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, align: { classPropertyName: "align", publicName: "align", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "separator" }, properties: { "attr.aria-orientation": "layout()", "class": "cn(cx('root'), styleClass())", "style": "sx('root')", "attr.data-p": "dataP" } }, providers: [DividerStyle, { provide: DIVIDER_INSTANCE, useExisting: Divider }, { provide: PARENT_INSTANCE, useExisting: Divider }], usesInheritance: true, hostDirectives: [{ directive: i1.Bind }], ngImport: i0, template: `
        <div [pBind]="ptm('content')" [class]="cx('content')">
            <ng-content></ng-content>
        </div>
    `, isInline: true, dependencies: [{ kind: "ngmodule", type: SharedModule }, { kind: "ngmodule", type: BindModule }, { kind: "directive", type: i1.Bind, selector: "[pBind]", inputs: ["pBind"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: Divider, decorators: [{
            type: Component,
            args: [{
                    selector: 'p-divider',
                    standalone: true,
                    imports: [SharedModule, BindModule],
                    template: `
        <div [pBind]="ptm('content')" [class]="cx('content')">
            <ng-content></ng-content>
        </div>
    `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        '[attr.aria-orientation]': 'layout()',
                        role: 'separator',
                        '[class]': "cn(cx('root'), styleClass())",
                        '[style]': "sx('root')",
                        '[attr.data-p]': 'dataP'
                    },
                    providers: [DividerStyle, { provide: DIVIDER_INSTANCE, useExisting: Divider }, { provide: PARENT_INSTANCE, useExisting: Divider }],
                    hostDirectives: [Bind]
                }]
        }], propDecorators: { styleClass: [{ type: i0.Input, args: [{ isSignal: true, alias: "styleClass", required: false }] }], layout: [{ type: i0.Input, args: [{ isSignal: true, alias: "layout", required: false }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], align: [{ type: i0.Input, args: [{ isSignal: true, alias: "align", required: false }] }] } });
class DividerModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DividerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "22.1.2", ngImport: i0, type: DividerModule, imports: [Divider, BindModule], exports: [Divider, BindModule] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DividerModule, imports: [Divider, BindModule, BindModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.1.2", ngImport: i0, type: DividerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [Divider, BindModule],
                    exports: [Divider, BindModule]
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { Divider, DividerClasses, DividerModule, DividerStyle };
//# sourceMappingURL=wawjs-ngx-prime-divider.mjs.map
